"""Sunshine application identity: titles are labels, numeric IDs are selectors."""
from urllib.parse import urlencode

MAX_NATIVE_APP_ID = 2147483647


def canonical_app_id(value):
    if value is None or isinstance(value, bool):
        raise ValueError('Missing Sunshine application ID')
    text = str(value)
    # Bound the string before integer parsing (including excessive zeroes).
    if (not text or len(text) > 10 or not text.isascii() or
            not text.isdecimal()):
        raise ValueError('Invalid Sunshine application ID')
    number = int(text)
    if number > MAX_NATIVE_APP_ID:
        raise ValueError('Sunshine application ID exceeds native range')
    return str(number)


def launch_url(base_url, title, app_id):
    if not isinstance(title, str) or not title:
        raise ValueError('Invalid Sunshine application title')
    return base_url + '?' + urlencode({
        'action': 'launch', 'game': title, 'appid': canonical_app_id(app_id)
    })
