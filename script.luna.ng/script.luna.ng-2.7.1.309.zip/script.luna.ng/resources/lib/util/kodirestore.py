"""Short-lived Kodi seek recovery after a definitively rejected Luna NG handoff.

Only a salted fingerprint of the media URI is written to disk. The URI itself
never goes into the plugin callback, a command line, or pending-seek state.
"""
import contextlib
import fcntl
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import secrets
import stat
import tempfile
import time

from resources.lib.util.safejson import read_bounded_json

STATE_NAME = '.luna-pending-seek.json'
LOCK_NAME = '.luna-pending-seek.lock'
SEEK_TIMEOUT_SECONDS = 10
LOCK_WAIT_SECONDS = 5.0
STATE_SCHEMA = 2
TOKEN = re.compile(r'^[0-9a-f]{32}$')
DIGEST = re.compile(r'^[0-9a-f]{64}$')


def _state_path():
    from xbmcvfs import translatePath
    folder = Path(translatePath('special://profile/addon_data/script.luna.ng/'))
    if not folder.is_dir():
        folder.mkdir(parents=True, mode=0o700, exist_ok=True)
    if folder.is_symlink():
        raise OSError('Luna recovery directory must not be a symlink')
    return folder / STATE_NAME


@contextlib.contextmanager
def _locked_state():
    """One stable advisory flock for scheduling, checking, and retirement."""
    path = _state_path()
    flags = (os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0) |
             getattr(os, 'O_NONBLOCK', 0) |
             getattr(os, 'O_CLOEXEC', 0))
    fd = os.open(str(path.parent / LOCK_NAME), flags, 0o600)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or
                info.st_uid != os.geteuid() or
                stat.S_IMODE(info.st_mode) & 0o077):
            raise OSError('Unsafe pending-seek lock file')
        deadline = time.monotonic() + LOCK_WAIT_SECONDS
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('Timed out waiting for pending-seek lock')
                time.sleep(min(0.05, remaining))
        try:
            yield path
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def _alarm(token):
    if not isinstance(token, str) or not TOKEN.fullmatch(token):
        raise ValueError('Invalid deferred seek token')
    # The URI, including possible SMB credentials, is never in a Kodi builtin.
    return ('AlarmClock(LunaSeek%s,'
            'RunPlugin(plugin://script.luna.ng/?action=restore_seek&token=%s),'
            '00:00:01,silent,false)' % (token[:12], token))


def _schedule(token):
    import xbmc
    xbmc.executebuiltin(_alarm(token))


def _fingerprint(uri, salt):
    """Randomly salted one-way media identifier; never store the actual URI."""
    return hashlib.sha256(bytes.fromhex(salt) + uri.encode('utf-8')).hexdigest()


def _read(path):
    try:
        # The same snapshot reader used by Luna's saved JSON enforces
        # O_NOFOLLOW, O_NONBLOCK, a final byte cap, and nesting depth.
        # Ownership and mode checks use that descriptor's fstat metadata.
        data, meta = read_bounded_json(path, 32768, with_stat=True)
        if (not stat.S_ISREG(meta.st_mode) or
                meta.st_uid != os.geteuid() or
                stat.S_IMODE(meta.st_mode) & 0o077 or
                meta.st_size < 15 or meta.st_size > 32768):
            return None
        if (not isinstance(data, dict) or data.get('schema') != STATE_SCHEMA or
                'uri' in data or
                not isinstance(data.get('token'), str) or
                not TOKEN.fullmatch(data['token']) or
                not isinstance(data.get('salt'), str) or
                not TOKEN.fullmatch(data['salt']) or
                not isinstance(data.get('digest'), str) or
                not DIGEST.fullmatch(data['digest']) or
                not isinstance(data.get('position'), (float, int)) or
                not math.isfinite(data['position']) or
                not 0 < data['position'] <= 864000 or
                not isinstance(data.get('expires'), (float, int)) or
                not math.isfinite(data['expires'])):
            return None
        return data
    except (OSError, UnicodeError, ValueError, TypeError):
        return None


def _retire(path, token):
    """Call only while holding _locked_state; validate identity before unlink."""
    record = _read(path)
    if record is not None and record['token'] == token:
        os.unlink(path)
        return True
    return False


def _retire_invalid(path):
    """Remove old plaintext-URI schemas or damaged private state on startup."""
    try:
        info = path.lstat()
        if (stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid() and
                info.st_size <= 32768 and
                not (stat.S_IMODE(info.st_mode) & 0o077)):
            path.unlink()
            return True
    except OSError:
        pass
    return False


def cleanup_expired_seek():
    """Run on Luna plugin startup; never leave a legacy plaintext URI behind."""
    try:
        path = _state_path()
        if not path.exists() and not path.is_symlink():
            return False
        with _locked_state() as locked:
            record = _read(locked)
            if record is None:
                return _retire_invalid(locked)
            if time.time() >= record['expires']:
                return _retire(locked, record['token'])
    except (OSError, ValueError, TypeError):
        pass
    return False


def schedule_seek(uri, position):
    """Schedule one-second callbacks without blocking Kodi's error dialog."""
    if (not isinstance(uri, str) or not 0 < len(uri) <= 16384 or
            any(ord(ch) < 32 for ch in uri)):
        raise ValueError('Invalid restored playback URI')
    try:
        position = float(position)
    except (TypeError, ValueError) as error:
        raise ValueError('Invalid restored position') from error
    if not math.isfinite(position) or not 0 < position <= 864000:
        raise ValueError('Invalid restored position')
    token = secrets.token_hex(16)
    salt = secrets.token_hex(16)
    payload = {
        'schema': STATE_SCHEMA,
        'token': token,
        'salt': salt,
        'digest': _fingerprint(uri, salt),
        'position': position,
        'expires': time.time() + SEEK_TIMEOUT_SECONDS,
    }
    with _locked_state() as path:
        if path.is_symlink():
            raise OSError('Unsafe pending-seek state path')
        temporary = None
        try:
            fd, temporary = tempfile.mkstemp(
                dir=path.parent, prefix='.luna-pending-seek-', suffix='.tmp')
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                os.fchmod(stream.fileno(), 0o600)
                json.dump(payload, stream, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            temporary = None
            _schedule(token)
        except BaseException:
            _retire(path, token)
            raise
        finally:
            if temporary is not None:
                Path(temporary).unlink(missing_ok=True)
    return token


def retry_pending_seek(token):
    """Seek only when the current item matches; don't race another launch."""
    if not isinstance(token, str) or not TOKEN.fullmatch(token):
        return False
    try:
        with _locked_state() as path:
            record = _read(path)
            if record is None or record['token'] != token:
                return False
            if time.time() >= record['expires']:
                _retire(path, token)
                return False

            import xbmc
            try:
                player = xbmc.Player()
                if player.isPlaying():
                    opened = player.getPlayingFile()
                    if (isinstance(opened, str) and
                            hmac.compare_digest(
                                _fingerprint(opened, record['salt']),
                                record['digest'])):
                        player.seekTime(record['position'])
                        _retire(path, token)
                        return True
                    if opened:
                        # The user started something else. Do not seek it.
                        _retire(path, token)
                        return False
            except (OSError, RuntimeError, AttributeError, TypeError, ValueError):
                pass
            if time.time() < record['expires']:
                try:
                    _schedule(token)
                except (OSError, RuntimeError, ValueError):
                    _retire(path, token)
            else:
                _retire(path, token)
    except (OSError, ValueError, TypeError):
        return False
    return False
