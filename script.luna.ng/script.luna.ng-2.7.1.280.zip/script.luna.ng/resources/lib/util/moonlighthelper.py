import os
import signal
import subprocess
import threading
import time
import re

import xbmc
import xbmcgui

def env_with_libs(binary_path, addon_path=None):
    env = dict(os.environ)
    root = os.path.abspath(addon_path or '')
    selected = os.path.abspath(binary_path or '')
    bin_root = os.path.join(root, 'bin')
    # System-installed Moonlight must not inherit the add-on's shared libraries.
    if not root or not (selected == bin_root or selected.startswith(bin_root + os.sep)):
        return env
    arch = 'coreelec-ng' if __import__('struct').calcsize('P') == 4 else 'coreelec-no'
    private = os.path.join(root, 'lib', arch)
    legacy = os.path.join(root, 'lib')
    if os.path.isdir(private):
        lib = private
    elif selected == bin_root and os.path.isdir(legacy):
        lib = legacy
    else:
        return env
    previous = env.get('LD_LIBRARY_PATH', '')
    env['LD_LIBRARY_PATH'] = lib + (':' + previous if previous else '')
    return env


def moonlight_environment(config_helper):
    return env_with_libs(config_helper.binary_path, config_helper.addon_path)


class MoonlightHelper:

    config_helper = None
    pin_received = False
    paired_address = None
    pairing_messages = ""

    def __init__(self, plugin, config_helper, logger):
        self.plugin = plugin
        self.config_helper = config_helper
        self.logger = logger

    def loop_lines(self, logger, iterator, dialog):
        for line in iterator:
            xbmc.log(line.strip(), xbmc.LOGERROR)

            found = re.search(r'Connecting to (\S+?)\.\.\.', line)
            if found:
                self.paired_address = found.group(1)
            if line.strip() == "":
                continue
            if 'enter the following PIN' in line:
                dialog.update(50, line)
                self.pin_received = True
                continue
            if not self.pin_received:
                continue
            if line.lstrip().startswith(('Request ', 'Response:', '<?xml', '<root')):
                continue
            self.pairing_messages += line.strip() + '\n'

    def pair(self):
        # Pairing must use the configured host, even before the first stream.
        self.config_helper.configure()
        binary_path = self.config_helper.binary_path
        self.pair_success = False
        self.paired_address = None

        address = self.config_helper.config.get('host_addr')
        if address:
            try:
                from resources.lib.util.hostapi import Host
                if Host(address).paired():
                    xbmcgui.Dialog().ok(
                        self.plugin.getLocalizedString(30000),
                        self.plugin.getLocalizedString(30265) or 'Already paired with this host')
                    return
            except Exception:
                pass
        try:
            pairing_proc = subprocess.Popen([binary_path + "moonlight", "pair"], cwd=binary_path, env=env_with_libs(binary_path, self.config_helper.addon_path), encoding='utf-8', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            lines_iterator = iter(pairing_proc.stdout.readline, "")
            dialog = xbmcgui.DialogProgress()
            dialog.create(
                self.plugin.getLocalizedString(30000),
                self.plugin.getLocalizedString(30285)
            )

            pairing_thread = threading.Thread(target=self.loop_lines, args=(self.logger, lines_iterator, dialog))
            pairing_thread.start()

            pairing_proc.wait(timeout=120)
            dialog.close()
            if 'Succesfully paired' in self.pairing_messages:
                self.pair_success = True

                xbmcgui.Dialog().ok(self.plugin.getLocalizedString(30000),
                                    self.plugin.getLocalizedString(30286))
            else:
                raise Exception(self.plugin.getLocalizedString(30287))
        except Exception as e:
            if len(self.pairing_messages) < 5:
                self.pairing_messages = (xbmc.getLocalizedString(257) + ':\n'
                                         + str(e))
            xbmcgui.Dialog().ok(self.plugin.getLocalizedString(30000), self.pairing_messages)

    def list_games(self):
        self.config_helper.configure()
        binary_path = self.config_helper.binary_path
        list_regex = r'\d+\.\s+([^\n]*)'

        try:
            moonlightOut = subprocess.check_output([binary_path + 'moonlight', 'list'], cwd=binary_path, env=env_with_libs(binary_path, self.config_helper.addon_path), timeout=5, encoding='utf-8', start_new_session=True)

            if 'must pair' in moonlightOut:
                return True

            return re.findall(list_regex, moonlightOut)
        except:
            return False

    KEEPALIVE = 'audiooutput.streamsilence'

    def _kodi_setting(self, name, value=None):
        import json
        try:
            if value is None:
                request = {'jsonrpc': '2.0', 'id': 1,
                           'method': 'Settings.GetSettingValue',
                           'params': {'setting': name}}
                answer = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                return answer.get('result', {}).get('value')

            request = {'jsonrpc': '2.0', 'id': 1,
                       'method': 'Settings.SetSettingValue',
                       'params': {'setting': name, 'value': value}}
            json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            return True
        except Exception:
            return None

    def _held_nodes(self):
        import glob
        import subprocess
        held = []
        for node in sorted(glob.glob('/dev/snd/pcmC0D*p')):
            try:
                out = subprocess.check_output(['fuser', node],
                                              stderr=subprocess.DEVNULL,
                                              encoding='utf-8')
                if out.strip():
                    held.append(node.rsplit('/', 1)[-1])
            except Exception:
                pass
        return held

    def release_audio(self):
        current = self._kodi_setting(self.KEEPALIVE)
        xbmc.log('LUNA audio: keepalive was %r, nodes held by %s'
                 % (current, self._held_nodes()), xbmc.LOGINFO)
        if current in (None, 0):
            return None

        self.plugin.setSettingString('saved_streamsilence', str(current))
        written = self._kodi_setting(self.KEEPALIVE, 0)
        after = self._kodi_setting(self.KEEPALIVE)
        xbmc.log('LUNA audio: wrote %r, now %r' % (written, after),
                 xbmc.LOGINFO)
        return current

    def wait_audio_free(self, seconds=6):
        import time
        deadline = time.time() + seconds
        while True:
            held = self._held_nodes()
            if not held:
                xbmc.log('LUNA audio: nodes are free', xbmc.LOGINFO)
                return True
            if time.time() >= deadline:
                xbmc.log('LUNA audio: still held: %s' % held, xbmc.LOGERROR)
                return False
            time.sleep(0.3)

    def restore_audio(self, previous):
        if previous is None:
            return
        self._kodi_setting(self.KEEPALIVE, previous)
        self.plugin.setSettingString('saved_streamsilence', '')

    def list_games_detailed(self):
        from resources.lib.util.hostapi import Host, HostError

        address = self.config_helper.config.get('host_addr')
        if not address:
            return None

        try:
            apps = Host(address).applist()
        except Exception:
            return None

        result = []
        for app_id, name in apps:
            try:
                art = self.boxart_path(address, app_id)
            except Exception:
                art = None
            result.append((app_id, name, art))
        return result

    def cached_games(self, max_age=300):
        import json
        import time
        import xbmcvfs

        folder = xbmcvfs.translatePath(
            'special://profile/addon_data/script.luna.ng/')
        path = os.path.join(folder, 'applist.json')

        fresh = False
        cached = None
        try:
            age = time.time() - os.path.getmtime(path)
            with open(path, encoding='utf-8') as f:
                cached = json.load(f)
            fresh = age < max_age
        except (OSError, ValueError):
            pass

        if fresh and cached:
            return [(app_id, name, self._art_if_present(app_id))
                    for app_id, name in cached]

        detailed = self.list_games_detailed()
        if detailed is None:
            if cached:
                return [(app_id, name, self._art_if_present(app_id))
                        for app_id, name in cached]
            return None

        try:
            os.makedirs(folder, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump([[a, n] for a, n, _ in detailed], f)
        except OSError:
            pass
        return detailed

    def _art_if_present(self, app_id):
        import xbmcvfs
        path = xbmcvfs.translatePath(
            'special://profile/addon_data/script.luna.ng/boxart/%s.png' % app_id)
        return path if os.path.exists(path) else None

    def boxart_path(self, address, app_id):
        import xbmcvfs
        from resources.lib.util.hostapi import Host

        folder = xbmcvfs.translatePath(
            'special://profile/addon_data/script.luna.ng/boxart/')
        path = os.path.join(folder, '%s.png' % app_id)
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return path

        data = Host(address).boxart(app_id)
        if not data:
            return None

        try:
            os.makedirs(folder, exist_ok=True)
            with open(path, 'wb') as f:
                f.write(data)
        except OSError:
            return None
        return path

    def quit_game(self):
        binary_path = self.config_helper.binary_path
        try:
            subprocess.run([binary_path + 'moonlight', 'quit'], cwd=binary_path, env=env_with_libs(binary_path, self.config_helper.addon_path), timeout=5, start_new_session=True)
        except:
            return False

        return True

    def _create_bug_report(self, scripts_path):
        command = [scripts_path + '../../create_bug_report.sh']
        try:
            process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                encoding='utf-8', cwd=scripts_path + '../../',
                start_new_session=True)
        except OSError as error:
            self.logger.info('[MoonlightHelper] - bug report did not start: %s' % error)
            return None

        try:
            output, _ = process.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            self.logger.info('[MoonlightHelper] - bug report timed out')
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            except OSError:
                pass
            process.communicate()
            return None

        if process.returncode != 0:
            self.logger.info('[MoonlightHelper] - bug report exited with %s'
                             % process.returncode)
            return None

        return output.strip() or None

    def launch_game(self, game_id):
        self.config_helper.configure()

        binary_path = self.config_helper.binary_path
        scripts_path = self.config_helper.launchscripts_path

        # Check installed ELF hashes and run Moonlight's help action while
        # Kodi is still responsive. A missing library must not freeze the TV.
        try:
            from resources.lib.util.runtimecheck import (
                check_ng_runtime, NativeRuntimeError)
            check_ng_runtime(self.config_helper.addon_path,
                             binary_path + 'moonlight',
                             moonlight_environment(self.config_helper))
        except NativeRuntimeError as error:
            xbmc.log('LUNA NG runtime preflight: %s' % error, xbmc.LOGERROR)
            xbmcgui.Dialog().ok(
                'Luna NG runtime check failed',
                str(error))
            return

        player = xbmc.Player()
        if player.isPlaying():
            player.stop()
            deadline = time.time() + 5
            while player.isPlaying() and time.time() < deadline:
                time.sleep(0.1)

        isResumeMode = bool(self.plugin.getSetting('last_run'))
        showIntro = self.plugin.getSettingBool('show_intro')
        codec = self.config_helper.config['codec']

        if not isResumeMode:
            self.plugin.setSettingString('last_run', game_id)

        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.executebuiltin("Dialog.Close(notification)")
        xbmc.executebuiltin("InhibitScreensaver(true)")

        keepalive = None
        t0 = None
        try:
            if showIntro and not isResumeMode:
                player.play(self.config_helper.addon_path + 'resources/statics/loading.mp4')
                time.sleep(10)
                player.stop()
            
            keepalive = self.release_audio()
            xbmc.audioSuspend()

            free = self.wait_audio_free(2)
            if not free:
                xbmc.log('LUNA audio: node taken again, retrying',
                         xbmc.LOGINFO)
                xbmc.audioSuspend()
                free = self.wait_audio_free()

            if not free:
                held = ', '.join(self._held_nodes())
                xbmc.log('LUNA audio: launch cancelled, held by %s' % held,
                         xbmc.LOGERROR)
                xbmcgui.Dialog().ok(self.plugin.getLocalizedString(30037),
                                    self.plugin.getLocalizedString(30268))
                return

            t0 = time.monotonic()
            subprocess.run([scripts_path + 'prescript.sh', binary_path, codec], cwd=scripts_path, start_new_session=True)
            env = moonlight_environment(self.config_helper)
            # Off unless enabled for a single diagnostic session in Advanced.
            # The native library reports once when the session shuts down.
            if self.plugin.getSettingBool('aml_profile'):
                env['MOONLIGHT_AML_PROFILE'] = '1'
            else:
                env.pop('MOONLIGHT_AML_PROFILE', None)

            # The experimental audio recovery applies only to direct ALSA.
            # PulseAudio and host-audio configurations are unaffected.
            if self.plugin.getSettingBool('alsa_resync'):
                env['MOONLIGHT_ALSA_RESYNC'] = '1'
            else:
                env.pop('MOONLIGHT_ALSA_RESYNC', None)

            # Read-only inspection and short retry on temporary event-device
            # open failures. Neither toggle writes to sysfs or rebinds drivers.
            for setting, variable in (
                    ('input_handoff_probe', 'MOONLIGHT_INPUT_HANDOFF_PROBE'),
                    ('input_recovery', 'MOONLIGHT_INPUT_RECOVERY')):
                if self.plugin.getSettingBool(setting):
                    env[variable] = '1'
                else:
                    env.pop(variable, None)

            # Kernel-level decoder experiments: independently opt-in, off by
            # default. Explicitly clear inherited values when disabled.
            for setting, variable in (
                    ('aml_tuning_probe', 'MOONLIGHT_AML_TUNING_PROBE'),
                    ('aml_hevc_tuning', 'MOONLIGHT_AML_HEVC_TUNING'),
                    ('aml_vfm', 'MOONLIGHT_AML_VFM')):
                if self.plugin.getSettingBool(setting):
                    env[variable] = '1'
                else:
                    env.pop(variable, None)

            env['MOONLIGHT_BINARY'] = binary_path + 'moonlight'
            launch_cmd = subprocess.Popen([scripts_path + 'launch.sh', game_id], cwd=binary_path, env=env, start_new_session=True)
            launch_cmd.wait()
            subprocess.run([scripts_path + 'postscript.sh', binary_path], cwd=scripts_path, start_new_session=True)

        except Exception as e:
            print("Failed to execute moonlight process.")
            print(e)
        finally:
            xbmc.audioResume()
            self.restore_audio(keepalive)
            xbmc.executebuiltin("InhibitScreensaver(false)")

            if t0 is None:
                pass
            elif time.monotonic() - t0 < 10:
                result = xbmcgui.Dialog().yesno(
                    "", self.plugin.getLocalizedString(30288))
                if result:
                    url = self._create_bug_report(scripts_path)
                    if url:
                        xbmcgui.Dialog().ok(
                            "", self.plugin.getLocalizedString(30289) + ' ' + url)
                    else:
                        xbmcgui.Dialog().ok(xbmc.getLocalizedString(257),
                                            self.plugin.getLocalizedString(30221))
            else:
                xbmcgui.Dialog().notification(
                    self.plugin.getLocalizedString(30290),
                    self.plugin.getLocalizedString(30291) % game_id,
                    xbmcgui.NOTIFICATION_INFO, False)
