#!/bin/sh
# Rescue Kodi if a Moonlight launcher disappears while kodi.bin is SIGSTOP'ed.
# A separate process is required because the launcher EXIT trap cannot handle
# SIGKILL, and Kodi's Python code is suspended until we send SIGCONT.
set -u
[ "$#" -eq 3 ] || exit 2
parent="$1"; parent_start="$2"; session="$3"
case "$parent:$parent_start" in *[!0-9:]*|:*|*:) exit 2;; esac
proc=/proc
if [ "${LUNA_WATCHDOG_TEST_ONLY:-}" = 1 ]; then
  proc="${LUNA_WATCHDOG_TEST_PROC:-/proc}"
fi
set -f

identity() {
  [ -r "$proc/$1/stat" ] || return 1
  line="$(cat "$proc/$1/stat" 2>/dev/null)" || return 1
  fields="${line##*) }"
  set -- $fields
  [ "$#" -ge 20 ] || return 1
  printf '%s %s\n' "$1" "${20}"
}

# Prove the rescue worker is alive and supervising exactly this launcher
# before the launcher is permitted to suspend Kodi.
initial="$(identity "$parent")" || exit 1
[ "${initial#* }" = "$parent_start" ] || exit 1
printf '%s\n' ready > "$session.ready" || exit 1

# Include zombie detection: if the parent is SIGSTOP'ed Kodi, SIGKILL'ed
# launchers stay as zombies until Kodi resumes and can reap them.
while :; do
  state="$(identity "$parent")" || break
  [ "${state#* }" = "$parent_start" ] || break
  case "${state%% *}" in Z|X|x) break;; esac
  sleep 1
done

# A verified, still-running Moonlight child receives a graceful TERM before
# Kodi resumes. Never target a PID that has been recycled.
if [ -r "$session" ]; then
  child=''; token=''
  read -r child token < "$session" || true
  case "$child:$token" in *[!0-9:]*|:*|*:) ;; *)
    state="$(identity "$child")" || state=''
    if [ -n "$state" ] && [ "${state#* }" = "$token" ]; then
      case "${state%% *}" in Z|X|x) ;; *)
        kill -TERM "$child" 2>/dev/null || true
        n=0
        while [ "$n" -lt 3 ]; do
          state="$(identity "$child")" || break
          [ "${state#* }" = "$token" ] || break
          case "${state%% *}" in Z|X|x) break;; esac
          n=$((n + 1))
          sleep 1
        done
      esac
    fi
  ;; esac
fi
killall -CONT kodi.bin 2>/dev/null || true
rm -f "$session" "$session.ready"
