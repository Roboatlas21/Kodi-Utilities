"""Bound DNS resolution outside Kodi's interpreter, retaining TLS host identity."""
import json
import socket
import subprocess
import time

_cache = {}
_RESOLVE = ('import socket,json,sys; '
            'print(json.dumps(socket.getaddrinfo(sys.argv[1],int(sys.argv[2]),'
            'type=socket.SOCK_STREAM)))')


def connect(address, timeout=4, source_address=None):
    host, port = address
    deadline = time.monotonic() + timeout
    key = (host, port)
    cached = _cache.get(key)
    if cached and time.monotonic() < cached[0]:
        results = cached[1]
    else:
        try:
            result = subprocess.run(['python3', '-c', _RESOLVE, host, str(port)],
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    text=True, timeout=timeout, check=True)
            results = json.loads(result.stdout)
        except (subprocess.SubprocessError, ValueError) as error:
            raise socket.timeout('Sunshine address resolution failed or timed out') from error
        if len(_cache) >= 128:
            _cache.clear()
        _cache[key] = (time.monotonic() + 60, results)
    last_error = socket.timeout('Sunshine connection deadline expired')
    for index, (family, kind, protocol, _, target) in enumerate(results):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        sock = None
        try:
            sock = socket.socket(family, kind, protocol)
            # Reserve a share of the total budget for every remaining address.
            sock.settimeout(remaining / (len(results) - index))
            if source_address:
                sock.bind(source_address)
            sock.connect(tuple(target))
            sock.settimeout(timeout)  # TLS and response reads get the request budget.
            return sock
        except OSError as error:
            last_error = error
            if sock is not None:
                sock.close()
    _cache.pop(key, None)  # A changed address must be retried on the next request.
    raise last_error
