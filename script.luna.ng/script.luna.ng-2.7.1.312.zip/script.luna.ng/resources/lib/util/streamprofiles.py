"""Per-host, per-Sunshine-app streaming presets for Luna NG.

Only the per-launch Moonlight config is overridden; Kodi's global settings,
shared moonlight.conf and other hosts' profiles are never modified.
"""
import fcntl
import json
import os
from pathlib import Path
import re
import stat
import tempfile

from resources.lib.util.appidentity import canonical_app_id
from resources.lib.util.resumestate import host_identity
from resources.lib.util.safejson import read_bounded_json
from resources.lib.util.safelock import locked_regular_file

FILE_NAME = 'stream-profiles.json'
PROFILE_MODES = {
    'desktop_4k60': (3840, 2160, 60),
    'gaming_1080p120': (1920, 1080, 120),
}
HOST_KEY_RE = re.compile(r'^[0-9a-f]{20}$')
MAX_FILE_SIZE = 1024 * 1024


class ProfileDataError(ValueError):
    """Existing profile data is damaged; never overwrite it with defaults."""


class StreamProfiles:
    def __init__(self, folder, host, host_options=None):
        self.folder = Path(folder)
        self.path = self.folder / FILE_NAME
        self.key = host_identity(host, host_options)
        if not self.key:
            raise ProfileDataError('Select a Sunshine host before editing profiles')

    def _load(self):
        data = {'schema': 1, 'by_host': {}}
        try:
            loaded = read_bounded_json(self.path, MAX_FILE_SIZE)
        except FileNotFoundError as error:
            if os.path.lexists(self.path):
                raise ProfileDataError('Existing application profiles cannot be read') from error
            return data
        except (OSError, ValueError) as error:
            raise ProfileDataError(
                'Saved application profiles are unsafe, oversized or invalid') from error
        if (not isinstance(loaded, dict) or set(loaded) != {'schema', 'by_host'} or
                type(loaded['schema']) is not int or loaded['schema'] != 1 or
                not isinstance(loaded['by_host'], dict)):
            raise ProfileDataError('Unexpected application profiles format')
        for host_key, apps in loaded['by_host'].items():
            if (not isinstance(host_key, str) or not HOST_KEY_RE.fullmatch(host_key) or
                    not isinstance(apps, dict)):
                raise ProfileDataError('Invalid application profiles host mapping')
            for app_id, profile in apps.items():
                try:
                    if (not isinstance(app_id, str) or
                            canonical_app_id(app_id) != app_id or
                            not isinstance(profile, str) or
                            profile not in PROFILE_MODES):
                        raise ProfileDataError('Invalid saved application profile')
                except ValueError as error:
                    raise ProfileDataError('Invalid saved application profile') from error
        return loaded

    def get(self, app_id):
        app_id = canonical_app_id(app_id)
        return self._load()['by_host'].get(self.key, {}).get(app_id)

    def set(self, app_id, profile):
        app_id = canonical_app_id(app_id)
        if profile is not None and (not isinstance(profile, str) or
                                    profile not in PROFILE_MODES):
            raise ValueError('Unknown streaming profile')
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            lock_path = self.folder / (FILE_NAME + '.lock')
            with locked_regular_file(lock_path):
                data = self._load()  # Refresh under lock, never trust stale cache.
                assignments = data['by_host'].get(self.key, {})
                previous = assignments.get(app_id)
                if previous == profile:
                    return False
                if profile is None:
                    assignments.pop(app_id, None)
                    if not assignments:
                        data['by_host'].pop(self.key, None)
                else:
                    data['by_host'].setdefault(self.key, {})[app_id] = profile
                # Match _load's byte limit before publishing. Never
                # persist a successful edit that the next launch cannot read.
                encoded = (json.dumps(
                    data, ensure_ascii=False, separators=(',', ':')) + '\n'
                    ).encode('utf-8')
                if len(encoded) > MAX_FILE_SIZE:
                    raise ProfileDataError(
                        'Application profiles would exceed the storage limit')
                temporary = None
                try:
                    fd, temporary = tempfile.mkstemp(
                        dir=str(self.folder), prefix='.stream-profiles-', suffix='.tmp')
                    with os.fdopen(fd, 'wb') as out:
                        os.fchmod(out.fileno(), 0o600)
                        out.write(encoded)
                        out.flush()
                        os.fsync(out.fileno())
                    os.replace(temporary, self.path)
                    directory = os.open(str(self.folder), os.O_RDONLY |
                                        getattr(os, 'O_DIRECTORY', 0))
                    try:
                        os.fsync(directory)
                    finally:
                        os.close(directory)
                finally:
                    if temporary is not None and os.path.exists(temporary):
                        os.unlink(temporary)
                return True
        except (OSError, UnicodeError) as error:
            raise ProfileDataError('Could not save application profile: %s' % error) from error


def apply_to_config(source, profile):
    """Replace only Moonlight width/height/FPS in an immutable launch copy.

    Keep repeated input= entries and every unrelated stream option verbatim.
    Fail closed if the source no longer contains exactly one of each key.
    """
    if profile not in PROFILE_MODES:
        raise ValueError('Invalid streaming profile for launch')
    width, height, fps = PROFILE_MODES[profile]
    replacement = {'width': width, 'height': height, 'fps': fps}
    found = {key: 0 for key in replacement}
    in_moonlight = False
    section_count = 0
    lines = []
    if not isinstance(source, str) or '\x00' in source:
        raise ValueError('Invalid immutable Moonlight configuration')
    for line in source.splitlines(keepends=True):
        stripped = line.strip()
        if stripped.startswith('[') and stripped.endswith(']'):
            in_moonlight = stripped.lower() == '[moonlight]'
            if in_moonlight:
                section_count += 1
        if in_moonlight and not stripped.startswith(('#', ';')) and '=' in line:
            key = line.split('=', 1)[0].strip().lower()
            if key in replacement:
                found[key] += 1
                ending = '\r\n' if line.endswith('\r\n') else '\n'
                lines.append('%s = %d%s' % (key, replacement[key], ending))
                continue
        lines.append(line)
    if section_count != 1 or any(count != 1 for count in found.values()):
        raise ValueError('Incomplete or duplicate Moonlight stream dimensions')
    return ''.join(lines)
