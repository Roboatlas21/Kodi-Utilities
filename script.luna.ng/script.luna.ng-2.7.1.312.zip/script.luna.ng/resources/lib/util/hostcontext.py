"""Canonical endpoint and credential context shared by UI, caches and launch."""
import hashlib
import json
import os
import re

HTTP_PORT = 47989


def default_key_dir():
    cache = os.environ.get('XDG_CACHE_DIR')
    if cache is None:
        cache = os.path.join(os.path.expanduser('~'), '.cache')
    return os.path.abspath(os.path.join(cache, 'moonlight'))


def normalize_options(options=None, native_cwd=None):
    options = dict(options or {})
    if set(options) - {'port', 'keydir'}:
        raise ValueError('Unknown host connection option')
    port = int(options.get('port', HTTP_PORT))
    if not 1 <= port <= 65535:
        raise ValueError('Invalid host port')
    directory = options.get('keydir', default_key_dir())
    if not isinstance(directory, str) or not directory or any(c in directory for c in '\r\n\x00'):
        raise ValueError('Invalid pairing key directory')
    directory = os.path.abspath(os.path.join(native_cwd or os.getcwd(), directory))
    result = {}
    if port != HTTP_PORT:
        result['port'] = str(port)
    if directory != default_key_dir():
        result['keydir'] = directory
    return result


def host_identity(host, options=None, native_cwd=None):
    normalized = (host or '').strip().lower()
    if not normalized:
        return ''
    context = normalize_options(options, native_cwd)
    # Preserve historical default-connection IDs. Custom contexts never fall
    # back to an address-only record whose original port cannot be established.
    if context:
        normalized += '\n' + json.dumps(context, sort_keys=True)
    return hashlib.sha256(normalized.encode('utf-8')).hexdigest()[:20]


def remove_pairing_keys(directory):
    """Delete only native credential filenames, never a configured directory."""
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open(directory, flags)
    try:
        names = {'client.pem', 'key.pem', 'client.p12', 'uniqueid.dat'}
        removed = 0
        for name in os.listdir(fd):
            if name not in names and not re.fullmatch(r'server-[0-9a-f]{64}\.pem', name):
                continue
            # unlink removes the entry itself, never a symlink's destination.
            os.unlink(name, dir_fd=fd)
            removed += 1
        return removed
    finally:
        os.close(fd)
