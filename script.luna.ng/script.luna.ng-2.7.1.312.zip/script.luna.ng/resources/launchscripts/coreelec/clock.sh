#!/bin/sh
# Boot-relative elapsed time for detached Luna launch/recovery deadlines.
# NTP and manual changes to wall-clock time must not affect live timeouts.
luna_monotonic_seconds() {
  read -r lu_uptime lu_idle < /proc/uptime || return 1
  lu_seconds="${lu_uptime%%.*}"
  case "$lu_seconds" in ''|*[!0-9]*) return 1 ;; esac
  printf '%s\n' "$lu_seconds"
}

luna_duration_stamp() {
  lu_seconds="$(luna_monotonic_seconds)" || return 1
  printf 'mono:%s\n' "$lu_seconds"
}

luna_elapsed_since() {
  lu_stamp="$1"
  case "$lu_stamp" in
    mono:*)
      lu_started="${lu_stamp#mono:}"
      case "$lu_started" in ''|*[!0-9]*) return 1 ;; esac
      [ "${#lu_started}" -le 13 ] || return 1
      lu_now="$(luna_monotonic_seconds)" || return 1
      ;;
    *)
      # One-time compatibility for old on-disk epoch stamps. No new launch
      # creates these; after old sessions retire all active timing is monotonic.
      lu_started="$lu_stamp"
      case "$lu_started" in ''|*[!0-9]*) return 1 ;; esac
      [ "${#lu_started}" -le 13 ] || return 1
      lu_now="$(date +%s)" || return 1
      case "$lu_now" in ''|*[!0-9]*) return 1 ;; esac
      ;;
  esac
  [ "$lu_now" -ge "$lu_started" ] || return 1
  printf '%s\n' "$((lu_now - lu_started))"
}
