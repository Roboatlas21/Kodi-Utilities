"""Kodi-owned artwork worker: directory listing never waits for image requests."""
import concurrent.futures
import json
import os
import time
import tempfile
from contextlib import nullcontext
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.util.moonlighthelper import MoonlightHelper
from resources.lib.util.safejson import read_bounded_json
from resources.lib.util.safelock import locked_regular_file
from resources.lib.util.appidentity import canonical_app_id


def process_job(path, monitor):
    payload = read_bounded_json(path, 4 * 1024 * 1024)
    address = payload['host']
    ids = payload['ids']
    refresh = payload.get('refresh') is True
    if (not isinstance(address, str) or not address or len(address) > 1024 or
            not isinstance(ids, list) or len(ids) > 20000 or
            any(canonical_app_id(value) != value for value in ids)):
        raise ValueError('Invalid artwork request')
    options = payload.get('host_options', {})
    if (not isinstance(options, dict) or set(options) - {'port', 'keydir'} or
            any(not isinstance(v, str) for v in options.values())):
        raise ValueError('Invalid host context')
    from resources.lib.util.nativeini import validate_and_mask_inputs
    validate_and_mask_inputs('[Moonlight]\n' + ''.join('%s = %s\n' % kv for kv in options.items()))
    helper = MoonlightHelper.__new__(MoonlightHelper)
    from resources.lib.util.hostcontext import normalize_options
    helper._artwork_host_options = normalize_options(options)
    changed = False
    failed = []
    last_refresh = 0

    def publish(force=False):
        nonlocal changed, last_refresh
        now = time.monotonic()
        if not changed or monitor.abortRequested() or (not force and now - last_refresh < 2):
            return
        current = xbmcaddon.Addon('script.luna.ng').getSetting('host_addr')
        if (current == address and
                xbmc.getInfoLabel('Container.PluginName') == 'script.luna.ng'):
            xbmc.executebuiltin('Container.Refresh')
        changed = False
        last_refresh = now

    def fetch(app_id):
        if monitor.abortRequested():
            return None, False
        previous = helper._art_if_present(address, app_id)
        result = helper.boxart_path(address, app_id, refresh=refresh)
        return result, bool(result and (refresh or not previous))

    # A batch has at most three futures; failed IDs alone survive a retry.
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for offset in range(0, min(len(ids), 3), 3):
            if monitor.abortRequested():
                return False
            pending = [(value, pool.submit(fetch, value)) for value in ids[offset:offset + 3]]
            for app_id, future in pending:
                try:
                    result, updated = future.result()
                    changed = updated or changed
                    if not result:
                        failed.append(app_id)
                except Exception:
                    failed.append(app_id)
            publish()
    publish(force=True)
    remaining = ids[3:]
    if remaining or failed:
        payload['ids'] = list(dict.fromkeys(remaining + failed))
        if remaining:
            payload['retry_at'] = 0
            save_job(path, payload)
        else:
            defer_job(path, payload)
        return False
    return True


def defer_job(path, payload=None):
    if payload is None:
        payload = read_bounded_json(path, 4 * 1024 * 1024)
    attempts = min(int(payload.get('attempts', 0)) + 1, 8)
    payload['attempts'] = attempts
    payload['retry_at'] = time.time() + min(300, 2 ** attempts)
    # Keep one compact job after outages; capped delay avoids busy retrying.
    save_job(path, payload)


def save_job(path, payload):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', dir=path.parent,
                prefix='.retry-', delete=False) as stream:
            temporary = stream.name
            json.dump(payload, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def merge_jobs(old, new):
    """Union generations without letting duplicate retries erase backoff."""
    if old.get('host') != new.get('host') or old.get('host_options', {}) != new.get('host_options', {}):
        raise ValueError('Artwork context mismatch')
    old_ids, new_ids = old['ids'], new['ids']
    merged = dict(old)
    merged['ids'] = list(dict.fromkeys(old_ids + new_ids))
    # Old removed apps must not let an obsolete retry set grow without bound.
    # Retain the newest requested IDs if the host's historical union is larger.
    merged['ids'] = merged['ids'][-20000:]
    upgraded = new.get('refresh') is True and old.get('refresh') is not True
    merged['refresh'] = old.get('refresh') is True or new.get('refresh') is True
    if upgraded or set(new_ids) - set(old_ids):
        merged['retry_at'] = 0
    return merged


def compact_jobs(jobs):
    """One work file per canonical context, including old UUID generations.

    The worker owns .work files. The producer's stable .json lock serializes
    claims with producer merges; requests arriving during a fetch stay pending.
    """
    from resources.lib.util.hostcontext import host_identity, normalize_options
    for path in sorted(jobs.glob('*.work')) + sorted(jobs.glob('*.json')):
        try:
            with (locked_regular_file(str(path) + '.lock', timeout=0.1)
                  if path.suffix == '.json' else nullcontext()):
                payload = read_bounded_json(path, 4 * 1024 * 1024)
                if not isinstance(payload, dict):
                    raise ValueError('Artwork request must be an object')
                address, ids = payload['host'], payload['ids']
                if (not isinstance(address, str) or not address or len(address) > 1024 or
                        not isinstance(ids, list) or len(ids) > 20000 or
                        any(not isinstance(v, str) or canonical_app_id(v) != v for v in ids)):
                    raise ValueError('Invalid artwork request')
                payload['host_options'] = normalize_options(payload.get('host_options', {}))
                target = jobs / (host_identity(address, payload['host_options']) + '.work')
                if path == target:
                    continue
                try:
                    old = read_bounded_json(target, 4 * 1024 * 1024)
                except (FileNotFoundError, ValueError, TypeError):
                    old = None
                if old is not None:
                    try:
                        payload = merge_jobs(old, payload)
                    except (AttributeError, KeyError, TypeError, ValueError):
                        pass  # Replace damaged old state with the valid request.
                save_job(target, payload)  # Publish union BEFORE removing input.
                path.unlink()
        except (ValueError, TypeError, KeyError):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        except OSError:
            pass  # Retry transient storage failures without discarding work.


def run():
    monitor = xbmc.Monitor()
    root = Path(xbmcvfs.translatePath('special://profile/addon_data/script.luna.ng/'))
    jobs = root / 'artwork-jobs'
    jobs.mkdir(parents=True, exist_ok=True)
    try:
        with locked_regular_file(str(jobs / 'worker.lock'), timeout=0):
            while not monitor.abortRequested():
                compact_jobs(jobs)
                for work in sorted(jobs.glob('*.work')):
                    if monitor.abortRequested():
                        return
                    try:
                        payload = read_bounded_json(work, 4 * 1024 * 1024)
                        if not isinstance(payload, dict):
                            raise ValueError('Artwork job must be an object')
                        if float(payload.get('retry_at', 0)) > time.time():
                            continue
                        complete = process_job(work, monitor)
                    except (RuntimeError, OSError):
                        try:
                            defer_job(work)
                        except (OSError, ValueError, TypeError, KeyError):
                            pass
                        complete = False
                    except (ValueError, TypeError, KeyError):
                        complete = True
                    if complete:
                        try:
                            work.unlink(missing_ok=True)
                        except OSError:
                            pass
                if monitor.waitForAbort(1):
                    return
    except TimeoutError:
        pass


if __name__ == '__main__':
    run()
