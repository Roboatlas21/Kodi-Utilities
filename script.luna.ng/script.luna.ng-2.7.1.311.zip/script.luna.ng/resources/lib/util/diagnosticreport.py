"""Offline Luna diagnostic reports. Nothing in this module uploads logs."""
import datetime
import ipaddress
import os
from pathlib import Path
import secrets
import re
import stat
import subprocess
import tempfile

MAX_SOURCE_BYTES = 512 * 1024
MAX_SOURCE_LINES = 300
MAX_LINE_LENGTH = 4096
DEFAULT_LOGFILES_ROOT = '/storage/logfiles'

# All sources pass through this conservative scrubber before ANY network-share
# copy. Mask unknown secrets too where they resemble credentials or filenames.
# No arbitrary-log redactor can promise to recognize every sensitive value.
_PEM = re.compile(r'(?is)-----BEGIN [^\r\n-]*(?:PRIVATE KEY|CERTIFICATE)-----.*?(?:-----END [^\r\n]+-----|\Z)')
_URL = re.compile(r'(?i)\b(?:https?|ftp|smb|nfs|rtsp|rtmp|plugin)://[^\s<>"\']+')
# Credential fields may have arbitrary prefixes or namespaces:
# session_token, api_token, my_password, service.auth_token, ns:api_key.
# Redact short values too; long-token heuristics cannot protect them.
_CREDENTIAL_SUFFIX = (
    r'(?:password|passwd|passphrase|access[_-]?token|refresh[_-]?token|'
    r'api[_-]?key|private[_-]?key|client[_-]?(?:key|cert)|'
    r'authorization|credentials?|uniqueid|secret|token|pin|'
    r'cookie|oauth|jwt|signature)')
_CREDENTIAL_FIELD = r'(?:[a-z0-9]+[_:.-])*' + _CREDENTIAL_SUFFIX
_XML_SECRET = re.compile(
    r'<(' + _CREDENTIAL_FIELD + r')(?:\s[^<>]*?)?>.*?</\1\s*>',
    re.IGNORECASE | re.DOTALL)
_SECRET = re.compile(
    r'(?<![a-z0-9])["\']?(' + _CREDENTIAL_FIELD + r')["\']?\s*[:=]\s*'
    r'("[^"\r\n]*"|\'[^\'\r\n]*\'|[^\s&;,<>{}]+)',
    re.IGNORECASE)
_BEARER = re.compile(r'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+')
_EMAIL = re.compile(r'(?i)\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')
_MAC = re.compile(r'(?i)\b(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b')
_IPV4 = re.compile(r'(?<![\w.])(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)'
                   r'(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}(?![\w.])')
_IPV6 = re.compile(r'(?i)(?<![\w])(?:[0-9a-f]{0,4}:){2,}[0-9a-f]{0,4}(?:%[\w.-]+)?(?![\w])')
_LOCAL_PATH = re.compile(
    r"(?i)(?<![\w])(?:/(?:storage|home|root|mnt|media|tmp|etc|var/media)/"
    r"[^\s\"'<>()\[\],;]+|[a-z]:\\[^\s\"'<>()\[\],;]+|"
    r"\\\\[a-z0-9_.-]+\\[^\s\"'<>()\[\],;]+)")
_ENDPOINT = re.compile(
    r'(?i)\b(?:host(?:name|_addr)?|server(?:_name|_addr)?|'
    r'address|ssid|serial(?:number)?|device_id|client_id)\s*[:=]\s*'
    r'(?:"[^"\r\n]*"|[^\s&;,<>{}]+)')
_LONG_TOKEN = re.compile(r'(?i)\b(?:[a-f0-9]{32,}|[a-z0-9_-]{48,}={0,2})\b')
# Native Moonlight logs use human phrases instead of key=value syntax.
# Preserve the failure context while hiding the endpoint. A bare local
# hostname need not contain a dot or an IP address.
_HOST_PROSE = re.compile(
    r'(?i)\b((?:(?:re)?connecting|connected|paired|pairing)\s+'
    r'(?:to|with|at)\s+)([^\s,;()<>\[\]]+)')
_HOST_DESCRIPTION = re.compile(
    r'(?i)\b((?:sunshine\s+)?(?:host|server)\s+'
    r'(?:is|at|named|name\s+is|address\s+is)\s+)([^\s,;()<>\[\]]+)')
_LOGIN_HOST = re.compile(
    r'(?i)(?<![\w])(?:[a-z0-9._~-]+)@(?:[a-z0-9._-]+)(?![\w])')
# Whole lines are withheld when they mention authentication material. This is
# safer than trying to understand every possible server-specific log format.
_SENSITIVE_LINE = re.compile(
    r'\b(?:authorization|proxy.authorization|bearer|cookie|set.cookie|'
    r'password|passwd|passphrase|private.?key|certificate|'
    r'access.?token|refresh.?token|api.?key|apikey|auth.?token|'
    r'pairing.?pin|credentials?|session.?secret|secret.?key|'
    r'uniqueid|oauth|jwt|signature|signed.?request|pin|pairing.?code)\b'
    r'|(?<![a-z0-9])' + _CREDENTIAL_FIELD + r'(?![a-z0-9])',
    re.IGNORECASE)


def redact(text):
    """Mask common secrets and network identities; a human must still review."""
    text = _PEM.sub('[PEM DATA REDACTED]', text)
    text = _URL.sub('[URL REDACTED]', text)
    text = _LOCAL_PATH.sub('[LOCAL PATH REDACTED]', text)
    text = _ENDPOINT.sub('[HOST IDENTIFIER REDACTED]', text)
    text = _HOST_PROSE.sub(lambda m: m[1] + '[HOST REDACTED]', text)
    text = _HOST_DESCRIPTION.sub(lambda m: m[1] + '[HOST REDACTED]', text)
    text = _LOGIN_HOST.sub('[ACCOUNT AND HOST REDACTED]', text)
    text = _XML_SECRET.sub(lambda m: '<%s>[REDACTED]</%s>' % (m[1], m[1]), text)
    text = _BEARER.sub('Bearer [REDACTED]', text)
    text = _SECRET.sub(lambda m: '%s=[REDACTED]' % m[1], text)
    text = _EMAIL.sub('[EMAIL REDACTED]', text)
    text = _MAC.sub('[MAC REDACTED]', text)
    text = _IPV4.sub('[IPv4 REDACTED]', text)

    def hide_ipv6(match):
        try:
            return '[IPv6 REDACTED]' if isinstance(
                ipaddress.ip_address(match.group(0).split('%', 1)[0]),
                ipaddress.IPv6Address) else match.group(0)
        except ValueError:
            return match.group(0)

    text = _IPV6.sub(hide_ipv6, text)
    text = _LONG_TOKEN.sub('[TOKEN REDACTED]', text)
    return '\n'.join(
        '[SENSITIVE LOG LINE REDACTED]' if _SENSITIVE_LINE.search(line) else line
        for line in text.split('\n'))


def _bounded_tail(raw):
    """Limit log size, lines, and line length without loading complete files."""
    if isinstance(raw, bytes):
        raw = raw[-MAX_SOURCE_BYTES:].decode('utf-8', 'replace')
    else:
        raw = raw[-MAX_SOURCE_BYTES:]
    lines = raw.splitlines()[-MAX_SOURCE_LINES:]
    return '\n'.join(line[:MAX_LINE_LENGTH] for line in lines) + '\n' if lines else '(empty)\n'


def _read_log(path):
    if path is None:
        return '(not configured)\n'
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0)
    flags |= getattr(os, 'O_NONBLOCK', 0)
    try:
        fd = os.open(os.fspath(path), flags)
        with os.fdopen(fd, 'rb') as stream:
            st = os.fstat(stream.fileno())
            if not stat.S_ISREG(st.st_mode):
                return '(not available: source is not a regular file)\n'
            if st.st_size > MAX_SOURCE_BYTES:
                stream.seek(st.st_size - MAX_SOURCE_BYTES)
                raw = stream.read(MAX_SOURCE_BYTES)
                raw = raw.split(b'\n', 1)[-1] if b'\n' in raw else raw
            else:
                raw = stream.read(MAX_SOURCE_BYTES)
        return _bounded_tail(raw)
    except OSError:
        return '(not available: log could not be read safely)\n'


def _kernel_log():
    try:
        result = subprocess.run(['dmesg'], stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, timeout=5,
                                check=False)
    except (OSError, subprocess.TimeoutExpired):
        return '(not available: kernel log collection failed)\n'
    if result.returncode:
        return '(not available: kernel log access denied)\n'
    return _bounded_tail(result.stdout)


def _prune_reports(directory_fd, keep_name, max_count=20, max_bytes=20 * 1024 * 1024):
    """Retain recent Luna reports; never follow or delete unrelated entries."""
    entries = []
    for name in os.listdir(directory_fd):
        if not re.fullmatch(r'luna-diagnostics-[0-9]{8}-[0-9]{6}-[a-z0-9_]+\.txt', name):
            continue
        try:
            info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1:
                continue
            entries.append((name, info))
        except OSError:
            continue
    entries.sort(key=lambda entry: entry[1].st_mtime_ns, reverse=True)
    size = count = 0
    for name, info in entries:
        count += 1
        size += info.st_size
        if name == keep_name or (count <= max_count and size <= max_bytes):
            continue
        try:
            current = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            if (current.st_dev, current.st_ino) == (info.st_dev, info.st_ino):
                os.unlink(name, dir_fd=directory_fd)
        except OSError:
            pass  # Retention must not discard the newly collected report.


def create_report(data_dir, kodi_log=None, legacy_log=None, kernel_output=None):
    """Create a private text file and return its path; no network or clipboard."""
    root = Path(data_dir)
    if not root.is_dir():
        root.mkdir(parents=True, mode=0o700, exist_ok=True)
    reports = root / 'diagnostics'
    reports.mkdir(mode=0o700, exist_ok=True)
    info = reports.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
        raise OSError('Unsafe diagnostics folder')
    reports.chmod(0o700)
    now = datetime.datetime.now(datetime.timezone.utc)
    sections = [
        ('Luna session log', _read_log(root / 'logfile')),
        ('Kodi log', _read_log(kodi_log)),
    ]
    if legacy_log is not None:
        sections.append(('Legacy native Moonlight log', _read_log(legacy_log)))
    kernel = _kernel_log() if kernel_output is None else _bounded_tail(kernel_output)
    sections.append(('Kernel log (last 300 lines)', kernel))
    header = ('Luna diagnostic report - LOCAL FILE ONLY\n'
              'Created (UTC): %s\n'
              'Nothing was uploaded or sent to an external service.\n'
              'Credentials, URLs, paths and network identifiers have been masked.\n'
              % now.isoformat(timespec='seconds'))
    report_text = header + ''.join('\n===== %s =====\n%s' % (name, redact(data))
                                   for name, data in sections)
    file_path = None
    try:
        fd, file_path = tempfile.mkstemp(
            prefix='luna-diagnostics-%s-' % now.strftime('%Y%m%d-%H%M%S'),
            suffix='.txt', dir=reports)
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            os.fchmod(out.fileno(), 0o600)
            out.write(report_text)
            out.flush()
            os.fsync(out.fileno())
        directory_fd = os.open(reports, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            _prune_reports(directory_fd, Path(file_path).name)
        finally:
            os.close(directory_fd)
        return Path(file_path)
    except BaseException:
        if file_path is not None:
            Path(file_path).unlink(missing_ok=True)
        raise


# Fail closed on Linux (CoreELEC) if directory-relative safety flags are
# unavailable. A verified fd survives pathname replacement by another process.
_EXPORT_DIR_FLAGS = (os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW |
                     getattr(os, 'O_CLOEXEC', 0))


def _open_or_create_directory_chain(path, create=True):
    """Walk the share path by fd, never following symlinks in any component."""
    folder = Path(path)
    current_fd = os.open('/' if folder.is_absolute() else '.', _EXPORT_DIR_FLAGS)
    try:
        for component in folder.parts:
            if component in ('/', '.', ''):
                continue
            if component == '..':
                raise OSError('Parent traversal is not allowed for Logfiles export')
            if create:
                try:
                    os.mkdir(component, mode=0o755, dir_fd=current_fd)
                except FileExistsError:
                    pass
            next_fd = os.open(component, _EXPORT_DIR_FLAGS, dir_fd=current_fd)
            os.close(current_fd)
            current_fd = next_fd
        return current_fd
    except BaseException:
        os.close(current_fd)
        raise


def _open_export_directory(share):
    """Return an owned Luna directory fd; do not reopen it by path."""
    share_fd = _open_or_create_directory_chain(share)
    try:
        root_info = os.fstat(share_fd)
        if (not stat.S_ISDIR(root_info.st_mode) or
                root_info.st_uid != os.geteuid()):
            raise OSError('Unsafe CoreELEC Logfiles root')
        try:
            os.mkdir('Luna', mode=0o755, dir_fd=share_fd)
        except FileExistsError:
            pass
        directory_fd = os.open('Luna', _EXPORT_DIR_FLAGS, dir_fd=share_fd)
        try:
            info = os.fstat(directory_fd)
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
                raise OSError('Unsafe CoreELEC Logfiles directory')
            os.fchmod(directory_fd, 0o755)  # Readable via CoreELEC's SMB share.
            return directory_fd
        except BaseException:
            os.close(directory_fd)
            raise
    finally:
        os.close(share_fd)


def _verify_export_destination(share, directory_fd, filename, expected_inode):
    """Check path still points at the pinned directory and published inode.

    A later rename is inherently possible when returning a pathname, but
    replacing it during export must not be silently reported as success.
    Read-only reopens never create or follow share-directory symlinks.
    """
    current_root = _open_or_create_directory_chain(share, create=False)
    try:
        try:
            current_luna = os.open('Luna', _EXPORT_DIR_FLAGS, dir_fd=current_root)
        except OSError as error:
            # A replaced directory may fail O_NOFOLLOW with ELOOP or ENOTDIR.
            # Both are the expected fail-closed directory-swap outcome.
            raise OSError('CoreELEC Logfiles/Luna directory changed during export') from error
        try:
            pinned = os.fstat(directory_fd)
            current = os.fstat(current_luna)
            if (pinned.st_dev != current.st_dev or
                    pinned.st_ino != current.st_ino):
                raise OSError('CoreELEC Logfiles/Luna directory changed during export')
            actual = os.stat(filename, dir_fd=current_luna,
                             follow_symlinks=False)
            if (not stat.S_ISREG(actual.st_mode) or
                    (actual.st_dev, actual.st_ino) != expected_inode):
                raise OSError('CoreELEC diagnostic destination changed during export')
        finally:
            os.close(current_luna)
    finally:
        os.close(current_root)


def export_report(report_path, logfiles_root=DEFAULT_LOGFILES_ROOT):
    """Publish only a re-sanitized report in CoreELEC's SMB Logfiles share.

    Keep the private original in addon_data. The public file appears in one
    atomic step after all content has been written and fsynced. Fail closed on
    symlinked share paths, existing target names or unexpected source files.
    """
    source = Path(report_path)
    fd = os.open(str(source), os.O_RDONLY | os.O_NONBLOCK |
                 getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0))
    with os.fdopen(fd, 'rb') as reader:
        metadata = os.fstat(reader.fileno())
        if (not stat.S_ISREG(metadata.st_mode) or
                metadata.st_uid != os.geteuid() or
                metadata.st_size < 10 or metadata.st_size > 4 * 1024 * 1024):
            raise OSError('Invalid private diagnostic source')
        data = reader.read(4 * 1024 * 1024 + 1)
        if len(data) > 4 * 1024 * 1024:
            raise OSError('Private diagnostic source grew beyond the size limit')
    prefix = 'Luna diagnostic report - LOCAL FILE ONLY\n'
    text = data.decode('utf-8', 'replace')
    if not text.startswith(prefix):
        raise OSError('Not a Luna diagnostic report')
    # Reapply redaction immediately before exposing the file via Samba.
    payload = (prefix + redact(text[len(prefix):])).encode('utf-8')
    if not source.name.startswith('luna-diagnostics-') or source.suffix != '.txt':
        raise OSError('Unexpected diagnostic filename')
    share = Path(logfiles_root)
    destination = share / 'Luna'
    directory_fd = _open_export_directory(share)
    temporary = None
    try:
        # Names are unpredictable; O_EXCL and O_NOFOLLOW prohibit replacement
        # of an existing temporary file or a symlink inserted via Samba.
        temporary = '.luna-export-%s.tmp' % secrets.token_hex(16)
        flags = (os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW |
                 getattr(os, 'O_CLOEXEC', 0))
        out_fd = os.open(temporary, flags, 0o600, dir_fd=directory_fd)
        # Retain the original inode until the final identity check. Closing
        # the only fd before validation permits immediate inode reuse after an
        # attacker replaces the published pathname via the Samba share.
        with os.fdopen(out_fd, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fchmod(stream.fileno(), 0o644)
            os.fsync(stream.fileno())
            meta = os.fstat(stream.fileno())
            published_inode = (meta.st_dev, meta.st_ino)
            # Publication and validation must see the SAME pinned inode.
            os.link(temporary, source.name, src_dir_fd=directory_fd,
                    dst_dir_fd=directory_fd, follow_symlinks=False)
            os.unlink(temporary, dir_fd=directory_fd)
            temporary = None
            os.fsync(directory_fd)
            _verify_export_destination(share, directory_fd, source.name,
                                       published_inode)
            _prune_reports(directory_fd, source.name)
            return destination / source.name
    finally:
        try:
            if temporary is not None:
                os.unlink(temporary, dir_fd=directory_fd)
        finally:
            os.close(directory_fd)

def show_in_kodi(path):
    """Show where the locally saved, redacted report is; no review reminder."""
    import xbmcgui
    xbmcgui.Dialog().ok(
        'Luna diagnostic report',
        'Saved redacted diagnostic report to:\n%s\n\n'
        'Windows: \\\\CoreELEC\\Logfiles\\Luna' % path)

def save_report_with_dialog(data_dir, kodi_log=None, legacy_log=None,
                            log_failure=None):
    """Common manual and early-exit path: preserve and report private files."""
    private = None
    try:
        private = create_report(data_dir, kodi_log=kodi_log, legacy_log=legacy_log)
        exported = export_report(private)
    except (OSError, ValueError) as error:
        if log_failure is not None:
            log_failure(type(error).__name__)
        if private is None:
            message = ('Could not create the private diagnostic report. '
                       'Check available storage and permissions.')
        else:
            message = ('Private redacted report saved to:\n%s\n\n'
                       'Could not complete export to CoreELEC Logfiles. '
                       'Check available storage and share permissions.' % private)
        import xbmcgui
        xbmcgui.Dialog().ok('Luna diagnostics', message)
        return False
    show_in_kodi(exported)
    return True


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Write local Luna diagnostics; never upload')
    parser.add_argument('--data-dir', default='/storage/.kodi/userdata/addon_data/script.luna.ng')
    parser.add_argument('--kodi-log', default='/storage/.kodi/temp/kodi.log')
    parser.add_argument('--legacy-log')
    options = parser.parse_args()
    report = create_report(options.data_dir, options.kodi_log, options.legacy_log)
    print(export_report(report))


if __name__ == '__main__':
    main()
