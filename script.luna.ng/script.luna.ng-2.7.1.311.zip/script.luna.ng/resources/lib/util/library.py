"""Persistent user folders with host-isolated application assignments."""
import hashlib
import json
import os
import tempfile

from resources.lib.util.safejson import read_bounded_json
from resources.lib.util.safelock import locked_regular_file

FILE_NAME = 'folders.json'
MAX_FOLDER_BYTES = 1024 * 1024
MAX_APPLIST_BYTES = 4 * 1024 * 1024


class LibraryDataError(ValueError):
    """Existing folder state is unreadable; never replace it with defaults."""
    pass
_UNCONFIGURED = 'unconfigured'


class Library(object):
    def __init__(self, folder, host=None):
        self.path = os.path.join(folder, FILE_NAME)
        self.host_key = self.host_identity(host)
        self._data = None
        self._needs_migration = False

    @staticmethod
    def host_identity(host):
        """Use the same normalized host identity as Luna's artwork cache."""
        normalized = (host or '').strip().lower()
        if not normalized:
            return _UNCONFIGURED
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()[:20]

    def _legacy_host(self):
        """If possible, assign legacy folders to their last cached host."""
        try:
            payload = read_bounded_json(
                os.path.join(os.path.dirname(self.path), 'applist.json'),
                MAX_APPLIST_BYTES)
            key = payload.get('host') if isinstance(payload, dict) else None
            if (isinstance(key, str) and len(key) == 20 and
                    all(char in '0123456789abcdef' for char in key)):
                return key
        except (OSError, ValueError, TypeError):
            pass
        return self.host_key

    def _load(self):
        if self._data is not None:
            return self._data

        self._needs_migration = False
        data = {'folders': [], 'assign_by_host': {}}
        try:
            loaded = read_bounded_json(self.path, MAX_FOLDER_BYTES)
            if not isinstance(loaded, dict):
                raise ValueError('folder document is not an object')
            # The modern format has assign_by_host; legacy has assign.
            # Missing both is an incomplete existing database, not an empty
            # first-run database. Refuse to overwrite its remaining content.
            if ('folders' not in loaded or
                    ('assign_by_host' not in loaded and 'assign' not in loaded)):
                raise ValueError('incomplete folder document')
            folders = loaded['folders']
            if (not isinstance(folders, list) or
                    any(not isinstance(name, str) for name in folders)):
                raise ValueError('invalid folder names')
            data['folders'] = list(folders)

            assignments = loaded.get('assign_by_host')
            if assignments is not None:
                if (not isinstance(assignments, dict) or
                        any(not isinstance(key, str) or not isinstance(value, dict) or
                            any(not isinstance(app_id, str) or not isinstance(folder, str)
                                for app_id, folder in value.items())
                            for key, value in assignments.items())):
                    raise ValueError('invalid host assignments')
                data['assign_by_host'] = assignments
            else:
                # Older records use 'assign'. Preserve the owning cached host.
                legacy = loaded.get('assign', {})
                if (not isinstance(legacy, dict) or
                        any(not isinstance(k, str) or not isinstance(v, str)
                            for k, v in legacy.items())):
                    raise ValueError('invalid legacy assignments')
                if legacy:
                    self._needs_migration = True
                    data['assign_by_host'][self._legacy_host()] = dict(legacy)
        except FileNotFoundError as error:
            # Dangling symlinks and races on an existing file are not
            # equivalent to first-time initialization.
            if os.path.lexists(self.path):
                raise LibraryDataError('Existing folders.json is inaccessible') from error
        except (OSError, ValueError, TypeError, UnicodeError) as error:
            raise LibraryDataError(
                'Existing folders.json is invalid or unreadable; original preserved') from error

        self._data = data
        return data

    def _assignments(self):
        return self._load()['assign_by_host'].setdefault(self.host_key, {})

    def _refresh(self):
        # Another Library instance may have updated a different host's folders.
        # Re-read before mutations instead of overwriting its newer assignments.
        self._data = None
        return self._load()

    def _save(self):
        data = self._load()
        path = None
        try:
            # Apply the same byte cap that _load enforces, BEFORE touching
            # the existing file. Character counts miss multi-byte UTF-8.
            encoded = json.dumps(
                data, ensure_ascii=False, indent=1).encode('utf-8')
            if len(encoded) > MAX_FOLDER_BYTES:
                return False
            folder = os.path.dirname(self.path)
            os.makedirs(folder, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode='wb', dir=folder,
                                             prefix='.folders.',
                                             delete=False) as stream:
                path = stream.name
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(path, self.path)
            return True
        except (OSError, ValueError, TypeError, UnicodeError):
            return False
        finally:
            if path is not None:
                try:
                    os.remove(path)
                except OSError:
                    pass

    def migrate_legacy(self):
        """Commit legacy host ownership under the folder lock before cache refresh."""
        folder = os.path.dirname(self.path)
        try:
            os.makedirs(folder, exist_ok=True)
            with locked_regular_file(self.path + '.lock'):
                self._data = None
                self._load()
                if not self._needs_migration:
                    return True
                saved = self._save()
                if not saved:
                    self._data = None
                return saved
        except OSError:
            self._data = None
            return False

    def folders(self):
        return list(self._load()['folders'])

    def _mutate(self, modify):
        """Serialize multi-instance changes and refresh disk state under lock.

        Folder names are global while each host's app assignments are scoped.
        A previously loaded Library must not overwrite assignments made by
        another Kodi invocation while it was alive.
        """
        folder = os.path.dirname(self.path)
        try:
            os.makedirs(folder, exist_ok=True)
            # Never delete the lock file: all processes must lock one inode.
            with locked_regular_file(self.path + '.lock'):
                self._data = None
                data = self._load()
                if not modify(data):
                    return False
                saved = self._save()
                if not saved:
                    self._data = None
                return saved
        except OSError:
            self._data = None
            return False

    def add_folder(self, name):
        name = (name or '').strip()
        if not name:
            return False
        def modify(data):
            if name in data['folders']:
                return False
            data['folders'].append(name)
            return True
        return self._mutate(modify)

    def rename_folder(self, old, new):
        new = (new or '').strip()
        if not new:
            return False
        def modify(data):
            if old not in data['folders'] or new in data['folders']:
                return False
            data['folders'][data['folders'].index(old)] = new
            for assignments in data['assign_by_host'].values():
                for app_id, folder in assignments.items():
                    if folder == old:
                        assignments[app_id] = new
            return True
        return self._mutate(modify)

    def remove_folder(self, name):
        def modify(data):
            if name not in data['folders']:
                return False
            data['folders'].remove(name)
            for key, assignments in data['assign_by_host'].items():
                data['assign_by_host'][key] = {
                    app_id: folder for app_id, folder in assignments.items()
                    if folder != name
                }
            return True
        return self._mutate(modify)

    def folder_of(self, app_id):
        data = self._load()
        folder = self._assignments().get(str(app_id))
        return folder if folder in data['folders'] else None

    def assign(self, app_id, folder):
        app_id = str(app_id)
        def modify(data):
            assignments = data['assign_by_host'].setdefault(self.host_key, {})
            if folder is None:
                assignments.pop(app_id, None)
            else:
                if folder not in data['folders']:
                    return False
                assignments[app_id] = folder
            return True
        return self._mutate(modify)

    def split(self, apps):
        data = self._load()
        buckets = {name: [] for name in data['folders']}
        loose = []
        assignments = self._assignments()

        for app in apps:
            folder = assignments.get(str(app[0]))
            if folder not in buckets:
                loose.append(app)
            else:
                buckets[folder].append(app)

        return [(name, buckets[name]) for name in data['folders']], loose
