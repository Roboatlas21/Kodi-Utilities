"""Kodi-owned artwork worker: directory listing never waits for image requests."""
import concurrent.futures
import json
import os
import time
import tempfile
import uuid
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.util.moonlighthelper import MoonlightHelper
from resources.lib.util.safejson import read_bounded_json
from resources.lib.util.safelock import locked_regular_file
from resources.lib.util.appidentity import canonical_app_id


def process_job(path, monitor):
    payload = read_bounded_json(path, 4 * 1024 * 1024)
    address = payload['host']
    ids = payload['ids']
    refresh = payload.get('refresh') is True
    if (not isinstance(address, str) or not address or len(address) > 1024 or
            not isinstance(ids, list) or len(ids) > 20000 or
            any(canonical_app_id(value) != value for value in ids)):
        raise ValueError('Invalid artwork request')
    options = payload.get('host_options', {})
    if (not isinstance(options, dict) or set(options) - {'port', 'keydir'} or
            any(not isinstance(v, str) for v in options.values())):
        raise ValueError('Invalid host context')
    from resources.lib.util.nativeini import validate_and_mask_inputs
    validate_and_mask_inputs('[Moonlight]\n' + ''.join('%s = %s\n' % kv for kv in options.items()))
    helper = MoonlightHelper.__new__(MoonlightHelper)
    helper._artwork_host_options = options
    changed = False
    failed = []
    last_refresh = 0

    def publish(force=False):
        nonlocal changed, last_refresh
        now = time.monotonic()
        if not changed or monitor.abortRequested() or (not force and now - last_refresh < 2):
            return
        current = xbmcaddon.Addon('script.luna.ng').getSetting('host_addr')
        if (current == address and
                xbmc.getInfoLabel('Container.PluginName') == 'script.luna.ng'):
            xbmc.executebuiltin('Container.Refresh')
        changed = False
        last_refresh = now

    def fetch(app_id):
        if monitor.abortRequested():
            return None, False
        previous = helper._art_if_present(address, app_id)
        result = helper.boxart_path(address, app_id, refresh=refresh)
        return result, bool(result and (refresh or not previous))

    # A batch has at most three futures; failed IDs alone survive a retry.
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for offset in range(0, len(ids), 3):
            if monitor.abortRequested():
                return False
            pending = [(value, pool.submit(fetch, value)) for value in ids[offset:offset + 3]]
            for app_id, future in pending:
                try:
                    result, updated = future.result()
                    changed = updated or changed
                    if not result:
                        failed.append(app_id)
                except Exception:
                    failed.append(app_id)
            publish()
    publish(force=True)
    if failed:
        payload['ids'] = failed
        defer_job(path, payload)
        return False
    return True


def defer_job(path, payload=None):
    if payload is None:
        payload = read_bounded_json(path, 4 * 1024 * 1024)
    attempts = min(int(payload.get('attempts', 0)) + 1, 8)
    payload['attempts'] = attempts
    payload['retry_at'] = time.time() + min(300, 2 ** attempts)
    # Keep the job after prolonged outages; capped delay avoids busy retrying.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', dir=path.parent,
                prefix='.retry-', delete=False) as stream:
            temporary = stream.name
            json.dump(payload, stream)
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def run():
    monitor = xbmc.Monitor()
    root = Path(xbmcvfs.translatePath('special://profile/addon_data/script.luna.ng/'))
    jobs = root / 'artwork-jobs'
    jobs.mkdir(parents=True, exist_ok=True)
    try:
        with locked_regular_file(str(jobs / 'worker.lock'), timeout=0):
            while not monitor.abortRequested():
                for path in sorted(jobs.glob('*.json')):
                    work = path.with_suffix('.work')
                    try:
                        if work.exists():
                            # Each accepted generation makes progress independently.
                            # Rename claims the exact inode; a later producer is safe.
                            work = path.with_name(path.stem + '-' + uuid.uuid4().hex + '.work')
                        os.replace(path, work)
                    except OSError:
                        continue  # Retry claim after transient storage/resource failure.
                for work in sorted(jobs.glob('*.work')):
                    if monitor.abortRequested():
                        return
                    try:
                        payload = read_bounded_json(work, 4 * 1024 * 1024)
                        if not isinstance(payload, dict):
                            raise ValueError('Artwork job must be an object')
                        if float(payload.get('retry_at', 0)) > time.time():
                            continue
                        complete = process_job(work, monitor)
                    except (RuntimeError, OSError):
                        try:
                            defer_job(work)
                        except (OSError, ValueError, TypeError, KeyError):
                            pass
                        complete = False
                    except (ValueError, TypeError, KeyError):
                        complete = True  # Drop malformed jobs, not cached images.
                    if complete:
                        try:
                            work.unlink(missing_ok=True)
                        except OSError:
                            pass  # A completed job can safely be retried.
                if monitor.waitForAbort(1):
                    return
    except TimeoutError:
        pass  # Another Kodi service instance owns the queue.


if __name__ == '__main__':
    run()
