"""Session-scoped CoreELEC HDMI mode matching, with crash-recovery journal.

This changes only a mode already advertised by the connected HDMI display.
Never changes Kodi/AML framebuffer geometry or any decoder setting.
"""
import configparser
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time

# Kodi imports this module as a package, but the CoreELEC launcher also
# executes hdmimode.py directly. Both invocation styles must work.
if __package__:
    from resources.lib.util.safejson import read_bounded_json
    from resources.lib.util.safefile import read_regular_bytes
    from resources.lib.util.nativeini import MAX_BYTES as MAX_STREAM_CONFIG_BYTES
else:
    # Scripts can run without the Kodi add-on root on the import path.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from safejson import read_bounded_json
    from safefile import read_regular_bytes
    from nativeini import MAX_BYTES as MAX_STREAM_CONFIG_BYTES


# Trusted Amlogic HDMI output names. Do not write arbitrary EDID strings to
# the global /sys/class/display/mode control.
MODE_RE = re.compile(
    r'^(?:480p60|576p50|720p(?:50|60)|'
    r'1080p(?:24|25|30|50|60|100|120)|1080i(?:50|60)|'
    r'2160p(?:24|25|30|50|60)|smpte(?:24|25|30|50|60))hz(?:420)?$')
FORMAT_BY_SIZE = {
    (1280, 720): '720p',
    (1920, 1080): '1080p',
    (3840, 2160): '2160p',
    (4096, 2160): 'smpte',
}
FPS_SUPPORTED = frozenset((24, 25, 30, 50, 60, 100, 120))
# Stream FPS and Amlogic HDMI output refresh are distinct capabilities:
# 90 FPS is a valid native stream profile but has no exact HDMI modeset.
STREAM_FPS_SUPPORTED = FPS_SUPPORTED | {90}


def profile_needs_unmatched_hdmi_output(stream_config):
    """Only unsupported stream modes may opt into a single-launch bypass.

    EDID mismatch, unreadable display state, or recovery uncertainty must
    continue to fail closed; they are NOT invitations to bypass user policy.
    """
    profile = snapshot_stream(stream_config)
    return (profile is not None and
            (profile[:2] not in FORMAT_BY_SIZE or profile[2] not in FPS_SUPPORTED))


def valid_mode(value):
    return isinstance(value, str) and MODE_RE.fullmatch(value) is not None


def capabilities(contents):
    # Most Amlogic devices put one EDID mode on each line; a trailing '*'
    # denotes the preferred/current mode on some releases.
    if len(contents) > 16384:
        return set()
    modes = set()
    for line in contents.splitlines():
        mode = line.strip().removesuffix('*').strip()
        if valid_mode(mode):
            modes.add(mode)
    return modes


def requested_mode(width, height, fps, available, current):
    name = FORMAT_BY_SIZE.get((width, height))
    if not name or fps not in FPS_SUPPORTED:
        return None
    prefix = '%s%dhz' % (name, fps)
    # Same geometry/rate already active? Avoid a pointless modeset just to
    # switch between unqualified and 4:2:0 variants.
    if current in (prefix, prefix + '420'):
        return current
    # Prefer full-rate modes without forced chroma subsampling; accept 420
    # only when EDID explicitly offers it for this UHD output mode.
    if prefix in available:
        return prefix
    if name in ('2160p', 'smpte') and prefix + '420' in available:
        return prefix + '420'
    return None


class HdmiModeUnavailable(ValueError):
    """Kodi can show this message without stopping local playback."""


def exact_rate(mode_node, fps):
    """The mode name alone cannot distinguish integer and fractional clocks."""
    try:
        text = Path(mode_node).with_name('vinfo').read_text(encoding='utf-8')
        values = [re.search(r'\b' + key + r'\s*[:=]\s*(\d+)', text)
                  for key in ('sync_duration_num', 'sync_duration_den')]
        return all(values) and int(values[1][1]) > 0 and int(values[0][1]) == fps * int(values[1][1])
    except (OSError, ValueError):
        return False


def integer_policy(mode_node):
    node = (Path('/sys/class/amhdmitx/amhdmitx0/frac_rate_policy')
            if str(mode_node).startswith('/sys/') else Path(mode_node).with_name('frac_rate_policy'))
    try:
        return node.read_text(encoding='ascii').strip() == '0'
    except (OSError, UnicodeError):
        return False


def check(stream_config, mode_node='/sys/class/display/mode',
          cap_node='/sys/class/amhdmitx/amhdmitx0/disp_cap'):
    """Validate an exact HDMI output mode without making any display changes.

    This must run before Kodi handoff and again immediately before switching:
    EDID or selected stream settings might change between those two checks.
    """
    profile = snapshot_stream(stream_config)
    if profile is None:
        raise HdmiModeUnavailable(
            'Cannot read the selected Moonlight resolution and FPS. '
            'HDMI matching is enabled; streaming was cancelled.')
    width, height, fps = profile
    if (width, height) not in FORMAT_BY_SIZE or fps not in FPS_SUPPORTED:
        raise HdmiModeUnavailable(
            'Exact HDMI matching is not supported for %dx%d at %d Hz. '
            'Choose a supported Moonlight resolution/FPS or disable '
            'HDMI matching.' % (width, height, fps))
    try:
        current = read_mode(mode_node)
        available = capabilities(Path(cap_node).read_text(encoding='utf-8'))
    except (OSError, UnicodeError, ValueError) as error:
        raise HdmiModeUnavailable(
            'Cannot verify the TV HDMI modes (%s). '
            'Streaming was cancelled.' % error) from error
    if not available:
        raise HdmiModeUnavailable(
            'The TV did not advertise any recognized HDMI modes. '
            'Streaming was cancelled; check the HDMI connection or '
            'disable HDMI matching.')
    if current not in available:
        raise HdmiModeUnavailable(
            'Current HDMI mode %s is not listed by the TV. '
            'Luna cannot guarantee restoring it; streaming was cancelled.'
            % current)
    target = requested_mode(width, height, fps, available, current)
    if target is None:
        raise HdmiModeUnavailable(
            'The TV does not advertise an exact HDMI mode for %dx%d at '
            '%d Hz. Choose another Moonlight resolution/FPS or disable '
            'HDMI matching.' % (width, height, fps))
    if target == current:
        if not exact_rate(mode_node, fps):
            raise HdmiModeUnavailable('Current HDMI refresh is not verified at exact %d Hz.' % fps)
    elif fps in (24, 30, 60, 120) and not integer_policy(mode_node):
        raise HdmiModeUnavailable('Exact HDMI matching requires verified integer refresh policy; disable matching or select integer output timing.')
    return current, target


def snapshot_stream(stream_config):
    if not stream_config:
        return None
    parser = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        # Immutable launch INI snapshots use the same 1-MiB bound as native
        # configuration. One no-follow, nonblocking regular fd avoids a FIFO
        # blocking Kodi during preflight or a concurrent pathname swap.
        raw, _ = read_regular_bytes(stream_config, MAX_STREAM_CONFIG_BYTES)
        parser.read_string(raw.decode('utf-8'))
        width = int(parser.get('Moonlight', 'width'))
        height = int(parser.get('Moonlight', 'height'))
        fps = int(parser.get('Moonlight', 'fps'))
    except (OSError, UnicodeError, ValueError, configparser.Error):
        return None
    if width <= 0 or height <= 0 or fps not in STREAM_FPS_SUPPORTED:
        return None
    return width, height, fps


def read_mode(node):
    # Unlike fps_info, reading the CoreELEC display mode has no sampling
    # side effect. Require exactly one known, stable mode name.
    raw = Path(node).read_text(encoding='utf-8').strip()
    if not valid_mode(raw):
        raise ValueError('unrecognized current HDMI mode %r' % raw[:64])
    return raw


def write_mode(node, mode):
    if not valid_mode(mode):
        raise ValueError('invalid HDMI output mode')
    with Path(node).open('w', encoding='utf-8') as output:
        output.write(mode + '\n')


def verified_mode(node, target, fps=None):
    # Amlogic modesets can settle asynchronously. Always verify readback
    # before Moonlight starts or Kodi takes back display ownership.
    for attempt in range(11):
        try:
            if read_mode(node) == target and (fps is None or exact_rate(node, fps)):
                return True
        except (OSError, ValueError):
            pass
        if attempt < 10:
            time.sleep(0.025)
    return False


def safe_state_file(state):
    state = Path(state)
    if state.is_symlink():
        raise ValueError('HDMI mode recovery journal must not be a symlink')
    if state.exists() and not state.is_file():
        raise ValueError('HDMI mode recovery journal is not a regular file')
    return state


def create_journal(state, mode_node, original, applied):
    state = safe_state_file(state)
    if state.exists():
        raise ValueError('unretired HDMI mode journal prevents another modeset')
    payload = {'schema': 1, 'mode_node': str(mode_node),
               'original': original, 'applied': applied}
    temporary = None
    try:
        fd, temporary = tempfile.mkstemp(
            dir=str(state.parent), prefix='.luna-hdmi-mode-', suffix='.pending')
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            os.fchmod(out.fileno(), 0o600)
            json.dump(payload, out, separators=(',', ':'))
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        # No-overwrite publication, after durable complete content: a killed
        # launcher cannot leave a partial journal trusted by the watchdog.
        os.link(temporary, state)
        directory = os.open(str(state.parent), os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def restore(state, mode_node, cap_node):
    state = safe_state_file(state)
    if not state.exists():
        return
    saved = read_bounded_json(state, 4096)
    if (not isinstance(saved, dict) or saved.get('schema') != 1 or
            saved.get('mode_node') != str(mode_node) or
            not valid_mode(saved.get('original')) or
            not valid_mode(saved.get('applied')) or
            saved['original'] == saved['applied']):
        raise ValueError('unsafe HDMI mode recovery journal')
    current = read_mode(mode_node)
    if current == saved['original']:
        state.unlink()
        print('Luna NG: HDMI mode already restored (%s)' % current)
        return
    if current != saved['applied']:
        # Another owner (or hotplug) selected a third mode. Never clobber it.
        state.unlink()
        print('Luna NG: HDMI mode changed externally (%s); not overriding' % current)
        return
    supported = capabilities(Path(cap_node).read_text(encoding='utf-8'))
    if saved['original'] not in supported:
        raise OSError('original HDMI mode is no longer in connected display capabilities')
    write_mode(mode_node, saved['original'])
    if not verified_mode(mode_node, saved['original']):
        raise OSError('failed to confirm original HDMI mode after restore')
    state.unlink()
    print('Luna NG: HDMI mode restored to %s' % saved['original'])


def apply(state, mode_node, cap_node, stream_config):
    state = safe_state_file(state)
    if state.exists():
        raise ValueError('pending HDMI mode recovery journal; cannot change mode')
    # Unlike the original silent fallback, every unsupported/unverifiable
    # mode is a hard error. The launcher will recover Kodi without streaming.
    current, target = check(stream_config, mode_node, cap_node)
    width, height, fps = snapshot_stream(stream_config)
    if target == current:
        print('Luna NG: HDMI mode already matches %dx%d@%d (%s)' %
              (width, height, fps, current))
        return
    create_journal(state, mode_node, current, target)
    try:
        write_mode(mode_node, target)
        if not verified_mode(mode_node, target, fps):
            raise OSError('HDMI mode %s did not take effect' % target)
    except (OSError, ValueError):
        # The atomic state survives a crash between journal and write.
        # Attempt an immediate rollback, then leave it for the watchdog if
        # the output cannot be restored.
        restore(state, mode_node, cap_node)
        raise
    print('Luna NG: HDMI output %s -> %s for %dx%d@%d stream' %
          (current, target, width, height, fps))


def main(args):
    if len(args) == 6 and args[1] == 'apply':
        apply(args[2], args[3], args[4], args[5])
    elif len(args) == 5 and args[1] == 'check':
        current, target = check(args[4], args[2], args[3])
        print('Luna NG: HDMI mode available: %s -> %s' % (current, target))
    elif len(args) == 5 and args[1] == 'restore':
        restore(args[2], args[3], args[4])
    else:
        raise ValueError('Usage: hdmimode.py apply STATE MODE CAP STREAM_CONFIG | check MODE CAP STREAM_CONFIG | restore STATE MODE CAP')


if __name__ == '__main__':
    try:
        main(sys.argv)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as error:
        print('Luna NG: HDMI mode match: %s' % error, file=sys.stderr)
        sys.exit(1)
