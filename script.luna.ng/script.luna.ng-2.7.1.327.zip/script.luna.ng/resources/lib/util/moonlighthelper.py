import os
import tempfile
import signal
import subprocess
import queue
import time
import re
import threading
import traceback
import uuid
from contextlib import contextmanager, ExitStack

LUNA_NG_ACK_WAIT_SECONDS = 6.0

def rfi_recovery_timeout(plugin):
    """Opt-in recovery deadline; explicit zero overrides inherited shell state."""
    if not plugin.getSettingBool('experimental_rfi_recovery'):
        return '0'
    value = plugin.getSettingString('rfi_recovery_timeout_ms') or '100'
    return value if value in ('50', '100', '150', '200', '300', '500') else '100'

def encode_input_names(names):
    """Exact UTF-8 whitelist for evdev hotplug; delimiters cannot escape hex."""
    encoded = []
    for name in names:
        data = name.encode('utf-8')
        if not data or len(data) > 255 or b'\x00' in data:
            raise ValueError('Invalid selected controller device name')
        encoded.append(data.hex())
    result = ','.join(dict.fromkeys(encoded))
    if len(result) > 16384:
        raise ValueError('Selected controller names exceed native whitelist size')
    return result

LUNA_NG_RECOVERY_STEP_SECONDS = 240.0
LUNA_NG_RECOVERY_MAX_SECONDS = 900.0

def recovery_step_seconds(env):
    """Kodi may await one old-session recovery without a progress heartbeat.

    The recover-only launcher budgets recovery_timeout + 45 seconds for its
    own lock acquisition, restoration and overhead. Keep a further 15-second
    handoff margin, but never extend the 900-second total reconciliation cap.
    Invalid overrides use the same 180-second default as the watchdog.
    """
    requested = env.get('LUNA_RECOVERY_TIMEOUT', '180')
    if not isinstance(requested, str) or not requested.isascii() or not requested.isdigit():
        requested = '180'
    seconds = int(requested)
    if seconds < 1 or seconds > 300:
        seconds = 180
    return float(seconds + 60)

import xbmc
import xbmcgui

def env_with_libs(binary_path, addon_path=None):
    env = dict(os.environ)
    root = os.path.abspath(addon_path or '')
    selected = os.path.abspath(binary_path or '')
    bin_root = os.path.join(root, 'bin')
    # System-installed Moonlight must not inherit the add-on's shared libraries.
    if not root or not (selected == bin_root or selected.startswith(bin_root + os.sep)):
        return env
    arch = 'coreelec-ng' if __import__('struct').calcsize('P') == 4 else 'coreelec-no'
    private = os.path.join(root, 'lib', arch)
    legacy = os.path.join(root, 'lib')
    if os.path.isdir(private):
        lib = private
    elif selected == bin_root and os.path.isdir(legacy):
        lib = legacy
    else:
        return env
    previous = env.get('LD_LIBRARY_PATH', '')
    env['LD_LIBRARY_PATH'] = lib + (':' + previous if previous else '')
    return env


def moonlight_environment(config_helper):
    return env_with_libs(config_helper.binary_path, config_helper.addon_path)


class MoonlightHelper:

    config_helper = None

    def __init__(self, plugin, config_helper, logger):
        self.plugin = plugin
        self.config_helper = config_helper
        self.logger = logger
        self.pin_received = False
        self._pairing_pin = None
        self.paired_address = None
        self.paired_context = None
        self.pairing_messages = ""
        self._pairing_error = None
        self.pair_success = False
        self.last_host_error = None
        self.last_unpair_error = None

    def _pair_line(self, line, dialog):
        text = line.strip()
        if not text:
            return

        # The four-digit pairing PIN belongs in the visible PIN dialog only,
        # never in persistent Kodi logs (including ordinary INFO-level logs).
        if 'enter the following PIN' in line:
            match = re.search(r'\b(\d{4})\b', text)
            self._pairing_pin = match.group(1) if match else None
            xbmc.log('LUNA pairing: PIN prompt displayed [redacted]', xbmc.LOGINFO)
            self.pin_received = True
            dialog.update(50, text)
            return

        safe_text = text
        if getattr(self, '_pairing_pin', None):
            safe_text = safe_text.replace(self._pairing_pin, '[PIN REDACTED]')
        xbmc.log('LUNA pairing: ' + safe_text, xbmc.LOGINFO)

        if text.startswith('Pairing: '):
            # Native progress begins only after the host answers the PIN
            # request, so it cannot hide the PIN while the user needs it.
            dialog.update(75, text[len('Pairing: '):])
            return

        # Keep the authoritative failure even before the PIN is available,
        # and prioritize it over debug output from rollback requests.
        if text.startswith(('Failed to pair to server:', "Can't initialize Moonlight",
                            'Gamestream error:', 'Invalid data received from server:',
                            'Unsupported version:', 'Not enough memory')):
            self._pairing_error = text

        found = re.search(r'Connecting to (\S+?)\.\.\.', line)
        if found:
            self.paired_address = found.group(1)

        if not self.pin_received:
            return
        if line.lstrip().startswith(('Request ', 'Response:', '<?xml', '<root')):
            return
        self.pairing_messages += text + '\n'

    @staticmethod
    def _read_pairing_output(stream, output_queue):
        """Read native Moonlight output without select/TextIO buffering races."""
        try:
            for line in stream:
                output_queue.put(('line', line))
        except Exception as error:
            output_queue.put(('error', error))
        finally:
            output_queue.put(('eof', None))

    def _stop_pairing_process(self, process):
        if process is None or process.poll() is not None:
            return

        try:
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        except OSError:
            try:
                process.terminate()
            except OSError:
                pass

        try:
            process.wait(timeout=2)
            return
        except subprocess.TimeoutExpired:
            pass

        try:
            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
        except OSError:
            try:
                process.kill()
            except OSError:
                pass

        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass

    def pair(self, expected_address=None, expected_options=None):
        # Re-Pair must never reload a different endpoint after confirmation.
        if expected_address is None:
            self.config_helper.configure()
            self._frozen_host_options = getattr(self.config_helper, '_launch_host_options', None)
            self._host_options()
            address = (getattr(self, '_selected_address', None) or
                       self.config_helper.config.get('host_addr'))
        else:
            if not isinstance(expected_options, dict):
                raise ValueError('Confirmed pairing requires frozen host options')
            address = expected_address
            self._selected_address = address
            self._frozen_host_options = dict(expected_options)
        binary_path = self.config_helper.binary_path

        # Pairing state is per attempt. A cancelled/timed-out attempt must not
        # leak a stale PIN or success message into the next one.
        self.pair_success = False
        self.pin_received = False
        self._pairing_pin = None
        self.paired_address = None
        self.paired_context = None
        self.pairing_messages = ""
        self._pairing_error = None

        title = self.plugin.getLocalizedString(30000)
        if not address:
            xbmcgui.Dialog().ok(
                title, 'Set the Sunshine host address before pairing.')
            return False

        try:
            from resources.lib.util.hostapi import Host
            trusted_host = self._host(address)
            if trusted_host.has_trusted_pin() and trusted_host.paired():
                self.pair_success = True
                self.paired_address = address
                self.paired_context = self._host_identity(address)
                xbmcgui.Dialog().ok(
                    title,
                    self.plugin.getLocalizedString(30265)
                    or 'Already paired with this host')
                return True
        except Exception:
            # Native pairing below provides the authoritative result.
            pass

        pairing_context = ExitStack()
        pairing_proc = None
        pairing_thread = None
        pairing_thread_started = False
        pairing_output = queue.Queue()
        dialog = xbmcgui.DialogProgress()
        cancelled = False
        timeout_message = None

        try:
            command, pair_env = pairing_context.enter_context(
                self._native_host_command('pair', address))
            pairing_proc = subprocess.Popen(
                command,
                cwd=binary_path,
                env=pair_env,
                encoding='utf-8',
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
                start_new_session=True)

            pairing_thread = threading.Thread(
                target=self._read_pairing_output,
                args=(pairing_proc.stdout, pairing_output),
                name='LunaPairingReader',
                daemon=True)
            pairing_thread.start()
            pairing_thread_started = True

            dialog.create(
                title,
                (self.plugin.getLocalizedString(30285)
                 or 'Connecting to Sunshine...'))

            from resources.lib.util.pairing_deadline import PairingDeadline
            pairing_deadline = PairingDeadline(time.monotonic())
            eof_received = False

            while not eof_received:
                if dialog.iscanceled():
                    cancelled = True
                    break

                try:
                    event, value = pairing_output.get(timeout=0.1)
                except queue.Empty:
                    event = None
                    value = None

                if event == 'line':
                    had_pin = self.pin_received
                    self._pair_line(value, dialog)
                    now = time.monotonic()
                    if self.pin_received and not had_pin:
                        pairing_deadline.pin_shown(now)
                    if value.strip().startswith('Pairing: '):
                        pairing_deadline.stage(value.strip(), now)
                elif event == 'error':
                    raise value
                elif event == 'eof':
                    eof_received = True

                now = time.monotonic()
                if pairing_deadline.expired(now):
                    if not self.pin_received:
                        timeout_message = (
                            'Timed out waiting for a pairing PIN from %s. '
                            'Check that Sunshine is running and reachable.'
                            % address)
                    else:
                        timeout_message = (
                            'Pairing timed out while waiting for Sunshine to '
                            'complete the PIN handshake.')
                    break

            if cancelled or timeout_message:
                self._stop_pairing_process(pairing_proc)

            if (not cancelled and not timeout_message
                    and pairing_proc.poll() is None):
                try:
                    pairing_proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    timeout_message = 'Native Moonlight did not exit after pairing output.'
                    self._stop_pairing_process(pairing_proc)

            if cancelled:
                return False

            if timeout_message:
                xbmcgui.Dialog().ok(title, timeout_message)
                return False

            reported_success = ('Succesfully paired' in self.pairing_messages
                                or 'Successfully paired' in self.pairing_messages)
            if reported_success and pairing_proc.returncode == 0:
                # A printed success phrase alone is insufficient. The native
                # process must exit successfully, and HTTPS serverinfo must
                # confirm this exact device is now paired.
                try:
                    from resources.lib.util.hostapi import Host
                    trusted_host = self._host(address)
                    confirmed = (trusted_host.has_trusted_pin()
                                 and trusted_host.pair_status())
                except Exception as error:
                    xbmcgui.Dialog().ok(
                        title, 'Moonlight reported success, but pairing could '
                        'not be verified: %s' % error)
                    return False
                if not confirmed:
                    self.pairing_messages += (
                        'Sunshine did not establish a trusted certificate. '
                        'Remove any stale pairing in Sunshine and retry.\n')
                if confirmed:
                    self.pair_success = True
                    self.paired_address = address
                    self.paired_context = self._host_identity(address)
                    xbmcgui.Dialog().ok(
                        title, self.plugin.getLocalizedString(30286))
                    return True

            if reported_success and pairing_proc.returncode != 0:
                self.pairing_messages += (
                    'Moonlight exited with status %s; pairing was not confirmed.\n'
                    % pairing_proc.returncode)
            elif reported_success:
                self.pairing_messages += (
                    'Sunshine did not confirm pairing over HTTPS.\n')

            message = self._pairing_error or self.pairing_messages.strip()
            if not message:
                message = (self.plugin.getLocalizedString(30287)
                           or 'Pairing failed.')
            xbmcgui.Dialog().ok(title, message)
            return False
        except Exception as e:
            self._stop_pairing_process(pairing_proc)
            xbmcgui.Dialog().ok(
                title, xbmc.getLocalizedString(257) + ':\n' + str(e))
            return False
        finally:
            # Even when an OS thread-allocation failure prevents start(), the
            # native process, output pipe and temporary command context must
            # be closed. Keep every later cleanup reachable after an error.
            try:
                if pairing_proc is not None and pairing_proc.poll() is None:
                    self._stop_pairing_process(pairing_proc)
            finally:
                try:
                    if pairing_thread_started:
                        pairing_thread.join(timeout=2)
                finally:
                    try:
                        if pairing_proc is not None and pairing_proc.stdout is not None:
                            try:
                                pairing_proc.stdout.close()
                            except OSError:
                                pass
                    finally:
                        try:
                            pairing_context.close()
                        finally:
                            dialog.close()

    def forget_trusted_server(self, address, expected_options=None):
        """Deliberate local-only trust reset; does not revoke pairing keys."""
        self.last_trust_error = None
        if expected_options is None:
            self.config_helper.configure(dump=False)
        else:
            # A modal settings edit must not change the credential directory.
            self._selected_address = address
            self._frozen_host_options = dict(expected_options)
        binary_path = self.config_helper.binary_path
        if (not binary_path or not isinstance(address, str) or
                not address.strip() or address.startswith('-') or
                any(char.isspace() for char in address)):
            self.last_trust_error = 'Select a valid host and Moonlight binary.'
            return False
        try:
            with self._native_host_command('forget-server-cert', address) as (command, env):
                result = subprocess.run(
                    command,
                    cwd=binary_path,
                    env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    timeout=10, encoding='utf-8', start_new_session=True)
        except (OSError, subprocess.TimeoutExpired) as error:
            self.last_trust_error = 'Unable to clear trusted certificate: %s' % error
            return False
        if result.returncode != 0:
            self.last_trust_error = (result.stdout or '').strip() or (
                'Native trust reset failed (exit %s)' % result.returncode)
            return False
        return True

    def unpair(self, expected_address=None, expected_options=None):
        if expected_address is None:
            self.config_helper.configure()
            self._frozen_host_options = getattr(self.config_helper, '_launch_host_options', None)
            self._host_options()
            address = (getattr(self, '_selected_address', None) or
                       self.config_helper.config.get('host_addr'))
        else:
            # Freeze the confirmation-time address, port and key directory for
            # both native unpair and authenticated post-unpair verification.
            if not isinstance(expected_options, dict):
                raise ValueError('Confirmed unpair requires frozen host options')
            address = expected_address
            self._selected_address = address
            self._frozen_host_options = dict(expected_options)
        binary_path = self.config_helper.binary_path
        self.last_unpair_error = None
        self.last_unpair_unverified = False
        if not address or not binary_path:
            self.last_unpair_error = 'No Sunshine host or Moonlight binary is configured.'
            return False
        try:
            with self._native_host_command('unpair', address) as (command, env):
                result = subprocess.run(
                    command,
                    cwd=binary_path,
                    env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    timeout=10, encoding='utf-8', start_new_session=True)
            output = (result.stdout or '').strip()
        except (OSError, subprocess.TimeoutExpired) as error:
            self.last_unpair_error = 'Unable to unpair from %s: %s' % (address, error)
            return False

        # Transport/protocol errors from the native client are authoritative.
        # An unauthenticated HTTP PairStatus=0 must NEVER override a failed
        # /unpair response: public serverinfo is not a trusted pairing result.
        if result.returncode != 0:
            self.last_unpair_error = (
                'Native Moonlight unpair failed (exit %s) for %s: %s'
                % (result.returncode, address,
                   output or 'No error details returned'))
            return False

        # Native /unpair may succeed even when a legacy client has no trusted
        # server certificate. Never mistake missing trust for a TLS mismatch:
        # report the accepted request as UNVERIFIED, not as confirmed remote
        # unpairing. A saved pin still requires authenticated verification.
        try:
            from resources.lib.util.hostapi import Host
            host = self._host(address)
            if not host.has_trusted_pin():
                self.last_unpair_unverified = True
                return True
            if not host.pair_status(allow_http_fallback=True):
                # A public HTTP 0 is useful evidence after client revocation,
                # not an authenticated server assertion.
                self.last_unpair_unverified = host._last_pair_status_public
                return True
        except Exception as error:
            self.last_unpair_error = (
                'Cannot confirm that %s was unpaired: %s' % (address, error))
            return False
        self.last_unpair_error = (
            'Host %s still reports this device paired. %s' % (address, output))
        return False

    def list_games(self):
        """Compatibility method: never use an unbound native name-only list.

        The older list action can silently merge stale moonlight.conf or
        autodiscover another host. Fail closed if exact-ID listing is unavailable.
        """
        detailed = self.list_games_native_detailed()
        if detailed is None:
            return False
        names = [name for _app_id, name, _art in detailed]
        if len(names) != len(set(names)):
            self.last_host_error = ('Duplicate Sunshine application titles '
                                    'require exact ID-based selection.')
            return False
        return names

    def list_games_native_detailed(self, snapshot=None):
        """List IDs using an immutable config bound to the chosen Sunshine host.

        A native subprocess must never consult stale moonlight.conf, a
        hosts/<name>.conf override, or autodiscover a different host.
        """
        if snapshot is None:
            self.config_helper.configure(dump=False)
        binary_path = self.config_helper.binary_path
        if not binary_path or not self._is_coreelec_ng(binary_path):
            self.last_host_error = 'Exact host-bound application IDs require Luna NG.'
            return None
        owned_snapshot = None
        try:
            if snapshot is None:
                owned_snapshot = self.config_helper.create_host_lookup_snapshot()
                snapshot = owned_snapshot
            env = env_with_libs(binary_path, self.config_helper.addon_path)
            env['LUNA_STREAM_CONFIG'] = snapshot
            result = subprocess.run(
                [binary_path + 'moonlight', 'list-ids', '-config', snapshot],
                cwd=binary_path, env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                encoding='utf-8', errors='replace', timeout=8,
                start_new_session=True, check=False)
            if result.returncode != 0:
                reason = self._native_failure_summary(result.stdout)
                self.last_host_error = (
                    'Moonlight list-ids failed (exit %s): %s' %
                    (result.returncode, reason or 'Sunshine application IDs unavailable.'))
                return None
            lines = result.stdout.splitlines()
            if (lines.count('LUNA_APP_IDS_V1') != 1 or
                    lines.count('LUNA_APP_IDS_END') != 1):
                raise ValueError('Missing native application ID record markers')
            begin = lines.index('LUNA_APP_IDS_V1')
            end = lines.index('LUNA_APP_IDS_END')
            if end <= begin or end - begin > 4097:
                raise ValueError('Invalid native application ID record count')
            from resources.lib.util.appidentity import canonical_app_id
            detailed = []
            seen = set()
            for row in lines[begin + 1:end]:
                number, separator, encoded = row.partition('\t')
                if not separator or not encoded or len(encoded) > 8192:
                    raise ValueError('Malformed native application record')
                app_id = canonical_app_id(number)
                name = bytes.fromhex(encoded).decode('utf-8')
                if not name or '\x00' in name or app_id in seen:
                    raise ValueError('Invalid or duplicate native application ID')
                seen.add(app_id)
                detailed.append((app_id, name, None))
            self.last_host_error = None
            return detailed
        except (OSError, subprocess.TimeoutExpired, UnicodeError, ValueError,
                TypeError) as error:
            self.last_host_error = 'Cannot safely list Sunshine application IDs: %s' % error
            return None
        finally:
            if owned_snapshot is not None:
                try:
                    os.unlink(owned_snapshot)
                except OSError:
                    pass

    @staticmethod
    def _ng_conflict_choice(running_id, selected_name):
        """No automatic quit: ask explicitly how to handle a different app."""
        return xbmcgui.Dialog().select(
            'Another Sunshine application is already running (ID %s)' % running_id,
            ['Cancel (leave Sunshine unchanged)',
             'Resume the running application',
             'Quit the running application and launch %s' % selected_name])

    @staticmethod
    def _native_failure_summary(output):
        """Show bounded native diagnostics, not raw HTTP requests or responses."""
        prefixes = (
            'Invalid data received from server:',
            'Gamestream error:',
            'Unsupported version:',
            'PIN-verified Sunshine server trust is required',
            'Default Moonlight configuration rejected',
            'Host-specific Moonlight configuration rejected',
            'app-status requires -appid',
        )
        for raw_line in reversed((output or '').splitlines()):
            line = raw_line.strip()
            if (line.startswith(prefixes) and len(line) <= 240 and
                    not any(mark in line for mark in ('://', '?', '<', '>', '=')) and
                    all(32 <= ord(char) < 127 for char in line)):
                return line
        return None

    def _running_ng_app(self, binary_path, env, app_id, timeout_seconds=12):
        """Return the verified running app ID without taking Kodi away."""
        from resources.lib.util.appidentity import canonical_app_id
        snapshot = env.get('LUNA_STREAM_CONFIG')
        if not snapshot:
            return None, 'Luna host snapshot was not provided'
        try:
            requested = canonical_app_id(app_id)
            command = [binary_path + 'moonlight', 'app-status',
                       '-config', snapshot, '-appid', requested]
            result = subprocess.run(
                command, cwd=binary_path, env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                encoding='utf-8', errors='replace', timeout=timeout_seconds,
                start_new_session=True, check=False)
            if result.returncode != 0:
                reason = self._native_failure_summary(result.stdout)
                if reason:
                    return None, (
                        'Moonlight app-status failed (exit %s): %s. '
                        'Kodi was left running.' %
                        (result.returncode, reason.rstrip('.')))
                return None, (
                    'Moonlight app-status failed (exit %s). Sunshine may be '
                    'offline, unpaired, or incompatible with this Luna NG '
                    'binary. Kodi was left running.' % result.returncode)
            lines = [line.strip() for line in result.stdout.splitlines()
                     if line.strip().startswith('LUNA_APP_STATUS_V1 ')]
            if len(lines) != 1:
                return None, 'Sunshine application-state response is missing or ambiguous'
            current = canonical_app_id(lines[0].split(' ', 1)[1])
            return current, None
        except subprocess.TimeoutExpired:
            return None, ('Sunshine did not respond within %g seconds. '
                          'Kodi was left running; check Sunshine and try again.' %
                          timeout_seconds)
        except (OSError, ValueError) as error:
            return None, 'Sunshine application-state check failed: %s' % error

    def _wait_for_ng_app_stopped(self, binary_path, env, app_id, seconds=5.0):
        """After an explicit Quit, wait briefly for Sunshine to finish exiting.

        All polls use one absolute monotonic deadline. A hanging network check
        receives only the remaining budget, and no Kodi video/audio state is
        modified until Sunshine definitively reports that no app is running.
        """
        deadline = time.monotonic() + seconds
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False, 'Sunshine still reports an application running.'
            current, error = self._running_ng_app(
                binary_path, env, app_id,
                timeout_seconds=min(3.0, remaining))
            if error:
                return False, error
            if current == '0':
                return True, None
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False, 'Sunshine still reports an application running.'
            time.sleep(min(0.25, remaining))

    KEEPALIVE = 'audiooutput.streamsilence'

    def _kodi_setting(self, name, value=None):
        from resources.lib.util.kodiaudio import kodi_setting
        return kodi_setting(name, value)

    def _held_nodes(self):
        import subprocess
        held = []
        from resources.lib.util.audiodevices import endpoint_node
        selected = (self.plugin.getSetting('audio_device_parameter') or '')
        endpoint = endpoint_node(selected)
        # Unknown plugins cannot be mapped safely to a physical PCM node.
        nodes = ['/dev/snd/pcmC%dD%dp' % endpoint] if endpoint else []
        for node in nodes:
            try:
                out = subprocess.check_output(['fuser', node],
                                              stderr=subprocess.DEVNULL,
                                              encoding='utf-8', errors='replace', timeout=1)
                if out.strip():
                    held.append(node.rsplit('/', 1)[-1])
            except Exception:
                pass
        return held

    def release_audio(self):
        current = self._kodi_setting(self.KEEPALIVE)
        xbmc.log('LUNA audio: keepalive was %r, nodes held by %s'
                 % (current, self._held_nodes()), xbmc.LOGINFO)
        if current in (None, 0):
            return None

        self.plugin.setSettingString('saved_streamsilence', str(current))
        written = self._kodi_setting(self.KEEPALIVE, 0)
        after = self._kodi_setting(self.KEEPALIVE)
        xbmc.log('LUNA audio: wrote %r, now %r' % (written, after),
                 xbmc.LOGINFO)
        return current

    def wait_audio_free(self, seconds=6):
        import time
        deadline = time.monotonic() + seconds
        while True:
            held = self._held_nodes()
            if not held:
                xbmc.log('LUNA audio: nodes are free', xbmc.LOGINFO)
                return True
            if time.monotonic() >= deadline:
                xbmc.log('LUNA audio: still held: %s' % held, xbmc.LOGERROR)
                return False
            time.sleep(0.3)

    def restore_audio(self, previous):
        if previous is None:
            return
        from resources.lib.util.kodiaudio import restore_saved_streamsilence
        if not restore_saved_streamsilence(self.plugin):
            # A JSON-RPC error or failed readback must retain the previous
            # setting for the next invocation instead of losing the backup.
            xbmc.log('LUNA audio: keepalive restoration pending; backup retained',
                     xbmc.LOGERROR)

    def list_games_detailed(self):
        from resources.lib.util.hostapi import Host

        self.last_host_error = None
        address = getattr(self, '_selected_address', None) or self.config_helper.config.get('host_addr')
        if not address:
            self.last_host_error = 'No Sunshine host is configured.'
            return None

        try:
            apps = self._host(address).applist()
        except Exception as error:
            self.last_host_error = str(error)
            xbmc.log('LUNA applications: %s: %s' % (address, error),
                     xbmc.LOGERROR)
            return None

        result = []
        for app_id, name in apps:
            try:
                art = self._art_if_present(address, app_id)
            except Exception:
                art = None
            result.append((app_id, name, art))
        self._queue_artwork(address, [item[0] for item in result],
                            refresh=getattr(self, '_refresh_artwork', False))
        return result

    def _host_options(self):
        saved = getattr(self, '_artwork_host_options', None)
        if saved is not None:
            return dict(saved)
        saved = getattr(self, '_frozen_host_options', None)
        if saved is None:
            config = getattr(self, 'config_helper', None)
            getter = getattr(config, 'host_options', None)
            options = getter() if callable(getter) else {}
            from resources.lib.util.hostcontext import normalize_options
            saved = normalize_options(options if isinstance(options, dict) else {},
                                      getattr(config, 'binary_path', None))
            self._frozen_host_options = saved
        return dict(saved)

    def _host_identity(self, address):
        from resources.lib.util.hostcontext import host_identity
        return host_identity(address, self._host_options())

    def _host(self, address):
        from resources.lib.util.hostapi import Host, HTTP_PORT, HTTPS_PORT
        from resources.lib.util.hostcontext import default_key_dir
        options = self._host_options()
        port = int(options.get('port', HTTP_PORT))
        return Host(address, http_port=port, inferred_port=True,
                    port=max(1, port + HTTPS_PORT - HTTP_PORT),
                    key_dir=options.get('keydir', default_key_dir()))

    def _queue_artwork(self, address, app_ids, refresh=False):
        import json
        import xbmcvfs
        wanted = [str(value) for value in app_ids
                  if refresh or not self._art_if_present(address, value)]
        if not wanted:
            return
        key = self._host_cache_key(address)
        root = xbmcvfs.translatePath('special://profile/addon_data/script.luna.ng/')
        folder = os.path.join(root, 'artwork-jobs')
        temporary = None
        try:
            from resources.lib.util.safelock import locked_regular_file
            from resources.lib.util.safejson import read_bounded_json
            os.makedirs(folder, exist_ok=True)
            job = os.path.join(folder, key + '.json')
            with locked_regular_file(job + '.lock', timeout=0.1):
                try:
                    previous = read_bounded_json(job, 4 * 1024 * 1024)
                    ids = previous.get('ids') if isinstance(previous, dict) else None
                    if (previous.get('host') == address and isinstance(ids, list)
                            and len(ids) <= 20000 and all(isinstance(value, str)
                                and value.isascii() and value.isdigit() for value in ids)):
                        wanted = list(dict.fromkeys(ids + wanted))
                        refresh = refresh or previous.get('refresh') is True
                except (OSError, ValueError, TypeError, AttributeError):
                    pass
                encoded = json.dumps({'host': address, 'ids': wanted, 'refresh': refresh, 'host_options': self._host_options()})
                if len(encoded.encode('utf-8')) > 4 * 1024 * 1024 or len(wanted) > 20000:
                    return
                with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                        dir=folder, prefix='.queue-', delete=False) as stream:
                    temporary = stream.name
                    stream.write(encoded)
                os.replace(temporary, job)
        except OSError:
            pass
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    def _host_cache_key(self, address):
        return self._host_identity(address) or None

    def cached_games(self, max_age=300):
        self._refresh_artwork = max_age == 0
        import json
        import time
        import xbmcvfs

        self.last_host_error = None
        address = getattr(self, '_selected_address', None) or self.config_helper.config.get('host_addr')
        host_key = self._host_cache_key(address)
        if host_key is None:
            self.last_host_error = 'No Sunshine host is configured.'
            return None

        folder = xbmcvfs.translatePath(
            'special://profile/addon_data/script.luna.ng/')
        path = os.path.join(folder, 'applist-' + host_key + '.json')
        legacy_path = os.path.join(folder, 'applist.json')
        fresh = False
        cached = None
        # Prefer the canonical per-host cache, with a read-only legacy
        # fallback. Never overwrite the old file before folder migration has
        # captured the identity that owns legacy app assignments.
        from resources.lib.util.safejson import read_bounded_json
        from resources.lib.util.library import MAX_APPLIST_BYTES
        from resources.lib.util.appidentity import canonical_app_id
        for candidate in (path, legacy_path):
            try:
                payload, cache_info = read_bounded_json(
                    candidate, MAX_APPLIST_BYTES, with_stat=True)
                age = time.time() - cache_info.st_mtime
                if not isinstance(payload, dict) or payload.get('host') != host_key:
                    continue
                apps = payload.get('apps')
                if isinstance(apps, list) and all(
                        isinstance(item, list) and len(item) == 2 and
                        isinstance(item[0], str) and isinstance(item[1], str)
                        and item[1] and canonical_app_id(item[0]) == item[0]
                        for item in apps):
                    cached = apps
                    fresh = 0 <= age < max_age
                    break
            except (OSError, ValueError, TypeError):
                continue

        def cached_items():
            self._queue_artwork(address, [item[0] for item in cached])
            return [(app_id, name, self._art_if_present(address, app_id))
                    for app_id, name in cached]

        if fresh and cached is not None:
            return cached_items()

        detailed = self.list_games_detailed()
        if detailed is None:
            return cached_items() if cached is not None else None

        # Persist the original cached host's legacy folder assignments before
        # overwriting the only cache that identifies their original owner.
        from resources.lib.util.library import Library
        if not Library(folder, host=address, host_options=self._host_options()).migrate_legacy():
            self.last_host_error = 'Unable to migrate saved folders; application cache not replaced.'
            return detailed

        temporary = None
        try:
            from resources.lib.util.library import MAX_APPLIST_BYTES
            encoded = json.dumps({
                'host': host_key,
                'apps': [[str(a), n] for a, n, _ in detailed],
            }).encode('utf-8')
            # Reader and writer must agree on the 4-MiB byte cap. An unusually
            # large live host list remains usable without replacing a valid
            # existing cached list with unreadable oversized state.
            if len(encoded) > MAX_APPLIST_BYTES:
                return detailed
            os.makedirs(folder, exist_ok=True)
            with tempfile.NamedTemporaryFile(
                    mode='wb', dir=folder,
                    prefix='.applist.', suffix='.tmp', delete=False) as stream:
                temporary = stream.name
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        except (OSError, TypeError, ValueError, UnicodeError):
            pass
        finally:
            if temporary:
                try:
                    os.remove(temporary)
                except OSError:
                    pass
        return detailed

    @staticmethod
    def _complete_artwork(data):
        from resources.lib.util.artwork import valid_artwork
        return valid_artwork(data)

    @classmethod
    def _complete_artwork_file(cls, path, fast_only=False):
        try:
            from resources.lib.util.artwork import valid_artwork
            from resources.lib.util.safefile import read_regular_bytes
            # Never inspect one path and open a potentially replaced FIFO
            # or symlink. Pin bytes, size, and JPEG TTL to one safe inode.
            import json
            import stat
            path = os.fspath(path)
            fingerprint_path = path + '.validated'
            info = os.stat(path, follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode):
                return False
            fingerprint = [info.st_dev, info.st_ino, info.st_size,
                           info.st_mtime_ns, info.st_ctime_ns]
            try:
                raw, _ = read_regular_bytes(fingerprint_path, 1024)
                record = json.loads(raw)
                if (isinstance(record, dict) and record.get('version') == 1 and record.get('file') == fingerprint
                        and (record.get('permanent') is True or
                             (0 <= time.time() - record['validated_at'] < 300
                              and time.time() < record.get('expires', 0)))):
                    current = os.stat(path, follow_symlinks=False)
                    return fingerprint == [current.st_dev, current.st_ino,
                        current.st_size, current.st_mtime_ns, current.st_ctime_ns]
            except (OSError, ValueError, TypeError, KeyError):
                pass
            if fast_only:
                return False  # Background worker owns expensive validation.
            data, info = read_regular_bytes(path, 16 * 1024 * 1024)
            fingerprint = [info.st_dev, info.st_ino, info.st_size,
                           info.st_mtime_ns, info.st_ctime_ns]
            complete = valid_artwork(data, for_cache=True)
            expires = time.time() + 300
            # Without Pillow, reuse a structurally valid JPEG for up to
            # 15 minutes, measured from the SAME descriptor's mtime.
            if not complete and data.startswith(b'\xff\xd8') and valid_artwork(data):
                complete = 0 <= time.time() - info.st_mtime < 900
                expires = min(expires, info.st_mtime + 900)
            if not complete:
                return False
            # Do not hand Kodi the pathname if it was replaced while the
            # bytes were being checked. A later rename is still possible.
            current = os.stat(path, follow_symlinks=False)
            if fingerprint != [current.st_dev, current.st_ino, current.st_size,
                               current.st_mtime_ns, current.st_ctime_ns]:
                return False
            temporary = None
            try:
                with tempfile.NamedTemporaryFile(mode='w', dir=os.path.dirname(path),
                        prefix='.validated-', delete=False) as stream:
                    temporary = stream.name
                    json.dump({'version': 1, 'file': fingerprint,
                               'validated_at': time.time(), 'expires': expires,
                               'permanent': data.startswith(b'\x89PNG\r\n\x1a\n')}, stream)
                os.replace(temporary, fingerprint_path)
            except OSError:
                pass  # Cache metadata must never make usable artwork fail.
            finally:
                if temporary and os.path.exists(temporary):
                    os.unlink(temporary)
            return True
        except (OSError, ValueError):
            return False

    def _art_if_present(self, address, app_id):
        import xbmcvfs
        if not str(app_id).isascii() or not str(app_id).isdigit():
            return None
        key = self._host_cache_key(address)
        if not key:
            return None
        folder = xbmcvfs.translatePath(
            'special://profile/addon_data/script.luna.ng/boxart/')
        path = os.path.join(folder, key, '%s.png' % app_id)
        return path if self._complete_artwork_file(path, fast_only=True) else None

    def boxart_path(self, address, app_id, refresh=False):
        import xbmcvfs
        from resources.lib.util.hostapi import Host

        if not str(app_id).isascii() or not str(app_id).isdigit():
            return None
        key = self._host_cache_key(address)
        if not key:
            return None
        root = xbmcvfs.translatePath(
            'special://profile/addon_data/script.luna.ng/boxart/')
        folder = os.path.join(root, key)
        path = os.path.join(folder, '%s.png' % app_id)
        cached = self._complete_artwork_file(path)
        if cached and not refresh:
            return path

        try:
            data = self._host(address).boxart(app_id)
        except Exception:
            return path if cached and not refresh else None
        if not self._complete_artwork(data) or len(data) > 16 * 1024 * 1024:
            return path if cached and not refresh else None

        temporary = None
        try:
            os.makedirs(folder, exist_ok=True)
            with tempfile.NamedTemporaryFile(
                    mode='wb', dir=folder, prefix='.boxart.',
                    suffix='.tmp', delete=False) as stream:
                temporary = stream.name
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            # Publish validation metadata before the UI observes this download.
            return path if self._complete_artwork_file(path) else None
        except OSError:
            return None
        finally:
            if temporary:
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass

    @contextmanager
    def _native_host_command(self, action, address, snapshot=None):
        owned = None
        try:
            if snapshot is None:
                owned = self.config_helper.create_host_lookup_snapshot(
                    address=address, host_options=self._host_options())
                snapshot = owned
            env = env_with_libs(self.config_helper.binary_path,
                                self.config_helper.addon_path)
            env['LUNA_STREAM_CONFIG'] = snapshot
            command = [self.config_helper.binary_path + 'moonlight', action,
                       '-config', snapshot]
            if action == 'forget-server-cert':
                # Native requires an EXPLICIT positional host to authorize
                # certificate deletion; a snapshot address is insufficient.
                command.append(address)
            yield (command, env)
        finally:
            if owned:
                try:
                    os.unlink(owned)
                except FileNotFoundError:
                    pass

    def quit_game(self, host, snapshot=None):
        if (not isinstance(host, str) or not host.strip() or host.startswith('-') or
                any(char.isspace() for char in host)):
            self.logger.info('[MoonlightHelper] - refusing Quit without a valid host')
            return False
        binary_path = self.config_helper.binary_path
        if not binary_path:
            return False
        try:
            with self._native_host_command('quit', host, snapshot) as (command, env):
                result = subprocess.run(
                    command, cwd=binary_path, env=env,
                    timeout=15, start_new_session=True,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        except (OSError, ValueError, subprocess.TimeoutExpired) as error:
            self.logger.info('[MoonlightHelper] - quit request failed: %s' % error)
            return False
        if result.returncode != 0:
            self.logger.info('[MoonlightHelper] - quit request exited with %s: %s' %
                             (result.returncode, result.stderr.strip()))
            return False
        return True

    def _create_local_report(self):
        """Use the same report/export/error dialog as the manual Luna menu."""
        from resources.lib.util.diagnosticreport import save_report_with_dialog
        from xbmcvfs import translatePath
        profile = translatePath('special://profile/addon_data/script.luna.ng/')
        kodi_log = translatePath('special://logpath/kodi.log')
        legacy_log = os.path.join(self.config_helper.addon_path, 'bin', 'logfile')
        return save_report_with_dialog(
            profile, kodi_log=kodi_log, legacy_log=legacy_log,
            log_failure=lambda kind: self.logger.info(
                '[MoonlightHelper] Local diagnostic save failed: %s' % kind))

    @staticmethod
    def _is_coreelec_ng(binary_path):
        normalized = os.path.normpath(binary_path or '')
        return os.path.basename(normalized) == 'coreelec-ng'

    def _stream_environment(self):
        env = moonlight_environment(self.config_helper)
        # The detached CoreELEC launcher must record which host confirmed
        # stream readiness, not merely the last application name.
        env.pop('LUNA_APP_ID', None)  # Never inherit an earlier app selection.
        env['LUNA_RESUME_CONTEXT'] = self._host_identity(self.config_helper.config.get('host_addr'))
        env['LUNA_RESUME_HOST'] = (self.config_helper.config.get('host_addr')
                                   or self.plugin.getSettingString('host_addr') or '')

        env['MOONLIGHT_STREAM_DIAGNOSTICS'] = (
            '1' if self.plugin.getSettingBool('debug_mode') else '0')
        # Only the detached, watchdog-armed NG launcher may change HDMI.
        env['MOONLIGHT_MATCH_HDMI_MODE'] = (
            '1' if self.plugin.getSettingBool('match_hdmi_mode') else '0')

        if self.plugin.getSettingBool('aml_profile'):
            env['MOONLIGHT_AML_PROFILE'] = '1'
        else:
            env.pop('MOONLIGHT_AML_PROFILE', None)

        if self.plugin.getSettingBool('alsa_resync'):
            env['MOONLIGHT_ALSA_RESYNC'] = '1'
        else:
            env.pop('MOONLIGHT_ALSA_RESYNC', None)

        if self.plugin.getSettingBool('cpu_performance_governor'):
            env['MOONLIGHT_CPU_PERFORMANCE'] = '1'
        else:
            env.pop('MOONLIGHT_CPU_PERFORMANCE', None)

        # Always set an explicit value: an inherited shell variable must
        # never silently override the OFF-by-default Kodi setting.
        env['MOONLIGHT_LATENCY_PRIORITY'] = (
            '1' if self.plugin.getSettingBool('latency_thread_priority') else '0')
        env['MOONLIGHT_RFI_RECOVERY_MS'] = rfi_recovery_timeout(self.plugin)

        for setting, variable in (
                ('input_handoff_probe', 'MOONLIGHT_INPUT_HANDOFF_PROBE'),
                ('input_recovery', 'MOONLIGHT_INPUT_RECOVERY'),
                ('aml_tuning_probe', 'MOONLIGHT_AML_TUNING_PROBE')):
            if self.plugin.getSettingBool(setting):
                env[variable] = '1'
            else:
                env.pop(variable, None)

        frame_pacing = self.plugin.getSettingString('frame_pacing') or 'latency'
        if frame_pacing not in ('latency', 'low-latency', 'adaptive', 'balanced'):
            frame_pacing = 'latency'
        # Pass the same stable device identities used to resolve the startup
        # config. Native Moonlight verifies every opened fd, then uses them
        # again for the initial udev scan and later reconnects.
        from resources.lib.util import inputdevices
        selected = inputdevices.load_selectors(self.plugin)
        env.pop('MOONLIGHT_INPUT_NAMES_HEX', None)
        if selected:
            env['MOONLIGHT_INPUT_SELECTORS_V2'] = inputdevices.encode_selectors(selected)
        else:
            env.pop('MOONLIGHT_INPUT_SELECTORS_V2', None)

        env['MOONLIGHT_FRAME_PACING'] = frame_pacing
        env['MOONLIGHT_TV_GAME_MODE'] = '1' if self.plugin.getSettingBool('tv_game_mode') else '0'

        pipeline = self.plugin.getSettingString('video_pipeline') or 'aml'
        if pipeline not in ('aml', 'aml-vfm'):
            pipeline = 'aml'
        env['MOONLIGHT_VIDEO_PIPELINE'] = pipeline
        env.pop('MOONLIGHT_VFM_ROOT', None)
        if pipeline == 'aml-vfm':
            root = os.path.join(self.config_helper.addon_path, 'vfm')
            env['MOONLIGHT_VFM_ROOT'] = root
            previous = env.get('LD_LIBRARY_PATH', '')
            env['LD_LIBRARY_PATH'] = os.path.join(root, 'lib') + (':' + previous if previous else '')

        env['MOONLIGHT_BINARY'] = self.config_helper.binary_path + 'moonlight'
        return env

    @staticmethod
    def _read_handoff_receipt(ack_path):
        """Pin and validate the actual launcher receipt before reading.

        Never block on a substituted FIFO or follow a symlink during the
        Kodi/systemd handoff. The launcher may atomically replace this path
        between reads; do not cache the pathname's previous metadata.
        """
        import stat
        fd = os.open(ack_path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW |
                     getattr(os, 'O_CLOEXEC', 0))
        with os.fdopen(fd, 'rb') as receipt:
            st = os.fstat(receipt.fileno())
            if (not stat.S_ISREG(st.st_mode) or
                    st.st_uid != os.geteuid() or st.st_nlink != 1 or
                    st.st_size > 64):
                raise OSError('Unsafe Luna launcher acknowledgment')
            value = receipt.read(65)
            if len(value) > 64:
                raise OSError('Oversized Luna launcher acknowledgment')
            try:
                return value.decode('ascii').strip()
            except UnicodeError as error:
                raise OSError('Invalid Luna launcher acknowledgment encoding') from error

    @staticmethod
    def _publish_handoff_observed(ack_path):
        """One-way O_EXCL sidecar. Never mutate the launcher's receipt inode.

        A later launcher-written 'confirmed' receipt is required for success:
        this sidecar alone is NOT proof the launcher accepted the handoff.
        """
        import stat
        path = ack_path + '.observed'
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                         getattr(os, 'O_NOFOLLOW', 0), 0o600)
        except FileExistsError:
            # Never open a possibly substituted FIFO in blocking mode. The
            # receipt is a single owner, single-link file with exact content.
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW |
                         getattr(os, 'O_CLOEXEC', 0))
            with os.fdopen(fd, 'rb') as existing:
                st = os.fstat(existing.fileno())
                if (not stat.S_ISREG(st.st_mode) or
                        st.st_uid != os.geteuid() or st.st_nlink != 1 or
                        st.st_size != len(b'observed\n') or
                        existing.read(len(b'observed\n') + 1) != b'observed\n'):
                    raise OSError('Invalid existing Kodi handoff observation')
            return
        with os.fdopen(fd, 'wb') as proof:
            proof.write(b'observed\n')
            proof.flush()
            os.fsync(proof.fileno())

    @staticmethod
    def _consume_confirmed_handoff(ack_path):
        """Unlink the launcher receipt only after Kodi saw confirmation.

        The detached launcher requires this unlink before stopping Kodi.
        Failure is an unconfirmed handoff, not a successful stream start.
        """
        try:
            os.unlink(ack_path + '.observed')
        except FileNotFoundError:
            pass
        os.unlink(ack_path)

    def _launch_coreelec_ng_service(self, game_id, scripts_path, env):
        # The caller distinguishes failures before submission from an
        # exception after systemd may have accepted the transient unit.
        self._systemd_submit_attempted = False
        systemd_run = '/usr/bin/systemd-run'
        if not os.path.isfile(systemd_run):
            systemd_run = 'systemd-run'

        forwarded = {}
        for key, value in env.items():
            if (key in ('HOME', 'PATH', 'LD_LIBRARY_PATH',
                        'XDG_CACHE_DIR', 'XDG_CONFIG_DIR') or
                    key.startswith('MOONLIGHT_') or key.startswith('LUNA_')):
                forwarded[key] = value

        # Forward only this explicitly supported SDL override, not the
        # Kodi process's full environment.
        mapping = env.get('SDL_GAMECONTROLLERCONFIG')
        if mapping:
            if (not isinstance(mapping, str) or '\x00' in mapping or
                    len(mapping.encode('utf-8')) > 16384):
                return False, 'SDL controller mapping override exceeds 16 KiB or is invalid.'
            forwarded['SDL_GAMECONTROLLERCONFIG'] = mapping

        unit_name = 'luna-ng-session-' + uuid.uuid4().hex[:12]
        unit = unit_name + '.service'
        forwarded['LUNA_SESSION_UNIT'] = unit

        # This receipt is created before submission. The independent launcher
        # writes 'entered' only after it executes and acquires its launch lock;
        # systemd-run --no-block returning 0 proves only that a job was queued.
        snapshot = env.get('LUNA_STREAM_CONFIG')
        ack_path = None
        if snapshot:
            if not os.path.isfile(snapshot):
                return False, 'Private Luna stream configuration is missing.'
            try:
                ack_fd, ack_path = tempfile.mkstemp(
                    prefix='.luna-ack-', suffix='.ack',
                    dir=os.path.dirname(snapshot))
                os.close(ack_fd)
            except OSError as error:
                return False, 'Unable to create Luna launcher acknowledgment: %s' % error
            forwarded['LUNA_LAUNCH_ACK'] = ack_path
            forwarded['LUNA_ACK_REQUIRED'] = '1'

        command = [
            systemd_run,
            '--unit=' + unit_name,
            '--property=TimeoutStopSec=30s',
            '--property=SendSIGKILL=yes',
            '--property=KillMode=control-group',
            '--collect', '--quiet', '--no-block',
            '/usr/bin/env',
        ]
        command.extend('%s=%s' % item for item in sorted(forwarded.items()))
        command.extend([scripts_path + 'launch.sh', game_id])

        retain_ack = False
        submit_started = time.monotonic()
        try:
            try:
                self._systemd_submit_attempted = True
                result = subprocess.run(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    encoding='utf-8',
                    errors='replace',
                    timeout=10,
                    check=False)
            except subprocess.TimeoutExpired:
                # A timed-out CLI may still have queued the unit. Do not
                # delete the stream configuration before stopping it.
                result = None
            except OSError as error:
                # Popen failed before the subprocess could be launched.
                self._systemd_submit_attempted = False
                xbmc.log('LUNA NG systemd handoff failed: %s' % error,
                         xbmc.LOGERROR)
                return False, str(error)

            xbmc.log(
                'LUNA_LAUNCH_TIMING_V1 source=kodi stage=systemd-submit elapsed_ms=%d' %
                max(0, round((time.monotonic() - submit_started) * 1000)),
                xbmc.LOGINFO)
            if result is not None and result.returncode != 0:
                message = (result.stdout or '').strip()
                xbmc.log('LUNA NG systemd handoff failed (%d): %s'
                         % (result.returncode, message), xbmc.LOGERROR)
                return False, message or 'Unable to queue Luna NG session.'

            if not ack_path:
                # Compatibility for callers that do not request a detached
                # session snapshot. The normal CoreELEC NG path always does.
                return True, None

            start = time.monotonic()
            deadline = start + LUNA_NG_ACK_WAIT_SECONDS
            final_deadline = start + LUNA_NG_RECOVERY_MAX_SECONDS
            last_step = None
            reconciling = False
            observation_requested = False
            while time.monotonic() <= deadline:
                try:
                    phase = self._read_handoff_receipt(ack_path)
                    if phase == 'armed':
                        # The launcher owns the receipt; this sidecar cannot
                        # overwrite a concurrent 'failed' or 'confirmed'.
                        try:
                            self._publish_handoff_observed(ack_path)
                        except OSError as error:
                            retain_ack = True
                            return None, ('Cannot confirm Luna handoff: %s. '
                                          'The detached unit retains ownership.'
                                          % error)
                        if not observation_requested:
                            observation_requested = True
                            deadline = min(
                                time.monotonic() + LUNA_NG_ACK_WAIT_SECONDS,
                                final_deadline)
                    if phase == 'confirmed':
                        # The launcher must wait until Kodi has consumed its
                        # confirmed receipt before stopping Kodi.
                        try:
                            self._consume_confirmed_handoff(ack_path)
                        except OSError as error:
                            retain_ack = True
                            return None, ('Luna confirmation was received but '
                                          'could not be consumed: %s. '
                                          'Kodi remains in control.' % error)
                        xbmc.log(
                            'LUNA_LAUNCH_TIMING_V1 source=kodi stage=handoff-ack elapsed_ms=%d' %
                            max(0, round((time.monotonic() - start) * 1000)),
                            xbmc.LOGINFO)
                        return True, None
                    if phase == 'failed:kodi-state':
                        return False, ('Luna could not verify Kodi\'s service state. '
                                       'Kodi was left unchanged. See the system journal '
                                       'for the service-query error.')
                    if phase == 'failed':
                        return False, ('Luna launcher exited before recovery '
                                       'was armed. Kodi was left running.')
                    if re.fullmatch(r'reconciling:[1-9][0-9]{0,3}', phase):
                        reconciling = True
                        if phase != last_step:
                            last_step = phase
                            deadline = min(
                                time.monotonic() + recovery_step_seconds(env),
                                final_deadline)
                except OSError:
                    pass
                time.sleep(0.1)

            if reconciling:
                # Leaving the wait loop withdraws permission to stop Kodi.
                # Do not interrupt the older recovery, but explicitly cancel
                # this new stream request so a late arm cannot succeed.
                try:
                    latest = self._read_handoff_receipt(ack_path)
                    if latest == 'confirmed':
                        try:
                            self._consume_confirmed_handoff(ack_path)
                        except OSError as error:
                            retain_ack = True
                            return None, (
                                'Luna confirmation could not be consumed: '
                                '%s. Kodi remains in control.' % error)
                        return True, None
                    if latest == 'armed':
                        # A late arm can arrive just as the previous
                        # recovery deadline expires. Only the launcher
                        # can confirm it, and only Kodi's consumption of
                        # that confirmation authorizes stopping Kodi.
                        self._publish_handoff_observed(ack_path)
                        confirm_until = (time.monotonic() +
                                         LUNA_NG_ACK_WAIT_SECONDS)
                        while time.monotonic() <= confirm_until:
                            try:
                                confirmed = self._read_handoff_receipt(ack_path)
                            except OSError:
                                break
                            if confirmed == 'confirmed':
                                try:
                                    self._consume_confirmed_handoff(ack_path)
                                except OSError as error:
                                    retain_ack = True
                                    return None, (
                                        'Luna confirmation could not be consumed: '
                                        '%s. Kodi remains in control.' % error)
                                return True, None
                            if confirmed == 'failed:kodi-state':
                                return False, (
                                    "Luna could not verify Kodi's service state. "
                                    "Kodi was left unchanged.")
                            if confirmed == 'failed':
                                return False, (
                                    'Luna launcher rejected the late handoff '
                                    'without stopping Kodi.')
                            if confirmed == 'abandoned':
                                break
                            time.sleep(0.1)
                        # No confirmation was consumed. The detached
                        # launcher will also refuse to stop Kodi unless
                        # Kodi removes its confirmed receipt. Its owner
                        # cleans any retained files after safe recovery.
                        retain_ack = True
                        return None, ('Luna handoff was observed but its '
                                      'launcher confirmation is pending. '
                                      'The detached unit retains ownership.')
                    if latest == 'failed:kodi-state':
                        return False, ('Luna could not verify Kodi\'s service state. '
                                       'Kodi was left unchanged. See the system journal '
                                       'for the service-query error.')
                    if latest == 'failed':
                        return False, ('Luna launcher rejected the new handoff '
                                       'without stopping Kodi.')
                    # A sidecar is never replaced by the launcher's
                    # atomic reconciling/armed receipt updates.
                    abandoned_fd = os.open(
                        ack_path + '.abandoned',
                        os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                        0o600)
                    with os.fdopen(abandoned_fd, 'w', encoding='ascii') as marker:
                        marker.write('abandoned\n')
                        marker.flush()
                        os.fsync(marker.fileno())
                    # The launcher owns the main receipt and may replace
                    # its inode atomically. Its O_EXCL .abandoned sidecar
                    # is authoritative; never write to a stale inode.
                except OSError as error:
                    xbmc.log('LUNA NG cannot publish handoff abandonment: %s' %
                             error, xbmc.LOGERROR)
                retain_ack = True
                return None, ('Earlier recovery continues, but this new handoff '
                              'was abandoned before Kodi stopped. '
                              'Retry after recovery finishes.')

            # Missing acknowledgment: cancel ONLY the unique transient unit.
            # This is not proof of failure until systemd confirms it stopped.
            control = env.get('LUNA_SYSTEMCTL') or 'systemctl'
            try:
                stopped = subprocess.run(
                    [control, 'stop', unit],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    timeout=10, check=False)
                state = subprocess.run(
                    [control, 'show', '--property=ActiveState', '--value', unit],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    encoding='utf-8', errors='replace', timeout=5, check=False)
                if (stopped.returncode == 0 and state.returncode == 0 and
                        state.stdout.strip() in ('inactive', 'failed')):
                    return False, ('Luna service did not acknowledge startup; '
                                   'the transient unit was stopped without '
                                   'taking Kodi away.')
            except (OSError, subprocess.TimeoutExpired) as error:
                xbmc.log('LUNA NG cannot confirm failed service startup: %s'
                         % error, xbmc.LOGERROR)

            # When the service state cannot be confirmed, the launcher may
            # still arrive late. Keep its snapshot/receipt for that process.
            retain_ack = True
            return None, ('Luna launch was submitted but not acknowledged. '
                          'Could not confirm the service stopped; its private '
                          'configuration was retained for safe recovery.')
        except Exception as error:
            # An unexpected error while observing a queued session is NOT
            # evidence that systemd declined it. Preserve its snapshot and
            # receipt; the detached launcher/independent watchdog owns cleanup.
            xbmc.log('LUNA NG handoff exception: %s' %
                     type(error).__name__, xbmc.LOGERROR)
            if self._systemd_submit_attempted:
                retain_ack = True
                return None, ('Luna handoff could not be confirmed after submission. '
                              'Its detached unit retains recovery ownership.')
            return False, ('Luna handoff failed before submission: %s' %
                           type(error).__name__)
        finally:
            if ack_path and not retain_ack:
                # Kodi already consumed confirmation on success; for
                # failed/early returns, unlink any remaining one-shot files.
                # Uncertain handoffs stay launcher-owned.
                for owned_path in (ack_path + '.observed', ack_path):
                    try:
                        os.unlink(owned_path)
                    except OSError:
                        pass

    @staticmethod
    def _capture_kodi_playback(player):
        """Record the current item before Kodi is interrupted for a launch.

        Never infer a playable URL from a title or alter playlist state.
        Unavailable metadata means there is nothing safe to restore.
        """
        try:
            uri = player.getPlayingFile()
            if not isinstance(uri, str) or not uri.strip():
                return None
            try:
                position = float(player.getTime())
                if not (0 <= position < float('inf')):
                    position = 0.0
            except (OSError, RuntimeError, TypeError, ValueError):
                position = 0.0
            try:
                item = player.getPlayingItem()
            except (OSError, RuntimeError, AttributeError):
                item = None
            paused = False
            try:
                paused = xbmc.getCondVisibility('Player.Paused') is True
            except (AttributeError, RuntimeError):
                pass
            return uri, position, item, paused
        except (OSError, RuntimeError, AttributeError):
            return None

    @staticmethod
    def _restore_kodi_playback(player, previous):
        """Best-effort restore only for a definitively rejected handoff.

        Never restart on an uncertain handoff: the native session may
        legitimately acquire the display after Python returns.
        """
        if previous is None:
            return False
        uri, position, item = previous[:3]
        paused = len(previous) > 3 and previous[3] is True
        try:
            # Do not replace another item the user started in the meantime.
            if player.isPlaying():
                return False
            if item is None:
                player.play(uri)
            else:
                player.play(uri, listitem=item)
            if position > 0.0 or paused:
                # Never hold up the launch-failure dialog for delayed SMB or
                # Jellyfin playback. A Kodi AlarmClock re-enters a tiny
                # token-verified plugin action after this invocation returns.
                ready = player.isPlaying()
                opened = None
                if ready:
                    try:
                        opened = player.getPlayingFile()
                    except (OSError, RuntimeError, AttributeError):
                        pass
                if ready and opened == uri:
                    if position > 0:
                        player.seekTime(position)
                    if paused and not xbmc.getCondVisibility('Player.Paused'):
                        player.pause()
                elif ready and opened:
                    xbmc.log('LUNA NG another item started; not restoring its seek',
                             xbmc.LOGINFO)
                else:
                    from resources.lib.util.kodirestore import schedule_seek
                    try:
                        schedule_seek(uri, position, paused=paused)
                    except (OSError, RuntimeError, ValueError) as error:
                        xbmc.log('LUNA NG deferred seek unavailable: %s' %
                                 type(error).__name__, xbmc.LOGINFO)
            return True
        except (OSError, RuntimeError, TypeError, ValueError) as error:
            xbmc.log('LUNA NG could not restore interrupted Kodi playback: %s'
                     % error, xbmc.LOGERROR)
            return False

    def _begin_local_stream_transition(self, player, show_intro, resume_mode):
        """Only disrupt Kodi playback after remote preflight and confirmation."""
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.executebuiltin("Dialog.Close(notification)")
        xbmc.executebuiltin("InhibitScreensaver(true)")
        previous = None
        if player.isPlaying():
            previous = self._capture_kodi_playback(player)
            self._transition_playback = previous
            player.stop()
            deadline = time.time() + 5
            while player.isPlaying() and time.time() < deadline:
                time.sleep(0.1)
        if show_intro and not resume_mode:
            player.play(self.config_helper.addon_path + 'resources/statics/loading.mp4')
            time.sleep(10)
            player.stop()
        return previous

    def launch_game(self, game_id, resume=False, app_id=None, expected_host=None):
        # Timing is observational only. Never skip, cache, or reorder checks.
        launch_started = launch_previous = time.monotonic()

        def launch_mark(stage):
            nonlocal launch_previous
            now = time.monotonic()
            try:
                xbmc.log(
                    'LUNA_LAUNCH_TIMING_V1 source=kodi stage=%s step_ms=%d total_ms=%d' %
                    (stage, max(0, round((now - launch_previous) * 1000)),
                     max(0, round((now - launch_started) * 1000))),
                    xbmc.LOGINFO)
            except (OSError, RuntimeError):
                pass  # A diagnostic cannot block an otherwise valid launch.
            launch_previous = now

        # Sunshine titles can collide; only an explicit validated ID selects
        # a precise app. Older callers retain name-based launching.
        if app_id is not None:
            from resources.lib.util.appidentity import canonical_app_id
            try:
                app_id = canonical_app_id(app_id)
            except ValueError:
                xbmcgui.Dialog().ok('Invalid Sunshine application',
                                    'The selected application has an invalid ID.')
                return
        from resources.lib.util import inputdevices
        try:
            self.config_helper.configure()
            self._frozen_host_options = getattr(self.config_helper, '_launch_host_options', None)
            self._host_options()
        except inputdevices.InputPathLimitExceeded as error:
            xbmcgui.Dialog().ok('Too many selected input devices', str(error))
            return

        launch_mark('configuration')
        from resources.lib.util.resumestate import host_identity
        if expected_host is not None and expected_host != self._host_identity(
                self.config_helper.config.get('host_addr')):
            xbmcgui.Dialog().ok('Sunshine host changed', 'Reopen its application list.')
            return

        binary_path = self.config_helper.binary_path
        scripts_path = self.config_helper.launchscripts_path
        if not binary_path:
            message = ('Moonlight executable was not found or failed architecture validation. '
                       'Check the Kodi log for each candidate path and ELF class.')
            xbmc.log('LUNA NG launch aborted: %s (addon=%s)' %
                     (message, self.config_helper.addon_path), xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Luna NG executable unavailable', message)
            return

        # The CoreELEC launcher stops Kodi and needs the bundled NG runtime's
        # independent systemd service and readiness protocol. A detached child
        # process still belongs to Kodi's cgroup and cannot safely own it.
        if (os.path.basename(os.path.normpath(scripts_path)) == 'coreelec' and
                os.path.abspath(binary_path) != os.path.join(
                    os.path.abspath(self.config_helper.addon_path),
                    'bin', 'coreelec-ng')):
            xbmcgui.Dialog().ok(
                'Unsupported CoreELEC streaming executable',
                'CoreELEC streaming requires Luna\'s bundled NG executable. '
                'Install the matching Luna NG bundle. External executables '
                'can only be used for host management.')
            return

        # Check installed ELF hashes and run Moonlight's help action while
        # Kodi is still responsive. A missing library must not freeze the TV.
        try:
            from resources.lib.util.runtimecheck import (
                check_ng_runtime, NativeRuntimeError)
            env = self._stream_environment()
            check_ng_runtime(
                self.config_helper.addon_path, binary_path + 'moonlight', env,
                on_timing=lambda stage, step, total: xbmc.log(
                    'LUNA_LAUNCH_TIMING_V1 source=runtime stage=%s '
                    'step_ms=%d total_ms=%d' % (stage, step, total),
                    xbmc.LOGINFO))
        except NativeRuntimeError as error:
            xbmc.log('LUNA NG runtime preflight: %s' % error, xbmc.LOGERROR)
            xbmcgui.Dialog().ok(
                'Luna NG runtime check failed',
                str(error))
            return
        except Exception:
            xbmc.log('LUNA NG unexpected runtime preflight exception:\n%s' %
                     traceback.format_exc(), xbmc.LOGERROR)
            xbmcgui.Dialog().ok(
                'Luna NG runtime check failed',
                'Unable to verify Moonlight before launch. See the Kodi log.')
            return

        launch_mark('runtime-validation')
        if app_id is not None and self._is_coreelec_ng(binary_path):
            env['LUNA_APP_ID'] = app_id
        if env['MOONLIGHT_VIDEO_PIPELINE'] == 'aml-vfm':
            from resources.lib.util.vfmruntime import check_runtime, VfmRuntimeError
            try:
                if (not self._is_coreelec_ng(binary_path) or
                        os.path.basename(os.path.normpath(scripts_path)) != 'coreelec'):
                    raise VfmRuntimeError('The prototype requires the CoreELEC NG launcher.')
                check_runtime(self.config_helper.addon_path, binary_path + 'moonlight', env)
            except VfmRuntimeError as error:
                xbmcgui.Dialog().ok('Experimental video pipeline unavailable', str(error))
                return

        launch_mark('backend-validation')
        player = xbmc.Player()
        isResumeMode = bool(resume)
        showIntro = self.plugin.getSettingBool('show_intro')
        codec = self.config_helper.config['codec']

        keepalive = None
        t0 = None
        local_transition_started = False
        audio_suspended = False
        legacy_restore = None
        self._transition_playback = None
        handoff_submitted = False
        try:
            if self._is_coreelec_ng(binary_path):
                snapshot = None
                stale_snapshot = None
                try:
                    # Do not read shared moonlight.conf again after
                    # preflight: another Kodi action may change it while
                    # systemd is starting the detached session.
                    try:
                        snapshot = self.config_helper.create_launch_snapshot()
                    except ValueError as error:
                        xbmcgui.Dialog().ok(
                            'Luna NG launch snapshot rejected', str(error))
                        return
                    # Keep Quit bound to the exact host captured by this
                    # immutable snapshot, even if another UI action changes
                    # the currently selected host while preflight runs.
                    session_host = self.config_helper.config.get('host_addr') or ''
                    env['LUNA_STREAM_CONFIG'] = snapshot
                    launch_mark('launch-snapshot')

                    # Resolve legacy name-based calls to exactly one host ID.
                    # A name that is ambiguous must not resume another app.
                    if app_id is None:
                        apps = self.list_games_native_detailed(snapshot=snapshot)
                        if apps is None:
                            xbmcgui.Dialog().ok(
                                'Luna NG application selection',
                                self.last_host_error or
                                'Could not retrieve Sunshine application IDs.')
                            return
                        matches = [(id_value, title) for id_value, title, _ in apps
                                   if title == game_id]
                        if len(matches) != 1:
                            xbmcgui.Dialog().ok(
                                'Luna NG application selection',
                                'Could not establish one exact Sunshine app ID '
                                'for this name. Refresh the application list.')
                            return
                        app_id = matches[0][0]
                        env['LUNA_APP_ID'] = app_id
                        launch_mark('app-id-lookup')

                    # One native paired-host serverinfo check handles both
                    # availability and running-app conflicts. Do not run a
                    # redundant 'moonlight list' before this app-status call.
                    current, status_error = self._running_ng_app(
                        binary_path, env, app_id)
                    launch_mark('sunshine-app-status')
                    if status_error:
                        xbmc.log('LUNA NG Sunshine preflight failed: %s' %
                                 status_error, xbmc.LOGERROR)
                        xbmcgui.Dialog().ok('Luna NG host unavailable', status_error)
                        return

                    replace_running = False
                    if current != '0' and current != app_id:
                        choice = self._ng_conflict_choice(current, game_id)
                        if choice == 1:
                            # Resume the app the host really has running; an
                            # exact ID prevents a same-title collision.
                            apps = self.list_games_native_detailed(snapshot=snapshot)
                            title = next((name for ident, name, _ in (apps or [])
                                          if ident == current),
                                         'Running application (ID %s)' % current)
                            game_id = title
                            app_id = current
                            env['LUNA_APP_ID'] = current
                            isResumeMode = True
                        elif choice == 2:
                            replace_running = True
                        else:
                            return  # Cancel must not alter the remote session.

                    # The final resolved Sunshine app ID matters: Resume or
                    # conflict resolution may target a DIFFERENT running app
                    # than the one the user originally selected. Apply only
                    # that app's saved mode, without touching global settings.
                    from resources.lib.util.streamprofiles import StreamProfiles
                    from xbmcvfs import translatePath
                    try:
                        store = StreamProfiles(
                            translatePath('special://profile/addon_data/script.luna.ng/'),
                            session_host, host_options=self._host_options())
                        selected_profile = store.get(app_id)
                        if selected_profile is not None:
                            personalized = self.config_helper.create_launch_snapshot(
                                stream_profile=selected_profile)
                            # The original host-bound preflight snapshot is
                            # no longer needed. Keep the new snapshot private
                            # and immutable for Moonlight AND HDMI matching.
                            stale_snapshot = snapshot
                            snapshot = personalized
                            env['LUNA_STREAM_CONFIG'] = snapshot
                    except (OSError, ValueError) as error:
                        xbmc.log('LUNA NG stream profile: %s' % error,
                                 xbmc.LOGERROR)
                        xbmcgui.Dialog().ok(
                            'Streaming profile unavailable',
                            'Unable to load the saved profile for this app. '
                            'Kodi was left running. %s' % error)
                        return

                    from resources.lib.util.runtimecheck import check_stream_geometry
                    try:
                        check_stream_geometry(snapshot, env.get('MOONLIGHT_VIDEO_PIPELINE'))
                    except ValueError as error:
                        xbmcgui.Dialog().ok('Unsupported streaming profile', str(error))
                        return

                    launch_mark('stream-profile')
                    # Validate the EFFECTIVE per-app resolution/FPS while Kodi
                    # still has the display. The detached launcher verifies
                    # the same snapshot again after handoff.
                    if env.get('MOONLIGHT_MATCH_HDMI_MODE') == '1':
                        from resources.lib.util import hdmimode
                        try:
                            hdmimode.check(snapshot)
                            launch_mark('hdmi-preflight')
                        except (OSError, ValueError) as error:
                            xbmc.log('LUNA HDMI matching preflight failed: %s' %
                                     error, xbmc.LOGERROR)
                            # Only profile modes with NO CoreELEC exact HDMI
                            # representation (for example 1440p or 90 FPS)
                            # may deliberately keep the current TV output.
                            # Never bypass an unsafe EDID/readback/recovery
                            # condition on a nominally supported HDMI mode.
                            unsupported_profile = (
                                isinstance(error, hdmimode.HdmiModeUnavailable)
                                and hdmimode.profile_needs_unmatched_hdmi_output(snapshot))
                            if unsupported_profile:
                                consent = xbmcgui.Dialog().yesno(
                                    'HDMI output mode unavailable',
                                    str(error) + '\n\nKeep the TV at its current HDMI '
                                    'mode and stream this session without matching?',
                                    nolabel='Cancel launch',
                                    yeslabel='Stream without matching')
                                if consent:
                                    env['MOONLIGHT_MATCH_HDMI_MODE'] = '0'
                                    xbmc.log(
                                        'LUNA HDMI matching bypassed by explicit '
                                        'consent for this session only',
                                        xbmc.LOGINFO)
                                else:
                                    return
                            else:
                                xbmcgui.Dialog().ok(
                                    'HDMI output mode unavailable', str(error))
                                return

                    if replace_running:
                        if not self.quit_game(session_host, snapshot=snapshot):
                            xbmcgui.Dialog().ok(
                                'Luna NG launch cancelled',
                                'Unable to quit the existing Sunshine application.')
                            return
                        # Sunshine can acknowledge Quit before the process has
                        # finished closing. Avoid a false cancellation, but
                        # never begin local Kodi handoff without verified idle.
                        stopped, stop_error = self._wait_for_ng_app_stopped(
                            binary_path, env, app_id)
                        if not stopped:
                            xbmcgui.Dialog().ok(
                                'Luna NG launch cancelled',
                                stop_error or
                                'Sunshine still reports an application running.')
                            return
                        launch_mark('remote-app-replace')

                    # No local Kodi playback/intro is stopped or started until
                    # the remote app is validated and the user's decision made.
                    local_transition_started = True
                    previous_kodi_playback = self._begin_local_stream_transition(
                        player, showIntro, isResumeMode)
                    launch_mark('local-transition')
                    handoff_submitted = True
                    self._systemd_submit_attempted = False
                    try:
                        launched, error = self._launch_coreelec_ng_service(
                            game_id, scripts_path, env)
                    except Exception as unexpected:
                        xbmc.log('LUNA NG handoff classification failed: %s' %
                                 type(unexpected).__name__, xbmc.LOGERROR)
                        if self._systemd_submit_attempted:
                            launched = None
                            error = ('Systemd submission may have succeeded. '
                                     'The detached session retains recovery ownership.')
                        else:
                            launched = False
                            error = ('Systemd handoff failed before submission; '
                                     'Kodi retains display ownership.')
                    launch_mark('systemd-handoff')
                    if launched is False:
                        # A definitive rejection leaves Kodi as display
                        # owner. Recover the playback that the transition
                        # interrupted, but never restart on an uncertain
                        # or successful handoff.
                        self._restore_kodi_playback(player, previous_kodi_playback)
                        xbmcgui.Dialog().ok(
                            'Luna NG launch failed',
                            error or 'Unable to hand the session to systemd.')
                    elif launched is None:
                        # A queued unit with uncertain ownership must keep
                        # the snapshot until it is safely retired.
                        snapshot = None
                        xbmcgui.Dialog().ok(
                            'Luna NG launch status unconfirmed', error)
                    else:
                        # The independent session owns deleting this snapshot.
                        snapshot = None
                    return
                finally:
                    # The base preflight snapshot must not leak after creating
                    # an app-specific copy, even when the detached session
                    # assumes ownership of the new one.
                    if stale_snapshot:
                        try:
                            os.unlink(stale_snapshot)
                        except OSError:
                            pass
                    if snapshot:
                        try:
                            os.unlink(snapshot)
                        except OSError:
                            pass

            local_transition_started = True
            legacy_restore = self._begin_local_stream_transition(player, showIntro, isResumeMode)
            keepalive = self.release_audio()
            xbmc.audioSuspend()
            audio_suspended = True

            free = self.wait_audio_free(2)
            if not free:
                xbmc.log('LUNA audio: node taken again, retrying',
                         xbmc.LOGINFO)
                xbmc.audioSuspend()
                free = self.wait_audio_free()

            if not free:
                held = ', '.join(self._held_nodes())
                xbmc.log('LUNA audio: launch cancelled, held by %s' % held,
                         xbmc.LOGERROR)
                xbmcgui.Dialog().ok(self.plugin.getLocalizedString(30037),
                                    self.plugin.getLocalizedString(30268))
                return

            t0 = time.monotonic()
            subprocess.run([scripts_path + 'prescript.sh', binary_path, codec], cwd=scripts_path, start_new_session=True)
            env = self._stream_environment()
            launch_cmd = subprocess.Popen([scripts_path + 'launch.sh', game_id], cwd=binary_path, env=env, start_new_session=True)
            legacy_restore = None  # The launched process now owns the transition.
            launch_status = launch_cmd.wait()
            if launch_status == 0 and not isResumeMode:
                from resources.lib.util.resumestate import host_identity
                self.plugin.setSettingString('last_run', game_id)
                self.plugin.setSettingString('last_run_id',
                                             app_id if self._is_coreelec_ng(binary_path)
                                             and app_id is not None else '')
                self.plugin.setSettingString('last_run_host', host_identity(
                    self.config_helper.config.get('host_addr')
                    or self.plugin.getSettingString('host_addr')))
            subprocess.run([scripts_path + 'postscript.sh', binary_path], cwd=scripts_path, start_new_session=True)

        except Exception:
            if not handoff_submitted:
                self._restore_kodi_playback(player, self._transition_playback)
            xbmc.log('LUNA NG launch exception:\n%s' % traceback.format_exc(),
                     xbmc.LOGERROR)
            xbmcgui.Dialog().ok(
                'Luna NG launch failed',
                'Moonlight could not be launched. See the Kodi log for the error details.')
        finally:
            if audio_suspended:
                xbmc.audioResume()
            self.restore_audio(keepalive)
            if legacy_restore is not None:
                self._restore_kodi_playback(player, legacy_restore)
            if local_transition_started:
                xbmc.executebuiltin("InhibitScreensaver(false)")

            if t0 is None:
                pass
            elif time.monotonic() - t0 < 10:
                result = xbmcgui.Dialog().yesno(
                    "", self.plugin.getLocalizedString(30288) or
                    'Moonlight exited unexpectedly. Save a local diagnostic '
                    'report? Nothing will be uploaded.')
                if result:
                    self._create_local_report()
            else:
                xbmcgui.Dialog().notification(
                    self.plugin.getLocalizedString(30290),
                    self.plugin.getLocalizedString(30291) % game_id,
                    xbmcgui.NOTIFICATION_INFO, False)
