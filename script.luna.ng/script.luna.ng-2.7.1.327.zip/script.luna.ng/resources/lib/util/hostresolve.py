"""Bound DNS resolution outside Kodi's interpreter, retaining TLS host identity."""
import json
import socket
import subprocess
import time

_cache = {}
_RESOLVE = ('import socket,json,sys; '
            'print(json.dumps(socket.getaddrinfo(sys.argv[1],int(sys.argv[2]),'
            'type=socket.SOCK_STREAM)))')


def socket_host(address):
    """Native-compatible transport host, without rewriting pin/host identity.

    URI authorities may include IPv6 brackets or RFC 6874 %25 zone escapes.
    getaddrinfo instead expects the bare IPv6 address and raw '%' zone.
    Keep the caller's host intact for certificate lookup and HTTPS identity.
    """
    if not isinstance(address, str) or not address or len(address) > 255:
        raise ValueError('Invalid Sunshine socket host')
    bracketed = address.startswith('[')
    if bracketed:
        if not address.endswith(']'):
            raise ValueError('Incomplete IPv6 host brackets')
        value = address[1:-1]
    else:
        value = address
    if ':' not in value:
        if bracketed or ']' in value:
            raise ValueError('Invalid socket host brackets')
        return value
    bare, separator, zone = value.partition('%')
    try:
        socket.inet_pton(socket.AF_INET6, bare)
    except OSError as error:
        raise ValueError('Invalid IPv6 Sunshine host') from error
    if separator:
        if zone.startswith('25'):
            zone = zone[2:]  # URI zone escape: %25eth0 -> %eth0
        if (not zone or '%' in zone or
                any(not (char.isascii() and
                         (char.isalnum() or char in '._~-'))
                    for char in zone)):
            raise ValueError('Invalid IPv6 Sunshine scope')
        return bare + '%' + zone
    return bare


def connect(address, timeout=4, source_address=None):
    """Use one total connection budget, refreshing cached DNS once on failure.

    A host which moved to another IP during the 60-second cache period
    should reconnect without requiring a second Kodi action. Cached-address
    attempts use at most half of the deadline, reserving time for a fresh DNS
    query and a new connection. Never loop indefinitely on a stale address.
    """
    host, port = address
    resolved_host = socket_host(host)
    deadline = time.monotonic() + timeout
    key = (host, port)
    cached = _cache.get(key)
    used_cache = bool(cached and time.monotonic() < cached[0])

    def resolve():
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise socket.timeout('Sunshine address resolution deadline expired')
        try:
            result = subprocess.run(
                ['python3', '-c', _RESOLVE, resolved_host, str(port)],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, timeout=remaining, check=True)
            records = json.loads(result.stdout)
            if not isinstance(records, list) or not records:
                raise ValueError('No Sunshine socket addresses')
        except (subprocess.SubprocessError, ValueError) as error:
            raise socket.timeout(
                'Sunshine address resolution failed or timed out') from error
        if len(_cache) >= 128:
            _cache.clear()
        _cache[key] = (time.monotonic() + 60, records)
        return records

    results = cached[1] if used_cache else resolve()
    last_error = socket.timeout('Sunshine connection deadline expired')
    for attempt in range(2 if used_cache else 1):
        for index, (family, kind, protocol, _, target) in enumerate(results):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            sock = None
            try:
                sock = socket.socket(family, kind, protocol)
                # Reserve half of the remaining budget for a fresh resolver
                # only when trying stale, cached addresses.
                per_address = remaining / (len(results) - index)
                if attempt == 0 and used_cache:
                    per_address /= 2
                sock.settimeout(per_address)
                if source_address:
                    sock.bind(source_address)
                sock.connect(tuple(target))
                sock.settimeout(timeout)  # TLS/HTTP deadline is owned by caller.
                return sock
            except OSError as error:
                last_error = error
                if sock is not None:
                    sock.close()
        if attempt == 0 and used_cache and deadline - time.monotonic() > 0:
            _cache.pop(key, None)
            results = resolve()
            continue
        break
    _cache.pop(key, None)
    raise last_error
