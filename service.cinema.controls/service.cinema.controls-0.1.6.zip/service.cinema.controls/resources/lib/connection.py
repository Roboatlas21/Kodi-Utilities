"""Read-only reuse of Jellyfin for Kodi's saved connection."""
import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field


class ApiError(Exception):
    def __init__(self, code, status=0):
        super().__init__(code)
        self.code, self.status = code, status


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


@dataclass(frozen=True)
class Connection:
    address: str
    user: str
    server: str
    device: str
    token: str = field(repr=False)
    version: str = ""
    device_name: str = ""

    @property
    def key(self):
        return hashlib.sha256((self.address + self.user + self.device + self.token).encode()).hexdigest()


def connections(profile, device, version="", device_name=""):
    # Never import the upstream client: doing so could start another session.
    with open(profile + "/data.json", encoding="utf-8") as stream:
        data = json.load(stream)
    result = []
    for server in data.get("Servers", []):
        address = (server.get("address") or "").rstrip("/")
        parsed = urllib.parse.urlsplit(address)
        if (parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username
                or parsed.password or parsed.query or parsed.fragment):
            continue
        if server.get("AccessToken") and server.get("UserId") and device:
            result.append(Connection(address, server["UserId"], server.get("Id", ""), device, server["AccessToken"], version, device_name))
    return result


def choose_connection(candidates, playing_file):
    parsed = urllib.parse.urlsplit(playing_file.split("|", 1)[0])
    if parsed.scheme in ("http", "https"):
        matches = []
        for c in candidates:
            base = urllib.parse.urlsplit(c.address)
            if (parsed.scheme, parsed.netloc) == (base.scheme, base.netloc) and (
                    not base.path or parsed.path.startswith(base.path.rstrip("/") + "/")):
                matches.append(c)
        return matches[0] if len(matches) == 1 else None
    return candidates[0] if len(candidates) == 1 else None


class Api:
    def __init__(self, connection):
        self.connection = connection
        self.opener = urllib.request.build_opener(NoRedirect())

    def call(self, route, data=None, timeout=8, jellyfin=False):
        c = self.connection
        url = c.address + ("/" if jellyfin else "/JellyTrailer/Kodi/") + route
        # Token belongs to the existing playback client; never create or stop a session.
        auth = 'MediaBrowser Client="Kodi", Device={}, DeviceId={}, Version={}, Token={}'.format(
            json.dumps(c.device_name), json.dumps(c.device), json.dumps(c.version), json.dumps(c.token))
        req = urllib.request.Request(url, data=None if data is None else json.dumps(data).encode(),
                                     headers={"Authorization": auth, "Accept": "application/json", "Content-Type": "application/json"})
        try:
            with self.opener.open(req, timeout=timeout) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
                if len(raw) > 2 * 1024 * 1024:
                    raise ApiError("invalid_response")
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as error:
            code = "http_{}".format(error.code)
            try:
                code = json.loads(error.read(4096)).get("error", code)
            except (ValueError, AttributeError):
                pass
            raise ApiError(code, error.code) from None
        except (OSError, ValueError):
            raise ApiError("connection_failed") from None

    def verify_user(self):
        actual = self.call("Users/Me", jellyfin=True).get("Id", "").replace("-", "").lower()
        if actual != self.connection.user.replace("-", "").lower():
            raise ApiError("account_mismatch")
