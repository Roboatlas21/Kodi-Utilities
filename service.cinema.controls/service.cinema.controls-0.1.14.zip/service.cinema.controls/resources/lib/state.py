"""Playback policy and navigation without Kodi or network dependencies."""
import math
import time
from dataclasses import dataclass


def seconds(value, default=0):
    try:
        value = float(value)
        return max(0.0, value) if math.isfinite(value) else float(default)
    except (TypeError, ValueError):
        return float(default)


@dataclass(frozen=True)
class Policy:
    show_skip: bool = True
    minimum: float = 15
    delay: float = 5
    auto_hide: float = 15
    seerr: bool = False

    @classmethod
    def read(cls, data, category=None):
        trailer = category == "Downloaded Trailer"
        delay = data.get("trailerSkipDelaySeconds", data.get("skipDelaySeconds")) if trailer else data.get("skipDelaySeconds")
        return cls(data.get("showSkip", True), seconds(data.get("minimumSeconds"), 15),
                   seconds(delay, 10 if trailer else 5),
                   seconds(data.get("autoHideSeconds"), 15), data.get("seerrEnabled", False))


class State:
    def __init__(self, policy, category, duration=None):
        self.policy, self.category = policy, category
        self.duration = seconds(duration)
        self.position = 0.0
        self.visible = True
        self.focus = "skip" if policy.show_skip else "close"
        self.request_label = ""
        self.requestable = False
        self.submitting = False
        self.skipping = False
        self.picker = False
        self.hide_remaining = policy.auto_hide
        self.was_locked = policy.show_skip and policy.delay > 0

    @property
    def eligible(self):
        return self.policy.minimum == 0 or self.duration >= self.policy.minimum

    @property
    def has_controls(self):
        return self.eligible and (self.policy.show_skip or bool(self.request_label))

    @property
    def capture_only(self):
        # Only registered clips with a known, below-minimum duration can
        # capture input without showing controls. Unknown durations stay free.
        return 0 < self.duration < self.policy.minimum

    @property
    def needs_overlay(self):
        return self.has_controls or self.capture_only

    @property
    def remaining(self):
        return math.ceil(max(0, self.policy.delay - self.position))

    @property
    def can_skip(self):
        return self.eligible and self.policy.show_skip and self.remaining == 0 and not self.skipping

    @property
    def progress(self):
        return min(1.0, self.position / self.duration) if self.duration > 0 else 0.0

    @property
    def skip_label(self):
        label = {"Downloaded Trailer": "Skip Trailer", "Commercial": "Skip Ad"}.get(self.category, "Skip")
        return "{} in {}s".format(label, self.remaining) if self.remaining else label

    def targets(self):
        return (["request"] if self.requestable and not self.submitting else []) + (
            ["skip"] if self.policy.show_skip else []) + ["close"]

    def default_focus(self):
        return "skip" if self.policy.show_skip else self.targets()[0]

    def repair_focus(self):
        if self.focus not in self.targets():
            self.focus = self.default_focus()

    def reveal(self, direction="right"):
        self.visible = True
        self.focus = self.targets()[0] if direction == "left" else self.default_focus()
        self.restart_hide()

    def move(self, direction):
        if not self.visible:
            self.reveal(direction)
            return
        self.repair_focus()
        targets = self.targets()
        i = targets.index(self.focus) + (-1 if direction == "left" else 1)
        self.focus = targets[min(len(targets) - 1, max(0, i))]
        self.restart_hide()

    def restart_hide(self):
        self.hide_remaining = self.policy.auto_hide

    def update(self, position, duration, elapsed, running):
        self.position = seconds(position)
        if seconds(duration) > 0:
            self.duration = seconds(duration)
        locked = self.policy.show_skip and self.remaining > 0
        if self.was_locked and not locked:
            self.restart_hide()
        self.was_locked = locked
        if self.visible and self.has_controls and running and not locked and not self.picker and not self.submitting and self.policy.auto_hide > 0:
            self.hide_remaining = max(0, self.hide_remaining - min(seconds(elapsed), 0.5))
            if self.hide_remaining == 0:
                self.visible = False
        self.repair_focus()

    def set_status(self, data, media_type):
        status = data.get("status") or {}
        label = status.get("label")
        self.requestable = label == "REQUEST" and any(q.get("requestable") for q in status.get("qualities", []))
        if self.requestable:
            more = any(q.get("confirmedSeasons") or q.get("status") for q in status.get("qualities", []))
            self.request_label = ("Request More" if more else "Request Series") if media_type == "tv" else "Request Movie"
        else:
            self.request_label = {"AVAILABLE": "Available", "REQUESTED": "Requested",
                                  "PENDING": "Pending", "PROCESSING": "Processing"}.get(label, "")
        self.repair_focus()


class RepeatGuard:
    """Re-arm Back only after an idle gap; every repeat extends the quiet period."""
    def __init__(self, quiet=0.7):
        self.quiet = quiet
        self.last = -math.inf

    def accept(self, now=None):
        now = time.monotonic() if now is None else now
        accepted = now - self.last >= self.quiet
        self.last = now
        return accepted
