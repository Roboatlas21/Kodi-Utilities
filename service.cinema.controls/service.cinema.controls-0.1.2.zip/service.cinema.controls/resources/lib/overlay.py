import xbmcgui


CONTROL = {"request": 3011, "skip": 3012, "close": 3013}


class Overlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.events = kwargs.pop("events")
        self.owner = kwargs.pop("owner")
        self.ready = False
        self.last_focus = None
        self.values = {}
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.ready = True

    def onAction(self, action):
        # Select is delivered through onClick; processing it twice would activate on reveal.
        if action.getId() != 7:
            self.events.put((self.owner, "action", action.getId()))

    def onClick(self, control_id):
        self.events.put((self.owner, "click", control_id))

    def prop(self, name, value):
        value = str(value)
        if self.values.get(name) != value:
            self.setProperty(name, value)
            self.values[name] = value

    def render(self, state):
        self.prop("cinema.visible", "true" if state.visible else "")
        self.prop("cinema.skip", "true" if state.policy.show_skip else "")
        self.prop("cinema.locked", "true" if state.remaining or state.skipping else "")
        self.prop("cinema.request", "true" if state.requestable and not state.submitting else "")
        self.prop("cinema.status", "" if state.requestable and not state.submitting else state.request_label)
        self.prop("cinema.skipLabel", state.skip_label)
        self.prop("cinema.requestLabel", "+ " + state.request_label)
        if not self.ready:
            return
        self.getControl(3020).setPercent(state.progress * 100)
        focus = CONTROL[state.focus] if state.visible else 3000
        if focus != self.last_focus:
            self.setFocusId(focus)
            self.last_focus = focus


class Picker(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.events = kwargs.pop("events")
        self.owner = kwargs.pop("owner")
        self.data = kwargs.pop("data")
        self.tv = kwargs.pop("tv")
        self.qualities = [q for q in self.data["status"]["qualities"] if q.get("requestable")]
        self.quality = 0
        self.selected = set()
        self.ready = False
        self.closed = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.ready = True
        self.setProperty("picker.title", "Request Series" if self.tv else "Request Movie")
        self.setProperty("picker.media", self.data["status"].get("title", ""))
        self.setProperty("picker.tv", "true" if self.tv else "")
        self.setProperty("picker.qualities", "true" if self.tv and len(self.qualities) > 1 else "")
        self.populate()
        self.setFocusId(3101)

    def populate(self):
        self.rows = self.qualities[self.quality].get("seasons", []) if self.tv else self.qualities
        control = self.getControl(3101)
        old = max(0, control.getSelectedPosition())
        control.reset()
        if self.tv:
            for season in self.rows:
                label = "Specials" if season == 0 else "Season {}".format(season)
                control.addItem(xbmcgui.ListItem(("[✓] " if season in self.selected else "[ ] ") + label))
        else:
            for quality in self.rows:
                control.addItem(xbmcgui.ListItem("4K" if quality.get("is4k") else "Standard"))
        if self.rows:
            control.selectItem(min(old, len(self.rows) - 1))
        self.getControl(3100).setLabel("Quality: " + ("4K" if self.qualities[self.quality].get("is4k") else "Standard"))
        self.getControl(3102).setEnabled(bool(self.selected))
        self.getControl(3103).setEnabled(any(n > 0 for n in self.rows) if self.tv else False)

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.events.put((self.owner, "picker_cancel", None))
        elif action.getId() == 13:
            self.events.put((self.owner, "action", 13))

    def onClick(self, control_id):
        if self.closed:
            return
        if control_id == 3104:
            self.events.put((self.owner, "picker_cancel", None))
        elif control_id == 3100:
            self.quality = (self.quality + 1) % len(self.qualities)
            self.selected.clear()
            self.populate()
        elif control_id == 3103:
            self.selected = {n for n in self.rows if n > 0}
            self.populate()
        elif control_id == 3101:
            index = self.getControl(3101).getSelectedPosition()
            if not 0 <= index < len(self.rows):
                return
            if self.tv:
                season = self.rows[index]
                self.selected.symmetric_difference_update({season})
                self.populate()
            else:
                self.send(self.rows[index], [], False)
        elif control_id == 3102 and self.selected:
            positive = {n for n in self.rows if n > 0}
            self.send(self.qualities[self.quality], sorted(self.selected), self.selected == positive and bool(positive))

    def send(self, quality, seasons, all_seasons):
        self.closed = True
        self.events.put((self.owner, "picker_submit", (quality.get("is4k", False), seasons, all_seasons)))

    def close(self):
        self.closed = True
        super().close()
