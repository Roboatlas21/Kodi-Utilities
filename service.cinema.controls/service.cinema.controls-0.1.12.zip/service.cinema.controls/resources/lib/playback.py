import hashlib
import json
import re
import urllib.parse
import uuid
from dataclasses import dataclass

import xbmc
import xbmcgui


def rpc(method, params=None):
    response = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})))
    if "error" in response:
        raise RuntimeError("Kodi RPC failed")
    return response.get("result", {})


def item_id(path):
    path = urllib.parse.urlsplit(path.split("|", 1)[0])
    match = re.search(r"/(?:Videos|Items|Audio)/([0-9a-fA-F-]{32,36})(?:/|$)", path.path, re.I)
    try:
        return uuid.UUID(match.group(1)).hex if match else ""
    except ValueError:
        return ""


def normalize_id(value):
    try:
        return uuid.UUID(str(value)).hex
    except (ValueError, TypeError):
        return ""


@dataclass(frozen=True)
class Snapshot:
    player: int
    playlist: int
    index: int
    item: str
    file: str
    queue: tuple
    generation: int

    @property
    def key(self):
        # A playlist refresh is not a new playback occurrence. Full Snapshot
        # equality still includes the queue for verification and Skip.
        occurrence = (self.player, self.playlist, self.index, self.item, self.file, self.generation)
        return hashlib.sha256(repr(occurrence).encode()).hexdigest()

    def payload(self):
        return {"itemId": self.item, "occurrence": self.key, "index": self.index,
                "queue": [{"id": item_id(p) or "00000000000000000000000000000000",
                           "path": p.split("|", 1)[0]} for p in self.queue]}


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.generation = 0

    def onAVStarted(self):
        self.generation += 1

    def onPlayBackStopped(self):
        self.generation += 1

    def onPlayBackEnded(self):
        self.generation += 1

    def snapshot(self):
        if not self.isPlayingVideo():
            return None
        players = [p for p in rpc("Player.GetActivePlayers") if p.get("type") == "video"]
        if len(players) != 1:
            return None
        pid = players[0]["playerid"]
        props = rpc("Player.GetProperties", {"playerid": pid, "properties": ["playlistid", "position", "repeat", "shuffled"]})
        if props.get("repeat") != "off" or props.get("shuffled") or props.get("playlistid", -1) < 0:
            return None
        entries = rpc("Playlist.GetItems", {"playlistid": props["playlistid"], "properties": ["file"]}).get("items", [])
        queue = tuple(x.get("file", "") for x in entries)
        index = props.get("position", -1)
        if not 0 <= index < len(queue) - 1 or len(queue) > 1000:
            return None
        path = self.getPlayingFile()
        current = item_id(path)
        prop = normalize_id(xbmcgui.Window(10000).getProperty("jellyfin_playing_id"))
        if not prop or current and prop != current:
            return None
        # A source switch or a stale playlist is never grounds for a next-item command.
        if path != queue[index] and (not current or item_id(queue[index]) != current):
            return None
        return Snapshot(pid, props["playlistid"], index, current or prop, path, queue, self.generation)

    def skip(self, expected):
        if self.snapshot() != expected:
            return False
        # An absolute target prevents repeated "next" commands from advancing past the feature.
        rpc("Player.GoTo", {"playerid": expected.player, "to": expected.index + 1})
        return True
