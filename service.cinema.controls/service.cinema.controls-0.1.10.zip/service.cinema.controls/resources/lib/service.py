"""The service owns UI and playback; bounded workers only perform HTTP operations."""
import os
import queue
import threading
import time
import traceback
from dataclasses import dataclass

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .connection import Api, ApiError, choose_connection, connections
from .overlay import Overlay, Picker
from .playback import Player
from .state import Policy, RepeatGuard, State


class Jobs:
    def __init__(self):
        self.results = queue.Queue()
        self.pending = set()
        self.queues = {name: queue.Queue(maxsize=8) for name in ("control", "status", "submit")}
        for name, tasks in self.queues.items():
            threading.Thread(target=self.work, args=(tasks,), name="cinema-" + name, daemon=True).start()

    def work(self, tasks):
        while True:
            ticket, work = tasks.get()
            try:
                result, error = work(), None
            except ApiError as e:
                result, error = None, e.code
            except Exception:
                result, error = None, "integration_error"
            self.results.put((ticket, result, error))
            tasks.task_done()

    def start(self, lane, owner, kind, work):
        ticket = (owner, kind)
        if ticket in self.pending:
            return False
        try:
            self.queues[lane].put_nowait((ticket, work))
        except queue.Full:
            return False
        self.pending.add(ticket)
        return True

    def drain(self):
        while True:
            try:
                ticket, result, error = self.results.get_nowait()
            except queue.Empty:
                return
            self.pending.discard(ticket)
            yield ticket, result, error


@dataclass
class Clip:
    key: str
    snapshot: object
    api: Api
    context: dict
    state: State
    status: object = None
    validated: float = 0
    refreshed: float = 0
    uncertain: bool = False
    status_started: bool = False


MESSAGES = {
    "quota_exceeded": "Your request limit has been reached.",
    "seasons_changed": "The available seasons changed. Please select them again.",
    "no_longer_requestable": "That quality is no longer available to request.",
    "account_changed": "Your account changed. Please try again.",
    "stale_context": "This trailer's request window has closed.",
}


class Service:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.path = self.addon.getAddonInfo("path")
        self.player = Player()
        self.monitor = xbmc.Monitor()
        self.jobs = Jobs()
        self.events = queue.Queue()
        self.back = RepeatGuard()
        self.clip = None
        self.overlay = None
        self.picker = None
        self.picker_owner = None
        self.grace_until = 0
        self.snapshot = None
        self.connection = None
        self.last_connection_check = 0
        self.attempt_at = 0
        self.suppressed = None
        self.warned = set()
        self.native_blocked = False
        self.last_trace = None

    def notify(self, message):
        xbmcgui.Dialog().notification("Cinema Controls", message, time=4000, sound=False)

    def log(self, message, warning=False):
        if warning or self.addon.getSettingBool("diagnostics"):
            xbmc.log("[Cinema Controls] " + message, xbmc.LOGWARNING if warning else xbmc.LOGINFO)

    def trace(self):
        if not self.addon.getSettingBool("diagnostics"):
            return
        state = (xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId(),
                 self.player.isPlayingVideo(), self.overlay is not None,
                 self.picker is not None, self.native_blocked)
        if state != self.last_trace:
            self.last_trace = state
            self.log("window={} dialog={} video={} overlay={} picker={} native_blocked={}".format(*state))

    def read_connection(self, snapshot, now):
        if now - self.last_connection_check < 1:
            return self.connection
        self.last_connection_check = now
        try:
            profile = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.jellyfin").rstrip("/")
            device = xbmcgui.Window(10000).getProperty("jellyfin_deviceId")
            if not device:
                with open(os.path.join(profile, "jellyfin_guid"), encoding="utf-8") as stream:
                    device = stream.read().strip()
            upstream = xbmcaddon.Addon("plugin.video.jellyfin")
            name = upstream.getSetting("deviceName") if upstream.getSettingBool("deviceNameOpt") else xbmc.getInfoLabel("System.FriendlyName")
            candidate = choose_connection(connections(profile, device, upstream.getAddonInfo("version"), name), snapshot.file)
        except (OSError, ValueError, TypeError, KeyError):
            candidate = None
        if self.connection != candidate:
            self.retire(False)
            self.close_picker()
            self.connection = candidate
            self.suppressed = None
        return candidate

    def native_conflict(self):
        upstream = xbmcaddon.Addon("plugin.video.jellyfin")
        if upstream.getSetting("mediaSegmentsEnabled") != "true":
            return False
        # These are checked read-only; the user keeps control of upstream preferences.
        return any(upstream.getSetting(name) not in ("", "0") for name in ("skipPreviewMode", "skipCommercialMode"))

    def open_clip(self, snapshot, connection):
        api = Api(connection)
        api.verify_user()
        config = api.call("Configuration")
        if config.get("apiVersion") != 1 or not config.get("enabled"):
            raise ApiError("controls_disabled")
        context = api.call("Context", snapshot.payload())
        state = State(Policy.read(config), context["category"], context.get("durationSeconds"))
        return Clip(snapshot.key, snapshot, api, context, state)

    def call(self, clip, route, extra=None, timeout=8):
        return clip.api.call(route, dict({"token": clip.context["token"]}, **(extra or {})), timeout=timeout)

    def refresh(self, clip, connect=False):
        if connect:
            account = self.call(clip, "Seerr/AutoConnect", timeout=35)
            if not account.get("connected"):
                raise ApiError(account.get("error") or "not_connected")
        return self.call(clip, "Seerr/Status", timeout=20)

    def retire(self, natural):
        clip, self.clip = self.clip, None
        if self.overlay:
            self.overlay.close()
            self.overlay = None
        if not clip:
            return
        grace = natural and self.picker_owner is clip and self.picker and clip.context.get("identity", {}).get("mediaType") == "tv"
        if grace:
            self.grace_until = time.monotonic() + 10
        elif self.picker_owner is clip:
            self.close_picker()
        self.jobs.start("control", clip.key, "end", lambda: self.call(clip, "Context/End", {"natural": bool(grace)}))

    def close_picker(self):
        owner = self.picker_owner
        if self.picker:
            self.picker.close()
        self.picker = self.picker_owner = None
        self.grace_until = 0
        if owner:
            owner.state.picker = False
            owner.state.restart_hide()
            self.jobs.start("control", owner.key, "close_picker", lambda: self.call(owner, "Context/Picker", {"open": False}))

    def stop_playback(self):
        # Kodi's stop is synchronous. Release our input-capturing windows before
        # entering player teardown, even if the decoder takes time to stop.
        if self.clip:
            self.suppressed = self.clip.key
        self.snapshot = None
        self.close_picker()
        self.retire(False)
        self.log("Dialogs released; requesting playback stop.")
        self.player.stop()
        self.log("Playback stop returned.")

    def submit(self, clip, is4k, seasons, all_seasons):
        if clip.state.submitting or clip.uncertain:
            return
        clip.state.submitting = True
        clip.state.request_label = "Requesting…"
        clip.state.requestable = False
        if self.picker:
            self.picker.close()
            self.picker = None
        # Keep the picker capability until the server accepts the submission.
        # The server re-fetches policy, seasons, quality and quota inside Submit.
        # Send promptly; do not add another status round trip before accepting work.
        def work():
            return self.call(clip, "Seerr/Request", {"revision": clip.status["revision"], "is4k": is4k,
                            "seasons": seasons, "allSeasons": all_seasons}, timeout=45)
        if not self.jobs.start("submit", clip.key, "submit", work):
            clip.state.submitting = False
            clip.state.set_status(clip.status, clip.context["identity"]["mediaType"])
            self.close_picker()
            self.notify("A request is already being processed.")

    def request(self, clip):
        state = clip.state
        if not state.requestable or state.submitting or clip.uncertain or state.picker:
            return
        if (clip.status or {}).get("status", {}).get("quotaExceeded"):
            self.notify(MESSAGES["quota_exceeded"])
            state.restart_hide()
            return
        state.picker = True
        def work():
            self.call(clip, "Context/Picker", {"open": True})
            return self.refresh(clip)
        if not self.jobs.start("status", clip.key, "prepare", work):
            state.picker = False

    def skip(self, clip):
        if clip is not self.clip or not clip.state.can_skip or clip.snapshot != self.snapshot:
            return
        clip.state.skipping = True
        if not self.jobs.start("control", clip.key, "skip", lambda: self.call(clip, "Context/Validate", timeout=4)):
            clip.state.skipping = False

    def result(self, ticket, value, error):
        key, kind = ticket
        if kind in ("end", "close_picker"):
            return
        if kind == "open":
            if not self.snapshot or self.snapshot.key != key or not self.connection:
                return
            if error:
                if error not in ("playback_not_ready", "intro_sequence_mismatch"):
                    self.suppressed = key
                self.log("Playback verification: " + error)
                return
            if self.clip or value.api.connection != self.connection or value.snapshot != self.snapshot:
                return
            self.clip = value
            value.validated = time.monotonic()
            return
        clip = self.clip if self.clip and self.clip.key == key else (
            self.picker_owner if self.picker_owner and self.picker_owner.key == key else None)
        if clip is None:
            return
        if kind in ("validate", "skip", "queue"):
            if error:
                if clip is self.clip:
                    self.suppressed = key
                    self.retire(False)
                return
            if kind == "queue":
                snapshot, context = value
                if clip is not self.clip or snapshot != self.snapshot:
                    return
                if context.get("token") != clip.context["token"]:
                    self.suppressed = key
                    self.retire(False)
                    return
                clip.snapshot = snapshot
                self.log("Playlist refresh verified; retained existing controls.")
            clip.validated = time.monotonic()
            if kind == "skip" and clip is self.clip:
                if clip.snapshot != self.snapshot:
                    clip.state.skipping = False
                    return
                # Recheck both media time and the entire local queue after the HTTP round trip.
                clip.state.position = max(0, self.player.getTime())
                if clip.state.remaining:
                    clip.state.skipping = False
                    return
                if self.player.skip(clip.snapshot):
                    self.suppressed = key
                    self.retire(False)
                else:
                    self.retire(False)
            return
        state = clip.state
        if kind == "submit":
            state.submitting = False
            if error:
                uncertain = error not in MESSAGES
                clip.uncertain = uncertain
                state.request_label = "Check request" if uncertain else ""
                state.requestable = False
                if clip is self.clip or clip is self.picker_owner:
                    self.notify(MESSAGES.get(error, "The request may have been sent. Check its status before trying again."))
            else:
                state.requestable = False
                clip.uncertain = value.get("outcome") != "accepted"
                state.request_label = "Check request" if clip.uncertain else "Requested"
                if clip is self.clip or clip is self.picker_owner:
                    self.notify("Request sent; confirmation is pending." if clip.uncertain else "Request submitted.")
            if self.picker_owner is clip:
                self.close_picker()
            state.restart_hide()
            return
        if kind == "status" and (state.picker or state.submitting or clip.uncertain):
            return
        if error:
            state.request_label = ""
            state.requestable = False
            state.picker = False
            if kind == "prepare":
                self.jobs.start("control", key, "close_picker", lambda: self.call(clip, "Context/Picker", {"open": False}))
                self.notify(MESSAGES.get(error, "Requests are temporarily unavailable."))
            return
        clip.status = value
        clip.refreshed = time.monotonic()
        if not state.submitting and not clip.uncertain:
            state.set_status(value, clip.context["identity"]["mediaType"])
        if kind == "prepare":
            qualities = [q for q in value["status"]["qualities"] if q.get("requestable")]
            if not qualities or value["status"].get("quotaExceeded"):
                state.picker = False
                self.jobs.start("control", key, "close_picker", lambda: self.call(clip, "Context/Picker", {"open": False}))
                self.notify("Your request limit has been reached." if value["status"].get("quotaExceeded") else "This title is no longer requestable.")
                return
            self.picker_owner = clip
            if clip.context["identity"]["mediaType"] == "movie" and len(qualities) == 1:
                self.submit(clip, qualities[0].get("is4k", False), [], False)
            else:
                self.picker = Picker("cinema-picker.xml", self.path, "default", "1080i",
                                     events=self.events, owner=key, data=value,
                                     tv=clip.context["identity"]["mediaType"] == "tv")
                self.picker.show()

    def input(self, key, kind, value):
        owner = self.clip if self.clip and self.clip.key == key else self.picker_owner
        if not owner or owner.key != key:
            return
        if kind == "picker_cancel":
            self.back.accept()
            self.close_picker()
            return
        if kind == "picker_submit":
            self.submit(owner, *value)
            return
        if kind == "action" and value == 13:
            self.stop_playback()
            return
        if owner is not self.clip or self.picker:
            return
        state = owner.state
        if kind == "click":
            if not state.visible or value == 3000:
                state.reveal()
            elif value == 3011:
                self.request(owner)
            elif value == 3012:
                self.skip(owner)
            elif value == 3013:
                state.visible = False
            return
        if value in (9, 10, 92):
            if not self.back.accept():
                return
            if state.visible:
                state.visible = False
            else:
                self.stop_playback()
        elif value in (1, 2):
            state.move("left" if value == 1 else "right")
        elif value in (77, 14):
            self.skip(owner)
        elif value in (12, 79, 229):
            self.player.pause()

    def tick(self, now, elapsed):
        # These cheap checks must precede synchronous playlist RPC. Once playback
        # exits, cleanup must not depend on querying a player being torn down.
        if (not self.addon.getSettingBool("enabled") or xbmcgui.getCurrentWindowId() != 12005
                or not self.player.isPlayingVideo()):
            self.snapshot = None
            self.retire(False)
            self.close_picker()
            return
        if self.native_blocked:
            if self.native_conflict():
                self.snapshot = None
                self.retire(False)
                self.close_picker()
                return
            self.native_blocked = False
            self.suppressed = None
            self.log("Native segment conflict cleared; verification may resume.")
        self.snapshot = self.player.snapshot()
        if not self.snapshot:
            if self.clip:
                self.log("Playback snapshot unavailable; releasing controls.")
            self.retire(self.player.isPlayingVideo())
            if not self.player.isPlayingVideo():
                self.close_picker()
            elif self.picker_owner:
                # The feature may be the last queue item and have no companion
                # snapshot. Keep watching account changes during the old picker grace.
                self.read_connection(self.picker_owner.snapshot, now)
            return
        snapshot = self.snapshot
        if self.clip and self.clip.key != snapshot.key:
            self.log("Playback occurrence changed; releasing previous controls.")
            self.retire(True)
        connection = self.read_connection(snapshot, now)
        if not connection:
            return
        if not self.clip and self.suppressed != snapshot.key and now >= self.attempt_at:
            self.attempt_at = now + 1
            self.jobs.start("control", snapshot.key, "open", lambda: self.open_clip(snapshot, connection))
        clip = self.clip
        if not clip:
            return
        if clip.snapshot != snapshot:
            # Recheck the changed queue with the server while retaining this
            # clip's focus, dismissal state and dialog. Skip waits for approval.
            self.jobs.start("control", clip.key, "queue",
                            lambda: (snapshot, clip.api.call("Context", snapshot.payload())))
        running = not xbmc.getCondVisibility("Player.Paused") and not xbmc.getCondVisibility("Player.Caching")
        clip.state.update(self.player.getTime(), self.player.getTotalTime(), elapsed, running)
        if clip.state.eligible and self.native_conflict():
            self.native_blocked = True
            self.suppressed = clip.key
            self.snapshot = None
            self.retire(False)
            self.close_picker()
            if "segments" not in self.warned:
                self.warned.add("segments")
                self.log("Native segment conflict: Cinema dialogs released; playback unchanged. window={} dialog={}".format(
                    xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId()), warning=True)
                self.notify("Set Jellyfin for Kodi Preview and Commercial segments to Off to use Cinema Controls.")
            return
        if clip.state.eligible and clip.state.policy.seerr and clip.context.get("identity") and not clip.status_started:
            clip.status_started = self.jobs.start("status", clip.key, "status", lambda: self.refresh(clip, True))
        if now - clip.validated >= 3:
            self.jobs.start("control", clip.key, "validate", lambda: self.call(clip, "Context/Validate", timeout=4))
        if now - clip.validated > 8:
            self.suppressed = clip.key
            self.retire(False)
            return
        if clip.status and now - clip.refreshed >= 20 and not clip.state.submitting and not clip.state.picker:
            self.jobs.start("status", clip.key, "status", lambda: self.refresh(clip))
        if clip.state.has_controls and not self.picker:
            if not self.overlay:
                self.overlay = Overlay("cinema-overlay.xml", self.path, "default", "1080i", events=self.events, owner=clip.key)
                self.overlay.render(clip.state)
                self.overlay.show()
            self.overlay.render(clip.state)
        elif self.overlay:
            self.overlay.close()
            self.overlay = None

    def run(self):
        previous = time.monotonic()
        try:
            while not self.monitor.waitForAbort(0.2):
                now = time.monotonic()
                try:
                    self.trace()
                    # Refresh the occurrence before handling any queued network response or input.
                    self.tick(now, now - previous)
                    if self.grace_until and now >= self.grace_until:
                        self.close_picker()
                    for ticket, value, error in self.jobs.drain():
                        self.result(ticket, value, error)
                    while not self.events.empty():
                        self.input(*self.events.get_nowait())
                except Exception as error:
                    # Exception text/locals can contain URLs or credentials. Log
                    # only code locations and the exception class.
                    frames = traceback.extract_tb(error.__traceback__)[-6:]
                    where = " > ".join("{}:{}:{}".format(os.path.basename(f.filename), f.name, f.lineno) for f in frames)
                    self.log("Local error {} at {}; releasing controls.".format(type(error).__name__, where))
                    self.snapshot = None
                    self.retire(False)
                    self.close_picker()
                previous = now
        finally:
            self.retire(False)
            self.close_picker()


def run():
    Service().run()
