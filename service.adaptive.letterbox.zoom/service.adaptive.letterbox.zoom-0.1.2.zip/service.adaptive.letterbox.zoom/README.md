# Adaptive Letterbox Zoom

A functional Kodi service for **CoreELEC 21.3 / P3I on AM6B+**, implementing specification v1.2 with the v1.3 zoom-policy addendum. It reads the playing video's aspect ratio and supported Dolby Vision L5 offsets, then changes Kodi's custom zoom automatically. It does not open another stream or decoder.

**Version:** 0.1.2 · **Add-on ID:** `service.adaptive.letterbox.zoom`

## Install

1. Download [`service.adaptive.letterbox.zoom-0.1.2.zip`](packages/service.adaptive.letterbox.zoom-0.1.2.zip) from this repository. On the GitHub file page, use **Download raw file**. This repository is private, so sign into your GitHub account to download it.
2. Copy the ZIP somewhere accessible to Kodi, such as the CoreELEC Downloads share. Use the installable ZIP linked above; GitHub's **Download ZIP** source archive is not the add-on package.
3. In Kodi, enable **Settings → System → Add-ons → Unknown sources** if necessary, then select **Add-ons → Install from zip file** and choose the ZIP.
4. The service starts automatically. Under **My add-ons → Services → Adaptive Letterbox Zoom → Configure**, leave automatic zoom enabled and choose a maximum between 100% and 115%.
5. Play a native-cropped title wider than 2:1 normally through Jellyfin for Kodi. It should automatically zoom. Then test a Dolby Vision title with a known widescreen/IMAX transition; 2:1 and taller scenes should stay at 100%.

No AF3 changes or special widget are needed. Replacing the installed ZIP with a newer version updates the same add-on ID.

## What it does

Reduce large movie bars, but keep the small bars of a **2:1 picture on a 16:9 TV**. Zoom stops when those bars remain, or when the configured maximum (up to 115%) is reached, whichever comes first. Each target bar is 5.56% of screen height: 120 pixels on a 2160p display or 60 pixels on a 1080p display. Content already at 2:1 or taller stays at 100%; the service never zooms out below 100% to create bars.

| Content | Behavior at the default maximum |
|---|---|
| Native DAR 2.40:1, such as 3840×1600 | 115% zoom |
| Native DAR 2.20:1 | 110%; leaves the 2:1 target bars |
| Native DAR 2.00:1 | 100%; keeps existing small bars |
| Native DAR 1.90:1 | 100% |
| Approximately 16:9 DV with supported L5 bars | Same 2:1 bar target, calculated from the effective offsets |
| Full-height scene or no usable L5 signal | 100% |
| 4:3/narrow content, unsupported side bars/asymmetry | 100% |
| 16:9 SDR/HDR10 with baked-in bars | 100%; pixel scanning is not included |

The image is uniformly enlarged, not stretched. At 115%, roughly 6.5% of the original image width is cropped from each side; very wide films still have some bars. Custom pixel ratio is set to 1.0, vertical shift to 0.0, and nonlinear stretch to false. Every numeric view-mode field is serialized as a floating-point value, including a return to 1.0.

Native DAR takes priority on non-16:9 videos, so P3I synthetic L5 for cropped sources is not counted twice. For 16:9 DV, the source profile is preferred; a valid processed DV profile is accepted when the source profile is missing, invalid, or zero.

The service samples approximately every 200 ms, with two consistent polls for zooming out and three for zooming in. Frequent P3I `onAVChange` notifications do not reset playback state; a missed `onAVStarted` can be recovered using the advancing playback clock and available geometry. Supported L5 offsets may vary by up to three pixels from the **first** sample in the pending confirmation window. Zoom uses the smallest safe top/bottom margin across the window. Cumulative drift resets confirmation even when every proposal would cap at 115%. Rounding cannot exceed the calculated bar-preservation ceiling, and a confirmed lower ceiling takes effect even when the change is smaller than the usual zoom-write threshold.

## Prerequisites and limitations

- Use fullscreen video on a calibrated 16:9 display. Set Kodi's allowed aspect-ratio error to zero and disable additional TV zoom or conflicting automatic zoom controllers. The add-on does not change these settings.
- **Turn off P3I per-folder L5 overrides before evaluating dynamic scene tracking.** The available info labels do not reliably reveal those overrides. This release logs their status as unverified; it does not claim they were detected or disabled.
- Effective `l5.detected` or `l5.auto` values on the 16:9 path are not trusted for dynamic zoom. Known safe/unsupported classifications return to 100%; changes in unused synthetic offsets cannot block that return indefinitely.
- L5 must match the actual picture. It can be constant legitimately; unchanged metadata does not expire. Animated aspect-ratio changes can have deliberately constant metadata and are not guaranteed to track.
- P3I can return a metadata record that does not match the displayed frame. Profile labels and repeated samples do not prove freshness. This service clears its own previous-session state but cannot guarantee that upstream metadata is current.
- Missing or malformed signals receive a 0.60-second grace, then a request for 100% zoom. A failing Kodi control API cannot be forced to apply that request; failures are logged and retried with bounded backoff.
- Dolby Vision decoding, FEL/MEL behavior, actual transition timing, and the installed P3I build's label compatibility **have not been validated on an AM6B+ for this release**. Local tests do not establish those results.

## Settings and lifecycle

- **Enable automatic zoom:** on by default. Disabling stops control and leaves the current zoom unchanged. Once automatic zoom is verified, adjusting Kodi zoom or view mode manually suspends automation for that movie. The manual setting survives seeks; a new movie or disabling/re-enabling the add-on resumes automation. Changes are detected with low-frequency `Player.GetViewMode` checks and before scene-change writes.
- **Maximum zoom (%):** 115 by default, range 100–115. The 2:1 bar target can stop zoom earlier. A lower cap takes effect during playback, including while paused.
- **Debug logging:** off by default. When enabled, logs contain observed numeric labels, provenance flags, decisions, and monotonic observation times. These are not video-frame timestamps. Debug messages use Kodi's information level so this toggle works without enabling global Kodi debug logging.

Seeks and new playback invalidate pending samples/commands and reapply the native-DAR result or a safe 100% baseline before stabilizing L5 unless manual zoom is active. Redundant AVChange messages are ignored; real video-geometry changes are detected by sampling. The service also attaches if enabled during playback. Stop/disable/shutdown never restore old preferences or reset zoom; Kodi keeps its existing per-movie video-setting persistence behavior. Enabling the service gives it ownership of automatic view settings for active playback.

Find logs in Kodi's usual `kodi.log` with the prefix `[Adaptive Letterbox Zoom]`. No playback URLs, Jellyfin tokens, frame scans, or network requests are logged or performed by the add-on.

## Development and validation

The runtime has no external Python dependencies. Run the local suite:

```sh
python3 -m unittest discover -v
```

Build a reproducible installable ZIP from the implementation commit:

```sh
python3 tools/build_zip.py --source-commit FULL_40_CHARACTER_IMPLEMENTATION_SHA
```

`build-info.json` inside the ZIP records the implementation commit, spec version, and packaged file checksums. The repository's package commit may be newer than the implementation commit recorded inside the ZIP.

See [the v1.4 playback-control addendum](docs/implementation-spec-v1.4.md), [the v1.3 zoom-policy addendum](docs/implementation-spec-v1.3.md), [the base v1.2 specification](docs/implementation-spec-v1.2.md), and [validation results](docs/validation.md). Local checks cover real service-loop integration with mocked Kodi interfaces, bar preservation, metadata classification, anchored jitter, invalid-signal fallback, lifecycle invalidation, float-only P3I-style numeric handling, retry/readback behavior, and ZIP integrity. No GitHub Actions workflow is required to build this Python-only add-on.
