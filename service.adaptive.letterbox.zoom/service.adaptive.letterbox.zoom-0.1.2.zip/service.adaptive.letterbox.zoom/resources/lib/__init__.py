"""Adaptive zoom detection, control, and Kodi integration."""
