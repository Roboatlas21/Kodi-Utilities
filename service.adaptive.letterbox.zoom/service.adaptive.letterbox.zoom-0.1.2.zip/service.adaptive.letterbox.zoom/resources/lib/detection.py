"""Pure interpretation of native DAR and effective P3I L5 observations."""

import math
import re
from dataclasses import dataclass
from typing import Optional, Tuple

SCREEN_DAR = 16.0 / 9.0
TARGET_PICTURE_DAR = 2.0
DAR_16_9_TOLERANCE = 0.02
HARD_MAX_ZOOM = 1.15
DEFAULT_MAX_ZOOM = 1.15
L5_JITTER_TOLERANCE_PX = 3
POLL_INTERVAL_SECONDS = 0.20

GEOMETRY_LABELS = {
    "dar": "videodar",
    "width": "video.width.raw",
    "height": "video.height.raw",
}
PROFILE_LABELS = {
    "source_profile": "video.source.dovi.profile",
    "processed_profile": "video.dovi.profile",
}
FLAG_LABELS = {
    "has_l5": "video.dovi.has.l5",
    "detected": "video.dovi.l5.detected",
    "auto": "video.dovi.l5.auto",
}
OFFSET_LABELS = {side: "video.dovi.l5.{}.offset".format(side)
                 for side in ("top", "bottom", "left", "right")}


def integer(value):
    """Reject decimal strings, negatives, booleans, and unreasonable integers."""
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]{1,10}", value.strip()):
        return None
    result = int(value.strip())
    return result if result <= 2147483647 else None


def flag(value):
    result = integer(value)
    return result if result in (0, 1) else None


def finite_number(value):
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def maximum(value):
    value = finite_number(value)
    return min(HARD_MAX_ZOOM, max(1.0, value)) if value is not None else DEFAULT_MAX_ZOOM


def zoom_value(value, cap):
    """Normalize without rounding above the geometric or configured ceiling."""
    cap = maximum(cap)
    value = finite_number(value)
    value = 1.0 if value is None else value
    limited = min(cap, max(1.0, value))
    return float(min(limited, round(limited, 3)))


def dv_profile(raw):
    """Prefer the source profile, accepting a positive processed fallback."""
    for name in ("source_profile", "processed_profile"):
        value = integer(raw.get(name))
        if value is not None and value > 0:
            return name, value
    return None, None


@dataclass(frozen=True)
class Geometry:
    dar: float
    width: int
    height: int

    @property
    def route(self):
        if self.dar > SCREEN_DAR + DAR_16_9_TOLERANCE:
            return "native_dar"
        if self.dar < SCREEN_DAR - DAR_16_9_TOLERANCE:
            return "narrow_content"
        return "l5"


def geometry(raw):
    dar = finite_number(raw.get("dar"))
    width, height = integer(raw.get("width")), integer(raw.get("height"))
    if dar is None or dar <= 0 or not width or not height:
        return None
    return Geometry(dar, width, height)


@dataclass(frozen=True)
class Signal:
    generation: int
    geometry: Optional[Geometry]
    route: str
    reason: str
    offsets: Optional[Tuple[int, int, int, int]] = None
    flags: Optional[Tuple[int, int, int]] = None
    eligible: bool = False

    @property
    def valid(self):
        return self.route != "invalid"

    @property
    def key(self):
        return (self.generation, self.geometry, self.route, self.reason,
                self.flags, self.eligible)

    @property
    def safe_bar(self):
        return min(self.offsets[:2]) if self.offsets is not None else 0

    def target(self, cap, safe_bar=None):
        if self.route == "native_dar":
            return zoom_value(self.geometry.dar / TARGET_PICTURE_DAR, cap)
        if self.route == "l5":
            bar = self.safe_bar if safe_bar is None else safe_bar
            # Leave the same bar height as unzoomed 2:1 on a 16:9 display.
            desired = (SCREEN_DAR * self.geometry.height / TARGET_PICTURE_DAR
                       / (self.geometry.height - 2 * bar))
            return zoom_value(desired, cap)
        return 1.0


def classify(raw, generation, consistent=True, override_active=False):
    """Interpret one guarded observation. Profile presence is not freshness."""
    geo = geometry(raw)
    if not consistent:
        return Signal(generation, geo, "invalid", "changed_during_read")
    if geo is None:
        return Signal(generation, None, "invalid", "invalid_geometry")
    if geo.route != "l5":
        return Signal(generation, geo, geo.route, geo.route)
    eligible = dv_profile(raw)[1] is not None
    if not eligible:
        return Signal(generation, geo, "safe", "no_dv_profile")
    flags = tuple(flag(raw.get(k)) for k in FLAG_LABELS)
    offsets = tuple(integer(raw.get(k)) for k in OFFSET_LABELS)
    if None in flags or None in offsets:
        return Signal(generation, geo, "invalid", "invalid_l5", eligible=True)
    top, bottom, left, right = offsets
    if (max(offsets) > 65535 or top + bottom >= geo.height
            or left + right >= geo.width):
        return Signal(generation, geo, "invalid", "invalid_offsets", eligible=True)
    has_l5, detected, auto = flags

    def result(route, reason):
        return Signal(generation, geo, route, reason, offsets, flags, True)

    if override_active:
        return result("safe", "active_override")
    if detected:
        return result("safe", "synthetic_detected")
    if auto:
        return result("safe", "synthetic_auto")
    if not any(offsets):
        return result("safe", "full_frame_or_no_signal")
    if not has_l5:
        return result("invalid", "contradictory_presence")
    if (abs(top - bottom) > max(2, math.ceil(geo.height * .001))
            or max(left, right) > max(2, math.ceil(geo.width * .001))):
        return result("safe", "unsupported_geometry")
    return result("l5", "effective_l5")


class Sampler:
    """Read guarded info-label tuples without touching L5 on native-DAR paths."""

    def __init__(self, get_label):
        self.get_label = get_label

    def read(self, labels):
        return {key: self.get_label("Player.Process({})".format(label))
                for key, label in labels.items()}

    def sample(self, generation, guard):
        raw = self.read(GEOMETRY_LABELS)
        geo = geometry(raw)
        if geo is not None and geo.route == "l5":
            raw.update(self.read(PROFILE_LABELS))
            if dv_profile(raw)[1] is not None:
                raw.update(self.read(FLAG_LABELS))
                raw.update(self.read(OFFSET_LABELS))
                after_flags = self.read(FLAG_LABELS)
            else:
                after_flags = {}
            after_profiles = self.read(PROFILE_LABELS)
            same = (bool(dv_profile(raw)[1]) == bool(dv_profile(after_profiles)[1])
                    and all(raw[k] == v for k, v in after_flags.items()))
        else:
            same = True
        after_geometry = self.read(GEOMETRY_LABELS)
        same = same and geometry(raw) == geometry(after_geometry) and guard()
        return classify(raw, generation, consistent=same), raw
