"""Kodi service entry point; importing core modules never requires Kodi."""

import xbmc
import xbmcaddon

from resources.lib.runtime import Events, Service


def main():
    events = Events()

    class Player(xbmc.Player):
        def onPlayBackStarted(self):
            events.emit("started")

        def onAVStarted(self):
            events.emit("av_started")

        def onAVChange(self):
            events.emit("av_change")

        def onPlayBackSeek(self, time, seekOffset):
            events.emit("seek")

        def onPlayBackStopped(self):
            events.emit("stopped")

        def onPlayBackEnded(self):
            events.emit("ended")

        def onPlayBackError(self):
            events.emit("error")

        def onPlayBackPaused(self):
            events.emit("paused")

        def onPlayBackResumed(self):
            events.emit("resumed")

    class Monitor(xbmc.Monitor):
        def onSettingsChanged(self):
            events.emit("settings")

    player, monitor = Player(), Monitor()
    Service(xbmc, xbmcaddon.Addon(), player, monitor, events).run()


if __name__ == "__main__":
    main()
