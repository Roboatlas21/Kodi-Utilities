"""Kodi-facing lifecycle and service loop, injectable for integration tests."""

import hashlib
import math
import threading
import time
from dataclasses import dataclass

from .controller import Actuator, Controller, ViewMode
from .detection import (GEOMETRY_LABELS, POLL_INTERVAL_SECONDS, Sampler,
                        classify, finite_number, geometry, maximum)


@dataclass(frozen=True)
class Snapshot:
    serial: int
    epoch: int
    ready: object
    settings: int
    resumes: int


class Events:
    """Callbacks only update small tokens; all Kodi writes run on the service loop."""

    def __init__(self):
        self.lock = threading.Lock()
        self.serial = self.epoch = self.settings = self.resumes = 0
        self.ready = None  # Service may attach after AVStarted already happened.

    def emit(self, kind):
        with self.lock:
            self.serial += 1
            if kind in ("started", "stopped", "ended", "error", "av_started", "av_change", "seek"):
                self.epoch += 1
                self.ready = kind in ("av_started", "av_change", "seek")
            if kind == "settings":
                self.settings += 1
            if kind == "resumed":
                self.resumes += 1

    def snapshot(self):
        with self.lock:
            return Snapshot(self.serial, self.epoch, self.ready, self.settings, self.resumes)


class Logger:
    def __init__(self, xbmc, clock=time.monotonic):
        self.xbmc, self.clock = xbmc, clock
        self.debug = False
        self.previous = {}

    def __call__(self, key, message):
        now = self.clock()
        previous = self.previous.get(key)
        if previous and previous[0] == message and now - previous[1] < 60:
            return
        self.previous[key] = (message, now)
        level = self.xbmc.LOGWARNING if key in ("control_failure", "runtime_error", "settings_error") else self.xbmc.LOGINFO
        self.xbmc.log("[Adaptive Letterbox Zoom] " + message, level)

    def sample(self, signal, raw, controller, now):
        if self.debug:
            # Only the known numeric info labels are included, never playback URLs.
            clean = {k: str(v)[:32] for k, v in raw.items()}
            self.xbmc.log(
                "[Adaptive Letterbox Zoom] observed={:.3f} generation={} route={} "
                "reason={} raw={} pending={} applied={} cap={:.3f}".format(
                    now, signal.generation, signal.route, signal.reason, clean,
                    len(controller.window), controller.applied, controller.cap),
                self.xbmc.LOGINFO)


class Service:
    def __init__(self, xbmc, addon, player, monitor, events, clock=time.monotonic):
        self.xbmc, self.addon, self.player, self.monitor = xbmc, addon, player, monitor
        self.events, self.clock = events, clock
        self.log = Logger(xbmc, clock)
        self.sampler = Sampler(xbmc.getInfoLabel)
        self.controller = Controller()
        self.actuator = Actuator(ViewMode(xbmc.executeJSONRPC), self.log)
        self.enabled = True
        self.settings_version = -1
        self.context = None
        self.attached_ready = False
        self.generation = 0
        self.resume_version = -1
        self.active = False
        self.reload_settings()
        self.log("startup", "Service 0.1.1 initialized; L5 override status unverified. "
                 "Disable P3I per-folder overrides for dynamic L5 playback.")

    def reload_settings(self):
        self.enabled = self.addon.getSetting("enabled").strip().lower() != "false"
        self.log.debug = self.addon.getSetting("debug").strip().lower() == "true"
        raw = self.addon.getSetting("max_zoom_percent")
        value = finite_number(raw)
        if value is None:
            value = 115.0
            self.log("settings_error", "Invalid maximum zoom; using 115%")
        old = self.controller.cap
        self.controller.set_maximum(maximum(value / 100.0))
        if self.controller.cap < old:
            # A newly lowered cap gets an immediate attempt, even when paused.
            self.actuator.next_attempt = 0.0

    def _identity(self):
        try:
            value = self.player.getPlayingFile()
        except RuntimeError:
            return None
        if not value:
            return None
        return hashlib.sha256(value.encode("utf-8")).digest()

    def _playing(self):
        return (self.player.isPlayingVideo() and not self.player.isExternalPlayer()
                and not self.monitor.abortRequested())

    def _ready(self, snapshot):
        if snapshot.ready is False or self.xbmc.getCondVisibility("Player.Seeking"):
            return False
        try:
            position = self.player.getTime()
        except RuntimeError:
            return False
        if not math.isfinite(position) or position < 0:
            return False
        if snapshot.ready is True:
            return True
        if self.attached_ready:
            return True
        # Attach to already-running video: require usable geometry as well as a
        # functioning playback clock when no AV callback has been observed.
        self.attached_ready = geometry(self.sampler.read(GEOMETRY_LABELS)) is not None
        return self.attached_ready

    def _guard(self, snapshot, identity):
        return (self.enabled and self.events.snapshot().serial == snapshot.serial
                and self._playing() and self._identity() == identity
                and self._ready(snapshot))

    def clear(self):
        if self.active:
            self.log("session", "Playback inactive or automation disabled; sampling stopped")
        self.active = False
        self.context = None
        self.attached_ready = False
        self.generation += 1
        self.controller.reset(self.generation)
        self.actuator.reset()

    def tick(self):
        snapshot = self.events.snapshot()
        if snapshot.settings != self.settings_version:
            self.reload_settings()
            self.settings_version = snapshot.settings
        if not self.enabled or not self._playing():
            if self.context is not None or self.active:
                self.clear()
            return 1.0
        self.active = True
        identity = self._identity()
        if identity is None:
            return POLL_INTERVAL_SECONDS
        context = (snapshot.epoch, identity)
        if context != self.context:
            self.context = context
            self.attached_ready = False
            self.generation += 1
            self.controller.reset(self.generation)
            self.actuator.reset()
            self.log("session", "Playback generation {} initialized".format(self.generation))
        if snapshot.resumes != self.resume_version:
            self.controller.clear_pending()
            self.resume_version = snapshot.resumes
        if not self._ready(snapshot):
            return POLL_INTERVAL_SECONDS
        guard = lambda: self._guard(snapshot, identity)
        now = self.clock()
        self.actuator.verify(self.controller, now, guard)
        paused = self.xbmc.getCondVisibility("Player.Paused")
        signal = None
        if not paused or self.controller.needs_paused_sample:
            try:
                signal, raw = self.sampler.sample(self.generation, guard)
            except (RuntimeError, ValueError, TypeError):
                raw = {}
                signal = classify(raw, self.generation)
            if not guard():
                return POLL_INTERVAL_SECONDS
            if signal.valid and signal.geometry != self.controller.geometry:
                self.actuator.reset()
            self.log("route", "route={} reason={} geometry={}".format(
                signal.route, signal.reason, signal.geometry))
            self.log.sample(signal, raw, self.controller, now)
        decision = self.controller.update(signal, now, paused)
        self.actuator.apply(decision, self.controller, now, guard)
        return POLL_INTERVAL_SECONDS

    def run(self):
        try:
            while not self.monitor.abortRequested():
                try:
                    delay = self.tick()
                except Exception as error:
                    # Kodi can invalidate its player between any two calls.
                    # Keep the service alive; never expose exception data/URLs.
                    self.controller.clear_pending()
                    self.log("runtime_error", "Service iteration failed ({})".format(type(error).__name__))
                    delay = 1.0
                if self.monitor.waitForAbort(delay):
                    break
        finally:
            self.clear()  # No JSON-RPC writes on shutdown.
            self.log("shutdown", "Service stopped")
