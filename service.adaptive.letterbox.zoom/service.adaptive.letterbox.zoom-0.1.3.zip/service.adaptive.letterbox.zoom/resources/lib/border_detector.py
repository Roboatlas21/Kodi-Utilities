"""Optional P3I pixel-scan fallback. Never binds/applies results to native L5."""

import json
import math
from urllib.parse import urlsplit

from .controller import RpcError
from .detection import Signal, finite_number

START_DELAY = 10.0
ADMISSION_TIMEOUT = 40.0
SCAN_TIMEOUT = 120.0
POLL_INTERVAL = 1.0


def detected_signal(reply, original, streamindex):
    """Accept only invariant, matching source-pixel geometry, never subtitle bounds."""
    strict = reply.get("strict")
    geo = original.geometry
    if (reply.get("status") != "completed" or reply.get("version") != 1
            or type(reply.get("streamindex")) is not int or reply["streamindex"] < 0
            or (streamindex >= 0 and reply["streamindex"] != streamindex)
            or not isinstance(strict, dict) or strict.get("valid") is not True
            or strict.get("confidence") != "invariant"
            or strict.get("units") != "source_pixels"
            or type(strict.get("width")) is not int or strict["width"] != geo.width
            or type(strict.get("height")) is not int or strict["height"] != geo.height):
        return None
    aspect = finite_number(reply.get("displayaspect"))
    if aspect is None or abs(aspect - geo.dar) > .02:
        return None
    offsets = strict.get("offsets", {})
    if not isinstance(offsets, dict):
        return None
    values = tuple(offsets.get(side) for side in ("top", "bottom", "left", "right"))
    if any(type(v) is not int or not 0 <= v <= 65535 for v in values):
        return None
    top, bottom, left, right = values
    if (top + bottom >= geo.height or left + right >= geo.width
            or abs(top - bottom) > max(2, math.ceil(geo.height * .001))
            or max(left, right) > max(2, math.ceil(geo.width * .001))):
        return None
    return Signal(original.generation, geo, "detected_borders", "detected_borders",
                  values, eligible=True)


class BorderDetector:
    def __init__(self, execute, get_label, get_condition, log):
        self.execute, self.get_label, self.get_condition = execute, get_label, get_condition
        self.log = log
        self.sequence = 0
        self.request = None
        self.supported = None
        self.reset()

    def _rpc(self, method, params=None):
        self.sequence += 1
        request = dict(jsonrpc="2.0", id=self.sequence, method="P3I.Detector." + method)
        if params is not None:
            request["params"] = params
        try:
            reply = json.loads(self.execute(json.dumps(request, allow_nan=False)))
        except (ValueError, TypeError, RuntimeError):
            raise RpcError("detector_response") from None
        if (not isinstance(reply, dict) or reply.get("id") != self.sequence
                or reply.get("jsonrpc") != "2.0" or "error" in reply
                or not isinstance(reply.get("result"), dict)):
            raise RpcError("detector_response")
        return reply["result"]

    def cancel(self):
        request, self.request = self.request, None
        if request is not None:
            try:
                self._rpc("Cancel", {"requestid": request})
            except RpcError:
                self.log("detector", "Could not confirm detector cancellation")

    def reset(self):
        self.cancel()
        self.key = None
        self.since = None
        self.started = 0.0
        self.next_poll = 0.0
        self.selection = None
        self.result = None
        self.done = False

    def _finish(self, reason):
        self.cancel()
        self.done = True
        self.result = None
        self.log("detector", "Border scan stopped: " + reason)

    def _selection(self, geo):
        reply = self._rpc("GetPlayback")
        if (reply.get("version") != 1 or reply.get("status") != "ready"
                or reply.get("width") != geo.width or reply.get("height") != geo.height
                or type(reply.get("streamindex")) is not int or reply["streamindex"] < -1):
            return None
        ids = tuple(reply.get(k) for k in ("playbackid", "selectionid"))
        if any(not isinstance(v, str) or not v.isdigit() or len(v) > 32 for v in ids):
            return None
        return ids + (reply["streamindex"],)

    def matches(self, guard):
        """Recheck the exact native stream immediately before a detector-based write."""
        try:
            return (guard() and self.result is not None
                    and self._selection(self.key[1]) == self.selection and guard())
        except RpcError:
            return False

    def update(self, original, context, now, get_path, guard, authored_seen=False,
               allow_start=True):
        eligible = (original.valid and original.eligible
                    and original.reason == "full_frame_or_no_signal" and not authored_seen)
        key = (context, original.geometry)
        if key != self.key:
            self.reset()
            self.key = key
        if not eligible:
            self.reset()
            return original
        if self.done and self.result is None:
            return original
        if not guard():
            self.cancel()
            return original
        try:
            if self.result is not None:
                if self._selection(original.geometry) != self.selection or not guard():
                    self._finish("playback selection changed")
                    return original
                return detected_signal(self.result, original, self.selection[2]) or original
            if self.since is None:
                self.since = now
            if self.request is not None:
                if now - self.started >= SCAN_TIMEOUT:
                    self._finish("time limit")
                elif now >= self.next_poll:
                    self.next_poll = now + POLL_INTERVAL
                    if self._selection(original.geometry) != self.selection or not guard():
                        self._finish("playback selection changed")
                        return original
                    if not self._buffer_ok(50):
                        self._finish("playback needs its buffer")
                        return original
                    reply = self._rpc("GetStatus", {"requestid": self.request})
                    if reply.get("requestid") != self.request or not guard():
                        self._finish("stale result")
                    elif reply.get("status") == "completed":
                        self.request = None
                        self.done = True
                        result = detected_signal(reply, original, self.selection[2])
                        if result is not None and self._selection(original.geometry) == self.selection and guard():
                            self.result = reply
                            self.log("detector", "Invariant border scan accepted")
                            return result
                        self.log("detector", "Border scan had no reliable matching geometry")
                    elif reply.get("status") not in ("queued", "running"):
                        self._finish("unavailable or inconclusive")
                return original
            if not allow_start:
                return original
            if now - self.since >= ADMISSION_TIMEOUT:
                self._finish("no suitable scan opportunity")
                return original
            if now - self.since < START_DELAY or now < self.next_poll:
                return original
            self.next_poll = now + POLL_INTERVAL
            if not self._buffer_ok(80):
                return original
            if self.supported is None:
                caps = self._rpc("GetCapabilities")
                self.supported = (caps.get("version") == 1 and caps.get("supported") is True
                                  and caps.get("geometryresults") is True)
            if not self.supported:
                self._finish("P3I detector API unavailable")
                return original
            path = get_path()
            if not isinstance(path, str) or not path or len(path) > 32768:
                self._finish("no resolved media path")
                return original
            scheme = urlsplit(path.split("|", 1)[0]).scheme.lower()
            if scheme not in ("", "file", "http", "https", "smb", "nfs"):
                self._finish("unsupported media path")
                return original
            self.selection = self._selection(original.geometry)
            if self.selection is None or not guard():
                return original
            reply = self._rpc("Start", {"path": path, "options": {
                "streamindex": self.selection[2], "allowhttp": False}})
            request = reply.get("requestid")
            if (reply.get("status") == "accepted" and isinstance(request, str)
                    and request.isdigit() and len(request) <= 32):
                # Capture ownership before the post-call guard, so a start/stop race
                # can cancel this job without touching another add-on's scanner.
                self.request = request
                self.started = now
                if not guard():
                    self._finish("playback changed during scan start")
                else:
                    self.log("detector", "Standalone border scan started; native L5 unchanged")
            else:
                self._finish("scanner unavailable or input excluded")
        except (RpcError, RuntimeError, ValueError, TypeError):
            self._finish("detector request failed")
        return original

    def _buffer_ok(self, minimum):
        if self.get_condition("Player.Caching"):
            return False
        level = finite_number(self.get_label("Player.CacheLevel"))
        return level is None or minimum <= level <= 100

    def paused(self, now):
        # No new scans or zoom-in while paused. Do not leave an owned job running
        # indefinitely merely because the ordinary metadata sampler is suspended.
        if self.request is not None and now - self.started >= SCAN_TIMEOUT:
            self._finish("time limit")
