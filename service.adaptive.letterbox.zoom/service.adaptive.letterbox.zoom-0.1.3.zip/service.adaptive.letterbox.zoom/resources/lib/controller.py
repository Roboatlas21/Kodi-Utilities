"""Deterministic zoom decisions and JSON-RPC transport; no Kodi imports."""

import json
from dataclasses import dataclass

from .detection import BAR_ROUTES, L5_JITTER_TOLERANCE_PX, finite_number, maximum, zoom_value

INVALID_SIGNAL_GRACE_SECONDS = 0.60
ZOOM_WRITE_EPSILON = 0.005
L5_ZOOM_OUT_POLLS = 2
L5_ZOOM_IN_POLLS = 3


@dataclass(frozen=True)
class Decision:
    target: float
    reason: str


class Controller:
    """Each decision is authorized by this tick, never an old retry queue."""

    def __init__(self, cap=1.15):
        self.cap = maximum(cap)
        self.reset(0)

    def reset(self, generation):
        self.generation = generation
        self.applied = None
        self.window = []
        self.invalid_since = None
        self.geometry = None
        self.usable_l5_seen = False

    def clear_pending(self):
        self.window = []

    def set_maximum(self, value):
        value = maximum(value)
        if value != self.cap:
            self.clear_pending()
        self.cap = value

    def confirm(self, target):
        self.applied = zoom_value(target, self.cap)

    @property
    def needs_paused_sample(self):
        return self.applied is None or bool(
            self.window and self.window[0].target(self.cap) < self.applied)

    def _decision(self, target, reason):
        target = zoom_value(target, self.cap)
        if (self.applied is None or self.applied > self.cap
                # A confirmed smaller ceiling must win even below the epsilon.
                or target < self.applied - 1e-12
                or abs(target - self.applied) + 1e-12 >= ZOOM_WRITE_EPSILON):
            return Decision(target, reason)
        return None

    def _append(self, signal):
        if len(self.window) >= L5_ZOOM_IN_POLLS:
            self.clear_pending()
        compatible = bool(self.window and self.window[0].key == signal.key)
        if compatible and signal.route in BAR_ROUTES:
            compatible = all(abs(a - b) <= L5_JITTER_TOLERANCE_PX
                             for a, b in zip(self.window[0].offsets, signal.offsets))
        # Safe routes never use offsets for zoom. Their reason/flags must agree,
        # but a noisy synthetic detector cannot indefinitely block zooming OUT.
        if not compatible:
            self.window = []
        self.window.append(signal)

    def update(self, signal, now, paused=False):
        if signal is not None and signal.generation != self.generation:
            return None
        if signal is not None and signal.valid and signal.geometry != self.geometry:
            self.geometry = signal.geometry
            self.applied = None
            self.clear_pending()
            self.invalid_since = None
        if signal is not None:
            if not signal.valid:
                self.clear_pending()
                if self.invalid_since is None:
                    self.invalid_since = now
            else:
                self.invalid_since = None
                self._append(signal)
                self.usable_l5_seen |= signal.route == "l5"

        if self.applied is not None and self.applied > self.cap:
            return Decision(float(self.cap), "maximum_reduced")
        if self.applied is None:
            target = signal.target(self.cap) if signal and signal.route == "native_dar" else 1.0
            return Decision(float(target), "initial_application")
        if (self.invalid_since is not None
                and now - self.invalid_since + 1e-9 >= INVALID_SIGNAL_GRACE_SECONDS):
            return self._decision(1.0, "invalid_signal_timeout")
        if signal is None or not signal.valid:
            return None
        if signal.route in ("native_dar", "narrow_content"):
            self.clear_pending()
            return self._decision(signal.target(self.cap), signal.reason)
        bar = min(s.safe_bar for s in self.window) if signal.route in BAR_ROUTES else 0
        target = signal.target(self.cap, safe_bar=bar)
        increasing = target > self.applied
        needed = L5_ZOOM_IN_POLLS if increasing else L5_ZOOM_OUT_POLLS
        if len(self.window) < needed:
            return None
        self.clear_pending()
        if paused and increasing:
            return None
        return self._decision(target, signal.reason)


class RpcError(Exception):
    """An unusable response without logging arbitrary response contents."""


class ViewMode:
    def __init__(self, execute):
        self.execute = execute
        self.sequence = 0

    def _call(self, method, params, guard):
        if not guard():
            raise RpcError("playback_changed")
        self.sequence += 1
        request = {"jsonrpc": "2.0", "id": self.sequence, "method": method}
        if params is not None:
            request["params"] = params
        try:
            result = json.loads(self.execute(json.dumps(request, allow_nan=False)))
        except (ValueError, TypeError, RuntimeError):
            raise RpcError("invalid_response") from None
        if (not isinstance(result, dict) or result.get("id") != self.sequence
                or result.get("jsonrpc") != "2.0" or "error" in result
                or "result" not in result):
            raise RpcError("rpc_failure")
        if not guard():
            raise RpcError("playback_changed")
        return result["result"]

    def set(self, target, cap, guard):
        fields = {"zoom": float(zoom_value(target, cap)), "pixelratio": 1.0,
                  "verticalshift": 0.0, "nonlinearstretch": False}
        if self._call("Player.SetViewMode", {"viewmode": fields}, guard) != "OK":
            raise RpcError("unexpected_ack")
        return fields["zoom"]

    def matches(self, target, guard):
        result = self._call("Player.GetViewMode", None, guard)
        if not isinstance(result, dict) or result.get("viewmode") != "custom":
            return False
        for name, expected in (("zoom", target), ("pixelratio", 1.0), ("verticalshift", 0.0)):
            value = result.get(name)
            if (type(value) not in (int, float) or finite_number(value) is None
                    or abs(value - expected) > 0.0001):
                return False
        return result.get("nonlinearstretch") is False


class Actuator:
    """Back off errors and verify initialization without polling view mode forever."""

    def __init__(self, view, log):
        self.view, self.log = view, log
        self.reset()

    def reset(self):
        self.failures = 0
        self.next_attempt = 0.0
        self.verify_target = None
        self.verify_after = 0.0
        self.verified = False  # saved pre-playback settings are not manual input

    def failed(self, now, reason):
        delay = (0.2, 0.5, 1.0, 2.0)[min(self.failures, 3)]
        self.failures += 1
        self.next_attempt = now + delay
        self.log("control_failure", "{}; retry in {:.1f}s".format(reason, delay))

    def verify(self, controller, now, guard):
        if self.verify_target is None or now + 1e-9 < self.verify_after:
            return
        target, self.verify_target = self.verify_target, None
        try:
            good = self.view.matches(target, guard)
        except RpcError:
            good = False
        if not good:
            self.verified = False
            controller.applied = None
            controller.clear_pending()
            self.failed(now, "initial_readback_failed")
        else:
            self.verified = True
            self.failures = 0
            self.next_attempt = 0.0
            self.log("verified", "Initial custom view mode verified")

    def apply(self, decision, controller, now, guard):
        if decision is None or now + 1e-9 < self.next_attempt or not guard():
            return
        first = controller.applied is None
        try:
            target = self.view.set(decision.target, controller.cap, guard)
        except RpcError as error:
            self.failed(now, str(error))
            return
        controller.confirm(target)
        # Do not clear failure count until initial readback succeeds: otherwise
        # ACK/readback mismatches would defeat backoff indefinitely.
        if first:
            self.verify_target, self.verify_after = target, now + 0.2
        else:
            self.failures, self.next_attempt = 0, 0.0
            if self.verify_target is not None:
                self.verify_target, self.verify_after = target, now + 0.2
        self.log("applied", "zoom={:.3f} reason={}".format(target, decision.reason))
