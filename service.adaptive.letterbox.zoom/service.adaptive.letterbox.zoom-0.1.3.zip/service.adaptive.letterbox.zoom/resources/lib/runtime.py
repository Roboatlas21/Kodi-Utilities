"""Kodi-facing lifecycle and service loop, injectable for integration tests."""

import hashlib
import math
import threading
import time
from dataclasses import dataclass

from .controller import Actuator, Controller, RpcError, ViewMode
from .border_detector import BorderDetector
from .detection import (GEOMETRY_LABELS, POLL_INTERVAL_SECONDS, Sampler,
                        classify, finite_number, geometry, maximum)


@dataclass(frozen=True)
class Snapshot:
    serial: int
    epoch: int
    ready: object
    settings: int
    resumes: int


MANUAL_CHECK_INTERVAL_SECONDS = 1.0


class Events:
    """Callbacks only update small tokens; all Kodi writes run on the service loop."""

    def __init__(self):
        self.lock = threading.Lock()
        self.serial = self.epoch = self.settings = self.resumes = 0
        self.ready = None  # Service may attach after AVStarted already happened.

    def emit(self, kind):
        # P3I can send AVChange repeatedly while updating frame metadata.
        # Such callbacks do not identify a new video or invalidate L5 samples.
        # The sampler detects real DAR/dimension changes directly.
        if kind == "av_change":
            return
        with self.lock:
            if kind == "av_started" and self.ready is True:
                return  # duplicate ready notification, not a new generation
            self.serial += 1
            if kind in ("started", "stopped", "ended", "error", "av_started", "seek"):
                self.epoch += 1
                self.ready = kind in ("av_started", "seek")
            if kind == "settings":
                self.settings += 1
            if kind == "resumed":
                self.resumes += 1

    def snapshot(self):
        with self.lock:
            return Snapshot(self.serial, self.epoch, self.ready, self.settings, self.resumes)


class Logger:
    def __init__(self, xbmc, clock=time.monotonic):
        self.xbmc, self.clock = xbmc, clock
        self.debug = False
        self.previous = {}

    def __call__(self, key, message):
        now = self.clock()
        previous = self.previous.get(key)
        if previous and previous[0] == message and now - previous[1] < 60:
            return
        self.previous[key] = (message, now)
        level = self.xbmc.LOGWARNING if key in ("control_failure", "runtime_error", "settings_error") else self.xbmc.LOGINFO
        self.xbmc.log("[Adaptive Letterbox Zoom] " + message, level)

    def sample(self, signal, raw, controller, now):
        if self.debug:
            # Only the known numeric info labels are included, never playback URLs.
            clean = {k: str(v)[:32] for k, v in raw.items()}
            self.xbmc.log(
                "[Adaptive Letterbox Zoom] observed={:.3f} generation={} route={} "
                "reason={} raw={} pending={} applied={} cap={:.3f}".format(
                    now, signal.generation, signal.route, signal.reason, clean,
                    len(controller.window), controller.applied, controller.cap),
                self.xbmc.LOGINFO)


class Service:
    def __init__(self, xbmc, addon, player, monitor, events, clock=time.monotonic):
        self.xbmc, self.addon, self.player, self.monitor = xbmc, addon, player, monitor
        self.events, self.clock = events, clock
        self.log = Logger(xbmc, clock)
        self.sampler = Sampler(xbmc.getInfoLabel)
        self.controller = Controller()
        self.actuator = Actuator(ViewMode(xbmc.executeJSONRPC), self.log)
        self.detector = BorderDetector(xbmc.executeJSONRPC, xbmc.getInfoLabel,
                                       xbmc.getCondVisibility, self.log)
        self.detect_missing_l5 = False
        self.authored_l5_seen = False
        self.enabled = True
        self.settings_version = -1
        self.context = None
        self.attached_ready = False
        self.generation = 0
        self.resume_version = -1
        self.active = False
        self.manual_hold = False
        self.next_manual_check = 0.0
        self.reload_settings()
        self.log("startup", "Service 0.1.3 initialized; L5 override status unverified. "
                 "Disable P3I per-folder overrides for dynamic L5 playback.")

    def reload_settings(self):
        self.enabled = self.addon.getSetting("enabled").strip().lower() != "false"
        detect = self.addon.getSetting("detect_missing_l5").strip().lower() == "true"
        if detect != self.detect_missing_l5:
            if self.detector.result is not None and not self.manual_hold:
                # Re-evaluate the fallback even while paused when it is disabled.
                self.controller.applied = None
                self.controller.clear_pending()
                self.actuator.reset()
            self.detector.reset()
        self.detect_missing_l5 = detect
        self.log.debug = self.addon.getSetting("debug").strip().lower() == "true"
        raw = self.addon.getSetting("max_zoom_percent")
        value = finite_number(raw)
        if value is None:
            value = 115.0
            self.log("settings_error", "Invalid maximum zoom; using 115%")
        old = self.controller.cap
        self.controller.set_maximum(maximum(value / 100.0))
        if self.controller.cap < old:
            # A newly lowered cap gets an immediate attempt, even when paused.
            self.actuator.next_attempt = 0.0

    def _identity(self):
        try:
            value = self.player.getPlayingFile()
        except RuntimeError:
            return None
        if not value:
            return None
        return hashlib.sha256(value.encode("utf-8")).digest()

    def _playing(self):
        return (self.player.isPlayingVideo() and not self.player.isExternalPlayer()
                and not self.monitor.abortRequested())

    def _ready(self, snapshot):
        if self.xbmc.getCondVisibility("Player.Seeking"):
            return False
        try:
            position = self.player.getTime()
        except RuntimeError:
            return False
        if not math.isfinite(position) or position < 0:
            return False
        if snapshot.ready is True or self.attached_ready:
            return True
        # If AVStarted was missed, detect an already-running video from its
        # advancing clock and reported geometry. Initial startup remains gated.
        if snapshot.ready is False and position < 0.5:
            return False
        self.attached_ready = geometry(self.sampler.read(GEOMETRY_LABELS)) is not None
        return self.attached_ready

    def _guard(self, snapshot, identity):
        return (self.enabled and self.events.snapshot().serial == snapshot.serial
                and self._playing() and self._identity() == identity
                and self._ready(snapshot))

    def clear(self):
        self.detector.reset()
        self.authored_l5_seen = False
        if self.active:
            self.log("session", "Playback inactive or automation disabled; sampling stopped")
        self.active = False
        self.context = None
        self.attached_ready = False
        self.manual_hold = False
        self.next_manual_check = 0.0
        self.generation += 1
        self.controller.reset(self.generation)
        self.actuator.reset()

    def _check_manual(self, now, guard, force=False):
        """Suspend automatic control when a user changes the verified zoom."""
        if (self.manual_hold or self.controller.applied is None
                or not self.actuator.verified or self.actuator.verify_target is not None):
            return
        if not force and now < self.next_manual_check:
            return
        self.next_manual_check = now + MANUAL_CHECK_INTERVAL_SECONDS
        try:
            matches = self.actuator.view.matches(self.controller.applied, guard)
        except RpcError:
            return  # failed readback does not imply manual intervention
        if not matches and guard():
            self.manual_hold = True
            self.detector.reset()
            self.controller.clear_pending()
            self.log("manual", "Manual zoom/view-mode detected; automation suspended "
                     "for this movie until a new item or add-on re-enable")

    def tick(self):
        snapshot = self.events.snapshot()
        if snapshot.settings != self.settings_version:
            self.reload_settings()
            self.settings_version = snapshot.settings
        if not self.enabled or not self._playing():
            if self.context is not None or self.active:
                self.clear()
            return 1.0
        self.active = True
        identity = self._identity()
        if identity is None:
            return POLL_INTERVAL_SECONDS
        context = (snapshot.epoch, identity)
        if context != self.context:
            self.detector.reset()
            # Manual priority survives seeks and AVStarted within this item.
            if self.context is None or self.context[1] != identity:
                self.authored_l5_seen = False
                self.manual_hold = False
                self.next_manual_check = 0.0
            self.context = context
            self.attached_ready = False
            self.generation += 1
            self.controller.reset(self.generation)
            self.actuator.reset()
            self.log("session", "Playback generation {} initialized".format(self.generation))
        if snapshot.resumes != self.resume_version:
            self.controller.clear_pending()
            self.resume_version = snapshot.resumes
        if not self._ready(snapshot):
            return POLL_INTERVAL_SECONDS
        if self.manual_hold:
            return 1.0  # hands off the user's view mode; still handles lifecycle
        guard = lambda: self._guard(snapshot, identity)
        now = self.clock()
        self.actuator.verify(self.controller, now, guard)
        self._check_manual(now, guard)
        if self.manual_hold:
            return 1.0
        paused = self.xbmc.getCondVisibility("Player.Paused")
        if paused:
            self.detector.paused(now)
        signal = None
        if not paused or self.controller.needs_paused_sample:
            try:
                signal, raw = self.sampler.sample(self.generation, guard)
            except (RuntimeError, ValueError, TypeError):
                raw = {}
                signal = classify(raw, self.generation)
            if not guard():
                return POLL_INTERVAL_SECONDS
            self.authored_l5_seen |= signal.route == "l5"
            if self.detect_missing_l5 and self.controller.cap > 1.0:
                signal = self.detector.update(signal, context, now,
                                              self.player.getPlayingFile, guard,
                                              self.authored_l5_seen,
                                              allow_start=not paused)
                if not guard():
                    return POLL_INTERVAL_SECONDS
            elif self.detector.key is not None:
                self.detector.reset()
            if signal.valid and signal.geometry != self.controller.geometry:
                self.actuator.reset()
            self.log("route", "route={} reason={} geometry={}".format(
                signal.route, signal.reason, signal.geometry))
            self.log.sample(signal, raw, self.controller, now)
        decision = self.controller.update(signal, now, paused)
        if decision is not None:
            # Also catch a manual change just before an automatic scene write.
            self._check_manual(now, guard, force=True)
        if not self.manual_hold:
            write_guard = (lambda: self.detector.matches(guard)) if (
                signal is not None and signal.route == "detected_borders") else guard
            self.actuator.apply(decision, self.controller, now, write_guard)
        return POLL_INTERVAL_SECONDS

    def run(self):
        try:
            while not self.monitor.abortRequested():
                try:
                    delay = self.tick()
                except Exception as error:
                    # Kodi can invalidate its player between any two calls.
                    # Keep the service alive; never expose exception data/URLs.
                    self.controller.clear_pending()
                    self.log("runtime_error", "Service iteration failed ({})".format(type(error).__name__))
                    delay = 1.0
                if self.monitor.waitForAbort(delay):
                    break
        finally:
            self.clear()  # Only cancel an owned scan; never reset zoom or native L5.
            self.log("shutdown", "Service stopped")
