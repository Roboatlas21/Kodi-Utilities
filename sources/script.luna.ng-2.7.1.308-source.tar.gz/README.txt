Luna NG 2.7.1.308 for CoreELEC 21 NG ARM32, with optional VFM runtime.

This archive contains the exact exported Moonlight and Luna sources, recursive
Moonlight common-code submodules, controller mappings, release-ID transform,
private FFmpeg recipe/nonblocking patch, VFM bridge source, stock CoreELEC build
recipes and patches, stock media module sources, FFmpeg 8.1.2 upstream source,
and libdrm 2.4.120 upstream source. The complete CoreELEC and FFmpeg archives
are supplied as checksummed parts beside this archive in the public repository.
Run python3 upstream/download-sources.py to retrieve and reassemble them.
See SOURCE_PROVENANCE.json for pinned commits
and archive checksums; build-inputs contains the successful build's manifests.
No private Git history or credentials are included.

The stock Linux base is publicly available at the exact recorded revision:
https://github.com/pannal/linux-amlogic/archive/2d0e0cc0db958d8d88f76407ac922f08d9a4004e.tar.gz
Browse the complete kernel source:
https://github.com/pannal/linux-amlogic/tree/2d0e0cc0db958d8d88f76407ac922f08d9a4004e
The kernel source is obtained from that public URL, not embedded in this archive.
Its CoreELEC patches and build configuration are in upstream/CoreELEC-872edca.tar.gz.
The bundled modules use that source and stock CE patches, plus the bridge code
in moonlight-embedded/kernel/moonlight-vfm. The full OS image is not installed.

For the native build use moonlight-embedded/docs/experimental-vfm.md and the
pinned dependencies in build-inputs/source-lock.json. The FFmpeg source archive
is pristine n8.1.2; the CoreELEC DRM PRIME patch and Moonlight nonblocking patch
must both be applied as specified by the build recipes. Stock media modules
also use the patches from the included CoreELEC recipes.

To reproduce this launcher update, follow the .308 instructions in
release-tooling/LUNA_NG_PUBLISHING.md. Reuse the complete .307 ARM32/VFM
artifact, overlay the three named recovery scripts from this Luna export,
then apply the Kodi-ID/version transform. Native objects and manifests are
unchanged. Original native build inputs retain their original revisions.

This update uses BusyBox-compatible bounded locking and handles CoreELEC's
empty framebuffer blank readback. A stopped session's old framebuffer-only
pending record can retire once Kodi owns the display, without display writes.

The AML decoder explicitly selects frame mode for the requested display route,
resumes its initialization pause, and exits after ten continuous seconds without
a complete accepted video unit so normal Luna cleanup can restore Kodi. The
stall guard detects failed submissions, not actual pictures on the display.
AML playback was confirmed on .307. Physical .308 recovery and VFM testing remain pending.

The source regressions execute the production setup and submission paths with
simulated hardware, including failures, partial writes, full queues, EAGAIN,
and recovery after transient back-pressure. Local test adapters and diagnostic
logs are excluded from this source archive. SOURCE_PROVENANCE.json and
build-inputs identify the native build, source revisions, and packaged artifacts.
