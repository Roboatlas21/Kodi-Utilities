"""Guard private build provenance, manual gating and artifact handoff."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / '.github/workflows/coreelec-ng-native.yml'
KEY = ROOT / 'packaging/coreelec-ng/native-dependency-key.py'


class PrivateNativeWorkflowTests(unittest.TestCase):
    def test_native_is_manual_and_requires_explicit_expensive_build_opt_in(self):
        source = WORKFLOW.read_text(encoding='utf-8')
        self.assertIn('  workflow_dispatch:', source)
        self.assertIn('  workflow_call:', source)
        self.assertNotIn('  push:', source)
        self.assertIn('if: ${{ inputs.build_native == true }}', source)
        self.assertIn('cancel-in-progress: false', source)

    def test_build_is_pinned_to_preflight_source_not_caller_sha(self):
        source = WORKFLOW.read_text(encoding='utf-8')
        self.assertIn('moonlight_sha: ${{ steps.source.outputs.sha }}', source)
        self.assertIn('ref: ${{ needs.prepare.outputs.moonlight_sha }}', source)
        self.assertIn('SOURCE_GIT_SHA: ${{ needs.prepare.outputs.moonlight_sha }}',
                      source)
        self.assertNotIn('SOURCE_GIT_SHA: ${{ github.sha }}', source)

    def test_all_current_host_regressions_gate_the_compiler(self):
        source = WORKFLOW.read_text(encoding='utf-8')
        for group in ('source', 'host', 'vfm', 'audio'):
            self.assertIn(f'bash tests/validate_private_source.sh {group}', source)
        self.assertIn('native:\n    needs: prepare', source)
        self.assertIn('name: coreelec-ng-preflight-logs', source)
        self.assertIn("bash tests/validate_private_source.sh extras", source)
        self.assertIn("steps.source_extra.outcome", source)
        self.assertIn('Report every host group and prohibit unsafe ARM32 builds',
                      source)
        for step in ('source_guard', 'dependencies', 'source_recipe',
                     'host_suite', 'vfm', 'audio'):
            self.assertIn(f'steps.{step}.outcome', source)
        runner = (ROOT / 'tests/run_private_host_checks.sh').read_text()
        self.assertIn('SOURCE_CHECK_FAIL', runner)
        self.assertIn('run_checked "unit-$name"', runner)
        self.assertIn('host-results.tsv', runner)
        self.assertIn('while IFS="$tab" read -r label result status log; do', runner)
        self.assertEqual(runner.count('while IFS="$tab" read -r label result status log; do'), 1)
        self.assertTrue(runner.rstrip().endswith('echo "PASS: private host regressions (full ARM32 build still required)"'))
        self.assertNotIn('while IFS=\n', runner)
        validator = (ROOT / 'tests/validate_private_source.sh').read_text()
        self.assertIn('run_checked host_runner_syntax bash -n tests/run_private_host_checks.sh', validator)
        import subprocess
        subprocess.run(['bash', '-n', str(ROOT / 'tests/run_private_host_checks.sh')],
                       check=True, capture_output=True, text=True)
        self.assertIn('bash tests/run_private_host_checks.sh', validator)
        self.assertIn('bash tests/test_vfm_host.sh', validator)
        self.assertIn('bash tests/test_alsa_bounded_write.sh', validator)
        self.assertIn('bash tests/test_stream_diagnostics.sh', validator)

    def test_native_run_title_encodes_source_and_dispatch_id(self):
        source = WORKFLOW.read_text(encoding='utf-8')
        self.assertIn('run-name: "CoreELEC21-NG source=', source)
        self.assertIn('correlation=', source)
        self.assertIn('dispatch_correlation:', source)
        self.assertIn('EXPECTED_NATIVE_SOURCE_SHA', source)
        self.assertIn('DISPATCH_CORRELATION', source)
        self.assertIn("ref: ${{ inputs.native_source_sha || github.sha }}", source)

    def test_cache_restores_compiler_first_and_reports_checkpoint_contents(self):
        source = WORKFLOW.read_text(encoding='utf-8')
        self.assertLess(source.index('name: Restore ARM32 toolchain checkpoint'),
                        source.index('name: Restore completed dependency checkpoint'))
        self.assertIn('toolchain-discovery.py', source)
        self.assertIn('name: coreelec-ng-build-logs', source)
        self.assertNotIn('steps.half-cache.', source)
        self.assertIn('env.MOONLIGHT_BUILD_VFM', source)

    def test_source_check_and_native_gate_share_extra_test_inventory(self):
        script = (ROOT / 'tests/validate_private_source_extras.sh').read_text()
        checks = (ROOT / '.github/workflows/coreelec-ng-checks.yml').read_text()
        validator = (ROOT / 'tests/validate_private_source.sh').read_text()
        for number in range(12, 33):
            name = f'check{number:02d}'
            self.assertIn(f'{name})', script)
            self.assertIn(
                f'run: bash tests/validate_private_source_extras.sh {name}',
                checks,
            )
        self.assertIn('bash tests/validate_private_source_extras.sh all',
                      validator)
        self.assertIn('SOURCE_CHECK_FAIL', script)


    def test_stale_public_snapshot_cannot_silently_package_luna(self):
        source = WORKFLOW.read_text(encoding='utf-8')
        self.assertNotIn('Luna_public_export', source)
        self.assertNotIn('repository: Roboatlas21/xbmc-p3i', source)
        self.assertNotIn('luna_source.outputs.compatible', source)
        self.assertIn('name: moonlight-coreelec21-ng-arm32', source)
        self.assertIn('name: moonlight-coreelec21-ng-vfm-runtime', source)
        self.assertIn('private Kodi-Utilities-Source release workflow', source)

    def test_dependency_key_excludes_luna_package_snapshot_pins(self):
        source = KEY.read_text(encoding='utf-8')
        self.assertIn('SOURCE_KEYS = ("CoreELEC"', source)
        self.assertNotIn('"Luna", "Luna_public_export"', source)
        self.assertIn('missing = ', source)


if __name__ == '__main__':
    unittest.main()
