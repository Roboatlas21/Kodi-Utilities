"""Source-level contracts for generic rumble and native Steam safe fallbacks."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


def section(source, start, end):
    a = source.index(start)
    return source[a:source.index(end, a + len(start))]


class RumbleSafetyWiringTests(unittest.TestCase):
    def test_generic_rumble_requires_exact_linux_ff_support(self):
        evdev = (ROOT / "src/input/evdev.c").read_text(encoding="utf-8")
        probe = section(evdev, "static bool evdev_supports_rumble(",
                        "static void send_controller_arrival(")
        arrival = section(evdev, "static void send_controller_arrival(",
                          "static bool evdev_handle_event(")
        rumble = section(evdev, "void evdev_rumble(", "void evdev_set_motion_event_state(")
        self.assertIn("libevdev_has_event_type(device, EV_FF)", probe)
        self.assertIn("libevdev_has_event_code(device, EV_FF, FF_RUMBLE)", probe)
        self.assertIn("if (evdev_supports_rumble(dev->dev))", arrival)
        self.assertIn("capabilities |= LI_CCAP_RUMBLE;", arrival)
        self.assertNotIn("// TODO: Probe for this properly", arrival)
        self.assertIn("capabilities |= dualsense_capabilities(dev->dualsense);", arrival)
        self.assertIn("!evdev_supports_rumble(device->dev)", rumble)
        self.assertIn("evdev_ff_get_locked(device)", rumble)
        self.assertIn("pthread_mutex_lock(&device->ff_mutex)", rumble)
        self.assertIn("pthread_mutex_unlock(&devices_mutex);", rumble)
        self.assertIn("evdev_ff_put(device);", rumble)
        self.assertLess(rumble.index("!evdev_supports_rumble(device->dev)"),
                        rumble.index("effect.type = FF_RUMBLE;"))

    def test_steam_rumble_callback_returns_ownership_not_queue_success(self):
        source = (ROOT / "src/input/steam_controller_2026.c").read_text(
            encoding="utf-8")
        connection = (ROOT / "src/connection.c").read_text(encoding="utf-8")
        callback = section(source, "bool sc26_rumble_host(", "bool sc26_motion_host(")
        self.assertIn("const bool owned=l!=NULL;", callback)
        self.assertIn("return owned;", callback)
        self.assertNotIn("return accepted;", callback)
        self.assertIn("const bool accepted=enqueue(", callback)
        self.assertIn("if(accepted){", callback)
        self.assertIn("} else if(stop){", callback)
        self.assertIn("l->queue_overflow=true;", callback)
        self.assertIn("l->haptic_failed=true;", callback)
        self.assertIn("if(notify)wake_service();", callback)
        self.assertIn("if (sc26_rumble_host(controllerNumber,lowFreqMotor,highFreqMotor))return;", connection)

    def test_native_haptic_stop_failure_uses_safe_handoff(self):
        source = (ROOT / "src/input/steam_controller_2026.c").read_text(
            encoding="utf-8")
        haptic = section(source, "void sc26_haptic_host(", "void sc26_settings_host(")
        service = section(source, "static void service(", "static int wake_event(")
        teardown = section(source, "static void close_link(", "static void feature_query(")
        self.assertIn("const bool stop=sc26_haptic_is_stop(report,length);", haptic)
        self.assertIn("if(accepted){", haptic)
        self.assertIn("} else if(stop){", haptic)
        self.assertIn("l->haptic_failed=true;", haptic)
        self.assertIn("l->queue_overflow=true;", haptic)
        self.assertIn("if(notify)wake_service();", haptic)
        self.assertIn("if(!enqueue(l,zero,10,false,true))", service)
        # The service now serializes a pending HID command ahead of the
        # queue so a transient write failure cannot reorder BLE reset and
        # re-enable packets. Check that bounded ordering and handoff remain.
        self.assertIn("if(!l->haptic_failed && !l->keepalive_queued &&", service)
        self.assertIn("if(enqueue(l,setting,sizeof(setting),true,true))", service)
        self.assertIn("l->queue[l->queue_count-1].keepalive=true;", service)
        self.assertIn("if(item.keepalive)", service)
        self.assertIn("while(!l->haptic_failed &&", service)
        self.assertIn("(l->pending_valid || l->queue_count) &&", service)
        self.assertIn("writes++<SC26_HID_WRITE_LIMIT", service)
        self.assertIn("l->pending_output=l->queue[0];", service)
        self.assertIn("l->pending_valid=true;", service)
        self.assertIn("const Sc26Output item=l->pending_output;", service)
        self.assertIn("if(++l->pending_attempts>=3)", service)
        self.assertIn("l->queue_count=0;", service)
        self.assertIn("l->pending_valid=false;", service)
        self.assertIn("close_link(l,true);", service)
        self.assertIn("stop_effects(l);", teardown)
        self.assertIn("udev_rescan_inputs();", teardown)

    def test_pulse_stop_detection_documents_on_off_repeat_layout(self):
        header = (ROOT / "src/input/steam_controller_2026_protocol.h").read_text(
            encoding="utf-8")
        self.assertIn("ON duration", header)
        self.assertIn("repeat count", header)
        self.assertIn("OR zero repeats", header)
        self.assertIn(
            "if(p[0]==SC26_REPORT_PULSE) return (!p[2]&&!p[3])||(!p[6]&&!p[7]);",
            header)


if __name__ == "__main__":
    unittest.main()
