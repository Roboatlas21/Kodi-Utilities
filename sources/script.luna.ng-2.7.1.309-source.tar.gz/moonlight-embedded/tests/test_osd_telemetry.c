/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include "../src/osd/telemetry.h"
#include "../src/osd/decode.h"
#include "../src/osd/layout.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static char root[128];
static bool connected_peer_available;
bool LiGetLunaConnectedPeerV1(struct sockaddr_storage *out, uint32_t size) {
  if (!connected_peer_available || !out || size != sizeof(*out)) return false;
  struct sockaddr_in *ip = (struct sockaddr_in *)out;
  memset(out, 0, sizeof(*out));
  ip->sin_family = AF_INET;
  ip->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  return true;
}
/* Netlink interface enumeration is forbidden in some host sandboxes. Keep
 * the route selection's local-address matching deterministic in this test. */
int __wrap_getifaddrs(struct ifaddrs **out) {
  static struct sockaddr_in address;
  static struct ifaddrs iface;
  address.sin_family=AF_INET;address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
  iface.ifa_name="lo";iface.ifa_addr=(struct sockaddr *)&address;
  *out=&iface;return 0;
}
void __wrap_freeifaddrs(struct ifaddrs *out) {(void)out;}
static const char *fixture(const char *path) {
  if (!strcmp(path,"/sys/class/mpgpu/utilization")) return "gpu";
  if (!strcmp(path,"/sys/class/thermal/thermal_zone1/temp")) return "temp";
  if (!strcmp(path,"/sys/class/display/mode")) return "hdmi";
  if (!strcmp(path,"/sys/class/video/vframe_states")) return "queue";
  if (!strcmp(path,"/tmp/moonlight-osd-note")) return "note";
  if (!strcmp(path,"/sys/class/net/lo/statistics/rx_bytes")) return "rx";
  if (!strcmp(path,"/sys/class/net/lo/statistics/rx_errors")) return "err";
  if (!strcmp(path,"/sys/class/net/lo/statistics/rx_dropped")) return "drop";
  return NULL;
}
int __real_open(const char *,int,...);
FILE *__real_fopen(const char *,const char *);
int __wrap_open(const char *path,int flags,...) {
  char mapped[256]; const char *f=fixture(path);
  if (!f) {errno=ENOENT;return -1;}
  snprintf(mapped,sizeof(mapped),"%s/%s",root,f);
  return __real_open(mapped,flags);
}
FILE *__wrap_fopen(const char *path,const char *mode) {
  char mapped[256]; const char *f=fixture(path);
  if (!f) {errno=ENOENT;return NULL;}
  snprintf(mapped,sizeof(mapped),"%s/%s",root,f);
  return __real_fopen(mapped,mode);
}
static void put(const char *name,const char *value) {
  char path[256]; snprintf(path,sizeof(path),"%s/%s",root,name);
  FILE *f=__real_fopen(path,"w");assert(f);assert(fputs(value,f)>=0);fclose(f);
}
static unsigned ioctl_calls;
static bool bad_ioctl;
int __wrap_ioctl(int fd,unsigned long request,...) {
  assert(fd==99 && request==0x800453cbUL);
  va_list args;va_start(args,request);
  OsdNgDecodeInfo *info=va_arg(args,OsdNgDecodeInfo *);va_end(args);
  assert(info->size==1192 && info->id==0);
  info->slots=bad_ioctl ? 9 : (++ioctl_calls==1 ? 8 : 2);
  for (int i=0;i<info->slots && i<8;i++)
    info->frames[i]=(OsdNgDecodeFrame){.width=1920,.height=1080,
                                       .decode_ns=ioctl_calls==1 ? 800000 : 1200000};
  return 0;
}
static int setup_result, audio_result, submitted, played;
static int setup(int format,int w,int h,int fps,void *ctx,int flags) {
  assert(format==VIDEO_FORMAT_H265 && w==1920 && h==1080 && fps==60);
  assert(ctx==(void *)1 && flags==123);return setup_result;
}
static int submit(PDECODE_UNIT du) { assert(du);++submitted;return DR_NEED_IDR; }
static int init(int config,const POPUS_MULTISTREAM_CONFIGURATION opus,void *ctx,int flags) {
  assert(config==7 && ctx==(void *)2 && flags==456 && opus->channelCount==6);
  return audio_result;
}
static void play(char *data,int n) {assert(data==(char *)3 && n==32000);++played;}
static void start(void) {}
int main(int argc,char **argv) {
  assert(argc==2);snprintf(root,sizeof(root),"%s",argv[1]);
  float gpu;
  assert(osd_parse_gpu_percent("0\n",&gpu) && gpu==0);
  assert(osd_parse_gpu_percent("100",&gpu) && gpu==100);
  assert(!osd_parse_gpu_percent("256",&gpu));
  assert(!osd_parse_gpu_percent("-1",&gpu));
  assert(!osd_parse_gpu_percent("53%",&gpu));
  double mbps;
  assert(osd_byte_rate(2000,1000,2000000,1000000,&mbps) && mbps==8);
  assert(!osd_byte_rate(2000,1000,100,200,&mbps));
  assert(!osd_byte_rate(1000,1000,200,100,&mbps));
  assert(!osd_byte_rate(62001,1000,200,100,&mbps));
  bool seen=false;uint32_t last=0,missing=0,gaps=0;
  osd_frame_gap(UINT32_MAX-1,&seen,&last,&missing,&gaps);
  osd_frame_gap(1,&seen,&last,&missing,&gaps);
  assert(missing==2 && gaps==1);
  osd_frame_gap(1,&seen,&last,&missing,&gaps);
  osd_frame_gap(0,&seen,&last,&missing,&gaps);
  osd_frame_gap(2,&seen,&last,&missing,&gaps);
  assert(missing==2 && gaps==1 && last==2);
  double decode;
  assert(osd_decode_sample(99,1920,1080,&decode) && fabs(decode-.88)<.0001);
  bad_ioctl=true;assert(!osd_decode_sample(99,1920,1080,&decode));
  bad_ioctl=false;assert(!osd_decode_sample(99,1280,720,&decode));
  assert(!osd_decode_sample(-1,1920,1080,&decode));

  DECODER_RENDERER_CALLBACKS v={.setup=setup,.submitDecodeUnit=submit,.start=start,.capabilities=123};
  AUDIO_RENDERER_CALLBACKS a={.init=init,.decodeAndPlaySample=play,.start=start,.capabilities=456};
  PDECODER_RENDERER_CALLBACKS vp=&v;PAUDIO_RENDERER_CALLBACKS ap=&a;
  osd_telemetry_prepare(NULL,0,&vp,&ap,false);
  assert(vp!=&v && ap!=&a && vp->capabilities==123 && ap->capabilities==456);
  assert(vp->start==start && ap->start==start && v.submitDecodeUnit==submit);
  /* The wrapper must not dereference NULL or send it to a backend that
   * expects a well-formed unit. It requests IDR without counting a frame. */
  assert(vp->submitDecodeUnit(NULL)==DR_NEED_IDR);
  assert(submitted==0);
  setup_result=9;assert(vp->setup(VIDEO_FORMAT_H265,1920,1080,60,(void *)1,123)==9);
  setup_result=0;assert(!vp->setup(VIDEO_FORMAT_H265,1920,1080,60,(void *)1,123));
  OPUS_MULTISTREAM_CONFIGURATION opus={.channelCount=6,.sampleRate=48000};
  audio_result=-2;assert(ap->init(7,&opus,(void *)2,456)==-2);
  audio_result=0;assert(!ap->init(7,&opus,(void *)2,456));
  put("gpu","54\n");put("temp","53000\n");put("hdmi","1080p60hz\n");
  put("queue","vframe_pool_size=12\nvframe buf_free_num=8\nvframe buf_avail_num=3\n");
  put("note","Example\nignored second line\n");
  OsdTelemetry t;osd_telemetry_open(&t,false);
  assert(t.ping_fd==-1 && t.decoder_fd==-1);
  OsdSnapshot s={.has_sys_cpu=true,.sys_cpu_percent=25,.has_kernel_queue=true,.kernel_queue=3};
  char first[1024],second[1536];
  osd_telemetry_format(&t,1000,&s,first,sizeof(first),second,sizeof(second));
  assert(strstr(first,"Video n/a") && strstr(first,"CPU 25% | GPU 54%"));
  assert(strstr(first,"zone1") && strstr(first,"HEVC 1920x1080 @ 60fps"));
  DECODE_UNIT du={.frameNumber=10,.fullLength=500000};
  assert(vp->submitDecodeUnit(&du)==DR_NEED_IDR);
  du.frameNumber=13;assert(vp->submitDecodeUnit(&du)==DR_NEED_IDR);
  ap->decodeAndPlaySample((char *)3,32000);
  osd_telemetry_format(&t,2000,&s,first,sizeof(first),second,sizeof(second));
  assert(submitted==2 && played==1 && strstr(first,"Video 8.00 Mbps"));
  assert(strstr(first,"6ch 48000Hz 256 kbps") && strstr(first,"Lost 2 fr (~0.03s) / 1 gaps"));
  assert(strstr(first,"Queue 3 fr (~50ms)") && strstr(first,"Pool 4/12 (peak 4)"));
  assert(strstr(second,"Note: Example") && !strstr(second,"ignored"));
  OsdLayout layout;
  osd_layout_wrap(first,second,156,12,&layout);
  assert(!layout.truncated);
  put("gpu","256\n");put("queue","vframe_pool_size=12\nvframe buf_free_num=10\n");
  osd_telemetry_format(&t,3000,&s,first,sizeof(first),second,sizeof(second));
  assert(strstr(first,"GPU n/a") && strstr(first,"Pool 2/12 (peak 4)"));
  osd_telemetry_close(&t);osd_telemetry_close(&t);
  /* Session restart resets loss and a pull renderer retains its null callback. */
  v.submitDecodeUnit=NULL;vp=&v;ap=&a;
  connected_peer_available = true;
  osd_telemetry_prepare("127.0.0.1",47984,&vp,&ap,false);
  assert(vp->submitDecodeUnit==NULL);
  osd_telemetry_open(&t,false);
  put("rx","1000000\n");put("err","1\n");put("drop","2\n");
  osd_telemetry_format(&t,1000,&s,first,sizeof(first),second,sizeof(second));
  put("rx","3000000\n");put("err","3\n");put("drop","5\n");
  osd_telemetry_format(&t,2000,&s,first,sizeof(first),second,sizeof(second));
  assert(strstr(first,"NIC RX 16.00 Mbps (lo)") && strstr(first,"+2 err / +3 drop"));
  put("rx","10\n");put("err","0\n");put("drop","0\n");
  osd_telemetry_format(&t,3000,&s,first,sizeof(first),second,sizeof(second));
  assert(strstr(first,"NIC RX n/a") && strstr(first,"NetErr n/a"));
  if (t.ping_fd>=0) {
    osd_telemetry_poll(&t,10000);
    struct timespec delay={0,150000000};nanosleep(&delay,NULL);
    osd_telemetry_poll(&t,10150);
    assert(t.ping_valid && t.ping_ms<100); /* Kernel timestamp excludes poll delay. */
    puts("Loopback ICMP kernel timestamp check passed");
  } else puts("Loopback ICMP unavailable under host permissions; timeout paths remain n/a");
  osd_telemetry_close(&t);
  puts("Telemetry callbacks, units, rate/reset/wrap, GPU, loss, queue/pool, NIC, decoder ABI and layout passed");
}
