#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
read -r -a cc_cmd <<< "${CC:-cc}"
read -r -a extra <<< "${CFLAGS:-}"
"${cc_cmd[@]}" -std=c99 -Wall -Wextra -Werror -O2 "${extra[@]}" \
  -I"$root/third_party/moonlight-common-c/src" \
  "$root/tests/test_osd_telemetry.c" "$root/src/osd/telemetry.c" \
  "$root/src/osd/decode.c" "$root/src/osd/stats.c" "$root/src/osd/layout.c" \
  "$root/src/osd/frametime.c" "$root/tests/host_metrics_stub.c" \
  -Wl,--wrap=open,--wrap=fopen,--wrap=ioctl,--wrap=getifaddrs,--wrap=freeifaddrs \
  -rdynamic -ldl -lm -o "$tmp/test"
"$tmp/test" "$tmp"
"${cc_cmd[@]}" -std=c99 -Wall -Wextra -Werror -O2 "${extra[@]}" \
  -I"$root/third_party/moonlight-common-c/src" \
  "$root/tests/test_osd_ping.c" "$root/src/osd/telemetry.c" \
  "$root/src/osd/decode.c" "$root/src/osd/stats.c" \
  "$root/src/osd/frametime.c" "$root/tests/host_metrics_stub.c" \
  -Wl,--wrap=socket,--wrap=connect,--wrap=setsockopt,--wrap=send,--wrap=recvmsg,--wrap=close \
  -rdynamic -ldl -lm -o "$tmp/ping"
"$tmp/ping"
