"""Check precise app-ID selection and non-mutating AML preflight wiring."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class SourceWiringTests(unittest.TestCase):
    def test_exact_id_bypasses_name_lookup(self):
        config = (ROOT / 'src/config.c').read_text()
        main = (ROOT / 'src/main.c').read_text()
        self.assertIn('{"appid", required_argument', config)
        self.assertIn('config->app_id = -1;', config)
        self.assertIn('config->app_id = parse_stream_number(', config)
        self.assertIn('config->app_id >= 0 ? config->app_id :', main)

    def test_native_fallback_emits_actual_ids_not_numbered_rows(self):
        main = (ROOT / 'src/main.c').read_text()
        self.assertIn('LUNA_APP_IDS_V1', main)
        self.assertIn('moonlight_app_id_line(stdout, app->id, app->name)', main)
        self.assertIn('strcmp("list-ids", config.action)', main)
        self.assertIn('return applist_ids(&server)', main)

    def test_controller_overflow_does_not_impersonate_player_zero(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        self.assertIn('moonlight_first_free_gamepad_slot(', source)
        self.assertIn('if (dev->controllerId < 0)', source)
        self.assertNotIn('dev->controllerId = 0;', source)

    def test_preflight_reports_running_app_before_display_takeover(self):
        main = (ROOT / 'src/main.c').read_text()
        self.assertIn('strcmp("app-status", config.action)', main)
        self.assertIn('LUNA_APP_STATUS_V1 %d', main)
        self.assertLess(main.index('strcmp("app-status", config.action)'),
                        main.index('strcmp("stream", config.action)'))

    def test_extra_gamepad_has_no_mouse_emulation_or_local_quit(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        self.assertIn('moonlight_gamepad_slot_valid(dev->controllerId) &&\n'
                      '            mouseEmulationEnabled', source)
        self.assertIn('gamepadModified && moonlight_gamepad_slot_valid(', source)
        self.assertIn('} else if (moonlight_gamepad_slot_valid(dev->controllerId)', source)

    def test_unassigned_gamepad_cannot_send_pointer_or_keyboard_events(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        self.assertIn('moonlight_host_input_allowed(dev->is_gamepad,', source)
        self.assertIn('if (dev->is_gamepad && !moonlight_gamepad_slot_valid(', source)
        self.assertIn('if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId))',
                      source)

    def test_loader_check_is_before_any_host_init(self):
        main = (ROOT / 'src/main.c').read_text()
        platform = (ROOT / 'src/platform.c').read_text()
        section = platform.split('int platform_probe_aml(void)', 1)[1].split(
            'int platform_probe_vfm(void)', 1)[0]
        self.assertLess(main.index('platform_probe_aml()'), main.index('gs_init(&server'))
        self.assertIn('RTLD_NOW | RTLD_LOCAL', section)
        self.assertIn('"decoder_callbacks_aml"', section)
        self.assertIn('"aml_set_failure_callback"', section)
        self.assertNotIn('codec_init(', section)
        self.assertNotIn('platform_start(', section)

if __name__ == '__main__':
    unittest.main()
