"""Exercise bounded native evdev service with two independent devices."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'src/input/evdev.c'


class InputIsolationTests(unittest.TestCase):
    def test_burst_budget_fault_detach_and_hotplug_reentry(self):
        source = SOURCE.read_text()
        start = source.index('static int evdev_handle(int fd) {')
        end = source.index('\n}\n', start) + 3
        harness = r'''
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LOOP_OK 0
#define LOOP_RETURN 1
#define LIBEVDEV_READ_STATUS_SUCCESS 0
#define LIBEVDEV_READ_STATUS_SYNC 1
#define LIBEVDEV_READ_FLAG_NORMAL 0
#define LIBEVDEV_READ_FLAG_SYNC 1
struct input_event { int code, value; };
struct input_device { int fd; void *dev; bool syncing; };
static struct input_device first = {10, (void *)1, false};
static struct input_device second = {11, (void *)2, false};
static struct input_device replug = {12, (void *)3, false};
static struct input_device *devices[3] = {&first, &second};
static int numDevices = 2;
static unsigned first_reads, second_reads, replug_reads, detached;
static bool first_failed;
static int next_event(void *dev, int flags, struct input_event *ev) {
  assert(flags == LIBEVDEV_READ_FLAG_NORMAL);
  ev->code = 1;
  if (dev == (void *)1) {
    ++first_reads;
    return first_failed ? -EIO : LIBEVDEV_READ_STATUS_SUCCESS;
  }
  if (dev == (void *)2) {
    ++second_reads;
    return LIBEVDEV_READ_STATUS_SUCCESS;
  }
  assert(dev == (void *)3);
  ++replug_reads;
  return LIBEVDEV_READ_STATUS_SUCCESS;
}
#define libevdev_next_event next_event
static bool record(struct input_event *ev, struct input_device *dev) {
  assert(ev->code == 1 && dev != NULL);
  return true;
}
static bool (*handler)(struct input_event *, struct input_device *) = record;
static unsigned retries;
static void udev_schedule_input_retry(void) { ++retries; }
static void evdev_remove(int idx) {
  assert(idx == 0);
  ++detached;
  devices[0] = devices[1];
  --numDevices;
}
'''
        harness += source[start:end]
        harness += r'''
int main(void) {
  assert(evdev_handle(10) == LOOP_OK && first_reads == 256);
  assert(evdev_handle(11) == LOOP_OK && second_reads == 256);
  assert(evdev_handle(10) == LOOP_OK && first_reads == 512);
  first_failed = true;
  assert(evdev_handle(10) == LOOP_OK && detached == 1 && retries == 1);
  assert(numDevices == 1 && devices[0] == &second);
  assert(evdev_handle(11) == LOOP_OK && second_reads == 512);
  devices[numDevices++] = &replug; /* udev 'add' restores this physical node */
  assert(evdev_handle(12) == LOOP_OK && replug_reads == 256);
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as directory:
            src = Path(directory) / 'isolation.c'
            exe = Path(directory) / 'isolation'
            src.write_text(harness)
            cmd = shlex.split(os.environ.get('CC', 'cc')) + [
                '-std=gnu99', '-Wall', '-Wextra', '-Werror',
                str(src), '-o', str(exe)]
            build = subprocess.run(cmd, capture_output=True, text=True)
            self.assertEqual(build.returncode, 0, build.stderr)
            subprocess.run([str(exe)], check=True, timeout=5)


if __name__ == '__main__':
    unittest.main()
