/* SPDX-License-Identifier: GPL-3.0-or-later
 * Fault-injected hidraw output report retries: no real controller required.
 */
#include "../src/input/saxense_hid_write.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

typedef struct {
  ssize_t replies[8];
  int errors[8];
  unsigned writes, waits;
} Mock;
static Mock mock;
static ssize_t fake_write(int fd, const void *data, size_t length) {
  assert(fd == 9 && data != NULL && length == 142);
  const unsigned i = mock.writes++;
  assert(i < 8);
  const ssize_t n = mock.replies[i];
  if (n < 0) errno = mock.errors[i];
  return n;
}
static void fake_wait(void) { ++mock.waits; }
static const MlSaxHidWriteOps ops = {
  .write_report = fake_write, .pause_retry = fake_wait
};
static void reset(void) { memset(&mock, 0, sizeof(mock)); }
int main(void) {
  uint8_t report[142] = {0x32};
  reset();
  mock.replies[0] = sizeof(report);
  assert(ml_sax_hid_write_bounded(&ops, 9, report, sizeof(report)));
  assert(mock.writes == 1 && mock.waits == 0);

  reset();
  mock.replies[0] = -1; mock.errors[0] = EINTR;
  mock.replies[1] = sizeof(report);
  assert(ml_sax_hid_write_bounded(&ops, 9, report, sizeof(report)));
  assert(mock.writes == 2 && mock.waits == 0);

  reset();
  mock.replies[0] = -1; mock.errors[0] = EAGAIN;
  mock.replies[1] = sizeof(report);
  assert(ml_sax_hid_write_bounded(&ops, 9, report, sizeof(report)));
  assert(mock.writes == 2 && mock.waits == 1);

  reset();
  for (unsigned i = 0; i < 3; ++i) {
    mock.replies[i] = -1; mock.errors[i] = EAGAIN;
  }
  assert(!ml_sax_hid_write_bounded(&ops, 9, report, sizeof(report)));
  assert(mock.writes == 3 && mock.waits == 2);

  /* hidraw writes are atomic reports: a positive short write is an error,
   * not permission to send a 71-byte remainder as another HID packet. */
  reset();
  mock.replies[0] = 71;
  assert(!ml_sax_hid_write_bounded(&ops, 9, report, sizeof(report)));
  assert(mock.writes == 1 && mock.waits == 0);

  reset();
  mock.replies[0] = -1; mock.errors[0] = EIO;
  assert(!ml_sax_hid_write_bounded(&ops, 9, report, sizeof(report)));
  assert(mock.writes == 1 && mock.waits == 0);

  reset();
  assert(!ml_sax_hid_write_bounded(&ops, -1, report, sizeof(report)));
  assert(mock.writes == 0);
  puts("PASS: bounded DualSense Bluetooth HID report retries/failures");
  return 0;
}
