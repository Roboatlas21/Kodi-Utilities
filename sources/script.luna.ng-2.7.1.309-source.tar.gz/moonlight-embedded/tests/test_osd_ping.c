/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "../src/osd/telemetry.h"
#include <assert.h>
#include <errno.h>
#include <math.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include <netinet/icmp6.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>
static unsigned char packet[16];
static int selected_family = AF_INET;
bool LiGetLunaConnectedPeerV1(struct sockaddr_storage *out, uint32_t size) {
  if (!out || size != sizeof(*out)) return false;
  memset(out, 0, sizeof(*out));
  out->ss_family = selected_family;
  if (selected_family == AF_INET) {
    ((struct sockaddr_in *)out)->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  } else {
    ((struct sockaddr_in6 *)out)->sin6_addr = in6addr_loopback;
  }
  return true;
}
static bool blocked,deliver,corrupt,send_fail;
static int protocol,sends,closes;
static uint64_t sent_ns,latency_ns=2000000;
int __wrap_socket(int family,int type,int p) {
  assert(family==AF_INET || family==AF_INET6);
  assert((type&SOCK_NONBLOCK) && (type&SOCK_CLOEXEC));
  protocol=p;if(blocked){errno=EPERM;return -1;}return 97;
}
int __wrap_connect(int fd,const struct sockaddr *addr,socklen_t n) {
  assert(fd==97 && addr && n);return 0;
}
int __wrap_setsockopt(int fd,int level,int option,const void *value,socklen_t n) {
  assert(fd==97 && level==SOL_SOCKET && option==SO_TIMESTAMPNS && value && n);return 0;
}
int __wrap_close(int fd) {assert(fd==97);++closes;return 0;}
ssize_t __wrap_send(int fd,const void *data,size_t n,int flags) {
  assert(fd==97 && n==16 && flags==MSG_DONTWAIT);++sends;
  if(send_fail){errno=EAGAIN;return -1;}
  memcpy(packet,data,n);
  struct timespec t;assert(!clock_gettime(CLOCK_REALTIME,&t));
  sent_ns=(uint64_t)t.tv_sec*1000000000+t.tv_nsec;
  if(protocol==IPPROTO_ICMP) {
    uint32_t sum=0;for(unsigned i=0;i<16;i+=2)sum+=((unsigned)packet[i]<<8)|packet[i+1];
    while(sum>>16)sum=(sum&65535)+(sum>>16);
    assert(sum==65535 && packet[0]==ICMP_ECHO);
  } else assert(packet[0]==ICMP6_ECHO_REQUEST);
  return (ssize_t)n;
}
ssize_t __wrap_recvmsg(int fd,struct msghdr *msg,int flags) {
  assert(fd==97 && flags==MSG_DONTWAIT);
  if(!deliver){errno=EAGAIN;return -1;}deliver=false;
  packet[0]=protocol==IPPROTO_ICMP ? ICMP_ECHOREPLY : ICMP6_ECHO_REPLY;
  if(corrupt)packet[7]^=1;
  memcpy(msg->msg_iov[0].iov_base,packet,16);
  struct cmsghdr *c=CMSG_FIRSTHDR(msg);
  c->cmsg_level=SOL_SOCKET;c->cmsg_type=SCM_TIMESTAMPNS;c->cmsg_len=CMSG_LEN(sizeof(struct timespec));
  uint64_t ns=sent_ns+latency_ns;
  struct timespec stamp={.tv_sec=ns/1000000000,.tv_nsec=ns%1000000000};
  memcpy(CMSG_DATA(c),&stamp,sizeof(stamp));
  msg->msg_controllen=CMSG_SPACE(sizeof(stamp));return 16;
}
int main(void) {
  for(unsigned family=0;family<2;family++) {
    selected_family = family ? AF_INET6 : AF_INET;
    osd_telemetry_prepare(family ? "::1" : "127.0.0.1",47984,NULL,NULL,false);
    OsdTelemetry t;blocked=true;osd_telemetry_open(&t,false);
    assert(t.ping_fd==-1);osd_telemetry_close(&t);
    blocked=false;send_fail=false;corrupt=false;latency_ns=2000000;
    osd_telemetry_open(&t,false);assert(t.ping_fd==97);
    osd_telemetry_poll(&t,1000);assert(t.ping_pending && !t.ping_valid);
    deliver=true;osd_telemetry_poll(&t,1150);
    assert(t.ping_valid && t.ping_ms>=2 && t.ping_ms<10); /* Not 150ms poll delay */
    int prior_sends=sends;osd_telemetry_poll(&t,2999);assert(sends==prior_sends);
    osd_telemetry_poll(&t,3000);latency_ns=6000000;deliver=true;
    osd_telemetry_poll(&t,3100);
    assert(t.ping_ms>=3.2 && t.ping_ms<4 && t.ping_jitter_ms>1 && t.ping_jitter_ms<2);
    osd_telemetry_poll(&t,5000);deliver=true;corrupt=true;osd_telemetry_poll(&t,5100);
    assert(t.ping_pending);osd_telemetry_poll(&t,6000);
    assert(!t.ping_pending && !t.ping_valid);
    send_fail=true;osd_telemetry_poll(&t,7000);assert(!t.ping_pending && !t.ping_valid);
    int prior_closes=closes;osd_telemetry_close(&t);osd_telemetry_close(&t);
    assert(closes==prior_closes+1);
  }
  puts("ICMP IPv4/IPv6 timestamp, checksum, cadence, jitter, stale/invalid reply, permission and send-failure tests passed");
}
