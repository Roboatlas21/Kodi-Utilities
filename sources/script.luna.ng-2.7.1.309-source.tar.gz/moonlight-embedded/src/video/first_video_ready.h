/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_FIRST_VIDEO_READY_H
#define MOONLIGHT_FIRST_VIDEO_READY_H
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>

/* Only the caller's pre-authorized Luna session receipt may be updated.
 * A missing env path means this is a standalone Moonlight invocation. */
static inline bool moonlight_receipt_publish(const char *path) {
  if (!path || !*path) return true;
  /* Luna created this single-owner file before native startup. Never create
   * an arbitrary pathname supplied through an environment variable. */
  int fd = open(path, O_WRONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
  if (fd < 0) return false;
  struct stat st;
  if (fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) || st.st_nlink != 1 || st.st_uid != geteuid() || st.st_size > 64) {
    close(fd);
    return false;
  }
  /* Inspect inode type/link count BEFORE truncation; hardlinks and symlinks
   * must not let an untrusted receipt path damage another file. */
  if (ftruncate(fd, 0) != 0) {
    close(fd);
    return false;
  }
  static const char receipt[] = "ready\n";
  const ssize_t n = write(fd, receipt, sizeof(receipt) - 1);
  const int closed = close(fd);
  return n == (ssize_t)(sizeof(receipt) - 1) && closed == 0;
}

/* Preserve the VFM/AML callers while sharing the same safe writer with
 * Moonlight's post-connection readiness receipt. */
static inline bool moonlight_first_video_publish(const char *path) {
  return moonlight_receipt_publish(path);
}
#endif
