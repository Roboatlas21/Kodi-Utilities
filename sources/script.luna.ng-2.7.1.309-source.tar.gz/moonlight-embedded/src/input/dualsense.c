/* SPDX-License-Identifier: GPL-3.0-or-later
 * Optional DualSense and DualSense Edge USB/Bluetooth HID bridge.
 * A matching evdev gamepad owns normal input; this code only handles sensor,
 * touch, battery, LED and adaptive-trigger messages. No HID rebind or EVIOCGRAB.
 */
#define _GNU_SOURCE
#include "dualsense.h"
#include "dualsense_report.h"
#include "dualsense_pcm.h"
#include <ControllerHaptics.h>
#include <ControllerSpeakerPcm.h>
#include "../loop.h"
#include <Limelight.h>
#include <libudev.h>
#include <linux/hidraw.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct moonlight_dualsense {
  struct moonlight_dualsense *next;
  int fd;
  int transport;
  short player; /* Only the native evdev loop assigns player slots. */
  unsigned sequence;
  uint16_t gyro_rate, accel_rate;
  uint64_t last_gyro_us, last_accel_us, last_battery_us;
  uint8_t last_battery_state, last_battery_percent;
  bool battery_known, touch_active[2], effect_active, listening;
  uint32_t touch_id[2];
  float touch_x[2], touch_y[2];
  ml_ds_audio *audio; /* Optional, independent haptics/speaker worker. */
};
static moonlight_dualsense *bridges;

static uint64_t monotonic_us(void) {
  struct timespec now;
  if (clock_gettime(CLOCK_MONOTONIC, &now) < 0) return 0;
  return (uint64_t)now.tv_sec * 1000000U + (uint64_t)now.tv_nsec / 1000U;
}

static bool send_report(moonlight_dualsense *d, const uint8_t body[ML_DS_PAYLOAD]) {
  uint8_t report[ML_DS_BT_OUT];
  size_t length = 0;
  if (!d || d->fd < 0 || !ml_ds_output(body, d->transport, d->sequence, report, &length))
    return false;
  ssize_t sent = write(d->fd, report, length);
  if (sent != (ssize_t)length) return false;
  d->sequence = (d->sequence + 1) & 15U;
  return true;
}

void dualsense_led(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  if (!d || d->fd < 0) return;
  uint8_t body[ML_DS_PAYLOAD] = {0};
  body[1] = 0x04; /* Only the lightbar control bit. */
  body[44] = r;
  body[45] = g;
  body[46] = b;
  (void)send_report(d, body);
}

void dualsense_adaptive(moonlight_dualsense *d, uint8_t flags, uint8_t left_type,
                        uint8_t right_type, const uint8_t *left, const uint8_t *right) {
  if (!d || d->fd < 0) return;
  flags &= 0x0c; /* The host may only select left/right trigger effects. */
  if (!flags || ((flags & 0x08) && !left) || ((flags & 0x04) && !right))
    return;
  uint8_t body[ML_DS_PAYLOAD] = {0};
  body[0] = flags;
  if (flags & 0x04) {
    body[10] = right_type;
    memcpy(body + 11, right, 10);
  }
  if (flags & 0x08) {
    body[21] = left_type;
    memcpy(body + 22, left, 10);
  }
  if (send_report(d, body)) d->effect_active = true;
}

void dualsense_motion_request(moonlight_dualsense *d, uint8_t type, uint16_t rate) {
  if (!d) return;
  if (rate > 250) rate = 250; /* Bound callback traffic, regardless of host request. */
  if (type == LI_MOTION_TYPE_GYRO)
    __atomic_store_n(&d->gyro_rate, rate, __ATOMIC_RELAXED);
  if (type == LI_MOTION_TYPE_ACCEL)
    __atomic_store_n(&d->accel_rate, rate, __ATOMIC_RELAXED);
}
void dualsense_set_player(moonlight_dualsense *d, short player) {
  if (d && player >= 0 && player < 16) d->player = player;
}
unsigned short dualsense_capabilities(const moonlight_dualsense *d) {
  if (!d || d->fd < 0) return 0;
  unsigned short result = LI_CCAP_TOUCHPAD | LI_CCAP_ACCEL | LI_CCAP_GYRO |
                          LI_CCAP_BATTERY_STATE | LI_CCAP_RGB_LED;
  if (ml_ds_audio_haptics_ready(d->audio)) result |= LI_CCAP_HAPTICS_PCM;
  if (ml_ds_audio_speaker_ready(d->audio)) result |= LI_CCAP_PS_SPEAKER_PCM;
  return result;
}

uint64_t dualsense_speaker_owner(const moonlight_dualsense *d) {
  return d ? ml_ds_audio_speaker_owner(d->audio) : 0;
}
bool dualsense_waveform_active(moonlight_dualsense *d) {
  return d && ml_ds_audio_playing(d->audio);
}
void dualsense_receive_haptics(moonlight_dualsense *d, uint32_t sequence,
                               const uint8_t *pcm, uint16_t frames) {
  if (d) ml_ds_audio_haptics(d->audio, sequence, pcm, frames);
}
void dualsense_receive_speaker(moonlight_dualsense *d, uint64_t owner, uint32_t generation,
                               uint32_t sequence, uint64_t position, uint16_t flags,
                               const uint8_t *pcm, uint16_t frames) {
  if (d) ml_ds_audio_speaker(d->audio, owner, generation, sequence, position, flags, pcm, frames);
}

static void send_touch(moonlight_dualsense *d, const ml_ds_sample *sample) {
  if (!(LiGetHostFeatureFlags() & LI_FF_CONTROLLER_TOUCH_EVENTS)) return;
  for (unsigned slot = 0; slot < 2; ++slot) {
    const uint8_t *p = sample->touch[slot];
    const bool active = (p[0] & 0x80) == 0;
    const uint32_t id = (slot << 8) | (p[0] & 0x7f);
    const float x = (float)(p[1] | ((p[2] & 0x0f) << 8)) / 1920.0f;
    const float y = (float)((p[2] >> 4) | (p[3] << 4)) / 1080.0f;
    if (d->touch_active[slot] && (!active || id != d->touch_id[slot])) {
      LiSendControllerTouchEvent((uint8_t)d->player, LI_TOUCH_EVENT_UP,
                                 d->touch_id[slot], d->touch_x[slot], d->touch_y[slot], 0);
      d->touch_active[slot] = false;
    }
    if (!active) continue;
    if (x < 0 || x > 1 || y < 0 || y > 1) continue;
    const bool down = !d->touch_active[slot];
    if (down || x != d->touch_x[slot] || y != d->touch_y[slot])
      LiSendControllerTouchEvent((uint8_t)d->player,
                                 down ? LI_TOUCH_EVENT_DOWN : LI_TOUCH_EVENT_MOVE,
                                 id, x, y, 1.0f);
    d->touch_id[slot] = id;
    d->touch_x[slot] = x;
    d->touch_y[slot] = y;
    d->touch_active[slot] = true;
  }
}

static void send_battery(moonlight_dualsense *d, uint8_t packed, uint64_t now) {
  uint8_t percent = (uint8_t)((packed & 0x0f) * 10 + 5);
  if (percent > 100) percent = 100;
  uint8_t state;
  switch ((packed >> 4) & 15) {
    case 0: state = LI_BATTERY_STATE_DISCHARGING; break;
    case 1: state = LI_BATTERY_STATE_CHARGING; break;
    case 2: state = LI_BATTERY_STATE_FULL; percent = 100; break;
    case 10: case 11: state = LI_BATTERY_STATE_NOT_CHARGING; percent = 0; break;
    default: state = LI_BATTERY_STATE_UNKNOWN; percent = LI_BATTERY_PERCENTAGE_UNKNOWN; break;
  }
  if (d->battery_known && state == d->last_battery_state &&
      percent == d->last_battery_percent && now - d->last_battery_us < 5000000U)
    return;
  LiSendControllerBatteryEvent((uint8_t)d->player, state, percent);
  d->battery_known = true;
  d->last_battery_state = state;
  d->last_battery_percent = percent;
  d->last_battery_us = now;
}

static void process_sample(moonlight_dualsense *d, const ml_ds_sample *s) {
  if (d->player < 0) return; /* Don't send before evdev advertises the controller. */
  const uint64_t now = monotonic_us();
  const uint16_t gyro = __atomic_load_n(&d->gyro_rate, __ATOMIC_RELAXED);
  const uint16_t accel = __atomic_load_n(&d->accel_rate, __ATOMIC_RELAXED);
  /* Raw scale factors from hid-playstation. Calibration/bias is firmware-
   * dependent, so sensor accuracy must be tested with a real pad. */
  if (gyro && (!d->last_gyro_us || now - d->last_gyro_us >= 1000000U / gyro)) {
    LiSendControllerMotionEvent((uint8_t)d->player, LI_MOTION_TYPE_GYRO,
                                s->gyro[0] / 1024.0f, s->gyro[1] / 1024.0f,
                                s->gyro[2] / 1024.0f);
    d->last_gyro_us = now;
  }
  if (accel && (!d->last_accel_us || now - d->last_accel_us >= 1000000U / accel)) {
    const float scale = 9.80665f / 8192.0f;
    LiSendControllerMotionEvent((uint8_t)d->player, LI_MOTION_TYPE_ACCEL,
                                s->accel[0] * scale, s->accel[1] * scale,
                                s->accel[2] * scale);
    d->last_accel_us = now;
  }
  send_touch(d, s);
  send_battery(d, s->battery, now);
}

static int on_hidraw(int fd) {
  moonlight_dualsense *d = bridges;
  while (d && d->fd != fd) d = d->next;
  if (!d) return LOOP_OK;
  /* Bound work per poll cycle, so controller/raw HID cannot starve CEC. */
  for (unsigned n = 0; n < 32; ++n) {
    uint8_t report[ML_DS_BT_IN];
    const ssize_t got = read(fd, report, sizeof(report));
    if (got > 0) {
      ml_ds_sample sample;
      if (ml_ds_parse(report, (size_t)got, d->transport, &sample))
        process_sample(d, &sample);
      continue;
    }
    if (got < 0 && errno == EINTR) continue;
    if (got < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
    /* Keep ownership for teardown; don't close a descriptor a host callback
     * may be using. Stop polling a disconnected/failed HID link. */
    loop_remove_fd(fd);
    d->listening = false;
    fprintf(stderr, "DualSense HID input stopped (errno=%d)\n", got < 0 ? errno : 0);
    break;
  }
  return LOOP_OK;
}

moonlight_dualsense *dualsense_attach(int event_fd, int vendor, int product) {
  /* Auto-detect by default. A process-only environment kill switch is
   * available for driver troubleshooting without a permanent Kodi setting. */
  if (!ml_ds_hid_enabled(getenv("MOONLIGHT_DUALSENSE_HID")))
    return NULL;
  if (vendor != 0x054c || (product != 0x0ce6 && product != 0x0df2))
    return NULL;
  struct stat st;
  if (fstat(event_fd, &st) != 0 || !S_ISCHR(st.st_mode)) return NULL;
  struct udev *u = udev_new();
  if (!u) return NULL;
  struct udev_device *event = udev_device_new_from_devnum(u, 'c', st.st_rdev);
  struct udev_device *parent = event ?
      udev_device_get_parent_with_subsystem_devtype(event, "hid", NULL) : NULL;
  const char *parent_path = parent ? udev_device_get_syspath(parent) : NULL;
  struct udev_enumerate *scan = udev_enumerate_new(u);
  moonlight_dualsense *d = NULL;
  if (parent_path && scan &&
      udev_enumerate_add_match_subsystem(scan, "hidraw") >= 0 &&
      udev_enumerate_scan_devices(scan) >= 0) {
    struct udev_list_entry *entry;
    udev_list_entry_foreach(entry, udev_enumerate_get_list_entry(scan)) {
      struct udev_device *raw = udev_device_new_from_syspath(u, udev_list_entry_get_name(entry));
      if (!raw) continue;
      struct udev_device *raw_parent = udev_device_get_parent_with_subsystem_devtype(raw, "hid", NULL);
      const char *raw_path = raw_parent ? udev_device_get_syspath(raw_parent) : NULL;
      const char *node = udev_device_get_devnode(raw);
      if (node && raw_path && strcmp(raw_path, parent_path) == 0) {
        int fd = open(node, O_RDWR | O_NONBLOCK | O_CLOEXEC);
        if (fd >= 0) {
          struct hidraw_devinfo info;
          if (ioctl(fd, HIDIOCGRAWINFO, &info) == 0 &&
              info.vendor == vendor && info.product == product &&
              (info.bustype == BUS_USB || info.bustype == BUS_BLUETOOTH)) {
            d = calloc(1, sizeof(*d));
            if (d) {
              d->fd = fd;
              d->transport = info.bustype == BUS_USB ? ML_DS_USB : ML_DS_BT;
              d->player = -1;
              d->audio = ml_ds_audio_open(fd, d->transport, event_fd);
              d->listening = true;
              d->next = bridges;
              bridges = d;
              loop_add_fd(fd, on_hidraw, POLLIN);
              fprintf(stderr, "DualSense HID bridge attached (%s)\n",
                      d->transport == ML_DS_USB ? "USB" : "Bluetooth");
            } else {
              close(fd);
            }
          } else {
            close(fd);
          }
        }
      }
      udev_device_unref(raw);
      if (d) break;
    }
  }
  if (scan) udev_enumerate_unref(scan);
  if (event) udev_device_unref(event);
  udev_unref(u);
  return d;
}

/* Touch contacts are host state, not merely HID-device state. A controller
 * removed while touching must publish UP for each outstanding contact. */
static void dualsense_release_touches(moonlight_dualsense *d) {
  if (!d) return;
  const bool can_send = d->player >= 0 &&
      (LiGetHostFeatureFlags() & LI_FF_CONTROLLER_TOUCH_EVENTS);
  for (unsigned slot = 0; slot < 2; ++slot) {
    if (!d->touch_active[slot]) continue;
    if (can_send)
      LiSendControllerTouchEvent((uint8_t)d->player, LI_TOUCH_EVENT_UP,
                                 d->touch_id[slot], d->touch_x[slot],
                                 d->touch_y[slot], 0);
    d->touch_active[slot] = false;
  }
}

void dualsense_detach(moonlight_dualsense *d) {
  if (!d) return;
  dualsense_release_touches(d);
  /* Join and quiesce any separate audio worker before closing its HID/ALSA
   * devices, or releasing the controller while feedback is in flight. */
  ml_ds_audio_close(d->audio);
  d->audio = NULL;
  if (d->effect_active) {
    const uint8_t empty[10] = {0};
    dualsense_adaptive(d, 0x0c, 0, 0, empty, empty);
  }
  if (d->listening) loop_remove_fd(d->fd);
  if (d->fd >= 0) close(d->fd);
  moonlight_dualsense **link = &bridges;
  while (*link && *link != d) link = &(*link)->next;
  if (*link) *link = d->next;
  free(d);
}
