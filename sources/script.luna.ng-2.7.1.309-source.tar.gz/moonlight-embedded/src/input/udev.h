/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "mapping.h"

void udev_init(bool autoload, struct mapping* mappings, bool verbose, int rotate);
void udev_destroy();
/* Re-enumerate selected event nodes when a previously claimed Steam native
 * HID link fails; never globally reset HID/USB drivers. */
void udev_rescan_inputs(void);
/* Rate-limited retry when a live device fails without a new udev add event. */
void udev_schedule_input_retry(void);
