/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#define _GNU_SOURCE

#include "platform.h"

#include "util.h"
#include "loop.h"

#include "audio/audio.h"
#include "video/video.h"

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dlfcn.h>
#include <errno.h>

typedef bool(*ImxInit)();

#ifdef HAVE_AML_VFM
static void *vfm_module;
#endif
static PDECODER_RENDERER_CALLBACKS vfm_callbacks;

/* Eagerly resolve every AML decoder dependency and mandatory callback.
 * No decoder initialization, display takeover, or sysfs access occurs here. */
int platform_probe_aml(void) {
#ifdef HAVE_AML
  void *module = dlopen("libmoonlight-aml.so", RTLD_NOW | RTLD_LOCAL);
  if (!module) {
    fprintf(stderr, "AML: decoder load failed: %s\n", dlerror());
    return -1;
  }
  PDECODER_RENDERER_CALLBACKS callbacks =
      (PDECODER_RENDERER_CALLBACKS)dlsym(module, "decoder_callbacks_aml");
  void (*set_failure)(void (*)(void)) =
      (void (*)(void (*)(void)))dlsym(module, "aml_set_failure_callback");
  const bool valid = callbacks && callbacks->setup && callbacks->cleanup &&
                     callbacks->submitDecodeUnit && set_failure;
  if (!valid)
    fprintf(stderr, "AML: required decoder callbacks are missing\n");
  dlclose(module);
  return valid ? 0 : -1;
#else
  fprintf(stderr, "AML: binary lacks Amlogic decoder support\n");
  return -1;
#endif
}

int platform_probe_vfm(void) {
#ifdef HAVE_AML_VFM
  typedef int (*VfmInit)(void (*)(void));
  VfmInit init;
  if (vfm_callbacks)
    return 0;
  vfm_module = dlopen("libmoonlight-aml-vfm.so", RTLD_NOW | RTLD_LOCAL);
  if (!vfm_module) {
    fprintf(stderr, "AML-VFM: cannot load prototype module: %s\n", dlerror());
    return -1;
  }
  init = (VfmInit)dlsym(vfm_module, "moonlight_vfm_init");
  vfm_callbacks = (PDECODER_RENDERER_CALLBACKS)dlsym(vfm_module, "decoder_callbacks_aml_vfm");
  if (!init || !vfm_callbacks || init(loop_request_error_stop) != 0) {
    fprintf(stderr, "AML-VFM: prototype dependencies are unavailable\n");
    vfm_callbacks = NULL;
    dlclose(vfm_module);
    vfm_module = NULL;
    return -1;
  }
  return 0;
#else
  fprintf(stderr, "AML-VFM: this Moonlight build has no experimental VFM backend\n");
  return -1;
#endif
}

enum platform platform_check(char* name) {
  bool std = strcmp(name, "auto") == 0;
  const char *pipeline = getenv("MOONLIGHT_VIDEO_PIPELINE");
  if ((std || strcmp(name, "aml") == 0) && pipeline && strcmp(pipeline, "aml-vfm") == 0)
    name = "aml-vfm";
  if (strcmp(name, "aml-vfm") == 0)
    return platform_probe_vfm() == 0 ? AML_VFM : NONE;
  #ifdef HAVE_IMX
  if (std || strcmp(name, "imx") == 0) {
    void *handle = dlopen("libmoonlight-imx.so", RTLD_NOW | RTLD_GLOBAL);
    ImxInit video_imx_init = (ImxInit) dlsym(RTLD_DEFAULT, "video_imx_init");
    if (handle != NULL) {
      if (video_imx_init())
        return IMX;
    }
  }
  #endif
  #ifdef HAVE_PI
  if (std || strcmp(name, "pi") == 0) {
    void *handle = dlopen("libmoonlight-pi.so", RTLD_NOW | RTLD_GLOBAL);
    if (handle != NULL && dlsym(RTLD_DEFAULT, "bcm_host_init") != NULL)
      return PI;
  }
  #endif
  #ifdef HAVE_MMAL
  if (std || strcmp(name, "mmal") == 0) {
    void *handle = dlopen("libmoonlight-mmal.so", RTLD_NOW | RTLD_GLOBAL);
    if (handle != NULL && dlsym(RTLD_DEFAULT, "bcm_host_init") != NULL)
      return MMAL;
  }
  #endif
  #ifdef HAVE_AML
  if (std || strcmp(name, "aml") == 0) {
    void *handle = dlopen("libmoonlight-aml.so", RTLD_LAZY | RTLD_GLOBAL);
    if (handle != NULL && access("/dev/amvideo", F_OK) != -1) {
      /* Pass the input-loop stop callback instead of resolving an unexported
       * main-executable symbol from a separately loaded decoder library. */
      typedef void (*AmlSetFailure)(void (*)(void));
      AmlSetFailure set_failure = (AmlSetFailure)dlsym(handle, "aml_set_failure_callback");
      if (set_failure != NULL) {
        set_failure(loop_request_error_stop);
        return AML;
      }
      fprintf(stderr, "AML: unable to install fatal frame-pump callback\n");
    }
  }
  #endif
  #ifdef HAVE_ROCKCHIP
  if (std || strcmp(name, "rk") == 0) {
    void *handle = dlopen("libmoonlight-rk.so", RTLD_NOW | RTLD_GLOBAL);
    if (handle != NULL && dlsym(RTLD_DEFAULT, "mpp_init") != NULL)
      return RK;
  }
  #endif
  #ifdef HAVE_X11
  bool x11 = strcmp(name, "x11") == 0;
  bool vdpau = strcmp(name, "x11_vdpau") == 0;
  bool vaapi = strcmp(name, "x11_vaapi") == 0;
  if (std || x11 || vdpau || vaapi) {
    int init = x11_init(std || vdpau, std || vaapi);
    #ifdef HAVE_VAAPI
    if (init == INIT_VAAPI)
      return X11_VAAPI;
    #endif
    #ifdef HAVE_VDPAU
    if (init == INIT_VDPAU)
      return X11_VDPAU;
    #endif
    #ifdef HAVE_SDL
    return SDL;
    #else
    return X11;
    #endif
  }
  #endif
  #ifdef HAVE_SDL
  if (std || strcmp(name, "sdl") == 0)
    return SDL;
  #endif

  if (strcmp(name, "fake") == 0)
    return FAKE;

  return 0;
}

#if defined(HAVE_AML) || defined(HAVE_AML_VFM) || defined(HAVE_PI) || defined(HAVE_MMAL)
/* fb1 may be absent on single-framebuffer devices. If it exists but is
 * unwritable, however, never silently claim that the display transitioned. */
static int display_write(const char *path, bool value, bool optional) {
  if (optional && access(path, F_OK) != 0 && errno == ENOENT)
    return 0;
  if (write_bool((char *)path, value) == 0)
    return 0;
  fprintf(stderr, "Display transition failed: %s -> %d (errno=%d)\n",
          path, value, errno);
  return -1;
}

#endif /* framebuffer-backed native platforms */

int platform_start(enum platform system) {
  int status = 0;
  switch (system) {
  #if defined(HAVE_AML) || defined(HAVE_AML_VFM)
  case AML:
  case AML_VFM:
    if (display_write("/sys/class/graphics/fb0/blank", true, false) < 0) status = -1;
    if (display_write("/sys/class/graphics/fb1/blank", true, true) < 0) status = -1;
    if (display_write("/sys/class/video/disable_video", false, false) < 0) status = -1;
    break;
  #endif
  #if defined(HAVE_PI) || defined(HAVE_MMAL)
  case PI:
    if (display_write("/sys/class/graphics/fb0/blank", true, false) < 0) status = -1;
    break;
  #endif
  default:
    break;
  }
  return status;
}

int platform_stop(enum platform system) {
  int status = 0;
  switch (system) {
  #if defined(HAVE_AML) || defined(HAVE_AML_VFM)
  case AML:
  case AML_VFM:
    /* Restore video first, then unblank Kodi's GUI. Continue best-effort
     * recovery even if one control fails, but report the incomplete handoff. */
    if (display_write("/sys/class/video/disable_video", true, false) < 0) status = -1;
    if (display_write("/sys/class/graphics/fb0/blank", false, false) < 0) status = -1;
    if (display_write("/sys/class/graphics/fb1/blank", false, true) < 0) status = -1;
    break;
  #endif
  #if defined(HAVE_PI) || defined(HAVE_MMAL)
  case PI:
    if (display_write("/sys/class/graphics/fb0/blank", false, false) < 0) status = -1;
    break;
  #endif
  default:
    break;
  }
  return status;
}

DECODER_RENDERER_CALLBACKS* platform_get_video(enum platform system) {
  switch (system) {
  case AML_VFM:
    return vfm_callbacks;
  #ifdef HAVE_X11
  case X11:
    return &decoder_callbacks_x11;
  #ifdef HAVE_VAAPI
  case X11_VAAPI:
    return &decoder_callbacks_x11_vaapi;
  #endif
  #ifdef HAVE_VDPAU
  case X11_VDPAU:
    return &decoder_callbacks_x11_vdpau;
  #endif
  #endif
  #ifdef HAVE_SDL
  case SDL:
    return &decoder_callbacks_sdl;
  #endif
  #ifdef HAVE_IMX
  case IMX:
    return (PDECODER_RENDERER_CALLBACKS) dlsym(RTLD_DEFAULT, "decoder_callbacks_imx");
  #endif
  #ifdef HAVE_PI
  case PI:
    return (PDECODER_RENDERER_CALLBACKS) dlsym(RTLD_DEFAULT, "decoder_callbacks_pi");
  #endif
  #ifdef HAVE_MMAL
  case MMAL:
    return (PDECODER_RENDERER_CALLBACKS) dlsym(RTLD_DEFAULT, "decoder_callbacks_mmal");
  #endif
  #ifdef HAVE_AML
  case AML:
    return (PDECODER_RENDERER_CALLBACKS) dlsym(RTLD_DEFAULT, "decoder_callbacks_aml");
  #endif
  #ifdef HAVE_ROCKCHIP
  case RK:
    return (PDECODER_RENDERER_CALLBACKS) dlsym(RTLD_DEFAULT, "decoder_callbacks_rk");
  #endif
  }
  return NULL;
}

AUDIO_RENDERER_CALLBACKS* platform_get_audio(enum platform system, char* audio_device) {
  switch (system) {
  case FAKE:
      return NULL;
  #ifdef HAVE_SDL
  case SDL:
    return &audio_callbacks_sdl;
  #endif
  #ifdef HAVE_PI
  case PI:
    if (audio_device == NULL || strcmp(audio_device, "local") == 0 || strcmp(audio_device, "hdmi") == 0)
      return (PAUDIO_RENDERER_CALLBACKS) dlsym(RTLD_DEFAULT, "audio_callbacks_omx");
    // fall-through
  #endif
  default:
    #ifdef HAVE_PULSE
    if (audio_pulse_init(audio_device))
      return &audio_callbacks_pulse;
    #endif
    #ifdef HAVE_ALSA
    return &audio_callbacks_alsa;
    #endif
    #ifdef __FreeBSD__
    return &audio_callbacks_oss;
    #endif
  }
  return NULL;
}

bool platform_prefers_codec(enum platform system, enum codecs codec) {
  switch (codec) {
  case CODEC_H264:
    // H.264 is always supported
    return true;
  case CODEC_HEVC:
    switch (system) {
    case AML:
    case AML_VFM:
    case RK:
    case X11_VAAPI:
    case X11_VDPAU:
      return true;
    }
    return false;
  case CODEC_AV1:
    return false;
  }
  return false;
}

char* platform_name(enum platform system) {
  switch(system) {
  case PI:
    return "Raspberry Pi (Broadcom)";
  case MMAL:
    return "Raspberry Pi (Broadcom) MMAL";
  case IMX:
    return "i.MX6 (MXC Vivante)";
  case AML:
    return "AMLogic VPU";
  case AML_VFM:
    return "Amlogic V4L2/VFM (experimental SDR/HDR10)";
  case RK:
    return "Rockchip VPU";
  case X11:
    return "X Window System (software decoding)";
  case X11_VAAPI:
    return "X Window System (VAAPI)";
  case X11_VDPAU:
    return "X Window System (VDPAU)";
  case SDL:
    return "SDL2 (software decoding)";
  case FAKE:
    return "Fake (no a/v output)";
  default:
    return "Unknown";
  }
}
