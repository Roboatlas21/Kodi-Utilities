Luna NG version: 2.7.1.309
Luna commit: 29b8688e567fb67cc856cc7f25c30b0a51753388
Moonlight native commit: fdea965c94bd8a081628ac5f5623c45b4ecb6799
Moonlight native run: 41369667296
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
