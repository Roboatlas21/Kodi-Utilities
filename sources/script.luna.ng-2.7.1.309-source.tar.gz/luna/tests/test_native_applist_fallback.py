"""Native fallback must keep host IDs for identically titled applications."""
import os
import subprocess
import tempfile
import sys
import types
import unittest
from unittest import mock

sys.modules.setdefault('xbmc', types.ModuleType('xbmc'))
sys.modules.setdefault('xbmcgui', types.ModuleType('xbmcgui'))

from resources.lib.util.moonlighthelper import MoonlightHelper


def native_output(*records):
    return ('Connecting to host...\nLUNA_APP_IDS_V1\n' +
            ''.join('%s\t%s\n' % (app_id, title.encode('utf-8').hex())
                    for app_id, title in records) +
            'LUNA_APP_IDS_END\n')


class NativeFallbackTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self.tempdir.cleanup)
        self.host = 'sunshine-a'
        self.snapshot = os.path.join(self.tempdir.name, 'host.conf')
        def create_snapshot():
            with open(self.snapshot, 'w') as file:
                file.write('[Moonlight]\naddress = %s\n' % self.host)
            return self.snapshot
        self.helper = MoonlightHelper.__new__(MoonlightHelper)
        self.helper.config_helper = types.SimpleNamespace(
            binary_path='/addon/bin/coreelec-ng/',
            addon_path='/addon',
            config={'host_addr': self.host},
            create_host_lookup_snapshot=create_snapshot,
            configure=lambda dump=False: None)
        self.helper.last_host_error = None

    def test_duplicate_titles_keep_distinct_ids(self):
        reply = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout=native_output(('42', 'Desktop'), ('99', 'Desktop')))
        with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                        return_value=reply) as run:
            result = self.helper.list_games_native_detailed()
        self.assertEqual(result, [('42', 'Desktop', None),
                                  ('99', 'Desktop', None)])
        cmd = run.call_args.args[0]
        self.assertEqual(cmd[:2], ['/addon/bin/coreelec-ng/moonlight', 'list-ids'])
        self.assertEqual(cmd[-2:], ['-config', self.snapshot])
        self.assertEqual(run.call_args.kwargs['env']['LUNA_STREAM_CONFIG'], self.snapshot)
        self.assertFalse(os.path.exists(self.snapshot))

    def test_host_change_uses_selected_host_not_stale_shared_config(self):
        for chosen in ('sunshine-a', 'sunshine-b'):
            self.host = chosen
            self.helper.config_helper.config['host_addr'] = chosen
            reply = subprocess.CompletedProcess(
                args=[], returncode=0,
                stdout=native_output(('42', 'Desktop')))
            def validate(command, **kwargs):
                with open(command[-1], encoding='utf-8') as snapshot:
                    self.assertIn('address = ' + chosen, snapshot.read())
                self.assertEqual(kwargs['env']['LUNA_STREAM_CONFIG'], command[-1])
                return reply
            with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                            side_effect=validate):
                self.assertEqual(self.helper.list_games_native_detailed()[0][0], '42')
            self.assertFalse(os.path.exists(self.snapshot))

    def test_running_app_status_uses_same_private_host_snapshot(self):
        reply = subprocess.CompletedProcess(
            args=[], returncode=0, stdout='LUNA_APP_STATUS_V1 99\n')
        with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                        return_value=reply) as run:
            current, error = self.helper._running_ng_app(
                '/addon/bin/coreelec-ng/',
                {'LUNA_STREAM_CONFIG': '/tmp/private-luna.conf'}, '42')
        self.assertEqual((current, error), ('99', None))
        self.assertEqual(run.call_args.args[0],
                         ['/addon/bin/coreelec-ng/moonlight', 'app-status',
                          '-config', '/tmp/private-luna.conf', '-appid', '42'])

    def test_app_status_native_failure_never_uses_legacy_list(self):
        failure = subprocess.CompletedProcess(
            args=[], returncode=1, stdout='host unreachable\n')
        with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                        return_value=failure) as runner:
            current, error = self.helper._running_ng_app(
                '/addon/bin/coreelec-ng/',
                {'LUNA_STREAM_CONFIG': '/tmp/private.conf'}, '42')
        self.assertIsNone(current)
        self.assertIn('offline, unpaired', error)
        self.assertEqual(runner.call_count, 1)
        self.assertEqual(runner.call_args.args[0][1], 'app-status')

    def test_conflict_choices_are_explicit_and_can_be_cancelled(self):
        dialog = mock.Mock()
        dialog.select.return_value = 0
        with mock.patch.object(
                sys.modules['xbmcgui'], 'Dialog', return_value=dialog,
                create=True):
            choice = self.helper._ng_conflict_choice('99', 'Desktop')
        self.assertEqual(choice, 0)
        choices = dialog.select.call_args.args[1]
        self.assertEqual(len(choices), 3)
        self.assertIn('Cancel', choices[0])
        self.assertIn('Resume', choices[1])
        self.assertIn('Quit', choices[2])

    def test_running_app_state_rejects_ambiguous_or_invalid_responses(self):
        for content in ('', 'LUNA_APP_STATUS_V1 -1\n',
                        'LUNA_APP_STATUS_V1 12\nLUNA_APP_STATUS_V1 99\n'):
            with self.subTest(content=content):
                reply = subprocess.CompletedProcess(
                    args=[], returncode=0, stdout=content)
                with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                                return_value=reply):
                    current, error = self.helper._running_ng_app(
                        '/addon/bin/coreelec-ng',
                        {'LUNA_STREAM_CONFIG': '/tmp/check.conf'}, '12')
                self.assertIsNone(current)
                self.assertTrue(error)

    def test_legacy_name_listing_never_invokes_unbound_native_list(self):
        with mock.patch.object(self.helper, 'list_games_native_detailed',
                               return_value=None), mock.patch(
                'resources.lib.util.moonlighthelper.subprocess.check_output'
                ) as native:
            self.assertFalse(self.helper.list_games())
            native.assert_not_called()

    def test_duplicate_names_cannot_be_returned_without_exact_ids(self):
        with mock.patch.object(self.helper, 'list_games_native_detailed',
                               return_value=[('42', 'Desktop', None),
                                             ('99', 'Desktop', None)]):
            self.assertFalse(self.helper.list_games())
            self.assertIn('exact ID', self.helper.last_host_error)

    def test_unicode_and_newline_titles_roundtrip(self):
        reply = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout=native_output(('7', 'Jeu é\ntab\tname')))
        with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                        return_value=reply):
            self.assertEqual(self.helper.list_games_native_detailed(),
                             [('7', 'Jeu é\ntab\tname', None)])

    def test_missing_markers_and_invalid_ids_fail_closed(self):
        for body in ('42\t4465736b746f70\n',
                     native_output(('2147483648', 'Desktop')),
                     native_output(('42', 'A'), ('42', 'B')),
                     'LUNA_APP_IDS_V1\n42\tzz\nLUNA_APP_IDS_END\n'):
            with self.subTest(body=body[:35]):
                reply = subprocess.CompletedProcess(
                    args=[], returncode=0, stdout=body)
                with mock.patch('resources.lib.util.moonlighthelper.subprocess.run',
                                return_value=reply):
                    self.assertIsNone(self.helper.list_games_native_detailed())
                self.assertIn('Cannot safely', self.helper.last_host_error)


if __name__ == '__main__':
    unittest.main()
