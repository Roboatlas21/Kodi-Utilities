"""Exact EDID mode matching and durable, non-overwriting HDMI restoration."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

from resources.lib.util import hdmimode, safefile


class HdmiModeMatchingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.mode = self.root / 'mode'
        self.cap = self.root / 'disp_cap'
        self.state = self.root / '.luna-session.aBcD1234.displaymode-state'
        self.config = self.root / 'stream.conf'
        self.mode.write_text('1080p120hz\n')
        self.cap.write_text('1080p60hz\n1080p120hz*\n2160p60hz\n2160p60hz420\n')
        self.set_stream(3840, 2160, 60)

    def set_stream(self, width, height, fps):
        self.config.write_text(
            '[Moonlight]\nwidth = %s\nheight = %s\nfps = %s\n' %
            (width, height, fps))

    def test_4k60_switch_is_verified_and_restored(self):
        real_write = hdmimode.write_mode
        def before_write(node, value):
            self.assertTrue(self.state.exists(), 'journal must precede modeset')
            saved = json.loads(self.state.read_text())
            self.assertEqual(saved['original'], '1080p120hz')
            real_write(node, value)
        with mock.patch.object(hdmimode, 'write_mode', side_effect=before_write):
            hdmimode.apply(self.state, self.mode, self.cap, self.config)
            self.assertEqual(hdmimode.read_mode(self.mode), '2160p60hz')
            hdmimode.restore(self.state, self.mode, self.cap)
        self.assertEqual(hdmimode.read_mode(self.mode), '1080p120hz')
        self.assertFalse(self.state.exists())

    def test_fallback_420_only_when_advertised_for_uhd(self):
        self.cap.write_text('1080p120hz\n2160p60hz420*\n')
        hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.assertEqual(hdmimode.read_mode(self.mode), '2160p60hz420')
        hdmimode.restore(self.state, self.mode, self.cap)
        self.assertEqual(hdmimode.read_mode(self.mode), '1080p120hz')

    def test_already_matched_does_not_force_chroma_change(self):
        self.mode.write_text('2160p60hz420\n')
        hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.assertFalse(self.state.exists())
        self.assertEqual(hdmimode.read_mode(self.mode), '2160p60hz420')

    def test_unsupported_size_fps_or_edid_blocks_launch(self):
        originals = self.mode.read_text()
        for dims in ((2560, 1440, 60), (3840, 2160, 120),
                     (1920, 1080, 24)):
            self.set_stream(*dims)
            with self.subTest(dims=dims):
                with self.assertRaisesRegex(
                        hdmimode.HdmiModeUnavailable,
                        'Exact HDMI matching|does not advertise'):
                    hdmimode.apply(self.state, self.mode, self.cap, self.config)
                self.assertEqual(self.mode.read_text(), originals)
                self.assertFalse(self.state.exists())
        self.set_stream(3840, 2160, 60)
        self.cap.write_text('1080p60hz\n2160p60hz\n')
        with self.assertRaisesRegex(
                hdmimode.HdmiModeUnavailable, 'not listed'):
            hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.assertFalse(self.state.exists())  # Original mode not in cap.

    def test_read_only_check_matches_apply_and_preserves_display(self):
        with mock.patch.object(hdmimode, 'write_mode',
                               side_effect=AssertionError('write forbidden')):
            current, target = hdmimode.check(
                self.config, self.mode, self.cap)
        self.assertEqual((current, target), ('1080p120hz', '2160p60hz'))
        self.assertEqual(self.mode.read_text(), '1080p120hz\n')
        self.assertFalse(self.state.exists())

    def test_missing_edid_and_mode_readback_fail_closed(self):
        self.cap.write_text('unrecognized-mode\n')
        with self.assertRaisesRegex(
                hdmimode.HdmiModeUnavailable, 'did not advertise'):
            hdmimode.check(self.config, self.mode, self.cap)
        self.cap.unlink()
        with self.assertRaisesRegex(
                hdmimode.HdmiModeUnavailable, 'Cannot verify'):
            hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.assertFalse(self.state.exists())
        self.assertEqual(self.mode.read_text(), '1080p120hz\n')

    def test_corrupt_or_different_root_journal_is_rejected(self):
        self.state.write_text(json.dumps(
            {'schema': 1, 'mode_node': str(self.root / 'unrelated'),
             'original': '1080p120hz', 'applied': '2160p60hz'}))
        with self.assertRaisesRegex(ValueError, 'unsafe'):
            hdmimode.restore(self.state, self.mode, self.cap)
        self.assertEqual(self.mode.read_text(), '1080p120hz\n')
        self.assertTrue(self.state.exists())
        self.state.unlink()
        self.state.symlink_to(self.mode)
        with self.assertRaisesRegex(ValueError, 'symlink'):
            hdmimode.restore(self.state, self.mode, self.cap)
        self.assertEqual(self.mode.read_text(), '1080p120hz\n')

    def test_unfinished_journal_blocks_reapply(self):
        hdmimode.apply(self.state, self.mode, self.cap, self.config)
        with self.assertRaisesRegex(ValueError, 'pending'):
            hdmimode.apply(self.state, self.mode, self.cap, self.config)
        hdmimode.restore(self.state, self.mode, self.cap)

    def test_external_mode_change_is_preserved(self):
        hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.mode.write_text('1080p60hz\n')
        hdmimode.restore(self.state, self.mode, self.cap)
        self.assertEqual(hdmimode.read_mode(self.mode), '1080p60hz')
        self.assertFalse(self.state.exists())

    def test_reset_mode_is_not_forced_when_original_edid_disappears(self):
        hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.cap.write_text('2160p60hz\n')
        with self.assertRaisesRegex(OSError, 'no longer'):
            hdmimode.restore(self.state, self.mode, self.cap)
        self.assertTrue(self.state.exists())
        self.assertEqual(hdmimode.read_mode(self.mode), '2160p60hz')
        self.cap.write_text('1080p120hz\n2160p60hz\n')
        hdmimode.restore(self.state, self.mode, self.cap)

    def test_mode_write_error_uses_same_journal_to_roll_back(self):
        real_write = hdmimode.write_mode
        def failed_mode_set(node, value):
            real_write(node, value)
            if value == '2160p60hz':
                raise OSError('injected write failure')
        with mock.patch.object(hdmimode, 'write_mode', side_effect=failed_mode_set):
            with self.assertRaisesRegex(OSError, 'injected'):
                hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.assertEqual(hdmimode.read_mode(self.mode), '1080p120hz')
        self.assertFalse(self.state.exists())

    def test_invalid_snapshot_rejects_launch_without_modifying_display(self):
        self.config.write_text('[Moonlight]\nwidth = garbage\n')
        with self.assertRaisesRegex(
                hdmimode.HdmiModeUnavailable, 'Cannot read'):
            hdmimode.apply(self.state, self.mode, self.cap, self.config)
        self.assertFalse(self.state.exists())
        self.assertEqual(hdmimode.read_mode(self.mode), '1080p120hz')

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_fifo_config_is_rejected_without_waiting_for_writer(self):
        self.config.unlink()
        os.mkfifo(self.config)
        start = time.monotonic()
        with self.assertRaisesRegex(hdmimode.HdmiModeUnavailable, 'Cannot read'):
            hdmimode.check(self.config, self.mode, self.cap)
        self.assertLess(time.monotonic() - start, 1.5)
        self.assertFalse(self.state.exists())
        self.assertEqual(self.mode.read_text(), '1080p120hz\n')

    def test_symlink_and_oversized_config_fail_before_modeset(self):
        target = self.root / 'target.conf'
        target.write_text('[Moonlight]\nwidth=3840\nheight=2160\nfps=60\n')
        self.config.unlink()
        self.config.symlink_to(target)
        with self.assertRaises(hdmimode.HdmiModeUnavailable):
            hdmimode.check(self.config, self.mode, self.cap)
        self.config.unlink()
        self.config.write_bytes(b' ' * (hdmimode.MAX_STREAM_CONFIG_BYTES + 1))
        with self.assertRaises(hdmimode.HdmiModeUnavailable):
            hdmimode.check(self.config, self.mode, self.cap)
        self.assertFalse(self.state.exists())
        self.assertEqual(self.mode.read_text(), '1080p120hz\n')

    def test_concurrent_config_path_replacement_uses_original_snapshot(self):
        original_open = os.open
        incoming = self.root / 'replacement.conf'
        incoming.write_text('[Moonlight]\nwidth=garbage\nheight=99\nfps=0\n')
        def after_open(name, flags, *args, **kwargs):
            descriptor = original_open(name, flags, *args, **kwargs)
            if os.fspath(name) == os.fspath(self.config):
                os.replace(incoming, self.config)
            return descriptor
        with mock.patch.object(safefile.os, 'open', side_effect=after_open):
            self.assertEqual(
                hdmimode.snapshot_stream(self.config), (3840, 2160, 60))
        self.assertIn('garbage', self.config.read_text())

    def test_standalone_hdmi_preflight_resolves_helpers_without_kodi_path(self):
        root = Path(__file__).resolve().parents[1]
        script = root / 'resources/lib/util/hdmimode.py'
        env = os.environ.copy()
        env.pop('PYTHONPATH', None)
        run = subprocess.run(
            [sys.executable, str(script), 'check',
             str(self.mode), str(self.cap), str(self.config)],
            cwd=self.root, env=env, capture_output=True, text=True, timeout=10)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn('1080p120hz -> 2160p60hz', run.stdout)

    def test_edid_token_parser_rejects_unknown_modes(self):
        caps = hdmimode.capabilities(
            '1080i50hz\n2160p60hz420*\ncustom_cmd\n'
            '../malicious\n3840x2160p999hz\n')
        self.assertEqual(caps, {'1080i50hz', '2160p60hz420'})
        self.assertFalse(hdmimode.valid_mode('1080p60hz;reboot'))


if __name__ == '__main__':
    unittest.main()
