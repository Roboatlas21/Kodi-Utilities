"""Exercise real Kodi folder actions without loading addon.py's entry point."""
import ast
from pathlib import Path
import types
import unittest
from unittest import mock

SOURCE = Path(__file__).resolve().parents[1] / 'addon.py'
FUNCTIONS = {'_folder_feedback', 'newFolder', 'renameFolder',
             'deleteFolder', 'assignApp'}


class FolderUiFeedbackTests(unittest.TestCase):
    def setUp(self):
        parsed = ast.parse(SOURCE.read_text(encoding='utf-8'))
        definitions = [node for node in parsed.body
                       if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS]
        self.assertEqual({node.name for node in definitions}, FUNCTIONS)
        self.dialog = mock.Mock()
        self.library = mock.Mock()
        self.library.folders.return_value = ['Existing', 'Other']
        self.library.folder_of.return_value = 'Existing'
        self.xbmc = types.SimpleNamespace(
            executebuiltin=mock.Mock(),
            getLocalizedString=lambda _id: '')
        self.xbmcgui = types.SimpleNamespace(
            Dialog=lambda: self.dialog,
            NOTIFICATION_ERROR='error',
            NOTIFICATION_INFO='info')
        self.scope = {
            'xbmc': self.xbmc, 'xbmcgui': self.xbmcgui,
            'addon': types.SimpleNamespace(getLocalizedString=lambda _id: ''),
            '_library': lambda: self.library, 'args': {}
        }
        artifact = ast.Module(body=definitions, type_ignores=[])
        exec(compile(artifact, str(SOURCE), 'exec'), self.scope)

    def assert_save_failure(self):
        self.dialog.notification.assert_called()
        self.assertEqual(self.dialog.notification.call_args.args[2], 'error')
        self.xbmc.executebuiltin.assert_not_called()

    def test_create_write_failure_is_visible(self):
        self.dialog.input.return_value = 'New'
        self.library.add_folder.return_value = False
        self.scope['newFolder']()
        self.library.add_folder.assert_called_once_with('New')
        self.assert_save_failure()

    def test_create_success_refreshes_only_after_save(self):
        self.dialog.input.return_value = 'New'
        self.library.add_folder.return_value = True
        self.scope['newFolder']()
        self.library.add_folder.assert_called_once_with('New')
        self.dialog.notification.assert_not_called()
        self.xbmc.executebuiltin.assert_called_once_with('Container.Refresh')

    def test_existing_folder_is_noop_not_write_failure(self):
        self.dialog.input.return_value = 'Existing'
        self.scope['newFolder']()
        self.library.add_folder.assert_not_called()
        self.assertEqual(self.dialog.notification.call_args.args[2], 'info')

    def test_rename_write_failure_is_visible(self):
        self.scope['args'] = {'folder': ['Existing']}
        self.dialog.input.return_value = 'Renamed'
        self.library.rename_folder.return_value = False
        self.scope['renameFolder']()
        self.library.rename_folder.assert_called_once_with('Existing', 'Renamed')
        self.assert_save_failure()

    def test_removal_write_failure_is_visible(self):
        self.scope['args'] = {'folder': ['Existing']}
        self.dialog.yesno.return_value = True
        self.library.remove_folder.return_value = False
        self.scope['deleteFolder']()
        self.library.remove_folder.assert_called_once_with('Existing')
        self.assert_save_failure()

    def test_assignment_write_failure_is_visible(self):
        self.scope['args'] = {'id': ['42']}
        self.dialog.select.return_value = 2  # Other, after New and Remove
        self.library.assign.return_value = False
        self.scope['assignApp']()
        self.library.assign.assert_called_once_with('42', 'Other')
        self.assert_save_failure()

    def test_new_folder_created_but_assignment_failed(self):
        self.scope['args'] = {'id': ['42']}
        self.dialog.select.return_value = 0
        self.dialog.input.return_value = 'New'
        self.library.add_folder.return_value = True
        self.library.assign.return_value = False
        self.scope['assignApp']()
        self.library.add_folder.assert_called_once_with('New')
        self.library.assign.assert_called_once_with('42', 'New')
        self.assert_save_failure()


if __name__ == '__main__':
    unittest.main()
