#!/usr/bin/env bash
# Private Luna counterpart of the public Luna-build grouped test runner.
# Usage: bash packaging/validate_private.sh {luna-python|luna-launch|luna-packaging} [LUNA_ROOT]
set -uo pipefail
group="${1:?validation group required}"
root="${2:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$root" || exit 1
base="${SOURCE_VALIDATION_LOG_DIR:-${RUNNER_TEMP:-/tmp}/source-validation}"
log_dir="$base/$group"
mkdir -p "$log_dir" || exit 1
printf 'check\tresult\texit_code\tlog\n' > "$log_dir/results.tsv"
checks=0
failures=0
run_checked() {
  local label="$1" safe log result=0
  shift
  checks=$((checks + 1))
  safe="${label//[^a-zA-Z0-9_.-]/_}"
  printf -v log '%s/%03d-%s.log' "$log_dir" "$checks" "$safe"
  printf '::group::Luna %s / %s\n' "$group" "$label"
  "$@" 2>&1 | tee "$log"
  local -a states=( "${PIPESTATUS[@]}" )
  if (( states[0] != 0 )); then result="${states[0]}"; fi
  if (( result == 0 && states[1] != 0 )); then result="${states[1]}"; fi
  printf '::endgroup::\n'
  if (( result )); then
    failures=$((failures + 1))
    printf 'SOURCE_CHECK_FAIL group=%s check=%s exit=%d\n' "$group" "$label" "$result" >&2
    printf '%s\tFAIL\t%d\t%s\n' "$label" "$result" "$log" >> "$log_dir/results.tsv"
  else
    printf 'SOURCE_CHECK_PASS group=%s check=%s\n' "$group" "$label"
    printf '%s\tPASS\t0\t%s\n' "$label" "$log" >> "$log_dir/results.tsv"
  fi
  return 0
}
case "$group" in
  luna-python)
    for required in resources/lib/util/resumestate.py resources/lib/util/hdmigamemode.py; do
      run_checked "required-${required//\//-}" test -f "$required"
    done
    run_checked compile python3 -m compileall -q addon.py resources/lib
    run_checked all_unittests python3 -m unittest discover -s tests -v
    ;;
  luna-launch)
    for script in \
      resources/launchscripts/coreelec/launch.sh \
      resources/launchscripts/coreelec/kodi-watchdog.sh \
      resources/launchscripts/coreelec/hang-diagnostics.sh \
      resources/launchscripts/coreelec/tsync.sh \
      resources/launchscripts/coreelec/aml-recovery.sh \
      resources/launchscripts/coreelec/display-recovery.sh \
      resources/launchscripts/coreelec/session-ownership.sh \
      resources/launchscripts/coreelec/recovery-journal.sh; do
      run_checked "syntax-$(basename "$script")" sh -n "$script"
    done
    run_checked launch_integration bash tests/test_launch.sh
    run_checked launch_cleanup bash tests/test_launch_file_cleanup.sh
    run_checked aml_recovery bash tests/test_aml_recovery.sh
    ;;
  luna-packaging)
    run_checked package_python_syntax python3 -m py_compile packaging/package_ng.py packaging/verify_vfm_runtime.py
    run_checked addon_metadata test -s addon.xml
    run_checked source_pin test -s packaging/moonlight-source-pin.json
    run_checked addon_license test -s LICENSE.txt
    run_checked vfm_runtime_tests python3 -m unittest discover -s tests -p test_vfm_runtime.py -v
    run_checked vfm_module_identity python3 -m unittest discover -s tests -p test_vfm_loaded_module_identity.py -v
    run_checked native_release_workflow python3 -m unittest discover -s tests -p test_private_build_workflow.py -v
    ;;
  *)
    echo "Unknown Luna private validation group: $group" >&2
    exit 2
    ;;
esac
printf '\nSOURCE_VALIDATION_SUMMARY group=%s total=%d failed=%d\n' "$group" "$checks" "$failures"
if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    printf '### Luna %s validation\n\n' "$group"
    printf '| Check | Result | Exit code |\n| --- | --- | --- |\n'
    while IFS=$'\t' read -r label outcome code log; do
      [[ "$label" == check ]] && continue
      printf '| %s | %s | %s |\n' "$label" "$outcome" "$code"
    done < "$log_dir/results.tsv"
    printf '\n%d checks, %d failures. Individual logs are retained as artifacts.\n' "$checks" "$failures"
  } >> "$GITHUB_STEP_SUMMARY"
fi
if (( failures )); then
  printf '::error::Luna %s validation: %d/%d checks failed\n' "$group" "$failures" "$checks" >&2
  exit 1
fi
