Luna NG CoreELEC 21 ARM32 version: 2.7.1.288
Luna frontend SHA: 631606663000cba2d7d2608568d37289d8b028b1
Moonlight native SHA: 0b78feecce3caf37db48c37eb5532af70216b06a
Native GitHub Actions run: 40374391736
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
