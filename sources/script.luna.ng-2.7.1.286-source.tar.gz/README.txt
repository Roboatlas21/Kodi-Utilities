Luna NG CoreELEC 21 ARM32 version: 2.7.1.286
Luna frontend SHA: 2b7b137f43fa9838481069597d24242ae5320bd9
Moonlight native SHA: c1ae6949b41676097e549dc15c6a4b31d9ce5053
Native GitHub Actions run: 40261805728
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
