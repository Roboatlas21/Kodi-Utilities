Luna NG CoreELEC 21 ARM32 version: 2.7.1.290
Luna frontend SHA: 0bffd1a74af0443411b7d949edc30bd51fc60b84
Moonlight native SHA: fcd33bbc59be93253648ff916b6cb04f678855cb
Native GitHub Actions run: 40552613772
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
