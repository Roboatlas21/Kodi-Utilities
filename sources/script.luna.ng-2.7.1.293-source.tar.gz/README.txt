Luna NG CoreELEC 21 ARM32 version: 2.7.1.293
Luna frontend SHA: 86fb21ab3b2dc9e589150cb313fe77463e8156ae
Moonlight native SHA: 98701e55c73a30f7f651b7a1daf95fac3970cf0a
Native GitHub Actions run: 40558118079
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
