Luna NG CoreELEC 21 ARM32 version: 2.7.1.295
Luna frontend SHA: 80102e5130a8de57dcea29949a4500d1061f1f25
Moonlight native SHA: 98701e55c73a30f7f651b7a1daf95fac3970cf0a
Native GitHub Actions run: 40558118079
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
