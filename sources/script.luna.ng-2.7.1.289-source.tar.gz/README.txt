Luna NG CoreELEC 21 ARM32 version: 2.7.1.289
Luna frontend SHA: 631606663000cba2d7d2608568d37289d8b028b1
Moonlight native SHA: 17e3b4e3181bfb11167ea448b16009a895680803
Native GitHub Actions run: 40550055606
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
