/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_REMOTE_INPUT_H
#define MOONLIGHT_REMOTE_INPUT_H

#include <stdbool.h>

/*
 * Classify a navigation-oriented HID without relying on vendor/product IDs.
 * Real gamepads and full keyboards keep their host-facing Back/Escape keys.
 */
static inline bool moonlight_is_navigation_remote(bool is_keyboard,
                                                  bool is_gamepad,
                                                  bool has_back_or_exit,
                                                  bool has_direction,
                                                  bool has_enter) {
  return !is_keyboard && !is_gamepad &&
         has_back_or_exit && has_direction && has_enter;
}

#endif
