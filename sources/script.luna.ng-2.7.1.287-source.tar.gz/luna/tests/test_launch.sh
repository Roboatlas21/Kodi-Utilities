#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
cat >"$tmp/killall" <<'EOF'
#!/bin/sh
printf '%s\n' "$*" >> "$CALLS"
EOF
mkdir -p "$tmp/coreelec-ng"
cat >"$tmp/coreelec-ng/moonlight" <<'EOF'
#!/bin/sh
printf '%s\n' "$*" >> "$CALLS"
exit 42
EOF
cat >"$tmp/vfm-write" <<'EOF'
#!/bin/sh
printf '%s\n' "$2" >> "$VFM_CALLS"
case "$2" in
  'rm default')
    : > "$1"
    ;;
  'add default decoder amvideo')
    if [ "${VFM_FAIL_ADD:-0}" = 1 ]; then
      exit 1
    fi
    printf '%s\n' '[00]  default { decoder(0) amvideo}' > "$1"
    ;;
  *)
    exit 1
    ;;
esac
EOF
chmod +x "$tmp/killall" "$tmp/coreelec-ng/moonlight" "$tmp/vfm-write"
export CALLS="$tmp/calls" LUNA_LOG_DIR="$tmp/logs"
export MOONLIGHT_BINARY="$tmp/coreelec-ng/moonlight"
export VFM_CALLS="$tmp/vfm-calls" LUNA_VFM_MAP="$tmp/vfm-map"
export LUNA_VFM_WRITE_HELPER="$tmp/vfm-write"
printf '%s\n' '[00]  default { }' > "$LUNA_VFM_MAP"
export PATH="$tmp:$PATH"
export LUNA_FB0_BLANK="$tmp/fb0.blank" LUNA_FB1_BLANK="$tmp/fb1.blank"
printf '1' > "$LUNA_FB0_BLANK"
printf '1' > "$LUNA_FB1_BLANK"
launcher="$root/resources/launchscripts/coreelec/launch.sh"
watchdog="$root/resources/launchscripts/coreelec/kodi-watchdog.sh"
grep -Fxq '#!/bin/sh' "$launcher"
grep -Fxq '#!/bin/sh' "$watchdog"
for stage in prescript postscript; do
  helper="$root/resources/launchscripts/coreelec/$stage.sh"
  grep -Fxq '#!/bin/sh' "$helper"
  "$helper" "$tmp" H264
done
sh -n "$launcher"
sh -n "$watchdog"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 42 ]]
grep -q -- '-STOP kodi.bin' "$CALLS"
grep -q -- 'stream -app Desktop' "$CALLS"
grep -q -- '-CONT kodi.bin' "$CALLS"
[[ "$(grep -c -- '-CONT kodi.bin' "$CALLS")" == 1 ]]
grep -Fxq 'rm default' "$VFM_CALLS"
grep -Fxq 'add default decoder amvideo' "$VFM_CALLS"
grep -Eq 'default[[:space:]]*\{[[:space:]]*decoder\(0\)[[:space:]]+amvideo[[:space:]]*\}' "$LUNA_VFM_MAP"
grep -Fq 'Luna NG: installed decoder -> amvideo VFM route' "$LUNA_LOG_DIR/logfile"
[[ "$(cat "$LUNA_FB0_BLANK")" == 0 ]]
[[ "$(cat "$LUNA_FB1_BLANK")" == 0 ]]
[[ -z "$(find "$tmp/logs" -name '.luna-session.*' -print)" ]]

# Existing non-empty VFM routes are owned by somebody else and must not be
# replaced by the launcher.
: > "$CALLS"
: > "$VFM_CALLS"
printf '%s\n' '[00]  default { decoder(0) amvideo}' > "$LUNA_VFM_MAP"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 42 ]]
[[ ! -s "$VFM_CALLS" ]]
grep -q -- '-STOP kodi.bin' "$CALLS"
grep -q -- 'stream -app Desktop' "$CALLS"

# If an empty NG route cannot be established, abort before Kodi is stopped.
: > "$CALLS"
: > "$VFM_CALLS"
printf '%s\n' '[00]  default { }' > "$LUNA_VFM_MAP"
export VFM_FAIL_ADD=1
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
unset VFM_FAIL_ADD
[[ "$status" == 1 ]]
grep -Fxq 'rm default' "$VFM_CALLS"
grep -Fxq 'add default decoder amvideo' "$VFM_CALLS"
! grep -q -- '-STOP kodi.bin' "$CALLS"
grep -Fq 'Refusing to suspend Kodi without a usable Luna NG video route' "$tmp/out"

: > "$CALLS"
export MOONLIGHT_BINARY="$tmp/no-binary"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 127 ]]
! grep -q -- '-STOP kodi.bin' "$CALLS"

# A real SIGKILL is not required to test recovery: simulate a zombie launcher
# in a fixture /proc tree and check that the independent worker sends CONT.
mkdir -p "$tmp/proc/424242"
printf '424242 (launch with spaces) Z' >"$tmp/proc/424242/stat"
for i in $(seq 1 18); do printf ' 0' >>"$tmp/proc/424242/stat"; done
printf ' 123456 0\n' >>"$tmp/proc/424242/stat"
: > "$CALLS"
printf '1' > "$LUNA_FB0_BLANK"
printf '1' > "$LUNA_FB1_BLANK"
export LUNA_WATCHDOG_TEST_ONLY=1 LUNA_WATCHDOG_TEST_PROC="$tmp/proc"
touch "$tmp/fixture-session"
sh "$watchdog" 424242 123456 "$tmp/fixture-session"
grep -Fq -- '-CONT kodi.bin' "$CALLS"
[[ "$(cat "$LUNA_FB0_BLANK")" == 0 ]]
[[ "$(cat "$LUNA_FB1_BLANK")" == 0 ]]
[[ ! -e "$tmp/fixture-session" ]]
[[ ! -e "$tmp/fixture-session.ready" ]]
echo 'PASS: VFM setup safety, normal exit, framebuffer restore, missing binary, and independent zombie rescue'
