#!/bin/sh
set -u
BIN="${MOONLIGHT_BINARY:-moonlight}"
LOG="${LUNA_LOG_DIR:-/storage/.kodi/userdata/addon_data/script.luna}/logfile"
VFM_MAP="${LUNA_VFM_MAP:-/sys/class/vfm/map}"
mkdir -p "$(dirname "$LOG")" || exit 1
if ! command -v "$BIN" >/dev/null 2>&1; then
  echo "Moonlight executable not found: $BIN" >&2
  exit 127
fi
scripts="$(CDPATH='' cd "$(dirname "$0")" && pwd)" || exit 1
if [ ! -r "$scripts/kodi-watchdog.sh" ]; then
  echo "Missing Kodi recovery watchdog" >&2
  exit 126
fi

# Linux start-time token prevents accidentally signaling a reused PID.
identity() {
  [ -r "/proc/$1/stat" ] || return 1
  line="$(cat "/proc/$1/stat" 2>/dev/null)" || return 1
  fields="${line##*) }"
  set -f
  set -- $fields
  [ "$#" -ge 20 ] || return 1
  printf '%s %s\n' "$1" "${20}"
}
self="$(identity "$$")" || exit 1
self_start="${self#* }"
session="$(mktemp "$(dirname "$LOG")/.luna-session.XXXXXXXX")" || exit 1
watchdog_pid=''
child=''
child_start=''
restore_kodi_framebuffers() {
  for blank in "${LUNA_FB0_BLANK:-/sys/class/graphics/fb0/blank}" \
               "${LUNA_FB1_BLANK:-/sys/class/graphics/fb1/blank}"; do
    [ -e "$blank" ] || continue
    if [ -w "$blank" ]; then
      printf '0' > "$blank" 2>/dev/null || \
        echo "Failed to unblank Kodi framebuffer: $blank" >&2
    else
      echo "Kodi framebuffer blank control is not writable: $blank" >&2
    fi
  done
}

vfm_write() {
  if [ -n "${LUNA_VFM_WRITE_HELPER:-}" ]; then
    "$LUNA_VFM_WRITE_HELPER" "$VFM_MAP" "$1"
  else
    printf '%s' "$1" > "$VFM_MAP"
  fi
}

ensure_ng_vfm_route() {
  # CoreELEC 21 NG exposes the active Amlogic stream as provider "decoder".
  # An empty default VFM route lets the decoder initialize but its buffers
  # never drain, producing black video and codec_write() EAGAIN timeouts.
  case "$BIN" in
    */coreelec-ng/moonlight) ;;
    *) return 0 ;;
  esac

  [ -r "$VFM_MAP" ] || return 0
  [ -w "$VFM_MAP" ] || {
    echo "Luna NG: VFM map is not writable: $VFM_MAP" >&2
    return 1
  }

  default_line="$(grep 'default[[:space:]]*{' "$VFM_MAP" 2>/dev/null | head -n 1)"
  [ -n "$default_line" ] || return 0

  # Never replace a route another component has already configured.
  if ! printf '%s\n' "$default_line" | \
       grep -Eq 'default[[:space:]]*\{[[:space:]]*\}'; then
    return 0
  fi

  if ! vfm_write 'rm default' || \
     ! vfm_write 'add default decoder amvideo'; then
    echo "Luna NG: failed to install decoder -> amvideo VFM route" >&2
    return 1
  fi

  default_line="$(grep 'default[[:space:]]*{' "$VFM_MAP" 2>/dev/null | head -n 1)"
  if ! printf '%s\n' "$default_line" | \
       grep -Eq 'default[[:space:]]*\{[[:space:]]*decoder(\([01]\))?[[:space:]]+amvideo[[:space:]]*\}'; then
    echo "Luna NG: decoder -> amvideo VFM route was not confirmed" >&2
    return 1
  fi

  echo "Luna NG: installed decoder -> amvideo VFM route" >> "$LOG"
  return 0
}

cleanup() {
  rc=$?
  trap - 0
  # If the script catches TERM/HUP/INT, also signal its own child. The
  # independent watcher covers launcher SIGKILL, which cannot be trapped.
  if [ -n "$child" ] && [ -n "$child_start" ]; then
    now="$(identity "$child")" || now=''
    if [ -n "$now" ] && [ "${now#* }" = "$child_start" ]; then
      case "${now%% *}" in Z|X|x) ;; *)
        kill -TERM "$child" 2>/dev/null || true ;;
      esac
    fi
  fi
  [ -z "$watchdog_pid" ] || kill -TERM "$watchdog_pid" 2>/dev/null || true
  rm -f "$session" "$session.ready"
  restore_kodi_framebuffers
  killall -CONT kodi.bin 2>/dev/null || true
  exit "$rc"
}
trap cleanup 0
trap 'exit 129' 1
trap 'exit 130' 2
trap 'exit 143' 15

# Start the rescue process BEFORE stopping Kodi. It is deliberately separate
# from the Kodi Python thread and the main Moonlight child.
sh "$scripts/kodi-watchdog.sh" "$$" "$self_start" "$session" \
  </dev/null >>"$LOG" 2>&1 &
watchdog_pid=$!
ready=0
tries=0
while [ "$tries" -lt 20 ]; do
  if [ -r "$session.ready" ]; then
    ready=1
    break
  fi
  if ! kill -0 "$watchdog_pid" 2>/dev/null; then
    break
  fi
  tries=$((tries + 1))
  sleep 0.1
done
if [ "$ready" -ne 1 ]; then
  echo "Kodi recovery watchdog did not initialize; refusing to suspend Kodi" >&2
  exit 1
fi
if [ -f "$LOG" ]; then mv -f "$LOG" "$LOG.old" 2>/dev/null || true; fi
if ! ensure_ng_vfm_route; then
  echo "Refusing to suspend Kodi without a usable Luna NG video route" >&2
  exit 1
fi
killall -STOP kodi.bin 2>/dev/null || true
"$BIN" stream -app "$@" >> "$LOG" 2>&1 &
child=$!
now="$(identity "$child")" || now=''
if [ -n "$now" ]; then
  child_start="${now#* }"
  printf '%s %s\n' "$child" "$child_start" > "$session"
fi
wait "$child"
exit $?
