Luna NG CoreELEC 21 ARM32 version: 2.7.1.296
Luna frontend SHA: 80102e5130a8de57dcea29949a4500d1061f1f25
Moonlight native SHA: 1bb69bd5d5fa6651d7e539342c2cd4774803aa46
Native GitHub Actions run: 40566930108
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
