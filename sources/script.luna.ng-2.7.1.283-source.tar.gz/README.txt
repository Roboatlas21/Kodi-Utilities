Luna NG CoreELEC 21 ARM32 version: 2.7.1.283
Luna frontend SHA: cd94159b65c6b53ed1ffde272af6372691feeef0
Moonlight native SHA: 0b78feecce3caf37db48c37eb5532af70216b06a
Native GitHub Actions run: 40374391736
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
