Luna NG version: 2.7.1.318
Luna commit: 629d0d318a42c4e4fc8b54ab6b2a299402b4ff79
Moonlight native commit: 88cc179341ccb1937c40aed607e2e1607dd7adb2
Moonlight native run: 41655163004
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
