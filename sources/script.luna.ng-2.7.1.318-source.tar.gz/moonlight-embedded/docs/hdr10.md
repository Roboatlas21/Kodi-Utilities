# CoreELEC NG HDR10

The AML decoder accepts negotiated HEVC Main10 through libamcodec's HEVC
path. `-codec h265 -hdr` (or `codec=h265` and `hdr=true` in the session
config) advertises Main10 support and requests HDR from Apollo/Sunshine.
Luna exposes this as a separate experimental toggle, off by default, and
selects HEVC for the session without changing the saved SDR codec.

A later explicit `hdr=false` now clears an earlier configuration's enabled
value. The CLI `-hdr` switch continues to enable it. Invalid HDR config
values fail with an explanation instead of silently changing the request.

Main10 negotiation and the host's HDR mode are logged separately. The
Amlogic decoder consumes the original HEVC VUI/SEI metadata, and CoreELEC
controls HDMI signalling. The host-mode callback is diagnostic; it does
not force global HDR/Dolby Vision state or claim the TV entered HDR.
Apollo/Sunshine must have HDR enabled on the streamed display, including
any virtual display, and the TV/HDMI path must support HDR10.

The experimental FFmpeg/VFM path supports HEVC Main10 through bridge ABI 2,
module version 6 and the matching `moonlight-hdr1` decoder extension. Its
ordinary SDR path remains linear NV12. For Main10, private FFmpeg selects
per-instance HEVC double-write mode 3 and exports a decoder/index token in
`AVFrame.opaque_ref`. The quarter-size 8-bit double-write only supplies the
V4L2 capture lifecycle; it is never presented as the HDR picture.

The bridge obtains the original full-resolution compressed vframe through
`aml_vfm_get_frame_v1`. It requires 10-bit Y/U/V, valid compression addresses,
matching full dimensions and PQ/BT.2020 or SDR/BT.709 signalling. It preserves
mastering-display and content-light metadata from the HEVC VUI/SEI unchanged,
and forces the compressed display path. It does not synthesize HDR metadata
from the asynchronous host-mode callback or relabel NV12 as 10-bit. HLG,
HDR10+, Dolby Vision and resolution changes are unsupported.

Each imported frame pins its decoder file and capture buffer. The decoder
rejects requeue of a held buffer and reset/streamoff/reallocation while any
frame is displayed. REAP releases ownership; STOP/close first blacks out and
unregisters the provider, then drops the references. This also protects the
picture if the process dies and its decoder fd closes before its bridge fd.
The AVFrame remains referenced until REAP or bridge close.

The build recipes patch only private FFmpeg and the matching decoder module;
the installed kernel image is unchanged. Luna verifies bridge version 6,
then, after stopping Kodi, replaces an idle stock `amvdec_ports` with the
bundled version using normal `rmmod`/`insmod`. It never force-unloads a busy
module. An older loaded bridge requires one reboot after installing the
complete future bundle. Do not mix the new plugin with old modules/libraries.

Host tests cover the actual config parser's on/off overrides and Luna's
settings-to-launch snapshot. Device testing must verify real HDR output,
colour correctness, OSD behaviour and return to SDR/Kodi. There is no
hardware-validation claim from these source changes alone.
