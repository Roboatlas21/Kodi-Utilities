# Native Moonlight configuration format

The standalone Moonlight client still reads legacy flat key=value files, or
a single [Moonlight] section. New native `-save` output is always sectioned,
so Luna can also read it. `-save` stages a complete, private (0600) file,
checks it with the real native parser, and atomically replaces only regular
file targets after the write succeeds. A failed save leaves the old bytes
untouched. Transient pairing PINs are deliberately not persisted.
Luna generates private per-launch [Moonlight] snapshots, which suppress
shared default config and mutable per-host files.

Supported syntax:
- key=value or key = value, tabs/spaces around '=', LF and CRLF.
- Blank lines and whole-line # and ; comments. Other INI sections are ignored.
- Exactly one [Moonlight] section when sections are present; preamble ignored.
- Repeated input keys up to 32; scalar settings exactly once per file.
- Keys are case-sensitive long options, plus address and sops.
- Booleans: true/false, yes/no, 1/0. Numeric/enum values use native CLI bounds.

Fail-closed behaviour:
- No nested 'config' includes or 'save' directives inside INI files; CLI-only.
- Invalid, duplicate, missing, or unknown entries fail without committing
  changes to the current runtime configuration or selected device count.
- The INI scanner publishes its entries only after the entire file is valid.
  INI conversion never calls the CLI parser, whose errors exit the process.
- Non-regular files, symlinks, unreadable files, embedded controls, binary NULs,
  files over 1 MiB and malformed section headers are rejected.
- Optional per-host files may change stream options but cannot redirect the
  selected Sunshine host. The host check runs before any changes commit,
  including when other entries would otherwise be valid.
  Existing unreadable files cause an explicit error.
- Invalid default files abort startup. Luna private snapshots suppress shared
  defaults and per-host overlays, but must themselves pass full validation.

Example:

~~~ini
[Moonlight]
address = gaming-vm
width = 3840
height = 2160
fps = 60
bitrate = 50000
codec = h265
hdr = true
cec = true
input = /dev/input/event2
input = /dev/input/event4
~~~

Run host-only parser tests with the private host checks script. Full ARM32
compilation and device validation are separate requirements.
