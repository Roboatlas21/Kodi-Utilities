# Experimental adaptive AMLVIDEO queue limit (CoreELEC NG)

This is the fourth optional Luna Frame Pacing mode, with the user-facing
order Lowest Latency / Low Latency / Adaptive / Balanced. Only Adaptive
uses the controller; all existing modes keep their previous behavior.

## Scope and boundaries

- The standard AMLVIDEO capture pump starts each Adaptive session at a
  maximum of **one** waiting decoded frame and can select **two or
  three** if sustained, qualified timing pressure appears.
- This is a bounded maximum queue limit, NOT a dynamic playout schedule,
  VRR implementation, GPU completion timestamp, measured HDMI-present
  time or guaranteed extra buffering. A raised limit can increase latency.
- No new V4L2 buffers, kernel changes or host-side settings are needed.
  Oldest buffers are dropped using the existing QBUF ownership rules.
- Direct-tunnel Lowest Latency is untouched. Fixed Low Latency is still
  one waiting frame, fixed Balanced remains three waiting frames.
- Experimental VFM uses a separate kernel bridge. Selecting Adaptive
  there intentionally uses VFM's original fixed one-pending-frame path
  and logs a warning: dynamic VFM buffer retuning is NOT implemented.

## Evidence and controller policy

At the decoder input callback, compare two independent frame-to-frame
intervals: common-c's assembled-frame enqueue timestamps, and host
presentation timestamps. These are delta comparisons within each clock,
never subtraction of one absolute clock from another. Both must be
monotonic and the frame sequence consecutive.

1. Measure gaps between common-c enqueue timestamps. That timestamp is
   collected **before** native decoder submission, so a slow codec_write
   cannot masquerade as late network assembly.
2. Compare with source PTS spacing, tolerating at least 4 ms or a
   quarter of the source interval (bounded at 8 ms).
3. Record a late observation only when the adjusted elapsed spacing
   exceeds the source spacing plus tolerance. Source-FPS changes,
   missing numbers and invalid observations are excluded.
4. Record the number of valid observations in lock-free u32 counters.
   No added clock reads, allocations, locks, sysfs reads, logs, or
   network calls occur in the video input callback.

The display pump consumes those counters and its own immediate evidence:
a decoded-frame dequeue burst (2+ available this pass), or an empty
decoded queue despite newly arrived input. Every 2 seconds it evaluates
at least 20 valid input observations. Only **3+ late observations,
at least 10% late, and correlated display-side pressure** may raise the
cap by one, with a 3-second minimum between raises. This is deliberately
more conservative than inferring a network problem from one long frame.

When the source becomes stable again, the cap falls one step only
after ten seconds without qualified pressure and a five-second step
cooldown. If the display loop clock goes backwards or stalls for over
five seconds, the target resets to one. Values never leave 1..3.
The controller is owned by the display thread and is fully disabled
for every other mode. Source callbacks only publish atomic counters.

## Diagnostics

- OSD stream header includes **Adaptive 1/3**, **2/3** or **3/3**.
  This is the cap, not the number of frames currently queued.
- Each target change logs a compact AML_ADAPTIVE_V1 row with its
  current cap, increases and decreases in the session.
- The existing frametime chart, decoder/sink rates, kernel drops
  and queue counters remain useful for A/B testing.
- The algorithm runs even with OSD, frame graph and debug log disabled.

## Test and safety notes

- Unit tests: test_aml_adaptive.c, test_aml_pacing.c.
- Integration checks: test_aml_pacing_modes.py and
  test_aml_display_errors.py.
- AMLVIDEO's existing QBUF failure recovery retains ownership; changing
  the cap does not bypass retry, change playback mode or manipulate
  V4L2 buffer lifetimes.
- Must be rebuilt for CoreELEC ARM32 and tested on the Ugoos AM6B+
  with both 4K60 and 1080p120, especially jitter bursts, a sustained
  30-fps video source, decoder backpressure, reconnects and stall
  recovery. A software unit test cannot establish reduced stutter or
  real end-to-end latency.
- Private repository only. Do not run GitHub workflows or update a
  public snapshot or Luna's pinned native source without a deliberate
  later validation step.
