# Experimental CE21 NG FFmpeg/VFM pipeline

Experimental pipeline, off by default. The native workflow can now build and
package its complete runtime: private ARM32 FFmpeg/plugin, pinned CE21 decoder
modules with the native-frame ownership extension and the ARM64 VFM bridge, inside an installable Luna ZIP. No CoreELEC
kernel/image/device-tree replacement is shipped. Device streaming, teardown,
HDR colour correctness and latency still require device validation.

The first device test reached FFmpeg but could not find a decoder: CoreELEC's
`coreelec_common.dtsi` disables `vcodec_dec`, overriding the enabled G12B base
node. Bridge version 2 registers a runtime `aml-vcodec-dec` platform device when
that known node is disabled and no decoder device already exists. It binds the
already loaded stock `amvdec_ports` driver; it does not edit the device tree.
An existing bound decoder is reused, and an unbound device fails explicitly.
Luna then queries the real device's capabilities and H.264/HEVC/NV12 formats
before starting Moonlight. The subsequent device log confirms decoder activation
and the first HEVC frame, then fails with `failed to map scatterlist` while
importing its DMA-BUF for display.

Bridge version 3 attaches those buffers to the existing `amvideom` platform
device, whose DMA operations and cache-coherency settings are initialized by
CoreELEC's OF platform code. The misc control device used previously had only
DMA masks set; ARM64 4.9 leaves it with dummy DMA operations that reject mapping.
The bridge retains a reference to the display device, requires its bound driver
and DMA support, and keeps the contiguous/identity-mapped/32-bit address checks.
No stock device DMA configuration is changed. Mapping failures now identify the
consumer and error code. Presentation and teardown still need a device test.

Bridge version 4 also marks each submitted frame with CoreELEC's
`VFRAME_FLAG_GAME_MODE`. In the pinned display driver, disabling tsync alone does
not bypass `vpts_expire()` timestamp comparisons. This existing per-frame flag
makes frames eligible at the next display opportunity without inheriting a global
freerun setting from an earlier AML/Kodi session. It does not request TV Game Mode
or change HDMI ALLM. Display cadence and latency still need hardware measurement.

The collector rejects a bridge other than version 6. Luna requires that version
in the bundle manifest and checks both an already-loaded bridge and a newly
loaded bridge before probing the decoder.

After updating from bridge version 1 through 5, reboot CoreELEC once if VFM was used
since boot. Luna detects the older loaded bridge before stopping Kodi and asks
for that reboot. It never forces a decoder or bridge module to unload.

## Configuration

Luna: Advanced settings → Video pipeline → **FFmpeg / VFM (experimental)**.
The default remains **Amlogic (standard)**. Missing prototype files, the wrong
kernel release, or an unpatched FFmpeg fail preflight before Kodi is stopped.
After driver setup starts, the existing launcher/watchdog restores Kodi on exit.

Native: `moonlight stream -platform aml-vfm …`, or set
`MOONLIGHT_VIDEO_PIPELINE=aml-vfm` when using automatic platform selection.
`moonlight check-vfm` only loads the userspace plugin and checks decoder features;
it does not touch the display or prove hardware compatibility. There is no silent
fallback to AML. Use `MOONLIGHT_FRAME_PACING=latency` (one pending frame) or
`balanced` (two); these bound the provider queue, not all decoder/network buffers.

The SDR path supports H.264/HEVC, progressive linear NV12, even
dimensions up to 4096×2160 and requested rates up to 120. These bounds are **not**
claims that the hardware sustains every combination. HEVC Main10 HDR10 uses
the original compressed-frame path described in [HDR10](hdr10.md). AV1,
rotation and dynamic format changes are excluded. The optional OSD supports VFM using shared
network/system/sink counters; AML-only decoder metrics remain n/a. FFmpeg capture
must export contiguous, identity-mapped DMA-BUFs with 32-byte-aligned strides;
unsupported layouts/modifiers are rejected instead of interpreted as linear.

## Pipeline and ownership

- A bounded four-packet input queue feeds a decoder worker. If input overflows,
  pending compressed packets are discarded and an IDR is requested; dependent
  packets are rejected until that IDR arrives.
- Private FFmpeg uses the stateful `h264_v4l2m2m`/`hevc_v4l2m2m` decoders and CE's
  DRM PRIME patch. A separate opt-in `nonblocking_dequeue` patch prevents the
  decoder worker from waiting indefinitely for a capture buffer. The worker polls
  for output at up to 2 ms intervals; that trade-off still needs measurement.
  A 10-second progress watchdog stops the experimental stream if compressed
  packets keep arriving but the VFM sink does not return a consumed frame.
  Video packets every three seconds still count toward the same stall window.
  A gap of five seconds or longer starts a fresh window for an idle/paused host.
  Only non-dropped provider completions count: bridge submissions and
  dropped queued frames cannot hide a frozen display.
  A paused/idle host does not trip this timeout. Luna then performs its normal
  Kodi recovery. This is independent of Moonlight's connection watchdog.
- `/dev/moonlight-vfm` imports the NV12 planes and registers a temporary named VFM
  route to the existing `amvideo` sink. It refuses an already active provider and
  never removes Kodi's existing VFM maps. No KMS/UVM/display-driver replacement.
- The bridge marks exported capture buffers with `VFRAME_FLAG_VIDEO_LINEAR`,
  matching stock `amvdec_ports`. CE21's display interface uses this flag to
  select linear pixel read order; linear canvas mode alone is insufficient.
  The independent `VFRAME_FLAG_GAME_MODE` timing flag remains enabled.
  This correction is bridge version 5. Packaging rejects older binaries, and
  Luna requests a reboot if an older bridge is still loaded after an update.
- Frame references stay alive until the sink calls provider `put` and userspace
  consumes the completion. A frame observed by `peek` cannot be evicted between
  `peek` and `get`. Queue drops only retire frames not acquired by the sink.
- On close, including process death, the bridge stops publishing, requests
  a blackout policy, unregisters synchronously, removes only its own route, and then
  unmaps buffers. Reviewed CE21 source drains its display IRQ and disables the
  layer in this path; **this shutdown behavior must be verified on the actual
  installed kernel before normal use**. START passes the actual sysfs blackout
  policy to the bridge, which restores it after unregistering, even on a crash.
  A persistent policy during unregister avoids a race where the last display IRQ
  clears the transient FORCE_BLACKOUT flag before shutting down. After the IRQ
  drains, forced blackout protects the detached last frame until Kodi supplies
  a new frame, while the configured policy is restored.

`returned` counts buffer releases, not presentation timestamps or vblank events.
Decoder modules stay loaded between sessions; do not unload/reload them per game.
When a module was already loaded at boot, native VFM setup enables
`amvdec_ports/parameters/multiplanar` before opening a decoder. It stays enabled
between sessions, matching Luna's `multiplanar=1` option for newly loaded modules.

## Complete build and installable addon

In **this Moonlight repository**, run **CoreELEC 21 NG ARM32 native build** on
`feat/coreelec-ng` with **Build complete experimental VFM runtime and installable
Luna addon** enabled (`build_vfm_runtime=true`). The standard build remains the
default when this input is off. This is separate from the older snapshot
workflow's `build_vfm_plugin` compile-check input.

The workflow:

1. Pins Pannal CoreELEC, its 4.9 kernel and media modules to the reviewed revisions
   in `packaging/coreelec-ng/vfm/sources.json`.
2. Builds private FFmpeg 8.1.2 with the checked CE DRM PRIME patch and our
   nonblocking dequeue and native Main10 patches. Both the plugin and runtime use these libraries.
3. Builds the stock kernel to obtain its exact configuration, exported symbol
   CRCs and V4L2 support modules; applies the decoder ownership patch and builds
   those media modules and our bridge
   against that output. The kernel image is a build dependency only.
4. Collects `amvdec_ports`, `amvdec_mh264`, `amvdec_h265`, their recursive module
   dependencies, and `moonlight_vfm` last. These CE21 codecs support V4L2 without
   Skupi's 5.15 `*_v4l` modules. The bridge activates the stock decoder device at
   runtime when the CoreELEC device tree leaves it disabled. Nothing patches an
   installed kernel or device tree.
5. Checks ARM32 libraries, ARM64 modules, vermagic, library dependencies and
   relocatable paths; records hashes and kernel/source provenance. Runs the
   **actual ARM32 plugin** under QEMU to verify its decoder capabilities.
6. Uses the existing pinned public Luna source export, read-only, to package
   native Moonlight plus the complete VFM runtime and license notices. This
   avoids another private-repository token and does not update the snapshot.

Download the `luna-coreelec21-ng-vfm-addon` artifact. Install its
**`luna-coreelec21-ng-vfm.zip`** using Kodi's *Install from ZIP file*, then select
**Advanced settings → Video pipeline → FFmpeg / VFM (experimental)**.
The artifact also contains the reusable `moonlight-coreelec21-ng-vfm-runtime.tar.gz`
and manifest. The standard native tar alone does not include VFM.

Luna validates the bundle before stopping Kodi and loads the missing modules
when launching Moonlight. Modules already loaded remain in place. The exact
kernel release must match; the kernel also enforces symbol CRC compatibility.
Do not bypass a mismatch with forced module loading. A compatible bundle must
be rebuilt for a different kernel; a successful QEMU probe does not prove
installed-kernel or device compatibility.

## Local build

Use the same pinned checkouts and CoreELEC build prerequisites as the native
workflow. Keep the kernel at `linux-amlogic-local` beside `CoreELEC`, symlinked
from `$HOME/linux-amlogic-local`, and media modules at
`CoreELEC/sources/media_modules-aml/media_modules-aml-local`.
Set `PROJECT=Amlogic-ce DEVICE=Amlogic-ng ARCH=arm MOONLIGHT_BUILD_VFM=yes` in the
build environment. From the Moonlight source root:

```sh
bash packaging/coreelec-ng/prepare-build.sh /path/to/CoreELEC
bash packaging/coreelec-ng/build-stage.sh toolchain /path/to/CoreELEC /path/to/logs
bash packaging/coreelec-ng/build-stage.sh deps-first /path/to/CoreELEC /path/to/logs
bash packaging/coreelec-ng/build-stage.sh deps-final /path/to/CoreELEC /path/to/logs
bash packaging/coreelec-ng/build-stage.sh vfm /path/to/CoreELEC /path/to/logs
(cd /path/to/CoreELEC && ./scripts/clean moonlight-embedded)
bash packaging/coreelec-ng/build-stage.sh moonlight /path/to/CoreELEC /path/to/logs
bash packaging/coreelec-ng/collect-native.sh /path/to/CoreELEC /path/to/native
python3 packaging/coreelec-ng/vfm/collect-runtime.py /path/to/CoreELEC /path/to/new-vfm
bash packaging/coreelec-ng/vfm/smoke-runtime.sh /path/to/CoreELEC /path/to/new-vfm
python3 packaging/coreelec-ng/vfm/package-addon.py /path/to/pinned-export/moonlight-build \
  /path/to/native/moonlight-coreelec21-ng-arm32.tar.gz /path/to/new-vfm /path/to/luna-vfm.zip
```

Use new collector output directories. `modinfo`, `readelf`, and `qemu-arm` are
required. Cleaning Moonlight before rebuilding prevents cached AML-only output
from surviving a change to the VFM build flag. The lower-level `build-ffmpeg.sh`,
`build-module.sh` and `collect.py` remain available for manual debugging.
`modules_prepare` alone cannot supply the symbol CRCs needed for shippable modules.

## Validation status

The public workflow has compiled ARM32 Moonlight and all VFM dependencies and
collected 17 kernel modules and four private libraries. A separate local ARM32
build of patched FFmpeg, libdrm and the plugin passes both decoder feature checks
under QEMU using CoreELEC's `/usr/lib` loader layout. The smoke script invokes
that loader explicitly because the compiler sysroot lacks the OS image's
`/lib` symlink. Missing loaders or bundled FFmpeg libraries still fail the test.
Packaging tests
exercise dependency ordering and reject missing libraries/modules, mixed
architectures, mismatched kernel releases and missing symbol-version metadata.
The previous version 2 bundle passed the complete public workflow, including
QEMU against its exact binaries. Its device test decoded a first HEVC frame but
failed DMA-BUF import; it did not establish successful VFM presentation. Version
4 includes the version 3 DMA correction and the per-frame timing correction.
It is source-stage work with a local ARM64 kernel-object compile check, not a new
runtime release or a hardware-validated fix. See
[the branch audit](coreelec-ng-audit-2026-10-28.md) for offline coverage and limits.

## Required device gates

First verify decoder node discovery and its NV12 export capability. Then test a
short SDR stream, queued drops, decoder starvation, normal exit, forced process
death, repeated launch and Kodi playback afterward. Check for invalid DMA access,
provider leaks, stale display buffers and driver stalls. Stop this approach if
required functionality cannot be provided through the installed kernel's exports;
do not turn it into a maintained CoreELEC fork.

## Experimental HDR10

HEVC Main10 now has a separate original-frame import path. See [HDR10](hdr10.md)
for its complete bundle requirements, buffer ownership and device validation
limits. The NV12 DMA-BUF path remains the SDR implementation.

## Native display readiness and blocked writes

The transport connection and first native video progress have separate Luna
receipts. AML confirms the first compressed unit fully accepted by the codec;
VFM confirms the first decoder-produced frame accepted by its kernel bridge.
These events prove video progressed further than a successful network
handshake, but neither guarantees a scanout or HDMI signal. Luna times out a
connected session that never reaches that first video unit (12s default).

On AML, a separate lightweight monitor checks only `codec_write()` calls
currently inside the vendor driver. If a single call blocks for 12 seconds,
the monitor requests normal connection shutdown. If that same call is still
blocked after 18 seconds, it exits the process so Luna's independent watchdog
can recover Kodi and display controls. It does not change libamcodec's
blocking/nonblocking mode.

Native framebuffer/video-control changes now report write and close failures.
The first-video receipt must be created by Luna before Moonlight starts; its
writer refuses symlinks, hardlinks, non-regular files and ownership mismatches.
This path needs a freshly built native executable and a matching Luna source
bundle. It has not been validated on an installed CoreELEC AM6B+ device.

The native ARM32 collector refuses binaries that do not embed the
`LUNA_NATIVE_FIRST_VIDEO_READY_V1` executable help marker and
`MOONLIGHT_VIDEO_READY_FILE` AML video receipt implementation; the generated
runtime manifest declares `first-video-ready-v1` explicitly. Luna verifies
the same markers, the file digests, and executable help output before
stopping Kodi. Older packages must be rebuilt, not relabeled.

For VFM, a separate ioctl-inflight guard watches bridge frame submission and
completion polling. After a bridge call has been blocked for 12 seconds it
requests normal stream shutdown without waiting on the video mutex (the
submitter may hold that mutex). At 18 seconds it exits the process if the
same ioctl remains in-flight. Luna must still independently verify native
termination before changing any shared decoder or display state. This is an
experimental recovery mechanism that needs ARM32 and AM6B+ device validation.

The independent VFM operation guard additionally covers
`avcodec_send_packet()` and `avcodec_receive_frame()`, not merely
`MLVFM_SUBMIT`/`MLVFM_REAP` bridge ioctls. Every instrumented operation
has a fresh generation and monotonic timestamp; shutdown is requested only
while the same operation is still active, avoiding stale timeouts when
operations complete rapidly. A simulated blocked FFmpeg-send test exercises
the stop request without needing 12 real seconds. Decoder and bridge
resources remain owned until native process exit is independently verified.
This is not proof that the vendor V4L2 driver cannot hang in other paths.

The normal private source-check workflow also runs the extracted AML setup
test using strict compiler warnings, so future changes to the native
write-monitor lifecycle must be reflected in its C harness.


Moonlight's newly generated `uniqueid.dat` is now a cryptographically
random, persistent 16-character hexadecimal device ID. Existing IDs,
including those generated by earlier fixed-ID releases, remain untouched to
preserve current pairings. Copying an existing credential directory still
copies its device identity; use a fresh credential directory for an
independent client.

For older GameStream v3–v6 hosts, SHA-1 pairing responses now transmit
20 initialized digest bytes followed by an explicit 12-byte zero tail in
the 32-byte AES-ECB response. Current v7 SHA-256 pairing stays unchanged.
The strict native host-test path includes a successful AML shutdown test
using real pthread joins and a live guard worker.
