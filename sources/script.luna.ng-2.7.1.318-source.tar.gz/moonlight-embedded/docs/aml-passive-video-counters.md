# Passive CoreELEC NG AML video-sink metrics

These measurements are **opt-in** with the existing native OSD or
`MOONLIGHT_STREAM_DIAGNOSTICS=1`. They are sampled off the decoder and
input threads, at the ordinary OSD/diagnostics interval. No pacing, decoder,
kernel setting or display configuration is changed.

- **Sink** (existing): interval estimate from
  `/sys/module/amvideo/parameters/display_frame_count`: selected-frame
  changes at the kernel sink; **not TV scanout**.
- **Dec / DecDrop** (existing): matched decoder channel count/rate/drops
  from `/sys/class/vdec/vdec_status`, when a unique channel matches.
- **KDrop** (new): interval increment of the system-wide
  `/sys/module/amvideo/parameters/video_drop_vf_cnt`, a kernel vframe
  discard count. May reset when video providers change; not packet loss.
- **NoNext** (new): interval increment of the system-wide
  `/sys/module/amvideo/parameters/underflow`, which increases when the
  kernel sink's next-vframe peek is empty. This is **not a count of visible
  stutters**: repeating the already-displayed frame can be normal.

Both new metrics show `n/a` for their first reading, absent or malformed
data, counter reset, or after a long sampling gap. `+N` means events in
the most recent sample **interval**, not an FPS rate. Other video consumers
may affect these global kernel counters.

## Why `fps_info` is deliberately excluded

Pannal's CoreELEC 21 NG kernel implements `/sys/class/video/fps_info`
using a show function that *updates* `last_frame_count` and
`last_frame_time`. Reading it can disturb another FPS diagnostic reader.
The existing sink and decoder rates avoid this side effect.

Compare `Sink`, `Dec`, `KDrop`, and `NoNext` on a steady 60 FPS
scene and during controlled interruptions. These are troubleshooting
clues, not direct end-to-end/input-to-photon latency measurements.
