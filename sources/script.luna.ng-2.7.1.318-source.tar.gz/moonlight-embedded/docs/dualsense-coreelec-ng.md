# Automatic DualSense / DualSense Edge HID support (CoreELEC NG)

Enhanced DualSense features are detected **automatically**, with no Kodi
setting. Standard evdev gamepad input remains the primary controller path.

## Detection and fallback

When an input node is successfully mapped as a gamepad, Moonlight checks
for Sony 054c:0ce6 (DualSense) and 054c:0df2 (DualSense Edge). For those
devices only, it looks for a writable hidraw device under the **same HID
sysfs parent** as the evdev input node. It checks the matched vendor/product
and USB/Bluetooth transport before attaching the optional bridge.

Missing permissions, unsupported HID transports, inaccessible device
nodes or failed enumeration leave the **ordinary evdev controller
functional**. Xbox, Nintendo, nonmatching Sony and generic controllers
do not use this raw HID bridge. No HID/xpad unbinds or rebinds occur.
The default input/event handling and rumble are unchanged.

## Features implemented in source

- Host-requested gyroscope and accelerometer reports, up to 250 Hz.
- Two-finger touchpad contacts and host-compatible battery reporting.
- RGB lightbar control and 10-byte adaptive-trigger effects from the host.
- USB HID report framing and Bluetooth report CRC checking/generation.
- Lifecycle-owned HID descriptors and trigger-effect cleanup at disconnect.

These features depend on the controller's exposed kernel HID interfaces,
the paired host's supported gamepad features and correct USB/BT reports.

## Emergency diagnostic override

The following **native process environment variable** disables only the
enhanced HID bridge for that Moonlight process:

```sh
MOONLIGHT_DUALSENSE_HID=0 moonlight stream ...
```

Unset the variable to return to automatic detection. The Luna UI
does **not** expose a corresponding toggle or write this variable.
Any older `dualsensehid` entry in Luna's saved `moonlight.conf` is
cleaned up when Luna next regenerates the config. The native parser ignores
unknown old config keys, so older session snapshots cannot disable auto
detection.

## Limits / validation

- Waveform haptics and USB controller-speaker PCM are now implemented
  using Nonary's versioned Moonlight-common-c protocol. See
  [DualSense PCM implementation](dualsense-pcm-coreelec.md) for the Bluetooth
  142-byte haptic report path, USB four-channel ALSA requirements and manual
  testing limitations. It is not yet confirmed on an AM6B+.
- Raw gyro/accel use the generic DualSense hardware scale, not per-device
  calibration. Controller orientation, bias and effects need hardware tests.
- Trigger rumble is distinct from adaptive-trigger resistance and is not
  incorrectly mapped to it.
- CoreELEC 21 may expose Sony devices differently or block independent
  HIDRAW access. Confirm the bridge attaches using the session log; otherwise
  the standard buttons/sticks remain available.
- Controller arrival is still allocated on the first mapped event.

Run the standalone report test on a build host:

```sh
cc -std=c99 -Wall -Wextra -Werror -pedantic tests/test_dualsense_report.c -o /tmp/test_dualsense_report
/tmp/test_dualsense_report
```

On an AM6B+, validate wired USB and Bluetooth with one and two controllers,
motion enable/disable, touch contacts, LED, trigger start/reset, normal rumble,
hotplug/reconnect, controller selection and Kodi recovery. These source
changes alone are not proof of device compatibility or performance.
