# Statistics OSD on CoreELEC 21 NG

The AM6B+ NG image exposes Amlogic `/dev/fb0`–`fb3`, but no `/dev/dri`.
The DRM renderer therefore cannot display the panel on that image. The
optional `ENABLE_FBDEV_OSD` backend uses the installed Mali EGL/GLES2 fbdev
window interface, the same graphics interface Kodi's Amlogic window system
uses. This is a native source change and needs a new Moonlight executable;
it does not change or rebuild the VFM kernel module.

## Ownership and rendering

Luna fully stops Kodi before starting the native stream and sets
`MOONLIGHT_OSD_TAKEOVER=1` only after confirming that handoff. The fbdev
renderer refuses to open without it, with a DRM card present, with an
explicit non-fb0 `FRAMEBUFFER`, or with an unrecognized framebuffer.
Do not set this flag manually while Kodi is running or merely SIGSTOP'd.

The worker uses fb0's existing resolution, an RGBA EGL window and a small
text texture over a transparent full-window background. It does not mmap
pixel storage, select fb1, change the HDMI mode, or write AFBC/scaler
settings. Mali handles allocation and panning, including its buffer layout.
In the pinned driver `osd_afbcd` readback reports hardware type, not the
current enable value; it cannot be used as a symmetric save/restore knob.

The first complete frame is swapped before fb0 is unblanked. Teardown
blanks fb0 before and after destroying the EGL surface and releases the
context, textures and driver handles on the same worker thread. Luna's
existing display recovery restarts Kodi only after the native session has
stopped; Kodi creates its own fresh graphics context. A killed child is
handled by the same watchdog/display recovery used for normal playback.
No new persistent recovery journal is introduced.

An initialization or presentation failure disables the visual overlay and
logs the failed stage. Playback and optional text diagnostics continue.
The DRM backend remains available on systems with a usable DRM overlay.

## AML and VFM

The OSD setting now works with either pipeline. AML provides its existing
native submission/dequeue/timing measurements. The separate FFmpeg/VFM
plugin does not export those counters: these values remain **n/a**, while
RTT, packet totals, CPU/temperature and the kernel sink counter can still
be shown. Do not interpret unavailable counters as zero or confirmed
healthy playback. The sink counter is system-wide, not panel illumination.

## Build and host checks

The CoreELEC NG package enables `ENABLE_FBDEV_OSD` and depends on
`opengl-meson` for its EGL/GLES headers. Driver libraries are loaded from
`/usr/lib/libEGL.so.1` and `/usr/lib/libGLESv2.so.2` only when the visual
backend is requested. Mali binaries are not copied into the add-on; OSD-off
playback and headless diagnostics have no additional ELF load dependency.

For the simulated-driver regression test, provide headers from the target
sysroot, including `EGL/fbdev_window.h` (not GBM's platform headers):

```sh
FBDEV_OSD_INCLUDE_DIR=/path/to/sysroot/usr/include bash tests/test_osd_fbdev.sh
```

The test executes the production renderer with fake device/EGL calls. It
covers refusal without handoff, wrong planes/drivers, all initialization
stages, transparent background/opaque text, bounded layout, failed swaps,
and resource cleanup. Address/undefined sanitizers can be supplied through
`CFLAGS` and `LDFLAGS`. No GPU or display writes occur in the host test.

Reference interfaces:

- CoreELEC `872edca4dd5a7c5d6344e785d7358766834d7119`, NG
  `opengl-meson/package.mk`: fbdev EGL headers and installed Mali symlinks.
- `CoreELEC/opengl-meson` `7bddce621a0c1e0cc12cfc8b707e93eb37fc0f82`:
  target EGL 1.4/GLES2 and fbdev-window declarations.
- `pannal/xbmc` `aml-4.9-21.3`, `xbmc/windowing/amlogic`:
  Kodi's `fbdev_window`, EGL default display and GLES2 context path.
- `pannal/linux-amlogic` `2d0e0cc0db958d8d88f76407ac922f08d9a4004e`,
  `drivers/amlogic/media/osd`: framebuffer identity and blank semantics.

## Required device validation

Host tests do not establish successful Mali rendering or physical recovery.
After an authorized native build, test AML and VFM with the same settings:

1. Enable OSD and confirm `OSD: Mali EGL framebuffer ready on fb0` followed
   by a readable panel with video visible outside it.
2. Check font/position settings, 720p/1080p GUI sizes and HDMI scaling.
3. Quit and relaunch each pipeline repeatedly; confirm Kodi renders normally.
4. Exercise a controlled native termination and watchdog return to Kodi.
5. Compare playback with OSD off/on. Keep OSD off for latency benchmarks.

The read-only `scripts/probe-coreelec-ng-osd.sh` and `tools/probe-ng-fb.c`
remain available for device inventory if initialization fails.
