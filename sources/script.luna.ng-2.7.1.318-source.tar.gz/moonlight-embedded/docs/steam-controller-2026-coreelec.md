# Steam Controller (2026) native CoreELEC NG input

This is the **private** low-level driver for the 2026 Valve Ibex controller
(NOT the 2015 Steam Controller), integrated into Moonlight Embedded's existing
evdev input, video, Kodi lifecycle and Nonary Moonlight-common-c protocol.

## Hardware and fallback

Automatic detection is limited to Valve VID 28de and:

| Device | PID | Native handling |
|---|---|---|
| USB cable, vendor HID interface 0 | 1302 | Yes, when feature report 1 works |
| Wireless Puck, vendor interfaces 2–5 | 1304 | Up to four slots on one receiver |
| Bluetooth LE via Linux uhid | 1303 | When HID feature writes are supported |
| 2015 Steam Controller / dongle | 1102 / 1142 | Unchanged generic evdev |

The manager opens only the exact HIDRAW vendor device and checks its product,
bus and interface. It must successfully set firmware configuration before
taking ownership. A selected-only controller allowlist is authoritative:
when Luna specifies `MOONLIGHT_INPUT_SELECTORS_V2` or
`MOONLIGHT_INPUT_NAMES_HEX`, the driver requires an event node under the
same HID parent to satisfy the existing identity selector.

The controller is placed in native mode while streaming using feature
report `01 87 09`: lizard mode (setting 9) OFF, RAW gyro/accelerometer
(setting 48) ON, firmware Steam watchdog (setting 71) OFF. Settings are
refreshed once per second for compatibility with Nonary's driver.
A normal exit sends explicit stops for rumble and both trackpad motors,
restores lizard mode, disables IMU, and closes HID handles.

**Caution:** Steam watchdog is deliberately disabled to prevent periodic IMU
loss. An uncatchable SIGKILL, crash or power loss cannot guarantee lizard-mode
restoration; disconnect/reconnect the controller if necessary. This is not a
replacement for testing Kodi's session watchdog.

An exact claimed HID parent shadows duplicate evdev input from that device.
If HID authorization/configuration fails, ordinary evdev remains. If native
output fails or the raw device disappears during a session, the manager
releases the Steam player slot, retires its HID node and requests a filtered
evdev rescan—without touching unrelated controllers or globally unbinding
USB drivers.

## Input and host features

The native driver handles 0x42 (wired), 0x45 (Puck/BLE) and 0x47
(timestamped pad) reports. It forwards:

- All ordinary controls, analog triggers/sticks, four rear grips, independent
  left/right pad and trigger clicks, Steam and Quick Access buttons.
- Capacitive left/right grip contact and left/right stick touch state.
- Both trackpads as two fingers on one controller touchpad (left/right
  halves), matching Nonary's compatible default. Pressure is normalized.
- Gyro/accelerometer axes in Moonlight's deg/s and m/s^2 convention, at the
  host-requested rate; 0 disables motion packets.
- Firmware battery state/percent and, when successfully retrieved, real
  firmware build attributes.
- Vibepollo Steam Controller haptics 0x80–0x85 and BLE host settings 0x87/0x8e
  with reserved link-control IDs removed. Default BLE haptic gain remains
  unchanged, as in Nonary's default.

Steam-native host capabilities use `LI_CTYPE_STEAM`,
`LI_CCAP_STEAM_HAPTIC`, `LI_CCAP_GRIP_SENSE`,
`LI_CCAP_STICK_TOUCH` and `LI_CCAP_SC26_BUTTONS`. Attributes are
advertised only if an actual attribute query succeeds; BLE settings only
on BLE links. Older Sunshine/Apollo hosts may ignore Steam-specific
capabilities and emulate a more generic controller.

The manager owns at most 16 links and shares the original evdev 16-player
bitmap. Puck links do not announce inactive empty wireless slots. A new
state report announces the player dynamically; after 3 seconds without a
state report the slot is retired, including touch-up and neutral input.

## Vibration capability and queue saturation

Generic evdev gamepads advertise conventional rumble only if the kernel
reports EV_FF with the FF_RUMBLE effect used by EVIOCSFF. A DualSense that
supports native PCM haptics retains those independent capabilities even if
the evdev node does not advertise conventional rumble.

The native Steam Controller rumble callback returns whether it owns the
Sunshine player, NOT whether an individual output packet entered the queue.
Otherwise a saturated native queue could incorrectly send Steam rumble to
the generic evdev backend.

The 32-entry HID queue protects feature commands and stop commands. An
ordinary effect can be evicted to admit a stop. Redundant older stops for
the same pulse/command actuator are retired; the new stop is appended last
so an intervening play effect cannot restart a motor. If all entries are
protected and a critical stop still cannot be queued, the service loop
sends direct stops, restores firmware settings and returns control to
generic evdev. Rejected ordinary commands do not change remembered rumble.

Ibex pulse report 0x81: byte 1 selects left/right/both, bytes 2–3 encode
ON duration, bytes 4–5 OFF interval, and bytes 6–7 repeat count, all
little-endian. Zero ON duration **or** zero repeat count means stop. They
are not independent left/right motor amplitudes, so the OR condition is
intentional. The kernel's reference driver swaps left/right pad identifiers
for this report before transmission; verify the physical L/R mapping on
actual hardware rather than inferring it from the raw selector value.
Source: Linux HID Ibex support patch v4 (August 7, 2026):
https://lore-kernel.gnuweeb.org/linux-input/20260807234816.47EC31F000E9%40smtp.kernel.org/T/

Host-only tests cover saturation, protected stops, left/right/both pulse
fields and source wiring. Real hardware validation on USB, Puck and BLE
is still required before claiming successful stop delivery on device.

## Performance and safety

- Entirely independent of AML/VFM video decode, frame pacing and ALSA.
- HID input is read on the existing event loop, bounded at 32 reports per
  poll callback. A 40ms service tick runs only while a native link is open;
  otherwise re-enumeration is scheduled at 2-second intervals.
- Host callbacks only enqueue bounded output reports (32 entries per link)
  and wake the event loop via a nonblocking eventfd.
- Stop reports and BLE feature-setting packets are protected from eviction
  by ordinary haptic effects. Invalid report IDs/lengths/sides are rejected.
- 500ms host rumble hold, 40ms refresh, a neutral release on disconnect,
  and explicit pad-finger UP events prevent stuck gameplay inputs.
- Input-selector matching and exact HID-parent de-duplication prevent
  generic keyboards, Xbox pads and DualSense devices being claimed.
- `MOONLIGHT_STEAM_CONTROLLER=0` disables the native Steam Controller
  driver for a process; no permanent Luna settings toggle is added.

**Do not update controller firmware from a remote host**: Steam could target
the host's virtual controller. Firmware must be updated while connected
directly to a computer running Steam.

## Testing

The source is committed without triggering GitHub Actions, generating a ZIP
or claiming physical CoreELEC compatibility. Rebuild an ARM32 CoreELEC21
native binary and test a spare AM6B+:

1. Control test: stream with an Xbox controller, DualSense and a 2015 Steam
   Controller; verify no regressions.
2. Connect the 2026 controller by USB then via the wireless Puck (multiple
   slots) and finally BLE; check the native-claim log and Windows arrival.
3. Verify independent trackpads, grips, sticks, triggers, pad/trigger clicks,
   gyro, battery, firmware and Steam-host haptic effects.
4. Disconnect/reconnect while haptics play; check the output queue,
   controller slot releases and generic evdev fallback.
5. Clean exit and crash recovery: confirm controller mode restoration and
   Kodi return, and observe whether the controller needs manual replugging
   after SIGKILL on the old CoreELEC 4.9 kernel.

Standalone decoder tests:

```sh
cc -std=c99 -Wall -Wextra -Werror -pedantic \
  -Ithird_party/moonlight-common-c/src \
  tests/test_steam_controller_2026_codec.c -o /tmp/test_sc26
/tmp/test_sc26
cc -std=c99 -Wall -Wextra -Werror -pedantic \
  -Ithird_party/moonlight-common-c/src \
  tests/test_steam_controller_2026_fallback.c -o /tmp/test_sc26_fallback
/tmp/test_sc26_fallback
python3 tests/test_steam_controller_2026_integration.py
```

There is no proven full feature parity or latency result until real-hardware
testing, especially on the CoreELEC kernel's uhid/hidraw implementation.
