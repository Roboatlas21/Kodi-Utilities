# Frame-arrival and decoder-submission timing graph (CoreELEC NG)

The existing Luna Statistics overlay -> Show frametime graph setting now
shows two separate lanes over the latest 240 decoder-callback samples:

- GREEN IN: spacing between frame/decode-unit arrivals at Moonlight's
  decoder callback, after network reassembly.
- MAGENTA SUB: wall time spent inside the decoder submit callback,
  including possible codec-write backpressure. This is NOT the video
  hardware's real decode-execution time.
- GRAY dashed reference: 1000 / requested FPS in milliseconds.
  The upper lane zooms around the requested interval. The lower lane
  scales dynamically from zero to at least 4ms or half a frame budget,
  at most two frame budgets.
- High-contrast edge markers flag outliers clipped by either axis.
- Cyan/yellow gap markers highlight missing frame numbers between
  decoder callbacks. This does NOT establish actual packet loss,
  lost network data or physical display drops.

Each caption shows A=average, 95=P95, 99=P99 and W=worst in milliseconds.
IN also shows GAP events and LOST frame numbers in the 240-sample window.
SUB shows H1 (>one frame budget plus 1ms) and H2 (>two frame budgets
plus 1ms). These are callback-duration hitches, not presentation hitches.
The initial arrival interval has no predecessor and is excluded from
arrival percentiles. Valid zero-duration submissions are retained.

Existing OSD diagnostics separately report decoder FPS, sink selected-frame
rate, codec/decode errors, queue depth and kernel drop counters. Compare
those indicators with the graph; a long callback does not prove decoder
execution time, and a missing frame number does not prove packet loss.

The pinned AM6B+ CoreELEC 4.9 driver provides NO reliable per-frame
physical HDMI presentation timestamp. This implementation does not
substitute callback returns, DRM overlay commits, or sink selected-frame
rates for actual presentation feedback.

## Performance and compatibility

- Existing Luna setting only; no new menus or host-side modifications.
- The callback reads CLOCK_MONOTONIC twice and publishes bounded 32-bit
  counters in the same lock-free ring. No sort, allocation, logging, sysfs
  or network operations occur in the video callback.
- Percentiles are calculated on the independent OSD worker at most 4Hz.
- Tickets prevent reading torn overwritten ring slots; the line plot
  never joins nonadjacent entries across an overwritten snapshot.
- Both DRM and Mali fbdev overlays use the same two-lane plot and a 168px
  graph area. If the panel cannot fit, hide the chart but keep OSD text.
- Direct AML tunnel, low-latency/balanced queues, VFM decoder and
  audio/controller paths are not changed.

## Validation

From the private Moonlight Embedded checkout:

    cc -std=c99 -Wall -Wextra -Werror -pedantic \
      tests/test_frametime.c src/osd/frametime.c -o /tmp/ft && /tmp/ft

    cc -std=c99 -Wall -Wextra -Werror -pedantic -pthread \
      tests/test_frametime_concurrent.c src/osd/frametime.c \
      -o /tmp/ftconcurrent && /tmp/ftconcurrent

    python3 tests/test_frametime_integration.py

Verify on a new ARM32 build using an AM6B+ at 4K60 and 1080p120:
visible paired lanes, labelled millisecond axes, long-spike markers,
frame-gap counters, render bounds and no added stutter. Compare OSD
OFF/ON and graph OFF/ON. The feature improves diagnosis, not the stream's
underlying latency or physical display frame delivery.
