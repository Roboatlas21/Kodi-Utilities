# DualSense waveform haptics and controller-speaker PCM — CoreELEC 21

This is an experimental private client implementation, not a claim that
haptics or controller-speaker output has been tested on an AM6B+.

## Protocol

Moonlight Embedded pins the `Nonary/moonlight-common-c` fork at commit
`3f9c009fe01db573cd29c1f286db5b7fa8a922fc` rather than upstream
`moonlight-stream/moonlight-common-c`, so the host can negotiate the two
versioned extensions used by Vibepollo:

* `0x5601`: 48 kHz stereo S16LE actuator samples; 12-byte payload header,
  maximum 240 stereo frames. The client advertises `ML_FF_HAPTICS_PCM`
  through a nonblocking controller-haptics callback and per-controller
  `LI_CCAP_HAPTICS_PCM` only when an output renderer is ready.
* `0x5602`: separate 48 kHz stereo S16LE speaker PCM; 32-byte header,
  generation, sequence, sample-position, and an owner token. The
  `LiStartConnectionWithSpeakerPcm` callback and
  `LiSendControllerSpeakerArrivalEvent` bind each eligible **PlayStation**
  controller to its own owner token before arrival. The client advertises
  `LI_CCAP_PS_SPEAKER_PCM` only with a working USB speaker renderer.

Ordinary video, audio, controller, and HDR streams are otherwise unaffected.
Update existing checkouts with `git submodule sync --recursive` followed by
`git submodule update --init --recursive`; a stale upstream submodule pointer
would not contain the new callback or protocol headers.

## Controller playback

* **DualSense Bluetooth**: After verifying the matched Sony HIDRAW device
  accepts the 142-byte silent SAxense `0x32` output packet, the client
  starts a bounded worker. It low-pass downsamples each 512 stereo frames
  of 48 kHz PCM to 32 stereo 8-bit frames at 3 kHz, packs the report with
  the Sony CRC, and sends it at the output cadence. Audio queues are bounded,
  sequence gaps reset stale samples, and inactivity sends a silence packet.
  A blocked/unsupported HID output disables the enhancement while ordinary
  evdev controls remain usable.
* **DualSense USB**: Only when Linux's ALSA `sound` device belongs to the
  **same physical USB device** and accepts an exact 48 kHz / S16LE /
  four-channel playback configuration, a separate nonblocking PCM worker
  renders speaker PCM to channels 1/2 and actuator PCM to channels 3/4.
  There is no fallback to default/HDMI audio or another USB sound card.
  Unsupported ALSA channels, devices, permissions or sample formats
  **disable both new USB PCM features**; ordinary rumble remains.
* **Other controllers**: No new raw-audio capabilities advertised.

Each callback copies up to 240 stereo frames and returns promptly. Device
cleanup stops and joins each worker before closing its playback devices.
A PCM waveform takes priority over basic FF_RUMBLE while active.
There is no user-facing toggle. The prior diagnostic environment override
`MOONLIGHT_DUALSENSE_HID=0` also prevents the optional audio backend from
starting on that process.

## What is not established

CoreELEC 21's Amlogic NG kernel is old and may not expose the DualSense
four-channel USB PCM endpoint or support Bluetooth SAxense HID writes.
Actual controller-speaker output may therefore be unavailable on the box
until tested with a real device. The Linux renderer is an independent
implementation; it is **not** the desktop Windows/WASAPI code.
Bluetooth controller-speaker PCM is not implemented; the BT path is
**actuator waveforms only**.

The 48 kHz to 3 kHz downsampler is a simple averaging decimator, which may
sound different from Nonary's SDL conversion. Before performance claims,
test waveform quality, channel orientation and packet pacing on hardware.

## Local tests (do not start CI workflows)

```sh
cc -std=c99 -Wall -Wextra -Werror -pedantic tests/test_dualsense_pcm_packets.c -o /tmp/test_dualsense_pcm_packets
/tmp/test_dualsense_pcm_packets
cc -std=c99 -Wall -Wextra -Werror -pedantic -Ithird_party/moonlight-common-c/src tests/test_dualsense_pcm_protocol.c -o /tmp/test_dualsense_pcm_protocol
/tmp/test_dualsense_pcm_protocol
python3 tests/test_dualsense_pcm_source.py
```

On a spare CoreELEC box, test regular input/rumble first, BT actuator reports
then USB four-channel speaker and actuator output, with two pads, unplug and
reconnect during active effects, plain Apollo/Sunshine fallback, and Kodi
suspend/resume. Inspect Moonlight logs for the bridge and USB PCM status.
No workflows or installable builds have been triggered by these source changes.
