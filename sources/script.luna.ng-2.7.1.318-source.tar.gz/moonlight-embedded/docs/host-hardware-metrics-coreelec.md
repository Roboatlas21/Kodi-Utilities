# Host hardware statistics in the CoreELEC Moonlight OSD

This is a **client-only** read-only extension. When Luna's existing
Statistics overlay is on, Moonlight shows a separate Host row below
its existing Client CPU/GPU/Temp row.

## Compatibility

- Vibeshine/Vibepollo with hardware_metrics enabled: reports the
  host CPU usage, GPU utilization, encoder utilization, GPU temperature,
  GPU VRAM used (MiB), and GPU VRAM usage percentage where available.
- Regular Sunshine and Apollo: streaming, audio, controllers, HDR, and
  existing OSD diagnostics behave as before. These hosts do **not**
  currently expose that API, so the Host row says
  "Host CPU/GPU n/a (not exposed by host)" after one optional probe.
- If metrics are missing or stale, each unavailable field is n/a.
  No host resource usage is estimated from video bitrate or frame times.

Uses HTTPS GET /api/hardware-metrics on the already negotiated streaming
HTTPS port, authenticated by the existing paired client certificate and
pinned host public key. There is no HTTP fallback or new host access key.
Vibeshine's hardware_metrics setting is currently disabled by default.

## Performance and lifecycle

- The OSD owns one dedicated background metrics worker. It is isolated
  from decoder, transport, audio and input callbacks.
- TLS request timeout is 750 ms, connect timeout 400 ms, response limited
  to 8192 bytes and JSON schema version must be 1.
- Successful polls occur at most once per 2 seconds, and respect any
  larger interval_ms provided by the host. Failed transient requests back
  off 5 seconds. An absent/disabled endpoint is probed at most once per
  Moonlight session.
- The reader holds a mutex only while copying a small snapshot. Stale
  values are suppressed; zero usage is distinguished from unavailable.
- When OSD is disabled, no hardware API requests are made. Debug-only
  stream diagnostics do not activate polling.
- Set MOONLIGHT_HOST_METRICS=0 to disable the feature for an OSD session.
- The worker stops before the stream's GameStream TLS state is torn down.
- Only the first GPU with valid metrics is shown; this may not be the
  hardware encoder GPU if the host has multiple GPUs.

## Tests

Run from the Moonlight Embedded repository root:

    cc -std=c99 -Wall -Wextra -Werror -pedantic \
      src/osd/host_metrics_json.c tests/test_host_metrics_json.c \
      -lm -o /tmp/test_host_json && /tmp/test_host_json

    cc -std=c99 -Wall -Wextra -Werror -pedantic -pthread \
      -Ilibgamestream src/osd/host_metrics_json.c src/osd/host_metrics.c \
      tests/test_host_metrics_reader.c -lm -o /tmp/test_host_reader && \
      /tmp/test_host_reader

Build an actual CoreELEC ARM32 binary, then check with a pinned
Vibeshine/Vibepollo host with metrics enabled, a host with metrics
disabled, and regular Sunshine and Apollo. This has not yet been
end-to-end validated on an AM6B+.

**Important:** No Moonlight-only implementation can obtain real Windows
CPU/GPU utilization from an unmodified host that has no telemetry API.
The correct result is n/a, not an invented host percentage.
