# Statistics panel additions

Enable Luna's existing On-Screen Display statistics setting. The panel puts
stream details and CPU/GPU usage first, followed by bitrate, network health,
frame gaps, queue/pool and latency. Detailed existing counters remain below.
Both DRM and Mali fbdev renderers preserve explicit lines, wrap words and fit
up to 12 rows within half the display height. Large fonts or small displays
can still truncate the last rows with `...`.

| Measurement | Source and meaning |
| --- | --- |
| Stream header | Negotiated video setup callback: codec, resolution and stream FPS; `/sys/class/display/mode` for HDMI mode. The audio init callback supplies channels and sample rate; compressed audio bytes give measured kbps. |
| CPU | Aggregate `/proc/stat` busy time across all cores, normalized to 0–100%. This is device usage, not Moonlight process usage. First sample needs a baseline. |
| GPU | `/sys/class/mpgpu/utilization`, a 0–100 percentage published by NG's Amlogic r12p0 Mali DVFS driver. It measures Mali activity, not the separate video decoder. Missing, unreadable or out-of-range values are `n/a`; zero is valid. |
| Temp | First valid millidegree reading from thermal zones 0–4, with the zone number shown. |
| Video | Decode-unit payload bytes arriving at the renderer per interval, in decimal Mbps. Excludes packet headers, FEC and lost data. This is measured, not the requested bitrate. |
| NIC RX / NetErr | Receive bytes, errors and drops on the interface selected by the route to the host. Includes other traffic using that interface. Error/drop values are interval deltas. Interface changes, counter resets and read failures invalidate the baseline. No sum across unrelated adapters. |
| Lost | Missing frame numbers at the renderer, cumulative for this connection, with gap-event count and missing frames / configured FPS as an approximate duration. Not packet loss, confirmed display drops, or measured freeze time. Duplicates, older frames and u32 rollover are handled. |
| Queue | Kernel available-frame count and count / stream FPS, an estimated duration, not measured queue latency. |
| Pool | Kernel pool minus free frames, total capacity and peak observed occupancy. Peak resets when capacity changes or the connection restarts; it may miss activity between samples. |
| Ping | Separate ICMP echo RTT and smoothed absolute-deviation jitter; independent of common-c's stream RTT. One small request per two seconds, one-second timeout. |
| Decode | Mean recent H.264/HEVC hardware decode cost and percent of one stream-frame budget on the pinned standard AML NG decoder. Separate from the existing application-side `Submit` time. |
| Note | Optional first line of `/tmp/moonlight-osd-note`. Bounded text only; control bytes are sanitized, symlinks and nonregular files are rejected. |

Unavailable measurements remain `n/a`. All sampling and file/socket I/O run
on the OSD monitor, not the video/audio callbacks. Callbacks only count bytes
and frame gaps and preserve original callbacks, capabilities, contexts and
return values. They are installed only for a requested AML/VFM overlay.
Counters and baselines reset per connection. The existing diagnostic heartbeat
has its own tracker and format and remains independent of overlay cadence.
Byte counters use lock-free u32 operations; modulo differences cover the
supported maximum 500 Mbps and 60-second sampling window.

Ping uses datagram ICMP sockets and kernel receive timestamps, so the monitor's
100ms polling cadence is not added to RTT. Unsupported socket permissions,
blocked replies, timeouts, or unavailable timestamp support yield `n/a` and do
not delay stream shutdown. No raw-socket escalation or external speed test is
used. NIC/ping support IPv4 and IPv6; a hostname resolving to multiple distinct
addresses is deliberately unavailable because common-c does not expose its
chosen address. Numeric host addresses avoid that ambiguity.

## Native decoder timing ABI

The standard AML backend exports a duplicate of its own initialized decoder
descriptor only on Linux 4.9.269. The monitor owns and closes that descriptor
before stream teardown. It never opens a new decoder device or scans other
processes' descriptors. `AMSTREAM_IOC_GET_MVDECINFO` is a consuming read of the
decoder's diagnostic ring; it does not consume video frames. Each refresh
drains at most one 128-entry ring, averaging valid matching-resolution samples.
This cannot be shared reliably with another consumer of the same QoS ring.

The pinned NG kernel accepts its legacy 1192-byte structure: 40-byte prefix,
eight 144-byte records, decode-cost offset 56. Compile-time checks enforce
these sizes and offsets, including 8-byte alignment on ARM32. Wrong sizes,
slot counts, dimensions, absent samples and failed ioctls stay unavailable.

Although the header comments say `us`, the pinned H.264/HEVC producers use
`local_clock()` deltas, in **nanoseconds**. We divide by 1,000,000 for ms and
use `ms * FPS / 10` for frame-budget percent, without Vortex's unit heuristic.
Other kernels and VFM's separate decoder runtime currently report `Decode n/a`.
The pinned common-c's unpopulated FEC recovery/OOS/invalid metrics also remain
`n/a`; those fields are not repaired by a panel change.

## Reference sources

- Vortex reference: private Luna `research/vortex-2.7.1.277`, formatter
  `0x40c660`, sampler `0x4103b0`, submit wrapper `0x40f380`. Native artifacts
  and pseudocode are reference material; no Vortex executable code was copied.
- [NG GPU package](https://github.com/pannal/CoreELEC/blob/872edca4dd5a7c5d6344e785d7358766834d7119/projects/Amlogic-ce/packages/linux-drivers/gpu-aml/package.mk)
  selects `khadas/android_hardware_arm_gpu` at
  `be29f1f274e3798d3ab2d7c489e47f8de20e8cf3`, bifrost r12p0.
  In that tree, `platform/devicetree/mpgpu.c` exports `mpgpu/utilization`,
  `meson_main2.c` returns the last percentage, and
  `backend/gpu/mali_kbase_pm_metrics.c` computes `100 * busy / total`.
  The separate governor's 255/256 scaling must not be applied to this node.
- [Pinned kernel ABI](https://github.com/pannal/linux-amlogic/blob/2d0e0cc0db958d8d88f76407ac922f08d9a4004e/include/linux/amlogic/media/utils/amstream.h).
- [Pinned media modules](https://github.com/pannal/media_modules-aml/tree/47d0ec45bbc2d659d675e3a0269788be1470e1f7):
  `drivers/stream_input/amports/amstream.c` checks the legacy structure size;
  `drivers/frame_provider/decoder/utils/vdec.c` consumes the diagnostic ring;
  `h264_multi/vmh264.c` and `h265/vh265.c` supply nanosecond timing.

## Validation

`bash tests/test_osd_telemetry.sh` exercises callback forwarding, negotiated
metadata, bitrate, reset/wrap handling, unavailable GPU values, thermal fallback,
queue/pool, NIC counters, decoder ABI/units and complete default-width layout.
It also tests mocked IPv4/IPv6 ICMP checksum, timestamps, cadence, jitter,
invalid replies, timeouts and permission/send failures. Existing statistics,
layout, monitor/diagnostics, framebuffer and probe tests cover integration.

Hardware acceptance still requires a native build on AM6B+: compare OSD off/on,
check CPU/GPU against the exposed counters, verify decoder timing and ping,
exercise stereo/surround and AML/VFM, check 720p/1080p layout/font settings, and
quit/relaunch repeatedly. Host tests do not establish hardware operation or
performance. No GitHub workflows were started for this source update.
