/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once

#include <limits.h>
#include <stdbool.h>

/* Sunshine XML values are unsigned decimal, not atoi()-style prefixes.
 * Never accept signs, whitespace, trailing junk, or integer overflow. */
static inline bool moonlight_server_uint(const char *text, int *out) {
  if (!text || !*text || !out) return false;
  unsigned int value = 0;
  for (const unsigned char *p = (const unsigned char *)text; *p; ++p) {
    if (*p < '0' || *p > '9') return false;
    const unsigned int digit = *p - '0';
    if (value > ((unsigned int)INT_MAX - digit) / 10U) return false;
    value = value * 10U + digit;
  }
  *out = (int)value;
  return true;
}

/* A GameStream appversion contains dot-separated numeric components, e.g.
 * 7.1.0.0. Sunshine-compatible hosts advertise 7.1.431.-1: only the
 * fourth component may use the exact negative marker -1. The first
 * component controls compatibility; validate the entire version. */
static inline bool moonlight_server_version_major(const char *text, int *out) {
  if (!text || !*text || !out) return false;
  const unsigned char *p = (const unsigned char *)text;
  unsigned int major = 0;
  unsigned int component_index = 0;
  while (*p) {
    if (component_index == 3 && p[0] == '-' &&
        p[1] == '1' && p[2] == '\0') {
      if (!major) return false;
      *out = (int)major;
      return true;
    }
    unsigned int segment = 0;
    unsigned int digits = 0;
    while (*p >= '0' && *p <= '9') {
      const unsigned int digit = *p - '0';
      if (segment > ((unsigned int)INT_MAX - digit) / 10U) return false;
      segment = segment * 10U + digit;
      ++digits;
      ++p;
    }
    if (!digits) return false;
    if (component_index == 0) major = segment;
    ++component_index;
    if (!*p) break;
    if (*p++ != '.' || !*p) return false;
  }
  if (!major) return false;
  *out = (int)major;
  return true;
}
