#!/usr/bin/env python3
"""Trusted local verifier for an immutable, pinned Git-less Luna public export.

Never import or execute programs from the export before checking its contents.
The expected SHA-1 *Git blob* of source-lock.json comes from the private
Moonlight source pins, not from any file provided by the export.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat

_SHA = re.compile(r"^[a-f0-9]{40}$")


def git_blob_sha(data):
    return hashlib.sha1(
        b"blob " + str(len(data)).encode("ascii") + b"\x00" + data
    ).hexdigest()


def _ignored(relative):
    parts = relative.parts
    return any(part in (".git", "__pycache__") for part in parts) or (
        len(parts) >= 2 and parts[:2] in (
            ("third_party", "moonlight-common-c"),
            ("third_party", "SDL_GameControllerDB"),
        )
    )


def verify(root, pins, capture=False):
    root = Path(root)
    expected_lock = pins.get("Luna_public_export_lock_blob")
    if not isinstance(expected_lock, str) or not _SHA.fullmatch(expected_lock):
        raise ValueError("Private Luna export manifest digest pin is unavailable")
    path = root / "source-lock.json"
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 256000:
        raise ValueError("Missing or unsafe Luna export manifest")
    data = path.read_bytes()
    if git_blob_sha(data) != expected_lock:
        raise ValueError("Luna public export manifest differs from trusted private pin")
    lock = json.loads(data.decode("utf-8"))
    if not isinstance(lock, dict) or lock.get("schema") != "luna-public-source-snapshot-v1":
        raise ValueError("Unrecognized pinned public Luna snapshot schema")
    sources = lock.get("sources")
    if not isinstance(sources, dict) or set(sources) != {"moonlight", "luna"}:
        raise ValueError("Unexpected pinned public export component list")
    luna = sources["luna"]
    if (not isinstance(luna, dict) or luna.get("repository") != "Roboatlas21/Luna" or
            luna.get("revision") != pins.get("Luna")):
        raise ValueError("Public Luna snapshot differs from its immutable source pin")

    # Capture verified bytes on their first and only read. An export can be
    # modified after validation, so its paths are not usable as executable
    # code or package contents unless copied from this immutable snapshot.
    captured_luna = {} if capture else None
    # Every source file must exactly match the digest list authenticated by
    # the pinned manifest blob. In particular do not trust the export's own
    # 'verify-snapshot.py', 'package_ng.py', or other executable Python code.
    for name, component in sources.items():
        files = component.get("files") if isinstance(component, dict) else None
        if not isinstance(files, dict) or not files:
            raise ValueError("Incomplete authenticated export file list: " + name)
        directory = root / name
        if directory.is_symlink() or not directory.is_dir():
            raise ValueError("Missing or symlinked export root: " + name)
        expected = set()
        for rel, info in files.items():
            if not isinstance(rel, str):
                raise ValueError("Malformed export file entry")
            pure = PurePosixPath(rel)
            if (pure.as_posix() != rel or pure.is_absolute() or
                    not pure.parts or any(p in (".", "..") for p in pure.parts) or
                    _ignored(pure)):
                raise ValueError("Unsafe authenticated export file path")
            if (not isinstance(info, dict) or
                    not isinstance(info.get("blob_sha"), str) or
                    not _SHA.fullmatch(info["blob_sha"]) or
                    info.get("mode") not in ("100644", "100755")):
                raise ValueError("Malformed authenticated export digest/mode")
            expected.add(rel)

        seen = set()
        for node in directory.rglob("*"):
            rel_path = node.relative_to(directory)
            if _ignored(rel_path):
                continue
            if node.is_symlink():
                raise ValueError("Unexpected source symlink: " + str(rel_path))
            if node.is_dir():
                continue
            if not node.is_file():
                raise ValueError("Unexpected non-file export entry: " + str(rel_path))
            rel = rel_path.as_posix()
            if rel not in expected:
                raise ValueError("Unexpected export source file: " + name + "/" + rel)
            seen.add(rel)
            blob = node.read_bytes()
            if git_blob_sha(blob) != files[rel]["blob_sha"]:
                raise ValueError("Modified exported source: " + name + "/" + rel)
            executable = bool(node.stat().st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
            if executable != (files[rel]["mode"] == "100755"):
                raise ValueError("Incorrect executable mode: " + name + "/" + rel)
            if captured_luna is not None and name == "luna":
                captured_luna[rel] = (blob, files[rel]["mode"])
        if seen != expected:
            raise ValueError("Missing export source files: " + name)
    if capture:
        return root / "luna", luna["revision"], {
            "manifest": data, "files": captured_luna,
        }
    return root / "luna", luna["revision"]
