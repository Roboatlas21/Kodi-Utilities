#!/usr/bin/env python3
"""Package one verified Luna source and one exact Moonlight native/VFM build.

Source may be a verified public export or a local private Luna Git checkout.
Neither mode requires cross-repository GitHub Actions credentials.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import types
import zipfile

HERE = Path(__file__).resolve().parent
RELEASE_LOCK_SCHEMA = "luna-ng-release-lock-v1"


def checked_revision(value, name):
    if not isinstance(value, str) or not re.fullmatch(r"[a-f0-9]{40}", value):
        raise ValueError("Invalid %s revision" % name)
    return value


def select_luna_source(location, pins, capture=False):
    """Verify Luna source identity before loading any packaging code from it."""
    location = Path(location).resolve()
    snapshot = location / "source-lock.json"
    authenticated = None
    if snapshot.is_file():
        data = json.loads(snapshot.read_text(encoding="utf-8"))
        if data.get("schema") != "luna-public-source-snapshot-v1":
            raise ValueError("Unrecognized public Luna snapshot schema")
        sources = data.get("sources", {})
        luna = sources.get("luna", {}) if isinstance(sources, dict) else {}
        if luna.get("repository") != "Roboatlas21/Luna":
            raise ValueError("Unrecognized Luna snapshot source")
        revision = checked_revision(luna.get("revision"), "Luna")
        if revision != pins["Luna"]:
            raise ValueError("Public Luna snapshot differs from its immutable pin; "
                             "use a current private checkout or refresh the export")
        # Trust ONLY this repository's verifier and private Git-blob pin.
        # Exported Python files are untrusted until every source hash matches.
        verifier_path = HERE / "verify-pinned-export.py"
        spec = importlib.util.spec_from_file_location("snapshot_verify_pinned", verifier_path)
        verifier = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(verifier)
        checked = verifier.verify(location, pins, capture=capture)
        if capture:
            source, authenticated_revision, authenticated = checked
        else:
            source, authenticated_revision = checked
        if authenticated_revision != revision:
            raise ValueError("Authenticated export Luna revision disagrees with source lock")
    else:
        # A local private checkout does not need the public export. Its HEAD
        # supplies the Luna half of the per-build lock; the packager rechecks it.
        source = location
        if not (source / ".git").exists():
            raise ValueError("Direct Luna source must be a Git checkout")
        revision = subprocess.check_output(
            ["git", "-C", str(source), "rev-parse", "HEAD"],
            text=True, timeout=5).strip()
        checked_revision(revision, "Luna")
        # A commit SHA is not sufficient provenance if the local checkout
        # contains edits that were never reviewed or committed.
        dirty = subprocess.check_output(
            ["git", "-C", str(source), "status", "--porcelain",
             "--untracked-files=normal"], text=True, timeout=5).strip()
        if dirty:
            raise ValueError("Private Luna checkout has uncommitted changes")
    if not (source / "addon.xml").is_file():
        raise ValueError("Selected Luna source is incomplete")
    if not (source / "packaging/package_ng.py").is_file():
        raise ValueError("Selected Luna packager is missing")
    return (source, revision, authenticated) if capture else (source, revision)


def _trusted_packager_bytes(source, revision):
    """Never execute the private checkout's mutable on-disk packager."""
    try:
        source_code = subprocess.check_output(
            ["git", "-C", str(source), "cat-file", "blob",
             revision + ":packaging/package_ng.py"],
            timeout=10, env={**os.environ, "GIT_NO_REPLACE_OBJECTS": "1"})
    except (OSError, subprocess.SubprocessError) as error:
        raise ValueError("Cannot read committed Luna packager") from error
    if not 0 < len(source_code) <= 512 * 1024:
        raise ValueError("Committed Luna packager is missing or oversized")
    return source_code


def _stage_export(snapshot, location):
    """Use exclusively authenticated bytes, even if the export changes later."""
    root = location / "luna"
    root.mkdir()
    (location / "source-lock.json").write_bytes(snapshot["manifest"])
    for rel, (content, mode) in snapshot["files"].items():
        path = root.joinpath(*rel.split("/"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        path.chmod(0o755 if mode == "100755" else 0o644)
    return root


def package(location, native, runtime, output, moonlight_revision):
    pins = json.loads((HERE / "sources.json").read_text(encoding="utf-8"))
    moonlight_revision = checked_revision(moonlight_revision, "Moonlight")
    source, luna_revision, authenticated = select_luna_source(
        location, pins, capture=True)
    if authenticated is None:
        code = _trusted_packager_bytes(source, luna_revision)
        return _package_trusted(source, code, luna_revision, native, runtime,
                                output, moonlight_revision)
    # The pinned export's manifest and every member were captured during
    # verification. Never re-read the export tree or its packager after that.
    with tempfile.TemporaryDirectory(prefix="luna-verified-export-") as tmp:
        safe_source = _stage_export(authenticated, Path(tmp))
        script = authenticated["files"].get("packaging/package_ng.py")
        if not script:
            raise ValueError("Authenticated Luna export lacks its packager")
        return _package_trusted(safe_source, script[0], luna_revision,
                                native, runtime, output, moonlight_revision)


def _package_trusted(source, code, luna_revision, native, runtime,
                     output, moonlight_revision):
    # compile() and exec() see only the previously authenticated immutable
    # source bytes, not an importlib path that could change after validation.
    packager = types.ModuleType("luna_package")
    packager.__file__ = str(source / "packaging/package_ng.py")
    exec(compile(code, packager.__file__, "exec"), packager.__dict__)
    if not hasattr(packager, "read_release_lock"):
        raise ValueError("Luna source lacks per-build release locks; "
                         "refresh the export or use the updated private checkout")
    # Modern Luna emits script.luna.ng directly; earlier immutable pinned
    # sources produced script.luna. Verify exactly the trusted packager's
    # declared ZIP root rather than assuming one version forever.
    addon_id = getattr(packager, "ADDON_ID", "script.luna")
    if addon_id not in ("script.luna.ng", "script.luna"):
        raise ValueError("Unexpected Luna add-on ID in trusted packager")

    native_members = packager.native_members(native)
    native_sha = packager.verify_runtime_manifest(native_members)["source_git_sha"]
    if native_sha != moonlight_revision:
        raise ValueError("Native artifact revision does not match Moonlight build commit")

    runtime_manifest = json.loads((runtime / "manifest.json").read_text(encoding="utf-8"))
    if runtime_manifest.get("moonlight_source_git_sha") != moonlight_revision:
        raise ValueError("VFM runtime and native artifact belong to different Moonlight commits")

    licenses = sorted((runtime / "licenses").glob("*.txt"))
    if len(licenses) != 3:
        raise ValueError("Incomplete VFM license set")

    release = {"schema": RELEASE_LOCK_SCHEMA, "luna_revision": luna_revision,
               "moonlight_revision": moonlight_revision}
    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    # Stage both packaging phases on the output filesystem, so a failed
    # license append or validation leaves an existing good ZIP untouched.
    fd, staged = tempfile.mkstemp(
        prefix=".luna-combined-", suffix=".zip", dir=output.parent)
    os.close(fd)
    try:
        with tempfile.TemporaryDirectory(prefix="luna-release-lock-") as temp:
            lock = Path(temp) / "release-lock.json"
            lock.write_text(json.dumps(release, sort_keys=True) + "\n", encoding="utf-8")
            # select_luna_source() already verified this Git-less export
            # against the externally pinned public snapshot and its manifest.
            # Never infer source identity from the export's own directory name.
            packager.package(source, native, staged, vfm_directory=runtime,
                             release_lock=lock,
                             verified_snapshot_revision=(luna_revision if
                                 not (source / ".git").exists() else None))

        with zipfile.ZipFile(staged, "a", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in licenses:
                packager.zip_entry(
                    archive, "resources/legal/vfm/" + path.name, path.read_bytes())
            packager.zip_entry(archive, "resources/legal/vfm/sources.json",
                               (runtime / "manifest.json").read_bytes())

        with zipfile.ZipFile(staged) as archive:
            if len(archive.namelist()) != len(set(archive.namelist())) or archive.testzip():
                raise ValueError("Invalid or duplicate entries in completed addon")
            if json.loads(archive.read(addon_id + "/release-lock.json")) != release:
                raise ValueError("Completed Luna package has incorrect release provenance")
            for name in runtime_manifest["objects"]:
                if archive.read(addon_id + "/vfm/" + name) != (runtime / name).read_bytes():
                    raise ValueError("Missing or changed VFM payload: " + name)

        with open(staged, "rb") as built:
            os.fsync(built.fileno())
        os.replace(staged, output)
    finally:
        if os.path.exists(staged):
            os.unlink(staged)
    print("Complete Luna VFM addon from Luna %s and Moonlight %s: %s" %
          (luna_revision, moonlight_revision, output))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("luna_source", type=Path)
    parser.add_argument("native", type=Path)
    parser.add_argument("runtime", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--moonlight-revision", required=True,
                        help="Exact Moonlight Git commit that created both artifacts")
    args = parser.parse_args()
    package(args.luna_source.resolve(), args.native.resolve(),
            args.runtime.resolve(), args.output.resolve(), args.moonlight_revision)
