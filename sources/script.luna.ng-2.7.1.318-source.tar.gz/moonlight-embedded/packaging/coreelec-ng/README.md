# Pannal CoreELEC 21 NG cross-build

Build target: Ugoos AM6B+, 32-bit ARM userspace, kernel 4.9.

The recipe in this folder is an **overlay**, not a change to pannal's public
repository. It uses a local clone of this *private* Moonlight fork, avoiding
GitHub tarball authentication in Pannal's build system.

## Steps on a Linux build machine

Clone Pannal's CoreELEC tree and this Moonlight fork. In the Moonlight fork:

```sh
git checkout feat/coreelec-ng
git submodule update --init --recursive
bash packaging/coreelec-ng/prepare-build.sh /path/to/CoreELEC
```

Then in the CoreELEC checkout:

```sh
PROJECT=Amlogic-ce DEVICE=Amlogic-ng ARCH=arm ./scripts/build moonlight-embedded
```

If CoreELEC cached an earlier Moonlight build, clean and rebuild that target
using the **same** PROJECT/DEVICE/ARCH. Re-running the setup script preserves
the original recipe and patch in `moonlight-ng-original`.

## Why the dependencies differ from the stock recipe

Pannal's stock Moonlight package tracks TheChoconut commit
`395f474`; its separate `moonlight-common-c` recipe tracks
`9da6329`. Our source fork starts at `f7dc33c`, whose
`moonlight-common-c` gitlink is `b126e481a195fdc7152d211def17190e3434bcce`.

This build takes moonlight-common-c from the checked-out git submodule
instead of copying the incompatible old package's source. It retains
Pannal's enet, sdlgamecontrollerdb and libamcodec dependencies.

Pannal's `01-surround-fix.patch` is moved out of the patch folder because
the same CoreELEC channel mapping is now an **optional CMake flag** in our
Moonlight fork.

## Limitations

A GitHub Actions build is not considered validated merely because its
workflow exists. Verify the selected run's compiler result, ARM32 artifact
manifest and toolchain diagnostics before installing anything. The host needs
Pannal's full toolchain, local-source dependencies and associated sources.
Device-side HDMI, decoder, audio and input tests remain necessary.

## Private GitHub Actions builds

For the current `feat/coreelec-ng` branch, open the private repository's
[CoreELEC 21 NG ARM32 native build](https://github.com/Roboatlas21/moonlight-embedded/actions/workflows/coreelec-ng-native.yml)
workflow, select **Run workflow**, and choose the `feat/coreelec-ng` branch
for best cache reuse. The small same-name workflow on the default `master`
branch only registers the manual action; it delegates to the private branch.

The default `build_native=false` runs the comprehensive private host
regressions without consuming ARM32 compiler hours. Set `build_native=true`
to start native compilation after the host checks pass. Leave
`clean_build=false` to reuse the existing CoreELEC NG toolchain/dependency
checkpoints. `build_vfm_runtime=true` also builds the experimental VFM
decoder runtime. **No source push invokes the expensive native workflow.**

The native outputs are immutable, short-lived workflow artifacts:

- `moonlight-coreelec21-ng-arm32`: ELF32 executable, matching private
  libraries, manifest and build info.
- `moonlight-coreelec21-ng-vfm-runtime`: optional VFM runtime and its
  source-revision manifest.
- `coreelec-ng-build-logs` and `coreelec-ng-preflight-logs`: diagnostics.

The **private** `Roboatlas21/Luna` repository now also has a standalone
**Luna NG private installable build** Actions workflow. Use the successful
Moonlight native run ID from above: Luna validates the exact ARM32 artifact,
checks out this private Moonlight source commit and recursively pinned
submodules, packages a `script.luna.ng` installable ZIP, verifies manifests
and checksums, and uploads its matching source archive. Luna requires its own
read-only `KODI_LUNA_READ_TOKEN` with access to this repository's Contents and
Actions artifacts. The expensive Moonlight compiler is **not** rerun by Luna.
This is the preferred private test-build path replacing the older public
Snapshot and Luna-build pipelines.

The **private** `Roboatlas21/Kodi-Utilities-Source` release workflow
consumes the exact successful native build run and current Luna source to
create the installable `script.luna.ng` ZIP, its source archive, and a
nonpublishing test build. Only a separate explicit `publish=true` run updates
the public Kodi Utilities feed. There is no need to refresh the older public
`xbmc-p3i` Luna source snapshot or run the old public `Luna-build` workflow.
Their SHA-pinned sources lag the active private branches.

Caching is private-repository scoped. The dependency fingerprint uses only
CoreELEC/kernel/FFmpeg pins and native recipe bytes, not Luna package/source
snapshot pins; a Luna-only update must not invalidate a CoreELEC toolchain.
A new cache namespace or GitHub's cache eviction policy may still require a
cold first build. Successful compilation does not prove HDMI/ALSA/HID runtime
behavior on Ugoos AM6B+, so hardware smoke tests remain mandatory.

## Native artifact provenance

After building, collect the native ELF bundle with an explicit source commit:

```sh
SOURCE_GIT_SHA="$(git rev-parse --verify HEAD)" \
  bash packaging/coreelec-ng/collect-native.sh /path/to/CoreELEC /path/to/output
```

The collector and manifest generator reject missing or `unknown` source
revisions, including for manually collected test bundles. Record the SHA from
the **Moonlight source checkout used for the CoreELEC build**. The Kodi add-on
packager also validates this field. A SHA records provenance but does not
replace testing or prove the toolchain built that particular checkout.
