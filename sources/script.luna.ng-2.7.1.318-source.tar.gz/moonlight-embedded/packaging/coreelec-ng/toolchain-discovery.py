#!/usr/bin/env python3
"""Non-mutating CoreELEC toolchain/cache inventory for private build diagnostics.

Ports the public Luna-build discovery report without using public snapshots.
Writes only path/size metadata, never credentials or executable contents.
"""
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys


def size_on_disk(path: Path):
    result = subprocess.run(
        ["du", "-sk", str(path)], capture_output=True, text=True, check=False
    )
    if result.returncode != 0:
        return None
    try:
        return int(result.stdout.split()[0]) * 1024
    except (IndexError, ValueError):
        return None


def inventory(coreelec: Path):
    builds = sorted(p for p in coreelec.glob("build.*") if p.is_dir())
    result = {
        "schema": 1,
        "build_roots": [],
        "compiler_candidates": [],
        "toolchain_directories": [],
        "sysroot_candidates": [],
        "stamp_directories": [],
        "host_utility_candidates": [],
        "note": "Diagnostic inventory only; existing build/cache data unchanged",
    }

    def entry(path: Path):
        item = {"path": str(path), "bytes_on_disk": size_on_disk(path)}
        if path.is_symlink():
            item["link_target"] = os.readlink(path)
        return item

    for build in builds:
        result["build_roots"].append(entry(build))
        for path in build.iterdir():
            name = path.name.lower()
            if "toolchain" in name:
                result["toolchain_directories"].append(entry(path))
            if "sysroot" in name:
                result["sysroot_candidates"].append(entry(path))
            if "stamp" in name:
                result["stamp_directories"].append(entry(path))

        for base in (
            build / "toolchain",
            build / "toolchain/bin",
            build / "toolchain/usr/bin",
            build / "stamps",
            build / ".stamps",
        ):
            if base.is_dir():
                key = "toolchain_directories" if "toolchain" in str(base) else "stamp_directories"
                result[key].append(entry(base))

        for pattern in (
            "**/*-gcc", "**/*-g++", "**/arm*-gcc", "**/sysroot",
            "**/stamps/toolchain", "**/stamp*/toolchain",
        ):
            for path in itertools.islice(build.glob(pattern), 25):
                if path.is_file() and os.access(path, os.X_OK):
                    result["compiler_candidates"].append(entry(path))
                elif path.is_dir():
                    key = "sysroot_candidates" if path.name == "sysroot" else "stamp_directories"
                    result[key].append(entry(path))

        for name in ("sed", "make", "cmake", "pkg-config", "python3"):
            for path in itertools.islice(build.glob("**/bin/" + name), 10):
                if path.is_file():
                    result["host_utility_candidates"].append(entry(path))

    for key, values in result.items():
        if isinstance(values, list):
            result[key] = list({item["path"]: item for item in values}.values())
    return result


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: toolchain-discovery.py COREELEC_PATH OUTPUT_JSON")
    root = Path(sys.argv[1])
    output = Path(sys.argv[2])
    output.parent.mkdir(parents=True, exist_ok=True)
    report = inventory(root)
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for key in (
        "build_roots", "toolchain_directories", "sysroot_candidates",
        "stamp_directories", "compiler_candidates", "host_utility_candidates",
    ):
        print(f"{key}: {len(report[key])}")
    print(f"Saved: {output}")
