/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_OSD_FBDEV_H
#define MOONLIGHT_OSD_FBDEV_H
#include "osd.h"
#include "frametime.h"
typedef struct OsdFbdev OsdFbdev;
/* CoreELEC NG Mali/fbdev only; requires Luna's stopped-Kodi handoff. All
 * calls, including teardown, must run on the same OSD worker thread. */
OsdFbdev *osd_fbdev_open(const OsdOptions *options);
bool osd_fbdev_draw(OsdFbdev *osd, const char *first, const char *second, const OsdFtView *graph);
void osd_fbdev_close(OsdFbdev *osd);
#endif
