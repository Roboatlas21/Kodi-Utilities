/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "frametime.h"
#include "font.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void osd_ft_reset(OsdFtCapture *capture) {
  if (capture) memset(capture, 0, sizeof(*capture));
}
static uint32_t bounded_interval(uint32_t delta) {
  return delta > OSD_FT_MAX_INTERVAL_US ? OSD_FT_MAX_INTERVAL_US : delta;
}
static void record(OsdFtCapture *capture, uint32_t start_us,
                   uint32_t end_us, bool has_frame, uint32_t frame_number) {
  if (!capture) return;
  const uint32_t index = capture->written;
  OsdFtEntry *entry = &capture->frames[index % OSD_FT_SAMPLES];
  const uint32_t gap_in = capture->seen ?
      bounded_interval(start_us - capture->last_callback_us) : 0;
  const uint32_t gap_out = capture->seen ?
      bounded_interval(end_us - capture->last_return_us) : 0;
  const uint32_t duration = bounded_interval(end_us - start_us);
  uint32_t missing = 0;
  if (has_frame) {
    const uint32_t delta = frame_number - capture->last_frame_number;
    if (capture->seen_frame && delta > 1 && delta < UINT32_MAX / 2)
      missing = delta - 1;
    if (!capture->seen_frame || (delta && delta < UINT32_MAX / 2)) {
      capture->last_frame_number = frame_number;
      capture->seen_frame = true;
    }
  }
  /* The video callback is the single producer. Atomic ticket invalidation
   * and publication prevent readers from accepting a torn overwritten slot. */
  __atomic_store_n(&entry->ticket, 0, __ATOMIC_SEQ_CST);
  __atomic_store_n(&entry->callback_gap_us, gap_in, __ATOMIC_RELAXED);
  __atomic_store_n(&entry->return_gap_us, gap_out, __ATOMIC_RELAXED);
  __atomic_store_n(&entry->execution_us, duration, __ATOMIC_RELAXED);
  __atomic_store_n(&entry->end_us, end_us, __ATOMIC_RELAXED);
  __atomic_store_n(&entry->missing_frames, missing, __ATOMIC_RELAXED);
  __atomic_store_n(&entry->ticket, index + 1, __ATOMIC_SEQ_CST);
  capture->last_callback_us = start_us;
  capture->last_return_us = end_us;
  capture->seen = true;
  capture->written = index + 1;
  __atomic_store_n(&capture->published, capture->written, __ATOMIC_RELEASE);
}
void osd_ft_record(OsdFtCapture *c, uint32_t start, uint32_t end) {
  record(c, start, end, false, 0);
}
void osd_ft_record_frame(OsdFtCapture *c, uint32_t start, uint32_t end,
                         uint32_t frame_number) {
  record(c, start, end, true, frame_number);
}
void osd_ft_snapshot(const OsdFtCapture *capture, uint32_t now_us,
                     int requested_fps, OsdFtView *out) {
  if (!out) return;
  memset(out, 0, sizeof(*out));
  if (!capture) return;
  out->requested_fps = requested_fps > 0 && requested_fps <= 240 ? requested_fps : 0;
  const uint32_t published = __atomic_load_n(&capture->published, __ATOMIC_ACQUIRE);
  const uint32_t oldest = published > OSD_FT_SAMPLES ? published - OSD_FT_SAMPLES : 0;
  out->span = published - oldest;
  for (uint32_t i = oldest; i < published; ++i) {
    const OsdFtEntry *entry = &capture->frames[i % OSD_FT_SAMPLES];
    const uint32_t ticket = __atomic_load_n(&entry->ticket, __ATOMIC_SEQ_CST);
    if (ticket != i + 1) continue;
    const uint32_t cb = __atomic_load_n(&entry->callback_gap_us, __ATOMIC_RELAXED);
    const uint32_t ret = __atomic_load_n(&entry->return_gap_us, __ATOMIC_RELAXED);
    const uint32_t exec = __atomic_load_n(&entry->execution_us, __ATOMIC_RELAXED);
    const uint32_t missing = __atomic_load_n(&entry->missing_frames, __ATOMIC_RELAXED);
    if (__atomic_load_n(&entry->ticket, __ATOMIC_SEQ_CST) != ticket) continue;
    const unsigned n = out->count++;
    out->callback_gap_us[n] = cb;
    out->return_gap_us[n] = ret;
    out->execution_us[n] = exec;
    out->missing_frames[n] = missing;
    out->position[n] = (uint16_t)(i - oldest);
  }
  if (published) {
    const OsdFtEntry *latest = &capture->frames[(published - 1) % OSD_FT_SAMPLES];
    if (__atomic_load_n(&latest->ticket, __ATOMIC_SEQ_CST) == published) {
      const uint32_t end = __atomic_load_n(&latest->end_us, __ATOMIC_RELAXED);
      if (__atomic_load_n(&latest->ticket, __ATOMIC_SEQ_CST) == published) {
        out->newest_age_ms = (now_us - end) / 1000;
        out->stale = (now_us - end) > 500000;
      }
    }
  }
}
static int ascending(const void *a, const void *b) {
  uint32_t x=*(const uint32_t*)a, y=*(const uint32_t*)b;
  return (x>y)-(x<y);
}
static void stats(const uint32_t *values, unsigned count, uint32_t budget,
                  bool skip_unknown, OsdFtPercentiles *out) {
  uint32_t sorted[OSD_FT_SAMPLES];
  uint64_t sum = 0;
  unsigned n = 0;
  for (unsigned i=0; i<count && i<OSD_FT_SAMPLES; i++) {
    const uint32_t us=values[i];
    if (skip_unknown && !us) continue;
    sorted[n++]=us;
    sum+=us;
    /* 1ms slack avoids treating ordinary arrival quantization as a hitch. */
    if (budget && us>budget+1000u) out->over_one_frame++;
    if (budget && us>budget*2u+1000u) out->over_two_frames++;
  }
  out->samples=n;
  if (!n) return;
  qsort(sorted,n,sizeof(sorted[0]),ascending);
  out->mean_us=(uint32_t)((sum+n/2)/n);
  out->p95_us=sorted[(95u*n+99u)/100u-1u];
  out->p99_us=sorted[(99u*n+99u)/100u-1u];
  out->worst_us=sorted[n-1];
}
void osd_ft_summarize(const OsdFtView *v, OsdFtSummary *out) {
  if (!out) return;
  memset(out,0,sizeof(*out));
  if (!v) return;
  out->target_us=v->requested_fps>0 && v->requested_fps<=240 ?
                 1000000u/(unsigned)v->requested_fps : 0;
  stats(v->callback_gap_us,v->count,out->target_us,true,&out->arrival);
  stats(v->execution_us,v->count,out->target_us,false,&out->submit);
  for (unsigned i=0;i<v->count && i<OSD_FT_SAMPLES;i++) {
    if (v->missing_frames[i]) {
      out->gap_events++;
      if (UINT32_MAX-out->missing_frames < v->missing_frames[i])
        out->missing_frames=UINT32_MAX;
      else out->missing_frames+=v->missing_frames[i];
    }
  }
}
void osd_ft_axes(const OsdFtView *v, const OsdFtSummary *s,
                 OsdFtAxes *axes) {
  if (!axes) return;
  const uint32_t target=s && s->target_us ? s->target_us :
      v && v->requested_fps>0 && v->requested_fps<=240 ?
      1000000u/(unsigned)v->requested_fps : 16667u;
  const uint32_t margin=target/2u>4000u?target/2u:4000u;
  axes->arrival_min_us=target>margin?target-margin:0;
  axes->arrival_max_us=target+margin;
  uint32_t p99=s?s->submit.p99_us:0;
  uint32_t upper=p99>UINT32_MAX/2u?UINT32_MAX:p99*2u;
  if (upper<4000u) upper=4000u;
  if (upper<target/2u) upper=target/2u;
  if (upper>target*2u) upper=target*2u;
  axes->submit_max_us=upper;
}
void osd_ft_caption(const OsdFtView *v, char *arrival, size_t an,
                    char *submit, size_t sn) {
  OsdFtSummary summary;
  osd_ft_summarize(v,&summary);
  if (arrival && an) {
    if (!summary.arrival.samples) snprintf(arrival,an,"IN: WAITING FOR FRAMES");
    else snprintf(arrival,an,
      "IN A%.1f 95:%.1f 99:%.1f W:%.1f GAP:%u LOST:%u",
      summary.arrival.mean_us/1000.0,summary.arrival.p95_us/1000.0,
      summary.arrival.p99_us/1000.0,summary.arrival.worst_us/1000.0,
      summary.gap_events,summary.missing_frames);
  }
  if (submit && sn) {
    if (!summary.submit.samples) snprintf(submit,sn,"SUB: WAITING FOR DECODER CALLBACKS");
    else snprintf(submit,sn,
      "SUB A%.1f 95:%.1f 99:%.1f W:%.1f H1:%u H2:%u",
      summary.submit.mean_us/1000.0,summary.submit.p95_us/1000.0,
      summary.submit.p99_us/1000.0,summary.submit.worst_us/1000.0,
      summary.submit.over_one_frame,summary.submit.over_two_frames);
  }
}
static void put(uint32_t *p, unsigned stride, unsigned sw, unsigned sh,
                int x, int y, uint32_t color) {
  if (x>=0 && y>=0 && (unsigned)x<sw && (unsigned)y<sh)
    p[(size_t)y*stride+(unsigned)x]=color;
}
static void segment(uint32_t *p, unsigned stride, unsigned sw, unsigned sh,
                    int x0, int y0, int x1, int y1, uint32_t color) {
  int dx=x0>x1?x0-x1:x1-x0, dy=y0>y1?y0-y1:y1-y0;
  int sx=x0<x1?1:-1,sy=y0<y1?1:-1,err=dx-dy;
  for (;;) {
    put(p,stride,sw,sh,x0,y0,color);
    if (x0==x1 && y0==y1) break;
    int e2=err*2;
    if (e2>-dy) {err-=dy;x0+=sx;}
    if (e2<dx) {err+=dx;y0+=sy;}
  }
}
static int graph_y(uint32_t value, int top, int bottom,
                   uint32_t low, uint32_t high) {
  if (value<low) value=low;
  if (value>high) value=high;
  return bottom-(int)((uint64_t)(value-low)*(uint32_t)(bottom-top)/(high-low));
}
/* Scale-independent 5x7 millisecond labels. */
static void graph_text(uint32_t *p, unsigned stride, unsigned sw, unsigned sh,
                       int x, int y, const char *txt, uint32_t color) {
  for (const char *q=txt;*q;q++,x+=6) {
    const uint8_t *glyph=osd_glyph(*q);
    for (int row=0;row<7;row++) for (int col=0;col<5;col++)
      if (glyph[row]&(1u<<(4-col)))
        put(p,stride,sw,sh,x+col,y+row,color);
  }
}
static void lane(uint32_t *p, unsigned stride, unsigned sw, unsigned sh,
                 const OsdFtView *v, bool arrival, int x, int right,
                 int top, int bottom, uint32_t low, uint32_t high,
                 uint32_t target) {
  if (top+14>bottom || high<=low) return;
  const uint32_t axis=0xff777777u, ref=0xffbcbcbcu,white=0xffffffffu;
  const uint32_t line=arrival?0xff00ff00u:0xffff00ffu;
  const uint32_t alert=0xff5555ffu, gap=0xff00ffffu;
  const int graph_left=x+52;
  if (graph_left>=right) return;
  char label[28];
  snprintf(label,sizeof(label),"%.1fMS",high/1000.0);
  graph_text(p,stride,sw,sh,x+2,top+1,label,white);
  graph_text(p,stride,sw,sh,x+2,top+11,arrival?"IN":"SUB",line);
  snprintf(label,sizeof(label),"%.1fMS",low/1000.0);
  graph_text(p,stride,sw,sh,x+2,bottom-7,label,white);
  segment(p,stride,sw,sh,graph_left,bottom,right,bottom,axis);
  if (target>=low && target<=high) {
    int yy=graph_y(target,top+1,bottom,low,high);
    for (int xx=graph_left;xx<=right;xx+=5)
      put(p,stride,sw,sh,xx,yy,ref);
  }
  if (!v->span) return;
  const unsigned width=(unsigned)(right-graph_left);
  int prior_x=0,prior_y=0;
  uint16_t prior_pos=0;
  bool prior_valid=false;
  for (unsigned i=0;i<v->count && i<OSD_FT_SAMPLES;i++) {
    const int xx=graph_left+(int)((uint64_t)v->position[i]*width/
                                    (v->span>1?v->span-1u:1u));
    const uint32_t value=arrival?v->callback_gap_us[i]:v->execution_us[i];
    const int yy=graph_y(value,top+1,bottom,low,high);
    const bool valid=!(arrival && value==0);
    if (valid && prior_valid && v->position[i]==(unsigned)prior_pos+1u)
      segment(p,stride,sw,sh,prior_x,prior_y,xx,yy,line);
    else if (valid) put(p,stride,sw,sh,xx,yy,line);
    if (valid && (value>high || value<low)) {
      const int flag_y=value>high?top+1:bottom-2;
      for(int k=0;k<3;k++) put(p,stride,sw,sh,xx,flag_y+k,alert);
    }
    if (arrival && v->missing_frames[i]) {
      for (int k=0;k<7;k++) put(p,stride,sw,sh,xx,top+1+k,gap);
    }
    prior_x=xx;prior_y=yy;prior_pos=v->position[i];prior_valid=valid;
  }
}
void osd_ft_plot(const OsdFtView *v, uint32_t *pixels, unsigned stride,
                 unsigned sw, unsigned sh, int x, int y, int width, int height) {
  if (!v || !pixels || !sw || !sh || stride<sw || width<90 || height<52 ||
      x<0 || y<0 || (unsigned)x>sw || (unsigned)y>sh ||
      (unsigned)width>sw-(unsigned)x || (unsigned)height>sh-(unsigned)y)
    return;
  OsdFtSummary summary;
  OsdFtAxes axes;
  osd_ft_summarize(v,&summary);
  osd_ft_axes(v,&summary,&axes);
  const int middle=y+height/2;
  lane(pixels,stride,sw,sh,v,true,x,x+width-2,y+1,middle-4,
       axes.arrival_min_us,axes.arrival_max_us,summary.target_us);
  lane(pixels,stride,sw,sh,v,false,x,x+width-2,middle+4,y+height-3,
       0,axes.submit_max_us,summary.target_us);
}
