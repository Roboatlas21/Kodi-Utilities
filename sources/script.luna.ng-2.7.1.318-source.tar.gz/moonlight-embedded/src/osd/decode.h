/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_OSD_DECODE_H
#define MOONLIGHT_OSD_DECODE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Pannal NG 4.9 legacy MVDECINFO ABI; see docs/osd-telemetry.md. Explicit
 * padding/alignment keeps this identical on ARM32 and AArch64. */
typedef struct {
  uint32_t qos[14], decode_ns, width, height, frame_rate, bit_depth_luma;
  uint32_t frame_duration, bit_depth_chroma, errors, status, frame_count;
  uint32_t frame_errors, drops;
  uint64_t total_data __attribute__((aligned(8)));
  uint32_t double_write, offset, ratio, vf_type, signal_type, pts;
  uint64_t pts_us __attribute__((aligned(8)));
} OsdNgDecodeFrame;
typedef struct {
  int32_t id, size, slots, decoder_id;
  char name[16];
  uint32_t type, padding;
  OsdNgDecodeFrame frames[8];
} OsdNgDecodeInfo;

bool osd_decode_accumulate(const OsdNgDecodeInfo *info, uint32_t width,
                            uint32_t height, uint64_t *ns, unsigned *count);
bool osd_decode_sample(int fd, uint32_t width, uint32_t height, double *ms);
#endif
