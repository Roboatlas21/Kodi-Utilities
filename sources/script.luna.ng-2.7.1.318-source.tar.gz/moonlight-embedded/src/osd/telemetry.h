/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_OSD_TELEMETRY_H
#define MOONLIGHT_OSD_TELEMETRY_H
#include "stats.h"
#include "frametime.h"
#include "host_metrics.h"
#include <Limelight.h>

/* One streaming session, like common-c. Prepare only while it is stopped.
 * Copies callbacks, preserving capabilities, contexts and return values. */
void osd_telemetry_prepare(const char *host, unsigned short https_port,
                           PDECODER_RENDERER_CALLBACKS *video,
                           PAUDIO_RENDERER_CALLBACKS *audio,
                           bool record_frame_timing);

typedef struct {
  bool initialized, nic_initialized;
  uint64_t last_ms, rx_bytes, rx_errors, rx_drops;
  uint32_t video_bytes, audio_bytes, pool_peak, pool_size;
  char interface[64];
  int ping_fd;
  HostMetricsReader host;
  int decoder_fd;
  bool ping_pending, ping_valid;
  uint16_t ping_sequence;
  uint64_t ping_sent_ms, ping_next_ms, ping_received_ms;
  uint64_t ping_sent_realtime_ns;
  double ping_ms, ping_jitter_ms;
} OsdTelemetry;

void osd_telemetry_open(OsdTelemetry *t, bool aml_stats);
void osd_telemetry_close(OsdTelemetry *t);
/* Nonblocking; call once each monitor tick, even between visual samples. */
void osd_telemetry_poll(OsdTelemetry *t, uint64_t now_ms);
/* Valid only while the optional visual OSD graph is requested. Neither
 * decoded frame submission nor the HDMI sink is physical scanout feedback. */
void osd_telemetry_frametime(OsdFtView *out);
/* Prefix stream details and new measurements; retain the original detailed
 * metrics in the second paragraph. Only the monitor thread reads sysfs. */
void osd_telemetry_format(OsdTelemetry *t, uint64_t now_ms,
                          const OsdSnapshot *s, char *first, size_t fn,
                          char *second, size_t sn);

/* Pure helpers shared by live collection and host tests. */
bool osd_parse_gpu_percent(const char *text, float *out);
bool osd_byte_rate(uint64_t now, uint64_t before, uint64_t bytes,
                   uint64_t prior_bytes, double *mbps);
void osd_frame_gap(uint32_t frame, bool *seen, uint32_t *last,
                    uint32_t *missing, uint32_t *gaps);
#endif
