/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef LUNA_DIAGNOSTIC_RING_H
#define LUNA_DIAGNOSTIC_RING_H
/* A separate bounded native diagnostics continuation. Never truncate or
 * rotate stderr/logfile: the launcher and other producers share that inode. */
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#ifndef OSD_DIAG_RING_LIMIT_BYTES
#define OSD_DIAG_RING_LIMIT_BYTES (16ULL * 1024ULL * 1024ULL)
#endif

#define OSD_DIAG_RING_CURRENT "native-diagnostics.rolling.0"
#define OSD_DIAG_RING_PREVIOUS "native-diagnostics.rolling.1"

typedef struct {
  int dirfd;
  int fd;
  uint64_t used;
  bool available;
} LunaDiagnosticRing;

static inline void osd_diag_ring_close(LunaDiagnosticRing *r) {
  if (!r) return;
  if (r->fd >= 0) {
    (void)fsync(r->fd);
    close(r->fd);
    r->fd = -1;
  }
  if (r->dirfd >= 0) {
    close(r->dirfd);
    r->dirfd = -1;
  }
  r->available = false;
}
static inline bool osd_diag_ring_file_ok(int dirfd, const char *filename) {
  struct stat st;
  return fstatat(dirfd, filename, &st, AT_SYMLINK_NOFOLLOW) == 0 &&
         S_ISREG(st.st_mode) && st.st_uid == geteuid() &&
         st.st_nlink == 1 && !(st.st_mode & (S_IWGRP | S_IWOTH));
}
static inline bool osd_diag_ring_new_file(LunaDiagnosticRing *r) {
  const int flags = O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC;
  int fd = openat(r->dirfd, OSD_DIAG_RING_CURRENT, flags, 0600);
  if (fd < 0) return false;
  struct stat st;
  if (fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) ||
      st.st_uid != geteuid() || st.st_nlink != 1) {
    close(fd);
    unlinkat(r->dirfd, OSD_DIAG_RING_CURRENT, 0);
    return false;
  }
  r->fd = fd;
  r->used = 0;
  return true;
}
static inline bool osd_diag_ring_rotate(LunaDiagnosticRing *r) {
  if (r->fd >= 0) {
    (void)fsync(r->fd);
    close(r->fd);
    r->fd = -1;
  }
  if (!osd_diag_ring_file_ok(r->dirfd, OSD_DIAG_RING_CURRENT) ||
      renameat(r->dirfd, OSD_DIAG_RING_CURRENT, r->dirfd,
               OSD_DIAG_RING_PREVIOUS) != 0)
    return false;
  return osd_diag_ring_new_file(r);
}
static inline bool osd_diag_ring_open(LunaDiagnosticRing *r,
                                      const char *directory) {
  if (!r) return false;
  r->dirfd = -1;
  r->fd = -1;
  r->used = 0;
  r->available = false;
  if (!directory || !*directory || strlen(directory) > 1024) return false;
  int fd = open(directory, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
  if (fd < 0) return false;
  struct stat st;
  if (fstat(fd, &st) != 0 || !S_ISDIR(st.st_mode) ||
      st.st_uid != geteuid() || (st.st_mode & (S_IWGRP | S_IWOTH))) {
    close(fd);
    return false;
  }
  r->dirfd = fd;
  if (fstatat(fd, OSD_DIAG_RING_CURRENT, &st, AT_SYMLINK_NOFOLLOW) == 0) {
    if (!osd_diag_ring_file_ok(fd, OSD_DIAG_RING_CURRENT) ||
        renameat(fd, OSD_DIAG_RING_CURRENT, fd,
                 OSD_DIAG_RING_PREVIOUS) != 0) {
      osd_diag_ring_close(r);
      return false;
    }
  } else if (errno != ENOENT) {
    osd_diag_ring_close(r);
    return false;
  }
  if (!osd_diag_ring_new_file(r)) {
    osd_diag_ring_close(r);
    return false;
  }
  r->available = true;
  return true;
}
static inline bool osd_diag_ring_write_all(int fd, const char *data,
                                           size_t count) {
  while (count) {
    ssize_t n = write(fd, data, count);
    if (n < 0 && errno == EINTR) continue;
    if (n <= 0) return false;
    data += n;
    count -= (size_t)n;
  }
  return true;
}
static inline bool osd_diag_ring_append(LunaDiagnosticRing *r,
                                        const char *line) {
  if (!r || !r->available || r->fd < 0 || !line) return false;
  size_t size = strnlen(line, 4097);
  if (size > 4096 || size + 1 > OSD_DIAG_RING_LIMIT_BYTES)
    return false;
  if (r->used + size + 1 > OSD_DIAG_RING_LIMIT_BYTES &&
      !osd_diag_ring_rotate(r)) {
    osd_diag_ring_close(r);
    return false;
  }
  if (!osd_diag_ring_write_all(r->fd, line, size) ||
      !osd_diag_ring_write_all(r->fd, "\n", 1)) {
    osd_diag_ring_close(r);
    return false;
  }
  r->used += size + 1;
  return true;
}
#endif
