/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef LUNA_OSD_DRM_RETRY_H
#define LUNA_OSD_DRM_RETRY_H
#include <stdbool.h>
#include <stdint.h>

/* Temporary KMS failures should not permanently remove the overlay, but
 * a missing DRM device must not cause endless re-open attempts. */
enum { OSD_DRM_RETRY_LIMIT = 3U, OSD_DRM_RETRY_DELAY_MS = 3000U };
static inline bool osd_drm_retry_due(unsigned attempts, uint64_t now_ms,
                                     uint64_t next_ms) {
  return attempts < OSD_DRM_RETRY_LIMIT && now_ms >= next_ms;
}
#endif
