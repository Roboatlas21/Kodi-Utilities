/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef LUNA_OSD_NETWORK_DEBUG_LOG_H
#define LUNA_OSD_NETWORK_DEBUG_LOG_H
#include "net_rx_debug.h"
typedef struct {
  LunaNetworkDebugV1 previous;
  bool initialized;
} LunaNetworkDebugTracker;

/* One bounded line per second. Counts are packet observations, not generic
 * network-loss percentages. Counter deltas tolerate u32 wrap. */
void luna_net_debug_format(LunaNetworkDebugTracker *tracker,
                           const LunaNetworkDebugV1 *current,
                           char *output, size_t size);
#endif
