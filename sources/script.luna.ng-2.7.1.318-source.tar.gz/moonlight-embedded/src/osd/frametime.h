/* SPDX-License-Identifier: GPL-3.0-or-later
 * Per-frame decoder callback timing, not physical display presentation.
 */
#ifndef MOONLIGHT_FRAMETIME_H
#define MOONLIGHT_FRAMETIME_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#define OSD_FT_SAMPLES 240
#define OSD_FT_MAX_INTERVAL_US 250000U
typedef struct {
  uint32_t ticket, callback_gap_us, return_gap_us, execution_us, end_us;
  uint32_t missing_frames;
} OsdFtEntry;
typedef struct {
  OsdFtEntry frames[OSD_FT_SAMPLES];
  uint32_t published, written, last_callback_us, last_return_us;
  uint32_t last_frame_number;
  bool seen, seen_frame;
} OsdFtCapture;
typedef struct {
  unsigned count, span;
  uint32_t callback_gap_us[OSD_FT_SAMPLES];
  uint32_t return_gap_us[OSD_FT_SAMPLES];
  uint32_t execution_us[OSD_FT_SAMPLES];
  uint32_t missing_frames[OSD_FT_SAMPLES];
  uint16_t position[OSD_FT_SAMPLES];
  uint32_t newest_age_ms;
  int requested_fps;
  bool stale;
} OsdFtView;
typedef struct {
  unsigned samples, over_one_frame, over_two_frames;
  uint32_t mean_us, p95_us, p99_us, worst_us;
} OsdFtPercentiles;
typedef struct {
  OsdFtPercentiles arrival, submit;
  uint32_t gap_events, missing_frames;
  uint32_t target_us;
} OsdFtSummary;
typedef struct {
  uint32_t arrival_min_us, arrival_max_us, submit_max_us;
} OsdFtAxes;
void osd_ft_reset(OsdFtCapture *capture);
void osd_ft_record(OsdFtCapture *capture, uint32_t start_us, uint32_t end_us);
void osd_ft_record_frame(OsdFtCapture *capture, uint32_t start_us,
                         uint32_t end_us, uint32_t frame_number);
void osd_ft_snapshot(const OsdFtCapture *capture, uint32_t now_us,
                     int requested_fps, OsdFtView *out);
void osd_ft_summarize(const OsdFtView *view, OsdFtSummary *out);
void osd_ft_axes(const OsdFtView *view, const OsdFtSummary *summary,
                 OsdFtAxes *axes);
void osd_ft_caption(const OsdFtView *view, char *arrival, size_t arrival_size,
                    char *submit, size_t submit_size);
/* Dual-lane ARGB8888 pixel plot with strict surface geometry checks. */
void osd_ft_plot(const OsdFtView *view, uint32_t *pixels,
                 unsigned stride_pixels, unsigned surface_width,
                 unsigned surface_height, int x, int y, int width, int height);
#endif
