/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_OSD_LOG_BUDGET_H
#define MOONLIGHT_OSD_LOG_BUDGET_H
#include <stdbool.h>
#include <stdint.h>
#include <sys/stat.h>
#include <unistd.h>

/* Bound the stream of periodic Debug samples without truncating or rotating
 * an open session file (which could invalidate concurrent appenders). Other
 * native error/status output remains available even after this cap. */
#define OSD_DIAG_LOG_LIMIT_BYTES (32ULL * 1024ULL * 1024ULL)
static inline bool osd_diag_log_budget_reached(int fd, uint64_t limit) {
  struct stat st;
  return fd >= 0 && fstat(fd, &st) == 0 && S_ISREG(st.st_mode) &&
         st.st_size >= 0 && (uint64_t)st.st_size >= limit;
}
#endif
