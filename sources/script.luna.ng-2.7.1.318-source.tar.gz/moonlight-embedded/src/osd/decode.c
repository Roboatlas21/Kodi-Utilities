/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "decode.h"
#include <sys/ioctl.h>

typedef char check_frame_size[sizeof(OsdNgDecodeFrame)==144 ? 1 : -1];
typedef char check_info_size[sizeof(OsdNgDecodeInfo)==1192 ? 1 : -1];
typedef char check_time_offset[offsetof(OsdNgDecodeFrame,decode_ns)==56 ? 1 : -1];
typedef char check_frames_offset[offsetof(OsdNgDecodeInfo,frames)==40 ? 1 : -1];

bool osd_decode_accumulate(const OsdNgDecodeInfo *info, uint32_t width,
                            uint32_t height, uint64_t *ns, unsigned *count) {
  if (!info || !ns || !count || !width || !height ||
      info->slots<1 || info->slots>8 || info->size!=(int)sizeof(*info)) return false;
  bool valid=false;
  for (int i=0;i<info->slots;i++) {
    const OsdNgDecodeFrame *f=&info->frames[i];
    if (f->width==width && f->height==height && f->decode_ns>0 &&
        f->decode_ns<=1000000000u) {
      *ns+=f->decode_ns; ++*count; valid=true;
    }
  }
  return valid;
}

bool osd_decode_sample(int fd, uint32_t width, uint32_t height, double *ms) {
  if (fd<0 || !ms) return false;
  uint64_t sum=0; unsigned count=0;
  /* The 128-entry driver ring is consumed by this ioctl. Bound work to one
   * ring and sample from the session's duplicated decoder fd only. Never open
   * amstream or select another process's decoder by a guessed global ID. */
  for (unsigned i=0;i<16;i++) {
    OsdNgDecodeInfo info={.size=sizeof(info)};
    if (ioctl(fd,_IOR('S',0xcb,int),&info)<0 || info.slots<1 || info.slots>8) break;
    osd_decode_accumulate(&info,width,height,&sum,&count);
    if (info.slots<8) break;
  }
  if (!count) return false;
  /* Both vmh264 and vh265 in the pinned NG media modules pass local_clock()
   * deltas, in nanoseconds. The kernel header's 'us' comment is incorrect. */
  *ms=(double)sum/count/1000000.0;
  return true;
}
