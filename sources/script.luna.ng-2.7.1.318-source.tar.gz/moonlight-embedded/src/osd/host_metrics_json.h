/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_HOST_METRICS_JSON_H
#define MOONLIGHT_HOST_METRICS_JSON_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
  uint32_t interval_ms;
  bool has_cpu, has_gpu, has_encoder, has_temp, has_vram, has_vram_percent;
  double cpu, gpu, encoder, temp, vram_mb, vram_percent;
  /* The v1 host schema lists GPUs, but does not identify the actual
   * Sunshine encoder. Label the sampled GPU rather than imply ownership. */
  uint32_t gpu_index;
  char gpu_name[48];
} HostMetricsSample;

/* Bounded parser for the documented Vibeshine v1 hardware-metrics schema.
 * Unknown and null fields are ignored; malformed responses are discarded. */
bool host_metrics_parse_json(const char *json, size_t length, HostMetricsSample *result);
#endif
