/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "telemetry.h"
#include "decode.h"
#include "frametime.h"
#include <dlfcn.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <inttypes.h>
#include <math.h>
#include <netdb.h>
#include <netinet/ip_icmp.h>
#include <netinet/icmp6.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

/* Session metadata is configured before the monitor starts. The two common-c
 * callback threads each publish their own lock-free u32 counters on ARM32. */
static DECODER_RENDERER_CALLBACKS original_video, wrapped_video;
static AUDIO_RENDERER_CALLBACKS original_audio, wrapped_audio;
static struct {
  uint32_t video_bytes, audio_bytes, missing, gaps;
  uint32_t last_frame;
  bool seen_frame;
  bool video_counting, audio_counting, record_frame_timing;
  int format, width, height, fps, channels, sample_rate;
  char host[256];
  unsigned short https_port;
  struct sockaddr_storage peer;
  socklen_t peer_len;
} session;
static bool same_address(const struct sockaddr *a, const struct sockaddr *b);
static OsdFtCapture frame_capture;

static bool monotonic_us32(uint32_t *out) {
  struct timespec ts;
  if (!out || clock_gettime(CLOCK_MONOTONIC, &ts)) return false;
  *out = (uint32_t)((uint64_t)ts.tv_sec * 1000000u + ts.tv_nsec / 1000);
  return true;
}

void osd_telemetry_frametime(OsdFtView *out) {
  uint32_t now = 0;
  if (!out) return;
  if (!session.record_frame_timing || !monotonic_us32(&now)) {
    memset(out, 0, sizeof(*out));
    return;
  }
  osd_ft_snapshot(&frame_capture, now, session.fps, out);
}

void osd_frame_gap(uint32_t frame, bool *seen, uint32_t *last,
                    uint32_t *missing, uint32_t *gaps) {
  const uint32_t delta = frame - *last;
  /* Serial arithmetic: duplicates and old frames cannot create huge losses.
   * Start each connection with a new baseline; u32 rollover is ordinary. */
  if (!*seen || (delta && delta < UINT32_MAX / 2)) {
    if (*seen && delta > 1) { *missing += delta - 1; ++*gaps; }
    *last = frame;
    *seen = true;
  }
}

static int video_setup(int format, int w, int h, int fps, void *ctx, int flags) {
  int result = original_video.setup ? original_video.setup(format,w,h,fps,ctx,flags) : 0;
  if (!result) { session.format=format; session.width=w; session.height=h; session.fps=fps; }
  return result;
}
static int video_submit(PDECODE_UNIT du) {
  /* Never dereference a malformed callback argument before the AML decoder's
   * own guard. A null decode unit requires a fresh IDR, not a process crash. */
  if (!du) return DR_NEED_IDR;
  uint32_t missing=__atomic_load_n(&session.missing,__ATOMIC_RELAXED);
  uint32_t gaps=__atomic_load_n(&session.gaps,__ATOMIC_RELAXED);
  osd_frame_gap((uint32_t)du->frameNumber, &session.seen_frame,
                &session.last_frame, &missing, &gaps);
  __atomic_store_n(&session.missing,missing,__ATOMIC_RELAXED);
  __atomic_store_n(&session.gaps,gaps,__ATOMIC_RELAXED);
  if (du->fullLength > 0)
    __atomic_fetch_add(&session.video_bytes,(uint32_t)du->fullLength,__ATOMIC_RELAXED);
  uint32_t start_us = 0, end_us = 0;
  const bool timed = session.record_frame_timing && monotonic_us32(&start_us);
  const int result = original_video.submitDecodeUnit(du);
  if (timed && monotonic_us32(&end_us))
    osd_ft_record_frame(&frame_capture, start_us, end_us,
                        (uint32_t)du->frameNumber);
  return result;
}
static int audio_init(int config, const POPUS_MULTISTREAM_CONFIGURATION opus,
                       void *ctx, int flags) {
  /* Save negotiated parameters before the backend adjusts its channel map. */
  int channels=opus->channelCount, rate=opus->sampleRate;
  int result=original_audio.init ? original_audio.init(config,opus,ctx,flags) : 0;
  if (!result) { session.channels=channels; session.sample_rate=rate; }
  return result;
}
static void audio_sample(char *data, int length) {
  if (length > 0) __atomic_fetch_add(&session.audio_bytes,(uint32_t)length,__ATOMIC_RELAXED);
  original_audio.decodeAndPlaySample(data,length);
}

void osd_telemetry_prepare(const char *host, unsigned short https_port,
                           PDECODER_RENDERER_CALLBACKS *video,
                           PAUDIO_RENDERER_CALLBACKS *audio, bool record_frame_timing) {
  memset(&session,0,sizeof(session));
  if (host && strlen(host)<sizeof(session.host)) {
    memcpy(session.host,host,strlen(host)+1);
    session.https_port=https_port;
  }
  session.record_frame_timing = record_frame_timing;
  /* Prepare is called before the connection begins and any video callback
   * exists. Never reset a live shared capture ring. */
  osd_ft_reset(&frame_capture);
  if (video && *video) {
    original_video=wrapped_video=**video;
    wrapped_video.setup=video_setup;
    /* A pull renderer must never acquire a submit callback. */
    if (original_video.submitDecodeUnit) {
      wrapped_video.submitDecodeUnit=video_submit; session.video_counting=true;
    }
    *video=&wrapped_video;
  }
  if (audio && *audio) {
    original_audio=wrapped_audio=**audio;
    wrapped_audio.init=audio_init;
    if (original_audio.decodeAndPlaySample) {
      wrapped_audio.decodeAndPlaySample=audio_sample; session.audio_counting=true;
    }
    *audio=&wrapped_audio;
  }
  /* The host name can resolve to several IPv4/IPv6 peers. Do not use a
   * DNS guess for RTT, NIC or route metrics: common-c chooses the actual
   * address later during connection establishment. */
  session.peer_len = 0;
}

bool osd_parse_gpu_percent(const char *text, float *out) {
  uint32_t n;
  if (!out || !osd_parse_sysfs_counter(text,&n) || n>100) return false;
  *out=(float)n;
  return true;
}
bool osd_byte_rate(uint64_t now, uint64_t before, uint64_t bytes,
                   uint64_t prior_bytes, double *mbps) {
  if (!mbps || now<=before || now-before<100 || now-before>61000 || bytes<prior_bytes)
    return false;
  *mbps=(double)(bytes-prior_bytes)*0.008/(double)(now-before);
  return true;
}
static bool read_text(const char *path, char *out, size_t size) {
  int fd=open(path,O_RDONLY|O_CLOEXEC|O_NONBLOCK|O_NOFOLLOW);
  if (fd<0 || size<2) { if (fd>=0) close(fd); return false; }
  struct stat st;
  if (fstat(fd,&st) || !S_ISREG(st.st_mode)) {close(fd);return false;}
  ssize_t n=read(fd,out,size-1);
  close(fd);
  if (n<=0) return false;
  out[n]=0;
  if ((size_t)n==size-1 && !strchr(out,'\n')) return false;
  out[strcspn(out,"\r\n")]=0;
  /* sysfs mode and optional note must not inject renderer/log controls. */
  for (char *p=out;*p;p++) if ((unsigned char)*p<32 || (unsigned char)*p>126) *p='?';
  return true;
}
static bool read_counter(const char *path, uint64_t *out) {
  char text[64], *end;
  if (!read_text(path,text,sizeof(text)) || !isdigit((unsigned char)text[0])) return false;
  errno=0;
  unsigned long long n=strtoull(text,&end,10);
  while (isspace((unsigned char)*end)) ++end;
  if (errno || *end) return false;
  *out=n;
  return true;
}
static bool same_address(const struct sockaddr *a, const struct sockaddr *b) {
  if (a->sa_family!=b->sa_family) return false;
  if (a->sa_family==AF_INET)
    return ((const struct sockaddr_in *)a)->sin_addr.s_addr==
           ((const struct sockaddr_in *)b)->sin_addr.s_addr;
  if (a->sa_family==AF_INET6)
    return !memcmp(&((const struct sockaddr_in6 *)a)->sin6_addr,
                   &((const struct sockaddr_in6 *)b)->sin6_addr,sizeof(struct in6_addr)) &&
           ((const struct sockaddr_in6 *)a)->sin6_scope_id==
           ((const struct sockaddr_in6 *)b)->sin6_scope_id;
  return false;
}
static bool network_interface(char *name, size_t size) {
  if (!session.peer_len) return false;
  int fd=socket(session.peer.ss_family,SOCK_DGRAM|SOCK_CLOEXEC,0);
  if (fd<0) return false;
  struct sockaddr_storage local;
  socklen_t n=sizeof(local);
  bool ok=connect(fd,(struct sockaddr *)&session.peer,session.peer_len)==0 &&
          getsockname(fd,(struct sockaddr *)&local,&n)==0;
  close(fd);
  struct ifaddrs *list=NULL;
  if (!ok || getifaddrs(&list)) return false;
  ok=false;
  for (struct ifaddrs *p=list;p;p=p->ifa_next) {
    if (p->ifa_addr && same_address(p->ifa_addr,(struct sockaddr *)&local) &&
        strlen(p->ifa_name)<size && !strchr(p->ifa_name,'/')) {
      strcpy(name,p->ifa_name); ok=true; break;
    }
  }
  freeifaddrs(list);
  return ok;
}
static bool nic_counter(const char *name, const char *metric, uint64_t *out) {
  char path[192];
  snprintf(path,sizeof(path),"/sys/class/net/%s/statistics/%s",name,metric);
  return read_counter(path,out);
}

void osd_telemetry_open(OsdTelemetry *t, bool aml_stats) {
  memset(t,0,sizeof(*t));
  t->ping_fd=-1;
  t->decoder_fd=-1;
  /* Called only after LiStartConnection succeeds: this address is the one
   * selected by common-c, not an arbitrary DNS answer. If the optional
   * private API is absent, RTT and interface statistics stay unavailable. */
  typedef bool (*SelectedPeer)(struct sockaddr_storage *, uint32_t);
  SelectedPeer selected =
      (SelectedPeer)dlsym(RTLD_DEFAULT, "LiGetLunaConnectedPeerV1");
  struct sockaddr_storage peer = {0};
  if (selected && selected(&peer, (uint32_t)sizeof(peer)) &&
      (peer.ss_family == AF_INET || peer.ss_family == AF_INET6)) {
    session.peer = peer;
    session.peer_len = peer.ss_family == AF_INET ?
        sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6);
  }
  typedef int (*DecoderFd)(void);
  DecoderFd decoder=(DecoderFd)dlsym(RTLD_DEFAULT,"aml_osd_decoder_fd");
  if (aml_stats && decoder) t->decoder_fd=decoder();
  /* Optional telemetry is entirely separate from ICMP and video callbacks. */
  const char *opt=getenv("MOONLIGHT_HOST_METRICS");
  if (!opt || strcmp(opt,"0")!=0)
    host_metrics_open(&t->host,session.host,session.https_port);
  if (!session.peer_len) return;
  int family=session.peer.ss_family;
  t->ping_fd=socket(family,SOCK_DGRAM|SOCK_NONBLOCK|SOCK_CLOEXEC,
                    family==AF_INET ? IPPROTO_ICMP : IPPROTO_ICMPV6);
  if (t->ping_fd<0) return;
  int timestamp=1;
  if (setsockopt(t->ping_fd,SOL_SOCKET,SO_TIMESTAMPNS,&timestamp,sizeof(timestamp))) {
    close(t->ping_fd); t->ping_fd=-1; return;
  }
  /* Use a separate ICMP copy; the selected streaming peer above is
   * intentionally preserved for network-interface matching. */
  struct sockaddr_storage icmp_peer=session.peer;
  if (family==AF_INET) ((struct sockaddr_in *)&icmp_peer)->sin_port=0;
  else ((struct sockaddr_in6 *)&icmp_peer)->sin6_port=0;
  if (connect(t->ping_fd,(struct sockaddr *)&icmp_peer,session.peer_len)) {
    close(t->ping_fd); t->ping_fd=-1;
  }
}
void osd_telemetry_close(OsdTelemetry *t) {
  host_metrics_close(&t->host);
  if (t->ping_fd>=0) close(t->ping_fd);
  if (t->decoder_fd>=0) close(t->decoder_fd);
  t->ping_fd=-1;
  t->decoder_fd=-1;
}
static uint16_t checksum(const unsigned char *p, size_t n) {
  uint32_t sum=0;
  for (size_t i=0;i+1<n;i+=2) sum+=((uint16_t)p[i]<<8)|p[i+1];
  if (n&1) sum+=(uint16_t)p[n-1]<<8;
  while (sum>>16) sum=(sum&0xffff)+(sum>>16);
  return (uint16_t)~sum;
}
void osd_telemetry_poll(OsdTelemetry *t, uint64_t now) {
  if (t->ping_fd<0) return;
  unsigned char reply[256];
  /* Bound work even with unsolicited traffic; connected socket filters peer. */
  for (int i=0;i<4;i++) {
    struct iovec iov={.iov_base=reply,.iov_len=sizeof(reply)};
    union { struct cmsghdr align; unsigned char bytes[CMSG_SPACE(sizeof(struct timespec))]; } control;
    struct msghdr msg={.msg_iov=&iov,.msg_iovlen=1,
                      .msg_control=control.bytes,.msg_controllen=sizeof(control.bytes)};
    ssize_t n=recvmsg(t->ping_fd,&msg,MSG_DONTWAIT);
    if (n<0) break;
    uint64_t received_ns=0;
    for (struct cmsghdr *c=CMSG_FIRSTHDR(&msg);c;c=CMSG_NXTHDR(&msg,c)) {
      if (c->cmsg_level==SOL_SOCKET && c->cmsg_type==SCM_TIMESTAMPNS &&
          c->cmsg_len>=CMSG_LEN(sizeof(struct timespec))) {
        struct timespec stamp; memcpy(&stamp,CMSG_DATA(c),sizeof(stamp));
        received_ns=(uint64_t)stamp.tv_sec*1000000000u+stamp.tv_nsec;
      }
    }
    unsigned type=session.peer.ss_family==AF_INET ? ICMP_ECHOREPLY : ICMP6_ECHO_REPLY;
    if (t->ping_pending && n==16 && reply[0]==type && reply[1]==0 &&
        reply[6]==(t->ping_sequence>>8) && reply[7]==(t->ping_sequence&255) &&
        !memcmp(reply+8,"LUNAOSD1",8) && now>=t->ping_sent_ms &&
        received_ns>=t->ping_sent_realtime_ns && !(msg.msg_flags&(MSG_TRUNC|MSG_CTRUNC))) {
      /* Kernel receive timestamp excludes the monitor's 100ms polling delay. */
      double elapsed=(received_ns-t->ping_sent_realtime_ns)/1000000.0;
      if (elapsed<=1000) {
        t->ping_jitter_ms=t->ping_valid ? .7*t->ping_jitter_ms+.3*fabs(elapsed-t->ping_ms) : 0;
        t->ping_ms=t->ping_valid ? .7*t->ping_ms+.3*elapsed : elapsed;
        t->ping_valid=true; t->ping_received_ms=now;
      }
      t->ping_pending=false;
    }
  }
  if (t->ping_pending && now-t->ping_sent_ms>=1000) {
    t->ping_pending=false; t->ping_valid=false;
  }
  if (now>=t->ping_next_ms && !t->ping_pending) {
    unsigned char request[16]={0};
    request[0]=session.peer.ss_family==AF_INET ? ICMP_ECHO : ICMP6_ECHO_REQUEST;
    ++t->ping_sequence;
    request[6]=t->ping_sequence>>8; request[7]=t->ping_sequence&255;
    memcpy(request+8,"LUNAOSD1",8);
    uint16_t sum=checksum(request,sizeof(request));
    if (session.peer.ss_family==AF_INET) {request[2]=sum>>8;request[3]=sum&255;}
    struct timespec sent;
    if (clock_gettime(CLOCK_REALTIME,&sent)) return;
    t->ping_sent_realtime_ns=(uint64_t)sent.tv_sec*1000000000u+sent.tv_nsec;
    t->ping_pending=send(t->ping_fd,request,sizeof(request),MSG_DONTWAIT)==sizeof(request);
    if (!t->ping_pending) t->ping_valid=false;
    t->ping_sent_ms=now; t->ping_next_ms=now+2000;
  }
}

void osd_telemetry_format(OsdTelemetry *t, uint64_t now, const OsdSnapshot *s,
                          char *first, size_t fn, char *second, size_t sn) {
  char base1[512],base2[768];
  osd_format(s,base1,sizeof(base1),base2,sizeof(base2));
  /* CPU/temperature are prominent above; keep the legacy diagnostics format
   * unchanged without duplicating those values in the visual panel. */
  char *system=strstr(base2," | SysCPU ");
  if (system) *system=0;
  const char *codec="n/a";
  if (session.format&VIDEO_FORMAT_MASK_H264) codec="H.264";
  else if (session.format&VIDEO_FORMAT_MASK_H265) codec="HEVC";
  else if (session.format&VIDEO_FORMAT_MASK_AV1) codec="AV1";
  char hdmi[64]="n/a", note[120]="", value[64];
  read_text("/sys/class/display/mode",hdmi,sizeof(hdmi));
  read_text("/tmp/moonlight-osd-note",note,sizeof(note));
  char gpu[24]="n/a", cpu[24]="n/a", temp[48]="n/a";
  float percent;
  /* Amlogic r12p0 mpgpu publishes the last DVFS percentage, not a 0..256
   * scaling-governor input. Do not guess units for other GPU nodes. */
  if (read_text("/sys/class/mpgpu/utilization",value,sizeof(value)) &&
      osd_parse_gpu_percent(value,&percent)) snprintf(gpu,sizeof(gpu),"%.0f%%",percent);
  if (s->has_sys_cpu) snprintf(cpu,sizeof(cpu),"%.0f%%",s->sys_cpu_percent);
  for (unsigned i=0;i<5;i++) {
    char path[96]; float c;
    snprintf(path,sizeof(path),"/sys/class/thermal/thermal_zone%u/temp",i);
    if (read_text(path,value,sizeof(value)) && osd_parse_thermal_millidegrees(value,&c)) {
      snprintf(temp,sizeof(temp),"%.1fC (zone%u)",c,i); break;
    }
  }
  uint32_t video=__atomic_load_n(&session.video_bytes,__ATOMIC_RELAXED);
  uint32_t audio=__atomic_load_n(&session.audio_bytes,__ATOMIC_RELAXED);
  char bitrate[32]="n/a", audio_rate[32]="n/a";
  double rate;
  if (session.video_counting && t->initialized && osd_byte_rate(now,t->last_ms,(uint32_t)(video-t->video_bytes),0,&rate))
    snprintf(bitrate,sizeof(bitrate),"%.2f Mbps",rate);
  if (session.audio_counting && t->initialized && osd_byte_rate(now,t->last_ms,(uint32_t)(audio-t->audio_bytes),0,&rate))
    snprintf(audio_rate,sizeof(audio_rate),"%.0f kbps",rate*1000);
  char nic[64]="n/a", net[40]="n/a", errors[80]="n/a";
  uint64_t bytes,err,drop;
  if (network_interface(nic,sizeof(nic)) && nic_counter(nic,"rx_bytes",&bytes) &&
      nic_counter(nic,"rx_errors",&err) && nic_counter(nic,"rx_dropped",&drop)) {
    if (t->nic_initialized && !strcmp(nic,t->interface) &&
        err>=t->rx_errors && drop>=t->rx_drops &&
        osd_byte_rate(now,t->last_ms,bytes,t->rx_bytes,&rate)) {
      snprintf(net,sizeof(net),"%.2f Mbps",rate);
      snprintf(errors,sizeof(errors),"+%"PRIu64" err / +%"PRIu64" drop",err-t->rx_errors,drop-t->rx_drops);
    }
    strcpy(t->interface,nic); t->rx_bytes=bytes;t->rx_errors=err;t->rx_drops=drop;
    t->nic_initialized=true;
  } else t->nic_initialized=false;
  char queue[48]="n/a", pool[64]="n/a";
  if (s->has_kernel_queue && session.fps>0)
    snprintf(queue,sizeof(queue),"%u fr (~%.0fms)",s->kernel_queue,1000.0*s->kernel_queue/session.fps);
  FILE *f=fopen("/sys/class/video/vframe_states","r");
  if (f) {
    char buf[2048]={0}; uint32_t total,free_frames;
    size_t n=fread(buf,1,sizeof(buf)-1,f); fclose(f);
    if (n && osd_parse_stat_value(buf,"vframe_pool_size",&total) &&
        osd_parse_stat_value(buf,"vframe buf_free_num",&free_frames) && free_frames<=total) {
      uint32_t used=total-free_frames;
      if (total!=t->pool_size) t->pool_peak=0;
      if (used>t->pool_peak) t->pool_peak=used;
      t->pool_size=total;
      snprintf(pool,sizeof(pool),"%u/%u (peak %u)",used,total,t->pool_peak);
    }
  }
  char lost[80]="n/a", ping[64]="n/a", stream[240]="Stream n/a", audio_info[80]="n/a";
  if (session.channels>0 && session.sample_rate>0)
    snprintf(audio_info,sizeof(audio_info),"%dch %dHz %s",session.channels,session.sample_rate,audio_rate);
  if (session.fps>0) {
    uint32_t missing=__atomic_load_n(&session.missing,__ATOMIC_RELAXED);
    uint32_t gaps=__atomic_load_n(&session.gaps,__ATOMIC_RELAXED);
    if (session.video_counting)
      snprintf(lost,sizeof(lost),"%u fr (~%.2fs) / %u gaps",missing,(double)missing/session.fps,gaps);
    snprintf(stream,sizeof(stream),"%s %dx%d @ %dfps | HDMI %s | Audio %s",
             codec,session.width,session.height,session.fps,hdmi,audio_info);
  }
  typedef unsigned int (*AdaptiveWaiting)(void);
  AdaptiveWaiting target = (AdaptiveWaiting)dlsym(RTLD_DEFAULT, "aml_adaptive_waiting");
  const unsigned int waiting = target ? target() : 0;
  if (waiting >= 1 && waiting <= 3) {
    const size_t used = strlen(stream);
    if (used + 18 < sizeof(stream))
      snprintf(stream + used, sizeof(stream) - used, " | Adaptive %u/3", waiting);
  }
  if (t->ping_valid && now>=t->ping_received_ms && now-t->ping_received_ms<5000)
    snprintf(ping,sizeof(ping),"%.1f +/- %.1fms",t->ping_ms,t->ping_jitter_ms);
  char decode[64]="n/a"; double decode_ms;
  if (session.fps>0 && osd_decode_sample(t->decoder_fd,session.width,session.height,&decode_ms))
    snprintf(decode,sizeof(decode),"%.2fms (%.0f%% budget)",decode_ms,decode_ms*session.fps/10.0);
  char host_line[192];
  host_metrics_format(&t->host,host_line,sizeof(host_line));
  snprintf(first,fn,"%s\nClient CPU %s | GPU %s | Temp %s\n%s\nVideo %s | NIC RX %s (%s) | NetErr %s\n"
           "Lost %s | Queue %s | Pool %s | Ping %s | Decode %s",
           stream,cpu,gpu,temp,host_line,bitrate,net,nic,errors,lost,queue,pool,ping,decode);
  snprintf(second,sn,"%s\n%s%s%s",base1,base2,*note ? "\nNote: " : "",note);
  t->video_bytes=video;t->audio_bytes=audio;t->last_ms=now;t->initialized=true;
}
