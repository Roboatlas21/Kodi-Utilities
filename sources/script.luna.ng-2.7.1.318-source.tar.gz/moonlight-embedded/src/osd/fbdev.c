/* SPDX-License-Identifier: GPL-3.0-or-later
 * CoreELEC NG's Mali fbdev window, also used by Kodi's Amlogic window system.
 * EGL owns allocation/panning: never mmap presumed linear pixels into AFBC
 * storage, change HDMI modes/scalers, or borrow the fb1 cursor plane.
 */
#define _GNU_SOURCE
#include "fbdev.h"
#include "font.h"
#include "layout.h"
#include <EGL/egl.h>
#include <EGL/fbdev_window.h>
#include <GLES2/gl2.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <unistd.h>

/* Resolve lazily so headless diagnostics and OSD-off playback do not depend
 * on a Mali driver. These libraries are supplied by CoreELEC, never bundled. */
#define EGL_FUNCTIONS(X) \
  X(eglGetDisplay) X(eglInitialize) X(eglBindAPI) X(eglChooseConfig) \
  X(eglCreateContext) X(eglCreateWindowSurface) X(eglMakeCurrent) \
  X(eglQuerySurface) X(eglSwapInterval) X(eglSwapBuffers) X(eglGetError) \
  X(eglDestroySurface) X(eglDestroyContext) X(eglTerminate) X(eglReleaseThread)
#define GL_FUNCTIONS(X) \
  X(glCreateShader) X(glShaderSource) X(glCompileShader) X(glGetShaderiv) \
  X(glDeleteShader) X(glCreateProgram) X(glAttachShader) X(glBindAttribLocation) \
  X(glLinkProgram) X(glGetProgramiv) X(glDeleteProgram) X(glUseProgram) \
  X(glGenTextures) X(glDeleteTextures) X(glBindTexture) X(glTexParameteri) \
  X(glTexImage2D) X(glViewport) X(glClearColor) X(glClear) \
  X(glVertexAttribPointer) X(glEnableVertexAttribArray) X(glDrawArrays) X(glGetError)

struct OsdFbdev {
  int fd;
  void *egl_lib, *gl_lib;
#define DECLARE(name) __typeof__(&name) name;
  EGL_FUNCTIONS(DECLARE)
  GL_FUNCTIONS(DECLARE)
#undef DECLARE
  EGLDisplay display;
  EGLContext context;
  EGLSurface surface;
  fbdev_window window;
  bool initialized, current, touched;
  GLuint program, texture;
  int width, height, x, y, scale;
  unsigned max_rows;
  int graph_height;
  uint32_t *pixels;
};

static bool load_api(OsdFbdev *s) {
  /* Absolute system paths prevent an add-on's LD_LIBRARY_PATH from selecting
   * a different Mali variant than the OS uses for Kodi. */
  s->egl_lib = dlopen("/usr/lib/libEGL.so.1", RTLD_NOW | RTLD_LOCAL);
  s->gl_lib = dlopen("/usr/lib/libGLESv2.so.2", RTLD_NOW | RTLD_LOCAL);
  if (!s->egl_lib || !s->gl_lib) {
    const char *error = dlerror();
    fprintf(stderr, "OSD: CoreELEC Mali EGL/GLES libraries unavailable: %s\n",
            error ? error : "library load failed");
    return false;
  }
#define LOAD(lib, name) do { \
    void *symbol = dlsym(s->lib, #name); \
    if (!symbol) { fprintf(stderr, "OSD: missing graphics symbol %s\n", #name); return false; } \
    _Static_assert(sizeof(s->name) == sizeof(symbol), "POSIX function pointer size"); \
    memcpy(&s->name, &symbol, sizeof(symbol)); \
  } while (0);
#define LOAD_EGL(name) LOAD(egl_lib, name)
#define LOAD_GL(name) LOAD(gl_lib, name)
  EGL_FUNCTIONS(LOAD_EGL)
  GL_FUNCTIONS(LOAD_GL)
#undef LOAD_EGL
#undef LOAD_GL
#undef LOAD
  return true;
}

static bool blank(OsdFbdev *s, bool hide) {
  if (ioctl(s->fd, FBIOBLANK, hide ? FB_BLANK_POWERDOWN : FB_BLANK_UNBLANK) == 0)
    return true;
  fprintf(stderr, "OSD: fb0 %s failed: %s\n", hide ? "blank" : "unblank", strerror(errno));
  return false;
}

static GLuint shader(OsdFbdev *s, GLenum type, const char *source) {
  GLuint id = s->glCreateShader(type);
  if (!id) return 0;
  s->glShaderSource(id, 1, &source, NULL);
  s->glCompileShader(id);
  GLint ok = 0;
  s->glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
  if (!ok) { s->glDeleteShader(id); return 0; }
  return id;
}

static bool create_panel(OsdFbdev *s) {
  const char *vertex = "attribute vec2 position; attribute vec2 uv; varying vec2 tex;"
                       "void main(){tex=uv;gl_Position=vec4(position,0.0,1.0);}";
  const char *fragment = "precision mediump float; varying vec2 tex; uniform sampler2D panel;"
                         "void main(){gl_FragColor=texture2D(panel,tex);}";
  GLuint vs = shader(s, GL_VERTEX_SHADER, vertex);
  GLuint fs = shader(s, GL_FRAGMENT_SHADER, fragment);
  if (vs && fs) {
    s->program = s->glCreateProgram();
    s->glAttachShader(s->program, vs);
    s->glAttachShader(s->program, fs);
    s->glBindAttribLocation(s->program, 0, "position");
    s->glBindAttribLocation(s->program, 1, "uv");
    s->glLinkProgram(s->program);
  }
  if (vs) s->glDeleteShader(vs);
  if (fs) s->glDeleteShader(fs);
  GLint ok = 0;
  if (s->program) s->glGetProgramiv(s->program, GL_LINK_STATUS, &ok);
  if (!ok) return false;
  s->glUseProgram(s->program);
  s->glGenTextures(1, &s->texture);
  s->glBindTexture(GL_TEXTURE_2D, s->texture);
  s->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  s->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  s->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  s->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  return s->texture && s->glGetError() == GL_NO_ERROR;
}

void osd_fbdev_close(OsdFbdev *s) {
  if (!s) return;
  /* Hide before releasing buffers and again afterward: Mali may pan/enable
   * fb0 during surface destruction. Luna's display recovery and fresh Kodi
   * context handle the final unblank, including after a killed native child. */
  if (s->touched) blank(s, true);
  if (s->current) {
    if (s->texture) s->glDeleteTextures(1, &s->texture);
    if (s->program) s->glDeleteProgram(s->program);
    s->eglMakeCurrent(s->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
  }
  if (s->surface != EGL_NO_SURFACE) s->eglDestroySurface(s->display, s->surface);
  if (s->context != EGL_NO_CONTEXT) s->eglDestroyContext(s->display, s->context);
  if (s->initialized) s->eglTerminate(s->display);
  if (s->eglReleaseThread) s->eglReleaseThread();
  if (s->touched) blank(s, true);
  if (s->fd >= 0) close(s->fd);
  if (s->gl_lib) dlclose(s->gl_lib);
  if (s->egl_lib) dlclose(s->egl_lib);
  free(s->pixels);
  free(s);
}

OsdFbdev *osd_fbdev_open(const OsdOptions *opt) {
  const char *handoff = getenv("MOONLIGHT_OSD_TAKEOVER");
  const char *fb = getenv("FRAMEBUFFER");
  /* A fbdev-native window is not a GBM/X11 window. Do not pass it to an
   * unrelated graphics stack or touch Kodi's live graphics plane. */
  if (!handoff || strcmp(handoff, "1")) {
    fprintf(stderr, "OSD: framebuffer requires Luna's stopped-Kodi handoff\n");
    return NULL;
  }
  if (access("/dev/dri/card0", F_OK) == 0 || (fb && strcmp(fb, "/dev/fb0"))) {
    fprintf(stderr, "OSD: framebuffer fallback requires NG fb0 without a DRM card\n");
    return NULL;
  }
  OsdFbdev *s = calloc(1, sizeof(*s));
  if (!s) return NULL;
  s->fd = -1;
  s->display = EGL_NO_DISPLAY;
  s->context = EGL_NO_CONTEXT;
  s->surface = EGL_NO_SURFACE;
  const char *stage = "opening Amlogic fb0";
  s->fd = open("/dev/fb0", O_RDWR | O_CLOEXEC);
  struct fb_fix_screeninfo fix = {0};
  struct fb_var_screeninfo var = {0};
  if (s->fd < 0 || ioctl(s->fd, FBIOGET_FSCREENINFO, &fix) ||
      ioctl(s->fd, FBIOGET_VSCREENINFO, &var) ||
      strncmp(fix.id, "OSD FB", 6) || var.xres < 640 || var.xres > 8192 ||
      var.yres < 360 || var.yres > 8192) goto fail;
  s->window.width = var.xres;
  s->window.height = var.yres;
  s->scale = opt->font_size / 8;
  if (s->scale < 1) s->scale = 1;
  if (s->scale > 5) s->scale = 5;
  s->width = var.xres > 1140 ? 1100 : (int)var.xres - 30;
  s->max_rows = OSD_LAYOUT_MAX_ROWS;
  s->graph_height = opt->frametime ? 168 : 0;
  if (2 * s->scale * 9 + 16 + s->graph_height > (int)var.yres / 2)
    s->graph_height = 0;
  while (s->max_rows > 2 &&
         (s->max_rows * s->scale * 9 + 16 + s->graph_height) > (int)var.yres / 2)
    s->max_rows--;
  s->height = s->max_rows * s->scale * 9 + 16 + s->graph_height;
  s->x = opt->x < 0 ? (int)var.xres - s->width - 20 : opt->x;
  s->y = opt->y;
  stage = "validating panel geometry";
  if (s->x < 0 || s->y < 0 || s->x + s->width > (int)var.xres ||
      s->y + s->height > (int)var.yres) goto fail;
  s->pixels = calloc((size_t)s->width * s->height, 4);
  stage = "loading CoreELEC graphics libraries";
  if (!s->pixels || !load_api(s)) goto fail;
  stage = "initializing Mali EGL";
  s->display = s->eglGetDisplay(EGL_DEFAULT_DISPLAY);
  if (s->display == EGL_NO_DISPLAY || !s->eglInitialize(s->display, NULL, NULL)) goto fail;
  s->initialized = true;
  const EGLint attrs[] = {EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
    EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
    EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0, EGL_NONE};
  const EGLint context_attrs[] = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE};
  EGLConfig config;
  EGLint count = 0;
  stage = "choosing an alpha-capable EGL window";
  if (!s->eglBindAPI(EGL_OPENGL_ES_API) ||
      !s->eglChooseConfig(s->display, attrs, &config, 1, &count) || count < 1) goto fail;
  s->context = s->eglCreateContext(s->display, config, EGL_NO_CONTEXT, context_attrs);
  if (s->context == EGL_NO_CONTEXT) goto fail;
  /* From this point only this launcher owns fb0; keep it hidden until a
   * complete transparent frame has been swapped successfully. */
  s->touched = true;
  if (!blank(s, true)) goto fail;
  stage = "creating the Mali fbdev surface";
  s->surface = s->eglCreateWindowSurface(s->display, config, (EGLNativeWindowType)&s->window, NULL);
  if (s->surface == EGL_NO_SURFACE || !blank(s, true) ||
      !s->eglMakeCurrent(s->display, s->surface, s->surface, s->context)) goto fail;
  s->current = true;
  EGLint width = 0, height = 0;
  if (!s->eglQuerySurface(s->display, s->surface, EGL_WIDTH, &width) ||
      !s->eglQuerySurface(s->display, s->surface, EGL_HEIGHT, &height) ||
      width != s->window.width || height != s->window.height) goto fail;
  stage = "creating OSD graphics resources";
  if (!s->eglSwapInterval(s->display, 1) || !create_panel(s)) goto fail;
  fprintf(stderr, "OSD: Mali EGL framebuffer ready on fb0 (%ux%u, Kodi handoff)\n",
          s->window.width, s->window.height);
  return s;
fail:
  fprintf(stderr, "OSD: framebuffer initialization failed while %s (EGL 0x%x)\n",
          stage, s->eglGetError ? s->eglGetError() : 0);
  osd_fbdev_close(s);
  return NULL;
}

static void panel_text(OsdFbdev *s, const char *text, int x, int y) {
  for (const char *c = text; *c && x + 5*s->scale < s->width; c++, x += 6*s->scale) {
    const uint8_t *g = osd_glyph(*c);
    for (int row = 0; row < 7; row++) for (int col = 0; col < 5; col++) {
      if (!(g[row] & (1 << (4-col)))) continue;
      for (int yy = 0; yy < s->scale; yy++) for (int xx = 0; xx < s->scale; xx++) {
        const int px = x + col*s->scale + xx, py = y + row*s->scale + yy;
        if (px >= 0 && py >= 0 && px < s->width && py < s->height)
          s->pixels[(size_t)py*s->width + px] = 0xffffffffu;
      }
    }
  }
}
bool osd_fbdev_draw(OsdFbdev *s, const char *first, const char *second, const OsdFtView *graph) {
  OsdLayout layout;
  osd_layout_wrap(first, second, (s->width - 24) / (6 * s->scale), s->max_rows, &layout);
  memset(s->pixels, 0, (size_t)s->width * s->height * 4);
  unsigned char *bytes = (unsigned char *)s->pixels;
  const int text_end = (int)layout.rows * s->scale * 9 + 16;
  const bool show_graph = graph && s->graph_height && text_end + s->graph_height <= s->height;
  const int used_height = text_end + (show_graph ? s->graph_height : 0);
  for (int y = 0; y < used_height; y++)
    for (int x = 0; x < s->width; x++) bytes[((size_t)y * s->width + x) * 4 + 3] = 176;
  for (unsigned line = 0; line < layout.rows; line++)
    panel_text(s, layout.text[line], 12, 8 + (int)line*s->scale*9);
  if (show_graph) {
    char in[128], sub[128];
    osd_ft_caption(graph,in,sizeof(in),sub,sizeof(sub));
    panel_text(s,in,12,text_end+2);
    panel_text(s,sub,12,text_end+2+9*s->scale);
    if (graph->stale) panel_text(s,"FRAME INPUT STALLED",s->width/2,text_end+2);
    const int legend = 2*9*s->scale+6;
    osd_ft_plot(graph,s->pixels,(unsigned)s->width,(unsigned)s->width,
                (unsigned)s->height,12,text_end+legend,s->width-24,
                s->graph_height-legend);
  }
  /* GL's viewport origin is bottom-left; panel text has a top-left origin. */
  static const GLfloat quad[] = {-1,-1,0,1, 1,-1,1,1, -1,1,0,0, 1,1,1,0};
  s->glViewport(0, 0, s->window.width, s->window.height);
  s->glClearColor(0, 0, 0, 0);
  s->glClear(GL_COLOR_BUFFER_BIT);
  s->glViewport(s->x, s->window.height - s->y - s->height, s->width, s->height);
  s->glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, s->width, s->height, 0, GL_RGBA, GL_UNSIGNED_BYTE, s->pixels);
  s->glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), quad);
  s->glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), quad + 2);
  s->glEnableVertexAttribArray(0);
  s->glEnableVertexAttribArray(1);
  s->glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
  if (s->glGetError() != GL_NO_ERROR || !s->eglSwapBuffers(s->display, s->surface)) {
    fprintf(stderr, "OSD: framebuffer presentation failed (EGL 0x%x)\n", s->eglGetError());
    return false;
  }
  return blank(s, false);
}
