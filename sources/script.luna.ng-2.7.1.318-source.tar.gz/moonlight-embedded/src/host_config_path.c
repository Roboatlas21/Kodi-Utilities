/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "host_config_path.h"
#include <stdint.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *moonlight_host_config_path(const char *address) {
  if (!address || !*address) { errno = EINVAL; return NULL; }
  const size_t len = strlen(address);
  /* Keep the name ONE path component: no traversal, controls, whitespace or
   * URL delimiters. Permit DNS names and bracketed/scoped IPv4/IPv6. */
  if (len > 255 || !strcmp(address, ".") || !strcmp(address, "..")) {
    errno = EINVAL;
    return NULL;
  }
  for (size_t i = 0; i < len; ++i) {
    const unsigned char c = (unsigned char)address[i];
    if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
          (c >= '0' && c <= '9') || c == '.' || c == '-' ||
          c == '_' || c == ':' || c == '%' || c == '[' || c == ']')) {
      errno = EINVAL;
      return NULL;
    }
  }
  const size_t extra = sizeof("hosts/") + sizeof(".conf");
  if (len > SIZE_MAX - extra) { errno = ENAMETOOLONG; return NULL; }
  char *path = malloc(len + extra);
  if (!path) return NULL;
  snprintf(path, len + extra, "hosts/%s.conf", address);
  return path;
}
