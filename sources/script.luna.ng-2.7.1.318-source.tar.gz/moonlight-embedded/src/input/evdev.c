/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "evdev.h"
#include "mapping_extended.h"
#include "handoff.h"
#include "stable_slots.h"
#include "remote_input.h"
#include "controller_count.h"
#include "mapping_capture.h"
#include "mapping_usable.h"
#include "selected_names.h"
#include "motion_math.h"
#include "dualsense.h"
#include "steam_controller_2026.h"
#include "udev.h"

#include "keyboard.h"
#ifdef HAVE_LIBCEC
#include "cec.h"
#endif

#include "../loop.h"

#include "libevdev/libevdev.h"
#include <Limelight.h>

#include <libudev.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include "mouse_deadzone.h"
#include "controller_count.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/input.h>
#include <fcntl.h>
#include <poll.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/eventfd.h>
#include <sys/timerfd.h>
#include <time.h>
#ifdef __linux__
#include <endian.h>
#else
#include <sys/endian.h>
#endif
#include <math.h>

#if __BYTE_ORDER == __LITTLE_ENDIAN
#define int16_to_le(val) val
#else
#define int16_to_le(val) ((((val) >> 8) & 0x00FF) | (((val) << 8) & 0xFF00))
#endif

struct input_abs_parms {
  int min, max;
  int flat;
  int avg;
  int range, diff;
};

struct input_device {
  struct libevdev *dev;
  bool is_keyboard;
  bool is_mouse;
  bool is_touchscreen;
  bool is_remote;
  bool is_gamepad;
  int rotate;
  struct mapping* map;
  int key_map[KEY_CNT];
  int abs_map[ABS_CNT];
  /* Linux defines ABS_HAT0..ABS_HAT3; the fourth hat is index 3. */
  int hats_state[4][2];
  int mapping_rest[ABS_CNT]; /* Snapshot before each mapping prompt. */
  int fd;
  char retry_path[64]; /* Exact eventN used to open this physical node. */
  unsigned long long retry_rdev;
  char retry_identity[ML_INPUT_IDENTITY_MAX]; /* Sysfs instance plus uniq/phys. */
  bool read_pending;
  bool syncing; /* SYN_DROPPED recovery must survive a bounded read callback. */
  bool pendingQuitOnModifiersUp; /* Never carry an exit request across devices. */
  unsigned char held_keys[(KEY_CNT + 7) / 8];
  bool held_mouse_buttons[5];
  char modifiers;
  #ifdef __linux__
  __s32 mouseDeltaX, mouseDeltaY, mouseVScroll, mouseHScroll;
  __s32 touchDownX, touchDownY, touchX, touchY;
  #else
  int32_t mouseDeltaX, mouseDeltaY, mouseVScroll, mouseHScroll;
  int32_t touchDownX, touchDownY, touchX, touchY;
  #endif
  struct timeval touchDownTime;
  struct timeval btnDownTime;
  short controllerId;
  int haptic_effect_id;
  /* Host callback ioctl/write can stall independently of the input loop.
   * References protect this device after hot-unplug; ff_mutex serializes its
   * force-feedback effects without holding the global devices_mutex. */
  pthread_mutex_t ff_mutex;
  pthread_cond_t ff_wake;
  unsigned ff_refs;
  bool ff_worker_started, ff_pending;
  unsigned short ff_low, ff_high;
  uint64_t ff_retry_after;
  int ff_worker_fd;
  bool ff_retired;
  bool ff_cleanup_done;
  bool wants_dualsense;
  int sony_vendor, sony_product;
  bool ds_led_pending, ds_adaptive_pending;
  bool ds_led_desired, ds_adaptive_desired;
  uint64_t ds_led_revision, ds_adaptive_revision;
  uint16_t ds_motion_rates[2]; /* Index 0 accel, 1 gyro. */
  uint8_t ds_led_color[3], ds_adaptive_flags;
  uint8_t ds_left_type, ds_right_type, ds_left[10], ds_right[10];
  moonlight_dualsense *dualsense;
  int buttonFlags;
  unsigned char leftTrigger, rightTrigger;
  short leftStickX, leftStickY;
  short rightStickX, rightStickY;
  bool gamepadModified;
  bool mouseEmulation;
  pthread_t meThread;
  unsigned mouse_refs;
  bool mouse_worker_started;
  struct input_abs_parms xParms, yParms, rxParms, ryParms, zParms, rzParms;
  struct input_abs_parms leftParms, rightParms, upParms, downParms;
};

#define HAT_UP 1
#define HAT_RIGHT 2
#define HAT_DOWN 4
#define HAT_LEFT 8
static const int hat_constants[3][3] = {{HAT_UP | HAT_LEFT, HAT_UP, HAT_UP | HAT_RIGHT}, {HAT_LEFT, 0, HAT_RIGHT}, {HAT_LEFT | HAT_DOWN, HAT_DOWN, HAT_DOWN | HAT_RIGHT}};

#define set_hat(flags, flag, hat, hat_flag) flags = (hat & hat_flag) == hat_flag ? flags | flag : flags & ~flag

#define TOUCH_UP -1
#define TOUCH_CLICK_RADIUS 10
#define TOUCH_CLICK_DELAY 100000 // microseconds
#define TOUCH_RCLICK_TIME 750 // milliseconds

// How long the Start button must be pressed to toggle mouse emulation
#define MOUSE_EMULATION_LONG_PRESS_TIME 750
// How long between polling the gamepad to send virtual mouse input
#define MOUSE_EMULATION_POLLING_INTERVAL 50000
// Determines how fast the mouse will move each interval
#define MOUSE_EMULATION_MOTION_MULTIPLIER 3
// Determines the maximum motion amount before allowing movement
#define MOUSE_EMULATION_DEADZONE 2

// Limited by number of bits in activeGamepadMask
#define MAX_GAMEPADS 16

static struct input_device **devices = NULL;
/* The common-c rumble callback runs on another thread. Protect lookup,
 * publication, force-feedback I/O and removal under one lifetime lock. */
static pthread_mutex_t devices_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t mouse_workers_drained = PTHREAD_COND_INITIALIZER;
static unsigned mouse_workers_active;
static int numDevices = 0;
static int assignedControllerIds = 0;
static uint16_t steam_reserved_mask;
static int dualsense_output_fd = -1;
static int dualsense_output_retry_fd = -1;
static unsigned dualsense_output_retry_ms = 10;
static uint64_t dualsense_output_due_ms;
static uint64_t evdev_now_ms(void) {
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  return (uint64_t)now.tv_sec * 1000 + now.tv_nsec / 1000000;
} /* Exponential cap: 250ms. */
static bool dualsense_output_online;
static bool gamepad_capacity_warned;

static short* currentKey;
static short* currentHat;
static short* currentHatDir;
static short* currentAbs;
static bool* currentReverse;
static char* currentHalfAxis;

static bool grabbingDevices;
static bool mouseEmulationEnabled;

int evdev_gamepads = 0;

#define ACTION_MODIFIERS (MODIFIER_SHIFT|MODIFIER_ALT|MODIFIER_CTRL)
#define QUIT_KEY KEY_Q
#define QUIT_BUTTONS (PLAY_FLAG|BACK_FLAG|LB_FLAG|RB_FLAG)

static bool (*handler) (struct input_event*, struct input_device*);
static void evdev_queue_ff_locked(struct input_device *, unsigned short, unsigned short);

static int evdev_get_map(int* map, int length, int value) {
  for (int i = 0; i < length; i++) {
    if (value == map[i])
      return i;
  }
  return -1;
}

static bool evdev_init_parms(struct input_device *dev, struct input_abs_parms *parms, int code) {
  *parms = (struct input_abs_parms){0};
  if (code < 0) return true; /* Optional unmapped axes are neutral. */
  int abs_code = evdev_get_map(dev->abs_map, ABS_MAX, code);
  if (abs_code < 0) return false;

  const int min = libevdev_get_abs_minimum(dev->dev, abs_code);
  const int max = libevdev_get_abs_maximum(dev->dev, abs_code);
  const int flat = libevdev_get_abs_flat(dev->dev, abs_code);
  const int64_t span = (int64_t)max - (int64_t)min;
  /* Both signed stick and unsigned trigger scaling require a positive
   * denominator. Reject impossible deadzones and overflowed ranges. */
  if (span <= 0 || span > INT_MAX || flat < 0 ||
      2LL * flat >= span)
    return false;
  parms->min = min;
  parms->max = max;
  parms->flat = flat;
  parms->avg = (int)(((int64_t)min + max) / 2);
  parms->range = max - parms->avg;
  parms->diff = (int)span;
  return true;
}

/* Explicit input= nodes and the selected-name udev startup sweep may refer
 * to the same event device. Compare the opened kernel node, not just its
 * eventN pathname (which can change across reconnects). */
static bool evdev_fd_already_registered(int fd) {
  struct stat candidate;
  if (fstat(fd, &candidate) < 0) return false;
  bool found = false;
  pthread_mutex_lock(&devices_mutex);
  for (int i = 0; i < numDevices; ++i) {
    struct stat existing;
    if (fstat(devices[i]->fd, &existing) == 0 &&
        existing.st_dev == candidate.st_dev &&
        existing.st_ino == candidate.st_ino &&
        existing.st_rdev == candidate.st_rdev) {
      found = true;
      break;
    }
  }
  pthread_mutex_unlock(&devices_mutex);
  return found;
}

/* Keyboard and mouse events are host-global, unlike controller slots.
 * Track each physical source's forwarded down events so an I/O failure can
 * release only that source's held inputs before retiring its descriptor. */
static int evdev_mouse_button_index(int button) {
  switch (button) {
  case BUTTON_LEFT: return 0;
  case BUTTON_MIDDLE: return 1;
  case BUTTON_RIGHT: return 2;
  case BUTTON_X1: return 3;
  case BUTTON_X2: return 4;
  default: return -1;
  }
}
static bool evdev_key_down(const struct input_device *dev, unsigned key) {
  return (dev->held_keys[key / 8] & (1u << (key % 8))) != 0;
}

static char evdev_modifiers(const struct input_device *dev) {
  return ((evdev_key_down(dev, KEY_LEFTSHIFT) || evdev_key_down(dev, KEY_RIGHTSHIFT)) ? MODIFIER_SHIFT : 0) |
         ((evdev_key_down(dev, KEY_LEFTCTRL) || evdev_key_down(dev, KEY_RIGHTCTRL)) ? MODIFIER_CTRL : 0) |
         ((evdev_key_down(dev, KEY_LEFTALT) || evdev_key_down(dev, KEY_RIGHTALT)) ? MODIFIER_ALT : 0) |
         ((evdev_key_down(dev, KEY_LEFTMETA) || evdev_key_down(dev, KEY_RIGHTMETA)) ? MODIFIER_META : 0);
}

/* Call with devices_mutex held. Keyboard state belongs to the host, not a slot. */
static char evdev_global_modifiers(void) {
  char modifiers = 0;
  for (int i = 0; i < numDevices; ++i)
    modifiers |= evdev_modifiers(devices[i]);
  return modifiers;
}

static bool cec_held_keys[256];
static bool host_key_held(unsigned code) {
  if (code < 256 && cec_held_keys[code]) return true;
  for (int i = 0; i < numDevices; ++i)
    for (unsigned key = 0; key < sizeof(keyCodes)/sizeof(keyCodes[0]); ++key)
      if ((unsigned)keyCodes[key] == code && evdev_key_down(devices[i], key)) return true;
  return false;
}
void evdev_cec_key(unsigned code, bool pressed) {
  if (!code || code >= 256) return;
  pthread_mutex_lock(&devices_mutex);
  const bool was_pressed = cec_held_keys[code];
  cec_held_keys[code] = pressed;
  if (pressed || (was_pressed && !host_key_held(code)))
    LiSendKeyboardEvent((short)(0x8000 | code), pressed ? KEY_ACTION_DOWN : KEY_ACTION_UP,
                        evdev_global_modifiers());
  pthread_mutex_unlock(&devices_mutex);
}

static void evdev_send_mouse_button(struct input_device *dev, int action, int button) {
  const int index = evdev_mouse_button_index(button);
  bool held = false;
  pthread_mutex_lock(&devices_mutex);
  if (index >= 0) {
    dev->held_mouse_buttons[index] = action == BUTTON_ACTION_PRESS;
    for (int i = 0; i < numDevices; ++i)
      held |= devices[i]->held_mouse_buttons[index];
  }
  pthread_mutex_unlock(&devices_mutex);
  if (action != BUTTON_ACTION_RELEASE || !held)
    LiSendMouseButtonEvent(action, button);
}

/* Only the last worker reference may reclaim a detached device. Both force
 * feedback and mouse-emulation callbacks can outlive evdev hot-unplug. */
static void evdev_free_retired_device(struct input_device *device) {
  pthread_cond_destroy(&device->ff_wake);
  pthread_mutex_destroy(&device->ff_mutex);
  free(device);
}

static void evdev_remove(int devindex) {
  pthread_mutex_lock(&devices_mutex);
  if (devindex < 0 || devindex >= numDevices) {
    pthread_mutex_unlock(&devices_mutex);
    return;
  }
  struct input_device *device = devices[devindex];
  const short controller_id = device->controllerId;
  const unsigned int previous_mask = (unsigned int)assignedControllerIds;
  unsigned char keys[(KEY_CNT + 7) / 8];
  bool mouse[5];
  memcpy(keys, device->held_keys, sizeof(keys));
  memcpy(mouse, device->held_mouse_buttons, sizeof(mouse));
  printf("Input device removed: %s (player %d)\n",
         libevdev_get_name(device->dev), controller_id + 1);
  if (controller_id >= 0 && controller_id < MAX_GAMEPADS) {
    assignedControllerIds &= ~(1 << controller_id);
    gamepad_capacity_warned = false;
  }
  if (device->is_gamepad && evdev_gamepads > 0)
    --evdev_gamepads;
  /* Only retire ownership under devices_mutex. A stalled HID/ALSA worker
   * must never hold the global lock while we join it. */
  /* Do not join a worker blocked inside Moonlight-common input delivery.
   * Its own reference keeps this device alive until the callback returns. */
  __atomic_store_n(&device->mouseEmulation, false, __ATOMIC_RELEASE);
  moonlight_dualsense *dualsense = device->dualsense;
  device->dualsense = NULL;
  libevdev_free(device->dev);
  loop_remove_fd(device->fd);
  close(device->fd);
  input_slots_remove(devices, &numDevices, devindex);
  __atomic_store_n(&device->ff_retired, true, __ATOMIC_RELEASE);
  pthread_cond_signal(&device->ff_wake);
  /* Retain the retired allocation while the cleanup thread can still
   * access it. A delayed FF callback may finish concurrently. */
  /* Keyboard/mouse buttons have host-global state. Another healthy input
   * may still hold the same button; never release it on their behalf. */
  for (int other = 0; other < numDevices; ++other) {
    for (unsigned int word = 0; word < sizeof(keys); ++word)
      keys[word] &= ~devices[other]->held_keys[word];
    for (unsigned int button = 0; button < sizeof(mouse) / sizeof(mouse[0]); ++button)
      if (devices[other]->held_mouse_buttons[button])
        mouse[button] = false;
  }
  const char remaining_modifiers = evdev_global_modifiers();
  const unsigned int remaining_mask = (unsigned int)assignedControllerIds;
  if (controller_id >= 0) {
    /* Neutralize held state while still advertised, then update the mask.
     * Do not send a zero-mask event for some other attached controller. */
    LiSendMultiControllerEvent(controller_id, previous_mask, 0, 0, 0, 0, 0, 0, 0);
    LiSendMultiControllerEvent(controller_id, remaining_mask, 0, 0, 0, 0, 0, 0, 0);
  }
  for (unsigned int key = 0; key < KEY_CNT; ++key) {
    if (keys[key / 8] & (1u << (key % 8)) &&
        key < sizeof(keyCodes) / sizeof(keyCodes[0])) {
      const short code = 0x80 << 8 | keyCodes[key];
      if (!host_key_held(keyCodes[key]))
        LiSendKeyboardEvent(code, KEY_ACTION_UP, remaining_modifiers);
    }
  }
  pthread_mutex_unlock(&devices_mutex);
  dualsense_detach(dualsense);
  /* Joins and controller feedback run outside the device lifetime lock.
   * Keyboard queue submission above is serialized with CEC ownership. */
  const int buttons[] = {BUTTON_LEFT, BUTTON_MIDDLE, BUTTON_RIGHT,
                         BUTTON_X1, BUTTON_X2};
  for (unsigned int button = 0; button < sizeof(buttons) / sizeof(buttons[0]); ++button)
    if (mouse[button])
      LiSendMouseButtonEvent(BUTTON_ACTION_RELEASE, buttons[button]);

  pthread_mutex_lock(&devices_mutex);
  device->ff_cleanup_done = true;
  const bool free_now = device->ff_refs == 0 && device->mouse_refs == 0;
  pthread_mutex_unlock(&devices_mutex);
  if (free_now)
    evdev_free_retired_device(device);
}

/* Out-of-range or malformed axis geometry must never trigger integer
 * overflow or divide by zero in an input callback. */
static bool evdev_axis_usable(const struct input_abs_parms *parms) {
  if (!parms) return false;
  struct mapping_axis axis = {parms->min, parms->max, parms->flat, parms->avg};
  return mapping_axis_usable(&axis);
}

static short evdev_convert_value(struct input_event *ev, struct input_device *dev,
                                 struct input_abs_parms *parms, bool reverse) {
  (void)dev;
  if (!evdev_axis_usable(parms)) return 0;
  struct mapping_axis axis = {parms->min, parms->max, parms->flat, parms->avg};
  return mapping_axis_stick(ev->value, &axis, reverse);
}

static unsigned char evdev_convert_value_byte(struct input_event *ev,
                          struct input_device *dev, struct input_abs_parms *parms,
                          char halfaxis) {
  (void)dev;
  if (!evdev_axis_usable(parms)) return 0;
  struct mapping_axis axis = {parms->min, parms->max, parms->flat, parms->avg};
  return mapping_axis_byte(ev->value, &axis, halfaxis);
}

void *HandleMouseEmulation(void* param)
{
  struct input_device* dev = (struct input_device*) param;

  while (__atomic_load_n(&dev->mouseEmulation, __ATOMIC_ACQUIRE)) {
    usleep(MOUSE_EMULATION_POLLING_INTERVAL);

    short rawX;
    short rawY;

    // All four axes are published by the evdev thread.
    const short lx = __atomic_load_n(&dev->leftStickX, __ATOMIC_RELAXED);
    const short ly = __atomic_load_n(&dev->leftStickY, __ATOMIC_RELAXED);
    const short rx = __atomic_load_n(&dev->rightStickX, __ATOMIC_RELAXED);
    const short ry = __atomic_load_n(&dev->rightStickY, __ATOMIC_RELAXED);
    if ((uint32_t)abs(lx) + abs(ly) > (uint32_t)abs(rx) + abs(ry)) {
      rawX = lx;
      rawY = ly;
    } else {
      rawX = rx;
      rawY = ry;
    }

    float deltaX;
    float deltaY;

    // Produce a base vector for mouse movement with increased speed as we deviate further from center
    deltaX = pow((float)rawX / 32767.0f * MOUSE_EMULATION_MOTION_MULTIPLIER, 3);
    deltaY = pow((float)rawY / 32767.0f * MOUSE_EMULATION_MOTION_MULTIPLIER, 3);

    // Enforce deadzones
    deltaX = moonlight_mouse_deadzone(deltaX, MOUSE_EMULATION_DEADZONE);
    deltaY = moonlight_mouse_deadzone(deltaY, MOUSE_EMULATION_DEADZONE);

    if (deltaX != 0 || deltaY != 0)
      LiSendMouseMoveEvent(deltaX, -deltaY);
  }

  pthread_mutex_lock(&devices_mutex);
  dev->mouse_worker_started = false;
  --dev->mouse_refs;
  --mouse_workers_active;
  pthread_cond_broadcast(&mouse_workers_drained);
  const bool free_now = dev->ff_cleanup_done &&
      dev->ff_refs == 0 && dev->mouse_refs == 0;
  pthread_mutex_unlock(&devices_mutex);
  if (free_now)
    evdev_free_retired_device(dev);
  return NULL;
}

/* Creation and ownership publication are ordered before the worker can run.
 * Only the input thread starts mouse emulation; workers exit asynchronously. */
static bool evdev_mouse_worker_start(struct input_device *dev) {
  pthread_mutex_lock(&devices_mutex);
  if (dev->mouse_worker_started ||
      __atomic_load_n(&dev->ff_retired, __ATOMIC_ACQUIRE)) {
    pthread_mutex_unlock(&devices_mutex);
    return false;
  }
  dev->mouse_worker_started = true;
  ++dev->mouse_refs;
  ++mouse_workers_active;
  __atomic_store_n(&dev->mouseEmulation, true, __ATOMIC_RELEASE);
  pthread_mutex_unlock(&devices_mutex);
  int rc = pthread_create(&dev->meThread, NULL, HandleMouseEmulation, dev);
  if (rc) {
    pthread_mutex_lock(&devices_mutex);
    __atomic_store_n(&dev->mouseEmulation, false, __ATOMIC_RELEASE);
    dev->mouse_worker_started = false;
    --dev->mouse_refs;
    --mouse_workers_active;
    pthread_cond_broadcast(&mouse_workers_drained);
    pthread_mutex_unlock(&devices_mutex);
    return false;
  }
  /* The last worker reference, not pthread_join, releases the allocation. */
  pthread_detach(dev->meThread);
  return true;
}

#define SET_BTN_FLAG(x, y) supportedButtonFlags |= (x >= 0) ? y : 0

static bool evdev_supports_rumble(const struct libevdev *device) {
  /* Only advertise normal force-feedback rumble when Linux confirms the
   * exact FF_RUMBLE effect used by EVIOCSFF. Native DualSense PCM haptics
   * remain independent capabilities, even if evdev exposes no FF bits. */
  return device &&
         libevdev_has_event_type(device, EV_FF) &&
         libevdev_has_event_code(device, EV_FF, FF_RUMBLE);
}

static void evdev_publish_arrival_locked(short slot,unsigned char type,unsigned int buttons,
                                         unsigned short caps,uint64_t speaker);
static const unsigned int mapping_button_flags[] = {
    A_FLAG, B_FLAG, X_FLAG, Y_FLAG, BACK_FLAG, PLAY_FLAG, SPECIAL_FLAG,
    LS_CLK_FLAG, RS_CLK_FLAG, LB_FLAG, RB_FLAG, UP_FLAG, DOWN_FLAG,
    LEFT_FLAG, RIGHT_FLAG, MISC_FLAG, PADDLE1_FLAG, PADDLE2_FLAG,
    PADDLE3_FLAG, PADDLE4_FLAG, TOUCHPAD_FLAG
  };

static bool evdev_read_extra(void *, const struct mapping_binding *, struct mapping_sample *);

static void send_controller_arrival_locked(struct input_device *dev) {
  unsigned char type = LI_CTYPE_UNKNOWN;
  unsigned int supportedButtonFlags = 0;
  unsigned short capabilities = 0;

  switch (libevdev_get_id_vendor(dev->dev)) {
  case 0x045e: // Microsoft
    type = LI_CTYPE_XBOX;
    break;
  case 0x054c: // Sony
    type = LI_CTYPE_PS;
    break;
  case 0x057e: // Nintendo
    type = LI_CTYPE_NINTENDO;
    break;
  }

  const char* name = libevdev_get_name(dev->dev);
  if (name && type == LI_CTYPE_UNKNOWN) {

    // Try to guess based on the name
    if (strstr(name, "Xbox") || strstr(name, "X-Box") || strstr(name, "XBox") || strstr(name, "XBOX")) {
      type = LI_CTYPE_XBOX;
    }
  }

  struct mapping_binding bindings[MAPPING_BINDING_MAX];
  unsigned count = mapping_bindings(dev->map, bindings);
  bool analog[2] = {false};
  for (unsigned i = 0; i < count; ++i) {
    const struct mapping_binding *binding = &bindings[i];
    struct mapping_sample sample = {0};
    if (!evdev_read_extra(dev, binding, &sample)) continue;
    if (binding->destination >= 6 && binding->destination < 27)
      supportedButtonFlags |= mapping_button_flags[binding->destination - 6];
    if (binding->destination >= 4 && binding->destination < 6 &&
        binding->source == 'a' && sample.maximum > sample.minimum)
      analog[binding->destination - 4] = true;
  }
  if (analog[0] && analog[1]) capabilities |= LI_CCAP_ANALOG_TRIGGERS;

  if (evdev_supports_rumble(dev->dev))
    capabilities |= LI_CCAP_RUMBLE;
  if (dev->dualsense) {
    capabilities |= dualsense_capabilities(dev->dualsense);
    dualsense_set_player(dev->dualsense, dev->controllerId);
  }

  const uint64_t speaker_owner = type == LI_CTYPE_PS && dev->dualsense ?
      dualsense_speaker_owner(dev->dualsense) : 0;
  evdev_publish_arrival_locked(dev->controllerId, type, supportedButtonFlags,
                         capabilities, speaker_owner);
}

static void send_controller_arrival(struct input_device *dev) {
  pthread_mutex_lock(&devices_mutex);
  send_controller_arrival_locked(dev);
  pthread_mutex_unlock(&devices_mutex);
}

static bool evdev_read_extra(void *context, const struct mapping_binding *b,
                              struct mapping_sample *sample) {
  struct input_device *dev = context;
  if (b->source == 'h') {
    int x = ABS_HAT0X + b->index * 2;
    if (!libevdev_has_event_code(dev->dev, EV_ABS, x) &&
        !libevdev_has_event_code(dev->dev, EV_ABS, x + 1)) return false;
    int vx = libevdev_get_event_value(dev->dev, EV_ABS, x);
    int vy = libevdev_get_event_value(dev->dev, EV_ABS, x + 1);
    sample->value = (vx < 0 ? 8 : vx > 0 ? 2 : 0) |
                    (vy < 0 ? 1 : vy > 0 ? 4 : 0);
    return true;
  }
  int code = evdev_get_map(b->source == 'a' ? dev->abs_map : dev->key_map,
                          b->source == 'a' ? ABS_MAX : KEY_MAX, b->index);
  if (code < 0) return false;
  sample->value = libevdev_get_event_value(dev->dev,
                      b->source == 'a' ? EV_ABS : EV_KEY, code);
  if (b->source == 'a') {
    sample->minimum = libevdev_get_abs_minimum(dev->dev, code);
    sample->maximum = libevdev_get_abs_maximum(dev->dev, code);
    sample->flat = libevdev_get_abs_flat(dev->dev, code);
  }
  return true;
}

static bool evdev_apply_extra(struct input_device *dev) {
  if (!dev->is_gamepad || !dev->map) return false;
  int values[27]; bool present[27];
  short *axes[] = {&dev->leftStickX, &dev->leftStickY,
                   &dev->rightStickX, &dev->rightStickY};
  bool extended[27] = {false};
  for (unsigned i = 0; i < dev->map->extra_count && i < MAPPING_EXTRA_MAX; ++i)
    if (dev->map->extra[i].destination < 27)
      extended[dev->map->extra[i].destination] = true;
  /* Legacy fields can also describe multiple sources for one destination
   * (for example a trigger axis plus button). Recompute those together. */
  struct mapping_binding bindings[MAPPING_BINDING_MAX];
  unsigned contributors[27] = {0};
  unsigned count = mapping_bindings(dev->map, bindings);
  for (unsigned i = 0; i < count; ++i) {
    struct mapping_sample sample;
    unsigned dst = bindings[i].destination;
    if (dst < 27 && evdev_read_extra(dev, &bindings[i], &sample) &&
        ++contributors[dst] > 1) extended[dst] = true;
  }
  /* The legacy event chain selects only the first destination of a shared
   * source. Recompute every destination in that fan-out, including sticks. */
  for (unsigned i = 0; i < count; ++i) {
    for (unsigned j = i + 1; j < count; ++j) {
      if (bindings[i].source == bindings[j].source &&
          bindings[i].index == bindings[j].index &&
          bindings[i].destination != bindings[j].destination &&
          bindings[i].destination < 27 && bindings[j].destination < 27) {
        extended[bindings[i].destination] = true;
        extended[bindings[j].destination] = true;
      }
    }
  }
  bool aggregate = false;
  for (unsigned i = 0; i < 27; ++i) aggregate |= extended[i];
  if (!aggregate) return false;
  mapping_evaluate_extra(dev->map, evdev_read_extra, dev, values, present);
  for (int i = 0; i < 4; ++i) if (extended[i] && present[i]) {
    int value = values[i];
    if (i == 1 || i == 3) value = value == -32768 ? 32767 : -value;
    __atomic_store_n(axes[i], (short)value, __ATOMIC_RELAXED);
  }
  if (extended[4] && present[4]) dev->leftTrigger = values[4];
  if (extended[5] && present[5]) dev->rightTrigger = values[5];
  for (int i = 6; i < 27; ++i) if (extended[i] && present[i]) {
    if (values[i]) dev->buttonFlags |= mapping_button_flags[i - 6];
    else dev->buttonFlags &= ~mapping_button_flags[i - 6];
  }
  return true;
}

static void evdev_gamepad_mouse_edge(struct input_device *dev,
    const struct input_event *ev, unsigned int gamepadCode) {
  if (gamepadCode == PLAY_FLAG && ev->value == 1) {
    dev->btnDownTime.tv_sec = ev->input_event_sec;
    dev->btnDownTime.tv_usec = ev->input_event_usec;
  }
  if (moonlight_gamepad_slot_valid(dev->controllerId) &&
      mouseEmulationEnabled && gamepadCode == PLAY_FLAG && ev->value == 0) {
    struct timeval eventTime;
    eventTime.tv_sec = ev->input_event_sec;
    eventTime.tv_usec = ev->input_event_usec;
    struct timeval elapsedTime;
    timersub(&eventTime, &dev->btnDownTime, &elapsedTime);
    int holdTimeMs = elapsedTime.tv_sec * 1000 + elapsedTime.tv_usec / 1000;
    if (holdTimeMs >= MOUSE_EMULATION_LONG_PRESS_TIME) {
      if (__atomic_load_n(&dev->mouseEmulation, __ATOMIC_ACQUIRE)) {
        __atomic_store_n(&dev->mouseEmulation, false, __ATOMIC_RELEASE);
        /* No event-loop join: a stuck common-c send must not block CEC. */
        const int buttons[] = {BUTTON_LEFT, BUTTON_MIDDLE, BUTTON_RIGHT, BUTTON_X1, BUTTON_X2};
        for (unsigned b = 0; b < sizeof(buttons)/sizeof(buttons[0]); ++b)
          evdev_send_mouse_button(dev, BUTTON_ACTION_RELEASE, buttons[b]);
        printf("Mouse emulation disabled for controller %d.\n", dev->controllerId);
      } else {
        if (!evdev_mouse_worker_start(dev)) {
          fprintf(stderr, "Controller mouse emulation unavailable or still stopping\n");
        } else {
          printf("Mouse emulation enabled for controller %d.\n", dev->controllerId);
        }
      }
      // clear gamepad state.
      if (dev->controllerId >= 0)
        evdev_publish_state(dev->controllerId, 0, 0, 0, 0, 0, 0, 0);
    }
  } else if (moonlight_gamepad_slot_valid(dev->controllerId) &&
             __atomic_load_n(&dev->mouseEmulation, __ATOMIC_ACQUIRE)) {
    char action = ev->value ? BUTTON_ACTION_PRESS : BUTTON_ACTION_RELEASE;
    switch (gamepadCode) {
      case A_FLAG:
        evdev_send_mouse_button(dev, action, BUTTON_LEFT);
        break;
      case B_FLAG:
        evdev_send_mouse_button(dev, action, BUTTON_RIGHT);
        break;
      case X_FLAG:
        evdev_send_mouse_button(dev, action, BUTTON_MIDDLE);
        break;
      case LB_FLAG:
        evdev_send_mouse_button(dev, action, BUTTON_X1);
        break;
      case RB_FLAG:
        evdev_send_mouse_button(dev, action, BUTTON_X2);
        break;
    }
  }
}

static bool evdev_handle_event(struct input_event *ev, struct input_device *dev) {
  bool gamepadModified = false;
  unsigned int previousButtons = dev->buttonFlags;

  switch (ev->type) {
  case EV_SYN:
    if (ev->code != SYN_REPORT) break;
    if (dev->mouseDeltaX != 0 || dev->mouseDeltaY != 0) {
      if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId)) {
        int32_t x = dev->mouseDeltaX, y = dev->mouseDeltaY;
        switch (dev->rotate) {
        case 90:
          x = dev->mouseDeltaY;
          y = moonlight_negate_rel(dev->mouseDeltaX);
          break;
        case 180:
          x = moonlight_negate_rel(dev->mouseDeltaX);
          y = moonlight_negate_rel(dev->mouseDeltaY);
          break;
        case 270:
          x = moonlight_negate_rel(dev->mouseDeltaY);
          y = dev->mouseDeltaX;
          break;
        }
        LiSendMouseMoveEvent(moonlight_mouse_delta(x), moonlight_mouse_delta(y));
      }
      dev->mouseDeltaX = 0;
      dev->mouseDeltaY = 0;
    }
    if (dev->mouseVScroll != 0) {
      if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId))
        LiSendScrollEvent(moonlight_scroll_delta(dev->mouseVScroll));
      dev->mouseVScroll = 0;
    }
    if (dev->mouseHScroll != 0) {
      if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId))
        LiSendHScrollEvent(moonlight_scroll_delta(dev->mouseHScroll));
      dev->mouseHScroll = 0;
    }
    if (dev->gamepadModified) {
      if (dev->controllerId < 0) {
        pthread_mutex_lock(&devices_mutex);
        const int slot = moonlight_first_free_gamepad_slot(
            (unsigned int)assignedControllerIds);
        if (slot >= 0) {
          assignedControllerIds |= (1U << slot);
          dev->controllerId = slot;
          gamepad_capacity_warned = false;
          send_controller_arrival_locked(dev);
          printf("Assigned %s as player %d\n", libevdev_get_name(dev->dev), slot + 1);
        } else if (!gamepad_capacity_warned) {
          fprintf(stderr, "Too many gamepads: refusing extra controller (16 slots full)\n");
          gamepad_capacity_warned = true;
        }
        pthread_mutex_unlock(&devices_mutex);

        if (dev->controllerId < 0) {
          /* Keep this device unassigned, so it can claim a newly freed slot
           * later instead of sending input as another user's controller. */
          dev->gamepadModified = false;
          break;
        }
      }
      // Send event only if mouse emulation is disabled.
      if (!__atomic_load_n(&dev->mouseEmulation, __ATOMIC_ACQUIRE))
        evdev_publish_state(dev->controllerId, dev->buttonFlags, dev->leftTrigger, dev->rightTrigger, dev->leftStickX, dev->leftStickY, dev->rightStickX, dev->rightStickY);
      dev->gamepadModified = false;
    }
    break;
  case EV_KEY:
    if (ev->code > KEY_MAX)
      return true;
#ifdef HAVE_LIBCEC
    /* Vortex routes local media keys to TV/AVR over libCEC. Do not send
     * these to Sunshine when an opted-in CEC adapter is actually open. */
    if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId) &&
        cec_handle_media_key(ev->code, ev->value))
      return true;
#endif

    /* A navigation remote's Back/Exit is local session navigation, not a
     * Windows key. Controllers and full keyboards intentionally keep their
     * existing host-facing Back/View and Escape behavior. */
    if (dev->is_remote && ev->value == 1 &&
        (ev->code == KEY_BACK || ev->code == KEY_EXIT || ev->code == KEY_ESC)) {
      printf("Remote Back/Exit requested local stream exit\n");
      return false;
    }
    /* Stage button/axis events until a slot becomes available, but never
     * forward keyboard-like keys from an unassigned 17th gamepad. */
    if (dev->is_gamepad && !moonlight_gamepad_slot_valid(dev->controllerId) &&
        ev->code < sizeof(keyCodes)/sizeof(keyCodes[0]))
      return true;
    if (ev->code < sizeof(keyCodes)/sizeof(keyCodes[0])) {
      char modifier = 0;
      switch (ev->code) {
      case KEY_LEFTSHIFT:
      case KEY_RIGHTSHIFT:
        modifier = MODIFIER_SHIFT;
        break;
      case KEY_LEFTALT:
      case KEY_RIGHTALT:
        modifier = MODIFIER_ALT;
        break;
      case KEY_LEFTCTRL:
      case KEY_RIGHTCTRL:
        modifier = MODIFIER_CTRL;
        break;
      case KEY_LEFTMETA:
      case KEY_RIGHTMETA:
        modifier = MODIFIER_META;
        break;
      }
      if (modifier != 0) {
        pthread_mutex_lock(&devices_mutex);
        if (ev->value)
          dev->held_keys[ev->code / 8] |= 1u << (ev->code % 8);
        else
          dev->held_keys[ev->code / 8] &= ~(1u << (ev->code % 8));
        dev->modifiers = evdev_modifiers(dev);
        pthread_mutex_unlock(&devices_mutex);
      }

      // After the quit key combo is pressed, quit once all keys are raised
      if ((dev->modifiers & ACTION_MODIFIERS) == ACTION_MODIFIERS &&
          ev->code == QUIT_KEY && ev->value != 0) {
        dev->pendingQuitOnModifiersUp = true;
        return true;
      } else if (dev->pendingQuitOnModifiersUp && dev->modifiers == 0) {
        dev->pendingQuitOnModifiersUp = false;
        return false;
      }

      short code = 0x80 << 8 | keyCodes[ev->code];
      pthread_mutex_lock(&devices_mutex);
      if (ev->value)
        dev->held_keys[ev->code / 8] |= 1u << (ev->code % 8);
      else
        dev->held_keys[ev->code / 8] &= ~(1u << (ev->code % 8));
      const bool held = host_key_held(keyCodes[ev->code]);
      const char modifiers = evdev_global_modifiers();
      if (ev->value || !held)
        LiSendKeyboardEvent(code, ev->value ? KEY_ACTION_DOWN : KEY_ACTION_UP, modifiers);
      pthread_mutex_unlock(&devices_mutex);
    } else {
      int mouseCode = 0;
      int gamepadCode = 0;
      int index = dev->key_map[ev->code];

      switch (ev->code) {
      case BTN_LEFT:
        mouseCode = BUTTON_LEFT;
        break;
      case BTN_MIDDLE:
        mouseCode = BUTTON_MIDDLE;
        break;
      case BTN_RIGHT:
        mouseCode = BUTTON_RIGHT;
        break;
      case BTN_SIDE:
        mouseCode = BUTTON_X1;
        break;
      case BTN_EXTRA:
        mouseCode = BUTTON_X2;
        break;
      case BTN_TOUCH:
        if (ev->value == 1) {
          dev->touchDownTime.tv_sec = ev->input_event_sec;
          dev->touchDownTime.tv_usec = ev->input_event_usec;
        } else {
          if (dev->touchDownX != TOUCH_UP && dev->touchDownY != TOUCH_UP) {
            if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId) &&
                moonlight_touch_is_tap(dev->touchX, dev->touchY,
                                      dev->touchDownX, dev->touchDownY,
                                      TOUCH_CLICK_RADIUS)) {
              struct timeval eventTime;
              eventTime.tv_sec = ev->input_event_sec;
              eventTime.tv_usec = ev->input_event_usec;
              struct timeval elapsedTime;
              timersub(&eventTime, &dev->touchDownTime, &elapsedTime);
              int holdTimeMs = elapsedTime.tv_sec * 1000 + elapsedTime.tv_usec / 1000;
              int button = holdTimeMs >= TOUCH_RCLICK_TIME ? BUTTON_RIGHT : BUTTON_LEFT;
              const int bi = evdev_mouse_button_index(button);
              const bool already_held = bi >= 0 && dev->held_mouse_buttons[bi];
              evdev_send_mouse_button(dev, BUTTON_ACTION_PRESS, button);
              if (!already_held) evdev_send_mouse_button(dev, BUTTON_ACTION_RELEASE, button);
            }
          }
          dev->touchDownX = TOUCH_UP;
          dev->touchDownY = TOUCH_UP;
        }
        break;
      default:
        gamepadModified = true;
        if (dev->map == NULL)
          break;
        else if (index == dev->map->btn_a)
          gamepadCode = A_FLAG;
        else if (index == dev->map->btn_x)
          gamepadCode = X_FLAG;
        else if (index == dev->map->btn_y)
          gamepadCode = Y_FLAG;
        else if (index == dev->map->btn_b)
          gamepadCode = B_FLAG;
        else if (index == dev->map->btn_dpup)
          gamepadCode = UP_FLAG;
        else if (index == dev->map->btn_dpdown)
          gamepadCode = DOWN_FLAG;
        else if (index == dev->map->btn_dpright)
          gamepadCode = RIGHT_FLAG;
        else if (index == dev->map->btn_dpleft)
          gamepadCode = LEFT_FLAG;
        else if (index == dev->map->btn_leftstick)
          gamepadCode = LS_CLK_FLAG;
        else if (index == dev->map->btn_rightstick)
          gamepadCode = RS_CLK_FLAG;
        else if (index == dev->map->btn_leftshoulder)
          gamepadCode = LB_FLAG;
        else if (index == dev->map->btn_rightshoulder)
          gamepadCode = RB_FLAG;
        else if (index == dev->map->btn_start)
          gamepadCode = PLAY_FLAG;
        else if (index == dev->map->btn_back)
          gamepadCode = BACK_FLAG;
        else if (index == dev->map->btn_guide)
          gamepadCode = SPECIAL_FLAG;
        else if (index == dev->map->btn_misc1)
          gamepadCode = MISC_FLAG;
        else if (index == dev->map->btn_paddle1)
          gamepadCode = PADDLE1_FLAG;
        else if (index == dev->map->btn_paddle2)
          gamepadCode = PADDLE2_FLAG;
        else if (index == dev->map->btn_paddle3)
          gamepadCode = PADDLE3_FLAG;
        else if (index == dev->map->btn_paddle4)
          gamepadCode = PADDLE4_FLAG;
        else if (index == dev->map->btn_touchpad)
          gamepadCode = TOUCHPAD_FLAG;
      }

      if (mouseCode != 0) {
        if (moonlight_host_input_allowed(dev->is_gamepad, dev->controllerId))
          evdev_send_mouse_button(dev,
              ev->value ? BUTTON_ACTION_PRESS : BUTTON_ACTION_RELEASE, mouseCode);
        gamepadModified = false;
      } else if (gamepadCode != 0) {
        if (ev->value) {
          dev->buttonFlags |= gamepadCode;
        } else
          dev->buttonFlags &= ~gamepadCode;
      } else if (dev->map != NULL && index == dev->map->btn_lefttrigger)
        dev->leftTrigger = ev->value ? UCHAR_MAX : 0;
      else if (dev->map != NULL && index == dev->map->btn_righttrigger)
        dev->rightTrigger = ev->value ? UCHAR_MAX : 0;
      else {
        if (dev->map != NULL)
          fprintf(stderr, "Unmapped button: %d\n", ev->code);

        gamepadModified = false;
      }
    }
    break;
  case EV_REL:
    switch (ev->code) {
      case REL_X:
        dev->mouseDeltaX = moonlight_accumulate_rel(dev->mouseDeltaX, ev->value);
        break;
      case REL_Y:
        dev->mouseDeltaY = moonlight_accumulate_rel(dev->mouseDeltaY, ev->value);
        break;
      case REL_HWHEEL:
        dev->mouseHScroll = moonlight_accumulate_rel(dev->mouseHScroll, ev->value);
        break;
      case REL_WHEEL:
        dev->mouseVScroll = moonlight_accumulate_rel(dev->mouseVScroll, ev->value);
        break;
    }
    break;
  case EV_ABS:
    if (ev->code > ABS_MAX)
      return true;
    if (dev->is_touchscreen) {
      switch (ev->code) {
      case ABS_X:
        if (dev->touchDownX == TOUCH_UP) {
          dev->touchDownX = ev->value;
          dev->touchX = ev->value;
        } else {
          dev->mouseDeltaX = moonlight_accumulate_rel(dev->mouseDeltaX,
              moonlight_touch_delta(ev->value, dev->touchX));
          dev->touchX = ev->value;
        }
        break;
      case ABS_Y:
        if (dev->touchDownY == TOUCH_UP) {
          dev->touchDownY = ev->value;
          dev->touchY = ev->value;
        } else {
          dev->mouseDeltaY = moonlight_accumulate_rel(dev->mouseDeltaY,
              moonlight_touch_delta(ev->value, dev->touchY));
          dev->touchY = ev->value;
        }
        break;
      }
      break;
    }

    if (dev->map == NULL)
      break;

    gamepadModified = true;
    int index = dev->abs_map[ev->code];
    int hat_index = (ev->code - ABS_HAT0X) / 2;
    int hat_dir_index = (ev->code - ABS_HAT0X) % 2;

    switch (ev->code) {
    case ABS_HAT0X:
    case ABS_HAT0Y:
    case ABS_HAT1X:
    case ABS_HAT1Y:
    case ABS_HAT2X:
    case ABS_HAT2Y:
    case ABS_HAT3X:
    case ABS_HAT3Y:
      dev->hats_state[hat_index][hat_dir_index] = ev->value < 0 ? -1 : (ev->value == 0 ? 0 : 1);
      int hat_state = hat_constants[dev->hats_state[hat_index][1] + 1][dev->hats_state[hat_index][0] + 1];
      if (hat_index == dev->map->hat_dpup)
        set_hat(dev->buttonFlags, UP_FLAG, hat_state, dev->map->hat_dir_dpup);
      if (hat_index == dev->map->hat_dpdown)
        set_hat(dev->buttonFlags, DOWN_FLAG, hat_state, dev->map->hat_dir_dpdown);
      if (hat_index == dev->map->hat_dpright)
        set_hat(dev->buttonFlags, RIGHT_FLAG, hat_state, dev->map->hat_dir_dpright);
      if (hat_index == dev->map->hat_dpleft)
        set_hat(dev->buttonFlags, LEFT_FLAG, hat_state, dev->map->hat_dir_dpleft);
      break;
    default:
      if (index == dev->map->abs_leftx)
        __atomic_store_n(&dev->leftStickX, evdev_convert_value(ev, dev, &dev->xParms, dev->map->reverse_leftx), __ATOMIC_RELAXED);
      else if (index == dev->map->abs_lefty)
        __atomic_store_n(&dev->leftStickY, evdev_convert_value(ev, dev, &dev->yParms, !dev->map->reverse_lefty), __ATOMIC_RELAXED);
      else if (index == dev->map->abs_rightx)
        __atomic_store_n(&dev->rightStickX, evdev_convert_value(ev, dev, &dev->rxParms, dev->map->reverse_rightx), __ATOMIC_RELAXED);
      else if (index == dev->map->abs_righty)
        __atomic_store_n(&dev->rightStickY, evdev_convert_value(ev, dev, &dev->ryParms, !dev->map->reverse_righty), __ATOMIC_RELAXED);
      else
        gamepadModified = false;

      if (index == dev->map->abs_lefttrigger) {
        dev->leftTrigger = evdev_convert_value_byte(ev, dev, &dev->zParms, dev->map->halfaxis_lefttrigger);
        gamepadModified = true;
      }
      if (index == dev->map->abs_righttrigger) {
        dev->rightTrigger = evdev_convert_value_byte(ev, dev, &dev->rzParms, dev->map->halfaxis_righttrigger);
        gamepadModified = true;
      }

      if (index == dev->map->abs_dpright) {
        if (evdev_convert_value_byte(ev, dev, &dev->rightParms, dev->map->halfaxis_dpright) > 127)
          dev->buttonFlags |= RIGHT_FLAG;
        else
          dev->buttonFlags &= ~RIGHT_FLAG;

        gamepadModified = true;
      }
      if (index == dev->map->abs_dpleft) {
        if (evdev_convert_value_byte(ev, dev, &dev->leftParms, dev->map->halfaxis_dpleft) > 127)
          dev->buttonFlags |= LEFT_FLAG;
        else
          dev->buttonFlags &= ~LEFT_FLAG;

        gamepadModified = true;
      }
      if (index == dev->map->abs_dpup) {
        if (evdev_convert_value_byte(ev, dev, &dev->upParms, dev->map->halfaxis_dpup) > 127)
          dev->buttonFlags |= UP_FLAG;
        else
          dev->buttonFlags &= ~UP_FLAG;

        gamepadModified = true;
      }
      if (index == dev->map->abs_dpdown) {
        if (evdev_convert_value_byte(ev, dev, &dev->downParms, dev->map->halfaxis_dpdown) > 127)
          dev->buttonFlags |= DOWN_FLAG;
        else
          dev->buttonFlags &= ~DOWN_FLAG;

        gamepadModified = true;
      }
    }
  }

  if ((ev->type == EV_KEY || ev->type == EV_ABS) && evdev_apply_extra(dev))
    gamepadModified = true;

  if (dev->is_gamepad && (ev->type == EV_KEY || ev->type == EV_ABS)) {
    unsigned int changed = previousButtons ^ dev->buttonFlags;
    for (unsigned i = 0; i < sizeof(mapping_button_flags)/sizeof(mapping_button_flags[0]); ++i) {
      unsigned int flag = mapping_button_flags[i];
      if (!(changed & flag)) continue;
      struct input_event edge = *ev;
      edge.value = (dev->buttonFlags & flag) ? 1 : 0;
      evdev_gamepad_mouse_edge(dev, &edge, flag);
    }
  }

  if (gamepadModified && moonlight_gamepad_slot_valid(dev->controllerId) &&
      (dev->buttonFlags & QUIT_BUTTONS) == QUIT_BUTTONS) {
    if (dev->controllerId >= 0)
      evdev_publish_state(dev->controllerId, 0, 0, 0, 0, 0, 0, 0);
    return false;
  }

  dev->gamepadModified |= gamepadModified;
  return true;
}

/* The evdev state includes the current ABS value even before the first
 * event reaches the wizard. Capture the inactive position BEFORE prompting. */
static void evdev_snapshot_mapping_rest(void) {
  for (int d = 0; d < numDevices; ++d) {
    for (unsigned int axis = 0; axis < ABS_CNT; ++axis) {
      if (libevdev_has_event_code(devices[d]->dev, EV_ABS, axis))
        devices[d]->mapping_rest[axis] =
            libevdev_get_event_value(devices[d]->dev, EV_ABS, axis);
    }
  }
}

static bool evdev_handle_mapping_event(struct input_event *ev, struct input_device *dev) {
  int index, hat_index;
  switch (ev->type) {
  case EV_KEY:
    if (ev->code > KEY_MAX) break;
    index = dev->key_map[ev->code];
    if (currentKey != NULL) {
      if (ev->value)
        *currentKey = index;
      else if (*currentKey != -1 && index == *currentKey)
        return false;
    }
    break;
  case EV_ABS:
    if (ev->code > ABS_MAX) break;
    /* Division of a negative code can round toward zero, creating a
     * bogus hat 0 with a negative direction index. */
    hat_index = -1;
    if (ev->code >= ABS_HAT0X && ev->code <= ABS_HAT3Y) {
      hat_index = (ev->code - ABS_HAT0X) / 2;
      int hat_dir_index = (ev->code - ABS_HAT0X) % 2;
      dev->hats_state[hat_index][hat_dir_index] =
          ev->value < 0 ? -1 : (ev->value == 0 ? 0 : 1);
    }
    if (currentAbs != NULL) {
      /* The mapping helper expects a mapped axis index, not Linux's ABS
       * event code. Missing indices cannot leave 'parms' uninitialized. */
      const int mapped = dev->abs_map[ev->code];
      if (mapped < 0) break;
      struct input_abs_parms parms = {0};
      if (!evdev_init_parms(dev, &parms, mapped)) break;
      if (*currentAbs >= 0) {
        /* Once a physical axis is captured, ignore unrelated events and
         * opposite-edge readings. A 0..255 trigger rests at an endpoint,
         * unlike a centered stick. */
        if (mapped == *currentAbs &&
            moonlight_mapping_axis_released(
                ev->value, dev->mapping_rest[ev->code],
                parms.min, parms.max))
          return false;
        break;
      }
      if (moonlight_mapping_axis_pressed(
              ev->value, dev->mapping_rest[ev->code],
              parms.min, parms.max)) {
        const bool positive = ev->value > dev->mapping_rest[ev->code];
        *currentAbs = mapped;
        if (currentReverse) *currentReverse = !positive;
        if (currentHalfAxis) {
          /* Full 0..255 scaling for a trigger pressed from its minimum.
           * A reverse/unipolar trigger or bipolar axis needs a half-axis. */
          *currentHalfAxis = moonlight_mapping_trigger_mode(
              parms.min, parms.max, dev->mapping_rest[ev->code], positive);
        }
      }
    } else if (currentHat != NULL && hat_index >= 0 && hat_index < 4) {
      const int direction =
          hat_constants[dev->hats_state[hat_index][1] + 1]
                       [dev->hats_state[hat_index][0] + 1];
      if (*currentHat >= 0) {
        /* Finish only after the SAME hat returns to neutral. Never record
         * a zero direction, which would be permanently pressed at runtime. */
        if (hat_index == *currentHat && direction == 0)
          return false;
      } else if (moonlight_mapping_hat_pressed(direction)) {
        *currentHat = hat_index;
        *currentHatDir = direction;
      }
    }
    break;
  }
  return true;
}

static void evdev_drain(void) {
  /* Mapping and shutdown also consume events. Keep these paths bounded so
   * an event flood or endless SYN_DROPPED cannot trap Kodi recovery. */
  enum { EVDEV_DRAIN_BUDGET = 256 };
  for (int i = 0; i < numDevices; ++i) {
    struct input_device *dev = devices[i];
    for (unsigned reads = 0; reads < EVDEV_DRAIN_BUDGET; ++reads) {
      struct input_event ev;
      const int rc = libevdev_next_event(dev->dev,
          dev->syncing ? LIBEVDEV_READ_FLAG_SYNC : LIBEVDEV_READ_FLAG_NORMAL, &ev);
      if (rc == LIBEVDEV_READ_STATUS_SYNC) {
        dev->syncing = true;
        continue;
      }
      if (rc == -EAGAIN && dev->syncing) {
        dev->syncing = false;
        continue;
      }
      if (rc == -EINTR) continue;
      if (rc < 0) break;
    }
  }
}

/* Explicit POLLNVAL recovery is valid only for evdev-owned descriptors.
 * Never swallow a bad signalfd or other essential event-loop registration. */
static int evdev_handle_invalid(int fd) {
  for (int i = 0; i < numDevices; ++i) {
    if (devices[i]->fd != fd) continue;
    fprintf(stderr, "Input device %d invalid; detaching node\n", fd);
    char retry_path[sizeof(devices[i]->retry_path)];
    snprintf(retry_path, sizeof(retry_path), "%s", devices[i]->retry_path);
    const unsigned long long retry_rdev = devices[i]->retry_rdev;
    char retry_identity[ML_INPUT_IDENTITY_MAX];
    memcpy(retry_identity, devices[i]->retry_identity, sizeof(retry_identity));
    evdev_remove(i);
    udev_schedule_input_retry(retry_path, retry_rdev, retry_identity);
    return LOOP_OK;
  }
  loop_remove_fd(fd); /* Stale registration; avoid a repeated POLLNVAL. */
  return LOOP_OK;
}

static int evdev_handle(int fd) {
  /* A continuously busy controller must not monopolize the same main loop
   * that services CEC, hotplug and other input descriptors. Count all read
   * attempts, including EINTR and resynchronization, to guarantee fairness. */
  enum { EVDEV_READ_BUDGET = 256 };
  for (int i = 0; i < numDevices; ++i) {
    if (devices[i]->fd != fd) continue;
    struct input_device *dev = devices[i];
    dev->read_pending = true;
    for (unsigned int reads = 0; reads < EVDEV_READ_BUDGET; ++reads) {
      struct input_event ev;
      int rc = libevdev_next_event(dev->dev,
          dev->syncing ? LIBEVDEV_READ_FLAG_SYNC : LIBEVDEV_READ_FLAG_NORMAL, &ev);
      if (rc == LIBEVDEV_READ_STATUS_SYNC) {
        if (!dev->syncing) {
          fprintf(stderr, "Input events dropped; resynchronizing device %d\n", fd);
          dev->syncing = true;
          continue; /* Initial SYN_DROPPED is not an input event. */
        }
        if (!handler(&ev, dev)) return LOOP_RETURN;
        continue;
      }
      if (rc == LIBEVDEV_READ_STATUS_SUCCESS) {
        if (!handler(&ev, dev)) return LOOP_RETURN;
        continue;
      }
      if (rc == -EAGAIN && dev->syncing) {
        dev->syncing = false;
        continue; /* Finish SYNC before resuming normal input. */
      }
      if (rc == -EINTR) continue;
      if (rc == -EAGAIN) { dev->read_pending = false; break; }
      /* A failed physical input node must never terminate the video/audio
       * stream or disconnect healthy controllers. Hotplug can re-add it. */
      fprintf(stderr, "Input device %d read failed (%d): %s; detaching node\n",
              fd, rc, rc < 0 ? strerror(-rc) : "invalid libevdev status");
      char retry_path[sizeof(dev->retry_path)];
      snprintf(retry_path, sizeof(retry_path), "%s", dev->retry_path);
      const unsigned long long retry_rdev = dev->retry_rdev;
      char retry_identity[ML_INPUT_IDENTITY_MAX];
      memcpy(retry_identity, dev->retry_identity, sizeof(retry_identity));
      evdev_remove(i);
      if (rc != -ENODEV)
        udev_schedule_input_retry(retry_path, retry_rdev, retry_identity);
      return LOOP_OK;
    }
    break;
  }
  return LOOP_OK;
}

/* A readable path is not necessarily an evdev device. Validate libevdev
 * before using metadata or registering a poll fd. Failed initialization
 * closes the fd; callers must not close it a second time. */
static struct libevdev *evdev_open_checked(int fd, const char *path) {
  struct libevdev *dev = libevdev_new();
  if (!dev) {
    fprintf(stderr, "Cannot allocate libevdev for %s\n", path);
    close(fd);
    return NULL;
  }
  int rc = libevdev_set_fd(dev, fd);
  if (rc < 0) {
    fprintf(stderr, "Not a usable evdev device %s: %s\n",
            path, strerror(-rc));
    libevdev_free(dev);
    close(fd);
    return NULL;
  }
  return dev;
}

static void evdev_mapping_guid(struct libevdev *evdev, char str_guid[33]) {
  const char *name = libevdev_get_name(evdev);
  if (!name) name = "Unknown input device";
  int16_t guid[8] = {0};
  guid[0] = int16_to_le(libevdev_get_id_bustype(evdev));
  int16_t vendor = libevdev_get_id_vendor(evdev);
  int16_t product = libevdev_get_id_product(evdev);
  if (vendor && product) {
    guid[2] = int16_to_le(vendor);
    guid[4] = int16_to_le(product);
    guid[6] = int16_to_le(libevdev_get_id_version(evdev));
  } else
    strncpy((char*) &guid[2], name, 11);

  char* buf = str_guid;
  for (int i = 0; i < 16; i++)
    buf += sprintf(buf, "%02x", ((unsigned char*) guid)[i]);
}

static void evdev_create_internal(const char* device, struct mapping* mappings,
                                  bool verbose, int rotate,
                                  const char *expected_identity) {
  int fd = open(device, O_RDWR|O_NONBLOCK);
  int error = fd < 0 ? errno : 0;
  /* Retry on the udev timer, never sleep in the shared input loop. O_PATH
   * captures identity without requiring permission to read input events. */
  if (fd < 0 && input_handoff_enabled("MOONLIGHT_INPUT_RECOVERY") &&
      input_handoff_retryable(error, 0)) {
    int identity_fd = open(device, O_PATH | O_CLOEXEC);
    if (identity_fd >= 0) {
      struct stat st;
      char identity[ML_INPUT_IDENTITY_MAX] = {0};
      if (fstat(identity_fd, &st) == 0 &&
          udev_input_identity_for_fd(identity_fd, identity, sizeof(identity)) &&
          (!expected_identity || strcmp(identity, expected_identity) == 0))
        udev_schedule_input_retry(device, (unsigned long long)st.st_rdev, identity);
      close(identity_fd);
    }
  }
  if (fd < 0) {
    fprintf(stderr, "Failed to open device %s: %s\n",
            device, strerror(error));
    fflush(stderr);
    return;
  }
  char current_identity[ML_INPUT_IDENTITY_MAX] = {0};
  const bool identity_known = udev_input_identity_for_fd(
      fd, current_identity, sizeof(current_identity));
  if (expected_identity &&
      (!identity_known || strcmp(current_identity, expected_identity) != 0)) {
    /* Re-read identity on this FD, not on the previous stat() pathname. */
    fprintf(stderr, "Input retry declined: physical device identity changed: %s\n",
            device);
    close(fd);
    return;
  }
  if (evdev_fd_already_registered(fd)) {
    if (verbose)
      fprintf(stderr, "Skipping already registered input device %s\n", device);
    close(fd);
    return;
  }
  /* A successfully claimed 2026 Valve vendor HID device suppresses only
   * event nodes under the exact same HID parent, avoiding duplicate
   * lizard-mode mouse/keyboard and joystick input. */
  if (sc26_owns_event_fd(fd)) {
    if (verbose)
      fprintf(stderr, "Steam Controller 2026: shadowing evdev node %s\n",device);
    close(fd);
    return;
  }

  struct libevdev *evdev = evdev_open_checked(fd, device);
  if (!evdev)
    return;
  const char* name = libevdev_get_name(evdev);
  if (!name)
    name = "Unknown input device";

  /* The event number may have been recycled since Luna's snapshot.
   * Validate the opened fd, including explicit input= paths, not just
   * nodes discovered later through udev. */
  const char *selectors = getenv("MOONLIGHT_INPUT_SELECTORS_V2");
  const char *legacy_names = getenv("MOONLIGHT_INPUT_NAMES_HEX");
  if (selectors || legacy_names) {
    char uniq[256] = {0}, phys[256] = {0};
    int n = ioctl(fd, EVIOCGUNIQ(sizeof(uniq)), uniq);
    if (n < 0 && (errno == EINTR || errno == EAGAIN || errno == EBUSY)) {
      struct stat st;
      char identity[ML_INPUT_IDENTITY_MAX];
      if (fstat(fd, &st) == 0 && udev_input_identity_for_fd(fd, identity, sizeof(identity)))
        udev_schedule_input_retry(device, st.st_rdev, identity);
      libevdev_free(evdev);
      close(fd);
      return;
    }
    if (n <= 0 || n >= (int)sizeof(uniq)) uniq[0] = 0;
    n = ioctl(fd, EVIOCGPHYS(sizeof(phys)), phys);
    if (n < 0 && (errno == EINTR || errno == EAGAIN || errno == EBUSY)) {
      struct stat st;
      char identity[ML_INPUT_IDENTITY_MAX];
      if (fstat(fd, &st) == 0 && udev_input_identity_for_fd(fd, identity, sizeof(identity)))
        udev_schedule_input_retry(device, st.st_rdev, identity);
      libevdev_free(evdev);
      close(fd);
      return;
    }
    if (n <= 0 || n >= (int)sizeof(phys)) phys[0] = 0;
    uniq[sizeof(uniq) - 1] = 0;
    phys[sizeof(phys) - 1] = 0;
    if (!moonlight_selected_identity(selectors, legacy_names, name, uniq, phys)) {
      if (verbose)
        fprintf(stderr, "Ignoring unselected evdev device %s on %s\n", name, device);
      libevdev_free(evdev);
      close(fd);
      return;
    }
  }

  char str_guid[33];
  evdev_mapping_guid(evdev, str_guid);

  struct mapping* default_mapping = NULL;
  struct mapping* xwc_mapping = NULL;
  while (mappings != NULL) {
    if (strncmp(str_guid, mappings->guid, 32) == 0) {
      if (verbose)
        printf("Detected %s (%s) on %s as %s\n", name, str_guid, device, mappings->name);

      break;
    } else if (strncmp("default", mappings->guid, 32) == 0)
      default_mapping = mappings;
    else if (strncmp("xwc", mappings->guid, 32) == 0)
      xwc_mapping = mappings;

    mappings = mappings->next;
  }

  if (mappings == NULL && strstr(name, "Xbox 360 Wireless Receiver") != NULL)
    mappings = xwc_mapping;

  bool is_keyboard = libevdev_has_event_code(evdev, EV_KEY, KEY_Q);
  bool is_mouse = libevdev_has_event_type(evdev, EV_REL) || libevdev_has_event_code(evdev, EV_KEY, BTN_LEFT);
  bool is_touchscreen = libevdev_has_event_code(evdev, EV_KEY, BTN_TOUCH);

  // This classification logic comes from SDL
  bool is_accelerometer =
    ((libevdev_has_event_code(evdev, EV_ABS, ABS_X) &&
      libevdev_has_event_code(evdev, EV_ABS, ABS_Y) &&
      libevdev_has_event_code(evdev, EV_ABS, ABS_Z)) ||
     (libevdev_has_event_code(evdev, EV_ABS, ABS_RX) &&
      libevdev_has_event_code(evdev, EV_ABS, ABS_RY) &&
      libevdev_has_event_code(evdev, EV_ABS, ABS_RZ))) &&
    !libevdev_has_event_type(evdev, EV_KEY);
  bool is_gamepad =
    ((libevdev_has_event_code(evdev, EV_ABS, ABS_X) &&
      libevdev_has_event_code(evdev, EV_ABS, ABS_Y)) ||
     (libevdev_has_event_code(evdev, EV_ABS, ABS_HAT0X) &&
      libevdev_has_event_code(evdev, EV_ABS, ABS_HAT0Y))) &&
    (libevdev_has_event_code(evdev, EV_KEY, BTN_TRIGGER) ||
     libevdev_has_event_code(evdev, EV_KEY, BTN_A) ||
     libevdev_has_event_code(evdev, EV_KEY, BTN_1) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_RX) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_RY) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_RZ) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_THROTTLE) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_RUDDER) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_WHEEL) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_GAS) ||
     libevdev_has_event_code(evdev, EV_ABS, ABS_BRAKE));

  const bool has_remote_back =
      libevdev_has_event_code(evdev, EV_KEY, KEY_BACK) ||
      libevdev_has_event_code(evdev, EV_KEY, KEY_EXIT) ||
      libevdev_has_event_code(evdev, EV_KEY, KEY_ESC);
  const bool has_remote_direction =
      libevdev_has_event_code(evdev, EV_KEY, KEY_UP) ||
      libevdev_has_event_code(evdev, EV_KEY, KEY_DOWN) ||
      libevdev_has_event_code(evdev, EV_KEY, KEY_LEFT) ||
      libevdev_has_event_code(evdev, EV_KEY, KEY_RIGHT);
  const bool has_remote_enter =
      libevdev_has_event_code(evdev, EV_KEY, KEY_ENTER) ||
      libevdev_has_event_code(evdev, EV_KEY, KEY_OK);
  const bool is_remote =
      moonlight_is_known_navigation_remote(name) ||
      moonlight_is_navigation_remote(
          is_keyboard, is_gamepad, has_remote_back,
          has_remote_direction, has_remote_enter);

  if (is_accelerometer) {
    if (verbose)
      printf("Ignoring accelerometer: %s\n", name);
    libevdev_free(evdev);
    close(fd);
    return;
  }

  if (is_gamepad) {
    if (mappings == NULL) {
      fprintf(stderr, "No mapping available for %s (%s) on %s\n", name, str_guid, device);
      mappings = default_mapping;
    }
  } else {
    if (verbose)
      printf("Not mapping %s as a gamepad\n", name);
    mappings = NULL;
  }

  struct input_device *new_device = calloc(1, sizeof(*new_device));
  const bool ff_initialized = new_device &&
      pthread_mutex_init(&new_device->ff_mutex, NULL) == 0;
  const bool wake_initialized = ff_initialized && pthread_cond_init(&new_device->ff_wake, NULL) == 0;
  pthread_mutex_lock(&devices_mutex);
  if (!wake_initialized ||
      !input_slots_append(&devices, &numDevices, new_device)) {
    pthread_mutex_unlock(&devices_mutex);
    fprintf(stderr, "Cannot allocate an input device slot\n");
    if (wake_initialized) pthread_cond_destroy(&new_device->ff_wake);
    if (ff_initialized) pthread_mutex_destroy(&new_device->ff_mutex);
    free(new_device);
    libevdev_free(evdev);
    close(fd);
    return;
  }
  const int dev = numDevices - 1;
  devices[dev]->fd = fd;
  devices[dev]->dev = evdev;
  const int vendor = libevdev_get_id_vendor(evdev);
  const int product = libevdev_get_id_product(evdev);
  devices[dev]->sony_vendor = vendor;
  devices[dev]->sony_product = product;
  devices[dev]->wants_dualsense =
      vendor == 0x054c && (product == 0x0ce6 || product == 0x0df2) &&
      (!getenv("MOONLIGHT_DUALSENSE_HID") ||
       strcmp(getenv("MOONLIGHT_DUALSENSE_HID"), "0") != 0);
  if (strlen(device) < sizeof(devices[dev]->retry_path)) {
    snprintf(devices[dev]->retry_path, sizeof(devices[dev]->retry_path),
             "%s", device);
    struct stat physical = {0};
    if (fstat(fd, &physical) == 0 && S_ISCHR(physical.st_mode))
      devices[dev]->retry_rdev = (unsigned long long)physical.st_rdev;
    if (identity_known)
      memcpy(devices[dev]->retry_identity, current_identity,
             sizeof(current_identity));
  }
  devices[dev]->map = mappings;
  /* Set unused evdev indices to -2 to avoid aliasing with the default -1 in our mappings */
  memset(devices[dev]->key_map, -2, sizeof(devices[dev]->key_map));
  memset(devices[dev]->abs_map, -2, sizeof(devices[dev]->abs_map));
  devices[dev]->is_keyboard = is_keyboard;
  devices[dev]->is_mouse = is_mouse;
  devices[dev]->is_touchscreen = is_touchscreen;
  devices[dev]->is_remote = is_remote;
  /* An unrecognized controller without a mapping cannot send usable
   * gamepad events and must not inflate Sunshine's launch bitmap. */
  devices[dev]->is_gamepad = is_gamepad && mappings != NULL;
  devices[dev]->rotate = rotate;
  devices[dev]->touchDownX = TOUCH_UP;
  devices[dev]->touchDownY = TOUCH_UP;

  int nbuttons = 0;
  /* Count joystick buttons first like SDL does */
  for (int i = BTN_JOYSTICK; i < KEY_MAX; ++i) {
    if (libevdev_has_event_code(devices[dev]->dev, EV_KEY, i))
      devices[dev]->key_map[i] = nbuttons++;
  }
  for (int i = 0; i < BTN_JOYSTICK; ++i) {
    if (libevdev_has_event_code(devices[dev]->dev, EV_KEY, i))
      devices[dev]->key_map[i] = nbuttons++;
  }

  int naxes = 0;
  for (int i = 0; i < ABS_MAX; ++i) {
    /* Skip hats */
    if (i == ABS_HAT0X)
      i = ABS_HAT3Y;
    else if (libevdev_has_event_code(devices[dev]->dev, EV_ABS, i))
      devices[dev]->abs_map[i] = naxes++;
  }

  devices[dev]->controllerId = -1;
  devices[dev]->haptic_effect_id = -1;

  if (devices[dev]->map != NULL) {
    bool valid = evdev_init_parms(devices[dev], &(devices[dev]->xParms), devices[dev]->map->abs_leftx);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->yParms), devices[dev]->map->abs_lefty);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->zParms), devices[dev]->map->abs_lefttrigger);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->rxParms), devices[dev]->map->abs_rightx);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->ryParms), devices[dev]->map->abs_righty);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->rzParms), devices[dev]->map->abs_righttrigger);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->leftParms), devices[dev]->map->abs_dpleft);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->rightParms), devices[dev]->map->abs_dpright);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->upParms), devices[dev]->map->abs_dpup);
    valid &= evdev_init_parms(devices[dev], &(devices[dev]->downParms), devices[dev]->map->abs_dpdown);
    if (!valid) {
      fprintf(stderr, "Mapping for %s (%s) on %s is incorrect\n", name, str_guid, device);
      devices[dev]->map = NULL;
      devices[dev]->is_gamepad = false;
    }
  }

  if (devices[dev]->is_gamepad) {
    unsigned int hats_mask = 0;
    for (unsigned int h = 0; h < 4; ++h) {
      if (libevdev_has_event_code(devices[dev]->dev, EV_ABS, ABS_HAT0X + 2 * h) ||
          libevdev_has_event_code(devices[dev]->dev, EV_ABS, ABS_HAT0Y + 2 * h))
        hats_mask |= 1U << h;
    }
    if (!moonlight_mapping_has_usable_bindings(devices[dev]->map,
                                               nbuttons, naxes, hats_mask)) {
      fprintf(stderr, "Gamepad %s has no usable mapped controls; not advertising it\n", name);
      devices[dev]->map = NULL;
      devices[dev]->is_gamepad = false;
    }
  }

  if (grabbingDevices && (is_keyboard || is_mouse || is_touchscreen)) {
    if (ioctl(fd, EVIOCGRAB, 1) < 0) {
      fprintf(stderr, "EVIOCGRAB failed with error %d\n", errno);
    }
  }

  /* Attempt only for a mapped gamepad; the HID bridge checks Sony IDs,
   * a matching kernel parent and availability. Normal evdev survives failure. */
  if (devices[dev]->is_gamepad)
    devices[dev]->dualsense = dualsense_attach(fd, vendor, product);
  if (!loop_try_add_device_fd(devices[dev]->fd, &evdev_handle,
                              &evdev_handle_invalid, POLLIN)) {
    /* Evict only this UNPUBLISHED node. A previous gamepad's count cannot
     * be decremented, and no other controller should lose its session. */
    const int allocation_error = errno;
    char retry_path[sizeof(devices[dev]->retry_path)];
    char retry_identity[sizeof(devices[dev]->retry_identity)];
    snprintf(retry_path, sizeof(retry_path), "%s", devices[dev]->retry_path);
    memcpy(retry_identity, devices[dev]->retry_identity, sizeof(retry_identity));
    const unsigned long long retry_rdev = devices[dev]->retry_rdev;
    devices[dev]->is_gamepad = false;
    pthread_mutex_unlock(&devices_mutex);
    fprintf(stderr, "Input event registration failed for %s: %s; retrying node\n",
            device, strerror(allocation_error));
    evdev_remove(dev);
    if (retry_path[0] && retry_identity[0])
      udev_schedule_input_retry(retry_path, retry_rdev, retry_identity);
    return;
  }
  udev_cancel_input_retry(devices[dev]->retry_path,
                          devices[dev]->retry_rdev);
  if (devices[dev]->wants_dualsense && devices[dev]->is_gamepad)
    udev_schedule_advanced_retry();
  /* Count only successfully registered devices. Failed allocations must
   * never advertise a nonexistent controller in Sunshine's launch mask. */
  if (devices[dev]->is_gamepad)
    ++evdev_gamepads;
  pthread_mutex_unlock(&devices_mutex);
}

void evdev_create(const char* device, struct mapping* mappings,
                  bool verbose, int rotate) {
  evdev_create_internal(device, mappings, verbose, rotate, NULL);
}

void evdev_create_verified(const char* device, struct mapping* mappings,
                           bool verbose, int rotate,
                           const char *expected_identity) {
  if (!expected_identity || !*expected_identity) return;
  evdev_create_internal(device, mappings, verbose, rotate, expected_identity);
}

static bool evdev_map_key(char* keyName, short* key) {
  printf("Press %s\n", keyName);
  currentKey = key;
  currentHat = NULL;
  currentHatDir = NULL;
  currentAbs = NULL;
  currentReverse = NULL;
  currentHalfAxis = NULL;
  *key = -1;
  if (loop_main() != LOOP_OK) {
    fprintf(stderr, "Controller mapping interrupted by input I/O error\n");
    return false;
  }
  usleep(250000);
  evdev_drain();
  return *key >= 0;
}

static bool evdev_map_abs(char* keyName, short* abs, bool* reverse) {
  printf("Move %s\n", keyName);
  currentKey = NULL;
  currentHat = NULL;
  currentHatDir = NULL;
  currentAbs = abs;
  currentReverse = reverse;
  currentHalfAxis = NULL;
  evdev_snapshot_mapping_rest();
  *abs = -1;
  if (loop_main() != LOOP_OK) {
    fprintf(stderr, "Controller mapping interrupted by input I/O error\n");
    return false;
  }
  usleep(250000);
  evdev_drain();
  return *abs >= 0;
}

static bool evdev_map_hatkey(char* keyName, short* hat, short* hat_dir, short* key) {
  printf("Press %s\n", keyName);
  currentKey = key;
  currentHat = hat;
  currentHatDir = hat_dir;
  currentAbs = NULL;
  currentReverse = NULL;
  currentHalfAxis = NULL;
  *key = -1;
  *hat = -1;
  *hat_dir = -1;
  if (loop_main() != LOOP_OK) {
    fprintf(stderr, "Controller mapping interrupted by input I/O error\n");
    return false;
  }
  usleep(250000);
  evdev_drain();
  return (*hat >= 0 && moonlight_mapping_hat_pressed(*hat_dir)) ||
         *key >= 0;
}

static bool evdev_map_abskey(char* keyName, short* abs, short* key, char* halfaxis) {
  printf("Press %s\n", keyName);
  currentKey = key;
  currentHat = NULL;
  currentHatDir = NULL;
  currentAbs = abs;
  currentReverse = NULL;
  currentHalfAxis = halfaxis;
  evdev_snapshot_mapping_rest();
  *key = -1;
  *abs = -1;
  *halfaxis = 0;
  if (loop_main() != LOOP_OK) {
    fprintf(stderr, "Controller mapping interrupted by input I/O error\n");
    return false;
  }
  usleep(250000);
  evdev_drain();
  return *abs >= 0 || *key >= 0;
}

bool evdev_map(char* device) {
  /* The device must already be registered for event-loop mapping.
   * If evdev_create failed, waiting here would hang indefinitely. */
  if (numDevices == 0) {
    fprintf(stderr, "Controller mapping aborted: no registered input device\n");
    return false;
  }
  int fd = open(device, O_RDONLY|O_NONBLOCK);
  if (fd < 0) {
    fprintf(stderr, "Cannot open input mapping device %s: %s\n",
            device, strerror(errno));
    return false;
  }
  struct libevdev *evdev = evdev_open_checked(fd, device);
  if (!evdev)
    return false;
  const char* name = libevdev_get_name(evdev);
  if (!name)
    name = "Unknown input device";

  char str_guid[33];
  evdev_mapping_guid(evdev, str_guid);

  struct mapping map = {0};
  /* The mapping parser's sentinel is -1, not zero. Leaving optional
   * controls at zero would serialize them as fictitious b0/a0 mappings. */
  memset(&map.abs_leftx, 0xff,
         offsetof(struct mapping, next) - offsetof(struct mapping, abs_leftx));
  strncpy(map.name, name, sizeof(map.name) - 1);
  strncpy(map.guid, str_guid, sizeof(map.guid) - 1);

  libevdev_free(evdev);
  close(fd);

  handler = evdev_handle_mapping_event;

#define MAP_STEP(call) do { \
  if (!(call)) { \
    fprintf(stderr, "Controller mapping failed; partial configuration discarded\n"); \
    return false; \
  } \
} while (0)
  MAP_STEP(evdev_map_abs("Left Stick Right", &(map.abs_leftx), &(map.reverse_leftx)));
  MAP_STEP(evdev_map_abs("Left Stick Down", &(map.abs_lefty), &(map.reverse_lefty)));
  MAP_STEP(evdev_map_key("Left Stick Button", &(map.btn_leftstick)));

  MAP_STEP(evdev_map_abs("Right Stick Right", &(map.abs_rightx), &(map.reverse_rightx)));
  MAP_STEP(evdev_map_abs("Right Stick Down", &(map.abs_righty), &(map.reverse_righty)));
  MAP_STEP(evdev_map_key("Right Stick Button", &(map.btn_rightstick)));

  MAP_STEP(evdev_map_hatkey("D-Pad Right", &(map.hat_dpright), &(map.hat_dir_dpright), &(map.btn_dpright)));
  MAP_STEP(evdev_map_hatkey("D-Pad Left", &(map.hat_dpleft), &(map.hat_dir_dpleft), &(map.btn_dpleft)));
  MAP_STEP(evdev_map_hatkey("D-Pad Up", &(map.hat_dpup), &(map.hat_dir_dpup), &(map.btn_dpup)));
  MAP_STEP(evdev_map_hatkey("D-Pad Down", &(map.hat_dpdown), &(map.hat_dir_dpdown), &(map.btn_dpdown)));

  MAP_STEP(evdev_map_key("Button X (1)", &(map.btn_x)));
  MAP_STEP(evdev_map_key("Button A (2)", &(map.btn_a)));
  MAP_STEP(evdev_map_key("Button B (3)", &(map.btn_b)));
  MAP_STEP(evdev_map_key("Button Y (4)", &(map.btn_y)));
  MAP_STEP(evdev_map_key("Back Button", &(map.btn_back)));
  MAP_STEP(evdev_map_key("Start Button", &(map.btn_start)));
  MAP_STEP(evdev_map_key("Special Button", &(map.btn_guide)));

  MAP_STEP(evdev_map_abskey("Left Trigger", &(map.abs_lefttrigger),
                            &(map.btn_lefttrigger), &(map.halfaxis_lefttrigger)));
  MAP_STEP(evdev_map_abskey("Right Trigger", &(map.abs_righttrigger),
                            &(map.btn_righttrigger), &(map.halfaxis_righttrigger)));

  MAP_STEP(evdev_map_key("Left Bumper", &(map.btn_leftshoulder)));
  MAP_STEP(evdev_map_key("Right Bumper", &(map.btn_rightshoulder)));
  mapping_print(&map);
#undef MAP_STEP
  return true;
}

/* Advanced HID commands arrive on common-c worker threads. Coalesce each
 * controller's latest LED and trigger commands under devices_mutex, and hand
 * desired state to per-device output workers from the main input loop. */
static void evdev_wake_dualsense_output(void) {
  __atomic_store_n(&dualsense_output_due_ms, 0, __ATOMIC_RELEASE);
  if (!__atomic_load_n(&dualsense_output_online, __ATOMIC_ACQUIRE) ||
      dualsense_output_fd < 0) return;
  uint64_t one = 1;
  (void)write(dualsense_output_fd, &one, sizeof(one));
}

static void evdev_retry_dualsense_output_later(void) {
  __atomic_store_n(&dualsense_output_due_ms, evdev_now_ms() + dualsense_output_retry_ms, __ATOMIC_RELEASE);
  if (dualsense_output_retry_fd < 0 ||
      !__atomic_load_n(&dualsense_output_online, __ATOMIC_ACQUIRE))
    return;
  /* No busy wait on nonblocking HID. Repeated EAGAIN backs off from
   * 10 ms to 250 ms; each input callback attempts a complete report once. */
  struct itimerspec timer = {0};
  timer.it_value.tv_sec = dualsense_output_retry_ms / 1000U;
  timer.it_value.tv_nsec = (long)(dualsense_output_retry_ms % 1000U) * 1000000L;
  (void)timerfd_settime(dualsense_output_retry_fd, 0, &timer, NULL);
  if (dualsense_output_retry_ms < 250U)
    dualsense_output_retry_ms =
        dualsense_output_retry_ms * 2U > 250U ? 250U :
        dualsense_output_retry_ms * 2U;
}

static int evdev_flush_dualsense_output(int fd) {
  uint64_t wakes = 0;
  if (fd >= 0) (void)read(fd, &wakes, sizeof(wakes)); /* Both eventfd and timerfd are 8B. */
  if (!__atomic_load_n(&dualsense_output_online, __ATOMIC_ACQUIRE))
    return LOOP_OK;
  bool retry_needed = false;
  for (int i = 0; i < numDevices; ++i) {
    pthread_mutex_lock(&devices_mutex);
    struct input_device *dev = devices[i];
    moonlight_dualsense *bridge = dev->dualsense;
    const bool led = dev->ds_led_pending;
    const bool adaptive = dev->ds_adaptive_pending;
    const uint64_t led_revision = dev->ds_led_revision;
    const uint64_t adaptive_revision = dev->ds_adaptive_revision;
    uint8_t color[3], left[10], right[10];
    memcpy(color, dev->ds_led_color, sizeof(color));
    memcpy(left, dev->ds_left, sizeof(left));
    memcpy(right, dev->ds_right, sizeof(right));
    const uint8_t flags = dev->ds_adaptive_flags;
    const uint8_t lt = dev->ds_left_type, rt = dev->ds_right_type;
    pthread_mutex_unlock(&devices_mutex);

    /* The main input-loop thread alone detaches bridges. A failed bridge
     * keeps its desired state until the independent reattach succeeds. */
    if (!bridge || !dualsense_hid_healthy(bridge)) continue;
    if (led) {
      const int result = dualsense_led_try(bridge, color[0], color[1], color[2]);
      if (result == ML_DS_SEND_RETRY) {
        retry_needed = true;
        continue; /* Do not overtake the pending LED report with triggers. */
      }
      if (result == ML_DS_SEND_FAILED)
        continue; /* HID recovery will replay latest desired state. */
      pthread_mutex_lock(&devices_mutex);
      if (dev->ds_led_revision == led_revision)
        dev->ds_led_pending = false;
      pthread_mutex_unlock(&devices_mutex);
    }
    if (adaptive && dualsense_hid_healthy(bridge)) {
      const int result = dualsense_adaptive_try(bridge, flags, lt, rt, left, right);
      if (result == ML_DS_SEND_RETRY) {
        retry_needed = true;
      } else if (result == ML_DS_SEND_OK) {
        pthread_mutex_lock(&devices_mutex);
        if (dev->ds_adaptive_revision == adaptive_revision)
          dev->ds_adaptive_pending = false;
        pthread_mutex_unlock(&devices_mutex);
      }
    }
  }
  if (retry_needed) evdev_retry_dualsense_output_later();
  else dualsense_output_retry_ms = 10;
  return LOOP_OK;
}

bool evdev_retry_dualsense_bridges(void) {
  /* Called only by the udev retry timer on the input-loop thread. Never
   * reopen the same hidraw/ALSA node while its previous bridge is closing. */
  bool pending = false;
  for (int i = 0; i < numDevices; ++i) {
    struct input_device *dev = devices[i];
    if (!dev->is_gamepad || !dev->wants_dualsense) continue;
    pending = true; /* Periodically notice an independently failed PCM worker. */
    if (dualsense_hid_healthy(dev->dualsense)) {
      pthread_mutex_lock(&devices_mutex);
      const bool changed = dualsense_retry_audio(dev->dualsense, dev->fd);
      pthread_mutex_unlock(&devices_mutex);
      if (changed && dev->controllerId >= 0) send_controller_arrival(dev);
      if (dualsense_hid_healthy(dev->dualsense)) continue;
    }
    pthread_mutex_lock(&devices_mutex);
    moonlight_dualsense *old = dev->dualsense;
    dev->dualsense = NULL; /* no new host feedback can borrow old */
    pthread_mutex_unlock(&devices_mutex);
    /* Teardown is handed to a separate worker. Wait for its completion on
     * later timer ticks before reopening this controller's hidraw/PCM node. */
    if (old) {
      dualsense_detach(old);
      pending = true;
      continue;
    }
    if (dualsense_cleanup_pending_for(dev->fd)) continue;
    moonlight_dualsense *next = dualsense_attach(dev->fd,
                                                 dev->sony_vendor, dev->sony_product);
    pthread_mutex_lock(&devices_mutex);
    dev->dualsense = next;
    if (next) {
      if (dev->controllerId >= 0)
        dualsense_set_player(next, dev->controllerId);
      dualsense_motion_request(next, LI_MOTION_TYPE_ACCEL, dev->ds_motion_rates[0]);
      dualsense_motion_request(next, LI_MOTION_TYPE_GYRO, dev->ds_motion_rates[1]);
      /* Replay only persistent host intent, not expired PCM packets. */
      if (dev->ds_led_desired) dev->ds_led_pending = true;
      if (dev->ds_adaptive_desired) dev->ds_adaptive_pending = true;
    }
    pthread_mutex_unlock(&devices_mutex);
    if (next && dev->controllerId >= 0)
      send_controller_arrival(dev); /* Re-advertise restored capabilities. */
    if (next) evdev_wake_dualsense_output();
    if (!next) pending = true;
  }
  return pending;
}

void evdev_start() {
  // After grabbing, the only way to quit via the keyboard
  // is via the special key combo that the input handling
  // code looks for. For this reason, we wait to grab until
  // we're ready to take input events. Ctrl+C works up until
  // this point.
  for (int i = 0; i < numDevices; i++) {
    if ((devices[i]->is_keyboard || devices[i]->is_mouse || devices[i]->is_touchscreen) && ioctl(devices[i]->fd, EVIOCGRAB, 1) < 0) {
      fprintf(stderr, "EVIOCGRAB failed with error %d\n", errno);
    }
  }

  // Any new input devices detected after this point will be grabbed immediately
  grabbingDevices = true;
  __atomic_store_n(&dualsense_output_online, true, __ATOMIC_RELEASE);
  evdev_wake_dualsense_output(); /* Flush any host command queued at startup. */

  // Handle input events until the quit combo is pressed
}

void evdev_stop() {
  /* Quiesce host callbacks under the lifetime lock. A stuck mouse worker
   * must not outlive common-c queue teardown; escalate to Luna recovery. */
  pthread_mutex_lock(&devices_mutex);
  grabbingDevices = false;
  __atomic_store_n(&dualsense_output_online, false, __ATOMIC_RELEASE);
  pthread_mutex_unlock(&devices_mutex);
  dualsense_output_retry_ms = 10;
  if (dualsense_output_retry_fd >= 0) {
    const struct itimerspec disarm = {0};
    (void)timerfd_settime(dualsense_output_retry_fd, 0, &disarm, NULL);
  }
  for (int i = 0; i < numDevices; ++i) {
    pthread_mutex_lock(&devices_mutex);
    struct input_device *device = devices[i];
    __atomic_store_n(&device->mouseEmulation, false, __ATOMIC_RELEASE);
    moonlight_dualsense *dualsense = device->dualsense;
    device->dualsense = NULL; /* No new common-c callback can borrow it. */
    pthread_mutex_unlock(&devices_mutex);
    dualsense_detach(dualsense);
  }
  /* Retired hotplug workers are included in this count even though they no
   * longer have an evdev slot. Do not call LiStopConnection while any
   * worker could still be inside LiSendMouseMoveEvent(). */
  struct timespec deadline;
  if (clock_gettime(CLOCK_REALTIME, &deadline) != 0) {
    fprintf(stderr, "Input: cannot time mouse worker teardown; Luna recovery required\n");
    _exit(124);
  }
  deadline.tv_nsec += 250000000L;
  deadline.tv_sec += deadline.tv_nsec / 1000000000L;
  deadline.tv_nsec %= 1000000000L;
  pthread_mutex_lock(&devices_mutex);
  while (mouse_workers_active &&
         pthread_cond_timedwait(&mouse_workers_drained, &devices_mutex, &deadline) == 0)
    ;
  const bool mouse_pending = mouse_workers_active != 0;
  pthread_mutex_unlock(&devices_mutex);
  if (mouse_pending) {
    fprintf(stderr, "Input: mouse-emulation callback still active; exiting for Luna recovery\n");
    _exit(124);
  }
  dualsense_cleanup_shutdown(); /* Bounded 250 ms, never an unbounded join. */
  evdev_drain();
}

static int evdev_tick(int ignored) {
  (void)ignored;
  sc26_poll_main();
  if (dualsense_completions_pending()) (void)evdev_retry_dualsense_bridges();
  for (int i = 0; i < numDevices; ++i) {
    if (devices[i]->read_pending) {
      int rc = evdev_handle(devices[i]->fd);
      if (rc != LOOP_OK) return rc;
    }
  }
  pthread_mutex_lock(&devices_mutex);
  for (int i = 0; i < numDevices; ++i)
    if (devices[i]->ff_pending && !devices[i]->ff_worker_started)
      evdev_queue_ff_locked(devices[i], devices[i]->ff_low, devices[i]->ff_high);
  pthread_mutex_unlock(&devices_mutex);
  /* Also covers allocation/arming failures of output notification fds. */
  if (evdev_now_ms() >= __atomic_load_n(&dualsense_output_due_ms, __ATOMIC_ACQUIRE))
    return evdev_flush_dualsense_output(-1);
  return LOOP_OK;
}

void evdev_init(bool mouse_emulation_enabled) {
  loop_set_input_tick_handler(evdev_tick);
  handler = evdev_handle_event;
  mouseEmulationEnabled = mouse_emulation_enabled;
  if (dualsense_output_fd < 0) {
    dualsense_output_fd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    if (dualsense_output_fd >= 0 &&
        !loop_try_add_fd(dualsense_output_fd, evdev_flush_dualsense_output, POLLIN)) {
      fprintf(stderr, "Input: DualSense output eventfd registration failed\n");
      close(dualsense_output_fd);
      dualsense_output_fd = -1;
    }
  }
  if (dualsense_output_retry_fd < 0) {
    dualsense_output_retry_fd =
        timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK | TFD_CLOEXEC);
    if (dualsense_output_retry_fd >= 0 &&
        !loop_try_add_fd(dualsense_output_retry_fd,
                         evdev_flush_dualsense_output, POLLIN)) {
      fprintf(stderr, "Input: DualSense output timer registration failed\n");
      close(dualsense_output_retry_fd);
      dualsense_output_retry_fd = -1;
    }
  }
}

/* Caller must hold devices_mutex throughout use of the returned pointer. */
static struct input_device* evdev_get_input_device(unsigned short controller_id) {
  for (int i=0; i<numDevices; i++)
    if (devices[i]->controllerId == controller_id)
      return devices[i];

  return NULL;
}

/* Caller holds devices_mutex. The duplicated descriptor and reference
 * remain valid even after evdev_remove drops the physical slot and closes
 * its original fd. Kernel FF writes are never under devices_mutex. */
static int evdev_ff_get_locked(struct input_device *device) {
  if (!device || __atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE))
    return -1;
  const int fd = fcntl(device->fd, F_DUPFD_CLOEXEC, 0);
  if (fd >= 0) ++device->ff_refs;
  return fd;
}

static void evdev_ff_put(struct input_device *device) {
  bool last = false;
  pthread_mutex_lock(&devices_mutex);
  if (--device->ff_refs == 0 &&
      __atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE) &&
      device->ff_cleanup_done && device->mouse_refs == 0)
    last = true;
  pthread_mutex_unlock(&devices_mutex);
  if (last)
    evdev_free_retired_device(device);
}

static void *evdev_ff_worker(void *arg) {
  struct input_device *device = arg;
  const int fd = device->ff_worker_fd;
  for (;;) {
    pthread_mutex_lock(&devices_mutex);
    while (!device->ff_pending && !__atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE))
      pthread_cond_wait(&device->ff_wake, &devices_mutex);
    if (__atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE)) {
      device->ff_worker_started = false;
      pthread_mutex_unlock(&devices_mutex);
      break;
    }
    const unsigned short low_freq_motor = device->ff_low, high_freq_motor = device->ff_high;
    device->ff_pending = false;
    pthread_mutex_unlock(&devices_mutex);
  /* Per-device serialization protects the effect id and prevents a delayed
   * rumble command from overtaking another one for the same controller. */
  bool failed = false;
  pthread_mutex_lock(&device->ff_mutex);
  if (!__atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE)) {
    if (device->haptic_effect_id >= 0) {
      if (ioctl(fd, EVIOCRMFF, device->haptic_effect_id) == 0 || errno == EINVAL)
        device->haptic_effect_id = -1;
      else failed = true;
    }
    if (!failed && (low_freq_motor || high_freq_motor)) {
      struct ff_effect effect = {0};
      effect.type = FF_RUMBLE;
      effect.id = -1;
      effect.replay.length = USHRT_MAX;
      effect.u.rumble.strong_magnitude = low_freq_motor;
      effect.u.rumble.weak_magnitude = high_freq_motor;
      if (ioctl(fd, EVIOCSFF, &effect) != -1 &&
          !__atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE)) {
        struct input_event event = {0};
        event.type = EV_FF;
        event.code = effect.id;
        event.value = 1;
        device->haptic_effect_id = effect.id;
        failed = write(fd, &event, sizeof(event)) != sizeof(event);
      } else failed = true;
    }
  }
  pthread_mutex_unlock(&device->ff_mutex);
  if (failed) {
    pthread_mutex_lock(&devices_mutex);
    if (!__atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE)) device->ff_pending = true;
    pthread_mutex_unlock(&devices_mutex);
    struct timespec delay = {.tv_nsec = 100000000};
    nanosleep(&delay, NULL); /* Bounded retry; no shared lock while waiting. */
  }
  }
  close(fd);
  evdev_ff_put(device);
  return NULL;
}

static void evdev_queue_ff_locked(struct input_device *device, unsigned short low,
                                  unsigned short high) {
  if (__atomic_load_n(&device->ff_retired, __ATOMIC_ACQUIRE)) return;
  device->ff_low = low;
  device->ff_high = high;
  device->ff_pending = true;
  if (device->ff_worker_started) { pthread_cond_signal(&device->ff_wake); return; }
  if (evdev_now_ms() < device->ff_retry_after) return;
  device->ff_retry_after = evdev_now_ms() + 1000;
  int fd = evdev_ff_get_locked(device);
  if (fd < 0) return;
  device->ff_worker_fd = fd;
  device->ff_worker_started = true;
  pthread_t worker;
  if (pthread_create(&worker, NULL, evdev_ff_worker, device) != 0) {
    device->ff_worker_started = false;
    --device->ff_refs;
    close(fd);
  } else pthread_detach(worker);
}

void evdev_rumble(unsigned short controller_id, unsigned short low_freq_motor,
                  unsigned short high_freq_motor) {
  pthread_mutex_lock(&devices_mutex);
  struct input_device *device = evdev_get_input_device(controller_id);
  if (device && evdev_supports_rumble(device->dev) &&
      !(device->dualsense && dualsense_waveform_active(device->dualsense)))
    evdev_queue_ff_locked(device, low_freq_motor, high_freq_motor);
  pthread_mutex_unlock(&devices_mutex);
}

/* All host callbacks run on common-c workers. Serialize HID output with
 * evdev removal and stream teardown under the existing lifetime lock. */
void evdev_set_motion_event_state(unsigned short controller_id, unsigned char type, unsigned short rate) {
  pthread_mutex_lock(&devices_mutex);
  struct input_device *device = evdev_get_input_device(controller_id);
  if (device && device->wants_dualsense) {
    if (rate > 250) rate = 250;
    if (type == LI_MOTION_TYPE_ACCEL)
      device->ds_motion_rates[0] = rate;
    else if (type == LI_MOTION_TYPE_GYRO)
      device->ds_motion_rates[1] = rate;
    if (device->dualsense)
      dualsense_motion_request(device->dualsense, type, rate);
  }
  pthread_mutex_unlock(&devices_mutex);
}
void evdev_set_controller_led(unsigned short controller_id, unsigned char r, unsigned char g, unsigned char b) {
  pthread_mutex_lock(&devices_mutex);
  struct input_device *device = evdev_get_input_device(controller_id);
  if (device && device->wants_dualsense) {
    device->ds_led_color[0] = r;
    device->ds_led_color[1] = g;
    device->ds_led_color[2] = b;
    device->ds_led_pending = true;
    device->ds_led_desired = true;
    ++device->ds_led_revision;
    if (dualsense_hid_healthy(device->dualsense))
      evdev_wake_dualsense_output();
  }
  pthread_mutex_unlock(&devices_mutex);
}
void evdev_set_adaptive_triggers(unsigned short controller_id, unsigned char flags,
                                  unsigned char left_type, unsigned char right_type,
                                  unsigned char *left, unsigned char *right) {
  pthread_mutex_lock(&devices_mutex);
  struct input_device *device = evdev_get_input_device(controller_id);
  if (device && device->wants_dualsense &&
      (!(flags & 0x08) || left) && (!(flags & 0x04) || right)) {
    device->ds_adaptive_flags |= flags & 0x0c;
    if (flags & 0x08) {
      device->ds_left_type = left_type;
      memcpy(device->ds_left, left, sizeof(device->ds_left));
    }
    if (flags & 0x04) {
      device->ds_right_type = right_type;
      memcpy(device->ds_right, right, sizeof(device->ds_right));
    }
    device->ds_adaptive_pending = true;
    device->ds_adaptive_desired = true;
    ++device->ds_adaptive_revision;
    if (dualsense_hid_healthy(device->dualsense))
      evdev_wake_dualsense_output();
  }
  pthread_mutex_unlock(&devices_mutex);
}

/* The Nonary Moonlight-common control receiver borrows its PCM payload for
 * the callback duration. Copy a bounded portion under our existing lifetime
 * lock and leave HID/ALSA output entirely to the controller worker. */
void evdev_receive_haptics(uint16_t controller_id, uint32_t sequence,
                           const uint8_t *pcm, uint16_t frames) {
  if (!pcm || frames == 0 || frames > 240) return;
  pthread_mutex_lock(&devices_mutex);
  struct input_device *device = evdev_get_input_device(controller_id);
  if (device && device->dualsense) {
    dualsense_receive_haptics(device->dualsense, sequence, pcm, frames);
    if (dualsense_waveform_active(device->dualsense))
      evdev_queue_ff_locked(device, 0, 0);
  }
  pthread_mutex_unlock(&devices_mutex);
}
void evdev_receive_speaker(uint16_t controller_id, uint64_t owner,
                           uint32_t generation, uint32_t sequence, uint64_t position,
                           uint16_t flags, const uint8_t *pcm, uint16_t frames) {
  if (!pcm || frames == 0 || frames > 240) return;
  pthread_mutex_lock(&devices_mutex);
  struct input_device *dev = evdev_get_input_device(controller_id);
  if (dev && dev->dualsense)
    dualsense_receive_speaker(dev->dualsense, owner, generation, sequence,
                              position, flags, pcm, frames);
  pthread_mutex_unlock(&devices_mutex);
}

/* Serialize mask snapshots with slot changes and queue submission. */
void evdev_publish_state(short slot,int buttons,unsigned char lt,unsigned char rt,
                         short lx,short ly,short rx,short ry) {
  pthread_mutex_lock(&devices_mutex);
  LiSendMultiControllerEvent(slot,assignedControllerIds,buttons,lt,rt,lx,ly,rx,ry);
  pthread_mutex_unlock(&devices_mutex);
}
static void evdev_publish_arrival_locked(short slot,unsigned char type,unsigned int buttons,
                           unsigned short caps,uint64_t speaker) {
  if(speaker)LiSendControllerSpeakerArrivalEvent(slot,assignedControllerIds,type,buttons,caps,speaker);
  else LiSendControllerArrivalEvent(slot,assignedControllerIds,type,buttons,caps);
}
int evdev_steam_claim_arrival(unsigned char type,unsigned int buttons,unsigned short caps) {
  pthread_mutex_lock(&devices_mutex);
  int slot=moonlight_first_free_gamepad_slot((unsigned)assignedControllerIds);
  if(slot>=0) {
    assignedControllerIds|=1U<<slot;steam_reserved_mask|=1U<<slot;
    evdev_publish_arrival_locked(slot,type,buttons,caps,0);
  }
  pthread_mutex_unlock(&devices_mutex);return slot;
}
uint16_t evdev_steam_release_event(int slot,bool online) {
  pthread_mutex_lock(&devices_mutex);
  if(slot>=0&&slot<MAX_GAMEPADS&&(steam_reserved_mask&(1U<<slot))) {
    if(online)LiSendMultiControllerEvent(slot,assignedControllerIds,0,0,0,0,0,0,0);
    steam_reserved_mask&=~(1U<<slot);assignedControllerIds&=~(1U<<slot);
    gamepad_capacity_warned=false;
    if(online)LiSendMultiControllerEvent(slot,assignedControllerIds,0,0,0,0,0,0,0);
  }
  uint16_t mask=(uint16_t)assignedControllerIds;
  pthread_mutex_unlock(&devices_mutex);return mask;
}
/* The evdev slot bitmap is the source of truth; keep a separate Steam
 * reservation bit so an old disconnect cannot clear an evdev gamepad slot. */
int evdev_steam_claim_slot(uint16_t *mask) {
  pthread_mutex_lock(&devices_mutex);
  int slot=moonlight_first_free_gamepad_slot((unsigned)assignedControllerIds);
  if(slot>=0) {
    assignedControllerIds|=1U<<slot;
    steam_reserved_mask|=1U<<slot;
  }
  if(mask)*mask=(uint16_t)assignedControllerIds;
  pthread_mutex_unlock(&devices_mutex);
  return slot;
}
uint16_t evdev_steam_release_slot(int slot) {
  pthread_mutex_lock(&devices_mutex);
  if(slot>=0&&slot<MAX_GAMEPADS&&(steam_reserved_mask&(1U<<slot))) {
    steam_reserved_mask&=~(1U<<slot);
    assignedControllerIds&=~(1U<<slot);
    gamepad_capacity_warned=false;
  }
  uint16_t mask=(uint16_t)assignedControllerIds;
  pthread_mutex_unlock(&devices_mutex);
  return mask;
}
uint16_t evdev_steam_mask(void) {
  pthread_mutex_lock(&devices_mutex);
  uint16_t mask=(uint16_t)assignedControllerIds;
  pthread_mutex_unlock(&devices_mutex);
  return mask;
}
bool evdev_steam_conflict_parent(const char *parent) {
  if(!parent||!parent[0])return false;
  struct udev *u=udev_new();
  if(!u)return true; /* Unknown ownership: leave generic evdev alone. */
  bool conflict=false;
  pthread_mutex_lock(&devices_mutex);
  for(int i=0;i<numDevices;++i) {
    struct stat st;
    if(fstat(devices[i]->fd,&st)<0||!S_ISCHR(st.st_mode))continue;
    struct udev_device *event=udev_device_new_from_devnum(u,'c',st.st_rdev);
    struct udev_device *hid=event?
        udev_device_get_parent_with_subsystem_devtype(event,"hid",NULL):NULL;
    const char *path=hid?udev_device_get_syspath(hid):NULL;
    if(path&&!strcmp(path,parent))conflict=true;
    if(event)udev_device_unref(event);
    if(conflict)break;
  }
  pthread_mutex_unlock(&devices_mutex);
  udev_unref(u);
  return conflict;
}
