/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include "mapping.h"
#include "mapping_axis.h"
#include <stdint.h>

struct mapping_sample { int value, minimum, maximum, flat; };
typedef bool (*mapping_read_source)(void *, const struct mapping_binding *,
                                    struct mapping_sample *);
/* Enumerate every physical contributor without changing the legacy parser or
 * its serialized format. Shared by aggregation and arrival capabilities. */
#define MAPPING_BINDING_MAX (MAPPING_EXTRA_MAX + 40)
static inline unsigned mapping_bindings(const struct mapping *m,
                                        struct mapping_binding out[MAPPING_BINDING_MAX]) {
  unsigned n = 0;
  for (unsigned i = 0; i < m->extra_count && i < MAPPING_EXTRA_MAX; ++i)
    out[n++] = m->extra[i];
#define ADD(src, idx, dst, halfaxis, reversed, dir) do { \
  if ((idx) >= 0) out[n++] = (struct mapping_binding){ \
    .source=(src), .index=(idx), .destination=(dst), .half=(halfaxis), \
    .invert=(reversed), .direction=(dir)}; \
} while (0)
  ADD('a', m->abs_leftx, 0, 0, m->reverse_leftx, 0);
  ADD('a', m->abs_lefty, 1, 0, m->reverse_lefty, 0);
  ADD('a', m->abs_rightx, 2, 0, m->reverse_rightx, 0);
  ADD('a', m->abs_righty, 3, 0, m->reverse_righty, 0);
  ADD('a', m->abs_lefttrigger, 4, m->halfaxis_lefttrigger, false, 0);
  ADD('b', m->btn_lefttrigger, 4, 0, false, 0);
  ADD('a', m->abs_righttrigger, 5, m->halfaxis_righttrigger, false, 0);
  ADD('b', m->btn_righttrigger, 5, 0, false, 0);
  ADD('b', m->btn_a, 6, 0, false, 0);
  ADD('b', m->btn_b, 7, 0, false, 0);
  ADD('b', m->btn_x, 8, 0, false, 0);
  ADD('b', m->btn_y, 9, 0, false, 0);
  ADD('b', m->btn_back, 10, 0, false, 0);
  ADD('b', m->btn_start, 11, 0, false, 0);
  ADD('b', m->btn_guide, 12, 0, false, 0);
  ADD('b', m->btn_leftstick, 13, 0, false, 0);
  ADD('b', m->btn_rightstick, 14, 0, false, 0);
  ADD('b', m->btn_leftshoulder, 15, 0, false, 0);
  ADD('b', m->btn_rightshoulder, 16, 0, false, 0);
  ADD('b', m->btn_dpup, 17, 0, false, 0);
  ADD('b', m->btn_dpdown, 18, 0, false, 0);
  ADD('b', m->btn_dpleft, 19, 0, false, 0);
  ADD('b', m->btn_dpright, 20, 0, false, 0);
  ADD('b', m->btn_misc1, 21, 0, false, 0);
  ADD('b', m->btn_paddle1, 22, 0, false, 0);
  ADD('b', m->btn_paddle2, 23, 0, false, 0);
  ADD('b', m->btn_paddle3, 24, 0, false, 0);
  ADD('b', m->btn_paddle4, 25, 0, false, 0);
  ADD('b', m->btn_touchpad, 26, 0, false, 0);
  ADD('a', m->abs_dpup, 17, m->halfaxis_dpup, false, 0);
  ADD('h', m->hat_dpup, 17, 0, false, m->hat_dir_dpup);
  ADD('a', m->abs_dpdown, 18, m->halfaxis_dpdown, false, 0);
  ADD('h', m->hat_dpdown, 18, 0, false, m->hat_dir_dpdown);
  ADD('a', m->abs_dpleft, 19, m->halfaxis_dpleft, false, 0);
  ADD('h', m->hat_dpleft, 19, 0, false, m->hat_dir_dpleft);
  ADD('a', m->abs_dpright, 20, m->halfaxis_dpright, false, 0);
  ADD('h', m->hat_dpright, 20, 0, false, m->hat_dir_dpright);
  #undef ADD
  return n;
}
/* Aggregate opposite digital directions before publishing so releasing one
 * direction cannot erase another held direction. Values use SDL's Y polarity. */
static inline void mapping_evaluate_extra(const struct mapping *map,
    mapping_read_source read_source, void *ctx, int output[27], bool present[27]) {
  for (int i = 0; i < 27; ++i) { output[i] = 0; present[i] = false; }
  struct mapping_binding bindings[MAPPING_BINDING_MAX];
  unsigned count = mapping_bindings(map, bindings);
  for (unsigned i = 0; i < count; ++i) {
    const struct mapping_binding *b = &bindings[i];
    struct mapping_sample s = {0};
    unsigned dst = b->destination;
    if (dst >= 27 || !read_source(ctx, b, &s)) continue;
    present[dst] = true;
    int64_t scaled;
    if (b->source != 'a') {
      bool active = b->source == 'h' ?
          (s.value & b->direction) == b->direction : s.value != 0;
      scaled = active ? 32767 : 0;
    } else {
      struct mapping_axis axis = {s.minimum, s.maximum, s.flat,
          (int)(((int64_t)s.minimum + s.maximum) / 2)};
      if (!mapping_axis_usable(&axis)) continue;
      if (dst >= 4) {
        /* An inactive half-axis stays neutral even for inverted bindings. */
        if (b->invert && ((b->half == '+' && s.value < axis.avg) ||
            (b->half == '-' && s.value > axis.avg))) continue;
        int v = mapping_axis_byte(s.value, &axis, b->half);
        if (b->invert) v = 255 - v;
        if (dst < 6) {
          if (v > output[dst]) output[dst] = v;
        } else if (v > 127) output[dst] = 1;
        continue;
      }
      if (!b->half && !b->output_half) {
        output[dst] += mapping_axis_stick(s.value, &axis, b->invert);
        continue;
      }
      int64_t lo = s.minimum, hi = s.maximum, value = s.value;
      if (hi <= lo || s.flat < 0 || 2LL * s.flat >= hi - lo) continue;
      int64_t center = (lo + hi) / 2;
      if (b->half == '+') lo = center;
      else if (b->half == '-') { hi = lo; lo = center; }
      /* Values outside a half-axis must be neutral, even when inverted. */
      if ((hi > lo && (value < lo || value > hi)) ||
          (hi < lo && (value > lo || value < hi))) {
        if (b->half) continue;
        value = value < lo ? lo : hi;
      }
      if (hi == lo) continue;
      if (b->half) {
        /* Use the same physical deadzone as ordinary stick bindings. Keep
         * full-source mappings below unchanged: their midpoint can represent
         * intentional half travel rather than a neutral output. */
        int normalized = mapping_axis_stick(s.value, &axis, false);
        scaled = b->half == '+' ? normalized :
            -(int64_t)normalized * 32767 / 32768;
        if (scaled < 0) scaled = 0;
      } else {
        scaled = (value - lo) * 32767 / (hi - lo);
      }
      if (b->invert) scaled = 32767 - scaled;
      if (dst < 4 && !b->output_half)
        scaled = scaled * 65535 / 32767 - 32768;
    }
    if (dst < 4) {
      if (b->output_half == '-') scaled = -scaled;
      output[dst] += (int)scaled;
    } else if (dst < 6) {
      int v = (int)(scaled * 255 / 32767);
      if (v > output[dst]) output[dst] = v;
    } else if (scaled > 16383) output[dst] = 1;
  }
  for (int i = 0; i < 4; ++i) {
    if (output[i] > 32767) output[i] = 32767;
    if (output[i] < -32768) output[i] = -32768;
  }
}
