/* SPDX-License-Identifier: GPL-3.0-or-later
 * Minimal, bounds-checked DualSense USB/Bluetooth framing.
 * Keep this independent of libudev/SDL for deterministic host tests.
 */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#define ML_DS_USB_IN 64
#define ML_DS_BT_IN 78
#define ML_DS_USB_OUT 63
#define ML_DS_BT_OUT 78
#define ML_DS_PAYLOAD 47
#define ML_DS_USB 1
#define ML_DS_BT 2

/* Only the explicit value "0" disables automatic enhanced HID handling. */
static inline bool ml_ds_hid_enabled(const char *mode) {
  return !mode || strcmp(mode, "0") != 0;
}

typedef struct {
  int16_t gyro[3], accel[3];
  uint8_t touch[2][4];
  uint8_t battery;
} ml_ds_sample;

static inline uint32_t ml_ds_crc32(uint8_t seed, const uint8_t *data, size_t length) {
  uint32_t crc = 0xffffffffU;
  /* Sony CRC uses the transaction prefix (input 0xa1, output 0xa2). */
  for (size_t i = 0; i <= length; ++i) {
    uint8_t byte = i ? data[i - 1] : seed;
    crc ^= byte;
    for (unsigned bit = 0; bit < 8; ++bit)
      crc = (crc >> 1) ^ (0xedb88320U & (0U - (crc & 1U)));
  }
  return ~crc;
}

static inline uint32_t ml_ds_le32(const uint8_t *b) {
  return (uint32_t)b[0] | ((uint32_t)b[1] << 8) |
         ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
}

static inline int16_t ml_ds_le16s(const uint8_t *b) {
  return (int16_t)((uint16_t)b[0] | ((uint16_t)b[1] << 8));
}

static inline bool ml_ds_parse(const uint8_t *in, size_t length, int transport, ml_ds_sample *out) {
  if (!in || !out) return false;
  size_t offset;
  if (transport == ML_DS_USB && length == ML_DS_USB_IN && in[0] == 0x01) {
    offset = 1;
  } else if (transport == ML_DS_BT && length == ML_DS_BT_IN && in[0] == 0x31) {
    if (ml_ds_crc32(0xa1, in, length - 4) != ml_ds_le32(in + length - 4))
      return false;
    offset = 2;
  } else {
    return false;
  }
  const uint8_t *p = in + offset;
  for (unsigned axis = 0; axis < 3; ++axis) {
    out->gyro[axis] = ml_ds_le16s(p + 15 + axis * 2);
    out->accel[axis] = ml_ds_le16s(p + 21 + axis * 2);
  }
  memcpy(out->touch[0], p + 32, 4);
  memcpy(out->touch[1], p + 36, 4);
  out->battery = p[52];
  return true;
}

static inline bool ml_ds_output(const uint8_t payload[ML_DS_PAYLOAD], int transport,
                                unsigned sequence, uint8_t out[ML_DS_BT_OUT], size_t *length) {
  if (!payload || !out || !length) return false;
  memset(out, 0, ML_DS_BT_OUT);
  if (transport == ML_DS_USB) {
    out[0] = 0x02;
    memcpy(out + 1, payload, ML_DS_PAYLOAD);
    *length = ML_DS_USB_OUT;
    return true;
  }
  if (transport == ML_DS_BT) {
    out[0] = 0x31;
    out[1] = (uint8_t)((sequence & 15U) << 4);
    out[2] = 0x10;
    memcpy(out + 3, payload, ML_DS_PAYLOAD);
    const uint32_t crc = ml_ds_crc32(0xa2, out, ML_DS_BT_OUT - 4);
    for (unsigned i = 0; i < 4; ++i)
      out[ML_DS_BT_OUT - 4 + i] = (uint8_t)(crc >> (8 * i));
    *length = ML_DS_BT_OUT;
    return true;
  }
  return false;
}
