/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once

/* Matches the controller slot limit in evdev and the GameStream mask. */
#define MOONLIGHT_GAMEPAD_SLOTS 16U

/* A controller without an assigned slot cannot issue host mouse events
 * or request local gamepad quit. Keyboard and CEC exits are independent. */
static inline int moonlight_gamepad_slot_valid(int id) {
  return id >= 0 && id < (int)MOONLIGHT_GAMEPAD_SLOTS;
}

/* Mapped controllers without an assigned slot may collect input state but
 * must not emit host keyboard, mouse, touch or CEC media events. Independent
 * keyboard and remote devices remain enabled. */
static inline int moonlight_host_input_allowed(int is_gamepad, int id) {
  return !is_gamepad || moonlight_gamepad_slot_valid(id);
}

/* Never alias an overflow controller onto player one's occupied slot. */
static inline int moonlight_first_free_gamepad_slot(unsigned int occupied) {
  for (unsigned int i = 0; i < MOONLIGHT_GAMEPAD_SLOTS; ++i)
    if (!(occupied & (1U << i))) return (int)i;
  return -1;
}

static inline int moonlight_gamepad_mask(int native, int sdl) {
  unsigned int count = native > 0 ? (unsigned int)native : 0U;
  if (count > MOONLIGHT_GAMEPAD_SLOTS)
    count = MOONLIGHT_GAMEPAD_SLOTS;
  if (sdl > 0) {
    const unsigned int remaining = MOONLIGHT_GAMEPAD_SLOTS - count;
    const unsigned int additional = (unsigned int)sdl;
    count += additional > remaining ? remaining : additional;
  }
  /* count <= 16; shifting an unsigned 32-bit value is defined. */
  return (int)((1U << count) - 1U);
}
