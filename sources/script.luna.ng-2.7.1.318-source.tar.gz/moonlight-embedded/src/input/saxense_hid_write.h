/* SPDX-License-Identifier: GPL-3.0-or-later
 * Bound retries for complete hidraw output reports. A short positive write
 * is NOT a valid partial report: do not send the remainder as a new report.
 * Keep callbacks injectable for deterministic host tests.
 */
#ifndef MOONLIGHT_SAXENSE_HID_WRITE_H
#define MOONLIGHT_SAXENSE_HID_WRITE_H
#include <stdbool.h>
#include <stddef.h>
#include <sys/types.h>
#include <errno.h>

typedef struct {
  ssize_t (*write_report)(int fd, const void *buf, size_t length);
  void (*pause_retry)(void);
} MlSaxHidWriteOps;

#define ML_SAX_HID_MAX_ATTEMPTS 3U

static inline bool ml_sax_hid_write_bounded(const MlSaxHidWriteOps *ops,
                                            int fd, const void *report,
                                            size_t length) {
  if (!ops || !ops->write_report || !ops->pause_retry ||
      fd < 0 || !report || !length) return false;
  for (unsigned attempt = 0; attempt < ML_SAX_HID_MAX_ATTEMPTS; ++attempt) {
    ssize_t written = ops->write_report(fd, report, length);
    if (written == (ssize_t)length) return true;
    if (written >= 0) return false; /* Never split an HID output report. */
    const int error = errno;
    if (error != EINTR && error != EAGAIN
#ifdef EWOULDBLOCK
        && error != EWOULDBLOCK
#endif
        ) return false;
    if (attempt + 1U == ML_SAX_HID_MAX_ATTEMPTS) return false;
    if (error != EINTR) ops->pause_retry();
  }
  return false;
}
#endif
