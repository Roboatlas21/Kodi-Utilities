/* SPDX-License-Identifier: GPL-3.0-or-later
 * Private CoreELEC 21 native 2026 Steam Controller driver.
 * No callbacks write HID on a common-c worker. No global driver resets.
 */
#ifndef MOONLIGHT_STEAM_CONTROLLER_2026_H
#define MOONLIGHT_STEAM_CONTROLLER_2026_H
#include <stdbool.h>
#include <stdint.h>
#ifdef __linux__
bool sc26_start(void);
void sc26_poll_main(void);
int sc26_claimed_controller_count(void);
void sc26_set_online(bool online);
void sc26_stop(void);
bool sc26_owns_event_fd(int event_fd);
bool sc26_rumble_host(unsigned short player,unsigned short low,unsigned short high);
bool sc26_motion_host(unsigned short player,uint8_t type,uint16_t rate);
void sc26_haptic_host(uint16_t player,uint8_t length,const uint8_t *report);
void sc26_settings_host(uint16_t player,uint8_t cmd,uint8_t count,const uint8_t *triples);
#else
static inline bool sc26_start(void){return false;}
static inline void sc26_poll_main(void){}
static inline int sc26_claimed_controller_count(void){return 0;}
static inline void sc26_set_online(bool online){(void)online;}
static inline void sc26_stop(void){}
static inline bool sc26_owns_event_fd(int fd){(void)fd;return false;}
static inline bool sc26_rumble_host(unsigned short id,unsigned short l,unsigned short h){
 (void)id;(void)l;(void)h;return false;
}
static inline bool sc26_motion_host(unsigned short id,uint8_t t,uint16_t r){
 (void)id;(void)t;(void)r;return false;
}
static inline void sc26_haptic_host(uint16_t id,uint8_t len,const uint8_t *report){
 (void)id;(void)len;(void)report;
}
static inline void sc26_settings_host(uint16_t id,uint8_t cmd,uint8_t count,const uint8_t *triples){
 (void)id;(void)cmd;(void)count;(void)triples;
}
#endif
#endif
