/* SPDX-License-Identifier: GPL-3.0-or-later
 * DualSense audio renderer. This is separate from Kodi/HDMI audio and video.
 */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct ml_ds_audio ml_ds_audio;

/* HID is opened and validated by dualsense.c. The optional audio renderer
 * duplicates that fd for Bluetooth or discovers a matching USB PCM endpoint. */
ml_ds_audio *ml_ds_audio_open(int hid_fd, int transport, int event_fd);
void ml_ds_audio_close(ml_ds_audio *a);
bool ml_ds_audio_haptics_ready(const ml_ds_audio *a);
bool ml_ds_audio_speaker_ready(const ml_ds_audio *a);
uint64_t ml_ds_audio_speaker_owner(const ml_ds_audio *a);
bool ml_ds_audio_playing(ml_ds_audio *a);
void ml_ds_audio_haptics(ml_ds_audio *a, uint32_t sequence, const uint8_t *pcm, uint16_t frames);
void ml_ds_audio_speaker(ml_ds_audio *a, uint64_t owner, uint32_t generation,
                          uint32_t sequence, uint64_t position, uint16_t flags,
                          const uint8_t *pcm, uint16_t frames);
