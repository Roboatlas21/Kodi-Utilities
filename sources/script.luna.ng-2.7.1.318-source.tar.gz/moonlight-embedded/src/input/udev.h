/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "mapping.h"
#include <stddef.h>
#define ML_INPUT_IDENTITY_MAX 768

void udev_init(bool autoload, struct mapping* mappings, bool verbose, int rotate);
void udev_destroy();
/* Re-enumerate selected event nodes when a previously claimed Steam native
 * HID link fails; never globally reset HID/USB drivers. */
void udev_rescan_inputs(void);
/* Rate-limited retry when a live device fails without a new udev add event. */
/* Exact sysfs input instance plus optional unique/physical identifiers.
 * No identity => no automatic retry of an eventN that may be recycled. */
bool udev_input_identity_for_fd(int fd, char *out, size_t capacity);
void udev_schedule_input_retry(const char *node_path, unsigned long long rdev,
                               const char *identity);
void udev_cancel_input_retry(const char *node_path, unsigned long long rdev);
/* Schedule independent Sony HID-bridge repair, without removing evdev pad. */
void udev_schedule_advanced_retry(void);
