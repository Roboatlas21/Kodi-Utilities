/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_STEAM_CONTROLLER_INITIAL_H
#define MOONLIGHT_STEAM_CONTROLLER_INITIAL_H
#include <stdbool.h>

/* Direct wired/BLE claims are controller devices. A Puck is an idle-capable
 * receiver, not a controller until the driver decodes a valid state packet.
 * Use the existing dynamic arrival path when an actual pad becomes active. */
static inline bool sc26_initial_slot_eligible(bool receiver,
                                               bool valid_controller_state) {
  return !receiver || valid_controller_state;
}
#endif
