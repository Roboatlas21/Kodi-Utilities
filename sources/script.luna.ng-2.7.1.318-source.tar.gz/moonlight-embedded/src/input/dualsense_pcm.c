/* SPDX-License-Identifier: GPL-3.0-or-later
 * Optional low-latency DualSense haptics/speaker renderer for CoreELEC.
 * All callbacks copy bounded samples; no HID or PCM I/O on the control thread.
 */
#define _GNU_SOURCE
#include "dualsense_pcm.h"
#include "dualsense_report.h"
#include "saxense_packet.h"
#include "saxense_hid_write.h"
#include "../audio/alsa_bounded_write.h"
#include "../audio/alsa_suspend_recovery.h"
#include <ControllerHaptics.h>
#include <ControllerSpeakerPcm.h>
#include <linux/input.h>
#include <libudev.h>
#include <sys/stat.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#if defined(HAVE_ALSA)
#include <alsa/asoundlib.h>
#endif

#define ML_DS_RING_FRAMES 4096U
#define ML_DS_USB_QUANTUM 240U
#define ML_DS_IDLE_US 60000ULL
typedef struct {
  uint8_t data[ML_DS_RING_FRAMES * 4];
  unsigned read, length;
} pcm_ring;
struct ml_ds_audio {
  int bt_fd;
#if defined(HAVE_ALSA)
  snd_pcm_t *usb_pcm;
#endif
  uint64_t owner;
  pthread_mutex_t lock;
  pthread_cond_t wake;
  pthread_t thread;
  bool thread_started, stop, active, failed;
  pcm_ring actuator, speaker;
  uint64_t last_nonzero_us;
  uint32_t act_seq, speaker_gen, speaker_seq;
  uint64_t speaker_next_pos;
  bool have_act_seq, have_speaker_seq, have_speaker_pos;
  uint8_t bt_sequence;
};

static uint64_t now_us(void) {
  struct timespec t;
  if (clock_gettime(CLOCK_MONOTONIC, &t) != 0) return 0;
  return (uint64_t)t.tv_sec * 1000000ULL + (uint64_t)t.tv_nsec / 1000ULL;
}

static void ring_clear(pcm_ring *r) { r->read = r->length = 0; }
static void ring_add(pcm_ring *r, const uint8_t *p, unsigned frames) {
  if (!p || frames == 0 || frames > ML_DS_RING_FRAMES) return;
  if (r->length + frames > ML_DS_RING_FRAMES) ring_clear(r); /* Drop stale backlog. */
  for (unsigned i = 0; i < frames; ++i) {
    const unsigned pos = (r->read + r->length + i) % ML_DS_RING_FRAMES;
    memcpy(r->data + pos * 4, p + i * 4, 4);
  }
  r->length += frames;
}
static void ring_take(pcm_ring *r, uint8_t *out, unsigned frames) {
  unsigned available = r->length < frames ? r->length : frames;
  for (unsigned i = 0; i < available; ++i)
    memcpy(out + i * 4, r->data + ((r->read + i) % ML_DS_RING_FRAMES) * 4, 4);
  if (available < frames) memset(out + available * 4, 0, (frames - available) * 4);
  r->read = (r->read + available) % ML_DS_RING_FRAMES;
  r->length -= available;
}
static bool contains_nonzero(const uint8_t *p, unsigned n) {
  for (unsigned i = 0; i < n; ++i) if (p[i] != 0) return true;
  return false;
}
static void next_wake(struct timespec *out, long nanoseconds) {
  clock_gettime(CLOCK_MONOTONIC, out);
  out->tv_nsec += nanoseconds;
  out->tv_sec += out->tv_nsec / 1000000000L;
  out->tv_nsec %= 1000000000L;
}
static bool waited(ml_ds_audio *a, long timeout_ns) {
  struct timespec deadline;
  next_wake(&deadline, timeout_ns);
  return pthread_cond_timedwait(&a->wake, &a->lock, &deadline) == 0;
}

/* The USB sound function must belong to the same physical Sony device as
 * the HID event node, not merely have a plausible name/card number. */
#if defined(HAVE_ALSA)
static snd_pcm_t *open_matching_usb_pcm(int event_fd) {
  struct stat st;
  if (fstat(event_fd, &st) < 0 || !S_ISCHR(st.st_mode)) return NULL;
  struct udev *u = udev_new();
  if (!u) return NULL;
  struct udev_device *event = udev_device_new_from_devnum(u, 'c', st.st_rdev);
  struct udev_device *parent = event ? udev_device_get_parent_with_subsystem_devtype(
      event, "usb", "usb_device") : NULL;
  const char *usb_path = parent ? udev_device_get_syspath(parent) : NULL;
  struct udev_enumerate *enumeration = udev_enumerate_new(u);
  snd_pcm_t *pcm = NULL;
  if (usb_path && enumeration &&
      udev_enumerate_add_match_subsystem(enumeration, "sound") >= 0 &&
      udev_enumerate_scan_devices(enumeration) >= 0) {
    struct udev_list_entry *entry;
    udev_list_entry_foreach(entry, udev_enumerate_get_list_entry(enumeration)) {
      struct udev_device *sound = udev_device_new_from_syspath(u, udev_list_entry_get_name(entry));
      if (!sound) continue;
      const char *name = udev_device_get_sysname(sound);
      struct udev_device *usb = udev_device_get_parent_with_subsystem_devtype(
          sound, "usb", "usb_device");
      const char *candidate = usb ? udev_device_get_syspath(usb) : NULL;
      unsigned card, device;
      char extra = 0;
      if (candidate && name && strcmp(candidate, usb_path) == 0 &&
          sscanf(name, "pcmC%uD%up%c", &card, &device, &extra) == 2 &&
          card <= 255 && device <= 255) {
        char alsa_name[32];
        snprintf(alsa_name, sizeof(alsa_name), "hw:%u,%u", card, device);
        snd_pcm_t *opened = NULL;
        if (snd_pcm_open(&opened, alsa_name, SND_PCM_STREAM_PLAYBACK,
                         SND_PCM_NONBLOCK) == 0) {
          /* No format/channel/rate conversion: channels 1/2 = speaker,
           * channels 3/4 = actuator waveform. Mismatched devices are skipped. */
          if (snd_pcm_set_params(opened, SND_PCM_FORMAT_S16_LE,
                                 SND_PCM_ACCESS_RW_INTERLEAVED,
                                 4, 48000, 0, 20000) == 0) {
            pcm = opened;
            fprintf(stderr, "DualSense USB four-channel audio available: %s\n", alsa_name);
          } else snd_pcm_close(opened);
        }
      }
      udev_device_unref(sound);
      if (pcm) break;
    }
  }
  if (enumeration) udev_enumerate_unref(enumeration);
  if (event) udev_device_unref(event);
  udev_unref(u);
  return pcm;
}
#endif

static uint64_t random_owner(void) {
  int fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
  if (fd < 0) return 0;
  uint64_t result = 0;
  const ssize_t n = read(fd, &result, sizeof(result));
  close(fd);
  return n == (ssize_t)sizeof(result) ? result : 0;
}

/* hidraw is nonblocking. Transient interrupts and queue backpressure can
 * occur, but never wait indefinitely or split a short positive HID report. */
static ssize_t sax_write_report(int fd, const void *report, size_t length) {
  return write(fd, report, length);
}
static void sax_pause_retry(void) {
  const struct timespec delay = {.tv_sec = 0, .tv_nsec = 2000000L};
  (void)nanosleep(&delay, NULL);
}
static const MlSaxHidWriteOps sax_hid_ops = {
  .write_report = sax_write_report,
  .pause_retry = sax_pause_retry,
};
static MlSaxChunk sax_chunk_ready(const ml_ds_audio *a) {
  const uint64_t now = now_us();
  const bool idle = a->active && now >= a->last_nonzero_us &&
                    now - a->last_nonzero_us >= ML_DS_IDLE_US;
  return ml_sax_next_chunk(a->actuator.length, a->active, idle);
}

static void *run_bluetooth(void *arg) {
  ml_ds_audio *a = arg;
  struct timespec deadline = {0};
  for (;;) {
    uint8_t chunk[ML_SAX_SOURCE_FRAMES * 4], samples[ML_SAX_PCM_BYTES];
    pthread_mutex_lock(&a->lock);
    while (!a->stop && sax_chunk_ready(a) == ML_SAX_CHUNK_WAIT) {
      if (!a->active && a->actuator.length == 0)
        pthread_cond_wait(&a->wake, &a->lock);
      else
        (void)waited(a, 10000000L);
    }
    if (a->stop) { pthread_mutex_unlock(&a->lock); break; }
    const MlSaxChunk next = sax_chunk_ready(a);
    const bool can_send = next == ML_SAX_CHUNK_FULL || next == ML_SAX_CHUNK_TAIL;
    if (can_send) {
      /* ring_take() zero-pads the remaining samples in a timed-out tail.
       * Leave active set until the following iteration sends the one final
       * silence packet. This preserves even one-frame haptic pulses. */
      ring_take(&a->actuator, chunk, ML_SAX_SOURCE_FRAMES);
    } else {
      a->active = false;
      ring_clear(&a->actuator);
      memset(chunk, 0, sizeof(chunk));
    }
    const uint8_t seq = a->bt_sequence++;
    pthread_mutex_unlock(&a->lock);
    if (can_send) ml_sax_downsample(chunk, samples);
    else memset(samples, 0, sizeof(samples));
    uint8_t report[ML_SAX_REPORT_BYTES];
    ml_sax_packet(report, seq, samples);
    if (!ml_sax_hid_write_bounded(&sax_hid_ops, a->bt_fd,
                                  report, sizeof(report))) {
      fprintf(stderr, "DualSense Bluetooth haptics unavailable; falling back to rumble\n");
      pthread_mutex_lock(&a->lock);
      a->failed = true;
      pthread_mutex_unlock(&a->lock);
      break;
    }
    /* SAxense consumes 32 stereo samples at 3 kHz = 10.667ms. */
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    int64_t late = (int64_t)(now.tv_sec - deadline.tv_sec) * 1000000000LL + now.tv_nsec - deadline.tv_nsec;
    if (!deadline.tv_sec || late > 21333334LL) deadline = now;
    deadline.tv_nsec += 10666667L;
    deadline.tv_sec += deadline.tv_nsec / 1000000000L;
    deadline.tv_nsec %= 1000000000L;
    while (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &deadline, NULL) == EINTR) {}
  }
  return NULL;
}

#if defined(HAVE_ALSA)
/* Reuse the bounded nonblocking ALSA writer for four-channel S16_LE
 * DualSense USB PCM. Only the dedicated worker invokes these callbacks. */
static long ds_usb_pcm_write(void *ctx, const void *samples, unsigned long frames) {
  return snd_pcm_writei((snd_pcm_t *)ctx, samples, (snd_pcm_uframes_t)frames);
}
static int ds_usb_pcm_wait(void *ctx, int milliseconds) {
  return snd_pcm_wait((snd_pcm_t *)ctx, milliseconds);
}
static int ds_usb_resume_once(void *ctx) {
  return snd_pcm_resume((snd_pcm_t *)ctx);
}
static int ds_usb_prepare(void *ctx) {
  return snd_pcm_prepare((snd_pcm_t *)ctx);
}
static int ds_usb_recover_standard(void *ctx, int error) {
  return snd_pcm_recover((snd_pcm_t *)ctx, error, 0);
}
static const AlsaRecoveryOps ds_usb_recovery_ops = {
  .resume = ds_usb_resume_once,
  .prepare = ds_usb_prepare,
  .recover = ds_usb_recover_standard,
};
static int ds_usb_pcm_recover(void *ctx, int error) {
  /* EINTR interrupted only this nonblocking write; retry the unplayed
   * frames without resetting the controller's PCM queue. The shared
   * bounded writer limits repeated interrupts to two recoveries. */
  if (error == -EINTR) return 0;
  /* For ESTRPIPE, attempt resume once before prepare. EPIPE follows
   * ALSA's standard recovery, as on the main Moonlight PCM renderer. */
  return alsa_recover_bounded(&ds_usb_recovery_ops, ctx, error);
}
static const AlsaBoundedOps ds_usb_pcm_ops = {
  .write = ds_usb_pcm_write,
  .wait = ds_usb_pcm_wait,
  .recover = ds_usb_pcm_recover,
};

static void *run_usb(void *arg) {
  ml_ds_audio *a = arg;
  struct timespec deadline = {0};
  for (;;) {
    uint8_t act[ML_DS_USB_QUANTUM * 4] = {0};
    uint8_t spk[ML_DS_USB_QUANTUM * 4] = {0};
    int16_t out[ML_DS_USB_QUANTUM * 4];
    pthread_mutex_lock(&a->lock);
    while (!a->stop && a->actuator.length == 0 && a->speaker.length == 0)
      pthread_cond_wait(&a->wake, &a->lock);
    if (a->stop) { pthread_mutex_unlock(&a->lock); break; }
    /* Coalesce independently arriving speaker/actuator packets on one
     * bounded render window. A short packet is not a full 5ms of audio. */
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    /* Preserve the timeline across writes: processing time must not be
     * added to every render window when only one lane is active. Reset
     * after a genuine idle gap; never issue an unbounded catch-up burst. */
    int64_t late_ns = (int64_t)(now.tv_sec - deadline.tv_sec) * 1000000000LL +
                      now.tv_nsec - deadline.tv_nsec;
    if (deadline.tv_sec == 0 || late_ns > 20000000LL)
      next_wake(&deadline, 5000000L);
    while (!a->stop && (a->actuator.length < ML_DS_USB_QUANTUM ||
                       a->speaker.length < ML_DS_USB_QUANTUM)) {
      if (pthread_cond_timedwait(&a->wake, &a->lock, &deadline) != 0) break;
    }
    if (a->stop) { pthread_mutex_unlock(&a->lock); break; }
    unsigned frames = a->actuator.length > a->speaker.length ?
                      a->actuator.length : a->speaker.length;
    if (frames > ML_DS_USB_QUANTUM) frames = ML_DS_USB_QUANTUM;
    ring_take(&a->actuator, act, frames);
    ring_take(&a->speaker, spk, frames);
    deadline.tv_nsec += (long)((uint64_t)frames * 1000000000ULL / 48000U);
    deadline.tv_sec += deadline.tv_nsec / 1000000000L;
    deadline.tv_nsec %= 1000000000L;
    pthread_mutex_unlock(&a->lock);
    for (unsigned i = 0; i < frames; ++i) {
      for (unsigned ch = 0; ch < 2; ++ch) {
        const uint8_t *s = spk + i * 4 + ch * 2;
        const uint8_t *h = act + i * 4 + ch * 2;
        out[i * 4 + ch] = (int16_t)((uint16_t)s[0] | ((uint16_t)s[1] << 8));
        out[i * 4 + 2 + ch] = (int16_t)((uint16_t)h[0] | ((uint16_t)h[1] << 8));
      }
    }
    /* A short ALSA write is a partial success: advance the interleaved
     * pointer, then retry only the remaining samples within strict limits.
     * Drop the unplayed tail rather than accumulating controller latency. */
    const AlsaBoundedResult result = alsa_bounded_write(
        &ds_usb_pcm_ops, a->usb_pcm, out, frames,
        sizeof(out[0]) * 4u);
    if (result.remaining && result.last_error != 0 &&
        result.last_error != -EAGAIN &&
        !((result.last_error == -EPIPE || result.last_error == -ESTRPIPE) &&
          result.recovery_attempts == result.successful_recoveries &&
          result.successful_recoveries != 0)) {
      fprintf(stderr, "DualSense USB audio failed (%d); disabling PCM\n",
              result.last_error);
      break;
    }
  }
  pthread_mutex_lock(&a->lock);
  a->failed = true;
  pthread_mutex_unlock(&a->lock);
  return NULL;
}
#endif

ml_ds_audio *ml_ds_audio_open(int hid_fd, int transport, int event_fd) {
  ml_ds_audio *a = calloc(1, sizeof(*a));
  if (!a) return NULL;
  a->bt_fd = -1;
  if (pthread_mutex_init(&a->lock, NULL) != 0) { free(a); return NULL; }
  pthread_condattr_t attr;
  if (pthread_condattr_init(&attr) != 0) {
    pthread_mutex_destroy(&a->lock); free(a); return NULL;
  }
  int cond_result = pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
  if (cond_result == 0) cond_result = pthread_cond_init(&a->wake, &attr);
  pthread_condattr_destroy(&attr);
  if (cond_result != 0) {
    pthread_mutex_destroy(&a->lock); free(a); return NULL;
  }
  void *(*thread)(void*) = NULL;
  if (transport == ML_DS_BT) {
    a->bt_fd = dup(hid_fd);
    if (a->bt_fd >= 0) {
      uint8_t zeros[ML_SAX_PCM_BYTES] = {0}, probe[ML_SAX_REPORT_BYTES];
      ml_sax_packet(probe, 0, zeros);
      if (!ml_sax_hid_write_bounded(&sax_hid_ops, a->bt_fd,
                                    probe, sizeof(probe))) {
        close(a->bt_fd);
        a->bt_fd = -1;
      } else {
        a->bt_sequence = 1;
        thread = run_bluetooth;
      }
    }
  } else if (transport == ML_DS_USB) {
#if defined(HAVE_ALSA)
    a->usb_pcm = open_matching_usb_pcm(event_fd);
    if (a->usb_pcm) {
      a->owner = random_owner();
      thread = run_usb;
    }
#else
    (void)event_fd;
#endif
  }
  if (thread && pthread_create(&a->thread, NULL, thread, a) == 0)
    a->thread_started = true;
  if (!a->thread_started) {
    if (a->bt_fd >= 0) close(a->bt_fd);
#if defined(HAVE_ALSA)
    if (a->usb_pcm) snd_pcm_close(a->usb_pcm);
#endif
    pthread_cond_destroy(&a->wake);
    pthread_mutex_destroy(&a->lock);
    free(a);
    return NULL;
  }
  return a;
}

void ml_ds_audio_close(ml_ds_audio *a) {
  if (!a) return;
  pthread_mutex_lock(&a->lock);
  a->stop = true;
  pthread_cond_broadcast(&a->wake);
  pthread_mutex_unlock(&a->lock);
  if (a->thread_started) pthread_join(a->thread, NULL);
  if (a->bt_fd >= 0) close(a->bt_fd);
#if defined(HAVE_ALSA)
  if (a->usb_pcm) {
    snd_pcm_drop(a->usb_pcm);
    snd_pcm_close(a->usb_pcm);
  }
#endif
  pthread_cond_destroy(&a->wake);
  pthread_mutex_destroy(&a->lock);
  free(a);
}
bool ml_ds_audio_haptics_ready(const ml_ds_audio *a) {
  if (!a) return false;
  pthread_mutex_lock((pthread_mutex_t*)&a->lock);
  const bool ready = !a->failed && !a->stop;
  pthread_mutex_unlock((pthread_mutex_t*)&a->lock);
  return ready;
}
bool ml_ds_audio_speaker_ready(const ml_ds_audio *a) {
#if defined(HAVE_ALSA)
  if (!a) return false;
  pthread_mutex_lock((pthread_mutex_t*)&a->lock);
  const bool ready = a->usb_pcm && !a->failed && !a->stop && a->owner != 0;
  pthread_mutex_unlock((pthread_mutex_t*)&a->lock);
  return ready;
#else
  (void)a; return false;
#endif
}
uint64_t ml_ds_audio_speaker_owner(const ml_ds_audio *a) {
  return ml_ds_audio_speaker_ready(a) ? a->owner : 0;
}
bool ml_ds_audio_playing(ml_ds_audio *a) {
  if (!a) return false;
  pthread_mutex_lock(&a->lock);
  const bool result = !a->failed && a->active &&
                      (a->actuator.length != 0 || now_us() - a->last_nonzero_us < ML_DS_IDLE_US);
  pthread_mutex_unlock(&a->lock);
  return result;
}
void ml_ds_audio_haptics(ml_ds_audio *a, uint32_t sequence,
                         const uint8_t *pcm, uint16_t frames) {
  if (!a || !pcm || !frames || frames > ML_HAPTICS_MAX_FRAMES) return;
  pthread_mutex_lock(&a->lock);
  if (!a->stop && !a->failed &&
      (!a->have_act_seq || (int32_t)(sequence - a->act_seq) > 0)) {
    const bool nonzero = contains_nonzero(pcm, (unsigned)frames * 4);
    if (nonzero) { a->last_nonzero_us = now_us(); a->active = true; }
    if (!a->have_act_seq || (uint32_t)(sequence - a->act_seq) != 1)
      ring_clear(&a->actuator);
    a->have_act_seq = true;
    a->act_seq = sequence;
    if (a->active || nonzero) {
      ring_add(&a->actuator, pcm, frames);
      pthread_cond_signal(&a->wake);
    }
  }
  pthread_mutex_unlock(&a->lock);
}
void ml_ds_audio_speaker(ml_ds_audio *a, uint64_t owner, uint32_t generation,
                          uint32_t sequence, uint64_t position, uint16_t flags,
                          const uint8_t *pcm, uint16_t frames) {
  if (!ml_ds_audio_speaker_ready(a) || !pcm || !owner || owner != a->owner ||
      !generation || !frames || frames > ML_SPEAKER_PCM_MAX_FRAMES ||
      (flags & ~ML_SPEAKER_PCM_FLAG_DISCONTINUITY) ||
      position > UINT64_MAX - frames) return;
  pthread_mutex_lock(&a->lock);
  if (!a->stop && !a->failed) {
    if (a->have_speaker_seq && (int32_t)(generation - a->speaker_gen) < 0) {
      pthread_mutex_unlock(&a->lock); return;
    }
    if (a->have_speaker_seq && generation == a->speaker_gen &&
        (int32_t)(sequence - a->speaker_seq) <= 0) {
      pthread_mutex_unlock(&a->lock); return;
    }
    if (!a->have_speaker_seq || generation != a->speaker_gen ||
        (flags & ML_SPEAKER_PCM_FLAG_DISCONTINUITY) ||
        (a->have_speaker_pos && position != a->speaker_next_pos))
      ring_clear(&a->speaker);
    a->have_speaker_seq = true;
    a->speaker_gen = generation;
    a->speaker_seq = sequence;
    a->speaker_next_pos = position + frames;
    a->have_speaker_pos = true;
    ring_add(&a->speaker, pcm, frames);
    pthread_cond_signal(&a->wake);
  }
  pthread_mutex_unlock(&a->lock);
}
