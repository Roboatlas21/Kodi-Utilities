// SPDX-License-Identifier: MPL-2.0 OR GPL-3.0-or-later
// SixAxis Sense (SAxense), adapted by Nonary for Moonlight, 2026.
// Original protocol research by Sdore (Egor Vorontsov), 2025.
// Source: https://github.com/Nonary/moonlight-qt/blob/master/third-party/saxense/packet.h
// This file maintains the 142-byte Bluetooth output report, 3 kHz signed
// stereo audio payload and transaction-prefixed Sony HID CRC32.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#define ML_SAX_REPORT_BYTES 142
#define ML_SAX_PCM_BYTES 64
#define ML_SAX_SOURCE_FRAMES 512

/* A timed-out partial source block must be padded and transmitted before
 * the final silence report. Never discard a pulse just because it has fewer
 * than 512 source frames. */
typedef enum {
  ML_SAX_CHUNK_WAIT = 0,
  ML_SAX_CHUNK_FULL = 1,
  ML_SAX_CHUNK_TAIL = 2,
  ML_SAX_CHUNK_SILENCE = 3,
} MlSaxChunk;
static inline MlSaxChunk ml_sax_next_chunk(unsigned queued_frames,
                                           bool active, bool idle_expired) {
  if (queued_frames >= ML_SAX_SOURCE_FRAMES) return ML_SAX_CHUNK_FULL;
  if (!active || !idle_expired) return ML_SAX_CHUNK_WAIT;
  return queued_frames ? ML_SAX_CHUNK_TAIL : ML_SAX_CHUNK_SILENCE;
}
static inline void ml_sax_packet(uint8_t report[ML_SAX_REPORT_BYTES], uint8_t seq,
                                 const uint8_t pcm[ML_SAX_PCM_BYTES]) {
  memset(report, 0, ML_SAX_REPORT_BYTES);
  report[0] = 0x32;
  report[2] = 0x91; report[3] = 7;
  report[4] = 0xfe; report[9] = 0xff; report[10] = seq;
  report[11] = 0x92; report[12] = ML_SAX_PCM_BYTES;
  memcpy(report + 13, pcm, ML_SAX_PCM_BYTES);
  uint32_t crc = ~UINT32_C(0xeada2d49);
  for (size_t i = 0; i < ML_SAX_REPORT_BYTES - 4; ++i) {
    crc ^= report[i];
    for (unsigned bit = 0; bit < 8; ++bit)
      crc = (crc >> 1) ^ (UINT32_C(0xedb88320) & (0U - (crc & 1U)));
  }
  crc = ~crc;
  for (unsigned i = 0; i < 4; ++i)
    report[ML_SAX_REPORT_BYTES - 4 + i] = (uint8_t)(crc >> (8 * i));
}

/* Average 16 samples before converting 48k S16 stereo to 3k S8 stereo.
 * This is a bounded low-pass decimator, not the desktop client's SDL
 * resampler. Every 64-byte packet represents 512 incoming stereo frames. */
static inline void ml_sax_downsample(const uint8_t source[ML_SAX_SOURCE_FRAMES * 4],
                                     uint8_t out[ML_SAX_PCM_BYTES]) {
  for (unsigned i = 0; i < 32; ++i) {
    for (unsigned ch = 0; ch < 2; ++ch) {
      int32_t sum = 0;
      for (unsigned j = 0; j < 16; ++j) {
        const uint8_t *s = source + (i * 16 + j) * 4 + ch * 2;
        sum += (int16_t)((uint16_t)s[0] | ((uint16_t)s[1] << 8));
      }
      int32_t sample = sum / (16 * 256);
      if (sample < -128) sample = -128;
      if (sample > 127) sample = 127;
      out[i * 2 + ch] = (uint8_t)(int8_t)sample;
    }
  }
}
