/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once

/* Apply the deadzone to magnitude, retaining the input's direction. */
static inline float moonlight_mouse_deadzone(float movement, float deadzone) {
  if (movement > deadzone)
    return movement - deadzone;
  if (movement < -deadzone)
    return movement + deadzone;
  return 0.0f;
}
