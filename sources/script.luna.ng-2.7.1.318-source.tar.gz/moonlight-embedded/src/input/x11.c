/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "x11.h"
#include "keyboard.h"

#include "../loop.h"

#include <Limelight.h>

#include <X11/Xatom.h>
#include <X11/Xutil.h>

#include <stdbool.h>
#include <stdlib.h>
#include <poll.h>

#define ACTION_MODIFIERS (MODIFIER_SHIFT|MODIFIER_ALT|MODIFIER_CTRL)
#define QUIT_KEY 0x18  /* KEY_Q */

static Display *display;
static Window window;

static Atom wm_deletemessage;

static int last_x = -1, last_y = -1;
static int keyboard_modifiers;
static bool held_keys[256];
static bool held_buttons[10];

static int current_modifiers(void) {
  return ((held_keys[0x32] || held_keys[0x3e]) ? MODIFIER_SHIFT : 0) |
         ((held_keys[0x40] || held_keys[0x6c]) ? MODIFIER_ALT : 0) |
         ((held_keys[0x25] || held_keys[0x69]) ? MODIFIER_CTRL : 0);
}

static const char data[1] = {0};
static Cursor cursor;
static bool grabbed = True;

static int x11_handler(int fd) {
  XEvent event;
  int button = 0;
  int motion_x, motion_y;

  while (XPending(display)) {
    XNextEvent(display, &event);
    button = 0;
    switch (event.type) {
    case KeyPress:
    case KeyRelease:
      if (event.xkey.keycode >= 8 && event.xkey.keycode < (sizeof(keyCodes)/sizeof(keyCodes[0]) + 8)) {
        if ((keyboard_modifiers & ACTION_MODIFIERS) == ACTION_MODIFIERS && event.type == KeyRelease) {
          if (event.xkey.keycode == QUIT_KEY)
            return LOOP_RETURN;
          else {
            grabbed = !grabbed;
            XDefineCursor(display, window, grabbed ? cursor : 0);
          }
        }

        held_keys[event.xkey.keycode] = event.type == KeyPress;
        keyboard_modifiers = current_modifiers();

        short code = 0x80 << 8 | keyCodes[event.xkey.keycode - 8];
        LiSendKeyboardEvent(code, event.type == KeyPress ? KEY_ACTION_DOWN : KEY_ACTION_UP, keyboard_modifiers);
      }
      break;
    case ButtonPress:
    case ButtonRelease:
      if (event.xbutton.button >= 4 && event.xbutton.button <= 7 &&
          event.type == ButtonRelease)
        break;
      switch (event.xbutton.button) {
      case Button1:
        button = BUTTON_LEFT;
        break;
      case Button2:
        button = BUTTON_MIDDLE;
        break;
      case Button3:
        button = BUTTON_RIGHT;
        break;
      case Button4:
        LiSendScrollEvent(1);
        break;
      case Button5:
        LiSendScrollEvent(-1);
        break;
      case 6:
        LiSendHScrollEvent(-1);
        break;
      case 7:
        LiSendHScrollEvent(1);
        break;
      case 8:
        button = BUTTON_X1;
        break;
      case 9:
        button = BUTTON_X2;
        break;
      }

      if (button != 0) {
        held_buttons[button] = event.type == ButtonPress;
        LiSendMouseButtonEvent(event.type==ButtonPress ? BUTTON_ACTION_PRESS : BUTTON_ACTION_RELEASE, button);
      }
      break;
    case MotionNotify:
      motion_x = event.xmotion.x - last_x;
      motion_y = event.xmotion.y - last_y;
      if (abs(motion_x) > 0 || abs(motion_y) > 0) {
        if (last_x >= 0 && last_y >= 0)
          LiSendMouseMoveEvent(motion_x, motion_y);

        if (grabbed) {
          XWindowAttributes attributes;
          if (XGetWindowAttributes(display, window, &attributes)) {
            last_x = attributes.width / 2;
            last_y = attributes.height / 2;
            XWarpPointer(display, None, window, 0, 0, 0, 0, last_x, last_y);
          }
        }
      }

      if (!grabbed) {
        last_x = event.xmotion.x;
        last_y = event.xmotion.y;
      }
      break;
    case FocusOut:
      for (unsigned key = 8; key < 256 && key < sizeof(keyCodes)/sizeof(keyCodes[0]) + 8; ++key) {
        if (held_keys[key]) {
          held_keys[key] = false;
          LiSendKeyboardEvent(0x8000 | keyCodes[key - 8], KEY_ACTION_UP, current_modifiers());
        }
      }
      for (int key = 1; key < 10; ++key) {
        if (held_buttons[key]) {
          held_buttons[key] = false;
          LiSendMouseButtonEvent(BUTTON_ACTION_RELEASE, key);
        }
      }
      keyboard_modifiers = 0;
      last_x = last_y = -1;
      break;
    case ClientMessage:
      if (event.xclient.data.l[0] == wm_deletemessage)
        return LOOP_RETURN;

      break;
    }
  }

  return LOOP_OK;
}

void x11_input_init(Display* x11_display, Window x11_window) {
  display = x11_display;
  window = x11_window;

  wm_deletemessage = XInternAtom(display, "WM_DELETE_WINDOW", False);
  XSetWMProtocols(display, window, &wm_deletemessage, 1);

  /* make a blank cursor */
  XColor dummy;
  Pixmap blank = XCreateBitmapFromData(display, window, data, 1, 1);
  cursor = XCreatePixmapCursor(display, blank, blank, &dummy, &dummy, 0, 0);
  XFreePixmap(display, blank);
  XDefineCursor(display, window, cursor);

  loop_add_fd(ConnectionNumber(display), x11_handler, POLLIN | POLLERR | POLLHUP);
}
