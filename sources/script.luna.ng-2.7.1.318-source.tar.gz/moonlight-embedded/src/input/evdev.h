/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "mapping.h"
#include <stdint.h>

#include <stdint.h>

extern int evdev_gamepads;

void evdev_create(const char* device, struct mapping* mappings, bool verbose, int rotate);
/* Retry a previous eventN only when its opened descriptor still identifies
 * the same sysfs instance and available uniq/phys identity. */
void evdev_create_verified(const char* device, struct mapping* mappings,
                           bool verbose, int rotate, const char *expected_identity);
/* Retry an independently failed Sony advanced HID bridge on the input loop. */
bool evdev_retry_dualsense_bridges(void);
void evdev_loop();
void evdev_cec_key(unsigned code, bool pressed);

void evdev_init(bool mouse_emulation_enabled);
void evdev_start();
void evdev_stop();
bool evdev_map(char* device);
void evdev_rumble(unsigned short controller_id, unsigned short low_freq_motor, unsigned short high_freq_motor);
void evdev_set_motion_event_state(unsigned short controller_id, unsigned char type, unsigned short rate);
void evdev_set_controller_led(unsigned short controller_id, unsigned char r, unsigned char g, unsigned char b);
void evdev_set_adaptive_triggers(unsigned short controller_id, unsigned char flags,
                                  unsigned char left_type, unsigned char right_type,
                                  unsigned char *left, unsigned char *right);

void evdev_receive_haptics(uint16_t controller_id, uint32_t sequence,
                           const uint8_t *pcm, uint16_t frames);
void evdev_receive_speaker(uint16_t controller_id, uint64_t speaker_owner,
                           uint32_t generation, uint32_t sequence, uint64_t sample_position,
                           uint16_t flags, const uint8_t *pcm, uint16_t frames);

/* Common slot allocation shared by generic evdev and native Steam controllers. */
int evdev_steam_claim_slot(uint16_t *mask);
uint16_t evdev_steam_release_slot(int player);
uint16_t evdev_steam_mask(void);
bool evdev_steam_conflict_parent(const char *hid_parent);

void evdev_publish_state(short slot,int buttons,unsigned char lt,unsigned char rt,
                         short lx,short ly,short rx,short ry);
int evdev_steam_claim_arrival(unsigned char type,unsigned int buttons,unsigned short caps);
uint16_t evdev_steam_release_event(int slot,bool online);
