/* SPDX-License-Identifier: GPL-3.0-or-later
 * Optional DualSense HID feedback/sensor bridge for the native evdev backend.
 * Core buttons/sticks and basic rumble remain owned by evdev.
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

typedef struct moonlight_dualsense moonlight_dualsense;
/* HID reports are indivisible. Only transient EAGAIN/EINTR may be retried;
 * a short positive write is an unrecoverable partial report. */
#define ML_DS_SEND_OK 1
#define ML_DS_SEND_RETRY 0
#define ML_DS_SEND_FAILED -1

#ifdef __linux__
moonlight_dualsense *dualsense_attach(int event_fd, int vendor, int product);
void dualsense_detach(moonlight_dualsense *device);
/* Detached bridge cleanup never joins HID/ALSA workers on the input thread.
 * Shutdown waits only a bounded interval; Luna owns final process recovery. */
bool dualsense_completions_pending(void);
bool dualsense_cleanup_pending(void);
bool dualsense_cleanup_pending_for(int event_fd);
void dualsense_cleanup_shutdown(void);
bool dualsense_hid_healthy(const moonlight_dualsense *device);
bool dualsense_retry_audio(moonlight_dualsense *device, int event_fd);
void dualsense_set_player(moonlight_dualsense *device, short player);
unsigned short dualsense_capabilities(const moonlight_dualsense *device);
void dualsense_motion_request(moonlight_dualsense *device, uint8_t type, uint16_t rate);
void dualsense_led(moonlight_dualsense *device, uint8_t r, uint8_t g, uint8_t b);
int dualsense_led_try(moonlight_dualsense *device, uint8_t r, uint8_t g, uint8_t b);
void dualsense_adaptive(moonlight_dualsense *device, uint8_t flags, uint8_t left_type,
                        uint8_t right_type, const uint8_t *left, const uint8_t *right);
int dualsense_adaptive_try(moonlight_dualsense *device, uint8_t flags, uint8_t left_type,
                           uint8_t right_type, const uint8_t *left, const uint8_t *right);
uint64_t dualsense_speaker_owner(const moonlight_dualsense *d);
bool dualsense_waveform_active(moonlight_dualsense *d);
void dualsense_receive_haptics(moonlight_dualsense *d, uint32_t sequence,
                               const uint8_t *pcm, uint16_t frames);
void dualsense_receive_speaker(moonlight_dualsense *d, uint64_t owner, uint32_t generation,
                               uint32_t sequence, uint64_t position, uint16_t flags,
                               const uint8_t *pcm, uint16_t frames);
#else
/* FreeBSD and other evdev-supported builds must not pull in Linux hidraw. */
static inline moonlight_dualsense *dualsense_attach(int fd, int vendor, int product) {
  (void)fd; (void)vendor; (void)product; return NULL;
}
static inline void dualsense_detach(moonlight_dualsense *d) { (void)d; }
static inline bool dualsense_completions_pending(void) { return false; }
static inline bool dualsense_cleanup_pending(void) { return false; }
static inline bool dualsense_cleanup_pending_for(int event_fd) { (void)event_fd; return false; }
static inline void dualsense_cleanup_shutdown(void) { }
static inline bool dualsense_retry_audio(moonlight_dualsense *d, int fd) { (void)d; (void)fd; return false; }
static inline bool dualsense_hid_healthy(const moonlight_dualsense *d) {
  (void)d; return false;
}
static inline void dualsense_set_player(moonlight_dualsense *d, short player) {
  (void)d; (void)player;
}
static inline unsigned short dualsense_capabilities(const moonlight_dualsense *d) {
  (void)d; return 0;
}
static inline void dualsense_motion_request(moonlight_dualsense *d, uint8_t t, uint16_t rate) {
  (void)d; (void)t; (void)rate;
}
static inline void dualsense_led(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  (void)d; (void)r; (void)g; (void)b;
}
static inline int dualsense_led_try(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  (void)d; (void)r; (void)g; (void)b; return ML_DS_SEND_FAILED;
}
static inline void dualsense_adaptive(moonlight_dualsense *d, uint8_t flags,
                                     uint8_t lt, uint8_t rt,
                                     const uint8_t *left, const uint8_t *right) {
  (void)d; (void)flags; (void)lt; (void)rt; (void)left; (void)right;
}
static inline int dualsense_adaptive_try(moonlight_dualsense *d, uint8_t flags,
                                      uint8_t lt, uint8_t rt,
                                      const uint8_t *left, const uint8_t *right) {
  (void)d; (void)flags; (void)lt; (void)rt; (void)left; (void)right;
  return ML_DS_SEND_FAILED;
}
static inline uint64_t dualsense_speaker_owner(const moonlight_dualsense *d) {
  (void)d; return 0;
}
static inline bool dualsense_waveform_active(moonlight_dualsense *d) {
  (void)d; return false;
}
static inline void dualsense_receive_haptics(moonlight_dualsense *d, uint32_t seq,
                                              const uint8_t *pcm, uint16_t frames) {
  (void)d; (void)seq; (void)pcm; (void)frames;
}
static inline void dualsense_receive_speaker(moonlight_dualsense *d, uint64_t owner,
      uint32_t gen, uint32_t seq, uint64_t pos, uint16_t flags,
      const uint8_t *pcm, uint16_t frames) {
  (void)d; (void)owner; (void)gen; (void)seq; (void)pos; (void)flags;
  (void)pcm; (void)frames;
}
#endif
