/* SPDX-License-Identifier: GPL-3.0-or-later
 * CoreELEC Steam Controller output queue. Pure bounded host-testable logic:
 * no HID I/O, no controller lifetime or host routing decisions.
 */
#ifndef MOONLIGHT_STEAM_OUTPUT_QUEUE_H
#define MOONLIGHT_STEAM_OUTPUT_QUEUE_H

#include "steam_controller_2026_protocol.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#define SC26_OUTPUTS 32

typedef struct {
  uint8_t data[SC26_FEATURE_LENGTH];
  uint8_t length;
  bool feature, stop, keepalive; /* Internal periodic settings refresh. */
} Sc26Output;

/* Caller holds the link mutex. Ordinary effects may be evicted, but feature
 * packets and stop commands are protected. A later stop for the same report
 * and actuator supersedes an earlier one, and goes at the END of the queue.
 * This matters when an intervening play effect would otherwise run last.
 * On a full, all-protected queue with no matching stop, return false so the
 * caller can perform a safe controller handoff rather than lose the stop.
 */
static inline bool sc26_queue_enqueue(Sc26Output queue[SC26_OUTPUTS],
                                       unsigned *count, const uint8_t *data,
                                       size_t length, bool feature, bool stop) {
  if (!queue || !count || !data || !length ||
      length > SC26_FEATURE_LENGTH || *count > SC26_OUTPUTS)
    return false;
  if (!feature && !sc26_valid_haptic(data, length))
    return false;

  /* Rumble reports represent a single continually updated motor state. */
  if (!feature && data[0] == SC26_REPORT_RUMBLE) {
    for (unsigned i = 0; i < *count;) {
      Sc26Output *item = &queue[i];
      if (!item->feature && item->data[0] == SC26_REPORT_RUMBLE) {
        memmove(item, item + 1, (--*count - i) * sizeof(*item));
      } else {
        ++i;
      }
    }
  } else if (!feature && stop &&
             (data[0] == SC26_REPORT_PULSE ||
              data[0] == SC26_REPORT_COMMAND)) {
    for (unsigned i = 0; i < *count; ++i) {
      Sc26Output *item = &queue[i];
      if (!item->feature && item->stop &&
          item->data[0] == data[0] && item->data[1] == data[1]) {
        memmove(item, item + 1, (--*count - i) * sizeof(*item));
        break;
      }
    }
  }

  if (*count >= SC26_OUTPUTS) {
    unsigned victim = SC26_OUTPUTS;
    for (unsigned i = 0; i < *count; ++i) {
      if (!queue[i].stop && !queue[i].feature) {
        victim = i;
        break;
      }
    }
    if (victim == SC26_OUTPUTS) return false;
    memmove(&queue[victim], &queue[victim + 1],
            (*count - victim - 1) * sizeof(queue[0]));
    --*count;
  }
  Sc26Output *slot = &queue[(*count)++];
  memset(slot, 0, sizeof(*slot));
  memcpy(slot->data, data, length);
  slot->length = (uint8_t)length;
  slot->feature = feature;
  slot->stop = stop;
  return true;
}
/* Atomically enqueue one or two protected BLE settings feature reports.
 * Reset-to-defaults requires two ordered writes (load defaults, then
 * restore streaming settings); partial enqueue could leave the controller
 * in lizard mode. Stage a bounded copy and commit only if *both* fit.
 * Caller holds sc26.lock and handles a false result explicitly. */
static inline bool sc26_queue_enqueue_settings_batch(
    Sc26Output queue[SC26_OUTPUTS], unsigned *count,
    const uint8_t first[SC26_FEATURE_LENGTH],
    const uint8_t *second) {
  if (!queue || !count || !first || *count > SC26_OUTPUTS)
    return false;
  Sc26Output staged[SC26_OUTPUTS];
  unsigned staged_count = *count;
  memcpy(staged, queue, sizeof(staged));
  if (!sc26_queue_enqueue(staged, &staged_count, first,
                          SC26_FEATURE_LENGTH, true, true))
    return false;
  if (second &&
      !sc26_queue_enqueue(staged, &staged_count, second,
                          SC26_FEATURE_LENGTH, true, true))
    return false;
  memcpy(queue, staged, sizeof(staged));
  *count = staged_count;
  return true;
}

#endif
