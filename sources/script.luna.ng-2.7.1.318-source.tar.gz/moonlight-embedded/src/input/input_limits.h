/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_INPUT_LIMITS_H
#define MOONLIGHT_INPUT_LIMITS_H
/* Explicit evdev nodes, separate from GameStream's 16 player slots. */
#define MAX_INPUTS 32
#endif
