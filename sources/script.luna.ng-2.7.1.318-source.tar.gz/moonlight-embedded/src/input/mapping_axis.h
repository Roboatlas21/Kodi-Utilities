/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
struct mapping_axis { int min, max, flat, avg; };
static inline bool mapping_axis_usable(const struct mapping_axis *parms) {
  if (!parms || parms->flat < 0) return false;
  const int64_t span = (int64_t)parms->max - parms->min;
  return span > 0 && span <= INT_MAX && 2LL * parms->flat < span;
}

static inline short mapping_axis_stick(int raw, const struct mapping_axis *parms, bool reverse) {
  if (!mapping_axis_usable(parms)) return 0;
  const int64_t value = raw;
  const int64_t flat = parms->flat;
  if (llabs(value - (int64_t)parms->avg) < flat) return 0;
  if (value > parms->max) return reverse ? SHRT_MIN : SHRT_MAX;
  if (value < parms->min) return reverse ? SHRT_MAX : SHRT_MIN;
  const int64_t span = (int64_t)parms->max - parms->min;
  const int64_t numerator = reverse ?
      (int64_t)parms->max - (value < parms->avg ? flat * 2 : 0) - value :
      value - (value > parms->avg ? flat * 2 : 0) - parms->min;
  int64_t scaled = numerator * ((int64_t)SHRT_MAX - SHRT_MIN) /
                   (span - flat * 2) + SHRT_MIN;
  if (scaled > SHRT_MAX) scaled = SHRT_MAX;
  if (scaled < SHRT_MIN) scaled = SHRT_MIN;
  return (short)scaled;
}

static inline unsigned char mapping_axis_byte(int raw, const struct mapping_axis *parms, char halfaxis) {
  if (!mapping_axis_usable(parms)) return 0;
  if (halfaxis == 0) {
    const int64_t value = raw;
    const int64_t min = parms->min;
    const int64_t flat = parms->flat;
    if (value <= min + flat) return 0;
    if (value >= parms->max) return UCHAR_MAX;
    const int64_t denominator = (int64_t)parms->max - min - flat;
    int64_t scaled = (value - flat - min) * UCHAR_MAX / denominator;
    if (scaled < 0) scaled = 0;
    if (scaled > UCHAR_MAX) scaled = UCHAR_MAX;
    return (unsigned char)scaled;
  }
  const short val = mapping_axis_stick(raw, parms, false);
  if (halfaxis == '~')
    return (unsigned char)(UCHAR_MAX - mapping_axis_byte(raw, parms, 0));
  if (halfaxis == '-' && val < 0)
    return (unsigned char)(-(int)val * UCHAR_MAX / -(int)SHRT_MIN);
  if (halfaxis == '+' && val > 0)
    return (unsigned char)((int)val * UCHAR_MAX / SHRT_MAX);
  return 0;
}
