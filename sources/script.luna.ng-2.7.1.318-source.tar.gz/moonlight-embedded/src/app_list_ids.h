/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

/* Exact host ID and hex-encoded UTF-8 title, never the UI row number. */
static inline bool moonlight_app_id_line(FILE *out, int id, const char *title) {
  if (!out || id < 0 || !title || !*title) return false;
  size_t length = 0;
  while (length <= 4096 && title[length]) ++length;
  if (length > 4096 || fprintf(out, "%d\t", id) < 0) return false;
  for (size_t i = 0; i < length; ++i)
    if (fprintf(out, "%02x", (unsigned int)(unsigned char)title[i]) < 0)
      return false;
  return fputc('\n', out) != EOF;
}
