/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2019 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "loop.h"

#include "connection.h"

#include <sys/stat.h>
#include <sys/signalfd.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <poll.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <stdint.h>
#include <limits.h>

static struct pollfd* fds = NULL;
static FdHandler* fdHandlers = NULL;
static FdHandler* fdFaultHandlers = NULL;
static int numFds = 0;
static size_t fdCapacity;

static FdHandler tick_handler;
static FdHandler input_tick_handler;
void loop_set_input_tick_handler(FdHandler handler) { input_tick_handler = handler; }
void loop_set_tick_handler(FdHandler handler) { tick_handler = handler; }
static int sigFd;
static bool loopReady;
static bool loopError;

static int loop_sig_handler(int fd) {
  struct signalfd_siginfo info;
  if (read(fd, &info, sizeof(info)) != sizeof(info))
    return LOOP_ERROR;
  switch (info.ssi_signo) {
    case SIGINT:
    case SIGTERM:
    case SIGQUIT:
    case SIGHUP:
      return LOOP_RETURN;
  }
  return LOOP_OK;
}

static bool loop_reserve_fds(void) {
  if ((size_t)numFds < fdCapacity) return true;
  /* A small geometric capacity avoids per-hotplug realloc churn while
   * keeping all three event-loop tables aligned. No table is published
   * until EVERY allocation succeeds. */
  const size_t next_capacity = fdCapacity ? fdCapacity * 2 : 8;
  if (next_capacity <= fdCapacity || next_capacity > INT_MAX ||
      next_capacity > SIZE_MAX / sizeof(*fds) ||
      next_capacity > SIZE_MAX / sizeof(*fdHandlers) ||
      next_capacity > SIZE_MAX / sizeof(*fdFaultHandlers)) {
    errno = ENOMEM;
    return false;
  }
  struct pollfd *next_fds = malloc(next_capacity * sizeof(*fds));
  FdHandler *next_handlers = malloc(next_capacity * sizeof(*fdHandlers));
  FdHandler *next_faults = malloc(next_capacity * sizeof(*fdFaultHandlers));
  if (!next_fds || !next_handlers || !next_faults) {
    free(next_fds);
    free(next_handlers);
    free(next_faults);
    errno = ENOMEM;
    return false;
  }
  if (numFds) {
    memcpy(next_fds, fds, (size_t)numFds * sizeof(*fds));
    memcpy(next_handlers, fdHandlers, (size_t)numFds * sizeof(*fdHandlers));
    memcpy(next_faults, fdFaultHandlers,
           (size_t)numFds * sizeof(*fdFaultHandlers));
  }
  free(fds);
  free(fdHandlers);
  free(fdFaultHandlers);
  fds = next_fds;
  fdHandlers = next_handlers;
  fdFaultHandlers = next_faults;
  fdCapacity = next_capacity;
  return true;
}

bool loop_try_add_device_fd(int fd, FdHandler handler,
                            FdHandler on_invalid, int events) {
  if (fd < 0 || !handler) {
    errno = EINVAL;
    return false;
  }
  if (!loop_reserve_fds()) return false;
  const int fdindex = numFds++;
  fds[fdindex] = (struct pollfd){.fd=fd, .events=(short)events, .revents=0};
  fdHandlers[fdindex] = handler;
  fdFaultHandlers[fdindex] = on_invalid;
  return true;
}

bool loop_try_add_fd(int fd, FdHandler handler, int events) {
  return loop_try_add_device_fd(fd, handler, NULL, events);
}

void loop_add_device_fd(int fd, FdHandler handler,
                        FdHandler on_invalid, int events) {
  /* The legacy API is reserved for ESSENTIAL descriptors. Optional input
   * devices must call loop_try_add_device_fd and retire their own FD when
   * registration fails, not terminate healthy video/audio streams. */
  if (!loop_try_add_device_fd(fd, handler, on_invalid, events)) {
    fprintf(stderr, "Moonlight critical event registration failed: %s\n",
            strerror(errno));
    loop_request_error_stop();
  }
}

void loop_add_fd(int fd, FdHandler handler, int events) {
  if (!loop_try_add_fd(fd, handler, events)) {
    fprintf(stderr, "Moonlight critical event registration failed: %s\n",
            strerror(errno));
    loop_request_error_stop();
  }
}

void loop_remove_fd(int fd) {
  /* Hotplug removal can be repeated. Unknown fds leave the list intact. */
  for (int i = 0; i < numFds; i++) {
    if (fds[i].fd != fd)
      continue;
    numFds--;
    if (i != numFds) {
      fds[i] = fds[numFds];
      fdHandlers[i] = fdHandlers[numFds];
      fdFaultHandlers[i] = fdFaultHandlers[numFds];
    }
    return;
  }
}

static void termination_sigset(sigset_t *set) {
  sigemptyset(set);
  sigaddset(set, SIGHUP);
  sigaddset(set, SIGTERM);
  sigaddset(set, SIGINT);
  sigaddset(set, SIGQUIT);
}

void loop_block_termination_signals(void) {
  sigset_t set;
  termination_sigset(&set);
  /* A newly-created worker inherits this thread's signal mask. Blocking
   * only in loop_init() is too late for libCEC and evdev worker threads. */
  int result = pthread_sigmask(SIG_BLOCK, &set, NULL);
  if (result != 0) {
    errno = result;
    perror("Unable to block Moonlight termination signals");
    exit(EXIT_FAILURE);
  }
}

void loop_init() {
  __atomic_store_n(&loopError, false, __ATOMIC_RELEASE);
  main_thread_id = pthread_self();
  loop_block_termination_signals(); /* Also safe for callers without workers. */
  sigset_t set;
  termination_sigset(&set);
  sigFd = signalfd(-1, &set, SFD_CLOEXEC);
  if (sigFd < 0) {
    perror("Moonlight signalfd");
    exit(EXIT_FAILURE);
  }
  loop_add_fd(sigFd, loop_sig_handler, POLLIN | POLLERR | POLLHUP);
  loopReady = true;
}

void loop_request_stop(void) {
  if (loopReady)
    kill(getpid(), SIGTERM); /* Process-pending: startup watcher or signalfd owns it. */
}

void loop_request_error_stop(void) {
  __atomic_store_n(&loopError, true, __ATOMIC_RELEASE);
  loop_request_stop();
}

bool loop_stream_failed(void) {
  return __atomic_load_n(&loopError, __ATOMIC_ACQUIRE);
}

static int loop_exit_result(void) {
  return __atomic_load_n(&loopError, __ATOMIC_ACQUIRE) ? LOOP_ERROR : LOOP_OK;
}

int loop_main() {
  for (;;) {
    if (__atomic_load_n(&loopError, __ATOMIC_ACQUIRE))
      return LOOP_ERROR;
    if (tick_handler && tick_handler(-1) != LOOP_OK)
      return LOOP_ERROR;
    if (input_tick_handler) {
      int status = input_tick_handler(-1);
      if (status == LOOP_RETURN) return loop_exit_result();
      if (status != LOOP_OK) return LOOP_ERROR;
    }
    int result = poll(fds, numFds, input_tick_handler ? 20 : tick_handler ? 250 : -1);
    if (result < 0) {
      if (errno == EINTR) continue;
      perror("Moonlight input poll failed");
      return LOOP_ERROR;
    }
    if (result == 0) continue;

    /* Callbacks may add or remove descriptors, including their own. Do not
     * retain pointers into reallocatable arrays across the callback. */
    for (int i = 0; i < numFds;) {
      const int fd = fds[i].fd;
      const FdHandler cb = fdHandlers[i];
      const short events = fds[i].revents;
      fds[i].revents = 0;
      if (!events) { ++i; continue; }
      /* Only a device that explicitly owns a fault handler may treat
       * POLLERR/POLLHUP as recoverable. Essential descriptors retain their
       * ordinary callback handling, and POLLNVAL remains fatal by default. */
      if ((events & POLLNVAL) ||
          ((events & (POLLERR | POLLHUP)) && fdFaultHandlers[i])) {
        FdHandler on_invalid = fdFaultHandlers[i];
        if (!on_invalid) {
          fprintf(stderr, "Moonlight input poll: critical invalid descriptor %d\n", fd);
          return LOOP_ERROR;
        }
        const int fault_status = on_invalid(fd);
        /* Recovery MUST retire the exact bad registration, or we'd enter an
         * endless POLLNVAL spin. Keep essential/unknown faults fatal. */
        if (fault_status != LOOP_OK ||
            (i < numFds && fds[i].fd == fd && fdHandlers[i] == cb)) {
          fprintf(stderr, "Moonlight input poll: unrecovered invalid descriptor %d\n", fd);
          return LOOP_ERROR;
        }
        continue; /* loop_remove_fd moved the next fd into this slot. */
      }
      int status = cb(fd);
      if (status == LOOP_RETURN)
        return loop_exit_result();
      if (status == LOOP_ERROR)
        return LOOP_ERROR;
      /* loop_remove_fd swaps the final slot into the removed position.
       * Revisit that index if it no longer contains this registration. */
      if (i < numFds && fds[i].fd == fd && fdHandlers[i] == cb)
        ++i;
    }
  }
}
