/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_ALSA_PENDING_QUEUE_H
#define MOONLIGHT_ALSA_PENDING_QUEUE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <limits.h>
#include <string.h>

/* Bounded PCM carry-over between consecutive audio callbacks. Always retain
 * the newest audio on overflow to avoid unbounded A/V drift. */
typedef struct {
  unsigned char *storage;
  size_t frame_bytes;
  unsigned long capacity_frames;
  unsigned long queued_frames;
} AlsaPendingQueue;

static inline bool alsa_pending_queue_configure(AlsaPendingQueue *q, void *storage,
                                                size_t storage_bytes,
                                                unsigned long capacity_frames,
                                                size_t frame_bytes) {
  if (!q || !storage || !capacity_frames || !frame_bytes ||
      capacity_frames > SIZE_MAX / frame_bytes ||
      (size_t)capacity_frames * frame_bytes > storage_bytes)
    return false;
  *q = (AlsaPendingQueue){
    .storage = storage, .frame_bytes = frame_bytes,
    .capacity_frames = capacity_frames, .queued_frames = 0
  };
  return true;
}

static inline void alsa_pending_queue_clear(AlsaPendingQueue *q) {
  if (q) q->queued_frames = 0;
}

static inline void alsa_pending_queue_consume(AlsaPendingQueue *q,
                                               unsigned long frames) {
  if (!q || !q->storage || !q->queued_frames) return;
  if (frames >= q->queued_frames) {
    q->queued_frames = 0;
    return;
  }
  q->queued_frames -= frames;
  memmove(q->storage, q->storage + (size_t)frames * q->frame_bytes,
          (size_t)q->queued_frames * q->frame_bytes);
}

/* Return the number of discarded frames. All copies stay within the configured
 * storage, including when a single decoded packet exceeds queue capacity. */
static inline unsigned long alsa_pending_queue_push(AlsaPendingQueue *q,
                                                     const void *pcm,
                                                     unsigned long frames) {
  if (!q || !q->storage || !q->capacity_frames || (!pcm && frames)) return frames;
  if (!frames) return 0;
  if (frames > SIZE_MAX / q->frame_bytes) return frames;
  const unsigned char *source = pcm;
  if (frames >= q->capacity_frames) {
    const unsigned long new_drops = frames - q->capacity_frames;
    const unsigned long dropped =
        q->queued_frames > ULONG_MAX - new_drops ? ULONG_MAX :
        q->queued_frames + new_drops;
    memcpy(q->storage, source + (size_t)new_drops * q->frame_bytes,
           (size_t)q->capacity_frames * q->frame_bytes);
    q->queued_frames = q->capacity_frames;
    return dropped;
  }
  unsigned long dropped = 0;
  if (q->queued_frames > q->capacity_frames - frames) {
    dropped = q->queued_frames - (q->capacity_frames - frames);
    alsa_pending_queue_consume(q, dropped);
  }
  memcpy(q->storage + (size_t)q->queued_frames * q->frame_bytes,
         source, (size_t)frames * q->frame_bytes);
  q->queued_frames += frames;
  return dropped;
}

#endif
