/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_ALSA_QUEUE_PRESSURE_H
#define MOONLIGHT_ALSA_QUEUE_PRESSURE_H
#include <stdbool.h>
#include <stdint.h>
#define ALSA_PRESSURE_LOG_INTERVAL_US 5000000ULL
typedef struct {
  uint64_t last_log_us;
  uint64_t suppressed;
  uint64_t events;
} AlsaQueuePressureLog;

/* Diagnostic logging only: never change the bounded 20-ms PCM carry-over. */
static inline bool alsa_queue_pressure_log(AlsaQueuePressureLog *s,
                                           uint64_t now_us) {
  if (!s) return false;
  ++s->events;
  if (s->events == 1 ||
      (now_us && now_us >= s->last_log_us &&
       now_us - s->last_log_us >= ALSA_PRESSURE_LOG_INTERVAL_US)) {
    s->last_log_us = now_us;
    return true;
  }
  ++s->suppressed;
  return false;
}
#endif
