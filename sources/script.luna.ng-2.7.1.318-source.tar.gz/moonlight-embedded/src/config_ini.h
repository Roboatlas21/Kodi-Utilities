/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_CONFIG_INI_H
#define MOONLIGHT_CONFIG_INI_H

#include "config_section.h"
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

/* The native configuration is deliberately a small, bounded INI subset:
 *  - legacy flat key=value files, or exactly one [Moonlight] section;
 *  - unrelated sections and a preamble in sectioned files are ignored;
 *  - whole-line # and ; comments, optional horizontal whitespace and CRLF;
 *  - repeated input keys only, with no duplicate scalar assignments;
 *  - malformed lines, embedded controls and truncated sections are errors.
 * The caller separately rejects unknown, dangerous and invalid option values.
 */
#define MOONLIGHT_INI_MAX_BYTES (1024U * 1024U)
#define MOONLIGHT_INI_MAX_ENTRIES 96U

typedef struct {
  char *key;
  char *value;
  unsigned line;
} MoonlightIniEntry;

typedef struct {
  MoonlightIniEntry entries[MOONLIGHT_INI_MAX_ENTRIES];
  size_t count;
} MoonlightIni;

static inline char *moonlight_ini_trim(char *value) {
  while (*value == ' ' || *value == '\t') ++value;
  size_t n = strlen(value);
  while (n && (value[n - 1] == ' ' || value[n - 1] == '\t'))
    value[--n] = '\0';
  return value;
}

static inline bool moonlight_ini_parse(char *source, size_t bytes,
                                       MoonlightIni *result) {
  if (!source || !result || bytes > MOONLIGHT_INI_MAX_BYTES ||
      source[bytes] != '\0' || memchr(source, '\0', bytes)) return false;
  /* Publish no partial entries if a later line is malformed. */
  MoonlightIni parsed = {0};
  /* Normalize CRLF and LF before interpreting keys or section headers. */
  for (size_t i = 0; i < bytes; ++i) {
    const unsigned char ch = (unsigned char)source[i];
    if (ch == '\n' || (ch == '\r' && i + 1 == bytes))
      source[i] = '\0';
    else if (ch == '\r' && source[i + 1] == '\n')
      source[i] = ' '; /* trimmed below; one line, not two empty tokens */
    else if ((ch < 32 && ch != '\t') || ch == 127) return false;
  }
  bool sectioned = false, found = false;
  for (char *line = source; line < source + bytes; line += strlen(line) + 1) {
    bool matched = false;
    int marker = moonlight_config_section_header(line, &matched);
    if (marker < 0) return false;
    if (marker == 1) {
      sectioned = true;
      if (matched && found) return false;
      if (matched) found = true;
    }
  }
  if (sectioned && !found) return false;

  bool active = !sectioned;
  unsigned line_number = 0;
  for (char *line = source; line < source + bytes;) {
    ++line_number;
    /* Save the next line before splitting the key at its '='. */
    char *next = line + strlen(line) + 1;
    bool matched = false;
    int marker = moonlight_config_section_header(line, &matched);
    if (marker == 1) { active = matched; line = next; continue; }
    if (!active) { line = next; continue; }
    char *entry = moonlight_ini_trim(line);
    if (!*entry || *entry == '#' || *entry == ';') {
      line = next;
      continue;
    }
    char *separator = strchr(entry, '=');
    if (!separator) return false;
    *separator = '\0';
    char *key = moonlight_ini_trim(entry);
    char *value = moonlight_ini_trim(separator + 1);
    if (!*key || !*value) return false;
    for (const unsigned char *p = (const unsigned char *)key; *p; ++p)
      if (!(('a' <= *p && *p <= 'z') || ('A' <= *p && *p <= 'Z') ||
            ('0' <= *p && *p <= '9') || *p == '_' || *p == '-')) return false;
    if (parsed.count == MOONLIGHT_INI_MAX_ENTRIES) return false;
    if (strcmp(key, "input"))
      for (size_t i = 0; i < parsed.count; ++i)
        if (!strcmp(parsed.entries[i].key, key)) return false;
    parsed.entries[parsed.count++] = (MoonlightIniEntry){key, value, line_number};
    line = next;
  }
  *result = parsed;
  return true;
}
#endif
