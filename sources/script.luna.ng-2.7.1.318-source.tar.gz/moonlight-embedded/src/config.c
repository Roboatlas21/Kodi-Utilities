/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "platform.h"
#include "config.h"
#include "config_section.h"
#include "config_ini.h"
#include "util.h"
#include "cpu.h"
#include "config_numeric.h"

#include "input/evdev.h"
#include "audio/audio.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#include <strings.h>

#define MOONLIGHT_PATH "/moonlight"
#define USER_PATHS "."
#define DEFAULT_CONFIG_DIR "/.config"
#define DEFAULT_CACHE_DIR "/.cache"

#define write_config_string(fd, key, value) fprintf(fd, "%s = %s\n", key, value)
#define write_config_int(fd, key, value) fprintf(fd, "%s = %d\n", key, value)
#define write_config_bool(fd, key, value) fprintf(fd, "%s = %s\n", key, value ? "true":"false")

bool inputAdded = false;

static struct option long_options[] = {
  {"720", no_argument, NULL, 'a'},
  {"1080", no_argument, NULL, 'b'},
  {"4k", no_argument, NULL, '0'},
  {"width", required_argument, NULL, 'c'},
  {"height", required_argument, NULL, 'd'},
  {"bitrate", required_argument, NULL, 'g'},
  {"packetsize", required_argument, NULL, 'h'},
  {"app", required_argument, NULL, 'i'},
  {"appid", required_argument, NULL, 'I'},
  {"input", required_argument, NULL, 'j'},
  {"mapping", required_argument, NULL, 'k'},
  {"nosops", no_argument, NULL, 'l'},
  {"audio", required_argument, NULL, 'm'},
  {"localaudio", no_argument, NULL, 'n'},
  {"config", required_argument, NULL, 'o'},
  {"platform", required_argument, NULL, 'p'},
  {"save", required_argument, NULL, 'q'},
  {"keydir", required_argument, NULL, 'r'},
  {"remote", required_argument, NULL, 's'},
  {"windowed", no_argument, NULL, 't'},
  {"surround", required_argument, NULL, 'u'},
  {"fps", required_argument, NULL, 'v'},
  {"codec", required_argument, NULL, 'x'},
  {"nounsupported", no_argument, NULL, 'y'},
  {"quitappafter", no_argument, NULL, '1'},
  {"viewonly", no_argument, NULL, '2'},
  {"rotate", required_argument, NULL, '3'},
  {"verbose", no_argument, NULL, 'z'},
  {"debug", no_argument, NULL, 'Z'},
  {"nomouseemulation", no_argument, NULL, '4'},
  {"pin", required_argument, NULL, '5'},
  {"port", required_argument, NULL, '6'},
  {"hdr", no_argument, NULL, '7'},
  {"cec", required_argument, NULL, 'C'},
  {"osd", no_argument, NULL, '8'},
  {"osdargs", required_argument, NULL, '9'},
  {0, 0, 0, 0},
};

/* Config discovery must see inaccessible existing files as errors, not
 * silently fall through to another user/system configuration. Other callers
 * (such as controller mapping lookup) still require a readable file. */
static bool moonlight_path_matches(const char *path, bool readable_only) {
  if (readable_only) return access(path, R_OK) == 0;
  struct stat found;
  if (lstat(path, &found) == 0) return true;
  return errno != ENOENT && errno != ENOTDIR;
}

static char *get_path_with_policy(char *name, char *extra_data_dirs,
                                  bool readable_only) {
  if (moonlight_path_matches(name, readable_only))
    return readable_only ? name : strdup(name);
  const char *xdg_config_dir = getenv("XDG_CONFIG_DIR");
  const char *home_dir = getenv("HOME");
  if (!home_dir) {
    struct passwd *pw = getpwuid(getuid());
    if (!pw || !pw->pw_dir || !*pw->pw_dir) {
      fprintf(stderr, "Cannot determine home directory for Moonlight configuration\n");
      return NULL;
    }
    home_dir = pw->pw_dir;
  }
  if (!extra_data_dirs) extra_data_dirs = "/usr/share:/usr/local/share";
  if (!xdg_config_dir) xdg_config_dir = home_dir;
  const int needed = snprintf(NULL, 0,
                              USER_PATHS ":%s:%s/" DEFAULT_CONFIG_DIR ":%s/",
                              xdg_config_dir, home_dir, extra_data_dirs);
  if (needed < 0) return NULL;
  const size_t length = (size_t)needed + 1;
  char *dirs = malloc(length);
  if (!dirs) return NULL;
  snprintf(dirs, length, USER_PATHS ":%s:%s/" DEFAULT_CONFIG_DIR ":%s/",
           xdg_config_dir, home_dir, extra_data_dirs);
  size_t cap = strlen(dirs) + strlen(MOONLIGHT_PATH) + strlen(name) + 2;
  char *path = malloc(cap);
  if (!path) { free(dirs); return NULL; }
  for (char *cursor = dirs;;) {
    char *end = strchr(cursor, ':');
    const size_t dir_len = end ? (size_t)(end - cursor) : strlen(cursor);
    if (dir_len) {
      memcpy(path, cursor, dir_len);
      path[dir_len] = '\0';
      snprintf(path + dir_len, cap - dir_len,
               path[0] == '/' ? MOONLIGHT_PATH "/%s" : "/%s", name);
      if (moonlight_path_matches(path, readable_only)) {
        free(dirs);
        return path;
      }
    }
    if (!end) break;
    cursor = end + 1;
  }
  free(dirs);
  free(path);
  return NULL;
}

char* get_path(char* name, char* extra_data_dirs) {
  return get_path_with_policy(name, extra_data_dirs, true);
}

static char *get_existing_config_path(char *name, char *extra_data_dirs) {
  return get_path_with_policy(name, extra_data_dirs, false);
}

static int parse_stream_number(const char *option, const char *value,
                               int minimum, int maximum) {
  int parsed = 0;
  if (!moonlight_parse_bounded_int(value, minimum, maximum, &parsed)) {
    fprintf(stderr, "Invalid %s: expected integer between %d and %d\n",
            option, minimum, maximum);
    exit(EXIT_FAILURE);
  }
  return parsed;
}

static void parse_argument(int c, char* value, PCONFIGURATION config) {
  switch (c) {
  case 'a':
    config->stream.width = 1280;
    config->stream.height = 720;
    break;
  case 'b':
    config->stream.width = 1920;
    config->stream.height = 1080;
    break;
  case '0':
    config->stream.width = 3840;
    config->stream.height = 2160;
    break;
  case 'c':
    config->stream.width = parse_stream_number("width", value, 64, 7680);
    break;
  case 'd':
    config->stream.height = parse_stream_number("height", value, 64, 4320);
    break;
  case 'g':
    config->stream.bitrate = parse_stream_number("bitrate", value, -1, 500000);
    break;
  case 'h':
    config->stream.packetSize = parse_stream_number("packetsize", value, 256, 1500);
    break;
  case 'i':
    config->app = value;
    break;
  case 'I':
    config->app_id = parse_stream_number("Sunshine app ID", value, 0, INT_MAX);
    break;
  case 'j':
    if (config->inputsCount >= MAX_INPUTS) {
      fprintf(stderr, "Too many input paths specified (maximum %d)\n", MAX_INPUTS);
      exit(EXIT_FAILURE);
    }
    config->inputs[config->inputsCount] = value;
    config->inputsCount++;
    inputAdded = true;
    break;
  case 'k':
    config->mapping = get_path(value, getenv("XDG_DATA_DIRS"));
    if (config->mapping == NULL) {
      fprintf(stderr, "Unable to open custom mapping file: %s\n", value);
      exit(-1);
    }
    break;
  case 'l':
    config->sops = false;
    break;
  case 'm':
    config->audio_device = value;
    break;
  case 'n':
    config->localaudio = true;
    break;
  case 'o':
    if (!config_file_parse(value, config))
      exit(EXIT_FAILURE);

    break;
  case 'p':
    config->platform = value;
    break;
  case 'q':
    config->config_file = value;
    break;
  case 'r':
    /* A key directory is supplied by local configuration/CLI, but it still
     * must fit the fixed credential path buffer without truncation. */
    if (value == NULL || strlen(value) >= sizeof(config->key_dir)) {
      fprintf(stderr, "Key directory path exceeds %zu bytes\n", sizeof(config->key_dir) - 1);
      exit(EXIT_FAILURE);
    }
    memcpy(config->key_dir, value, strlen(value) + 1);
    break;
  case 's':
    if (strcasecmp(value, "auto") == 0)
      config->stream.streamingRemotely = STREAM_CFG_AUTO;
    else if (strcasecmp(value, "true") == 0 || strcasecmp(value, "yes") == 0)
      config->stream.streamingRemotely = STREAM_CFG_REMOTE;
    else if (strcasecmp(value, "false") == 0 || strcasecmp(value, "no") == 0)
      config->stream.streamingRemotely = STREAM_CFG_LOCAL;
    break;

  case 't':
    config->fullscreen = false;
    break;
  case 'u':
    if (strcasecmp(value, "5.1") == 0)
      config->stream.audioConfiguration = AUDIO_CONFIGURATION_51_SURROUND;
    else if (strcasecmp(value, "7.1") == 0)
      config->stream.audioConfiguration = AUDIO_CONFIGURATION_71_SURROUND;
    break;
  case 'v':
    config->stream.fps = parse_stream_number("fps", value, 1, 240);
    break;
  case 'x':
    if (strcasecmp(value, "auto") == 0)
      config->codec = CODEC_UNSPECIFIED;
    else if (strcasecmp(value, "h264") == 0)
      config->codec = CODEC_H264;
    else if (strcasecmp(value, "h265") == 0 || strcasecmp(value, "hevc") == 0)
      config->codec = CODEC_HEVC;
    else if (strcasecmp(value, "av1") == 0)
      config->codec = CODEC_AV1;
    break;
  case 'y':
    config->unsupported = false;
    break;
  case '1':
    config->quitappafter = true;
    break;
  case '2':
    config->viewonly = true;
    break;
  case '3':
    config->rotate = parse_stream_number("rotation", value, 0, 270);
    if (config->rotate != 0 && config->rotate != 90 &&
        config->rotate != 180 && config->rotate != 270) {
      fprintf(stderr, "Invalid rotation: expected 0, 90, 180, or 270 degrees\n");
      exit(EXIT_FAILURE);
    }
    break;
  case 'z':
    config->debug_level = 1;
    break;
  case 'Z':
    config->debug_level = 2;
    break;
  case '4':
    config->mouse_emulation = false;
    break;
  case '5':
    config->pin = parse_stream_number("pairing PIN", value, 1, 9999);
    break;
  case '6':
    config->port = parse_stream_number("host port", value, 1, 65535);
    break;
  case 'C':
    // Luna writes an explicit boolean; do not treat "cec = false" as enabled.
    if (strcasecmp(value, "true") == 0 || strcasecmp(value, "yes") == 0)
      config->cec = true;
    else if (strcasecmp(value, "false") == 0 || strcasecmp(value, "no") == 0)
      config->cec = false;
    else {
      fprintf(stderr, "Invalid cec setting: expected true/false\n");
      exit(EXIT_FAILURE);
    }
    break;
  case '7':
    if (!value || strcasecmp(value, "true") == 0 || strcasecmp(value, "yes") == 0)
      config->hdr = true;
    else if (strcasecmp(value, "false") == 0 || strcasecmp(value, "no") == 0)
      config->hdr = false;
    else {
      fprintf(stderr, "Invalid hdr setting: expected true/false\n");
      exit(EXIT_FAILURE);
    }
    break;
  case '8':
    config->osd = true;
    break;
  case '9':
    config->osdargs = value;
    break;
  case 1:
    if (config->action == NULL)
      config->action = value;
    else if (!config->command_line_address_set) {
      /* A saved config address is only a default. Luna's explicit Quit
       * destination (or any explicitly supplied host) must override it. */
      config->address = value;
      config->command_line_address_set = true;
    } else {
      fprintf(stderr, "Too many positional arguments\n");
      exit(EXIT_FAILURE);
    }
  }
}

/* The native INI format has deliberately stricter semantics than the CLI:
 * never recurse into another -config file or write a -save destination,
 * and never accept invalid values by silently keeping previous defaults. */
static int moonlight_ini_option(const char *key) {
  if (!strcmp(key, "address")) return 'A';
  if (!strcmp(key, "sops")) return 'S';
  for (int i = 0; long_options[i].name; ++i)
    if (!strcmp(key, long_options[i].name)) return long_options[i].val;
  return -1;
}

static bool moonlight_ini_bool(const char *text, bool *out) {
  if (!strcasecmp(text, "true") || !strcasecmp(text, "yes") ||
      !strcmp(text, "1")) { *out = true; return true; }
  if (!strcasecmp(text, "false") || !strcasecmp(text, "no") ||
      !strcmp(text, "0")) { *out = false; return true; }
  return false;
}

static bool moonlight_ini_number(const char *value, int lo, int hi) {
  int parsed;
  return moonlight_parse_bounded_int(value, lo, hi, &parsed);
}

static bool moonlight_ini_valid(const MoonlightIniEntry *entry) {
  const int code = moonlight_ini_option(entry->key);
  const char *value = entry->value;
  const size_t length = strlen(value);
  if (code < 0 || code == 'o' || code == 'q' || !length || length > 4095)
    return false;
  switch (code) {
  case 'A':
    /* Keep host identities consistent with hosts/<name>.conf lookup. */
    if (length > 255 || !strcmp(value, ".") || !strcmp(value, "..")) return false;
    for (const unsigned char *p = (const unsigned char *)value; *p; ++p)
      if (!(('a' <= *p && *p <= 'z') || ('A' <= *p && *p <= 'Z') ||
            ('0' <= *p && *p <= '9') || *p == '.' || *p == '-' ||
            *p == '_' || *p == ':' || *p == '[' || *p == ']' || *p == '%'))
        return false;
    return true;
  case 'c': return moonlight_ini_number(value, 64, 7680);
  case 'd': return moonlight_ini_number(value, 64, 4320);
  case 'g': return moonlight_ini_number(value, -1, 500000);
  case 'h': return moonlight_ini_number(value, 256, 1500);
  case 'I': return moonlight_ini_number(value, 0, INT_MAX);
  case 'v': return moonlight_ini_number(value, 1, 240);
  case '3':
    return moonlight_ini_number(value, 0, 270) &&
           (!strcmp(value, "0") || !strcmp(value, "90") ||
            !strcmp(value, "180") || !strcmp(value, "270"));
  case '5': return moonlight_ini_number(value, 1, 9999);
  case '6': return moonlight_ini_number(value, 1, 65535);
  case 's':
    return !strcasecmp(value, "auto") || !strcasecmp(value, "true") ||
           !strcasecmp(value, "yes") || !strcasecmp(value, "false") ||
           !strcasecmp(value, "no");
  case 'u':
    return !strcasecmp(value, "5.1") || !strcasecmp(value, "7.1") ||
           !strcasecmp(value, "stereo") || !strcasecmp(value, "false");
  case 'x':
    return !strcasecmp(value, "auto") || !strcasecmp(value, "h264") ||
           !strcasecmp(value, "h265") || !strcasecmp(value, "hevc") ||
           !strcasecmp(value, "av1");
  case 'r': return length < sizeof(((PCONFIGURATION)0)->key_dir);
  case '9': return length < 256; /* osd_parse_options has a 256-byte bound */
  case 'C': case 'S': case '7': case 'a': case 'b': case '0':
  case 'l': case 'n': case 't': case 'y': case '1': case '2':
  case 'z': case 'Z': case '4': case '8': {
    bool enabled;
    return moonlight_ini_bool(value, &enabled);
  }
  default:
    /* String-valued app, input, mapping, audio and platform settings. */
    return true;
  }
}

static bool config_file_parse_checked(char* filename, PCONFIGURATION config,
                                      const char *expected_host) {
  if (!filename || !config) return false;
  /* Never block on a pipe or follow a symlinked configuration into an
   * untrusted location. A missing or unreadable requested file is an error. */
  int fd = open(filename, O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
  if (fd < 0) {
    fprintf(stderr, "Cannot open Moonlight configuration %s: %s\n",
            filename, strerror(errno));
    return false;
  }
  struct stat info;
  if (fstat(fd, &info) || !S_ISREG(info.st_mode) ||
      info.st_size > (off_t)MOONLIGHT_INI_MAX_BYTES || info.st_size < 0) {
    close(fd);
    fprintf(stderr, "Moonlight configuration is not a bounded regular file: %s\n", filename);
    return false;
  }
  const size_t bytes = (size_t)info.st_size;
  char *source = malloc(bytes + 1);
  if (!source) { close(fd); return false; }
  FILE *stream = fdopen(fd, "rb");
  if (!stream) { close(fd); free(source); return false; }
  bool loaded = fread(source, 1, bytes, stream) == bytes && !ferror(stream);
  if (loaded && fgetc(stream) != EOF) loaded = false; /* Concurrently extended */
  if (ferror(stream)) loaded = false;
  if (fclose(stream)) loaded = false;
  if (!loaded) {
    free(source);
    fprintf(stderr, "Moonlight configuration could not be read fully: %s\n", filename);
    return false;
  }
  source[bytes] = '\0';
  MoonlightIni entries;
  if (!moonlight_ini_parse(source, bytes, &entries)) {
    fprintf(stderr, "Malformed, duplicate, or ambiguous Moonlight INI entries: %s\n", filename);
    free(source);
    return false;
  }
  /* Validate *all* values before attempting a single conversion. The live
   * configuration and inputAdded remain unchanged on every parser failure. */
  size_t incoming_inputs = 0;
  for (size_t i = 0; i < entries.count; ++i) {
    const MoonlightIniEntry *entry = &entries.entries[i];
    if (!moonlight_ini_valid(entry) ||
        (!strcmp(entry->key, "input") && ++incoming_inputs +
         (size_t)config->inputsCount > MAX_INPUTS)) {
      fprintf(stderr, "Invalid Moonlight configuration option '%s' on line %u in %s\n",
              entry->key, entry->line, filename);
      free(source);
      return false;
    }
  }
  CONFIGURATION staged = *config;
  char *owned[MOONLIGHT_INI_MAX_ENTRIES] = {0};
  size_t owned_count = 0;
  for (size_t i = 0; i < entries.count; ++i) {
    const MoonlightIniEntry *entry = &entries.entries[i];
    const int code = moonlight_ini_option(entry->key);
    bool enabled = false;
    if (code == 'S' || code == 'C' || code == '7' ||
        (code != 'A' && code != 's' && code != 'u' && code != 'x' &&
         code != 'c' && code != 'd' && code != 'g' && code != 'h' &&
         code != 'I' && code != 'v' && code != '3' && code != '5' &&
         code != '6' && code != 'r' && code != '9' && code != 'i' &&
         code != 'j' && code != 'k' && code != 'm' && code != 'p'))
      (void)moonlight_ini_bool(entry->value, &enabled);
    switch (code) {
    case 'A': case 'i': case 'j': case 'k': case 'm': case 'p': case '9': {
      char *copy = strdup(entry->value);
      if (!copy) goto failed;
      if (code == 'k') {
        char *mapping = get_path(copy, getenv("XDG_DATA_DIRS"));
        if (!mapping) { free(copy); goto failed; }
        if (mapping != copy) free(copy);
        copy = mapping;
      }
      owned[owned_count++] = copy;
      switch (code) {
      case 'A': staged.address = copy; break;
      case 'i': staged.app = copy; break;
      case 'j': staged.inputs[staged.inputsCount++] = copy; break;
      case 'k': staged.mapping = copy; break;
      case 'm': staged.audio_device = copy; break;
      case 'p': staged.platform = copy; break;
      case '9': staged.osdargs = copy; break;
      }
      break;
    }
    case 'S': staged.sops = enabled; break;
    case 'C': staged.cec = enabled; break;
    case '7': staged.hdr = enabled; break;
    case 'l': staged.sops = !enabled; break;
    case 'n': staged.localaudio = enabled; break;
    case 't': staged.fullscreen = !enabled; break;
    case 'y': staged.unsupported = !enabled; break;
    case '1': staged.quitappafter = enabled; break;
    case '2': staged.viewonly = enabled; break;
    case '4': staged.mouse_emulation = !enabled; break;
    case '8': staged.osd = enabled; break;
    case 'z':
      if (enabled) staged.debug_level = 1;
      else if (staged.debug_level == 1) staged.debug_level = 0;
      break;
    case 'Z':
      if (enabled) staged.debug_level = 2;
      else if (staged.debug_level == 2) staged.debug_level = 0;
      break;
    case 'a':
      if (enabled) { staged.stream.width = 1280; staged.stream.height = 720; }
      break;
    case 'b':
      if (enabled) { staged.stream.width = 1920; staged.stream.height = 1080; }
      break;
    case '0':
      if (enabled) { staged.stream.width = 3840; staged.stream.height = 2160; }
      break;
    case 'c':
      if (!moonlight_parse_bounded_int(entry->value, 64, 7680, &staged.stream.width))
        goto failed;
      break;
    case 'd':
      if (!moonlight_parse_bounded_int(entry->value, 64, 4320, &staged.stream.height))
        goto failed;
      break;
    case 'g':
      if (!moonlight_parse_bounded_int(entry->value, -1, 500000, &staged.stream.bitrate))
        goto failed;
      break;
    case 'h':
      if (!moonlight_parse_bounded_int(entry->value, 256, 1500, &staged.stream.packetSize))
        goto failed;
      break;
    case 'I':
      if (!moonlight_parse_bounded_int(entry->value, 0, INT_MAX, &staged.app_id))
        goto failed;
      break;
    case 'v':
      if (!moonlight_parse_bounded_int(entry->value, 1, 240, &staged.stream.fps))
        goto failed;
      break;
    case '3':
      if (!moonlight_parse_bounded_int(entry->value, 0, 270, &staged.rotate))
        goto failed;
      break;
    case '5':
      if (!moonlight_parse_bounded_int(entry->value, 1, 9999, &staged.pin))
        goto failed;
      break;
    case '6': {
      int port = 0;
      if (!moonlight_parse_bounded_int(entry->value, 1, 65535, &port))
        goto failed;
      staged.port = (unsigned short)port;
      break;
    }
    case 'r':
      memcpy(staged.key_dir, entry->value, strlen(entry->value) + 1);
      break;
    case 's':
      staged.stream.streamingRemotely = !strcasecmp(entry->value, "auto")
          ? STREAM_CFG_AUTO
          : (!strcasecmp(entry->value, "true") ||
             !strcasecmp(entry->value, "yes") ? STREAM_CFG_REMOTE : STREAM_CFG_LOCAL);
      break;
    case 'u':
      staged.stream.audioConfiguration =
          !strcasecmp(entry->value, "5.1") ? AUDIO_CONFIGURATION_51_SURROUND :
          !strcasecmp(entry->value, "7.1") ? AUDIO_CONFIGURATION_71_SURROUND :
          AUDIO_CONFIGURATION_STEREO;
      break;
    case 'x':
      staged.codec = !strcasecmp(entry->value, "auto") ? CODEC_UNSPECIFIED :
                     !strcasecmp(entry->value, "h264") ? CODEC_H264 :
                     (!strcasecmp(entry->value, "h265") ||
                      !strcasecmp(entry->value, "hevc")) ? CODEC_HEVC : CODEC_AV1;
      break;
    default:
      /* INI conversion never calls the CLI's exit()-based parser. New
       * options must be supported explicitly to preserve atomic failure. */
      goto failed;
    }
  }
  if (!moonlight_stream_numbers_valid(staged.stream.width,
                                      staged.stream.height,
                                      staged.stream.fps,
                                      staged.stream.packetSize,
                                      staged.stream.bitrate)) goto failed;
  /* A host override is rejected before any of its changes are committed. */
  if (expected_host && (!staged.address ||
      strcmp(staged.address, expected_host) != 0)) {
    fprintf(stderr, "Host-specific Moonlight configuration would redirect selected host: %s\n",
            filename);
    goto failed;
  }
  *config = staged;
  inputAdded = config->inputsCount > 0;
  free(source);
  return true;
failed:
  for (size_t i = 0; i < owned_count; ++i) free(owned[i]);
  free(source);
  fprintf(stderr, "Moonlight configuration staging failed: %s\n", filename);
  return false;
}

bool config_file_parse(char *filename, PCONFIGURATION config) {
  return config_file_parse_checked(filename, config, NULL);
}

bool config_file_parse_for_host(char *filename, PCONFIGURATION config,
                                const char *expected_host) {
  if (!expected_host || !*expected_host) return false;
  return config_file_parse_checked(filename, config, expected_host);
}

/* Native -save must emit the same strict, sectioned format accepted by Luna.
 * Reject control characters before writing: a CLI app title with a newline
 * must not be able to inject a second address or an arbitrary INI key. */
static bool config_save_value_safe(const char *value) {
  if (!value || !*value || strlen(value) > 4095) return false;
  for (const unsigned char *p = (const unsigned char *)value; *p; ++p)
    if (*p < 32 || *p == 127) return false;
  return true;
}

static void config_save_sync_parent(const char *filename) {
  char *copy = strdup(filename);
  if (!copy) return;
  char *slash = strrchr(copy, '/');
  const char *directory = ".";
  if (slash) {
    if (slash == copy) copy[1] = '\0';
    else *slash = '\0';
    directory = copy;
  }
  int fd = open(directory, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
  if (fd >= 0) {
    if (fsync(fd) != 0)
      fprintf(stderr, "Moonlight configuration saved; directory sync unavailable\n");
    close(fd);
  }
  free(copy);
}

void config_save(char* filename, PCONFIGURATION config) {
  if (!filename || !*filename || !config || config->inputsCount < 0 ||
      config->inputsCount > MAX_INPUTS) {
    fprintf(stderr, "Invalid Moonlight configuration save request\n");
    exit(EXIT_FAILURE);
  }

  const char *codec = NULL;
  switch (config->codec) {
  case CODEC_UNSPECIFIED: codec = "auto"; break;
  case CODEC_H264: codec = "h264"; break;
  case CODEC_HEVC: codec = "h265"; break;
  case CODEC_AV1: codec = "av1"; break;
  default: break;
  }
  const char *remote = config->stream.streamingRemotely == STREAM_CFG_AUTO ? "auto" :
      config->stream.streamingRemotely == STREAM_CFG_REMOTE ? "true" :
      config->stream.streamingRemotely == STREAM_CFG_LOCAL ? "false" : NULL;
  const char *surround = config->stream.audioConfiguration == AUDIO_CONFIGURATION_STEREO ? "stereo" :
      config->stream.audioConfiguration == AUDIO_CONFIGURATION_51_SURROUND ? "5.1" :
      config->stream.audioConfiguration == AUDIO_CONFIGURATION_71_SURROUND ? "7.1" : NULL;

  struct { const char *name; const char *value; } text_fields[] = {
    { "address", config->address }, { "app", config->app },
    { "platform", config->platform }, { "mapping", config->mapping },
    { "audio", config->audio_device }, { "keydir", config->key_dir },
    { "osdargs", config->osdargs },
    { "codec", codec }, { "remote", remote }, { "surround", surround }
  };
  if (!codec || !remote || !surround || config->debug_level < 0 ||
      config->debug_level > 2) {
    fprintf(stderr, "Moonlight cannot serialize an invalid runtime option\n");
    exit(EXIT_FAILURE);
  }
  for (size_t i = 0; i < sizeof(text_fields) / sizeof(text_fields[0]); ++i)
    if (text_fields[i].value && *text_fields[i].value &&
        !config_save_value_safe(text_fields[i].value)) {
      fprintf(stderr, "Moonlight cannot save an invalid text setting\n");
      exit(EXIT_FAILURE);
    }
  for (int i = 0; i < config->inputsCount; ++i)
    if (!config_save_value_safe(config->inputs[i])) {
      fprintf(stderr, "Moonlight cannot save an invalid input device path\n");
      exit(EXIT_FAILURE);
    }

  struct stat existing;
  const int target_status = lstat(filename, &existing);
  if ((target_status == 0 && !S_ISREG(existing.st_mode)) ||
      (target_status != 0 && errno != ENOENT)) {
    fprintf(stderr, "Moonlight refuses an unsafe or inaccessible save target\n");
    exit(EXIT_FAILURE);
  }
  char *temporary = malloc(strlen(filename) + sizeof(".tmp.XXXXXX"));
  if (!temporary) {
    fprintf(stderr, "Out of memory saving Moonlight configuration\n");
    exit(EXIT_FAILURE);
  }
  sprintf(temporary, "%s.tmp.XXXXXX", filename);
  int output_fd = mkstemp(temporary);
  if (output_fd < 0) {
    perror("Moonlight cannot stage configuration");
    free(temporary);
    exit(EXIT_FAILURE);
  }
  FILE *out = fdopen(output_fd, "w");
  if (!out) {
    close(output_fd);
    unlink(temporary);
    free(temporary);
    exit(EXIT_FAILURE);
  }

  bool good = fchmod(fileno(out), 0600) == 0;
  if (good) {
    fprintf(out, "[Moonlight]\n");
    for (size_t i = 0; i < sizeof(text_fields) / sizeof(text_fields[0]); ++i)
      if (text_fields[i].value && *text_fields[i].value)
        write_config_string(out, text_fields[i].name, text_fields[i].value);
    write_config_int(out, "width", config->stream.width);
    write_config_int(out, "height", config->stream.height);
    write_config_int(out, "fps", config->stream.fps);
    write_config_int(out, "bitrate", config->stream.bitrate);
    write_config_int(out, "packetsize", config->stream.packetSize);
    write_config_int(out, "port", config->port);
    if (config->app_id >= 0)
      write_config_int(out, "appid", config->app_id);
    write_config_int(out, "rotate", config->rotate);
    write_config_bool(out, "sops", config->sops);
    write_config_bool(out, "localaudio", config->localaudio);
    write_config_bool(out, "quitappafter", config->quitappafter);
    write_config_bool(out, "viewonly", config->viewonly);
    write_config_bool(out, "windowed", !config->fullscreen);
    write_config_bool(out, "nounsupported", !config->unsupported);
    write_config_bool(out, "nomouseemulation", !config->mouse_emulation);
    write_config_bool(out, "verbose", config->debug_level == 1);
    write_config_bool(out, "debug", config->debug_level == 2);
    write_config_bool(out, "hdr", config->hdr);
    write_config_bool(out, "cec", config->cec);
    write_config_bool(out, "osd", config->osd);
    for (int i = 0; i < config->inputsCount; ++i)
      write_config_string(out, "input", config->inputs[i]);
    good = !ferror(out) && fflush(out) == 0 && fsync(fileno(out)) == 0;
  }
  if (fclose(out) != 0) good = false;

  /* The generated file must round-trip through the real native parser
   * BEFORE the original is replaced, including duplicate-input handling.
   * Keep the live configuration and input selection untouched by validation. */
  if (good) {
    CONFIGURATION checked = *config;
    checked.inputsCount = 0;
    const bool original_input_added = inputAdded;
    good = config_file_parse(temporary, &checked);
    inputAdded = original_input_added;
  }
  if (good && rename(temporary, filename) == 0) {
    config_save_sync_parent(filename);
    free(temporary);
    return;
  }
  unlink(temporary);
  free(temporary);
  fprintf(stderr, "Moonlight configuration save failed; existing file preserved\n");
  exit(EXIT_FAILURE);
}

void config_parse(int argc, char* argv[], PCONFIGURATION config) {
  LiInitializeStreamConfiguration(&config->stream);

  config->stream.width = 1280;
  config->stream.height = 720;
  config->stream.fps = 60;
  config->stream.bitrate = -1;
  config->stream.packetSize = 1392;
  config->stream.streamingRemotely = STREAM_CFG_AUTO;
  config->stream.audioConfiguration = AUDIO_CONFIGURATION_STEREO;
  config->stream.supportedVideoFormats = SCM_H264;

  // Opt in for video encryption if the CPU has good AES performance
  if (has_fast_aes()) {
    config->stream.encryptionFlags = ENCFLG_ALL;
  }
  else if (has_slow_aes()) {
    // For extremely slow CPUs, opt out of audio encryption
    config->stream.encryptionFlags = ENCFLG_NONE;
    printf("Disabling encryption on low performance CPU\n");
  }
  else {
    config->stream.encryptionFlags = ENCFLG_AUDIO;
  }

  config->debug_level = 0;
  config->platform = "auto";
  config->app = "Steam";
  config->app_id = -1;
  config->action = NULL;
  config->address = NULL;
  config->command_line_address_set = false;
  config->config_file = NULL;
  config->audio_device = NULL;
  config->sops = true;
  config->localaudio = false;
  config->fullscreen = true;
  config->unsupported = true;
  config->quitappafter = false;
  config->viewonly = false;
  config->mouse_emulation = true;
  config->rotate = 0;
  config->codec = CODEC_UNSPECIFIED;
  config->hdr = false;
  config->cec = false;
  config->osd = false;
  config->osdargs = NULL;
  config->pin = 0;
  config->port = 47989;

  config->inputsCount = 0;
  config->mapping = get_path("gamecontrollerdb.txt", getenv("XDG_DATA_DIRS"));
  config->key_dir[0] = 0;

  /* Luna passes an exact per-session -config file after preflighting that
   * same snapshot. Do not load shared moonlight.conf first: options omitted
   * from the snapshot would otherwise leak through, and repeated input=
   * values could register the same device more than once. */
  const char *session_config = getenv("LUNA_STREAM_CONFIG");
  bool use_session_only = false;
  if (session_config && *session_config) {
    for (int i = 1; i + 1 < argc; ++i) {
      if ((strcmp(argv[i], "-config") == 0 ||
           strcmp(argv[i], "--config") == 0) &&
          strcmp(argv[i + 1], session_config) == 0) {
        use_session_only = true;
        break;
      }
    }
  }
  /* Explicit no-argument diagnostics never stream, pair, or save files.
   * Other commands and requests with options still validate the default. */
  const bool diagnostic_only = argc == 2 &&
      (!strcmp(argv[1], "help") || !strcmp(argv[1], "check-aml") ||
       !strcmp(argv[1], "check-vfm"));
  if (!use_session_only && !diagnostic_only) {
    char *config_file = get_existing_config_path("moonlight.conf", "/etc");
    if (config_file) {
      const bool accepted = config_file_parse(config_file, config);
      free(config_file);
      if (!accepted) {
        fprintf(stderr, "Default Moonlight configuration rejected; refusing to connect\n");
        exit(EXIT_FAILURE);
      }
    }
  }

  if (argc == 2 && access(argv[1], F_OK) == 0) {
    config->action = "stream";
    if (!config_file_parse(argv[1], config))
      exit(EXIT_FAILURE);

  } else {
    int option_index = 0;
    int c;
    while ((c = getopt_long_only(argc, argv, "-abc:d:efg:h:i:I:j:k:lm:no:p:q:r:s:tu:v:w:xy45:6:789:C:", long_options, &option_index)) != -1) {
      parse_argument(c, optarg, config);
    }
  }

  if (config->key_dir[0] == 0x0) {
    struct passwd *pw = getpwuid(getuid());
    const char *dir;
    if ((dir = getenv("XDG_CACHE_DIR")) != NULL && dir[0] == '/')
      snprintf(config->key_dir, sizeof(config->key_dir), "%s" MOONLIGHT_PATH, dir);
    else if ((dir = getenv("HOME")) != NULL)
      snprintf(config->key_dir, sizeof(config->key_dir), "%s" DEFAULT_CACHE_DIR MOONLIGHT_PATH, dir);
    else if (pw && pw->pw_dir && *pw->pw_dir)
      snprintf(config->key_dir, sizeof(config->key_dir), "%s" DEFAULT_CACHE_DIR MOONLIGHT_PATH, pw->pw_dir);
    else {
      fprintf(stderr, "Cannot determine credential directory without HOME or passwd entry\n");
      exit(EXIT_FAILURE);
    }
  }

  if (!moonlight_stream_numbers_valid(config->stream.width,
                                      config->stream.height,
                                      config->stream.fps,
                                      config->stream.packetSize,
                                      config->stream.bitrate)) {
    fprintf(stderr, "Invalid stream dimensions, FPS, packet size, or bitrate\n");
    exit(EXIT_FAILURE);
  }

  const uint64_t pixels = moonlight_stream_pixel_count(
      config->stream.width, config->stream.height);
  if (config->stream.bitrate == -1) {
    // This table prefers 16:10 resolutions because they are
    // only slightly more pixels than the 16:9 equivalents, so
    // we don't want to bump those 16:10 resolutions up to the
    // next 16:9 slot.

    if (pixels <= 640 * 360) {
      config->stream.bitrate = (int)(1000 * (config->stream.fps / 30.0));
    } else if (pixels <= 854 * 480) {
      config->stream.bitrate = (int)(1500 * (config->stream.fps / 30.0));
    } else if (pixels <= 1366 * 768) {
      // This covers 1280x720 and 1280x800 too
      config->stream.bitrate = (int)(5000 * (config->stream.fps / 30.0));
    } else if (pixels <= 1920 * 1200) {
      config->stream.bitrate = (int)(10000 * (config->stream.fps / 30.0));
    } else if (pixels <= 2560 * 1600) {
      config->stream.bitrate = (int)(20000 * (config->stream.fps / 30.0));
    } else { /* All larger validated resolutions, up to 8K. */
      config->stream.bitrate = (int)(40000 * (config->stream.fps / 30.0));
    }
  }

  /* Persist the validated effective options, including the resolved key
   * directory and auto-derived bitrate, rather than an incomplete preflight. */
  if (config->config_file != NULL)
    config_save(config->config_file, config);
}
