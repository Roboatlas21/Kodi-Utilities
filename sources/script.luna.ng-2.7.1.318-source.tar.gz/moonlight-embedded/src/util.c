/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "util.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int write_bool(char *path, bool val) {
  int fd = open(path, O_RDWR);

  if (fd < 0)
    return -1;
  ssize_t count = write(fd, val ? "1" : "0", 1);
  int saved_errno = errno;
  int close_status = close(fd);
  if (count != 1 || close_status != 0) {
    fprintf(stderr, "Failed to write %d to %s (written=%zd, errno=%d, close=%d)\n",
            val ? 1 : 0, path, count, saved_errno, close_status);
    return -1;
  }
  return 0;
}

int read_file(char *path, char* output, int output_len) {
  int fd = open(path, O_RDONLY);

  if(fd >= 0) {
    output_len = read(fd, output, output_len);
    close(fd);
    return output_len;
  } else
    return -1;
}

bool ensure_buf_size_checked(void **buf, size_t *buf_size, size_t required_size) {
  if (!buf || !buf_size) { errno = EINVAL; return false; }
  if (*buf_size >= required_size) return true;
  void *replacement = realloc(*buf, required_size);
  if (!replacement) { errno = ENOMEM; return false; }
  *buf = replacement;
  *buf_size = required_size;
  return true;
}

bool ensure_buf_size(void **buf, size_t *buf_size, size_t required_size) {
  if (*buf_size >= required_size)
    return false;

  *buf_size = required_size;
  *buf = realloc(*buf, *buf_size);
  if (!*buf) {
    fprintf(stderr, "Failed to allocate %zu bytes\n", *buf_size);
    abort();
  }

  return true;
}
