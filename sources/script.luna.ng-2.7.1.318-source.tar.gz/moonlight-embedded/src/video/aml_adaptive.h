/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_AML_ADAPTIVE_H
#define MOONLIGHT_AML_ADAPTIVE_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

/* Pure, deterministic policy for the existing AMLVIDEO display pump.
 * This is a maximum queue-occupancy limit, NOT a playout deadline or an
 * additional allocation. State is owned entirely by the display thread. */
typedef struct {
  uint64_t window_start_ms, last_tick_ms, last_change_ms, last_pressure_ms;
  uint32_t eligible, late, bursts, empty;
  unsigned int limit, raises, lowers;
} AmlAdaptivePacing;

static inline void aml_adaptive_init(AmlAdaptivePacing *s, uint64_t now_ms) {
  if (!s) return;
  memset(s, 0, sizeof(*s));
  s->limit = 1;
  s->window_start_ms = s->last_tick_ms = now_ms;
  s->last_pressure_ms = now_ms;
}

/* Compare consecutive frame-enqueue deltas (after packet assembly) against
 * source PTS deltas. Both clocks are examined only as same-clock differences.
 * Enqueue occurs before decoder work, so blocked codec_write does not
 * become transport jitter. Invalid or changing source sequences do not grow. */
static inline bool aml_adaptive_input_late(uint32_t arrival_gap_us,
                                           uint64_t source_gap_us,
                                           uint32_t frame_step) {
  if (frame_step != 1 || source_gap_us < 4000 || source_gap_us > 50000 ||
      arrival_gap_us > 200000) return false;
  uint32_t slack = (uint32_t)(source_gap_us / 4);
  if (slack < 4000) slack = 4000;
  if (slack > 8000) slack = 8000;
  return (uint64_t)arrival_gap_us > source_gap_us + slack;
}
static inline bool aml_adaptive_input_eligible(uint64_t source_gap_us,
                                               uint32_t frame_step,
                                               uint32_t arrival_gap_us) {
  return frame_step == 1 && source_gap_us >= 4000 &&
         source_gap_us <= 50000 && arrival_gap_us <= 200000;
}

/* Evaluate at most once every 2 seconds. A single late frame, a natural
 * source-FPS change or a temporarily empty queue cannot increase buffering.
 * Require correlated jitter AND display-side pressure. Recover downward only
 * after ten seconds without qualifying pressure. No change on paused streams
 * with fewer than 20 eligible observations per window. */
static inline unsigned int aml_adaptive_update(AmlAdaptivePacing *s,
    uint64_t now_ms, uint32_t newly_eligible, uint32_t newly_late,
    bool burst, bool empty_with_input) {
  if (!s) return 1;
  if (now_ms < s->last_tick_ms || now_ms - s->last_tick_ms > 5000) {
    aml_adaptive_init(s, now_ms);
    return s->limit;
  }
  s->last_tick_ms = now_ms;
  /* Saturation prevents pathological counter jumps from affecting policy. */
  s->eligible += newly_eligible > 1000 ? 1000 : newly_eligible;
  if (s->eligible > 2000) s->eligible = 2000;
  s->late += newly_late > 1000 ? 1000 : newly_late;
  if (s->late > 2000) s->late = 2000;
  s->bursts += (unsigned)burst;
  s->empty += (unsigned)empty_with_input;
  if (now_ms - s->window_start_ms < 2000) return s->limit;

  const bool qualified = s->eligible >= 20;
  const bool pressure = qualified && s->late >= 3 &&
                        s->late * 10 >= s->eligible &&
                        (s->bursts >= 1 || s->empty >= 2);
  if (pressure) {
    s->last_pressure_ms = now_ms;
    if (s->limit < 3 && (s->last_change_ms == 0 ||
                          now_ms - s->last_change_ms >= 3000)) {
      ++s->limit;
      ++s->raises;
      s->last_change_ms = now_ms;
    }
  } else if (qualified && s->late <= 1 && !s->bursts && !s->empty &&
             s->limit > 1 && now_ms >= s->last_pressure_ms &&
             now_ms - s->last_pressure_ms >= 10000 &&
             now_ms - s->last_change_ms >= 5000) {
    --s->limit;
    ++s->lowers;
    s->last_change_ms = now_ms;
  }
  s->window_start_ms = now_ms;
  s->eligible = s->late = s->bursts = s->empty = 0;
  return s->limit;
}
#endif
