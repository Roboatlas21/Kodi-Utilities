/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_VFM_PROGRESS_H
#define MOONLIGHT_VFM_PROGRESS_H
#include <stdbool.h>
#include <stdint.h>

/* Active compressed input without a non-dropped provider completion is a
 * sink/decoder stall. An accepted bridge submit is not proof of display
 * progress. Short packet gaps, including slow 3-second bursts, must not reset
 * the stall timer. An extended idle/paused host receives a fresh first-frame
 * grace period. Access is serialized by the VFM mutex. */
#define VFM_PROGRESS_STALL_US 10000000ULL
#define VFM_PROGRESS_ACTIVE_US 2000000ULL
#define VFM_PROGRESS_IDLE_RESET_US 5000000ULL

typedef struct {
  uint64_t waiting_since_us;
  uint64_t last_input_us;
} VfmProgress;

static inline void vfm_progress_input(VfmProgress *p, uint64_t now) {
  if (!p || !now) return;
  if (!p->waiting_since_us || now < p->last_input_us ||
      now - p->last_input_us >= VFM_PROGRESS_IDLE_RESET_US)
    p->waiting_since_us = now;
  p->last_input_us = now;
}

static inline void vfm_progress_frame(VfmProgress *p) {
  if (p) p->waiting_since_us = 0;
}

static inline bool vfm_progress_stalled(const VfmProgress *p, uint64_t now) {
  return p && p->waiting_since_us && p->last_input_us &&
      now >= p->waiting_since_us && now >= p->last_input_us &&
      now - p->waiting_since_us >= VFM_PROGRESS_STALL_US &&
      now - p->last_input_us <= VFM_PROGRESS_ACTIVE_US;
}
#endif
