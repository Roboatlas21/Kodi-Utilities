/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 * Copyright (C) 2016 OtherCrashOverride, Daniel Mehrwald
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include <Limelight.h>

#include <sys/utsname.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <codec.h>
#include <errno.h>
#include <pthread.h>
#include <poll.h>

#include <linux/videodev2.h>

#include "../util.h"
#include "video.h"
#include "aml_profile.h"
#include "aml_tuning.h"
#include "aml_low_latency.h"
#include "latency_priority.h"
#include "aml_pacing.h"
#include "aml_adaptive.h"
#include "aml_pacing_debug.h"
#include "aml_pacing_fault.h"
#include "aml_write_progress.h"
#include "first_video_ready.h"
#include "aml_write_watchdog.h"
#include "aml_decode_unit_validate.h"
#include "../osd/stats.h"

#define SYNC_OUTSIDE 0x02
#define UCODE_IP_ONLY_PARAM 0x08
#define MAX_WRITE_ATTEMPTS 5
#define EAGAIN_SLEEP_TIME 2 * 1000

/* Match Skupi's pre-write decoder back-pressure shape: start throttling
 * before the Amlogic input buffer is effectively full, poll in coarse
 * intervals, and never block the Moonlight submit thread indefinitely. */
#define AML_VBUF_HIGH_WATER_PERCENT 95U
#define AML_VBUF_POLL_INTERVAL_US (5U * 1000U)
#define AML_VBUF_WAIT_TIMEOUT_US (30U * 1000U)
#define AML_VBUF_MAX_POLLS (AML_VBUF_WAIT_TIMEOUT_US / AML_VBUF_POLL_INTERVAL_US)
#define AML_VDEC_ERROR_IDR_COOLDOWN_MS 1000U
#define AML_SUBMIT_STALL_TIMEOUT_US (10ULL * 1000ULL * 1000ULL)

#define AML_PACING_QUEUE_CAPACITY 16U
#define AML_PACING_POLL_TIMEOUT_MS 50

/* Same control values used by Skupi and CoreELEC Kodi's AML decoder. */
#define AML_TRICKMODE_NONE 0U
#define AML_AV_SYNC_THRESH (90000U * 30U)
#define AML_VIDEO_DELAY_LIMIT_MS 1000

/*
 * Vortex's CoreELEC NO binary exposes MOONLIGHT_HEVC_RFI=0 to disable
 * reference-frame invalidation when a decoder cannot reliably handle it.
 * Leave upstream behaviour unchanged unless the caller explicitly opts out.
 */
extern DECODER_RENDERER_CALLBACKS decoder_callbacks_aml;

static void __attribute__((constructor)) aml_configure_hevc_rfi(void) {
  const char *rfi = getenv("MOONLIGHT_HEVC_RFI");
  if (rfi != NULL && strcmp(rfi, "0") == 0) {
    decoder_callbacks_aml.capabilities &=
        ~CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC;
    fprintf(stderr, "HEVC reference-frame invalidation disabled (MOONLIGHT_HEVC_RFI=0)\n");
  }
}

static codec_para_t codecParam = { 0 };
static pthread_t displayThread;
static bool display_thread_started = false;
static bool codec_initialized = false;
static int videoFd = -1;
static bool done = false;
static AmlProfile stream_profile;
static AmlTuning stream_tuning;
static AmlLowLatency stream_low_latency;
static bool balanced_pacing;
static unsigned int pacing_max_waiting;
static bool adaptive_pacing;
static uint32_t adaptive_target_waiting;
static uint32_t adaptive_input_eligible_count, adaptive_input_late_count;
static uint64_t adaptive_last_enqueue_us;
static uint32_t adaptive_last_frame_number;
static uint64_t adaptive_last_pts_us;
static bool adaptive_seen_input;

/* Optional read-only OSD ABI, independent of the AmlFrameStats struct size. */
unsigned int aml_adaptive_waiting(void) {
  return adaptive_pacing ? __atomic_load_n(&adaptive_target_waiting, __ATOMIC_ACQUIRE) : 0;
}

static void (*aml_failure_callback)(void);
static uint64_t submit_stall_since_us;
static bool submit_stalling;
static bool submit_failed;
static bool first_video_ready_sent;
/* Independent worker monitors streaming decoder operations in flight.
 * On a persistent stuck ioctl/write it asks Moonlight to stop normally, then
 * escalates after bounded grace if the decoder thread never unwinds. */
static pthread_t codec_write_guard;
static bool codec_write_guard_started;
static bool codec_write_guard_stop;
static bool codec_write_inflight;
static uint32_t codec_write_entered_ms;
/* AMLVIDEO display-pump ioctls run on a different worker from codec_write.
 * Never let codec operations clear the display watchdog's active lifetime.
 * Reuse the existing monitor thread: no additional CE21 pthread allocation. */
enum aml_display_guard_operation {
  AML_DISPLAY_GUARD_DQBUF = 1,
  AML_DISPLAY_GUARD_QBUF = 2
};
static bool display_ioctl_inflight;
static uint32_t display_ioctl_entered_ms;
static unsigned int display_ioctl_generation;
static int display_ioctl_operation;

static void *aml_codec_write_guard(void *unused) {
  (void)unused;
  bool stop_requested = false;
  bool display_stop_requested = false;
  unsigned int seen_display_generation = 0;
  for (;;) {
    if (__atomic_load_n(&codec_write_guard_stop, __ATOMIC_ACQUIRE))
      return NULL;
    bool busy = __atomic_load_n(&codec_write_inflight, __ATOMIC_ACQUIRE);
    if (!busy) {
      stop_requested = false;
    } else {
      const uint32_t entered = __atomic_load_n(&codec_write_entered_ms, __ATOMIC_RELAXED);
      const int action = aml_blocked_write_action((uint32_t)LiGetMillis(), entered);
      if (action >= AML_WRITE_GUARD_REQUEST_STOP && !stop_requested) {
        fprintf(stderr, "AML: decoder operation blocked for 12s; requesting stream shutdown\n");
        stop_requested = true;
        if (aml_failure_callback) aml_failure_callback();
      }
      if (action == AML_WRITE_GUARD_FORCE_EXIT && stop_requested &&
          __atomic_load_n(&codec_write_inflight, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&codec_write_entered_ms, __ATOMIC_RELAXED) == entered) {
        /* A callback stuck in a vendor driver cannot be joined safely.
         * Process exit closes decoder handles; Luna's independent watchdog
         * restores Kodi. Never force-unload kernel modules here. */
        fprintf(stderr, "AML: decoder operation still blocked after shutdown grace; exiting for Luna recovery\n");
        _exit(124);
      }
    }
    /* Separate display-pump lifetime: a queued frame may be returned to
     * amlvideo via a blocking VIDIOC_QBUF, or DQBUF may wedge inside the
     * Amlogic driver. Track this regardless of normal codec-write activity. */
    if (!__atomic_load_n(&display_ioctl_inflight, __ATOMIC_ACQUIRE)) {
      display_stop_requested = false;
    } else {
      const unsigned int generation =
          __atomic_load_n(&display_ioctl_generation, __ATOMIC_RELAXED);
      const uint32_t entered =
          __atomic_load_n(&display_ioctl_entered_ms, __ATOMIC_RELAXED);
      if (generation != seen_display_generation) {
        seen_display_generation = generation;
        display_stop_requested = false;
      }
      const int operation =
          __atomic_load_n(&display_ioctl_operation, __ATOMIC_RELAXED);
      const int action = aml_blocked_write_action((uint32_t)LiGetMillis(), entered);
      if (action >= AML_WRITE_GUARD_REQUEST_STOP &&
          !display_stop_requested &&
          __atomic_load_n(&display_ioctl_inflight, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&display_ioctl_generation, __ATOMIC_RELAXED) ==
              generation) {
        display_stop_requested = true;
        fprintf(stderr, "AML: display-pump %s blocked for 12s; requesting shutdown\n",
                operation == AML_DISPLAY_GUARD_QBUF ? "VIDIOC_QBUF" : "VIDIOC_DQBUF");
        /* Nonblocking stream cancellation only. Do not join the display
         * worker or acquire a hardware mutex from this guard thread. */
        if (aml_failure_callback) aml_failure_callback();
      }
      if (action == AML_WRITE_GUARD_FORCE_EXIT &&
          display_stop_requested &&
          __atomic_load_n(&display_ioctl_inflight, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&display_ioctl_generation, __ATOMIC_RELAXED) ==
              seen_display_generation) {
        fprintf(stderr, "AML: display-pump ioctl still blocked; exiting for Luna recovery\n");
        _exit(124);
      }
    }
    usleep(250000);
  }
}

static void aml_display_operation_enter(enum aml_display_guard_operation operation) {
  __atomic_store_n(&display_ioctl_operation, operation, __ATOMIC_RELAXED);
  __atomic_store_n(&display_ioctl_entered_ms, (uint32_t)LiGetMillis(),
                   __ATOMIC_RELAXED);
  __atomic_add_fetch(&display_ioctl_generation, 1U, __ATOMIC_RELAXED);
  __atomic_store_n(&display_ioctl_inflight, true, __ATOMIC_RELEASE);
}
static void aml_display_operation_leave(void) {
  __atomic_store_n(&display_ioctl_inflight, false, __ATOMIC_RELEASE);
}

static void aml_operation_enter(void) {
  __atomic_store_n(&codec_write_entered_ms, (uint32_t)LiGetMillis(), __ATOMIC_RELAXED);
  __atomic_store_n(&codec_write_inflight, true, __ATOMIC_RELEASE);
}
static void aml_operation_leave(void) {
  __atomic_store_n(&codec_write_inflight, false, __ATOMIC_RELEASE);
}
static void aml_stop_codec_write_guard(void) {
  if (!codec_write_guard_started) return;
  __atomic_store_n(&codec_write_guard_stop, true, __ATOMIC_RELEASE);
  pthread_join(codec_write_guard, NULL);
  codec_write_guard_started = false;
  __atomic_store_n(&codec_write_inflight, false, __ATOMIC_RELEASE);
}


void aml_set_failure_callback(void (*callback)(void)) {
  aml_failure_callback = callback;
}

static void aml_abort_balanced_pacing(const char *stage, int error) {
  fprintf(stderr, "AML: balanced frame pump failed in %s (%d); stopping stream\n", stage, error);
  if (aml_failure_callback) aml_failure_callback();
}

/* A connected stream can remain alive while a full decoder rejects every
 * frame. Bound that failure so the normal native exit returns control to
 * Luna's recovery. A complete accepted unit breaks the failure streak;
 * partial writes and IDR requests alone are not decoder progress. */
static void aml_record_submit_progress(bool submitted) {
  if (submit_failed)
    return;
  if (submitted) {
    submit_stalling = false;
    return;
  }
  const uint64_t now = LiGetMicroseconds();
  if (!submit_stalling) {
    submit_stall_since_us = now;
    submit_stalling = true;
  } else if (now >= submit_stall_since_us &&
             now - submit_stall_since_us >= AML_SUBMIT_STALL_TIMEOUT_US) {
    submit_failed = true;
    fprintf(stderr, "AML: decoder accepted no complete video unit for 10 seconds; stopping stream for Kodi recovery\n");
    if (aml_failure_callback) aml_failure_callback();
  }
}

static uint32_t pacing_units_written;
static uint32_t pacing_frames_returned;
static uint32_t pacing_frames_dropped;

/* Cheap opt-in 32-bit atomics; no lock or per-frame print in the video path.
 * These are submission/V4L2-dequeue events, not guaranteed hardware presents. */
static AmlFrameStats osd_stats;
static bool osd_stats_enabled;
static AmlPaceDebug pacing_debug;
static uint64_t last_pace_dequeue_us;
static uint32_t last_dequeue_ms;
static uint32_t last_vdec_error_count;
static uint64_t last_vdec_error_idr_ms;

static bool aml_vbuf_needs_wait(const struct buf_status *vbuf, size_t incoming) {
  if (!vbuf || vbuf->size <= 0 || vbuf->data_len < 0 || vbuf->free_len < 0)
    return false;

  const uint64_t size = (uint64_t)(unsigned int)vbuf->size;
  const uint64_t data = (uint64_t)(unsigned int)vbuf->data_len;
  const uint64_t free_bytes = (uint64_t)(unsigned int)vbuf->free_len;
  const uint64_t high_water = size * AML_VBUF_HIGH_WATER_PERCENT / 100U;

  return data + (uint64_t)incoming > high_water ||
         free_bytes < (uint64_t)incoming;
}

/* Fail open if this older libamcodec cannot report buffer state reliably.
 * codec_write()/EAGAIN remains the compatibility fallback in that case. */
static bool aml_wait_for_vbuf_room(size_t incoming, unsigned int *polls) {
  if (polls) *polls = 0;

  for (unsigned int i = 0;; i++) {
    struct buf_status vbuf = { 0 };
    aml_operation_enter();
    int state_result = codec_get_vbuf_state(&codecParam, &vbuf);
    aml_operation_leave();
    if (state_result != 0)
      return true;

    if (!aml_vbuf_needs_wait(&vbuf, incoming))
      return true;

    if (i >= AML_VBUF_MAX_POLLS)
      return false;

    if (polls) (*polls)++;
    usleep(AML_VBUF_POLL_INTERVAL_US);
  }
}

/* Match Skupi's post-submit decoder recovery. libamcodec exposes an
 * accumulated decoder error_count; a newly increased count means the
 * current reference chain may no longer be trustworthy. Request an IDR
 * through DR_NEED_IDR, but no more than once per second. */
static bool aml_vdec_error_needs_idr(void) {
  struct vdec_status vdec = { 0 };
  aml_operation_enter();
  int state_result = codec_get_vdec_state(&codecParam, &vdec);
  aml_operation_leave();
  if (state_result != 0)
    return false;

  if (vdec.error_count < last_vdec_error_count) {
    /* Decoder reset/counter restart: establish a new baseline. */
    last_vdec_error_count = vdec.error_count;
    return false;
  }

  if (vdec.error_count == last_vdec_error_count)
    return false;

  last_vdec_error_count = vdec.error_count;

  const uint64_t now_ms = LiGetMillis();
  if (last_vdec_error_idr_ms != 0 &&
      now_ms - last_vdec_error_idr_ms < AML_VDEC_ERROR_IDR_COOLDOWN_MS)
    return false;

  last_vdec_error_idr_ms = now_ms;
  fprintf(stderr, "AML: decoder error count %u, asking for a keyframe\n",
          vdec.error_count);
  return true;
}

/* Monitor starts after decoder setup and joins before cleanup. The duplicate
 * remains owned by the monitor, which closes it before stream teardown. */
int aml_osd_decoder_fd(void) {
  struct utsname kernel;
  if (!codec_initialized || codecParam.handle < 0 || uname(&kernel) ||
      strncmp(kernel.release, "4.9.269", 7) ||
      (kernel.release[7] && kernel.release[7] != '-')) return -1;
  return fcntl(codecParam.handle, F_DUPFD_CLOEXEC, 0);
}

/* A versioned, read-only diagnostics ABI. The OSD samples it off the video threads. */
bool aml_pacing_debug_snapshot(AmlPaceSnapshot *out) {
  return aml_pace_snapshot(&pacing_debug, out);
}

void aml_osd_snapshot(AmlFrameStats *out) {
  if (!out) return;
  out->submitted = __atomic_load_n(&osd_stats.submitted, __ATOMIC_RELAXED);
  out->dequeued = __atomic_load_n(&osd_stats.dequeued, __ATOMIC_RELAXED);
  out->uses_v4l2 = __atomic_load_n(&osd_stats.uses_v4l2, __ATOMIC_RELAXED);
  out->submit_failures = __atomic_load_n(&osd_stats.submit_failures, __ATOMIC_RELAXED);
  out->codec_eagain = __atomic_load_n(&osd_stats.codec_eagain, __ATOMIC_RELAXED);
  out->backpressure_waits = __atomic_load_n(&osd_stats.backpressure_waits, __ATOMIC_RELAXED);
  out->backpressure_wait_us = __atomic_load_n(&osd_stats.backpressure_wait_us, __ATOMIC_RELAXED);
  out->backpressure_drops = __atomic_load_n(&osd_stats.backpressure_drops, __ATOMIC_RELAXED);
  out->idr_frames = __atomic_load_n(&osd_stats.idr_frames, __ATOMIC_RELAXED);
  out->codec_submit_us = __atomic_load_n(&osd_stats.codec_submit_us, __ATOMIC_RELAXED);
  out->codec_submit_samples = __atomic_load_n(&osd_stats.codec_submit_samples, __ATOMIC_RELAXED);
  out->dequeue_gaps_25ms = __atomic_load_n(&osd_stats.dequeue_gaps_25ms, __ATOMIC_RELAXED);
  out->dequeue_gaps_33ms = __atomic_load_n(&osd_stats.dequeue_gaps_33ms, __ATOMIC_RELAXED);
  out->host_samples = __atomic_load_n(&osd_stats.host_samples, __ATOMIC_RELAXED);
  out->host_tenths_ms = __atomic_load_n(&osd_stats.host_tenths_ms, __ATOMIC_RELAXED);
  out->assembly_samples = __atomic_load_n(&osd_stats.assembly_samples, __ATOMIC_RELAXED);
  out->assembly_us = __atomic_load_n(&osd_stats.assembly_us, __ATOMIC_RELAXED);
  out->stream_width = __atomic_load_n(&osd_stats.stream_width, __ATOMIC_RELAXED);
  out->stream_height = __atomic_load_n(&osd_stats.stream_height, __ATOMIC_RELAXED);
  out->codec_family = __atomic_load_n(&osd_stats.codec_family, __ATOMIC_RELAXED);
  out->qbuf_failures = __atomic_load_n(&osd_stats.qbuf_failures, __ATOMIC_RELAXED);
#define COPY_DIAG(field) out->field = __atomic_load_n(&osd_stats.field, __ATOMIC_RELAXED)
  COPY_DIAG(input_frames);
  COPY_DIAG(last_input_ms);
  COPY_DIAG(input_gaps_50ms);
  COPY_DIAG(input_gaps_100ms);
  COPY_DIAG(submit_slow_20ms);
  COPY_DIAG(submit_slow_50ms);
  COPY_DIAG(queue_wait_us);
  COPY_DIAG(queue_wait_samples);
  COPY_DIAG(queue_wait_20ms);
#undef COPY_DIAG
}

void *pkt_buf = NULL;
size_t pkt_buf_size = 0;

static void aml_record_dequeue(void) {
  aml_profile_display_poll(&stream_profile, true);
  if (!osd_stats_enabled && !pacing_debug.enabled) return;
  const uint64_t now_us = aml_profile_now_us();
  if (pacing_debug.enabled && now_us) {
    if (last_pace_dequeue_us && now_us > last_pace_dequeue_us &&
        now_us - last_pace_dequeue_us <= 1000000U) {
      const uint32_t gap = (uint32_t)(now_us - last_pace_dequeue_us);
      aml_pace_record(&pacing_debug.decode_output_gap, gap);
      const uint32_t expected = pacing_debug.fps ?
          1000000U / pacing_debug.fps : 0;
      if (expected && gap > (uint64_t)expected * 2U)
        aml_pace_event(&pacing_debug.display_events, now_us, pacing_debug.start_us,
                       AML_PACE_OUTPUT_GAP, gap, expected);
    }
    last_pace_dequeue_us = now_us;
  }
  if (!osd_stats_enabled) return;
  __atomic_fetch_add(&osd_stats.dequeued, 1, __ATOMIC_RELAXED);
  const uint32_t ms = (uint32_t)(now_us / 1000);
  if (last_dequeue_ms) {
    const uint32_t gap = ms - last_dequeue_ms;
    if (gap > 25)
      __atomic_fetch_add(&osd_stats.dequeue_gaps_25ms, 1, __ATOMIC_RELAXED);
    if (gap > 33)
      __atomic_fetch_add(&osd_stats.dequeue_gaps_33ms, 1, __ATOMIC_RELAXED);
  }
  last_dequeue_ms = ms;
}

static int aml_qbuf_index(uint32_t index, bool drop) {
  struct v4l2_buffer vbuf = { 0 };
  vbuf.index = index;
  vbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
  if (drop)
    vbuf.flags = V4L2_BUF_FLAG_DONE;

  aml_display_operation_enter(AML_DISPLAY_GUARD_QBUF);
  const int status = ioctl(videoFd, VIDIOC_QBUF, &vbuf);
  const int error = status < 0 ? errno : 0;
  aml_display_operation_leave();
  if (status == 0)
    return 0;

  const uint32_t failures = __atomic_add_fetch(&osd_stats.qbuf_failures, 1, __ATOMIC_RELAXED);
  if (failures == 1 || failures % 60 == 0) {
    fprintf(stderr, "AML: VIDIOC_QBUF%s failed (%u times): %s\n",
            drop ? " (drop)" : "", failures, strerror(error));
  }
  errno = error; /* Callers use errno to identify terminal device failures. */
  return -1;
}

/* Amlogic amlvideo pump (Low Latency / Balanced):
 * - collect decoded buffers into a bounded local ring;
 * - keep at most 1 or 3 pending, returning older buffers with DONE set;
 * - poll the Amlogic control fd and return one normal buffer per refresh.
 *
 * Failed buffer returns retain ownership/index until retried. The separate
 * direct-tunnel Lowest Latency mode never starts this thread. */
void* aml_display_thread(void* unused) {
  /* The optional Balanced pump is a separate native video worker. */
  moonlight_latency_priority_current("AMLDisplay", -2);
  unsigned int max_waiting = pacing_max_waiting;
  AmlAdaptivePacing adaptive;
  uint32_t observed_eligible = 0, observed_late = 0;
  if (adaptive_pacing) aml_adaptive_init(&adaptive, aml_profile_now_us() / 1000u);
  uint32_t queue[AML_PACING_QUEUE_CAPACITY] = { 0 };
  unsigned int head = 0;
  unsigned int count = 0;
  unsigned int dq_errors = 0, poll_errors = 0, qbuf_errors = 0;
  uint64_t empty_ready_at_us = 0; /* Observation only, no extra DQBUF. */

  printf("AML: pump gives back one frame per refresh, at most %u waiting\n",
         max_waiting);

  while (!__atomic_load_n(&done, __ATOMIC_ACQUIRE)) {
    unsigned int batch = 0;
    while (count < AML_PACING_QUEUE_CAPACITY) {
      struct v4l2_buffer vbuf = { 0 };
      vbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

      aml_display_operation_enter(AML_DISPLAY_GUARD_DQBUF);
      const int dequeue_rc = ioctl(videoFd, VIDIOC_DQBUF, &vbuf);
      const int dequeue_errno = dequeue_rc < 0 ? errno : 0;
      aml_display_operation_leave();
      if (dequeue_rc < 0) {
        const int error = dequeue_errno;
        if (aml_pacing_fatal_dequeue(error, &dq_errors)) {
          aml_abort_balanced_pacing("VIDIOC_DQBUF", error);
          goto finish;
        }
        if (error == EAGAIN) {
          aml_profile_display_poll(&stream_profile, false);
        } else if (error == EINTR) {
          continue;
        } else {
          fprintf(stderr, "AML: VIDIOC_DQBUF failed (%u/3): %s\n",
                  dq_errors, strerror(error));
        }
        break;
      }

      dq_errors = 0;
      queue[(head + count) % AML_PACING_QUEUE_CAPACITY] = vbuf.index;
      count++;
      ++batch;
      aml_record_dequeue();
      if (pacing_debug.enabled && empty_ready_at_us) {
        const uint64_t observed_us = aml_profile_now_us();
        if (observed_us >= empty_ready_at_us &&
            observed_us - empty_ready_at_us <= 3000U) {
          aml_pace_inc(&pacing_debug.near_wake_dequeues);
          aml_pace_event(&pacing_debug.display_events, observed_us,
                         pacing_debug.start_us, AML_PACE_NEAR_WAKE,
                         (uint32_t)(observed_us - empty_ready_at_us), count);
        }
        empty_ready_at_us = 0;
      }
    }

    if (adaptive_pacing) {
      const uint32_t eligible = __atomic_load_n(&adaptive_input_eligible_count, __ATOMIC_RELAXED);
      const uint32_t late = __atomic_load_n(&adaptive_input_late_count, __ATOMIC_RELAXED);
      const uint32_t new_eligible = eligible - observed_eligible;
      const uint32_t new_late = late - observed_late;
      observed_eligible = eligible;
      observed_late = late;
      const unsigned int previous = max_waiting;
      const bool empty = count == 0 && new_eligible > 0;
      const uint32_t evidence_total = adaptive.eligible + new_eligible;
      const uint32_t evidence_late = adaptive.late + new_late;
      const uint32_t evidence_bursts = adaptive.bursts + (unsigned)(batch >= 2);
      const uint32_t evidence_empty = adaptive.empty + (unsigned)empty;
      max_waiting = aml_adaptive_update(&adaptive, aml_profile_now_us() / 1000u,
                                        new_eligible, new_late, batch >= 2, empty);
      if (max_waiting != previous) {
        __atomic_store_n(&adaptive_target_waiting, max_waiting, __ATOMIC_RELEASE);
        fprintf(stderr, "AML_ADAPTIVE_V1 limit=%u/3 raises=%u lowers=%u\n",
                max_waiting, adaptive.raises, adaptive.lowers);
        if (pacing_debug.enabled) {
          __atomic_store_n(&pacing_debug.adaptive_cap, max_waiting, __ATOMIC_RELAXED);
          if (max_waiting > previous) aml_pace_inc(&pacing_debug.adaptive_raises);
          else aml_pace_inc(&pacing_debug.adaptive_lowers);
          const uint64_t now_us = aml_profile_now_us();
          aml_pace_event(&pacing_debug.display_events, now_us, pacing_debug.start_us,
                         AML_PACE_ADAPT_CHANGE, max_waiting, previous);
          fprintf(stderr, "PACING_ADAPT_V1 old=%u new=%u pairs=%u late=%u bursts=%u empty=%u\n",
                  previous, max_waiting, evidence_total, evidence_late,
                  evidence_bursts, evidence_empty);
        }
      }
    }

    while (count > max_waiting) {
      const int qbuf_result = aml_qbuf_index(queue[head], true);
      if (!aml_pacing_complete_qbuf(qbuf_result, AML_PACING_QUEUE_CAPACITY,
                                    &head, &count)) {
        if (++qbuf_errors >= 3) {
          aml_abort_balanced_pacing("VIDIOC_QBUF(drop)", errno);
          goto finish;
        }
        break;
      }
      qbuf_errors = 0;
      __atomic_fetch_add(&pacing_frames_dropped, 1, __ATOMIC_RELAXED);
      if (pacing_debug.enabled) aml_pace_inc(&pacing_debug.frames_dropped);
    }

    struct pollfd pfd = {
      .fd = codecParam.cntl_handle,
      .events = POLLOUT,
      .revents = 0
    };
    if (pacing_debug.enabled) aml_pace_queue(&pacing_debug, count);
    const uint64_t poll_begin_us = pacing_debug.enabled ? aml_profile_now_us() : 0;
    const int poll_result = poll(&pfd, 1, AML_PACING_POLL_TIMEOUT_MS);
    const int poll_error = poll_result < 0 ? errno : 0;
    if (pacing_debug.enabled) {
      const uint64_t poll_end_us = aml_profile_now_us();
      if (poll_begin_us && poll_end_us >= poll_begin_us &&
          poll_end_us - poll_begin_us <= UINT32_MAX) {
        const uint32_t duration_us = (uint32_t)(poll_end_us - poll_begin_us);
        aml_pace_record(&pacing_debug.poll_wait, duration_us);
        if (duration_us > 35000U)
          aml_pace_event(&pacing_debug.display_events, poll_end_us,
                         pacing_debug.start_us, AML_PACE_LONG_POLL,
                         duration_us, (uint32_t)(poll_result == 0));
      }
      if (poll_result == 0) aml_pace_inc(&pacing_debug.poll_timeouts);
      if (poll_result > 0 && (pfd.revents & POLLOUT) && count == 0) {
        aml_pace_inc(&pacing_debug.empty_ready_wakes);
        empty_ready_at_us = poll_end_us;
      } else {
        empty_ready_at_us = 0;
      }
    }
    if (aml_pacing_fatal_poll(poll_result, pfd.revents, poll_error, &poll_errors)) {
      aml_abort_balanced_pacing("poll", poll_result < 0 ? poll_error : EIO);
      goto finish;
    }
    if (poll_result > 0 && (pfd.revents & POLLOUT) && count > 0) {
      const int qbuf_result = aml_qbuf_index(queue[head], false);
      if (aml_pacing_complete_qbuf(qbuf_result, AML_PACING_QUEUE_CAPACITY,
                                   &head, &count)) {
        qbuf_errors = 0;
        __atomic_fetch_add(&pacing_frames_returned, 1, __ATOMIC_RELAXED);
        if (pacing_debug.enabled) aml_pace_inc(&pacing_debug.frames_returned);
      } else if (++qbuf_errors >= 3) {
        aml_abort_balanced_pacing("VIDIOC_QBUF", errno);
        goto finish;
      }
    }
  }

finish:
  while (count > 0) {
    const int qbuf_result = aml_qbuf_index(queue[head], false);
    if (!aml_pacing_complete_qbuf(qbuf_result, AML_PACING_QUEUE_CAPACITY,
                                  &head, &count))
      break;
  }

  printf("Display thread terminated\n");
  return NULL;
}

int aml_setup(int videoFormat, int width, int height, int redrawRate, void* context, int drFlags) {
  if (drFlags & DISPLAY_ROTATE_MASK) {
    fprintf(stderr, "AML does not support display rotation; set rotate=0\n");
    return -1;
  }
  // Diagnostics are off unless explicitly enabled. No per-frame logging.
  const char *pacing = getenv("MOONLIGHT_FRAME_PACING");
  pacing_max_waiting = aml_pacing_wait_limit(pacing);
  adaptive_pacing = aml_pacing_is_adaptive(pacing);
  balanced_pacing = pacing_max_waiting > 0;
  __atomic_store_n(&adaptive_target_waiting, adaptive_pacing ? 1U : 0U, __ATOMIC_RELEASE);
  __atomic_store_n(&adaptive_input_eligible_count, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&adaptive_input_late_count, 0, __ATOMIC_RELAXED);
  adaptive_last_enqueue_us = 0;
  adaptive_last_frame_number = 0;
  adaptive_last_pts_us = 0;
  adaptive_seen_input = false;
  if (pacing && strcmp(pacing, "latency") != 0 &&
      strcmp(pacing, "low-latency") != 0 &&
      strcmp(pacing, "balanced") != 0 &&
      strcmp(pacing, "adaptive") != 0)
    fprintf(stderr, "AML: unknown frame pacing '%s'; using latency\n", pacing);
  aml_profile_init(&stream_profile, getenv("MOONLIGHT_AML_PROFILE"));
  osd_stats_enabled = getenv("MOONLIGHT_AML_OSD") &&
                      strcmp(getenv("MOONLIGHT_AML_OSD"), "1") == 0;
  memset(&pacing_debug, 0, sizeof(pacing_debug));
  const char *diag = getenv("MOONLIGHT_STREAM_DIAGNOSTICS");
  pacing_debug.enabled = diag && strcmp(diag, "1") == 0;
  pacing_debug.mode = adaptive_pacing ? 2U :
                      pacing_max_waiting == 1 ? 1U :
                      pacing_max_waiting == 3 ? 3U : 0U;
  pacing_debug.fps = redrawRate > 0 ? (uint32_t)redrawRate : 0U;
  pacing_debug.start_us = pacing_debug.enabled ? aml_profile_now_us() : 0;
  pacing_debug.adaptive_cap = pacing_max_waiting;
  last_pace_dequeue_us = 0;
  memset(&osd_stats, 0, sizeof(osd_stats));
  if (osd_stats_enabled) {
    __atomic_store_n(&osd_stats.stream_width, (uint32_t)width, __ATOMIC_RELAXED);
    __atomic_store_n(&osd_stats.stream_height, (uint32_t)height, __ATOMIC_RELAXED);
    const uint32_t family = (videoFormat & VIDEO_FORMAT_MASK_H264) ? 1 :
                            (videoFormat & VIDEO_FORMAT_MASK_H265) ? 2 : 0;
    __atomic_store_n(&osd_stats.codec_family, family, __ATOMIC_RELAXED);
  }
  last_dequeue_ms = 0;
  last_vdec_error_count = 0;
  last_vdec_error_idr_ms = 0;
  __atomic_store_n(&pacing_units_written, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&pacing_frames_returned, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&pacing_frames_dropped, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&done, false, __ATOMIC_RELEASE);
  display_thread_started = false;
  codec_initialized = false;
  submit_stalling = false;
  submit_failed = false;
  first_video_ready_sent = false;
  codec_write_guard_started = false;
  __atomic_store_n(&codec_write_guard_stop, false, __ATOMIC_RELEASE);
  __atomic_store_n(&codec_write_inflight, false, __ATOMIC_RELEASE);
  __atomic_store_n(&display_ioctl_inflight, false, __ATOMIC_RELEASE);
  __atomic_store_n(&display_ioctl_generation, 0U, __ATOMIC_RELAXED);
  __atomic_store_n(&display_ioctl_entered_ms, 0U, __ATOMIC_RELAXED);
  __atomic_store_n(&display_ioctl_operation, 0, __ATOMIC_RELAXED);
  /* The monitor must exist BEFORE codec_init and vendor control calls.
   * Luna's independent watchdog remains the fallback if a thread cannot
   * be allocated on a constrained CoreELEC installation. */
  if (pthread_create(&codec_write_guard, NULL, aml_codec_write_guard, NULL) != 0) {
    fprintf(stderr, "AML: unable to guard decoder initialization\n");
    return -2;
  }
  codec_write_guard_started = true;

  if (balanced_pacing) {
    aml_operation_enter();
    videoFd = open("/dev/video10", O_RDONLY | O_NONBLOCK);
    aml_operation_leave();
    if (videoFd < 0) {
      fprintf(stderr, "AML: can't open /dev/video10: %s\n", strerror(errno));
      aml_stop_codec_write_guard();
      return -3;
    }
  } else {
    videoFd = -1;
  }

  codecParam.handle             = -1;
  codecParam.cntl_handle        = -1;
  codecParam.audio_utils_handle = -1;
  codecParam.sub_handle         = -1;
  codecParam.has_video          = 1;
  codecParam.noblock            = 0;
  codecParam.stream_type        = STREAM_TYPE_ES_VIDEO;
  codecParam.am_sysinfo.param   = 0;

  /* STREAM_TYPE_FRAME is an enum, not a preprocessor macro. Selecting frame
   * mode is required for the per-decoder video_path below to take effect. */
  codecParam.dec_mode           = STREAM_TYPE_FRAME;

  /* Skupi uses the tunnel path for lowest latency and Kodi's amlvideo
   * path for balanced pacing. These enum values are part of the NG
   * libamcodec/kernel ABI. */
  codecParam.video_path = balanced_pacing ?
      FRAME_BASE_PATH_AMLVIDEO_AMVIDEO : FRAME_BASE_PATH_TUNNEL_MODE;

  if (videoFormat & VIDEO_FORMAT_MASK_H264) {
    if (width > 1920 || height > 1080) {
      codecParam.video_type = VFORMAT_H264_4K2K;
      codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_H264_4K2K;
    } else {
      codecParam.video_type = VFORMAT_H264;
      codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_H264;

      // Workaround for decoding special case of C1, 1080p, H264
      int major, minor;
      struct utsname name;
      uname(&name);
      int ret = sscanf(name.release, "%d.%d", &major, &minor);
      if (ret == 2 && !(major > 3 || (major == 3 && minor >= 14)) && width == 1920 && height == 1080)
          codecParam.am_sysinfo.param = (void*) UCODE_IP_ONLY_PARAM;
    }
  } else if (videoFormat & VIDEO_FORMAT_MASK_H265) {
    codecParam.video_type = VFORMAT_HEVC;
    codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_HEVC;
    if (videoFormat & VIDEO_FORMAT_MASK_10BIT)
      fprintf(stderr, "AML: HEVC Main10 negotiated; HDR10 output follows stream metadata and CoreELEC display policy\n");
#ifdef CODEC_TAG_AV1
  } else if (videoFormat & VIDEO_FORMAT_MASK_AV1) {
    codecParam.video_type = VFORMAT_AV1;
    codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_AV1;
#endif
  } else {
    printf("Video format not supported\n");
    if (videoFd >= 0) {
      close(videoFd);
      videoFd = -1;
    }
    aml_stop_codec_write_guard();
    return -1;
  }

  codecParam.am_sysinfo.width = width;
  codecParam.am_sysinfo.height = height;
  codecParam.am_sysinfo.rate = 96000 / redrawRate;
  codecParam.am_sysinfo.param = (void*) ((size_t) codecParam.am_sysinfo.param | SYNC_OUTSIDE);

  /* These helpers perform vendor sysfs reads/writes before codec_init.
   * Do not leave them unmonitored merely because the guard thread exists. */
  aml_operation_enter();
  aml_low_latency_init(&stream_low_latency, NULL);
  (void)aml_low_latency_enable(&stream_low_latency);

  aml_tuning_init(&stream_tuning, NULL);
  aml_tuning_configure(&stream_tuning,
      (videoFormat & VIDEO_FORMAT_MASK_H265) != 0,
      getenv("MOONLIGHT_AML_TUNING_PROBE"));
  aml_operation_leave();

  int ret;
  aml_operation_enter();
  ret = codec_init(&codecParam);
  aml_operation_leave();
  if (ret != 0) {
    fprintf(stderr, "codec_init error: %x\n", ret);
    aml_operation_enter();
    if (videoFd >= 0) {
      close(videoFd);
      videoFd = -1;
    }
    aml_tuning_restore(&stream_tuning);
    aml_low_latency_restore(&stream_low_latency);
    aml_operation_leave();
    aml_stop_codec_write_guard();
    return -2;
  }

  codec_initialized = true;

  printf("AML: frame pacing %s (max waiting %u)\n",
         adaptive_pacing ? "adaptive (1..3)" :
         pacing_max_waiting == 1 ? "low-latency" :
         balanced_pacing ? "balanced" : "latency",
         pacing_max_waiting);

  /* Match Skupi/CoreELEC's AML control initialization. Global tsync is owned
   * by Luna's CoreELEC session wrapper, not this native decoder. These calls
   * establish normal playback mode,
   * bound the driver's video-delay accounting, and use the same AV/sync
   * thresholds as Kodi before freerun presentation is enabled below. */
  /* Keep sequential vendor controls under one deadline. Any failure path
   * enters guarded teardown rather than leaving a live monitor behind. */
  aml_operation_enter();
  if ((ret = codec_pause(&codecParam)) != 0)
    fprintf(stderr, "AML: codec_pause failed: %d\n", ret);
  if ((ret = codec_set_cntl_mode(&codecParam, AML_TRICKMODE_NONE)) != 0)
    fprintf(stderr, "AML: codec_set_cntl_mode failed: %d\n", ret);
  if ((ret = codec_set_video_delay_limited_ms(&codecParam,
                                         AML_VIDEO_DELAY_LIMIT_MS)) != 0)
    fprintf(stderr, "AML: codec_set_video_delay_limited_ms failed: %d\n", ret);
  if ((ret = codec_set_cntl_avthresh(&codecParam, AML_AV_SYNC_THRESH)) != 0)
    fprintf(stderr, "AML: codec_set_cntl_avthresh failed: %d\n", ret);
  if ((ret = codec_set_cntl_syncthresh(&codecParam, 0)) != 0)
    fprintf(stderr, "AML: codec_set_cntl_syncthresh failed: %d\n", ret);

  if ((ret = codec_set_freerun_mode(&codecParam, 1)) != 0) {
    fprintf(stderr, "Can't set Freerun mode: %x\n", ret);
    goto codec_setup_failed;
  }
  /* TRICKMODE_NONE and freerun do not undo codec_pause(). */
  if ((ret = codec_resume(&codecParam)) != 0) {
    fprintf(stderr, "AML: codec_resume failed: %d\n", ret);
    goto codec_setup_failed;
  }

  aml_operation_leave();

  if (balanced_pacing) {
    if (codecParam.cntl_handle < 0) {
      fprintf(stderr, "AML: balanced pacing requires a video control handle\n");
      goto codec_setup_failed;
    }

    if (pthread_create(&displayThread, NULL, aml_display_thread, NULL) == 0) {
      display_thread_started = true;
      __atomic_store_n(&osd_stats.uses_v4l2, 1, __ATOMIC_RELAXED);
    } else {
      fprintf(stderr, "AML: can't start the amlvideo pump\n");
      goto codec_setup_failed;
    }
  }

  if (!ensure_buf_size_checked(&pkt_buf, &pkt_buf_size,
                               INITIAL_DECODER_BUFFER_SIZE)) {
    fprintf(stderr, "AML: decoder packet buffer allocation failed\n");
    goto codec_setup_failed;
  }
  return 0;

codec_setup_failed:
  /* The guard remains alive across the display worker join, codec close,
   * and device recovery. A stuck vendor call exits for Luna recovery. */
  aml_operation_enter();
  if (display_thread_started) {
    __atomic_store_n(&done, true, __ATOMIC_RELEASE);
    pthread_join(displayThread, NULL);
    display_thread_started = false;
  }
  codec_close(&codecParam);
  codec_initialized = false;
  free(pkt_buf);
  pkt_buf = NULL;
  pkt_buf_size = 0;
  if (videoFd >= 0) {
    close(videoFd);
    videoFd = -1;
  }
  aml_tuning_restore(&stream_tuning);
  aml_low_latency_restore(&stream_low_latency);
  aml_operation_leave();
  aml_stop_codec_write_guard();
  return -2;
}

void aml_cleanup() {
  /* Do not disarm the watchdog before waiting on the display worker or
   * closing a vendor codec; these operations can block in kernel code. */
  if (codec_write_guard_started) aml_operation_enter();
  if (videoFd >= 0) {
    __atomic_store_n(&done, true, __ATOMIC_RELEASE);
    if (display_thread_started) {
      pthread_join(displayThread, NULL);
      display_thread_started = false;
    }
    close(videoFd);
    videoFd = -1;
  }

  if (codec_initialized) {
    codec_close(&codecParam);
    codec_initialized = false;
  }
  aml_tuning_restore(&stream_tuning);
  aml_low_latency_restore(&stream_low_latency);
  if (codec_write_guard_started) {
    aml_operation_leave();
    aml_stop_codec_write_guard();
  }
  aml_profile_report(&stream_profile, stderr);
  aml_pace_report(&pacing_debug, stderr);
  if (balanced_pacing) {
    fprintf(stderr,
            "AML: %u units written, %u frames given back one per refresh, "
            "%u dropped by the pump, %u QBUF failures\n",
            __atomic_load_n(&pacing_units_written, __ATOMIC_RELAXED),
            __atomic_load_n(&pacing_frames_returned, __ATOMIC_RELAXED),
            __atomic_load_n(&pacing_frames_dropped, __ATOMIC_RELAXED),
            __atomic_load_n(&osd_stats.qbuf_failures, __ATOMIC_RELAXED));
  }
  free(pkt_buf);
  pkt_buf = NULL;
  pkt_buf_size = 0;
}

int aml_submit_decode_unit(PDECODE_UNIT decodeUnit) {
  if (submit_failed)
    return DR_NEED_IDR;
  /* Validate before diagnostics, timestamps or any other dereference. */
  if (!aml_decode_unit_valid(decodeUnit)) {
    /* Malformed input is also zero decoder progress. Keep the IDR request,
     * but do not permit a persistent corrupt-frame storm to evade the same
     * 10-second watchdog used for stalled codec writes/backpressure. */
    if (!submit_stalling)
      fprintf(stderr, "AML: invalid decode-unit fragment chain, requesting IDR\n");
    aml_record_submit_progress(false);
    return DR_NEED_IDR;
  }
  const uint64_t submit_start_us =
      (stream_profile.enabled || osd_stats_enabled) ? aml_profile_now_us() : 0;
  /* Both timestamps below originate in common-c; compare only their
   * deltas. Do NOT subtract them from CLOCK_MONOTONIC callback timestamps.
   * Enqueue is after video reassembly and before any decoder backpressure. */
  if (adaptive_pacing || pacing_debug.enabled) {
    const uint64_t enqueue = decodeUnit->enqueueTimeUs;
    const uint32_t frame = (uint32_t)decodeUnit->frameNumber;
    const uint64_t pts = decodeUnit->presentationTimeUs;
    if (adaptive_seen_input && enqueue && enqueue > adaptive_last_enqueue_us &&
        pts > adaptive_last_pts_us) {
      const uint64_t gap = enqueue - adaptive_last_enqueue_us;
      const uint64_t source_gap = pts - adaptive_last_pts_us;
      const uint32_t step = frame - adaptive_last_frame_number;
      const bool eligible = gap <= UINT32_MAX &&
          aml_adaptive_input_eligible(source_gap, step, (uint32_t)gap);
      if (eligible && adaptive_pacing) {
        __atomic_fetch_add(&adaptive_input_eligible_count, 1, __ATOMIC_RELAXED);
        if (aml_adaptive_input_late((uint32_t)gap, source_gap, step))
          __atomic_fetch_add(&adaptive_input_late_count, 1, __ATOMIC_RELAXED);
      }
      if (pacing_debug.enabled) {
        if (eligible) {
          const uint32_t error_us = (uint32_t)(gap > source_gap ?
                                                gap - source_gap : source_gap - gap);
          aml_pace_record(&pacing_debug.arrival_error, error_us);
          const uint64_t slack = source_gap / 4U < 4000U ? 4000U :
                                 source_gap / 4U > 8000U ? 8000U : source_gap / 4U;
          if (gap > source_gap + slack) {
            aml_pace_inc(&pacing_debug.arrival_late);
            if (error_us > 8000U)
              aml_pace_event(&pacing_debug.input_events, submit_start_us,
                             pacing_debug.start_us, AML_PACE_LATE_ARRIVAL,
                             error_us, (uint32_t)source_gap);
          } else if (source_gap > gap + slack) {
            aml_pace_inc(&pacing_debug.arrival_early);
          }
        } else {
          aml_pace_inc(&pacing_debug.arrival_invalid);
        }
      }
    } else if (adaptive_seen_input && pacing_debug.enabled) {
      aml_pace_inc(&pacing_debug.arrival_invalid);
    }
    adaptive_last_enqueue_us = enqueue;
    adaptive_last_pts_us = pts;
    adaptive_last_frame_number = frame;
    adaptive_seen_input = true;
  }
  unsigned int write_calls = 0;
  unsigned int eagain_count = 0;
  unsigned int backpressure_polls = 0;
  bool backpressure_dropped = false;

  if (osd_stats_enabled) {
    const uint32_t ms = (uint32_t)(submit_start_us / 1000);
    const uint32_t prior = __atomic_load_n(&osd_stats.last_input_ms, __ATOMIC_RELAXED);
    if (__atomic_load_n(&osd_stats.input_frames, __ATOMIC_RELAXED)) {
      const uint32_t gap = ms - prior;
      if (gap > 50) __atomic_fetch_add(&osd_stats.input_gaps_50ms, 1, __ATOMIC_RELAXED);
      if (gap > 100) __atomic_fetch_add(&osd_stats.input_gaps_100ms, 1, __ATOMIC_RELAXED);
    }
    __atomic_store_n(&osd_stats.last_input_ms, ms, __ATOMIC_RELAXED);
    __atomic_fetch_add(&osd_stats.input_frames, 1, __ATOMIC_RELAXED);
    /* common-c owns the enqueue epoch; do not subtract our own clock from it. */
    const uint64_t now = LiGetMicroseconds();
    if (decodeUnit->enqueueTimeUs && now >= decodeUnit->enqueueTimeUs &&
        now - decodeUnit->enqueueTimeUs <= 60000000) {
      const uint32_t wait = (uint32_t)(now - decodeUnit->enqueueTimeUs);
      __atomic_fetch_add(&osd_stats.queue_wait_us, wait, __ATOMIC_RELAXED);
      __atomic_fetch_add(&osd_stats.queue_wait_samples, 1, __ATOMIC_RELAXED);
      if (wait > 20000) __atomic_fetch_add(&osd_stats.queue_wait_20ms, 1, __ATOMIC_RELAXED);
    }
  }

  if (!ensure_buf_size_checked(&pkt_buf, &pkt_buf_size,
                               (size_t)decodeUnit->fullLength)) {
    fprintf(stderr, "AML: decoder packet allocation failed; stopping stream\n");
    submit_failed = true;
    if (aml_failure_callback) aml_failure_callback();
    return DR_NEED_IDR;
  }

  int written = 0, length = 0, api;
  unsigned int no_progress = 0;
  PLENTRY entry = decodeUnit->bufferList;
  do {
    memcpy(pkt_buf+length, entry->data, entry->length);
    length += entry->length;
    entry = entry->next;
  } while (entry != NULL);

  if (!aml_wait_for_vbuf_room((size_t)length, &backpressure_polls)) {
    backpressure_dropped = true;
    fprintf(stderr,
            "AML: decoder input still above %u%% after %u ms, unit of %d bytes dropped\n",
            AML_VBUF_HIGH_WATER_PERCENT, AML_VBUF_WAIT_TIMEOUT_US / 1000U, length);
  }

  const uint64_t backpressure_wait_us =
      (uint64_t)backpressure_polls * AML_VBUF_POLL_INTERVAL_US;
  uint64_t write_start_us = 0;

  if (!backpressure_dropped) {
    /* Preserve Moonlight's full microsecond timestamp. CoreELEC Kodi and
     * Skupi both use the uS64 ioctl for ES video rather than truncating to ms. */
    aml_operation_enter();
    const int pts_rc = codec_checkin_pts_us64(&codecParam,
                                              decodeUnit->presentationTimeUs);
    aml_operation_leave();
    if (pacing_debug.enabled) {
      if (pts_rc != 0) {
        const uint32_t streak = __atomic_add_fetch(
            &pacing_debug.pts_consecutive, 1U, __ATOMIC_RELAXED);
        const uint32_t total = __atomic_add_fetch(
            &pacing_debug.pts_checkin_failures, 1U, __ATOMIC_RELAXED);
        uint32_t peak = __atomic_load_n(
            &pacing_debug.pts_consecutive_peak, __ATOMIC_RELAXED);
        while (peak < streak && !__atomic_compare_exchange_n(
            &pacing_debug.pts_consecutive_peak, &peak, streak, true,
            __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
        /* No automatic reset/IDR here: repeated PTS failures need diagnosis
         * on real Amlogic hardware before modifying playback policy. */
        if (streak == 1U || streak == 8U || (streak > 8U && streak % 64U == 0U))
          fprintf(stderr,
                  "AML_PTS_DIAG_V1 result=%d consecutive=%u total=%u\n",
                  pts_rc, streak, total);
      } else {
        __atomic_store_n(&pacing_debug.pts_consecutive, 0U, __ATOMIC_RELAXED);
      }
    }
    write_start_us = stream_profile.enabled ? aml_profile_now_us() : 0;
    while (length > 0) {
      __atomic_store_n(&codec_write_entered_ms, (uint32_t)LiGetMillis(),
                       __ATOMIC_RELAXED);
      __atomic_store_n(&codec_write_inflight, true, __ATOMIC_RELEASE);
      const uint64_t write_begin_us = pacing_debug.enabled ? aml_profile_now_us() : 0;
      api = codec_write(&codecParam, pkt_buf+written, length);
      /* clock_gettime() in debug sampling must never overwrite codec_write errno. */
      const int write_errno = api < 0 ? errno : 0;
      __atomic_store_n(&codec_write_inflight, false, __ATOMIC_RELEASE);
      if (pacing_debug.enabled && write_begin_us) {
        const uint64_t write_end_us = aml_profile_now_us();
        if (write_end_us >= write_begin_us && write_end_us - write_begin_us <= UINT32_MAX) {
          const uint32_t duration_us = (uint32_t)(write_end_us - write_begin_us);
          aml_pace_record(&pacing_debug.codec_write, duration_us);
          if (duration_us > 20000U)
            aml_pace_event(&pacing_debug.input_events, write_end_us,
                           pacing_debug.start_us, AML_PACE_SLOW_WRITE,
                           duration_us, 0);
        }
      }
      if (stream_profile.enabled) write_calls++;
      const AmlWriteProgress status = aml_write_progress(
          api, write_errno, length, &no_progress, MAX_WRITE_ATTEMPTS);
      if (status == AML_WRITE_FATAL) {
        fprintf(stderr, "codec_write() invalid/error result: %d (errno=%d)\n",
                api, write_errno);
        aml_operation_enter();
        codec_reset(&codecParam);
        aml_operation_leave();
        break;
      }
      if (status == AML_WRITE_TIMEOUT) {
        fprintf(stderr, "codec_write() timed out after %u no-progress writes (%s)\n",
                no_progress, api == 0 ? "zero bytes" : "EAGAIN");
        break;
      }
      if (status == AML_WRITE_RETRY) {
        if (api < 0) {
          if (stream_profile.enabled) eagain_count++;
          if (osd_stats_enabled)
            __atomic_fetch_add(&osd_stats.codec_eagain, 1, __ATOMIC_RELAXED);
        }
        usleep(EAGAIN_SLEEP_TIME);
      } else {
        written += api;
        length -= api;
      }
    }
  }

  if (!backpressure_dropped && length == 0) {
    __atomic_fetch_add(&pacing_units_written, 1, __ATOMIC_RELAXED);
    /* AML tunnel mode does not expose a reliable displayed-frame event.
     * A fully accepted compressed video unit is the earliest available
     * independent video progress, distinct from LiStartConnection success. */
    if (!first_video_ready_sent) {
      if (moonlight_first_video_publish(getenv("MOONLIGHT_VIDEO_READY_FILE"))) {
        first_video_ready_sent = true;
      } else {
        fprintf(stderr, "AML: could not publish first-video progress receipt\n");
        submit_failed = true;
        if (aml_failure_callback) aml_failure_callback();
      }
    }
  }

  aml_record_submit_progress(!backpressure_dropped && length == 0);

  const bool decoder_error_needs_idr =
      !backpressure_dropped && length == 0 && aml_vdec_error_needs_idr();

  if (osd_stats_enabled) {
    if (!backpressure_dropped) {
      __atomic_fetch_add(&osd_stats.submitted, 1, __ATOMIC_RELAXED);
      if (decodeUnit->frameType == FRAME_TYPE_IDR)
        __atomic_fetch_add(&osd_stats.idr_frames, 1, __ATOMIC_RELAXED);
    }
    if (backpressure_polls) {
      __atomic_fetch_add(&osd_stats.backpressure_waits, 1, __ATOMIC_RELAXED);
      __atomic_fetch_add(&osd_stats.backpressure_wait_us,
                         (uint32_t)backpressure_wait_us, __ATOMIC_RELAXED);
    }
    if (backpressure_dropped)
      __atomic_fetch_add(&osd_stats.backpressure_drops, 1, __ATOMIC_RELAXED);
    const uint64_t end_us = aml_profile_now_us();
    if (end_us >= submit_start_us) {
      const uint64_t duration = end_us - submit_start_us;
      if (duration > 20000) __atomic_fetch_add(&osd_stats.submit_slow_20ms, 1, __ATOMIC_RELAXED);
      if (duration > 50000) __atomic_fetch_add(&osd_stats.submit_slow_50ms, 1, __ATOMIC_RELAXED);
    }
    if (end_us >= submit_start_us && end_us - submit_start_us <= 1000000) {
      __atomic_fetch_add(&osd_stats.codec_submit_us,
                         (uint32_t)(end_us - submit_start_us), __ATOMIC_RELAXED);
      __atomic_fetch_add(&osd_stats.codec_submit_samples, 1, __ATOMIC_RELAXED);
    }
    if (length && !backpressure_dropped)
      __atomic_fetch_add(&osd_stats.submit_failures, 1, __ATOMIC_RELAXED);
    if (decodeUnit->frameHostProcessingLatency) {
      __atomic_fetch_add(&osd_stats.host_tenths_ms, decodeUnit->frameHostProcessingLatency,
                         __ATOMIC_RELAXED);
      __atomic_fetch_add(&osd_stats.host_samples, 1, __ATOMIC_RELAXED);
    }
    if (decodeUnit->enqueueTimeUs >= decodeUnit->receiveTimeUs) {
      uint64_t dt = decodeUnit->enqueueTimeUs - decodeUnit->receiveTimeUs;
      if (dt <= 1000000) {
        __atomic_fetch_add(&osd_stats.assembly_us, (uint32_t)dt, __ATOMIC_RELAXED);
        __atomic_fetch_add(&osd_stats.assembly_samples, 1, __ATOMIC_RELAXED);
      }
    }
  }
  if (stream_profile.enabled) {
    const uint64_t end_us = aml_profile_now_us();
    AmlProfileSample sample = {
      .bytes = decodeUnit->fullLength,
      // Both timestamps come from moonlight-common-c's own monotonic epoch.
      .assembly_us = decodeUnit->enqueueTimeUs >= decodeUnit->receiveTimeUs ?
          decodeUnit->enqueueTimeUs - decodeUnit->receiveTimeUs : 0,
      .submit_us = end_us >= submit_start_us ? end_us - submit_start_us : 0,
      .write_us = write_start_us && end_us >= write_start_us ?
          end_us - write_start_us : 0,
      .eagain = eagain_count,
      .write_calls = write_calls,
      .backpressure_wait_us = backpressure_wait_us,
      .backpressure_polls = backpressure_polls,
      .failed = length != 0,
      .dropped = backpressure_dropped
    };
    aml_profile_record(&stream_profile, &sample);
  }
  if (pacing_debug.enabled && submit_start_us) {
    const uint64_t end_us = aml_profile_now_us();
    if (end_us >= submit_start_us && end_us - submit_start_us <= UINT32_MAX) {
      const uint32_t duration_us = (uint32_t)(end_us - submit_start_us);
      aml_pace_record(&pacing_debug.submit, duration_us);
      const uint32_t interval = pacing_debug.fps ?
          1000000U / pacing_debug.fps : 0;
      if (interval && duration_us > (uint64_t)interval * 2U)
        aml_pace_event(&pacing_debug.input_events, end_us,
                       pacing_debug.start_us, AML_PACE_SLOW_SUBMIT,
                       duration_us, interval);
    }
  }
  return (submit_failed || length || decoder_error_needs_idr) ? DR_NEED_IDR : DR_OK;
}

DECODER_RENDERER_CALLBACKS decoder_callbacks_aml = {
  .setup = aml_setup,
  .cleanup = aml_cleanup,
  .submitDecodeUnit = aml_submit_decode_unit,

  // We may delay in aml_submit_decode_unit() for a while, so we can't set CAPABILITY_DIRECT_SUBMIT
  .capabilities = CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC,
};
