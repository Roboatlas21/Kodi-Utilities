/* SPDX-License-Identifier: GPL-3.0-or-later
 * Debug-only, bounded AML pacing evidence. Not a display-present clock and
 * never used to make scheduling, buffer-size, or frame-drop decisions.
 */
#ifndef MOONLIGHT_AML_PACING_DEBUG_H
#define MOONLIGHT_AML_PACING_DEBUG_H

#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define AML_PACE_DEBUG_ABI 1U
#define AML_PACE_BINS 10U
#define AML_PACE_EVENTS 64U

/* Inclusive upper bounds; bin 9 is open-ended (>132 ms). */
static const uint32_t aml_pace_limits[AML_PACE_BINS - 1] = {
  500, 1000, 2000, 4000, 8000, 16000, 33000, 66000, 132000
};

typedef struct {
  uint32_t bins[AML_PACE_BINS], count, sum_16us, worst_us;
  uint64_t exact_total_us; /* Single writer; read only after worker shutdown. */
} AmlPaceMetric;
typedef struct {
  uint32_t bins[AML_PACE_BINS], count, sum_16us, worst_us;
} AmlPaceMetricView;
typedef struct {
  uint32_t at_ms, kind, value_us, detail;
} AmlPaceEvent;
typedef struct {
  AmlPaceEvent items[AML_PACE_EVENTS];
  uint32_t written; /* One writer per ring; read only after shutdown. */
} AmlPaceEventRing;
enum {
  AML_PACE_LATE_ARRIVAL = 1, AML_PACE_SLOW_SUBMIT,
  AML_PACE_SLOW_WRITE, AML_PACE_OUTPUT_GAP,
  AML_PACE_LONG_POLL, AML_PACE_NEAR_WAKE, AML_PACE_ADAPT_CHANGE
};
typedef struct {
  bool enabled;
  uint32_t mode, fps; /* 0=direct, 1=low, 2=adaptive, 3=balanced */
  uint64_t start_us;
  AmlPaceMetric arrival_error, submit, codec_write, decode_output_gap, poll_wait;
  uint32_t arrival_late, arrival_early, arrival_invalid;
  uint32_t poll_timeouts, empty_ready_wakes, near_wake_dequeues;
  uint32_t depth_samples, depth_sum, depth_peak;
  uint32_t frames_returned, frames_dropped;
  uint32_t adaptive_cap, adaptive_raises, adaptive_lowers;
  uint32_t pts_checkin_failures, pts_consecutive, pts_consecutive_peak;
  AmlPaceEventRing input_events, display_events;
} AmlPaceDebug;
typedef struct {
  uint32_t abi, mode, fps;
  AmlPaceMetricView arrival_error, submit, codec_write, decode_output_gap, poll_wait;
  uint32_t arrival_late, arrival_early, arrival_invalid;
  uint32_t poll_timeouts, empty_ready_wakes, near_wake_dequeues;
  uint32_t depth_samples, depth_sum, depth_peak;
  uint32_t frames_returned, frames_dropped;
  uint32_t adaptive_cap, adaptive_raises, adaptive_lowers;
  uint32_t pts_checkin_failures, pts_consecutive, pts_consecutive_peak;
} AmlPaceSnapshot;

static inline const char *aml_pace_mode(unsigned mode) {
  switch (mode) {
    case 0: return "lowest-latency";
    case 1: return "low-latency";
    case 2: return "adaptive";
    case 3: return "balanced";
    default: return "unknown";
  }
}
static inline unsigned aml_pace_bin(uint32_t us) {
  unsigned i = 0;
  while (i < AML_PACE_BINS - 1 && us > aml_pace_limits[i]) ++i;
  return i;
}
static inline void aml_pace_record(AmlPaceMetric *m, uint32_t us) {
  /* Each metric has exactly one producer: decoder input or display pump.
   * The monitor reads only u32 atomics, never the native 64-bit exact sum. */
  m->exact_total_us += us;
  __atomic_fetch_add(&m->sum_16us, (uint32_t)(((uint64_t)us + 8U) / 16U), __ATOMIC_RELAXED);
  __atomic_fetch_add(&m->bins[aml_pace_bin(us)], 1U, __ATOMIC_RELAXED);
  __atomic_fetch_add(&m->count, 1U, __ATOMIC_RELAXED);
  uint32_t maximum = __atomic_load_n(&m->worst_us, __ATOMIC_RELAXED);
  while (maximum < us && !__atomic_compare_exchange_n(&m->worst_us,
           &maximum, us, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
}
static inline void aml_pace_inc(uint32_t *counter) {
  __atomic_fetch_add(counter, 1U, __ATOMIC_RELAXED);
}
static inline void aml_pace_event(AmlPaceEventRing *r, uint64_t now_us,
                                    uint64_t start_us, uint32_t kind,
                                    uint32_t value, uint32_t detail) {
  uint32_t at = now_us >= start_us ? (uint32_t)((now_us - start_us) / 1000U) : 0;
  r->items[r->written % AML_PACE_EVENTS] = (AmlPaceEvent){at, kind, value, detail};
  ++r->written;
}
static inline void aml_pace_queue(AmlPaceDebug *d, uint32_t count) {
  __atomic_fetch_add(&d->depth_samples, 1U, __ATOMIC_RELAXED);
  __atomic_fetch_add(&d->depth_sum, count, __ATOMIC_RELAXED);
  uint32_t maximum = __atomic_load_n(&d->depth_peak, __ATOMIC_RELAXED);
  while (maximum < count && !__atomic_compare_exchange_n(&d->depth_peak,
           &maximum, count, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
}
static inline void aml_pace_metric_snapshot(const AmlPaceMetric *m,
                                              AmlPaceMetricView *out) {
  for (unsigned i = 0; i < AML_PACE_BINS; ++i)
    out->bins[i] = __atomic_load_n(&m->bins[i], __ATOMIC_RELAXED);
  out->count = __atomic_load_n(&m->count, __ATOMIC_RELAXED);
  out->sum_16us = __atomic_load_n(&m->sum_16us, __ATOMIC_RELAXED);
  out->worst_us = __atomic_load_n(&m->worst_us, __ATOMIC_RELAXED);
}
#define AML_PACE_LOAD(d, out, field) \
  ((out)->field = __atomic_load_n(&(d)->field, __ATOMIC_RELAXED))
static inline bool aml_pace_snapshot(const AmlPaceDebug *d, AmlPaceSnapshot *out) {
  if (!d || !out || !d->enabled) return false;
  memset(out, 0, sizeof(*out));
  out->abi = AML_PACE_DEBUG_ABI;
  out->mode = d->mode;
  out->fps = d->fps;
  aml_pace_metric_snapshot(&d->arrival_error, &out->arrival_error);
  aml_pace_metric_snapshot(&d->submit, &out->submit);
  aml_pace_metric_snapshot(&d->codec_write, &out->codec_write);
  aml_pace_metric_snapshot(&d->decode_output_gap, &out->decode_output_gap);
  aml_pace_metric_snapshot(&d->poll_wait, &out->poll_wait);
  AML_PACE_LOAD(d, out, arrival_late);
  AML_PACE_LOAD(d, out, arrival_early);
  AML_PACE_LOAD(d, out, arrival_invalid);
  AML_PACE_LOAD(d, out, poll_timeouts);
  AML_PACE_LOAD(d, out, empty_ready_wakes);
  AML_PACE_LOAD(d, out, near_wake_dequeues);
  AML_PACE_LOAD(d, out, depth_samples);
  AML_PACE_LOAD(d, out, depth_sum);
  AML_PACE_LOAD(d, out, depth_peak);
  AML_PACE_LOAD(d, out, frames_returned);
  AML_PACE_LOAD(d, out, frames_dropped);
  AML_PACE_LOAD(d, out, adaptive_cap);
  AML_PACE_LOAD(d, out, adaptive_raises);
  AML_PACE_LOAD(d, out, adaptive_lowers);
  AML_PACE_LOAD(d, out, pts_checkin_failures);
  AML_PACE_LOAD(d, out, pts_consecutive);
  AML_PACE_LOAD(d, out, pts_consecutive_peak);
  return true;
}
#undef AML_PACE_LOAD

/* A histogram delta is an interval; never confuse session P95 with 1s P95. */
static inline AmlPaceMetricView aml_pace_delta(const AmlPaceMetricView *now,
                                                 const AmlPaceMetricView *prior) {
  AmlPaceMetricView out = *now;
  if (prior) {
    out.count -= prior->count;
    out.sum_16us -= prior->sum_16us; /* Valid modulo u32 over one sample. */
    for (unsigned i = 0; i < AML_PACE_BINS; ++i) out.bins[i] -= prior->bins[i];
  }
  return out;
}
static inline uint32_t aml_pace_quantile_bin(const uint32_t *bins,
                                              unsigned percentile) {
  uint64_t total = 0;
  for (unsigned i = 0; i < AML_PACE_BINS; ++i) total += bins[i];
  if (!total) return 0;
  const uint64_t goal = (total * percentile + 99) / 100;
  uint64_t count = 0;
  for (unsigned i = 0; i < AML_PACE_BINS; ++i) {
    count += bins[i];
    if (count >= goal)
      return i == AML_PACE_BINS - 1 ? UINT32_MAX : aml_pace_limits[i];
  }
  return 0;
}
static inline void aml_pace_quantile_text(const uint32_t *bins,
                                            unsigned percentile,
                                            char *out, size_t size) {
  const uint32_t upper = aml_pace_quantile_bin(bins, percentile);
  if (!upper) snprintf(out, size, "n/a");
  else if (upper == UINT32_MAX) snprintf(out, size, ">132000");
  else snprintf(out, size, "%" PRIu32, upper);
}
static inline uint32_t aml_pace_mean_us(const AmlPaceMetricView *m) {
  return m->count ? (uint32_t)(((uint64_t)m->sum_16us * 16U) / m->count) : 0;
}
static inline void aml_pace_format_interval(const AmlPaceSnapshot *now,
                                             const AmlPaceSnapshot *prior,
                                             char *out, size_t size) {
  if (!now || !out || !size) return;
  if (now->abi != AML_PACE_DEBUG_ABI) {
    snprintf(out, size, "PACING_DIAG_V1 abi=mismatch");
    return;
  }
  if (!prior || prior->abi != now->abi || prior->mode != now->mode) {
    snprintf(out, size, "PACING_DIAG_V1 mode=%s baseline=1 pump=%s",
             aml_pace_mode(now->mode), now->mode ? "yes" : "no");
    return;
  }
  const AmlPaceMetricView a = aml_pace_delta(&now->arrival_error, &prior->arrival_error);
  const AmlPaceMetricView s = aml_pace_delta(&now->submit, &prior->submit);
  const AmlPaceMetricView w = aml_pace_delta(&now->codec_write, &prior->codec_write);
  const AmlPaceMetricView d = aml_pace_delta(&now->decode_output_gap, &prior->decode_output_gap);
  const AmlPaceMetricView p = aml_pace_delta(&now->poll_wait, &prior->poll_wait);
  char a95[20], a99[20], s95[20], s99[20], w95[20], w99[20];
  char d95[20], d99[20], p95[20], p99[20];
  aml_pace_quantile_text(a.bins, 95, a95, sizeof(a95));
  aml_pace_quantile_text(a.bins, 99, a99, sizeof(a99));
  aml_pace_quantile_text(s.bins, 95, s95, sizeof(s95));
  aml_pace_quantile_text(s.bins, 99, s99, sizeof(s99));
  aml_pace_quantile_text(w.bins, 95, w95, sizeof(w95));
  aml_pace_quantile_text(w.bins, 99, w99, sizeof(w99));
  aml_pace_quantile_text(d.bins, 95, d95, sizeof(d95));
  aml_pace_quantile_text(d.bins, 99, d99, sizeof(d99));
  aml_pace_quantile_text(p.bins, 95, p95, sizeof(p95));
  aml_pace_quantile_text(p.bins, 99, p99, sizeof(p99));
  const uint32_t qn = now->depth_samples - prior->depth_samples;
  const uint32_t qs = now->depth_sum - prior->depth_sum;
  /* Evidence labels describe the stage, not a definitive root-cause claim. */
  const uint32_t late = now->arrival_late - prior->arrival_late;
  const uint32_t slow = s.count && aml_pace_mean_us(&s) > 20000U;
  const uint32_t near = now->near_wake_dequeues - prior->near_wake_dequeues;
  const char *hint = (late >= 3 && (slow || near)) ? "mixed" :
                     late >= 3 ? "arrival" : slow ? "submission" :
                     near ? "post-wake" : "none";
  snprintf(out, size,
      "PACING_DIAG_V1 mode=%s fps=%u arrival_pairs=+%u late=+%u early=+%u invalid=+%u "
      "arrival_abs_mean_us=%u arrival_p95_bucket_us=%s arrival_p99_bucket_us=%s "
      "submit_n=+%u submit_mean_us=%u submit_p95_bucket_us=%s submit_p99_bucket_us=%s "
      "write_n=+%u write_mean_us=%u write_p95_bucket_us=%s write_p99_bucket_us=%s "
      "decode_gap_n=+%u decode_gap_mean_us=%u decode_gap_p95_bucket_us=%s decode_gap_p99_bucket_us=%s "
      "poll_n=+%u poll_mean_us=%u poll_p95_bucket_us=%s poll_p99_bucket_us=%s "
      "timeouts=+%u empty_wakes=+%u near_wake=+%u "
      "depth_iter_mean=%.2f depth_peak=%u returned=+%u dropped=+%u "
      "cap=%u raises=+%u lowers=+%u pts_failures=+%u pts_consecutive=%u pts_peak=%u evidence=%s",
      aml_pace_mode(now->mode), now->fps, a.count, late,
      now->arrival_early - prior->arrival_early,
      now->arrival_invalid - prior->arrival_invalid,
      aml_pace_mean_us(&a), a95, a99,
      s.count, aml_pace_mean_us(&s), s95, s99,
      w.count, aml_pace_mean_us(&w), w95, w99,
      d.count, aml_pace_mean_us(&d), d95, d99,
      p.count, aml_pace_mean_us(&p), p95, p99,
      now->poll_timeouts - prior->poll_timeouts,
      now->empty_ready_wakes - prior->empty_ready_wakes, near,
      qn ? (double)qs / qn : 0.0, now->depth_peak,
      now->frames_returned - prior->frames_returned,
      now->frames_dropped - prior->frames_dropped,
      now->adaptive_cap,
      now->adaptive_raises - prior->adaptive_raises,
      now->adaptive_lowers - prior->adaptive_lowers,
      now->pts_checkin_failures - prior->pts_checkin_failures,
      now->pts_consecutive, now->pts_consecutive_peak, hint);
}
static inline void aml_pace_report_metric(FILE *f, const char *name,
                                            const AmlPaceMetric *m) {
  char p95[20], p99[20];
  uint32_t bins[AML_PACE_BINS];
  for (unsigned i=0;i<AML_PACE_BINS;++i) bins[i] = m->bins[i];
  aml_pace_quantile_text(bins, 95, p95, sizeof(p95));
  aml_pace_quantile_text(bins, 99, p99, sizeof(p99));
  fprintf(f, "PACING_TIMING_V1 stage=%s samples=%u mean_us=%" PRIu64
             " p95_bucket_us=%s p99_bucket_us=%s worst_us=%u\n",
          name, m->count, m->count ? m->exact_total_us / m->count : 0,
          p95, p99, m->worst_us);
}
static inline void aml_pace_report_ring(FILE *f, const char *stage,
                                          const AmlPaceEventRing *r) {
  const uint32_t total = r->written;
  const uint32_t retained = total < AML_PACE_EVENTS ? total : AML_PACE_EVENTS;
  /* Last 12 abnormal events per producer; no per-frame disk I/O. */
  const uint32_t printed = retained < 12U ? retained : 12U;
  for (uint32_t i = 0; i < printed; ++i) {
    const uint32_t slot = (total - printed + i) % AML_PACE_EVENTS;
    const AmlPaceEvent *e = &r->items[slot];
    fprintf(f, "PACING_EVENT_V1 thread=%s t_ms=%u kind=%u value_us=%u detail=%u\n",
            stage, e->at_ms, e->kind, e->value_us, e->detail);
  }
}
static inline void aml_pace_report(const AmlPaceDebug *d, FILE *f) {
  if (!d || !d->enabled || !f) return;
  fprintf(f, "PACING_SUMMARY_V1 mode=%s fps=%u pairs=%u late=%u early=%u "
             "invalid=%u empty_wakes=%u near_wake=%u timeouts=%u "
             "depth_peak=%u returned=%u dropped=%u cap=%u raises=%u lowers=%u "
             "pts_failures=%u pts_peak=%u "
             "note=driver-handoffs-not-physical-presents\n",
          aml_pace_mode(d->mode), d->fps, d->arrival_error.count,
          d->arrival_late, d->arrival_early, d->arrival_invalid,
          d->empty_ready_wakes, d->near_wake_dequeues, d->poll_timeouts,
          d->depth_peak, d->frames_returned, d->frames_dropped,
          d->adaptive_cap, d->adaptive_raises, d->adaptive_lowers,
          d->pts_checkin_failures, d->pts_consecutive_peak);
  aml_pace_report_metric(f, "arrival_abs_error", &d->arrival_error);
  aml_pace_report_metric(f, "decoder_submit", &d->submit);
  aml_pace_report_metric(f, "codec_write_call", &d->codec_write);
  if (d->mode != 0) {
    aml_pace_report_metric(f, "v4l2_output_gap", &d->decode_output_gap);
    aml_pace_report_metric(f, "driver_poll_wait", &d->poll_wait);
  }
  aml_pace_report_ring(f, "input", &d->input_events);
  if (d->mode != 0) aml_pace_report_ring(f, "display", &d->display_events);
}
#endif
