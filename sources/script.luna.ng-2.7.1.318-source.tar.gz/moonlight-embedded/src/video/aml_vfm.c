/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Opt-in SDR/HDR10 path: FFmpeg V4L2-M2M -> CE21 VFM bridge.
 * SDR uses linear DRM PRIME; Main10 retains native compressed frames.
 * This is a separate dlopen module: the default AML backend never loads FFmpeg.
 */
#define _POSIX_C_SOURCE 200809L
#include "video.h"
#include "aml_vfm_frame.h"
#include "vfm_progress.h"
#include "vfm_slot_pressure.h"
#include "vfm_ioctl_watchdog.h"
#include "first_video_ready.h"
#include "aml_decode_unit_validate.h"
#include "latency_priority.h"
#include "../../kernel/moonlight-vfm/moonlight_vfm.h"
#include <libavcodec/avcodec.h>
#include <libavutil/hwcontext_drm.h>
#include <libavutil/opt.h>
#include <drm_fourcc.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <time.h>

static AVCodecContext *decoder;
static AVFrame *inflight[MLVFM_SLOTS];
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_t worker;
static bool worker_started, stopping, await_idr;
static pthread_cond_t work_ready;
static bool work_ready_initialized;
static int init_work_ready(void) {
  if (work_ready_initialized) return 0;
  pthread_condattr_t attr;
  int rc = pthread_condattr_init(&attr);
  if (rc) return rc;
  rc = pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
  if (!rc) rc = pthread_cond_init(&work_ready, &attr);
  pthread_condattr_destroy(&attr);
  if (!rc) work_ready_initialized = true;
  return rc;
}
#define INPUT_QUEUE_SIZE 4
static AVPacket *input_queue[INPUT_QUEUE_SIZE];
static unsigned int input_count;
static void *decode_worker(void *unused);
static int bridge_fd = -1, frame_duration, stream_width, stream_height;
static bool native_main10;
static void (*request_stop)(void);
static unsigned long submitted, returned, dropped;
static VfmSlotPressure slot_pressure;
static bool worker_diagnostics;
static unsigned long worker_iterations, worker_waits, worker_send_eagain;
static unsigned long worker_empty_queue_timeouts;
static unsigned long long worker_wait_us;
static VfmProgress video_progress;
static bool first_video_ready_sent;
/* Independently detect a userspace worker trapped in bridge ioctl (including
 * DMA-BUF import), which the worker's own progress timer cannot observe. */
static pthread_t bridge_guard_thread;
static bool bridge_guard_started, bridge_guard_stop, bridge_guard_active;
/* Teardown is a SEPARATE lifetime. The decoder worker can leave its guarded
 * operation while the owner is blocked in pthread_join; that worker must not
 * be able to clear or reset the teardown monitor. */
static bool bridge_teardown_active;
static uint32_t bridge_teardown_entered_ms;
/* A timed-out setup must not continue initializing after the blocked call returns. */
static bool bridge_guard_cancelled;
/* ARM32 builds avoid lock-free 64-bit atomics and external libatomic. */
static uint32_t bridge_guard_entered_ms;
static unsigned int bridge_guard_generation;
/* The setup thread owns initial driver calls; the decode worker owns later
 * ioctls and FFmpeg calls. One guard monitors each potentially blocked stage. */
enum vfm_guard_operation {
  VFM_GUARD_NONE = 0,
  VFM_GUARD_BRIDGE = 1,
  VFM_GUARD_SEND_PACKET = 2,
  VFM_GUARD_RECEIVE_FRAME = 3,
  VFM_GUARD_OPEN_DECODER = 4,
  VFM_GUARD_TEARDOWN = 5,
  VFM_GUARD_SYSFS = 6,
  VFM_GUARD_OPEN_BRIDGE = 7,
  VFM_GUARD_RETURN_FRAME = 8
};
static int bridge_guard_operation;

/* Tests inject a deterministic monotonic clock; production uses clock_gettime. */
#ifndef VFM_NOW_US
static uint64_t vfm_now_us(void) {
  struct timespec now;
  if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return 0;
  return (uint64_t)now.tv_sec * 1000000ULL + now.tv_nsec / 1000;
}
#define VFM_NOW_US vfm_now_us
#endif

/* Does not open devices, register a provider, or change display state. */
int moonlight_vfm_init(void (*stop_callback)(void))
{
  const char *names[] = { "h264_v4l2m2m", "hevc_v4l2m2m" };
  unsigned int n;
  request_stop = stop_callback;
  for (n = 0; n < sizeof(names) / sizeof(names[0]); ++n) {
    const AVCodec *codec = avcodec_find_decoder_by_name(names[n]);
    int i;
    if (!codec) {
      fprintf(stderr, "AML-VFM: FFmpeg is missing %s\n", names[n]);
      return -1;
    }
    AVCodecContext *probe = avcodec_alloc_context3(codec);
    if (!probe || !av_opt_find(probe->priv_data, "nonblocking_dequeue", NULL, 0, 0)) {
      avcodec_free_context(&probe);
      fprintf(stderr, "AML-VFM: %s lacks nonblocking dequeue support\n", names[n]);
      return -1;
    }
    if (n == 1 && !av_opt_find(probe->priv_data, "aml_vfm_hdr", NULL, 0, 0)) {
      avcodec_free_context(&probe);
      fprintf(stderr, "AML-VFM: HEVC decoder lacks native Main10 frame export\n");
      return -1;
    }
    avcodec_free_context(&probe);
    for (i = 0; ; ++i) {
      const AVCodecHWConfig *hw = avcodec_get_hw_config(codec, i);
      if (!hw) {
        fprintf(stderr, "AML-VFM: %s lacks the V4L2 DRM PRIME patch\n", names[n]);
        return -1;
      }
      if (hw->pix_fmt == AV_PIX_FMT_DRM_PRIME)
        break;
    }
  }
  return 0;
}
static void fail(const char *operation, int error)
{
  char detail[AV_ERROR_MAX_STRING_SIZE];
  av_strerror(error, detail, sizeof(detail));
  fprintf(stderr, "AML-VFM: %s: %s; stopping experimental pipeline\n", operation, detail);
  pthread_mutex_lock(&lock);
  stopping = true;
  pthread_cond_broadcast(&work_ready);
  pthread_mutex_unlock(&lock);
  if (request_stop)
    request_stop();
}
/* Both bridge ioctls and FFmpeg V4L2 send/receive can call into vendor
 * drivers. Do not close fds/unload modules while any operation is in flight.
 * Luna verifies native process termination before touching shared hardware. */
static void vfm_guard_enter(enum vfm_guard_operation operation) {
  __atomic_store_n(&bridge_guard_operation, operation, __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_guard_entered_ms, (uint32_t)(VFM_NOW_US() / 1000ULL),
                   __ATOMIC_RELAXED);
  __atomic_add_fetch(&bridge_guard_generation, 1, __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_guard_active, true, __ATOMIC_RELEASE);
}
static void vfm_guard_leave(void) {
  __atomic_store_n(&bridge_guard_active, false, __ATOMIC_RELEASE);
}
static void vfm_teardown_guard_begin(void) {
  /* The common-c stop callback runs BEFORE cleanup. Never restart the
   * deadline once stop began: repeated stop/cleanup cannot grant a stuck
   * driver another full shutdown window. */
  if (__atomic_load_n(&bridge_teardown_active, __ATOMIC_ACQUIRE))
    return;
  __atomic_store_n(&bridge_teardown_entered_ms,
                   (uint32_t)(VFM_NOW_US() / 1000ULL), __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_teardown_active, true, __ATOMIC_RELEASE);
}
static void vfm_teardown_guard_end(void) {
  __atomic_store_n(&bridge_teardown_active, false, __ATOMIC_RELEASE);
}
static int monitored_bridge_ioctl(unsigned long command, void *arg) {
  vfm_guard_enter(VFM_GUARD_BRIDGE);
  int result = ioctl(bridge_fd, command, arg);
  vfm_guard_leave();
  return result;
}
static int monitored_decoder_open(const AVCodec *codec, AVDictionary **options) {
  vfm_guard_enter(VFM_GUARD_OPEN_DECODER);
  int result = avcodec_open2(decoder, codec, options);
  vfm_guard_leave();
  return result;
}
static int monitored_decoder_send(const AVPacket *packet) {
  vfm_guard_enter(VFM_GUARD_SEND_PACKET);
  int result = avcodec_send_packet(decoder, packet);
  vfm_guard_leave();
  return result;
}
static int monitored_decoder_receive(AVFrame *frame) {
  vfm_guard_enter(VFM_GUARD_RECEIVE_FRAME);
  int result = avcodec_receive_frame(decoder, frame);
  vfm_guard_leave();
  return result;
}
/* FFmpeg's CoreELEC DRM PRIME buffer-release callback can return a V4L2
 * capture buffer through VIDIOC_QBUF. av_frame_unref/free are therefore
 * driver calls, NOT ordinary malloc frees. Cover reaping, drain, failed
 * bridge submits, slot-pressure drops and cleanup with the independent
 * native operation watchdog rather than the decoder's progress timer. */
static void monitored_frame_unref(AVFrame *frame) {
  if (!frame) return;
  vfm_guard_enter(VFM_GUARD_RETURN_FRAME);
  av_frame_unref(frame);
  vfm_guard_leave();
}
static void monitored_frame_free(AVFrame **frame) {
  if (!frame || !*frame) return;
  vfm_guard_enter(VFM_GUARD_RETURN_FRAME);
  av_frame_free(frame);
  vfm_guard_leave();
}
static const char *vfm_guard_name(int operation) {
  switch (operation) {
  case VFM_GUARD_BRIDGE: return "bridge ioctl";
  case VFM_GUARD_SEND_PACKET: return "avcodec_send_packet";
  case VFM_GUARD_RECEIVE_FRAME: return "avcodec_receive_frame";
  case VFM_GUARD_OPEN_DECODER: return "avcodec_open2";
  case VFM_GUARD_TEARDOWN: return "driver teardown";
  case VFM_GUARD_SYSFS: return "decoder sysfs configuration";
  case VFM_GUARD_OPEN_BRIDGE: return "VFM bridge device open";
  case VFM_GUARD_RETURN_FRAME: return "V4L2 capture-buffer return";
  default: return "decoder operation";
  }
}

static void *bridge_guard_worker(void *unused) {
  (void)unused;
  unsigned int seen_generation = 0;
  bool stop_requested = false;
  bool teardown_stop_requested = false;
  for (;;) {
    if (__atomic_load_n(&bridge_guard_stop, __ATOMIC_ACQUIRE))
      return NULL;
    if (!__atomic_load_n(&bridge_guard_active, __ATOMIC_ACQUIRE)) {
      stop_requested = false;
    } else {
      const unsigned int generation =
          __atomic_load_n(&bridge_guard_generation, __ATOMIC_RELAXED);
      const uint32_t entered =
          __atomic_load_n(&bridge_guard_entered_ms, __ATOMIC_RELAXED);
      if (generation != seen_generation) {
        stop_requested = false;
        seen_generation = generation;
      }
      const int operation =
          __atomic_load_n(&bridge_guard_operation, __ATOMIC_RELAXED);
      int action = vfm_ioctl_watch_action((uint32_t)(VFM_NOW_US() / 1000ULL), entered);
      /* An operation may have returned while the monitor sampled its age.
       * Confirm both activity and generation before requesting shutdown. */
      if (action >= VFM_IOCTL_WATCH_REQUEST && !stop_requested &&
          __atomic_load_n(&bridge_guard_active, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&bridge_guard_generation, __ATOMIC_RELAXED) ==
              generation) {
        stop_requested = true;
        __atomic_store_n(&bridge_guard_cancelled, true, __ATOMIC_RELEASE);
        /* present() holds the VFM mutex during bridge ioctl; a decoder
         * operation may also be wedged. Do NOT call fail() here: it would
         * acquire that mutex and could deadlock this independent monitor. */
        fprintf(stderr, "AML-VFM: %s blocked for 12s; requesting shutdown\n",
                vfm_guard_name(operation));
        if (request_stop) request_stop();
      }
      if (action == VFM_IOCTL_WATCH_EXIT && stop_requested &&
          __atomic_load_n(&bridge_guard_active, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&bridge_guard_generation, __ATOMIC_RELAXED) ==
              seen_generation) {
        fprintf(stderr,
                "AML-VFM: %s still blocked after shutdown grace; exiting for Luna recovery\n",
                vfm_guard_name(operation));
        _exit(124);
      }
    }
    /* Independently watch the owner from BEFORE vfm_stop() through close()
     * and avcodec_free_context(). The worker's vfm_guard_leave() may clear
     * bridge_guard_active but cannot affect this separate teardown flag. */
    if (__atomic_load_n(&bridge_teardown_active, __ATOMIC_ACQUIRE)) {
      const uint32_t started =
          __atomic_load_n(&bridge_teardown_entered_ms, __ATOMIC_RELAXED);
      const int action = vfm_ioctl_watch_action(
          (uint32_t)(VFM_NOW_US() / 1000ULL), started);
      if (action >= VFM_IOCTL_WATCH_REQUEST && !teardown_stop_requested &&
          __atomic_load_n(&bridge_teardown_active, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&bridge_teardown_entered_ms, __ATOMIC_RELAXED) ==
              started) {
        teardown_stop_requested = true;
        __atomic_store_n(&bridge_guard_cancelled, true, __ATOMIC_RELEASE);
        fprintf(stderr, "AML-VFM: teardown/join blocked for 12s; requesting shutdown\n");
        if (request_stop) request_stop();
      }
      if (action == VFM_IOCTL_WATCH_EXIT && teardown_stop_requested &&
          __atomic_load_n(&bridge_teardown_active, __ATOMIC_ACQUIRE) &&
          __atomic_load_n(&bridge_teardown_entered_ms, __ATOMIC_RELAXED) ==
              started) {
        fprintf(stderr, "AML-VFM: teardown/join remained blocked; exiting for Luna recovery\n");
        _exit(124);
      }
    } else {
      teardown_stop_requested = false;
    }
    const struct timespec interval = { .tv_sec = 0, .tv_nsec = 250000000L };
    nanosleep(&interval, NULL);
  }
}

static void stop_bridge_guard(void) {
  if (!bridge_guard_started) return;
  __atomic_store_n(&bridge_guard_stop, true, __ATOMIC_RELEASE);
  pthread_join(bridge_guard_thread, NULL);
  bridge_guard_started = false;
}

static enum AVPixelFormat select_format(AVCodecContext *ctx,
                                       const enum AVPixelFormat *formats)
{
  for (; *formats != AV_PIX_FMT_NONE; ++formats)
    if (*formats == AV_PIX_FMT_DRM_PRIME)
      return *formats;
  fprintf(stderr, "AML-VFM: decoder offered no DRM PRIME output\n");
  return AV_PIX_FMT_NONE; /* Never quietly switch to CPU decoding/copying. */
}
static int reap_frames(void)
{
  struct mlvfm_done done;
  while (monitored_bridge_ioctl(MLVFM_REAP, &done) == 0) {
    if (done.cookie >= MLVFM_SLOTS || !inflight[done.cookie])
      return AVERROR(EPROTO);
    /* Only a non-dropped completion came through provider_get()/put().
     * Successfully submitted or later discarded frames are NOT evidence
     * that the video sink ever consumed a new picture. */
    if (!done.dropped) {
      pthread_mutex_lock(&lock);
      vfm_progress_frame(&video_progress);
      pthread_mutex_unlock(&lock);
    }
    monitored_frame_free(&inflight[done.cookie]);
    if (worker_diagnostics) ++returned;
    if (worker_diagnostics) dropped += !!done.dropped;
  }
  return errno == EAGAIN || errno == EINTR ? 0 : AVERROR(errno);
}
static void vfm_stop(void)
{
  /* Common-c calls stop before cleanup. A blocked AVFrame return may own
   * lock; arm independent teardown BEFORE trying to acquire that mutex. */
  vfm_teardown_guard_begin();
  pthread_mutex_lock(&lock);
  stopping = true;
  if (work_ready_initialized) pthread_cond_signal(&work_ready);
  pthread_mutex_unlock(&lock);
}
static void vfm_cleanup(void)
{
  unsigned int i;
  /* The worker join can itself wedge. Arm a separate owner lifetime before
   * requesting stop; a worker-side operation leave must not disarm it. */
  vfm_teardown_guard_begin();
  vfm_guard_enter(VFM_GUARD_TEARDOWN);
  vfm_stop();
  if (worker_started) {
    pthread_join(worker, NULL);
    worker_started = false;
  }
  /* The decoder worker can finish its own nested guarded operation just
   * before pthread_join returns, clearing bridge_guard_active. Re-arm the
   * teardown operation after the join so close/unmap remain monitored. */
  vfm_guard_enter(VFM_GUARD_TEARDOWN);
  for (i = 0; i < input_count; ++i)
    av_packet_free(&input_queue[i]);
  input_count = 0;
  video_progress = (VfmProgress){0};
  /* close() invokes kernel-side blackout/unregister, including on process
   * death. Do this before releasing FFmpeg frames or decoder capture pools. */
  if (bridge_fd >= 0) {
    close(bridge_fd);
    bridge_fd = -1;
  }
  for (i = 0; i < MLVFM_SLOTS; ++i)
    monitored_frame_free(&inflight[i]);
  avcodec_free_context(&decoder);
  vfm_guard_leave();
  vfm_teardown_guard_end();
  stop_bridge_guard();
  if (worker_diagnostics)
    fprintf(stderr, "AML-VFM: submitted=%lu returned=%lu queue_drops=%lu\n",
            submitted, returned, dropped);
  if (slot_pressure.dropped_decoded)
    fprintf(stderr, "VFM_SLOT_PRESSURE_SUMMARY_V1 dropped_unsubmitted=%llu\n",
            (unsigned long long)slot_pressure.dropped_decoded);
  if (worker_diagnostics)
    fprintf(stderr, "VFM_WORKER_DIAG_V1 iterations=%lu waits=%lu send_eagain=%lu empty_queue_timeouts=%lu wait_us=%llu\n",
            worker_iterations, worker_waits, worker_send_eagain,
            worker_empty_queue_timeouts, worker_wait_us);
}
static int vfm_setup(int format, int width, int height, int fps,
                     void *context, int flags)
{
  if (init_work_ready() != 0) return -1;
  struct mlvfm_info info;
  struct mlvfm_start start = { .abi = MLVFM_ABI, .pending_frames = 1 };
  FILE *blackout;
  unsigned int policy;
  AVDictionary *options = NULL;
  const AVCodec *codec;
  const char *pacing = getenv("MOONLIGHT_FRAME_PACING");
  int ret;
  if ((format != VIDEO_FORMAT_H264 && format != VIDEO_FORMAT_H265 &&
       format != VIDEO_FORMAT_H265_MAIN10) ||
      (flags & DISPLAY_ROTATE_MASK) || width < 2 || height < 2 ||
      width > 4096 || height > 2160 || (width & 1) || (height & 1) ||
      fps < 1 || fps > 120) {
    fprintf(stderr, "AML-VFM: supports unrotated H.264/HEVC SDR or HEVC Main10 HDR10, up to 4096x2160/120\n");
    return -1;
  }
  submitted = returned = dropped = 0;
  slot_pressure = (VfmSlotPressure){0};
  worker_iterations = worker_waits = worker_send_eagain = worker_empty_queue_timeouts = 0;
  worker_wait_us = 0;
  video_progress = (VfmProgress){0};
  first_video_ready_sent = false;
  bridge_guard_started = false;
  __atomic_store_n(&bridge_guard_stop, false, __ATOMIC_RELEASE);
  __atomic_store_n(&bridge_guard_active, false, __ATOMIC_RELEASE);
  __atomic_store_n(&bridge_teardown_active, false, __ATOMIC_RELEASE);
  __atomic_store_n(&bridge_teardown_entered_ms, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_guard_generation, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_guard_entered_ms, 0, __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_guard_operation, VFM_GUARD_NONE, __ATOMIC_RELAXED);
  __atomic_store_n(&bridge_guard_cancelled, false, __ATOMIC_RELEASE);
  worker_diagnostics = getenv("MOONLIGHT_STREAM_DIAGNOSTICS") &&
      strcmp(getenv("MOONLIGHT_STREAM_DIAGNOSTICS"), "1") == 0;
  stopping = false;
  await_idr = false;
  input_count = 0;
  native_main10 = format == VIDEO_FORMAT_H265_MAIN10;
  stream_width = width;
  stream_height = height;
  frame_duration = 96000 / fps;
  /* The VFM bridge has a different queue from amlvideo. Low Latency maps
   * to VFM's existing minimum (one pending); Balanced keeps two pending. */
  if (pacing && strcmp(pacing, "balanced") == 0)
    start.pending_frames = 2;
  else if (pacing && (strcmp(pacing, "low-latency") == 0 ||
                      strcmp(pacing, "adaptive") == 0)) {
    start.pending_frames = 1;
    if (strcmp(pacing, "adaptive") == 0)
      fprintf(stderr, "AML-VFM: Adaptive requires AMLVIDEO; using fixed one-frame VFM queue\n");
  }
  /* Arm before any bridge or FFmpeg driver initialization. If an ioctl or
   * avcodec_open2 wedges, this independent worker can request shutdown and
   * ultimately exit for Luna recovery instead of joining a stuck setup. */
  if (pthread_create(&bridge_guard_thread, NULL, bridge_guard_worker, NULL)) {
    fprintf(stderr, "AML-VFM: unable to arm initialization watchdog\n");
    goto error;
  }
  bridge_guard_started = true;
  /* This guard now starts BEFORE sysfs transitions and the bridge open.
   * Both can enter vendor kernel code; a blocked call must be recoverable
   * without joining the thread that is waiting in the kernel. */
  vfm_guard_enter(VFM_GUARD_SYSFS);
  /* CE loads amvdec_ports at boot with multiplanar disabled, despite exposing
   * VIDEO_M2M_MPLANE capabilities. Luna's insmod option only covers a newly
   * loaded module. Set the same mode for an existing module before FFmpeg opens
   * a context (Kodi has already stopped). Keep it enabled between sessions,
   * just as when the module was loaded with multiplanar=1. check-vfm never
   * reaches this hardware setup path. */
  FILE *mode = fopen("/sys/module/amvdec_ports/parameters/multiplanar", "r");
  int current = mode ? fgetc(mode) : EOF;
  if (mode)
    fclose(mode);
  if (current != 'Y' && current != '1') {
    if (current != 'N' && current != '0') {
      fprintf(stderr, "AML-VFM: cannot read amvdec_ports multiplanar mode\n");
      vfm_guard_leave();
      goto error;
    }
    mode = fopen("/sys/module/amvdec_ports/parameters/multiplanar", "w");
    if (!mode) {
      fprintf(stderr, "AML-VFM: cannot enable amvdec_ports multiplanar mode\n");
      vfm_guard_leave();
      goto error;
    }
    ret = fputs("1\n", mode);
    int closed = fclose(mode);
    if (ret < 0 || closed) {
      fprintf(stderr, "AML-VFM: enabling amvdec_ports multiplanar mode failed\n");
      vfm_guard_leave();
      goto error;
    }
  }
  vfm_guard_leave();
  if (__atomic_load_n(&bridge_guard_cancelled, __ATOMIC_ACQUIRE))
    goto error;
  vfm_guard_enter(VFM_GUARD_SYSFS);
  blackout = fopen("/sys/class/video/blackout_policy", "r");
  if (!blackout) {
    fprintf(stderr, "AML-VFM: cannot snapshot video blackout policy\n");
    vfm_guard_leave();
    goto error;
  }
  ret = fscanf(blackout, "%u", &policy);
  fclose(blackout);
  if (ret != 1 || policy > 1) {
    fprintf(stderr, "AML-VFM: unsupported video blackout policy\n");
    vfm_guard_leave();
    goto error;
  }
  vfm_guard_leave();
  if (__atomic_load_n(&bridge_guard_cancelled, __ATOMIC_ACQUIRE))
    goto error;
  start.blackout_policy = policy;
  vfm_guard_enter(VFM_GUARD_OPEN_BRIDGE);
  bridge_fd = open("/dev/moonlight-vfm", O_RDWR | O_CLOEXEC);
  vfm_guard_leave();
  if (__atomic_load_n(&bridge_guard_cancelled, __ATOMIC_ACQUIRE))
    goto error;
  if (bridge_fd < 0) {
    fprintf(stderr, "AML-VFM: cannot open /dev/moonlight-vfm: %s\n", strerror(errno));
    goto error;
  }
  if (monitored_bridge_ioctl(MLVFM_QUERY, &info) < 0 ||
      __atomic_load_n(&bridge_guard_cancelled, __ATOMIC_ACQUIRE) ||
      info.abi != MLVFM_ABI || info.slots != MLVFM_SLOTS) {
    fprintf(stderr, "AML-VFM: bridge ABI mismatch\n");
    goto error;
  }
  codec = avcodec_find_decoder_by_name(format == VIDEO_FORMAT_H264 ?
                                      "h264_v4l2m2m" : "hevc_v4l2m2m");
  decoder = avcodec_alloc_context3(codec);
  if (!decoder || !codec)
    goto error;
  decoder->width = width;
  decoder->height = height;
  decoder->pkt_timebase = (AVRational){ 1, 1000000 };
  decoder->framerate = (AVRational){ fps, 1 };
  decoder->get_format = select_format;
  decoder->flags |= AV_CODEC_FLAG_LOW_DELAY;
  decoder->thread_count = 1;
  av_dict_set(&options, "num_output_buffers", "16", 0);
  av_dict_set(&options, "num_capture_buffers", "20", 0);
  av_dict_set(&options, "pixel_format", "nv12", 0);
  av_dict_set(&options, "nonblocking_dequeue", "1", 0);
  if (native_main10)
    av_dict_set(&options, "aml_vfm_hdr", "1", 0);
  ret = monitored_decoder_open(codec, &options);
  if (ret < 0 || __atomic_load_n(&bridge_guard_cancelled, __ATOMIC_ACQUIRE) ||
      av_dict_count(options)) {
    fprintf(stderr, "AML-VFM: unable to open patched V4L2 NV12 decoder (error %d, unused options %d)\n",
            ret, av_dict_count(options));
    goto error;
  }
  av_dict_free(&options);
  if (monitored_bridge_ioctl(MLVFM_START, &start) < 0 ||
      __atomic_load_n(&bridge_guard_cancelled, __ATOMIC_ACQUIRE)) {
    fprintf(stderr, "AML-VFM: cannot register provider: %s\n", strerror(errno));
    goto error;
  }
  if (pthread_create(&worker, NULL, decode_worker, NULL))
    goto error;
  worker_started = true;
  fprintf(stderr, "AML-VFM: experimental %s pipeline, %u pending frame(s)\n",
          native_main10 ? "native Main10/HDR10" : "SDR NV12", start.pending_frames);
  return 0;
error:
  av_dict_free(&options);
  vfm_cleanup();
  return -1;
}
static int present(AVFrame *frame)
{
  struct mlvfm_frame output;
  struct mlvfm_native_frame native;
  unsigned int i;
  int ret = native_main10 ?
      aml_vfm_native_frame(frame, stream_width, stream_height, frame_duration, &native) :
      aml_vfm_frame(frame, decoder->width, decoder->height, frame_duration, &output);
  if (ret < 0)
    return ret;
  pthread_mutex_lock(&lock);
  if (stopping) {
    pthread_mutex_unlock(&lock);
    return AVERROR(EINTR);
  }
  for (i = 0; i < MLVFM_SLOTS && inflight[i]; ++i) {}
  if (i == MLVFM_SLOTS) {
    /* Drop the mutex before a bounded, non-blocking reap. Completion
     * accounting briefly takes this mutex itself. Never evict a frame the
     * bridge/kernel still owns. */
    pthread_mutex_unlock(&lock);
    ret = reap_frames();
    if (ret < 0) return ret;
    pthread_mutex_lock(&lock);
    if (stopping) {
      pthread_mutex_unlock(&lock);
      return AVERROR(EINTR);
    }
    for (i = 0; i < MLVFM_SLOTS && inflight[i]; ++i) {}
    if (i == MLVFM_SLOTS) {
      /* This decoded frame is NOT submitted to the bridge, so dropping it
       * cannot invalidate provider_get()/put() pointers. Nonfatal positive
       * sentinel also prevents false first-video-ready receipts. The active
       * input progress watchdog still stops a persistently wedged sink. */
      const bool log_drop = vfm_slot_drop_record(&slot_pressure, VFM_NOW_US());
      const unsigned long long drops =
          (unsigned long long)slot_pressure.dropped_decoded;
      pthread_mutex_unlock(&lock);
      if (log_drop)
        fprintf(stderr,
                "VFM_SLOT_PRESSURE_V1 action=drop_unsubmitted occupied=%u dropped=%llu\n",
                MLVFM_SLOTS, drops);
      return VFM_FRAME_DROPPED;
    }
  }
  if (native_main10)
    native.cookie = i;
  else
    output.cookie = i;
  inflight[i] = av_frame_clone(frame);
  if (!inflight[i]) {
    pthread_mutex_unlock(&lock);
    return AVERROR(ENOMEM);
  }
  ret = native_main10 ? monitored_bridge_ioctl(MLVFM_SUBMIT_NATIVE, &native) :
                        monitored_bridge_ioctl(MLVFM_SUBMIT, &output);
  if (ret < 0) {
    ret = AVERROR(errno);
    monitored_frame_free(&inflight[i]);
  } else {
    /* Accepted by the bridge, not necessarily fetched by amvideo.
     * Do not reset the sink-stall watchdog here. */
    if (worker_diagnostics) ++submitted;
  }
  pthread_mutex_unlock(&lock);
  if (ret == 0 && !first_video_ready_sent) {
    /* A decoder-produced frame was accepted by the bridge. This is stronger
     * than network connection readiness, but not an HDMI presentation ack. */
    if (!moonlight_first_video_publish(getenv("MOONLIGHT_VIDEO_READY_FILE"))) {
      fail("unable to publish first-video progress receipt", AVERROR(EIO));
      return AVERROR(EIO);
    }
    first_video_ready_sent = true;
  }
  return ret;
}
static int drain_frames(void)
{
  AVFrame *frame = av_frame_alloc();
  int ret;
  if (!frame)
    return AVERROR(ENOMEM);
  while ((ret = monitored_decoder_receive(frame)) == 0) {
    ret = present(frame);
    monitored_frame_unref(frame);
    if (ret < 0)
      break;
  }
  monitored_frame_free(&frame);
  return ret == AVERROR(EAGAIN) ? 0 : ret;
}
static void *decode_worker(void *unused)
{
  moonlight_latency_priority_current("VFMDecode", -2);
  AVPacket *pending = NULL;
  for (;;) {
    unsigned int i;
    int ret;
    if (worker_diagnostics) ++worker_iterations;
    pthread_mutex_lock(&lock);
    if (stopping) {
      pthread_mutex_unlock(&lock);
      break;
    }
    if (vfm_progress_stalled(&video_progress, VFM_NOW_US())) {
      pthread_mutex_unlock(&lock);
      fail("decoder produced no frames for 10s of active input", AVERROR(ETIMEDOUT));
      break;
    }
    if (!pending && input_count) {
      pending = input_queue[0];
      for (i = 1; i < input_count; ++i)
        input_queue[i - 1] = input_queue[i];
      --input_count;
    }
    pthread_mutex_unlock(&lock);
    ret = reap_frames();
    if (ret >= 0 && pending) {
      ret = monitored_decoder_send(pending);
      if (ret >= 0)
        av_packet_free(&pending);
      else if (ret == AVERROR(EAGAIN)) {
        if (worker_diagnostics) ++worker_send_eagain;
        ret = 0;
      }
    }
    if (ret >= 0)
      ret = drain_frames();
    if (ret < 0) {
      if (ret == AVERROR(EINTR)) {
        /* EINTR is an expected result only after a coordinated stop. If
         * a running decoder exits silently, future frames would accumulate
         * without a worker and Luna would never regain Kodi ownership. */
        pthread_mutex_lock(&lock);
        const bool shutting_down = stopping;
        pthread_mutex_unlock(&lock);
        if (!shutting_down)
          fail("unexpected decoder interruption", ret);
      } else {
        fail("decode/present", ret);
      }
      break;
    }
    /* V4L2 completion is asynchronous. Poll it even when the host produces
     * no new packets. The private FFmpeg option guarantees a zero-timeout
     * capture dequeue; never block the receiver or wait forever during stop. */
    pthread_mutex_lock(&lock);
    if (!stopping && (pending || !input_count)) {
      struct timespec until;
      clock_gettime(CLOCK_MONOTONIC, &until);
      until.tv_nsec += 2000000;
      if (until.tv_nsec >= 1000000000) {
        ++until.tv_sec;
        until.tv_nsec -= 1000000000;
      }
      struct timespec before, after;
      if (worker_diagnostics) {
        ++worker_waits;
        clock_gettime(CLOCK_MONOTONIC, &before);
      }
      int wait_rc = pthread_cond_timedwait(&work_ready, &lock, &until);
      if (worker_diagnostics) {
        clock_gettime(CLOCK_MONOTONIC, &after);
        long long elapsed = (long long)(after.tv_sec - before.tv_sec) * 1000000LL +
                            (after.tv_nsec - before.tv_nsec) / 1000LL;
        if (elapsed > 0) worker_wait_us += (unsigned long long)elapsed;
        if (wait_rc == ETIMEDOUT && !pending && !input_count)
          ++worker_empty_queue_timeouts;
      }
    }
    pthread_mutex_unlock(&lock);
  }
  av_packet_free(&pending);
  return NULL;
}
static int vfm_submit(PDECODE_UNIT unit)
{
  AVPacket *packet;
  PLENTRY entry;
  int offset = 0;
  unsigned int i;
  bool stopped;
  pthread_mutex_lock(&lock);
  stopped = stopping;
  pthread_mutex_unlock(&lock);
  if (stopped)
    return DR_OK;
  if (!aml_decode_unit_valid(unit) || (unit->hdrActive && !native_main10) ||
      unit->presentationTimeUs > INT64_MAX) {
    fail("unsupported decode unit", AVERROR(EINVAL));
    return DR_NEED_IDR;
  }
  packet = av_packet_alloc();
  if (!packet || av_new_packet(packet, unit->fullLength) < 0) {
    av_packet_free(&packet);
    fail("packet allocation", AVERROR(ENOMEM));
    return DR_NEED_IDR;
  }
  for (entry = unit->bufferList; entry; entry = entry->next) {
    if (entry->length < 0 || entry->length > unit->fullLength - offset) {
      av_packet_free(&packet);
      fail("invalid packet chain", AVERROR(EINVAL));
      return DR_NEED_IDR;
    }
    memcpy(packet->data + offset, entry->data, entry->length);
    offset += entry->length;
  }
  if (offset != unit->fullLength) {
    av_packet_free(&packet);
    fail("truncated packet chain", AVERROR(EINVAL));
    return DR_NEED_IDR;
  }
  packet->pts = packet->dts = unit->presentationTimeUs;
  if (unit->frameType == FRAME_TYPE_IDR)
    packet->flags |= AV_PKT_FLAG_KEY;
  pthread_mutex_lock(&lock);
  if (stopping) {
    pthread_mutex_unlock(&lock);
    av_packet_free(&packet);
    return DR_OK;
  }
  /* Track sustained incoming video even if the short queue overflows. A
   * completely idle/paused host is deliberately not considered stalled. */
  vfm_progress_input(&video_progress, VFM_NOW_US());
  if (input_count == INPUT_QUEUE_SIZE) {
    for (i = 0; i < input_count; ++i)
      av_packet_free(&input_queue[i]);
    input_count = 0;
    await_idr = true;
  }
  if (await_idr && unit->frameType != FRAME_TYPE_IDR) {
    pthread_mutex_unlock(&lock);
    av_packet_free(&packet);
    return DR_NEED_IDR;
  }
  await_idr = false;
  input_queue[input_count++] = packet;
  pthread_cond_signal(&work_ready);
  pthread_mutex_unlock(&lock);
  return DR_OK;
}
DECODER_RENDERER_CALLBACKS decoder_callbacks_aml_vfm = {
  .setup = vfm_setup, .stop = vfm_stop, .cleanup = vfm_cleanup,
  .submitDecodeUnit = vfm_submit,
  /* Use common's decoder thread; no direct network-thread decode or RFI. */
  .capabilities = 0,
};
