/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_AML_PACING_H
#define MOONLIGHT_AML_PACING_H
#include <stdbool.h>
#include <string.h>

/* 0 = direct Amlogic tunnel (no userspace frame queue).
 * The amlvideo pump retains the freshest 1 (Low Latency), 1..3 (Adaptive),
 * or 3 (Balanced) waiting frames. Unknown modes use the direct tunnel. */
static inline unsigned int aml_pacing_wait_limit(const char *mode) {
  if (!mode || !strcmp(mode, "latency")) return 0U;
  if (!strcmp(mode, "low-latency") || !strcmp(mode, "adaptive")) return 1U;
  if (!strcmp(mode, "balanced")) return 3U;
  return 0U;
}

static inline bool aml_pacing_is_adaptive(const char *mode) {
  return mode && !strcmp(mode, "adaptive");
}

/* A dequeued V4L2 buffer remains owned by userspace until QBUF succeeds.
 * Advance the local ring only after the kernel accepted that buffer back. */
static inline bool aml_pacing_complete_qbuf(int qbuf_result,
                                            unsigned int capacity,
                                            unsigned int *head,
                                            unsigned int *count) {
  if (qbuf_result != 0 || !head || !count || capacity == 0 ||
      *count == 0 || *head >= capacity)
    return false;
  *head = (*head + 1U) % capacity;
  --*count;
  return true;
}
#endif
