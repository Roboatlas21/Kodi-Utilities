/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_AML_WRITE_WATCHDOG_H
#define MOONLIGHT_AML_WRITE_WATCHDOG_H
#include <stdint.h>

#define AML_WRITE_GUARD_REQUEST_MS 12000U
#define AML_WRITE_GUARD_EXIT_MS 18000U
#define AML_WRITE_GUARD_IDLE 0
#define AML_WRITE_GUARD_REQUEST_STOP 1
#define AML_WRITE_GUARD_FORCE_EXIT 2

/* Plain uint32 monotonic millisecond subtraction remains valid over wrap
 * as long as watchdog durations are < 2^31 ms. */
static inline int aml_blocked_write_action(uint32_t now_ms, uint32_t entered_ms) {
  const uint32_t elapsed = now_ms - entered_ms;
  if (elapsed >= AML_WRITE_GUARD_EXIT_MS && elapsed < 0x80000000U)
    return AML_WRITE_GUARD_FORCE_EXIT;
  if (elapsed >= AML_WRITE_GUARD_REQUEST_MS && elapsed < 0x80000000U)
    return AML_WRITE_GUARD_REQUEST_STOP;
  return AML_WRITE_GUARD_IDLE;
}
#endif
