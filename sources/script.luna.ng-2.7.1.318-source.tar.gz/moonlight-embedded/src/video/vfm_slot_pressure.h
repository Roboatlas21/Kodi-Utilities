/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_VFM_SLOT_PRESSURE_H
#define MOONLIGHT_VFM_SLOT_PRESSURE_H
#include <stdbool.h>
#include <stdint.h>

/* Previously submitted frames belong to the bridge until MLVFM_REAP/STOP.
 * Only an unsubmitted decoded frame can be discarded on full occupancy. */
#define VFM_FRAME_DROPPED 1
#define VFM_SLOT_LOG_INTERVAL_US 5000000ULL
typedef struct {
  uint64_t dropped_decoded;
  uint64_t last_log_us;
  uint64_t suppressed;
} VfmSlotPressure;

static inline bool vfm_slot_drop_record(VfmSlotPressure *s, uint64_t now_us) {
  if (!s) return false;
  ++s->dropped_decoded;
  if (s->dropped_decoded == 1 ||
      (now_us && now_us >= s->last_log_us &&
       now_us - s->last_log_us >= VFM_SLOT_LOG_INTERVAL_US)) {
    s->last_log_us = now_us;
    s->suppressed = 0;
    return true;
  }
  ++s->suppressed;
  return false;
}
#endif
