/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_LATENCY_PRIORITY_H
#define MOONLIGHT_LATENCY_PRIORITY_H
#include <stdbool.h>

/* Optional, session-only Linux nice adjustments for the named video, audio,
 * and input workers. This never requests real-time scheduling. */
bool moonlight_latency_priority_enabled(void);
int moonlight_latency_priority_for_name(const char *name);
void moonlight_latency_priority_current(const char *role, int nice_value);
void moonlight_latency_priority_start(void);
void moonlight_latency_priority_stop(void);
#endif
