/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include "latency_priority.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __linux__
#include <dirent.h>
#include <pthread.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

static pthread_t scan_thread;
static bool scan_started;
static bool stop_scan;

static long current_tid(void) { return syscall(SYS_gettid); }

static void apply_priority(long tid, const char *role, int target) {
  errno = 0;
  const int before = getpriority(PRIO_PROCESS, (id_t)tid);
  if (before == -1 && errno != 0) {
    if (errno != ESRCH)
      fprintf(stderr, "LATENCY_PRIORITY_V1 role=%s tid=%ld error=%s (read)\n",
              role, tid, strerror(errno));
    return;
  }
  /* Never lower a user's already-more-favorable priority. */
  if (before <= target) return;
  if (setpriority(PRIO_PROCESS, (id_t)tid, target) == 0) {
    fprintf(stderr, "LATENCY_PRIORITY_V1 role=%s tid=%ld nice=%d->%d\n",
            role, tid, before, target);
  } else if (errno != ESRCH) {
    fprintf(stderr,
            "LATENCY_PRIORITY_V1 role=%s tid=%ld nice=%d requested=%d error=%s (continuing normally)\n",
            role, tid, before, target, strerror(errno));
  }
}

static bool thread_tid(const char *name, long *tid) {
  if (!name || !*name || !tid) return false;
  const char *s = name;
  while (*s >= '0' && *s <= '9') s++;
  if (!*name || *s) return false;
  errno = 0;
  char *end = NULL;
  const long value = strtol(name, &end, 10);
  if (errno || end == name || *end || value <= 0) return false;
  *tid = value;
  return true;
}

static void scan_common_threads(long seen[5]) {
  DIR *directory = opendir("/proc/self/task");
  if (!directory) {
    fprintf(stderr, "LATENCY_PRIORITY_V1 cannot inspect thread list: %s\n",
            strerror(errno));
    return;
  }
  struct dirent *entry;
  while ((entry = readdir(directory)) != NULL) {
    long tid;
    if (!thread_tid(entry->d_name, &tid)) continue;
    char path[96], name[40];
    if (snprintf(path, sizeof(path), "/proc/self/task/%ld/comm", tid) >= (int)sizeof(path))
      continue;
    FILE *file = fopen(path, "r");
    if (!file) continue;
    const bool read = fgets(name, sizeof(name), file) != NULL;
    fclose(file);
    if (!read) continue;
    name[strcspn(name, "\n")] = '\0';
    static const char *const roles[5] = {
      "InputSend", "AudioRecv", "AudioDec", "VideoRecv", "VideoDec"
    };
    for (unsigned i = 0; i < 5; i++) {
      if (strcmp(name, roles[i]) != 0 || seen[i] == tid) continue;
      seen[i] = tid; /* One attempt per worker; log denied changes only once. */
      apply_priority(tid, roles[i], moonlight_latency_priority_for_name(roles[i]));
      break;
    }
  }
  closedir(directory);
}

static void *scan_worker(void *unused) {
  (void)unused;
  long seen[5] = {0};
  /* Native Moonlight-common-c names workers asynchronously after creation.
   * Rescan briefly without blocking stream startup or polling forever. */
  for (unsigned attempt = 0; attempt < 20 &&
       !__atomic_load_n(&stop_scan, __ATOMIC_ACQUIRE); attempt++) {
    scan_common_threads(seen);
    bool all_seen = true;
    for (unsigned i = 0; i < 5; i++) if (!seen[i]) all_seen = false;
    if (all_seen) break;
    struct timespec delay = {.tv_sec = 0, .tv_nsec = 50000000};
    nanosleep(&delay, NULL);
  }
  return NULL;
}
#endif

bool moonlight_latency_priority_enabled(void) {
  const char *value = getenv("MOONLIGHT_LATENCY_PRIORITY");
  return value && strcmp(value, "1") == 0;
}

int moonlight_latency_priority_for_name(const char *name) {
  if (!name) return 0;
  if (!strcmp(name, "InputSend") || !strcmp(name, "AudioRecv") ||
      !strcmp(name, "AudioDec") || !strcmp(name, "InputLoop")) return -3;
  if (!strcmp(name, "VideoRecv") || !strcmp(name, "VideoDec") ||
      !strcmp(name, "AMLDisplay") || !strcmp(name, "VFMDecode")) return -2;
  return 0;
}

void moonlight_latency_priority_current(const char *role, int nice_value) {
#ifdef __linux__
  if (!moonlight_latency_priority_enabled() || !role || nice_value >= 0) return;
  apply_priority(current_tid(), role, nice_value);
#else
  (void)role;
  (void)nice_value;
#endif
}

void moonlight_latency_priority_start(void) {
#ifdef __linux__
  if (!moonlight_latency_priority_enabled()) return;
  /* Leave the main thread at its original nice until the OSD and helper
   * workers have been created. New pthreads inherit their creator's nice. */
  __atomic_store_n(&stop_scan, false, __ATOMIC_RELEASE);
  if (pthread_create(&scan_thread, NULL, scan_worker, NULL) == 0) {
    scan_started = true;
  } else {
    fprintf(stderr, "LATENCY_PRIORITY_V1 worker inspection unavailable (continuing normally)\n");
  }
#endif
}

void moonlight_latency_priority_stop(void) {
#ifdef __linux__
  if (!scan_started) return;
  __atomic_store_n(&stop_scan, true, __ATOMIC_RELEASE);
  pthread_join(scan_thread, NULL);
  scan_started = false;
#endif
}
