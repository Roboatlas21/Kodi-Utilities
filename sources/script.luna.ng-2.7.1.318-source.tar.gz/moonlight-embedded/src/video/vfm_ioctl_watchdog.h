/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_VFM_IOCTL_WATCHDOG_H
#define MOONLIGHT_VFM_IOCTL_WATCHDOG_H
#include <stdint.h>
#define VFM_IOCTL_WATCH_REQUEST_MS 12000U
#define VFM_IOCTL_WATCH_EXIT_MS 18000U
#define VFM_IOCTL_WATCH_IDLE 0
#define VFM_IOCTL_WATCH_REQUEST 1
#define VFM_IOCTL_WATCH_EXIT 2

/* 32-bit monotonic milliseconds permit lock-free atomics on ARM32. The
 * 49-day wrap is safe for bounded intervals below 2^31 milliseconds. */
static inline int vfm_ioctl_watch_action(uint32_t now_ms, uint32_t since_ms) {
  const uint32_t elapsed = now_ms - since_ms;
  if (elapsed >= 0x80000000U)
    return VFM_IOCTL_WATCH_IDLE;
  if (elapsed >= VFM_IOCTL_WATCH_EXIT_MS)
    return VFM_IOCTL_WATCH_EXIT;
  if (elapsed >= VFM_IOCTL_WATCH_REQUEST_MS)
    return VFM_IOCTL_WATCH_REQUEST;
  return VFM_IOCTL_WATCH_IDLE;
}
#endif
