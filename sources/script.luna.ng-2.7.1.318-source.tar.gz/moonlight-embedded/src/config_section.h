/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_CONFIG_SECTION_H
#define MOONLIGHT_CONFIG_SECTION_H
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
/* 1=valid section header, 0=ordinary line, -1=malformed header. Flat legacy
 * config files remain compatible; sectioned files use only [Moonlight]. */
static inline int moonlight_config_section_header(const char *line,
                                                   bool *is_moonlight) {
  if (!line || !is_moonlight) return -1;
  const char *p = line;
  while (*p == ' ' || *p == '\t') ++p;
  if (*p != '[') return 0;
  const char *end = strchr(p + 1, ']');
  if (!end) return -1;
  const char *tail = end + 1;
  while (*tail == ' ' || *tail == '\t' || *tail == '\r' || *tail == '\n')
    ++tail;
  if (*tail && *tail != '#' && *tail != ';') return -1;
  *is_moonlight = (size_t)(end - p - 1) == sizeof("Moonlight") - 1 &&
                  memcmp(p + 1, "Moonlight", sizeof("Moonlight") - 1) == 0;
  return 1;
}
#endif
