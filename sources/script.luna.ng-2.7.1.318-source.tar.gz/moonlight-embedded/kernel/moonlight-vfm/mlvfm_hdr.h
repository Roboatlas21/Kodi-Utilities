/* SPDX-License-Identifier: GPL-2.0 */
#ifndef MLVFM_HDR_H
#define MLVFM_HDR_H
/* The vendor decoder owns colour information. Permit HDR10/PQ BT.2020 and
 * SDR BT.709 inside a Main10 session, including host HDR on/off transitions.
 * Reject HLG/DV/HDR10+ rather than guessing their processing/aux metadata. */
static inline int mlvfm_colour_supported(unsigned int signal)
{
  unsigned int primaries = (signal >> 16) & 255;
  unsigned int transfer = (signal >> 8) & 255;
  unsigned int matrix = signal & 255;
  if (!(signal & (1U << 29)) || !(signal & (1U << 24)))
    return 0;
  return (primaries == 9 && transfer == 16 && matrix == 9) ||
         (primaries == 1 && (transfer == 1 || transfer == 13) && matrix == 1);
}
#endif
