"""Compile and exercise the REAL DualSense cleanup dispatcher under backpressure.

Only device-specific closers are mocked: the production queue dispatcher and
the exact production concurrency limit run unchanged, with no hidraw or ALSA.
"""
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DualSenseBackpressureTests(unittest.TestCase):
    def test_stalled_cleanup_is_bounded_and_another_device_can_complete(self):
        source = (ROOT / 'src/input/dualsense.c').read_text()
        declarations = source[source.index('#define DUALSENSE_CLEANUP_MAX_ACTIVE'):
                              source.index('static void *dualsense_close_one(')]
        dispatcher = source[source.index('static void *dualsense_cleanup_worker('):
                            source.index('static bool dualsense_cleanup_start(')]
        harness = r'''
#define _GNU_SOURCE
#include <assert.h>
#include <stdbool.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

typedef struct moonlight_dualsense {
  struct moonlight_dualsense *next, *retire_next;
  unsigned id;
} moonlight_dualsense;
'''
        harness += declarations
        harness += r'''
static bool released[12];
static bool started[12], finished[12];
static unsigned peak_active;
static void *dualsense_close_one(void *arg) {
  moonlight_dualsense *d = arg;
  pthread_mutex_lock(&bridge_cleanup.lock);
  started[d->id] = true;
  if (bridge_cleanup.active > peak_active)
    peak_active = bridge_cleanup.active;
  pthread_cond_broadcast(&bridge_cleanup.wake);
  while (!released[d->id])
    pthread_cond_wait(&bridge_cleanup.wake, &bridge_cleanup.lock);
  finished[d->id] = true;
  --bridge_cleanup.active; /* Production closer releases this reserved slot. */
  --bridge_cleanup.pending;
  pthread_cond_broadcast(&bridge_cleanup.wake);
  pthread_mutex_unlock(&bridge_cleanup.lock);
  free(d);
  return NULL;
}
'''
        harness += dispatcher
        harness += r'''
static void queue(unsigned id, bool blocked) {
  moonlight_dualsense *d = calloc(1, sizeof(*d));
  assert(d && id < 12);
  d->id = id;
  pthread_mutex_lock(&bridge_cleanup.lock);
  released[id] = !blocked;
  if (bridge_cleanup.tail) bridge_cleanup.tail->next = d;
  else bridge_cleanup.head = d;
  bridge_cleanup.tail = d;
  ++bridge_cleanup.pending;
  pthread_cond_broadcast(&bridge_cleanup.wake);
  pthread_mutex_unlock(&bridge_cleanup.lock);
}
static void allow(unsigned id) {
  pthread_mutex_lock(&bridge_cleanup.lock);
  released[id] = true;
  pthread_cond_broadcast(&bridge_cleanup.wake);
  pthread_mutex_unlock(&bridge_cleanup.lock);
}
static bool await(bool *flag) {
  struct timespec deadline;
  assert(clock_gettime(CLOCK_REALTIME, &deadline) == 0);
  deadline.tv_sec += 2;
  pthread_mutex_lock(&bridge_cleanup.lock);
  while (!*flag) {
    if (pthread_cond_timedwait(&bridge_cleanup.wake,
                               &bridge_cleanup.lock, &deadline) == ETIMEDOUT)
      break;
  }
  const bool ok = *flag;
  pthread_mutex_unlock(&bridge_cleanup.lock);
  return ok;
}
int main(void) {
  assert(DUALSENSE_CLEANUP_MAX_ACTIVE == 2U);
  assert(!pthread_create(&bridge_cleanup.worker, NULL,
                         dualsense_cleanup_worker, NULL));
  /* One blocked device must not prevent healthy queued devices from
   * retiring on the other worker slot. */
  queue(1, true);
  assert(await(&started[1]));
  queue(2, false);
  queue(3, false);
  queue(4, false);
  assert(await(&finished[2]));
  assert(await(&finished[3]));
  assert(await(&finished[4]));
  assert(!finished[1] && peak_active == 2);
  allow(1);
  assert(await(&finished[1]));

  /* Two blocked closers occupy the cap. Extra retirements remain queued
   * WITHOUT another pthread; a slot opens when either blocker finishes. */
  queue(5, true); queue(6, true);
  assert(await(&started[5]) && await(&started[6]));
  queue(7, false);
  usleep(30000);
  pthread_mutex_lock(&bridge_cleanup.lock);
  assert(!started[7] && bridge_cleanup.active == 2);
  pthread_mutex_unlock(&bridge_cleanup.lock);
  allow(5);
  assert(await(&finished[7]));
  assert(!finished[6]);
  allow(6);
  assert(await(&finished[5]) && await(&finished[6]));

  pthread_mutex_lock(&bridge_cleanup.lock);
  assert(bridge_cleanup.active == 0 && bridge_cleanup.pending == 0);
  assert(peak_active == DUALSENSE_CLEANUP_MAX_ACTIVE);
  bridge_cleanup.stopping = true;
  pthread_cond_broadcast(&bridge_cleanup.wake);
  pthread_mutex_unlock(&bridge_cleanup.lock);
  assert(!pthread_join(bridge_cleanup.worker, NULL));
  puts("DualSense cleanup: bounded parallelism, blocked devices and queue passed");
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as td:
            file = Path(td) / 'ds_cleanup_backpressure.c'
            binary = Path(td) / 'ds_cleanup_backpressure'
            file.write_text(harness)
            compiler = shlex.split(os.environ.get('CC', 'cc'))
            cmd = compiler + ['-std=gnu11', '-Wall', '-Wextra', '-Werror',
                              '-pthread', str(file), '-o', str(binary)]
            subprocess.run(cmd, capture_output=True, text=True, check=True)
            subprocess.run([str(binary)], timeout=8, check=True,
                           capture_output=True, text=True)


if __name__ == '__main__':
    unittest.main()
