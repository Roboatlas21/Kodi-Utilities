/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../src/platform.h"
#include "../src/config.h"

static bool parse(PCONFIGURATION cfg, const char *text) {
  char path[] = "/tmp/moonlight-hdr-XXXXXX";
  int fd = mkstemp(path);
  assert(fd >= 0);
  FILE *file = fdopen(fd, "w");
  assert(file);
  fputs(text, file);
  assert(fclose(file) == 0);
  bool accepted = config_file_parse(path, cfg);
  assert(unlink(path) == 0);
  return accepted;
}
static void load(PCONFIGURATION cfg, const char *text) {
  assert(parse(cfg, text));
}
int main(void) {
  CONFIGURATION cfg = {0};
  /* config_file_parse merges into a valid existing stream configuration. */
  cfg.stream.width = 1280;
  cfg.stream.height = 720;
  cfg.stream.fps = 60;
  cfg.stream.packetSize = 1392;
  cfg.stream.bitrate = -1;
  load(&cfg, "hdr = true\ncodec = h265\n");
  assert(cfg.hdr && cfg.codec == CODEC_HEVC);
  load(&cfg, "hdr = false\n");
  assert(!cfg.hdr); /* A session override must clear an older config. */
  load(&cfg, "hdr = yes\n"); assert(cfg.hdr);
  load(&cfg, "hdr = no\n"); assert(!cfg.hdr);
  load(&cfg, "hdr = yes\n");
  assert(!parse(&cfg, "hdr = TRUE\nhdr = FALSE\n"));
  assert(cfg.hdr); /* Duplicate scalar preserves the previous HDR value. */
  puts("PASS: HDR config on/off and layered false override");
}
