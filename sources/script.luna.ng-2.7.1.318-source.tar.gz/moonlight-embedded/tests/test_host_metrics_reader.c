/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/osd/host_metrics.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
/* Link the real worker with a fake HTTPS provider, no network or driver. */
int http_fetch_hardware_metrics(const char *h,unsigned short port,char *buf,size_t cap) {
  if (!strcmp(h,"192.0.2.6")) return 2;
  if (strcmp(h,"192.0.2.5")||port!=47984) return 1;
  snprintf(buf,cap,"{\"version\":1,\"interval_ms\":1000,\"cpu\":{\"cpu_usage_percent\":23},\"gpus\":[{\"metrics\":{\"gpu_usage_percent\":55}}]}");
  return 0;
}
int main(void) {
  HostMetricsReader r;
  host_metrics_open(&r,"192.0.2.5",47984);
  assert(r.started);
  struct timespec t={.tv_sec=0,.tv_nsec=100000000};nanosleep(&t,NULL);
  char out[256]; host_metrics_format(&r,out,sizeof(out));
  assert(strstr(out,"Host CPU 23%")&&strstr(out,"GPU[0] 55%"));
  host_metrics_close(&r);
  host_metrics_open(&r,"192.0.2.100",47984);
  assert(r.started);
  nanosleep(&t,NULL);
  host_metrics_format(&r,out,sizeof(out));
  assert(strstr(out,"not exposed"));
  host_metrics_close(&r);
  host_metrics_open(&r,"192.0.2.6",47984);
  assert(r.started);
  nanosleep(&t,NULL);
  host_metrics_format(&r,out,sizeof(out));
  assert(strstr(out,"authorization denied; retrying"));
  assert(!r.unsupported);
  host_metrics_close(&r);
  puts("host metrics worker: OK");
}
