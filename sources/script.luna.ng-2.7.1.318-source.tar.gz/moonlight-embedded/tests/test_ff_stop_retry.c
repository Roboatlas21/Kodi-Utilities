/* A failed stop retains the effect ID and retries without new host feedback. */
#define _GNU_SOURCE
#include <assert.h>
#include <stdarg.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/input.h>
static int attempts;
int __wrap_ioctl(int fd,unsigned long request,...) {
  (void)fd;assert(request==EVIOCRMFF);
  va_list args;va_start(args,request);int id=va_arg(args,int);va_end(args);assert(id==7);
  if(++attempts==1){errno=EAGAIN;return -1;}return 0;
}
#include "../src/input/evdev.c"
static int events;
int LiSendMultiControllerEvent(short slot,short mask,int buttons,unsigned char lt,unsigned char rt,
                              short lx,short ly,short rx,short ry) {
  (void)slot;(void)buttons;(void)lt;(void)rt;(void)lx;(void)ly;(void)rx;(void)ry;
  assert(events>=1);assert(mask==(events==3?0:1));++events;return 0;
}
int LiSendControllerArrivalEvent(uint8_t slot,uint16_t mask,uint8_t type,uint32_t buttons,uint16_t caps) {
  (void)type;(void)buttons;(void)caps;assert(events==0&&slot==0&&mask==1);++events;return 0;
}
int LiSendControllerSpeakerArrivalEvent(uint8_t slot,uint16_t mask,uint8_t type,uint32_t buttons,uint16_t caps,uint64_t speaker) {
  (void)speaker;return LiSendControllerArrivalEvent(slot,mask,type,buttons,caps);
}
int main(void) {
  assert(evdev_steam_claim_arrival(LI_CTYPE_STEAM,0,0)==0);
  evdev_publish_state(0,1,0,0,0,0,0,0);
  assert(evdev_steam_release_event(0,true)==0&&events==4);
  struct input_device device={.ff_pending=true,.haptic_effect_id=7,.ff_refs=1};
  device.ff_worker_fd=open("/dev/null",O_RDWR);
  pthread_mutex_init(&device.ff_mutex,NULL);pthread_cond_init(&device.ff_wake,NULL);
  pthread_t thread;assert(pthread_create(&thread,NULL,evdev_ff_worker,&device)==0);
  bool stopped=false;
  for(unsigned i=0;i<2000;++i) {
    pthread_mutex_lock(&device.ff_mutex);stopped=device.haptic_effect_id==-1;pthread_mutex_unlock(&device.ff_mutex);
    if(stopped)break;
    usleep(1000);
  }
  assert(stopped);
  pthread_mutex_lock(&devices_mutex);__atomic_store_n(&device.ff_retired,true,__ATOMIC_RELEASE);
  pthread_cond_signal(&device.ff_wake);pthread_mutex_unlock(&devices_mutex);
  pthread_join(thread,NULL);assert(attempts==2);
  pthread_cond_destroy(&device.ff_wake);pthread_mutex_destroy(&device.ff_mutex);
}
