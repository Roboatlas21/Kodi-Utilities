/* SPDX-License-Identifier: GPL-3.0-or-later
 * Four-channel S16_LE DualSense USB frames (8 bytes per frame) using the
 * shared ALSA bounded write helper, with mocked nonblocking callbacks.
 */
#include "../src/audio/alsa_bounded_write.h"
#include <assert.h>
#include <stdio.h>

#define USB_FRAMES 240U
#define USB_FRAME_BYTES 8U

typedef struct {
  long replies[20];
  int wait_reply[4], recover_reply;
  unsigned writes, waits, recovers;
  const unsigned char *pointers[20];
  unsigned long requests[20];
} Mock;
static long write_audio(void *ptr, const void *samples, unsigned long frames) {
  Mock *m = ptr;
  const unsigned i = m->writes++;
  assert(i < 20);
  m->pointers[i] = samples;
  m->requests[i] = frames;
  return m->replies[i];
}
static int wait_audio(void *ptr, int ms) {
  Mock *m = ptr;
  assert(ms == 5 && m->waits < 4);
  return m->wait_reply[m->waits++];
}
static int recover_audio(void *ptr, int error) {
  Mock *m = ptr;
  assert(error == -EPIPE || error == -ESTRPIPE || error == -EINTR);
  ++m->recovers;
  return m->recover_reply;
}
static const AlsaBoundedOps ops = {
  .write = write_audio, .wait = wait_audio, .recover = recover_audio
};
static Mock fresh(void) {
  Mock m = {0};
  for (unsigned i = 0; i < 20; ++i) m.replies[i] = USB_FRAMES;
  for (unsigned i = 0; i < 4; ++i) m.wait_reply[i] = 1;
  return m;
}
static AlsaBoundedResult submit(Mock *m, const unsigned char *buffer) {
  return alsa_bounded_write(&ops, m, buffer, USB_FRAMES, USB_FRAME_BYTES);
}
int main(void) {
  unsigned char pcm[USB_FRAMES * USB_FRAME_BYTES] = {0};
  Mock m = fresh();
  AlsaBoundedResult r = submit(&m, pcm);
  assert(r.remaining == 0 && m.writes == 1);
  assert(m.requests[0] == USB_FRAMES && m.pointers[0] == pcm);

  /* A short write must retry from frame 73, not retransmit played audio. */
  m = fresh();
  m.replies[0] = 73;
  m.replies[1] = USB_FRAMES - 73;
  r = submit(&m, pcm);
  assert(r.remaining == 0 && m.writes == 2);
  assert(m.requests[1] == USB_FRAMES - 73);
  assert(m.pointers[1] == pcm + 73 * USB_FRAME_BYTES);

  m = fresh();
  m.replies[0] = -EAGAIN;
  m.replies[1] = USB_FRAMES;
  r = submit(&m, pcm);
  assert(r.remaining == 0 && m.waits == 1 && m.recovers == 0);

  /* A single interrupted write is recoverable, with no replay or
   * ALSA queue reset; the next write retries exactly the pending frames. */
  m = fresh();
  m.replies[0] = -EINTR;
  m.replies[1] = USB_FRAMES;
  r = submit(&m, pcm);
  assert(r.remaining == 0 && m.writes == 2 && m.recovers == 1);
  assert(r.recovery_attempts == 1 && r.successful_recoveries == 1);
  assert(m.requests[1] == USB_FRAMES && m.pointers[1] == pcm);

  /* Repeated interruptions are bounded and fail rather than hanging. */
  m = fresh();
  for (unsigned i = 0; i < 20; ++i) m.replies[i] = -EINTR;
  r = submit(&m, pcm);
  assert(r.remaining == USB_FRAMES && m.writes == 3 && m.recovers == 2);
  assert(r.last_error == -EINTR);

  m = fresh();
  m.replies[0] = -EPIPE;
  m.replies[1] = USB_FRAMES;
  r = submit(&m, pcm);
  assert(r.remaining == 0 && m.recovers == 1);
  assert(r.recovery_attempts == 1 && r.successful_recoveries == 1);

  m = fresh();
  m.replies[0] = -EPIPE;
  m.recover_reply = -EIO;
  r = submit(&m, pcm);
  assert(r.remaining == USB_FRAMES && r.last_error == -EPIPE);
  assert(r.recovery_attempts == 1 && r.successful_recoveries == 0);

  m = fresh();
  for (unsigned i = 0; i < 20; ++i) m.replies[i] = -EAGAIN;
  r = submit(&m, pcm);
  assert(r.remaining == USB_FRAMES && m.waits == 2 && m.writes == 3);

  /* Sixteen one-frame writes must terminate without replaying consumed data. */
  m = fresh();
  for (unsigned i = 0; i < 20; ++i) m.replies[i] = 1;
  r = submit(&m, pcm);
  assert(r.remaining == USB_FRAMES - 16 && m.writes == 16);
  assert(m.pointers[15] == pcm + 15 * USB_FRAME_BYTES);

  puts("PASS: DualSense USB bounded four-channel PCM partial writes/recovery");
  return 0;
}
