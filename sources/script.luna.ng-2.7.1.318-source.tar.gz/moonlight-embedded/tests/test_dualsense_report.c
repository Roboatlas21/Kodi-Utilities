/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/input/dualsense_report.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
  assert(ml_ds_hid_enabled(NULL));  /* Normal auto-detection default. */
  assert(ml_ds_hid_enabled(""));
  assert(ml_ds_hid_enabled("1"));
  assert(!ml_ds_hid_enabled("0"));  /* Troubleshooting override. */
  uint8_t usb[ML_DS_USB_IN] = {0x01};
  usb[1 + 15] = 0x00; usb[1 + 16] = 0x04; /* gyro x: 1024 dps units */
  usb[1 + 21] = 0x00; usb[1 + 22] = 0x20; /* accel x: 1g units */
  usb[1 + 32] = 0x80; usb[1 + 36] = 0x81;
  usb[1 + 52] = 0x15;
  ml_ds_sample s;
  assert(ml_ds_parse(usb, sizeof(usb), ML_DS_USB, &s));
  assert(s.gyro[0] == 1024 && s.accel[0] == 8192);
  assert(s.touch[0][0] == 0x80 && s.battery == 0x15);
  assert(!ml_ds_parse(usb, sizeof(usb) - 1, ML_DS_USB, &s));
  assert(!ml_ds_parse(usb, sizeof(usb), ML_DS_BT, &s));

  uint8_t bt[ML_DS_BT_IN] = {0x31, 0};
  memcpy(bt + 2, usb + 1, ML_DS_USB_IN - 1);
  uint32_t crc = ml_ds_crc32(0xa1, bt, ML_DS_BT_IN - 4);
  for (unsigned i = 0; i < 4; ++i)
    bt[ML_DS_BT_IN - 4 + i] = (uint8_t)(crc >> (8 * i));
  assert(ml_ds_parse(bt, sizeof(bt), ML_DS_BT, &s));
  assert(s.gyro[0] == 1024 && s.accel[0] == 8192);
  bt[9] ^= 1;
  assert(!ml_ds_parse(bt, sizeof(bt), ML_DS_BT, &s));

  uint8_t body[ML_DS_PAYLOAD] = {0}, output[ML_DS_BT_OUT];
  body[0] = 0x0c; body[10] = 0x21; body[11] = 7; body[21] = 0x22;
  body[22] = 9;
  size_t size = 0;
  assert(ml_ds_output(body, ML_DS_USB, 0, output, &size));
  assert(size == ML_DS_USB_OUT && output[0] == 0x02);
  assert(output[11] == 0x21 && output[12] == 7 && output[22] == 0x22);
  assert(ml_ds_output(body, ML_DS_BT, 5, output, &size));
  assert(size == ML_DS_BT_OUT && output[0] == 0x31 && output[1] == 0x50);
  assert(output[13] == 0x21 && output[14] == 7);
  assert(ml_ds_le32(output + 74) == ml_ds_crc32(0xa2, output, 74));
  puts("PASS: DualSense USB/Bluetooth framing, CRC and effect offsets");
  return 0;
}
