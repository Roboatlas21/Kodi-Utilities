"""Verify AML validates decode units before diagnostics or tracing uses them."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).resolve().parents[1] / "src/video/aml.c")


class AmlGuardOrderTests(unittest.TestCase):
    def test_display_pump_ioctl_watchdog_is_independent_and_bounded(self):
        code = SOURCE.read_text()
        guard = code.split('static void *aml_codec_write_guard(', 1)[1].split(
            'static void aml_operation_enter(', 1)[0]
        pump = code.split('void* aml_display_thread(', 1)[1].split(
            'int aml_setup(', 1)[0]
        qbuf = code.split('static int aml_qbuf_index(', 1)[1].split(
            'void* aml_display_thread(', 1)[0]
        self.assertIn('display_ioctl_inflight', guard)
        self.assertIn('display_ioctl_generation', guard)
        self.assertIn('display_stop_requested', guard)
        self.assertIn('AML_WRITE_GUARD_REQUEST_STOP', guard)
        self.assertIn('AML_WRITE_GUARD_FORCE_EXIT', guard)
        self.assertIn('_exit(124)', guard)
        self.assertIn('aml_display_operation_enter(AML_DISPLAY_GUARD_QBUF);', qbuf)
        self.assertLess(qbuf.index('aml_display_operation_enter('),
                        qbuf.index('ioctl(videoFd, VIDIOC_QBUF, &vbuf)'))
        self.assertIn('aml_display_operation_leave();', qbuf)
        self.assertIn('aml_display_operation_enter(AML_DISPLAY_GUARD_DQBUF);', pump)
        self.assertLess(pump.index('aml_display_operation_enter('),
                        pump.index('ioctl(videoFd, VIDIOC_DQBUF, &vbuf)'))
        self.assertIn('aml_display_operation_leave();', pump)
        self.assertEqual(pump.count('ioctl(videoFd, VIDIOC_DQBUF,'), 1)
        self.assertEqual(code.count('ioctl(videoFd, VIDIOC_QBUF,'), 1)

    def test_invalid_unit_rejected_before_any_member_access(self):
        code = SOURCE.read_text()
        body = code.split("int aml_submit_decode_unit(PDECODE_UNIT decodeUnit) {", 1)[1]
        first_validation = body.index("if (!aml_decode_unit_valid(decodeUnit))")
        first_member = body.index("decodeUnit->")
        first_buffer = body.index("ensure_buf_size_checked(&pkt_buf")
        self.assertLess(first_validation, first_member)
        self.assertLess(first_validation, first_buffer)
        self.assertEqual(body.count("if (!aml_decode_unit_valid(decodeUnit))"), 1)


if __name__ == "__main__":
    unittest.main()
