/* SPDX-License-Identifier: GPL-3.0-or-later
 * ABI test for the pinned Nonary streaming-library extension.
 */
#include <Limelight.h>
#include <ControllerHaptics.h>
#include <ControllerSpeakerPcm.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
  uint8_t haptic[ML_HAPTICS_HEADER_SIZE + 8] = {0};
  haptic[0] = 1;
  haptic[1] = 1;
  MlHapticsWrite16(haptic + 2, 2);
  MlHapticsWrite32(haptic + 4, 99);
  MlHapticsWrite16(haptic + 8, 2);
  assert(MlHapticsValidate(haptic, sizeof(haptic)));
  haptic[10] = 1;
  assert(!MlHapticsValidate(haptic, sizeof(haptic)));

  uint8_t speaker[ML_SPEAKER_PCM_HEADER_SIZE + 8] = {0};
  speaker[0] = 2;
  speaker[1] = 1;
  MlSpeakerWrite16(speaker + 2, 2);
  MlSpeakerWrite32(speaker + 4, 1);
  MlSpeakerWrite32(speaker + 8, 14);
  MlSpeakerWrite64(speaker + 12, 500);
  MlSpeakerWrite16(speaker + 20, 2);
  MlSpeakerWrite64(speaker + 24, 1234);
  assert(MlSpeakerPcmValidate(speaker, sizeof(speaker)));
  speaker[22] = 4; /* Unknown flag must fail. */
  assert(!MlSpeakerPcmValidate(speaker, sizeof(speaker)));

  uint8_t bind[ML_SPEAKER_BIND_SIZE];
  assert(MlSpeakerPcmBuildBinding(bind, sizeof(bind), 2, 1234));
  assert(MlSpeakerRead32(bind + 4) == ML_SPEAKER_BIND_MAGIC);
  assert(MlSpeakerRead64(bind + 12) == 1234);
  assert(!MlSpeakerPcmBuildBinding(bind, sizeof(bind), 2, 0));
  assert(LI_CCAP_HAPTICS_PCM != LI_CCAP_PS_SPEAKER_PCM);
  puts("PASS: haptics/speaker PCM protocol validation and binding ABI");
  return 0;
}
