"""Compile and run the actual native configuration parser's HDR regression."""
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class HdrConfigTests(unittest.TestCase):
    def test_hdr_can_be_enabled_and_explicitly_disabled(self):
        with tempfile.TemporaryDirectory() as td:
            binary = Path(td) / 'hdr-config'
            subprocess.run(shlex.split(os.environ.get('CC', 'cc')) + [
                '-std=gnu99', '-Wall', '-Wextra', '-Werror',
                '-ffunction-sections', '-fdata-sections',
                '-I' + str(ROOT / 'third_party/moonlight-common-c/src'),
                '-I' + str(ROOT / 'src'),
                str(ROOT / 'tests/test_hdr_config.c'), str(ROOT / 'src/config.c'),
                '-Wl,--gc-sections', '-o', str(binary)], check=True)
            subprocess.run([str(binary)], check=True, timeout=10)


if __name__ == '__main__':
    unittest.main()
