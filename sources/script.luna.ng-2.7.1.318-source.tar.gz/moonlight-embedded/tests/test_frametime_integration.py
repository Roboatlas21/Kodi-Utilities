# SPDX-License-Identifier: GPL-3.0-or-later
"""Regression contracts for opt-in CoreELEC client frame timing."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def read(path): return (ROOT/path).read_text()
osd=read("src/osd/osd.c")
telemetry=read("src/osd/telemetry.c")
drm=read("src/osd/drm.c")
fb=read("src/osd/fbdev.c")
main=read("src/main.c")
assert 'if (strcmp(p, "-frametime") == 0)' in osd
assert "next_graph = ticks_ms() + 250" in osd
assert "next_statistics = ticks_ms() +" in osd
assert "session.record_frame_timing && monotonic_us32" in telemetry
assert "osd_ft_record_frame(&frame_capture" in telemetry
assert "const int result = original_video.submitDecodeUnit(du);" in telemetry
assert "osd_telemetry_prepare(server->serverInfo.address, server->httpsPort," in main
for renderer in (drm,fb):
    assert "graph_height = opt->frametime ? 168 : 0" in renderer
    assert "osd_ft_plot(graph" in renderer
    assert "s->graph_height = 0" in renderer
    assert "osd_ft_caption(graph" in renderer
assert "frame_capture" not in read("src/video/aml.c")
print("PASS: renderer and callback frame-time graph integration checks")
