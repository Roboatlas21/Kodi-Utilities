/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "../src/video/aml_write_watchdog.h"
int main(void) {
  assert(aml_blocked_write_action(100, 100) == AML_WRITE_GUARD_IDLE);
  assert(aml_blocked_write_action(12099, 100) == AML_WRITE_GUARD_IDLE);
  assert(aml_blocked_write_action(12100, 100) == AML_WRITE_GUARD_REQUEST_STOP);
  assert(aml_blocked_write_action(18099, 100) == AML_WRITE_GUARD_REQUEST_STOP);
  assert(aml_blocked_write_action(18100, 100) == AML_WRITE_GUARD_FORCE_EXIT);
  assert(aml_blocked_write_action(50, 100) == AML_WRITE_GUARD_IDLE);
  /* 32-bit timer wrapping across the 49.7-day boundary remains safe. */
  uint32_t near_wrap = UINT32_MAX - 5000U;
  assert(aml_blocked_write_action((uint32_t)(near_wrap + 11999U),
                                  near_wrap) == AML_WRITE_GUARD_IDLE);
  assert(aml_blocked_write_action((uint32_t)(near_wrap + 12000U),
                                  near_wrap) == AML_WRITE_GUARD_REQUEST_STOP);
  assert(aml_blocked_write_action((uint32_t)(near_wrap + 18000U),
                                  near_wrap) == AML_WRITE_GUARD_FORCE_EXIT);
  puts("PASS: AML blocked-write stop/escalation timing and 32-bit clock wrap");
}
