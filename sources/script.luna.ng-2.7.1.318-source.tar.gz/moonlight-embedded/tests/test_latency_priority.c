/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include "../src/video/latency_priority.h"
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>

static int input_applied, audio_applied, video_applied, unexpected;
static int ready_count, release_workers;

/* Test actual /proc/self/task name detection without changing test process
 * priorities or depending on CAP_SYS_NICE. */
int __wrap_getpriority(int which, id_t who) {
  assert(which == PRIO_PROCESS && who > 0);
  return 0;
}
int __wrap_setpriority(int which, id_t who, int priority) {
  assert(which == PRIO_PROCESS && who > 0);
  const char *name = NULL;
  char path[96], buf[32];
  snprintf(path, sizeof(path), "/proc/self/task/%ld/comm", (long)who);
  FILE *fp = fopen(path, "r");
  if (fp && fgets(buf, sizeof(buf), fp)) {
    buf[strcspn(buf, "\n")] = 0;
    name = buf;
  }
  if (fp) fclose(fp);
  if (name && !strcmp(name, "InputSend") && priority == -3)
    __atomic_add_fetch(&input_applied, 1, __ATOMIC_RELAXED);
  else if (name && !strcmp(name, "AudioDec") && priority == -3)
    __atomic_add_fetch(&audio_applied, 1, __ATOMIC_RELAXED);
  else if (name && !strcmp(name, "VideoDec") && priority == -2)
    __atomic_add_fetch(&video_applied, 1, __ATOMIC_RELAXED);
  else
    __atomic_add_fetch(&unexpected, 1, __ATOMIC_RELAXED);
  return 0;
}

static void *worker(void *arg) {
  assert(pthread_setname_np(pthread_self(), (const char *)arg) == 0);
  __atomic_add_fetch(&ready_count, 1, __ATOMIC_RELEASE);
  while (!__atomic_load_n(&release_workers, __ATOMIC_ACQUIRE)) {
    struct timespec pause = {.tv_nsec = 1000000};
    nanosleep(&pause, NULL);
  }
  return NULL;
}

int main(void) {
  assert(unsetenv("MOONLIGHT_LATENCY_PRIORITY") == 0);
  assert(!moonlight_latency_priority_enabled());
  assert(setenv("MOONLIGHT_LATENCY_PRIORITY", "0", 1) == 0);
  assert(!moonlight_latency_priority_enabled());
  assert(setenv("MOONLIGHT_LATENCY_PRIORITY", "true", 1) == 0);
  assert(!moonlight_latency_priority_enabled());
  assert(setenv("MOONLIGHT_LATENCY_PRIORITY", "1", 1) == 0);
  assert(moonlight_latency_priority_enabled());
  const char *input[] = {"InputLoop", "InputSend", "AudioRecv", "AudioDec"};
  for (unsigned i = 0; i < sizeof(input) / sizeof(input[0]); i++)
    assert(moonlight_latency_priority_for_name(input[i]) == -3);
  const char *video[] = {"VideoRecv", "VideoDec", "AMLDisplay", "VFMDecode"};
  for (unsigned i = 0; i < sizeof(video) / sizeof(video[0]); i++)
    assert(moonlight_latency_priority_for_name(video[i]) == -2);
  assert(moonlight_latency_priority_for_name(NULL) == 0);
  assert(moonlight_latency_priority_for_name("OSD") == 0);
  assert(moonlight_latency_priority_for_name("VideoPing") == 0);
  assert(moonlight_latency_priority_for_name("VideoDecExtra") == 0);
  assert(moonlight_latency_priority_for_name("AudioPing") == 0);
  assert(unsetenv("MOONLIGHT_LATENCY_PRIORITY") == 0);
  moonlight_latency_priority_start();
  moonlight_latency_priority_stop();
  moonlight_latency_priority_current("InputLoop", -3);

  pthread_t threads[4];
  const char *names[4] = {"InputSend", "AudioDec", "VideoDec", "OSD"};
  for (unsigned i = 0; i < 4; i++)
    assert(pthread_create(&threads[i], NULL, worker, (void *)names[i]) == 0);
  while (__atomic_load_n(&ready_count, __ATOMIC_ACQUIRE) != 4) {
    struct timespec pause = {.tv_nsec = 1000000};
    nanosleep(&pause, NULL);
  }
  assert(setenv("MOONLIGHT_LATENCY_PRIORITY", "1", 1) == 0);
  moonlight_latency_priority_start();
  for (unsigned i = 0; i < 300 &&
       (!__atomic_load_n(&input_applied, __ATOMIC_RELAXED) ||
        !__atomic_load_n(&audio_applied, __ATOMIC_RELAXED) ||
        !__atomic_load_n(&video_applied, __ATOMIC_RELAXED)); i++) {
    struct timespec pause = {.tv_nsec = 1000000};
    nanosleep(&pause, NULL);
  }
  moonlight_latency_priority_stop();
  assert(input_applied == 1 && audio_applied == 1 && video_applied == 1);
  assert(unexpected == 0); /* OSD remains unprioritized. */
  __atomic_store_n(&release_workers, 1, __ATOMIC_RELEASE);
  for (unsigned i = 0; i < 4; i++) pthread_join(threads[i], NULL);
  puts("PASS: opt-in named-thread priorities, unrelated workers, and disabled no-op");
  return 0;
}
