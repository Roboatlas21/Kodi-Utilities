/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/video/aml_pacing_debug.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
  AmlPaceDebug d = {0};
  AmlPaceSnapshot before = {0}, after = {0};
  assert(!aml_pace_snapshot(&d, &after)); /* Debug OFF. */
  d.enabled = true;
  d.mode = 2;
  d.fps = 60;
  d.start_us = 1000000U;
  d.adaptive_cap = 1;
  assert(aml_pace_snapshot(&d, &before));
  assert(before.abi == AML_PACE_DEBUG_ABI && !before.arrival_error.count);

  aml_pace_record(&d.arrival_error, 500U);
  aml_pace_record(&d.arrival_error, 1000U);
  aml_pace_record(&d.submit, 20000U);
  aml_pace_record(&d.codec_write, 1000U);
  aml_pace_record(&d.decode_output_gap, 16667U);
  aml_pace_record(&d.poll_wait, 10000U);
  aml_pace_inc(&d.arrival_late);
  aml_pace_inc(&d.empty_ready_wakes);
  aml_pace_inc(&d.near_wake_dequeues);
  aml_pace_inc(&d.frames_dropped);
  aml_pace_queue(&d, 1);
  aml_pace_queue(&d, 3);
  d.adaptive_cap = 2;
  aml_pace_inc(&d.adaptive_raises);
  assert(aml_pace_snapshot(&d, &after));
  assert(after.arrival_error.count == 2);
  assert(after.arrival_error.bins[0] == 1 && after.arrival_error.bins[1] == 1);
  assert(after.arrival_error.worst_us == 1000);
  assert(aml_pace_quantile_bin(after.arrival_error.bins, 95) == 1000);
  assert(aml_pace_quantile_bin(after.arrival_error.bins, 99) == 1000);
  assert(after.depth_samples == 2 && after.depth_sum == 4 && after.depth_peak == 3);

  char buf[1500];
  aml_pace_format_interval(&before, NULL, buf, sizeof(buf));
  assert(strstr(buf, "baseline=1"));
  aml_pace_format_interval(&after, &before, buf, sizeof(buf));
  assert(strstr(buf, "PACING_DIAG_V1 mode=adaptive fps=60"));
  assert(strstr(buf, "arrival_pairs=+2 late=+1"));
  assert(strstr(buf, "near_wake=+1 depth_iter_mean=2.00 depth_peak=3"));
  assert(strstr(buf, "cap=2 raises=+1 lowers=+0"));
  assert(strstr(buf, "arrival_p99_bucket_us=1000"));
  assert(strstr(buf, "submit_mean_us=20000"));
  assert(strstr(buf, "write_mean_us=1008"));
  assert(strstr(buf, "decode_gap_n=+1 decode_gap_mean_us=16672"));
  assert(strstr(buf, "poll_mean_us=10000"));

  /* u32 wrapping is handled for short interval deltas. */
  AmlPaceMetricView prior = {.count=UINT32_MAX-1, .sum_16us=UINT32_MAX-2};
  AmlPaceMetricView current = {.count=1, .sum_16us=4};
  prior.bins[0]=UINT32_MAX-1;
  current.bins[0]=1;
  AmlPaceMetricView delta = aml_pace_delta(&current, &prior);
  assert(delta.count == 3 && delta.sum_16us == 7 && delta.bins[0] == 3);

  /* A bounded ring overwrites oldest events and prints at most 12 at exit. */
  for (uint32_t i = 0; i < 80; ++i)
    aml_pace_event(&d.input_events, 1000000U + i * 1000U, d.start_us,
                   AML_PACE_LATE_ARRIVAL, i, 0);
  assert(d.input_events.written == 80);
  assert(d.input_events.items[0].value_us == 64);

  FILE *f = tmpfile();
  assert(f);
  aml_pace_report(&d, f);
  fflush(f);
  rewind(f);
  unsigned lines=0, event_lines=0;
  char line[512];
  bool summary=false, exact_mean=false;
  while (fgets(line, sizeof(line), f)) {
    ++lines;
    if (strstr(line, "PACING_SUMMARY_V1 mode=adaptive")) summary=true;
    if (strstr(line, "stage=arrival_abs_error") &&
        strstr(line, "mean_us=750")) exact_mean=true;
    if (strstr(line, "PACING_EVENT_V1")) ++event_lines;
  }
  assert(summary && exact_mean && event_lines == 12 && lines <= 20);
  fclose(f);
  puts("AML pacing debug: OFF gate, interval/percentiles, wrap, bounded trace and summary passed");
  return 0;
}
