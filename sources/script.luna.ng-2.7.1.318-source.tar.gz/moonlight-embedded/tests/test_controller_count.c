#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include "../src/input/controller_count.h"

int main(void) {
  assert(moonlight_gamepad_mask(0,0) == 0);
  assert(moonlight_gamepad_mask(1,0) == 1);
  assert(moonlight_gamepad_mask(2,1) == 7);
  /* Two mapped evdev pads plus one claimed native Steam HID pad. */
  assert(moonlight_gamepad_mask(2 + 1,0) == 7);
  assert(moonlight_gamepad_mask(15 + 2,0) == 65535);
  assert(moonlight_gamepad_mask(0,16) == 65535);
  assert(moonlight_gamepad_mask(16,0) == 65535);
  assert(moonlight_gamepad_mask(17,0) == 65535);
  assert(moonlight_gamepad_mask(INT_MAX,INT_MAX) == 65535);
  assert(moonlight_gamepad_mask(-20,2) == 3);
  assert(moonlight_gamepad_mask(2,-5) == 3);
  assert(moonlight_gamepad_mask(8,8) == 65535);
  assert(!moonlight_host_input_allowed(1, -1));
  assert(moonlight_host_input_allowed(1, 0));
  assert(moonlight_host_input_allowed(1, 15));
  assert(!moonlight_host_input_allowed(1, 16));
  assert(moonlight_host_input_allowed(0, -1)); /* Keyboard/remote still work. */
  assert(!moonlight_gamepad_slot_valid(-1));
  assert(moonlight_gamepad_slot_valid(0));
  assert(moonlight_gamepad_slot_valid(15));
  assert(!moonlight_gamepad_slot_valid(16));
  assert(moonlight_first_free_gamepad_slot(0) == 0);
  assert(moonlight_first_free_gamepad_slot(1U) == 1);
  assert(moonlight_first_free_gamepad_slot(0xfffeU) == 0);
  assert(moonlight_first_free_gamepad_slot(0xffffU) == -1);
  assert(moonlight_first_free_gamepad_slot(0xffffU | (1U << 20)) == -1);
  puts("PASS: controller count and bounded mask");
  return 0;
}
