/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/osd/frametime.h"
#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
static OsdFtCapture captured;
static unsigned finished;
static void *write_frames(void *ignored) {
  (void)ignored;
  for (uint32_t i=0; i<100000; ++i) {
    const uint32_t t=100000u+i*16667u;
    osd_ft_record(&captured,t,t+300u);
  }
  __atomic_store_n(&finished,1,__ATOMIC_RELEASE);
  return NULL;
}
int main(void) {
  osd_ft_reset(&captured);
  pthread_t th;
  assert(pthread_create(&th,NULL,write_frames,NULL)==0);
  OsdFtView view;
  unsigned snapshots=0;
  do {
    osd_ft_snapshot(&captured,0u,60,&view);
    assert(view.count<=OSD_FT_SAMPLES);
    for(unsigned i=0;i<view.count;i++) {
      assert(view.callback_gap_us[i]<=OSD_FT_MAX_INTERVAL_US);
      assert(view.return_gap_us[i]<=OSD_FT_MAX_INTERVAL_US);
      assert(view.execution_us[i]==300u);
      assert(view.missing_frames[i]==0);
      if (i) assert(view.position[i]>view.position[i-1]);
    }
    ++snapshots;
  } while(!__atomic_load_n(&finished,__ATOMIC_ACQUIRE));
  pthread_join(th,NULL);
  osd_ft_snapshot(&captured,0u,60,&view);
  assert(view.count==OSD_FT_SAMPLES);
  assert(snapshots>0);
  puts("PASS: concurrent frametime reads never tear callbacks");
}
