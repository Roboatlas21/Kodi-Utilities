"""Priority scheduling is opt-in and boosts only targeted stream threads."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class LatencyPriorityWiringTests(unittest.TestCase):
    def test_input_loop_is_boosted_only_after_osd_worker_creation(self):
        main = (ROOT / "src/main.c").read_text()
        self.assertIn('if (IS_EMBEDDED(system)) moonlight_latency_priority_start();', main)
        self.assertIn('if (IS_EMBEDDED(system)) moonlight_latency_priority_stop();', main)
        self.assertIn('moonlight_latency_priority_current("InputLoop", -3);', main)
        self.assertLess(main.index('osd_start_monitor(&native_osd,'),
                        main.index('moonlight_latency_priority_current("InputLoop", -3);'))
        self.assertLess(main.index('moonlight_latency_priority_current("InputLoop", -3);'),
                        main.index('input_loop_status = loop_main();'))
        self.assertGreaterEqual(main.count('moonlight_latency_priority_stop();'), 2)

    def test_targeted_native_workers_and_build_support(self):
        aml = (ROOT / "src/video/aml.c").read_text()
        vfm = (ROOT / "src/video/aml_vfm.c").read_text()
        cmake = (ROOT / "CMakeLists.txt").read_text()
        self.assertIn('moonlight_latency_priority_current("AMLDisplay", -2);', aml)
        self.assertIn('moonlight_latency_priority_current("VFMDecode", -2);', vfm)
        self.assertIn('target_sources(moonlight PRIVATE ./src/video/latency_priority.c)', cmake)
        self.assertIn('target_link_libraries(moonlight Threads::Threads)', cmake)
        self.assertIn('src/video/latency_priority.c ./src/util.c', cmake)
        self.assertIn('src/video/latency_priority.c)', cmake)


if __name__ == "__main__":
    unittest.main()
