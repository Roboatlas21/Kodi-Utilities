"""Mapping/teardown event drains must not wait forever on a busy device."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class EvdevDrainBudgetTests(unittest.TestCase):
    def test_continuously_readable_devices_are_bounded_and_sync_survives(self):
        source = (ROOT / "src/input/evdev.c").read_text()
        start = source.index("static void evdev_drain(void) {")
        end = source.index("\n/* Explicit POLLNVAL recovery", start)
        native = source[start:end]
        harness = r'''
#include <assert.h>
#include <stdbool.h>
#include <errno.h>
#define LIBEVDEV_READ_STATUS_SUCCESS 0
#define LIBEVDEV_READ_STATUS_SYNC 1
#define LIBEVDEV_READ_FLAG_NORMAL 0
#define LIBEVDEV_READ_FLAG_SYNC 1
struct input_event { int code; };
struct input_device { void *dev; bool syncing; };
static struct input_device d0 = {(void*)1, false};
static struct input_device d1 = {(void*)2, false};
static struct input_device *devices[] = {&d0, &d1};
static int numDevices = 2;
static unsigned attempts0, attempts1;
static int next_event(void *device, int flags, struct input_event *ev) {
  (void)ev;
  if (device == (void*)1) {
    assert(flags == LIBEVDEV_READ_FLAG_NORMAL);
    ++attempts0;
    return LIBEVDEV_READ_STATUS_SUCCESS; /* Always readable */
  }
  assert(device == (void*)2 && flags == LIBEVDEV_READ_FLAG_SYNC);
  ++attempts1;
  return LIBEVDEV_READ_STATUS_SYNC; /* Endless libevdev sync */
}
#define libevdev_next_event next_event
'''
        harness += native
        harness += r'''
int main(void) {
  d1.syncing = true;
  evdev_drain();
  assert(attempts0 == 256 && attempts1 == 256);
  assert(d1.syncing);
  evdev_drain();
  assert(attempts0 == 512 && attempts1 == 512);
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "drain.c"
            exe = Path(td) / "drain"
            src.write_text(harness)
            build = subprocess.run(
                shlex.split(os.environ.get("CC", "cc")) +
                ["-std=gnu11", "-Wall", "-Wextra", "-Werror",
                 str(src), "-o", str(exe)],
                text=True, capture_output=True)
            self.assertEqual(build.returncode, 0, build.stderr)
            subprocess.run([str(exe)], timeout=5, check=True)


if __name__ == "__main__":
    unittest.main()
