/* Test the lexical INI scanner separately from native CLI/network setup. */
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "../src/config_ini.h"

static void check(const char *input, bool valid, size_t count) {
  const size_t n = strlen(input);
  char *copy = malloc(n + 1);
  assert(copy);
  memcpy(copy, input, n + 1);
  MoonlightIni config = {0};
  config.count = 7;
  config.entries[0].key = "prior";
  bool result = moonlight_ini_parse(copy, n, &config);
  assert(result == valid);
  if (result) assert(config.count == count);
  else {
    assert(config.count == 7);
    assert(strcmp(config.entries[0].key, "prior") == 0);
  }
  free(copy);
}

int main(void) {
  check("[Moonlight]\naddress = gaming-vm\n", true, 1);
  check("address=desktop-vm\r\nfps=120\r\n", true, 2);
  check(" ; comment\n[Other]\naddress=wrong\n"
        "[Moonlight]\naddress=right\n", true, 1);
  check("[Moonlight]\ninput=/dev/input/event1\n"
        "input=/dev/input/event2\n", true, 2);
  check("[Moonlight]\naddress=x\n[Moonlight]\naddress=y\n", false, 0);
  check("[Moonlight]\naddress=x\naddress=y\n", false, 0);
  check("[Moonlight]\naddress=x\nunexpected\n", false, 0);
  check("address=x\rjunk\n", false, 0);
  check("[Moonlight\naddress=x\n", false, 0);
  check("[Other]\naddress=x\n", false, 0);
  check("[Moonlight]\naddress=\n", false, 0);
  check("[Moonlight]\naddress=x\n[Other]\naddress=y\n", true, 1);
  check("  # ignored\r\n[Moonlight] ; note\r\n"
        "address = hdr-vm\r\ncodec = HEVC\r\n", true, 2);
  check("[Other]\nhdr=invalid\n[Moonlight]\nhdr=true\n", true, 1);
  check("[Moonlight]\nhdr=true\nhdr=false\n", false, 0);
  check("[Moonlight]\ninput=/dev/input/event1\n"
        "input=/dev/input/event1\n", true, 2);
  check("[Moonlight]\naddress=x\n[Other]\n"
        "[Moonlight]\nfps=120\n", false, 0);
  check("[Moonlight] stray\naddress=x\n", false, 0);
  check("[Moonlight]\naddress=x\nfps=120\ninvalid-line\n", false, 0);
  check("[Moonlight]\naddress=x\nfps=120\n"
        "bad-key!=foo\n", false, 0);
  puts("PASS: bounded native INI scanner");
  return 0;
}
