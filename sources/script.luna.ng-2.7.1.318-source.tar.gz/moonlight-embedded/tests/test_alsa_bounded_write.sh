#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -I"$root/src/audio" \
  "$root/tests/test_alsa_bounded_write.c" -o "$tmp/test-alsa-bounded-write"
"$tmp/test-alsa-bounded-write"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic -I"$root/src/audio" \
  "$root/tests/test_alsa_pending_queue.c" -o "$tmp/test-alsa-pending-queue"
"$tmp/test-alsa-pending-queue"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -I"$root/src/audio" \
  "$root/tests/test_alsa_suspend_recovery.c" -o "$tmp/test-alsa-suspend-recovery"
"$tmp/test-alsa-suspend-recovery"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -I"$root/src/audio" \
  "$root/tests/test_dualsense_usb_bounded_write.c" -o "$tmp/test-dualsense-usb-write"
"$tmp/test-dualsense-usb-write"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic \
  "$root/tests/test_dualsense_pcm_packets.c" -o "$tmp/test-dualsense-bt-packets"
"$tmp/test-dualsense-bt-packets"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic \
  "$root/tests/test_saxense_hid_write.c" -o "$tmp/test-dualsense-bt-write"
"$tmp/test-dualsense-bt-write"
