/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/video/aml_adaptive.h"
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
int main(void) {
  AmlAdaptivePacing s;
  aml_adaptive_init(&s, 100);
  assert(s.limit == 1);
  assert(aml_adaptive_input_eligible(16667, 1, 27000));
  assert(aml_adaptive_input_late(27000, 16667, 1));
  assert(!aml_adaptive_input_late(27000, 33333, 1)); /* 30 fps source */
  assert(!aml_adaptive_input_late(27000, 16667, 2)); /* missing frame */
  assert(!aml_adaptive_input_late(20000, 16667, 1)); /* below threshold */
  assert(!aml_adaptive_input_eligible(0, 1, 27000));
  assert(!aml_adaptive_input_eligible(16667, 2, 27000));
  assert(!aml_adaptive_input_eligible(16000, 1, 300000));
  assert(aml_adaptive_update(&s, 2100, 100, 1, true, true)==1);
  assert(aml_adaptive_update(&s, 4200, 100, 12, false, false)==1);
  assert(aml_adaptive_update(&s, 6300, 100, 12, true, false)==2);
  assert(aml_adaptive_update(&s, 8400, 100, 12, true, false)==2);
  assert(aml_adaptive_update(&s, 10500, 100, 12, true, false)==3);
  assert(s.raises==2);
  for (uint64_t t=12600;t<=18900;t+=2100)
    assert(aml_adaptive_update(&s,t,100,0,false,false)==3);
  assert(aml_adaptive_update(&s,21000,100,0,false,false)==2);
  assert(aml_adaptive_update(&s,23100,100,0,false,false)==2);
  assert(aml_adaptive_update(&s,25200,100,0,false,false)==2);
  assert(aml_adaptive_update(&s,27300,100,0,false,false)==1);
  assert(s.lowers==2);
  aml_adaptive_init(&s,100);
  assert(aml_adaptive_update(&s,2200,100,100,false,false)==1);
  aml_adaptive_init(&s,100);
  assert(aml_adaptive_update(&s,2200,100,0,true,true)==1);
  aml_adaptive_init(&s,100);
  assert(aml_adaptive_update(&s,2200,10,10,true,true)==1);
  aml_adaptive_init(&s,100);
  assert(aml_adaptive_update(&s,2200,100,8,true,true)==1);
  aml_adaptive_init(&s,100);
  assert(aml_adaptive_update(&s,2200,100,10,true,true)==2);
  assert(aml_adaptive_update(&s,1000,100,10,true,true)==1);
  assert(aml_adaptive_update(&s,7001,100,10,true,true)==1);
  puts("PASS: adaptive pacing qualification, ramp, release, reset and jitter filtering");
}
