"""Verify all four pacing modes in the real AML decoder pump."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AmlPacingModesTests(unittest.TestCase):
    def test_aml_modes_select_direct_or_pump_with_runtime_limit(self):
        header = (ROOT / 'src/video/aml_pacing.h').read_text()
        aml = (ROOT / 'src/video/aml.c').read_text()
        self.assertIn('aml_pacing_wait_limit(const char *mode)', header)
        self.assertIn('!strcmp(mode, "low-latency") || !strcmp(mode, "adaptive")', header)
        self.assertIn('!strcmp(mode, "balanced")) return 3U', header)
        self.assertIn('pacing_max_waiting = aml_pacing_wait_limit(pacing)', aml)
        self.assertIn('balanced_pacing = pacing_max_waiting > 0', aml)
        self.assertIn('unsigned int max_waiting = pacing_max_waiting', aml)
        self.assertIn('max_waiting = aml_adaptive_update(&adaptive', aml)
        self.assertIn('const unsigned int previous = max_waiting', aml)
        self.assertIn('adaptive_pacing = aml_pacing_is_adaptive(pacing)', aml)
        self.assertIn('aml_adaptive_waiting(void)', aml)
        self.assertIn('while (count > max_waiting)', aml)
        self.assertIn('FRAME_BASE_PATH_TUNNEL_MODE', aml)
        self.assertIn('FRAME_BASE_PATH_AMLVIDEO_AMVIDEO', aml)
        self.assertNotIn('AML_PACING_MAX_WAITING 3U', aml)
        self.assertIn('aml_adaptive_input_eligible(source_gap, step, (uint32_t)gap)', aml)
        self.assertIn('aml_adaptive_input_late((uint32_t)gap, source_gap, step)', aml)
        self.assertIn('adaptive_last_enqueue_us', aml)
        self.assertIn('adaptive_last_pts_us', aml)
        self.assertIn('adaptive_input_eligible_count', aml)

    def test_experimental_vfm_uses_its_own_existing_queue(self):
        vfm = (ROOT / 'src/video/aml_vfm.c').read_text()
        self.assertIn('if (pacing && strcmp(pacing, "balanced") == 0)', vfm)
        self.assertIn('start.pending_frames = 2', vfm)
        self.assertIn('strcmp(pacing, "low-latency") == 0', vfm)
        self.assertIn('start.pending_frames = 1', vfm)
        self.assertIn('Adaptive requires AMLVIDEO', vfm)
        self.assertNotIn('aml_adaptive_update(', vfm)


if __name__ == '__main__':
    unittest.main()
