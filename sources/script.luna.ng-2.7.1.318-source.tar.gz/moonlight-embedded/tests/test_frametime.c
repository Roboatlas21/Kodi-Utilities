/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/osd/frametime.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void) {
  OsdFtCapture c; OsdFtView v; osd_ft_reset(&c);
  osd_ft_snapshot(&c, 0, 60, &v);
  assert(v.count==0 && v.requested_fps==60);
  osd_ft_record(&c,1000,1200);
  osd_ft_record(&c,17667,17867);
  osd_ft_record(&c,34333,34533);
  osd_ft_snapshot(&c,35000,60,&v);
  assert(v.count==3 && v.callback_gap_us[0]==0);
  assert(v.callback_gap_us[1]==16667 && v.return_gap_us[2]==16666);
  assert(v.execution_us[2]==200 && !v.stale);
  osd_ft_snapshot(&c,600000,60,&v); assert(v.stale);
  for(int i=0;i<500;++i)
    osd_ft_record(&c,(uint32_t)(100000+i*16667),(uint32_t)(100200+i*16667));
  osd_ft_snapshot(&c,8500000,120,&v);
  assert(v.count==OSD_FT_SAMPLES && v.requested_fps==120);
  osd_ft_reset(&c);
  osd_ft_record(&c,UINT32_MAX-1000,UINT32_MAX-900);
  osd_ft_record(&c,500,700);
  osd_ft_snapshot(&c,800,60,&v);
  assert(v.callback_gap_us[1]==1501 && v.return_gap_us[1]==1601);
  enum {W=155,H=105}; uint32_t pad[W*H+2];
  memset(pad,0,sizeof(pad));pad[0]=0x12345678;pad[W*H+1]=0x87654321;
  osd_ft_plot(&v,pad+1,W,W,H,4,5,142,90);
  assert(pad[0]==0x12345678 && pad[W*H+1]==0x87654321);
  unsigned touched=0;for(unsigned j=1;j<=W*H;++j)touched+=pad[j]!=0;
  assert(touched>0);
  osd_ft_plot(&v,pad+1,W,W,H,-1,0,200,200);
  assert(pad[0]==0x12345678 && pad[W*H+1]==0x87654321);

  OsdFtSummary summary;
  OsdFtAxes axes;
  osd_ft_summarize(&v,&summary);
  osd_ft_axes(&v,&summary,&axes);
  assert(summary.submit.samples==2);
  assert(summary.submit.p95_us==200 && summary.submit.p99_us==200);
  assert(axes.arrival_min_us<summary.target_us &&
         axes.arrival_max_us>summary.target_us);
  osd_ft_reset(&c);
  osd_ft_record_frame(&c,1000,1200,100);
  osd_ft_record_frame(&c,17667,17867,101);
  osd_ft_record_frame(&c,34333,34533,105);
  osd_ft_snapshot(&c,35000,60,&v);
  osd_ft_summarize(&v,&summary);
  assert(summary.arrival.samples==2 && summary.arrival.mean_us==16667);
  assert(summary.arrival.p95_us==16667 && summary.arrival.p99_us==16667);
  assert(summary.gap_events==1 && summary.missing_frames==3);
  assert(v.missing_frames[2]==3 && v.position[2]==2 && v.span==3);
  char in[128],sub[128];
  osd_ft_caption(&v,in,sizeof(in),sub,sizeof(sub));
  assert(strstr(in,"GAP:1 LOST:3"));
  assert(strstr(sub,"SUB A0.2"));
  osd_ft_record_frame(&c,50000,80000,106);
  osd_ft_snapshot(&c,82000,120,&v);
  osd_ft_summarize(&v,&summary);
  assert(summary.submit.over_one_frame && summary.submit.over_two_frames);
  assert(summary.submit.p99_us==30000);
  osd_ft_reset(&c);
  osd_ft_record_frame(&c,1000,1100,UINT32_MAX-1);
  osd_ft_record_frame(&c,17667,17767,0);
  osd_ft_snapshot(&c,18000,60,&v);
  osd_ft_summarize(&v,&summary);
  assert(summary.missing_frames==1);
  puts("PASS: frametime capture, statistics, gaps, percentiles and plot bounds");
  return 0;
}
