"""Check the native config lookup failure and final-segment guards."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).resolve().parents[1] / "src/config.c").read_text()

class ConfigLookupSafetyTests(unittest.TestCase):
    def test_malloc_and_passwd_checked_before_use(self):
        find = SOURCE.split('static char *get_path_with_policy(', 1)[1].split(
            'static int parse_stream_number(', 1)[0]
        self.assertIn('if (!dirs)', find)
        self.assertIn('if (!pw || !pw->pw_dir', find)
        self.assertIn('if (!end) break;', find)
        self.assertLess(find.index('if (!dirs)'), find.index('snprintf(dirs,'))
        self.assertIn('get_existing_config_path(', find)
        self.assertIn('lstat(path, &found)', SOURCE)

    def test_stream_numbers_use_checked_parser_before_auto_bitrate(self):
        for option in ('width', 'height', 'fps', 'packetsize', 'bitrate'):
            self.assertIn('parse_stream_number("%s", value,' % option, SOURCE)
        self.assertNotIn('config->stream.width = atoi(value)', SOURCE)
        self.assertNotIn('config->stream.height = atoi(value)', SOURCE)
        self.assertNotIn('config->stream.fps = atoi(value)', SOURCE)
        validated = SOURCE.index('if (!moonlight_stream_numbers_valid(')
        pixel_count = SOURCE.index('const uint64_t pixels = moonlight_stream_pixel_count(')
        self.assertLess(validated, pixel_count)
        self.assertNotIn('config->stream.width * config->stream.height <=', SOURCE)

    def test_explicit_pin_port_and_rotation_are_bounded(self):
        self.assertIn('parse_stream_number("rotation", value, 0, 270)', SOURCE)
        self.assertIn('parse_stream_number("pairing PIN", value, 1, 9999)', SOURCE)
        self.assertIn('parse_stream_number("host port", value, 1, 65535)', SOURCE)
        self.assertIn('config->rotate != 90', SOURCE)
        self.assertIn('config->rotate != 180', SOURCE)
        self.assertIn('config->rotate != 270', SOURCE)
        self.assertNotIn('config->rotate = atoi(value)', SOURCE)
        self.assertNotIn('config->pin = atoi(value)', SOURCE)
        self.assertNotIn('config->port = atoi(value)', SOURCE)

    def test_forget_host_trust_bypasses_broken_optional_host_config(self):
        source = (Path(__file__).resolve().parents[1] / "src/main.c").read_text()
        start = source.index('int main(int argc, char* argv[])')
        native = source[start:]
        reset = native.index('if (strcmp(config.action, "forget-server-cert") == 0)')
        overlay = native.index('char *host_config_file = moonlight_host_config_path')
        connect = native.index('if ((ret = gs_init(')
        self.assertLess(reset, overlay)
        self.assertLess(reset, connect)
        self.assertIn('config.command_line_address_set', native[:overlay])
        self.assertIn('gs_forget_server_pin_at_port(config.key_dir, config.address, config.port)', native[:overlay])

    def test_credentials_require_known_home(self):
        self.assertIn("Cannot determine credential directory", SOURCE)
        self.assertIn("exit(EXIT_FAILURE);", SOURCE)

if __name__ == "__main__":
    unittest.main()
