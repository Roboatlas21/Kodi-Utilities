"""Inject allocation/ALSA errors into the actual initializer without audio hardware.

Only the external APIs are simulated. The initializer and its error path are
extracted unchanged from alsa.c; each acquired resource must be released even
when common-c returns immediately on init failure without calling cleanup.
"""
import os
from pathlib import Path
import re
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AlsaInitializationTests(unittest.TestCase):
    def test_every_initialization_failure_releases_partial_state(self):
        source = (ROOT / 'src/audio/alsa.c').read_text()
        start = source.index('static int alsa_renderer_init(')
        end = source.index('\nstatic void alsa_renderer_cleanup', start)
        initializer = source[start:end]
        stats = re.search(r'typedef struct \{.*?\} AlsaRuntimeStats;', source, re.S)[0]
        check = next(line for line in source.splitlines() if line.startswith('#define CHECK_RETURN'))
        harness = r'''
#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "alsa_pending_queue.h"
#include "alsa_queue_pressure.h"
#include "alsa_resync.h"
#include "alsa_bounded_write.h"
#include "diagnostics.h"
#include "alsa_rate.h"
enum { SND_CHMAP_FL, SND_CHMAP_FR, SND_CHMAP_FC, SND_CHMAP_LFE,
       SND_CHMAP_RL, SND_CHMAP_RR, SND_CHMAP_SL, SND_CHMAP_SR };
#define SND_CHMAP_POSITION_MASK 0xffff
#define snd_pcm_get_chmap(handle) ((snd_pcm_chmap_t *)0)
typedef struct { unsigned channels; unsigned pos[8]; } snd_pcm_chmap_t;
typedef int OpusMSDecoder, snd_pcm_t, snd_pcm_hw_params_t, snd_pcm_sw_params_t;
typedef unsigned long snd_pcm_uframes_t;
typedef struct { int sampleRate, channelCount, streams, coupledStreams,
    samplesPerFrame; unsigned char mapping[8]; } Config;
typedef Config *POPUS_MULTISTREAM_CONFIGURATION;
#define AUDIO_CONFIGURATION_MAX_CHANNEL_COUNT 8
#define OPUS_OK 0
static snd_pcm_t *handle;
static OpusMSDecoder *decoder;
static short *pcmBuffer;
static int samplesPerFrame;
static unsigned char alsaPendingStorage[960 * AUDIO_CONFIGURATION_MAX_CHANNEL_COUNT * sizeof(short)];
static AlsaPendingQueue alsaPending;
static bool alsaResyncEnabled;
static AlsaResyncConfig alsaResyncConfig;
static AlsaResyncStats alsaResyncStats;
static AudioDiagnostics audioDiagnostics;
static bool audioDiagnosticsEnabled;
/* Keep the initializer's real Opus diagnostic state in this isolated C harness.
 * It resets these counters on each init; no audio hardware is required. */
static uint64_t last_opus_error_log_us;
static unsigned int suppressed_opus_error_logs;
static bool logged_opus_error;
static uint64_t last_decoded_packet_us;
/* The extracted initializer only selects an ops table; no PCM writes occur.
 * Supply the real table type and distinct sentinels without pulling in ALSA. */
static const AlsaBoundedOps bounded_ops_diagnostics = {0};
static const AlsaBoundedOps bounded_ops_normal = {0};
static const AlsaBoundedOps *active_bounded_ops;
static int fail_at, calls, live, optional_failed;
static int step(void) { return ++calls == fail_at ? -12 : 0; }
static snd_pcm_uframes_t observed_start_threshold, observed_avail_min;
static int reject_packet_avail_min, reject_commit_avail_min;
static int apply_start_threshold(snd_pcm_uframes_t threshold) {
    observed_start_threshold = threshold;
    return step();
}
static int apply_avail_min(snd_pcm_uframes_t frames) {
    observed_avail_min = frames;
    if (reject_packet_avail_min && frames < 960) return -EINVAL;
    return step();
}
static int apply_sw_params(void) {
    if (reject_commit_avail_min && observed_avail_min < 960) return -EINVAL;
    return step();
}
static int optional_step(void) {
    int rc = step(); if (rc) optional_failed = 1; return rc;
}
static void *acquire(size_t size) {
    if (step()) return NULL;
    void *p = calloc(1, size); assert(p); ++live; return p;
}
static void release(void *p) { if (p) { assert(live > 0); --live; free(p); } }
static int allocate(void **p) { *p = acquire(sizeof(int)); return *p ? 0 : -12; }
static OpusMSDecoder *create(int *rc) {
    OpusMSDecoder *p = acquire(sizeof(int)); *rc = p ? 0 : -7; return p;
}
#define malloc acquire
#define free release
#define opus_multistream_decoder_create(a,b,c,d,e,rc) create(rc)
#define opus_multistream_decoder_destroy release
#define snd_pcm_open(p,...) allocate((void **)(p))
#define snd_pcm_close(p) (release(p), 0)
#define snd_pcm_hw_params_malloc(p) allocate((void **)(p))
#define snd_pcm_sw_params_malloc(p) allocate((void **)(p))
#define snd_pcm_hw_params_free release
#define snd_pcm_sw_params_free release
#define snd_pcm_hw_params_any(...) step()
#define snd_pcm_hw_params_set_access(...) step()
#define snd_pcm_hw_params_set_format(...) step()
#define snd_pcm_hw_params_set_rate_near(...) step()
#define snd_pcm_hw_params_set_channels(...) step()
#define snd_pcm_hw_params_set_period_size_near(...) step()
#define snd_pcm_hw_params_set_buffer_size_near(...) step()
#define snd_pcm_hw_params(...) step()
#define snd_pcm_hw_params_get_buffer_size(...) optional_step()
#define snd_pcm_hw_params_get_period_size(...) optional_step()
#define snd_pcm_sw_params_current(...) step()
#define snd_pcm_sw_params_set_avail_min(a,b,frames) apply_avail_min(frames)
#define snd_pcm_sw_params_set_start_threshold(handle, params, value) apply_start_threshold(value)
#define snd_pcm_sw_params(...) apply_sw_params()
#define snd_pcm_sw_params_get_start_threshold(...) optional_step()
#define snd_pcm_sw_params_get_avail_min(...) optional_step()
#define snd_pcm_prepare(...) step()
'''
        harness += '\n' + stats + '\nstatic AlsaRuntimeStats alsaStats;\nstatic AlsaQueuePressureLog alsaPressureLog;\n' + check + '\n' + initializer
        harness += r'''
static void successful_cleanup(void) {
    release(handle); handle = NULL;
    release(decoder); decoder = NULL;
    release(pcmBuffer); pcmBuffer = NULL;
}
int main(void) {
    Config config = {48000, 2, 1, 1, 240, {0, 1}};
    unsetenv("MOONLIGHT_ALSA_RESYNC");
    for (int enabled = 0; enabled <= 1; ++enabled) {
    setenv("MOONLIGHT_STREAM_DIAGNOSTICS", enabled ? "1" : "0", 1);
    last_opus_error_log_us = 5000000;
    suppressed_opus_error_logs = 17;
    logged_opus_error = true;
    calls = fail_at = 0;
    assert(alsa_renderer_init(0, &config, NULL, 0) == 0);
    assert(last_opus_error_log_us == 0);
    assert(suppressed_opus_error_logs == 0);
    assert(!logged_opus_error);
    assert(active_bounded_ops == (enabled ? &bounded_ops_diagnostics : &bounded_ops_normal));
    assert(observed_start_threshold == 1920); /* two 960-frame ALSA periods */
    assert(observed_avail_min == 240); /* one decoded 5-ms packet */
    assert(alsaPending.capacity_frames == 960 && alsaPending.queued_frames == 0);
    successful_cleanup();
    /* Some drivers reject packet-sized readiness at set or commit time. */
    reject_packet_avail_min = 1;
    calls = fail_at = 0;
    assert(alsa_renderer_init(0, &config, NULL, 0) == 0);
    assert(observed_avail_min == 960);
    successful_cleanup();
    reject_packet_avail_min = 0;
    reject_commit_avail_min = 1;
    calls = fail_at = 0;
    assert(alsa_renderer_init(0, &config, NULL, 0) == 0);
    assert(observed_avail_min == 960);
    successful_cleanup();
    reject_commit_avail_min = 0;
    calls = fail_at = 0;
    assert(alsa_renderer_init(0, &config, NULL, 0) == 0);
    int total = calls;
    assert(live == 3);
    successful_cleanup();
    for (int n = 1; n <= total; ++n) {
        calls = optional_failed = 0; fail_at = n;
        int result = alsa_renderer_init(0, &config, NULL, 0);
        assert(result < 0 || optional_failed);
        if (result == 0) successful_cleanup(); /* Optional geometry reads. */
        else assert(audioDiagnostics.active == 0);
        assert(!handle && !decoder && !pcmBuffer && live == 0);
        calls = fail_at = 0;
        assert(alsa_renderer_init(0, &config, NULL, 0) == 0);
        successful_cleanup(); /* Retrying after a failure must also work. */
        assert(live == 0);
    }
    printf("ALSA init: %d injected failure points and retries passed (diagnostics=%d)\n", total, enabled);
    }
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            (path / 'test.c').write_text(harness)
            command = shlex.split(os.environ.get('CC', 'cc'))
            command += ['-std=c99', '-Wall', '-Wextra', '-Werror',
                        '-Wno-unused-parameter', '-Wno-unused-but-set-variable',
                        '-Wno-unused-value', '-I' + str(ROOT / 'src/audio'),
                        str(path / 'test.c'), '-o', str(path / 'test')]
            subprocess.run(command, check=True)
            subprocess.run([str(path / 'test')], check=True, capture_output=True)


    def test_idle_gap_pcm_drop_policy_and_xrun_rearm_are_characterized(self):
        # Test the actual native function with only ALSA and queue primitives
        # stubbed. This documents the non-XRUN discard case for the next
        # on-device audio-pop diagnosis without changing playback behaviour.
        source = (ROOT / 'src/audio/alsa.c').read_text()
        start = source.index('static void alsa_rearm_if_xrun_after_idle(')
        end = source.index('static void alsa_renderer_decode_and_play_sample(', start)
        original = source[start:end]
        harness = r'''
#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "alsa_pending_queue.h"
typedef struct {
  unsigned sample_rate;
  unsigned long buffer_frames;
  uint64_t dropped_frames;
  unsigned failed_packets, idle_xrun_rearms;
} MockAlsaStats;
static MockAlsaStats alsaStats;
static unsigned char pending_storage[1920];
static AlsaPendingQueue alsaPending;
static uint64_t last_decoded_packet_us;
static int mock_state, prepare_calls;
static void *handle;
#define SND_PCM_STATE_XRUN 1
static int snd_pcm_state(void *unused) { (void)unused; return mock_state; }
static int snd_pcm_prepare(void *unused) { (void)unused; ++prepare_calls; return 0; }
'''
        harness += '\n' + original + r'''
int main(void) {
  alsaStats.sample_rate = 48000;
  alsaStats.buffer_frames = 2880; /* 60ms */
  last_decoded_packet_us = 1000000;
  assert(alsa_pending_queue_configure(&alsaPending, pending_storage,
                                      sizeof(pending_storage), 960, 2));
  alsaPending.queued_frames = 240;
  mock_state = 0; /* healthy RUNNING/SETUP-like state */
  alsa_rearm_if_xrun_after_idle(1020000);
  assert(alsaPending.queued_frames == 240 && alsaStats.dropped_frames == 0);
  alsa_rearm_if_xrun_after_idle(1070000);
  /* Current policy discards stale pending PCM even before observing XRUN. */
  assert(alsaPending.queued_frames == 0 && alsaStats.dropped_frames == 240);
  assert(prepare_calls == 0 && alsaStats.idle_xrun_rearms == 0);
  alsaPending.queued_frames = 120;
  mock_state = SND_PCM_STATE_XRUN;
  alsa_rearm_if_xrun_after_idle(1070000);
  assert(alsaPending.queued_frames == 0 && alsaStats.dropped_frames == 360);
  assert(prepare_calls == 1 && alsaStats.idle_xrun_rearms == 1);
  puts("ALSA idle-gap drop and XRUN rearm behavior characterized");
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            src = path / 'idle-gap.c'
            src.write_text(harness)
            command = shlex.split(os.environ.get('CC', 'cc'))
            command += ['-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        '-I' + str(ROOT / 'src/audio'), str(src),
                        '-o', str(path / 'idle-gap')]
            subprocess.run(command, check=True, capture_output=True, text=True)
            subprocess.run([str(path / 'idle-gap')], check=True,
                           capture_output=True, text=True)


if __name__ == '__main__':
    unittest.main()
