"""Exercise the production USB render loop with in-memory ALSA writes."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class UsbTimingTests(unittest.TestCase):
    def test_short_packets_and_staggered_planes_preserve_frame_count(self):
        source = (ROOT / 'src/input/dualsense_pcm.c').read_text()
        rings = source.split('static void ring_clear', 1)[1].split('static bool contains_nonzero', 1)[0]
        wake = source.split('static void next_wake', 1)[1].split('static bool waited', 1)[0]
        worker = source.split('static void *run_usb', 1)[1].split('\n#endif', 1)[0]
        harness = r'''
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#define ML_DS_RING_FRAMES 4096U
#define ML_DS_USB_QUANTUM 240U
typedef struct { uint8_t data[4096*4]; unsigned read,length; } pcm_ring;
typedef struct {
  pthread_mutex_t lock; pthread_cond_t wake; bool stop,failed;
  pcm_ring actuator,speaker; void *usb_pcm;
} ml_ds_audio;
typedef struct {
  unsigned remaining; int last_error;
  unsigned recovery_attempts,successful_recoveries;
} AlsaBoundedResult;
static int ds_usb_pcm_ops;
static unsigned calls, frames_written, nonzero_frames, mode;
static ml_ds_audio a;
''' + 'static void ring_clear' + rings + 'static void next_wake' + wake + r'''
static AlsaBoundedResult alsa_bounded_write(void *ops,void *pcm,
    const int16_t *out,unsigned frames,unsigned stride) {
  (void)ops;(void)pcm; assert(stride == 8);
  calls++; frames_written+=frames;
  for(unsigned i=0;i<frames;i++) {
    if(out[i*4])nonzero_frames++;
    if(mode==1) assert(out[i*4] && out[i*4+2]);
  }
  if(mode==2 && calls<60) {
    uint8_t data[240*4];memset(data,1,sizeof(data));
    ring_add(&a.speaker,data,240);
    struct timespec work={0,2000000};nanosleep(&work,0);
  } else if(mode==0 && calls==1) {
    uint8_t data[120*4];memset(data,1,sizeof(data));
    ring_add(&a.speaker,data,120);
  } else a.stop=true;
  return (AlsaBoundedResult){0};
}
''' + 'static void *run_usb' + worker + r'''
static void *speaker_arrival(void *unused) {
  (void)unused;
  struct timespec pause={0,1000000}; nanosleep(&pause,0);
  uint8_t data[120*4];memset(data,1,sizeof(data));
  pthread_mutex_lock(&a.lock);
  ring_add(&a.speaker,data,120);pthread_cond_signal(&a.wake);
  pthread_mutex_unlock(&a.lock);return 0;
}
int main(void) {
  pthread_mutex_init(&a.lock,0);
  pthread_condattr_t attr;pthread_condattr_init(&attr);
  pthread_condattr_setclock(&attr,CLOCK_MONOTONIC);
  pthread_cond_init(&a.wake,&attr);pthread_condattr_destroy(&attr);
  uint8_t data[120*4];memset(data,1,sizeof(data));
  ring_add(&a.speaker,data,120);run_usb(&a);
  assert(calls==2 && frames_written==240 && nonzero_frames==240);
  mode=1;calls=frames_written=nonzero_frames=0;a.stop=a.failed=false;
  ring_clear(&a.speaker);ring_clear(&a.actuator);
  ring_add(&a.actuator,data,120);
  pthread_t producer;assert(!pthread_create(&producer,0,speaker_arrival,0));
  run_usb(&a);pthread_join(producer,0);
  assert(calls==1 && frames_written==120 && nonzero_frames==120);
  mode=2;calls=frames_written=nonzero_frames=0;a.stop=a.failed=false;
  ring_clear(&a.speaker);ring_clear(&a.actuator);
  uint8_t full[240*4];memset(full,1,sizeof(full));ring_add(&a.speaker,full,240);
  struct timespec begin,end;clock_gettime(CLOCK_MONOTONIC,&begin);
  run_usb(&a);clock_gettime(CLOCK_MONOTONIC,&end);
  long elapsed=(end.tv_sec-begin.tv_sec)*1000000000L+end.tv_nsec-begin.tv_nsec;
  assert(calls==60 && frames_written==14400);
  /* 300ms of samples: simulated write overhead must not add 120ms. */
  assert(elapsed < 390000000L);
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'timing.c'
            path.write_text(harness)
            binary = Path(folder) / 'timing'
            subprocess.run(['cc', '-std=gnu99', '-Wall', '-Wextra', '-Werror',
                            '-pthread', str(path), '-o', str(binary)], check=True)
            subprocess.run([str(binary)], check=True, timeout=5)
