/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Exercise actual evdev lookup, rumble and remove functions in two threads.
 * The feedback ioctl pauses while the event loop tries to unplug. */
#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <linux/input.h>
#include <libevdev/libevdev.h>

static pthread_mutex_t test_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t test_cond = PTHREAD_COND_INITIALIZER;
static bool feedback_entered, release_feedback, remover_entered, remover_done;

int __wrap_ioctl(int fd, unsigned long request, ...) {
  (void)fd;
  if (request == EVIOCSFF) {
    va_list args;
    va_start(args, request);
    struct ff_effect *effect = va_arg(args, struct ff_effect *);
    va_end(args);
    effect->id = 7;
    pthread_mutex_lock(&test_mutex);
    feedback_entered = true;
    pthread_cond_broadcast(&test_cond);
    while (!release_feedback)
      pthread_cond_wait(&test_cond, &test_mutex);
    pthread_mutex_unlock(&test_mutex);
  }
  return 0;
}

#include "../src/input/evdev.c"
bool sc26_owns_event_fd(int fd) {(void)fd;return false;}
bool sc26_rumble_host(unsigned short id,unsigned short lo,unsigned short hi) {
  (void)id;(void)lo;(void)hi;return false;
}
bool sc26_motion_host(unsigned short id,uint8_t type,uint16_t rate) {
  (void)id;(void)type;(void)rate;return false;
}

/* This test compiles evdev.c directly, without its optional DualSense module.
 * Keep the mock bridge inert and verify the original rumble lifetime behavior. */
moonlight_dualsense *dualsense_attach(int fd, int vendor, int product) {
  (void)fd; (void)vendor; (void)product; return NULL;
}
void dualsense_detach(moonlight_dualsense *d) { (void)d; }
bool dualsense_cleanup_pending_for(int fd) { (void)fd; return false; }
bool dualsense_cleanup_pending(void) { return false; }
void dualsense_cleanup_shutdown(void) { }
bool dualsense_hid_healthy(const moonlight_dualsense *d) { (void)d; return false; }
int dualsense_led_try(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  (void)d; (void)r; (void)g; (void)b; return ML_DS_SEND_FAILED;
}
int dualsense_adaptive_try(moonlight_dualsense *d, uint8_t flags, uint8_t lt,
                           uint8_t rt, const uint8_t *left, const uint8_t *right) {
  (void)d; (void)flags; (void)lt; (void)rt; (void)left; (void)right;
  return ML_DS_SEND_FAILED;
}
bool udev_input_identity_for_fd(int fd, char *out, size_t cap) {
  (void)fd; if (cap) out[0] = 0; return false;
}
void udev_schedule_input_retry(const char *node, unsigned long long rdev,
                                const char *identity) {
  (void)node; (void)rdev; (void)identity;
}
void udev_cancel_input_retry(const char *node, unsigned long long rdev) {
  (void)node; (void)rdev;
}
void udev_schedule_advanced_retry(void) { }
void dualsense_set_player(moonlight_dualsense *d, short id) { (void)d; (void)id; }
unsigned short dualsense_capabilities(const moonlight_dualsense *d) { (void)d; return 0; }
void dualsense_motion_request(moonlight_dualsense *d, uint8_t type, uint16_t rate) {
  (void)d; (void)type; (void)rate;
}
void dualsense_led(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  (void)d; (void)r; (void)g; (void)b;
}
void dualsense_adaptive(moonlight_dualsense *d, uint8_t flags, uint8_t lt, uint8_t rt,
                        const uint8_t *left, const uint8_t *right) {
  (void)d; (void)flags; (void)lt; (void)rt; (void)left; (void)right;
}
uint64_t dualsense_speaker_owner(const moonlight_dualsense *d) { (void)d; return 0; }
bool dualsense_waveform_active(moonlight_dualsense *d) { (void)d; return false; }
void dualsense_receive_haptics(moonlight_dualsense *d, uint32_t s, const uint8_t *p, uint16_t n) {
  (void)d; (void)s; (void)p; (void)n;
}
void dualsense_receive_speaker(moonlight_dualsense *d, uint64_t owner, uint32_t g,
                                uint32_t s, uint64_t pos, uint16_t fl,
                                const uint8_t *pcm, uint16_t n) {
  (void)d; (void)owner; (void)g; (void)s; (void)pos; (void)fl; (void)pcm; (void)n;
}
int LiSendControllerSpeakerArrivalEvent(uint8_t number, uint16_t mask, uint8_t type,
                                      uint32_t flags, uint16_t caps, uint64_t owner) {
  (void)number; (void)mask; (void)type; (void)flags; (void)caps; (void)owner; return 0;
}

int LiSendKeyboardEvent(short code, char action, char modifiers) {
  (void)code; (void)action; (void)modifiers;
  return 0;
}
int LiSendMouseButtonEvent(char action, int button) {
  (void)action; (void)button;
  return 0;
}
void loop_remove_fd(int fd) { (void)fd; }
int LiSendMultiControllerEvent(short id, short mask, int buttons,
  unsigned char lt, unsigned char rt, short lx, short ly, short rx, short ry) {
  (void)id;(void)mask;(void)buttons;(void)lt;(void)rt;
  (void)lx;(void)ly;(void)rx;(void)ry;
  return 0;
}
static void *feedback(void *ignored) {
  (void)ignored;
  evdev_rumble(0, 32767, 10000);
  return NULL;
}
static void *disconnect(void *ignored) {
  (void)ignored;
  pthread_mutex_lock(&test_mutex);
  remover_entered = true;
  pthread_cond_broadcast(&test_cond);
  pthread_mutex_unlock(&test_mutex);
  evdev_remove(0);
  pthread_mutex_lock(&test_mutex);
  remover_done = true;
  pthread_cond_broadcast(&test_cond);
  pthread_mutex_unlock(&test_mutex);
  return NULL;
}

int main(void) {
  int pipefd[2];
  assert(pipe(pipefd) == 0);
  struct input_device *device = calloc(1, sizeof(*device));
  assert(device);
  device->dev = libevdev_new();
  assert(device->dev);
  libevdev_set_name(device->dev, "ASan mocked controller");
  /* Mirror a real force-feedback-capable gamepad. Rumble now intentionally
   * skips devices without EV_FF + FF_RUMBLE. Without this the fixture waits
   * forever for a callback that correctly never reaches EVIOCSFF.
   */
  assert(libevdev_enable_event_type(device->dev, EV_FF) == 0);
  assert(libevdev_enable_event_code(device->dev, EV_FF, FF_RUMBLE, NULL) == 0);
  device->controllerId = 0;
  device->haptic_effect_id = -1;
  assert(pthread_mutex_init(&device->ff_mutex, NULL) == 0);
  assert(pthread_cond_init(&device->ff_wake, NULL) == 0);
  device->fd = pipefd[1];
  assert(input_slots_append(&devices, &numDevices, device));
  assignedControllerIds = 1;
  pthread_t callback, unplug;
  assert(pthread_create(&callback, NULL, feedback, NULL) == 0);
  pthread_mutex_lock(&test_mutex);
  while (!feedback_entered)
    pthread_cond_wait(&test_cond, &test_mutex);
  pthread_mutex_unlock(&test_mutex);
  /* Callback must return while the independent I/O worker is still blocked. */
  struct timespec callback_deadline;
  clock_gettime(CLOCK_REALTIME, &callback_deadline);
  callback_deadline.tv_sec += 2;
  assert(pthread_timedjoin_np(callback, NULL, &callback_deadline) == 0);
  assert(pthread_create(&unplug, NULL, disconnect, NULL) == 0);
  pthread_mutex_lock(&test_mutex);
  while (!remover_entered)
    pthread_cond_wait(&test_cond, &test_mutex);
  pthread_mutex_unlock(&test_mutex);
  /* The stuck EVIOCSFF is deliberately NOT released yet. Device teardown
   * must finish anyway; the callback owns a duplicate fd and reference. */
  struct timespec deadline;
  assert(clock_gettime(CLOCK_REALTIME, &deadline) == 0);
  deadline.tv_sec += 2;
  pthread_mutex_lock(&test_mutex);
  while (!remover_done) {
    int status = pthread_cond_timedwait(&test_cond, &test_mutex, &deadline);
    assert(status == 0); /* Detach must not wait for a blocked rumble ioctl. */
  }
  pthread_mutex_unlock(&test_mutex);
  pthread_join(unplug, NULL);
  assert(numDevices == 0);
  pthread_mutex_lock(&test_mutex);
  release_feedback = true;
  pthread_cond_broadcast(&test_cond);
  pthread_mutex_unlock(&test_mutex);

  assert(numDevices == 0);
  /* Late feedback for an unplugged controller must be harmless. */
  evdev_rumble(0, 1000, 1000);
  free(devices);
  close(pipefd[0]);
  puts("PASS: failed controller detaches while FF ioctl is blocked; callback releases its pinned lifetime");
  return 0;
}
