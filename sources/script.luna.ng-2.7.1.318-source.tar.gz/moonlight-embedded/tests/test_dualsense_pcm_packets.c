/* SPDX-License-Identifier: GPL-3.0-or-later
 * Protocol-derived Bluetooth waveform conversion smoke tests, no hardware.
 */
#include "../src/input/saxense_packet.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
  uint8_t input[ML_SAX_SOURCE_FRAMES * 4], pcm[ML_SAX_PCM_BYTES], report[ML_SAX_REPORT_BYTES];
  memset(input, 0, sizeof(input));
  ml_sax_downsample(input, pcm);
  for (unsigned i=0;i<sizeof(pcm);++i) assert(pcm[i]==0);
  /* Constant +16384 in left and -16384 in right yields +64/-64 in S8. */
  for (unsigned i=0;i<ML_SAX_SOURCE_FRAMES;++i) {
    input[i*4] = 0; input[i*4+1] = 0x40;
    input[i*4+2] = 0; input[i*4+3] = 0xc0;
  }
  ml_sax_downsample(input, pcm);
  for (unsigned i=0;i<32;++i) {
    assert(pcm[2*i]==64 && pcm[2*i+1]==(uint8_t)(int8_t)-64);
  }
  ml_sax_packet(report, 7, pcm);
  assert(report[0]==0x32 && report[10]==7);
  assert(report[11]==0x92 && report[12]==64);
  assert(memcmp(report+13, pcm, 64)==0);
  /* No heap allocation, uninitialized bytes or nondeterministic CRC. */
  uint8_t repeated[ML_SAX_REPORT_BYTES];
  ml_sax_packet(repeated, 7, pcm);
  assert(memcmp(report, repeated, sizeof(report))==0);
  /* 1..511 frames must remain playable as a zero-padded final packet.
   * Once it is consumed, emit exactly one explicit silence report. */
  for (unsigned count = 1; count < ML_SAX_SOURCE_FRAMES; ++count) {
    uint8_t partial[ML_SAX_SOURCE_FRAMES * 4] = {0};
    memcpy(partial, input, count * 4u);
    assert(ml_sax_next_chunk(count, true, false) == ML_SAX_CHUNK_WAIT);
    assert(ml_sax_next_chunk(count, true, true) == ML_SAX_CHUNK_TAIL);
    ml_sax_downsample(partial, pcm);
    assert(pcm[0] != 0 && pcm[1] != 0);
    assert(ml_sax_next_chunk(0, true, true) == ML_SAX_CHUNK_SILENCE);
    assert(ml_sax_next_chunk(0, false, true) == ML_SAX_CHUNK_WAIT);
  }
  assert(ml_sax_next_chunk(ML_SAX_SOURCE_FRAMES, true, false) ==
         ML_SAX_CHUNK_FULL);
  /* A 512-frame full packet followed by a 15-frame tail keeps both.
   * The preceding frame group is NOT replaced by the last partial one. */
  assert(ml_sax_next_chunk(527, true, false) == ML_SAX_CHUNK_FULL);
  assert(ml_sax_next_chunk(15, true, true) == ML_SAX_CHUNK_TAIL);
  puts("PASS: DualSense 48k-to-3k conversion and SAxense packet framing");
  return 0;
}
