"""Ensure all GameStream URL paths use one IPv6-safe host encoder."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class GameStreamUrlWiringTests(unittest.TestCase):
    def test_every_control_url_uses_validated_authority(self):
        source = (ROOT / 'libgamestream/client.c').read_text(encoding='utf-8')
        endpoints = {
            'load_serverinfo': ('static int load_serverinfo(', 'static int load_server_status(', 1),
            'gs_unpair': ('int gs_unpair(', 'int gs_pair(', 1),
            'gs_pair': ('int gs_pair(', 'int gs_applist(', 5),
            'gs_applist': ('int gs_applist(', 'int gs_start_app(', 1),
            'gs_start_app': ('int gs_start_app(', 'int gs_quit_app(', 1),
            'gs_quit_app': ('int gs_quit_app(', 'int gs_forget_server_pin(', 1),
        }
        for label, (start, end, count) in endpoints.items():
            with self.subTest(endpoint=label):
                block = source[source.index(start):source.index(end, source.index(start))]
                self.assertIn(
                    'moonlight_url_host(server->serverInfo.address, url_host, sizeof(url_host))',
                    block)
                urls = re.findall(r'snprintf\(url,\s*[^;]+;', block, re.S)
                self.assertEqual(len(urls), count)
                for request in urls:
                    self.assertIn('url_host,', request)
                    self.assertNotIn('server->serverInfo.address,', request)

    def test_metrics_url_uses_the_same_authority_formatter(self):
        http = (ROOT / 'libgamestream/http.c').read_text(encoding='utf-8')
        metrics = http[http.index('int http_fetch_hardware_metrics('):]
        self.assertIn('moonlight_url_host(address, url_host, sizeof(url_host))',
                      metrics)
        self.assertIn('"https://%s:%u/api/hardware-metrics"', metrics)
        self.assertNotIn('const bool ipv6=strchr(address', metrics)

    def test_host_boundaries_are_not_rewritten_for_transport_or_pairing(self):
        source = (ROOT / 'libgamestream/client.c').read_text(encoding='utf-8')
        self.assertIn('server->serverInfo.address = address;', source)
        helper = ROOT / 'libgamestream/url_host.h'
        self.assertTrue(helper.is_file())
        content = helper.read_text(encoding='utf-8')
        self.assertIn('inet_pton(AF_INET6', content)
        self.assertIn('[%s%%25%s]', content)


    def test_socket_normalization_does_not_change_pin_or_control_identity(self):
        main = (ROOT / 'src/main.c').read_text(encoding='utf-8')
        client = (ROOT / 'libgamestream/client.c').read_text(encoding='utf-8')
        # Validate the input before Sunshine launches the remote application.
        self.assertLess(main.index('moonlight_transport_host('),
                        main.index('gs_start_app('))
        self.assertIn('SERVER_INFORMATION transport_server_info = server->serverInfo;', main)
        self.assertIn('transport_server_info.address = transport_address;', main)
        self.assertEqual(main.count('&transport_server_info'), 2)
        self.assertIn('server->serverInfo.address = address;', client)
        self.assertIn('http_bind_server_certificate_at_port(keyDirectory, address, httpPort)', client)


if __name__ == '__main__':
    unittest.main()
