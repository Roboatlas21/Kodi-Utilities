/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include "../src/app_list_ids.h"
#include <assert.h>
#include <stdlib.h>

int main(void) {
  char *result = NULL;
  size_t len = 0;
  FILE *mem = open_memstream(&result, &len);
  assert(mem);
  assert(moonlight_app_id_line(mem, 42, "Desktop"));
  assert(moonlight_app_id_line(mem, 99, "Desktop"));
  assert(moonlight_app_id_line(mem, 7, "Tab\tNew\nLine"));
  assert(!moonlight_app_id_line(mem, -1, "Desktop"));
  assert(!moonlight_app_id_line(mem, 0, ""));
  assert(fclose(mem) == 0);
  assert(result && strcmp(result, "42\t4465736b746f70\n"
                                 "99\t4465736b746f70\n"
                                 "7\t546162094e65770a4c696e65\n") == 0);
  free(result);
  return 0;
}
