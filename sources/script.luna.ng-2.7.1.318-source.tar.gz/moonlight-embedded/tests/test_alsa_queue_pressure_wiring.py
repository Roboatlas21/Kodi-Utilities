"""ALSA queue pressure must not silently change buffering or native pacing."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]


class AlsaPressureWiringTests(unittest.TestCase):
    def test_pressure_reports_opt_in_and_preserves_low_latency(self):
        src = (ROOT / 'src/audio/alsa.c').read_text()
        self.assertIn('#define ALSA_PENDING_MAX_FRAMES 960', src)
        self.assertIn('alsa_queue_pressure_log(&alsaPressureLog', src)
        self.assertIn('ALSA_PRESSURE_V1', src)
        self.assertIn('ALSA_PRESSURE_SUMMARY_V1', src)
        self.assertIn('alsaStats.pending_overflow_events++', src)
        self.assertIn('alsaStats.pending_stall_callbacks++', src)
        self.assertIn('alsa_pending_queue_push(', src)
        self.assertIn('alsa_pending_queue_consume(', src)
        self.assertIn('active_bounded_ops, handle, alsaPending.storage,', src)
        start = src.index('const unsigned long queued = alsaPending.queued_frames;')
        peak = src.index('if (queued > alsaStats.peak_pending_frames)', start)
        write = src.index('AlsaBoundedResult result = alsa_bounded_write(', start)
        consume = src.index('alsa_pending_queue_consume(&alsaPending', start)
        self.assertLess(start, peak)
        self.assertLess(peak, write)
        self.assertLess(write, consume)
        self.assertIn('if (!audioDiagnosticsEnabled) return;', src)


if __name__ == '__main__':
    unittest.main()
