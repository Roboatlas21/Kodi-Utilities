"""Exercise the actual AML pump monitor with a synthetic monotonic clock.

No CoreELEC devices or host services are needed; the production monitor
function is compiled directly into a pthread harness, not copied by hand.
"""
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'src/video/aml.c'


class DisplayPumpGuardTests(unittest.TestCase):
    def test_display_ioctl_stall_is_independently_monitored(self):
        source = SOURCE.read_text(encoding='utf-8')
        start = source.index('static void *aml_codec_write_guard(')
        end = source.index('static void aml_display_operation_enter(', start)
        actual_guard = source[start:end]
        prefix = r'''
#define _DEFAULT_SOURCE 1
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include "aml_write_watchdog.h"

enum aml_display_guard_operation {
  AML_DISPLAY_GUARD_DQBUF = 1,
  AML_DISPLAY_GUARD_QBUF = 2
};
static bool codec_write_guard_stop, codec_write_inflight;
static uint32_t codec_write_entered_ms;
static bool display_ioctl_inflight;
static uint32_t display_ioctl_entered_ms;
static unsigned int display_ioctl_generation;
static int display_ioctl_operation;
static uint32_t fake_time_ms;
static int shutdown_requests;
static uint32_t LiGetMillis(void) {
  return __atomic_load_n(&fake_time_ms, __ATOMIC_ACQUIRE);
}
static void request_shutdown(void) {
  __atomic_fetch_add(&shutdown_requests, 1, __ATOMIC_RELAXED);
}
static void (*aml_failure_callback)(void) = request_shutdown;
'''
        suffix = r'''
static void wait_for_request(void) {
  for (int i = 0; i < 150; ++i) {
    if (__atomic_load_n(&shutdown_requests, __ATOMIC_ACQUIRE)) return;
    usleep(10000);
  }
  assert(!"Independent AML pump watchdog did not request stream stop");
}
int main(void) {
  /* Only display is stuck. The codec-write guard is deliberately idle. */
  display_ioctl_operation = AML_DISPLAY_GUARD_QBUF;
  display_ioctl_generation = 1;
  display_ioctl_entered_ms = 100;
  display_ioctl_inflight = true;
  fake_time_ms = 12200;
  pthread_t guard;
  assert(pthread_create(&guard, NULL, aml_codec_write_guard, NULL) == 0);
  wait_for_request();
  assert(shutdown_requests == 1);
  display_ioctl_inflight = false;
  codec_write_guard_stop = true;
  assert(pthread_join(guard, NULL) == 0);

  /* No phantom stop from an old operation after it has completed. */
  shutdown_requests = 0;
  codec_write_guard_stop = false;
  fake_time_ms = 20000;
  assert(pthread_create(&guard, NULL, aml_codec_write_guard, NULL) == 0);
  usleep(30000);
  assert(shutdown_requests == 0);
  codec_write_guard_stop = true;
  assert(pthread_join(guard, NULL) == 0);

  /* Persistent ioctl: the independently running monitor must ultimately
   * exit the process with status 124 for Luna's recovery supervisor. */
  pid_t child = fork();
  assert(child >= 0);
  if (child == 0) {
    alarm(3);
    codec_write_guard_stop = false;
    display_ioctl_inflight = true;
    display_ioctl_generation = 2;
    display_ioctl_entered_ms = 100;
    fake_time_ms = 20000;
    aml_codec_write_guard(NULL);
    _exit(99);
  }
  int status = 0;
  assert(waitpid(child, &status, 0) == child);
  assert(WIFEXITED(status) && WEXITSTATUS(status) == 124);
  puts("AML pump watchdog: independent stop, clear lifetime, forced recovery");
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as td:
            source_file = Path(td) / 'watchdog.c'
            binary = Path(td) / 'watchdog'
            source_file.write_text(prefix + actual_guard + suffix)
            compiler = shlex.split(os.environ.get('CC', 'cc'))
            subprocess.run(compiler + ['-std=gnu99', '-Wall', '-Wextra',
                           '-Werror', '-pthread',
                           '-I' + str(ROOT / 'src/video'), str(source_file),
                           '-o', str(binary)], check=True, timeout=12)
            subprocess.run([str(binary)], check=True, timeout=8)


if __name__ == '__main__':
    unittest.main()
