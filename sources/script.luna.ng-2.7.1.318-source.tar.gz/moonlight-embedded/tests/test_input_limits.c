#include <assert.h>
#include <stdio.h>
#include "../src/input/input_limits.h"
#include "../src/input/controller_count.h"
int main(void) {
  assert(MAX_INPUTS == 32);
  assert(MOONLIGHT_GAMEPAD_SLOTS == 16U);
  assert(moonlight_gamepad_mask(16, 0) == 65535);
  assert(moonlight_gamepad_mask(32, 0) == 65535);
  puts("PASS: 32 input nodes with independent 16-player protocol");
  return 0;
}
