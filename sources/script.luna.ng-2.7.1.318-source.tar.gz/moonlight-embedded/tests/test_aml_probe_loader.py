"""Required vendor symbols fail preflight; unused lazy imports remain allowed."""
from pathlib import Path
import os
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AmlLoaderTests(unittest.TestCase):
    def test_missing_used_function_and_unused_vendor_import(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            flags = ['cc', '-std=gnu99', '-I' + str(ROOT / 'third_party/moonlight-common-c/src')]
            (root / 'main.c').write_text('int platform_probe_aml(void); int main(void) { return platform_probe_aml() == 0 ? 0 : 1; }')
            subprocess.run(flags + ['-DHAVE_AML', '-ffunction-sections', '-fdata-sections',
                str(root / 'main.c'), str(ROOT / 'src/platform.c'), '-Wl,--gc-sections',
                '-ldl', '-o', str(root / 'probe')], check=True)
            vendor = ['codec_init', 'codec_close', 'codec_write', 'codec_reset',
                'codec_get_vbuf_state', 'codec_get_vdec_state', 'codec_checkin_pts_us64',
                'codec_pause', 'codec_resume', 'codec_set_cntl_avthresh', 'codec_set_cntl_mode',
                'codec_set_cntl_syncthresh', 'codec_set_freerun_mode', 'codec_set_video_delay_limited_ms']
            source = '''#include <Limelight.h>
static int setup(int a,int b,int c,int d,void* e,int f) { return 0; }
static void cleanup(void) {}
static int submit(PDECODE_UNIT unit) { return 0; }
DECODER_RENDERER_CALLBACKS decoder_callbacks_aml = {
 .setup=setup, .cleanup=cleanup, .submitDecodeUnit=submit};
void aml_set_failure_callback(void (*cb)(void)) {}
extern void get_decoder_status(void);
void unused_vendor_feature(void) { get_decoder_status(); }
'''
            for missing, expected in [(None, 0), ('codec_write', 1)]:
                (root / 'fake.c').write_text(source + ''.join(
                    'void %s(void) {}\n' % name for name in vendor if name != missing))
                subprocess.run(flags + ['-shared', '-fPIC', str(root / 'fake.c'),
                    '-o', str(root / 'libmoonlight-aml.so')], check=True)
                result = subprocess.run([str(root / 'probe')],
                    env=dict(os.environ, LD_LIBRARY_PATH=directory), capture_output=True, text=True)
                self.assertEqual(result.returncode, expected, result.stderr)
