/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/audio/alsa_pending_queue.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
  unsigned char storage[8] = {0}; /* Four two-byte test frames. */
  AlsaPendingQueue q = {0};
  assert(!alsa_pending_queue_configure(&q, storage, sizeof(storage), 5, 2));
  assert(!alsa_pending_queue_configure(&q, storage, sizeof(storage), 4, 0));
  assert(alsa_pending_queue_configure(&q, storage, sizeof(storage), 4, 2));
  const unsigned char a[] = {1, 2, 3, 4, 5, 6};
  const unsigned char b[] = {7, 8, 9, 10};
  assert(alsa_pending_queue_push(&q, a, 3) == 0);
  assert(q.queued_frames == 3 && memcmp(storage, a, 6) == 0);
  alsa_pending_queue_consume(&q, 1);
  assert(q.queued_frames == 2 && memcmp(storage, a + 2, 4) == 0);
  assert(alsa_pending_queue_push(&q, b, 2) == 0);
  const unsigned char expected[] = {3, 4, 5, 6, 7, 8, 9, 10};
  assert(q.queued_frames == 4 && memcmp(storage, expected, 8) == 0);

  /* Overflow evicts old frames and keeps newer audio in playback order. */
  const unsigned char c[] = {11, 12, 13, 14};
  assert(alsa_pending_queue_push(&q, c, 2) == 2);
  const unsigned char after_evict[] = {7, 8, 9, 10, 11, 12, 13, 14};
  assert(q.queued_frames == 4 && memcmp(storage, after_evict, 8) == 0);

  /* A packet larger than capacity keeps only its newest frames. */
  const unsigned char huge[] = {21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32};
  assert(alsa_pending_queue_push(&q, huge, 6) == 6);
  assert(q.queued_frames == 4 && memcmp(storage, huge + 4, 8) == 0);
  alsa_pending_queue_consume(&q, 4);
  assert(q.queued_frames == 0);
  assert(alsa_pending_queue_push(&q, b, 2) == 0);
  alsa_pending_queue_clear(&q);
  assert(q.queued_frames == 0);
  assert(alsa_pending_queue_push(&q, b, 2) == 0);
  assert(q.queued_frames == 2 && memcmp(storage, b, 4) == 0);
  puts("ALSA pending queue: ordering, consumption, overflow and reset passed");
}
