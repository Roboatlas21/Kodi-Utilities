"""The production DualSense cleanup must release every active touch contact."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DualSenseTouchDetachTests(unittest.TestCase):
    def test_two_contacts_release_once_on_disconnect(self):
        source = (ROOT / "src/input/dualsense.c").read_text()
        start = source.rindex("static void dualsense_release_touches(")
        end = source.index("\nstatic void dualsense_mark_failed(", start)
        cleanup = source[start:end]
        detach_start = source.index("\nvoid dualsense_detach(", end)
        detach = source[detach_start:source.index("\n}", detach_start) + 2]
        self.assertIn("dualsense_release_touches(d);", detach)
        harness = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#define LI_TOUCH_EVENT_UP 2
#define LI_FF_CONTROLLER_TOUCH_EVENTS 0x100
typedef struct {
  int player;
  bool touch_active[2];
  uint32_t touch_id[2];
  float touch_x[2], touch_y[2];
} moonlight_dualsense;
static unsigned capabilities = LI_FF_CONTROLLER_TOUCH_EVENTS;
static int releases, next_slot;
static unsigned LiGetHostFeatureFlags(void) { return capabilities; }
static int LiSendControllerTouchEvent(uint8_t player, int type,
                                      uint32_t id, float x, float y, float pressure) {
  assert(player == 3 && type == LI_TOUCH_EVENT_UP && pressure == 0);
  assert(id == (next_slot == 0 ? 7u : 9u));
  assert(x >= 0 && x <= 1 && y >= 0 && y <= 1);
  ++next_slot; ++releases;
  return 0;
}
'''
        harness += cleanup
        harness += r'''
int main(void) {
  moonlight_dualsense d = {.player = 3,
     .touch_active = {true, true}, .touch_id = {7, 9},
     .touch_x = {.2f, .7f}, .touch_y = {.3f, .8f}};
  dualsense_release_touches(&d);
  assert(releases == 2 && !d.touch_active[0] && !d.touch_active[1]);
  dualsense_release_touches(&d);
  assert(releases == 2); /* No duplicate UP events */
  d.touch_active[0] = true;
  capabilities = 0;
  dualsense_release_touches(&d);
  assert(!d.touch_active[0] && releases == 2); /* Still clears local state */
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "touch.c"
            exe = Path(td) / "touch"
            src.write_text(harness)
            command = shlex.split(os.environ.get("CC", "cc")) + [
                "-std=gnu11", "-Wall", "-Wextra", "-Werror", str(src), "-o", str(exe)]
            build = subprocess.run(command, text=True, capture_output=True)
            self.assertEqual(build.returncode, 0, build.stderr)
            subprocess.run([str(exe)], check=True, timeout=5)


if __name__ == "__main__":
    unittest.main()
