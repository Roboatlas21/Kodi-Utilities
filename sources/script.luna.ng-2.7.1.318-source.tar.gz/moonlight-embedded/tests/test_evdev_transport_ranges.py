"""Exercise production report dispatch using the real transport argument widths."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class TransportRangeTests(unittest.TestCase):
    def test_motion_and_scroll_keep_direction_at_transport_boundaries(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        start = source.index('    if (dev->mouseDeltaX != 0 || dev->mouseDeltaY != 0) {',
                             source.index('static bool evdev_handle_event'))
        end = source.index('    if (dev->gamepadModified)', start)
        harness = r'''
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <Limelight.h>
#include "motion_math.h"
struct device {
  int32_t mouseDeltaX, mouseDeltaY, mouseVScroll, mouseHScroll;
  int rotate, controllerId; bool is_gamepad;
};
static int x, y, vertical, horizontal, calls;
static bool allowed = true;
static bool moonlight_host_input_allowed(bool gamepad, int id) {
  (void)gamepad; (void)id; return allowed;
}
int LiSendMouseMoveEvent(short dx, short dy) {x=dx;y=dy;calls++;return 0;}
int LiSendScrollEvent(signed char v) {vertical=v;calls++;return 0;}
int LiSendHScrollEvent(signed char v) {horizontal=v;calls++;return 0;}
static void report(struct device *dev) {
''' + source[start:end] + r'''
}
int main(void) {
  const int32_t values[] = {INT32_MIN,-40000,-32769,-32768,-128,-1,0,1,
                            127,128,32767,32768,40000,INT32_MAX};
  for (unsigned i=0;i<sizeof(values)/sizeof(values[0]);i++) {
    int32_t v=values[i];
    struct device d={.mouseDeltaX=v,.mouseDeltaY=v,.mouseVScroll=v,.mouseHScroll=v};
    x=y=vertical=horizontal=calls=0;
    report(&d);
    int expected_mouse=v>32767?32767:v<-32768?-32768:v;
    int expected_scroll=v>127?127:v<-128?-128:v;
    assert(x==expected_mouse && y==expected_mouse);
    assert(vertical==expected_scroll && horizontal==expected_scroll);
    assert(calls==(v?3:0));
    assert(!d.mouseDeltaX && !d.mouseDeltaY && !d.mouseVScroll && !d.mouseHScroll);
  }
  const int rotations[]={0,90,180,270};
  const int expected[][2]={{32767,-32768},{-32768,-32768},
                         {-32768,32767},{32767,32767}};
  for (unsigned i=0;i<4;i++) {
    struct device d={.mouseDeltaX=INT32_MAX,.mouseDeltaY=INT32_MIN,.rotate=rotations[i]};
    calls=0; report(&d);
    assert(calls==1 && x==expected[i][0] && y==expected[i][1]);
  }
  struct device touch={.mouseDeltaX=moonlight_touch_delta(60000,1000)};
  report(&touch); assert(x==32767);
  allowed=false; calls=0;
  struct device blocked={.mouseDeltaX=40000,.mouseVScroll=128,.mouseHScroll=256};
  report(&blocked);
  assert(!calls && !blocked.mouseDeltaX && !blocked.mouseVScroll && !blocked.mouseHScroll);
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as directory:
            src = Path(directory) / 'report.c'
            exe = Path(directory) / 'report'
            src.write_text(harness)
            subprocess.run(['cc', '-std=gnu99', '-Wall', '-Wextra', '-Werror',
                            '-fsanitize=undefined', '-fno-sanitize-recover=undefined',
                            '-I'+str(ROOT/'src/input'),
                            '-I'+str(ROOT/'third_party/moonlight-common-c/src'),
                            str(src), '-o', str(exe)], check=True)
            subprocess.run([str(exe)], check=True, timeout=5)
