/* SPDX-License-Identifier: GPL-3.0-or-later
 * The OSD monitor and ICMP telemetry host tests intentionally do not use
 * real network host metrics. Their HTTP worker/parser have separate tests.
 */
#include "../src/osd/host_metrics.h"
#include <stdio.h>
#include <string.h>

void host_metrics_open(HostMetricsReader *r, const char *host, unsigned short port) {
  (void)host;
  (void)port;
  if (r) memset(r, 0, sizeof(*r));
}
void host_metrics_close(HostMetricsReader *r) { (void)r; }
void host_metrics_format(HostMetricsReader *r, char *out, size_t size) {
  (void)r;
  if (out && size) snprintf(out, size, "Host CPU/GPU n/a (no telemetry)");
}
