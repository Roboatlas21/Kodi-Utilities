/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include "../src/video/first_video_ready.h"

int main(void) {
  char dir[] = "/tmp/ml-video-ready-XXXXXX";
  assert(mkdtemp(dir));
  char path[256], target[256], contents[16] = {0};
  snprintf(path, sizeof(path), "%s/video", dir);
  snprintf(target, sizeof(target), "%s/target", dir);
  assert(moonlight_first_video_publish(NULL));
  assert(moonlight_first_video_publish(""));
  assert(!moonlight_first_video_publish(path)); /* Luna must create it. */
  FILE *precreated = fopen(path, "w");
  assert(precreated);
  fclose(precreated);
  assert(moonlight_first_video_publish(path));
  FILE *in = fopen(path, "r");
  assert(in && fgets(contents, sizeof(contents), in));
  fclose(in);
  assert(strcmp(contents, "ready\n") == 0);
  assert(moonlight_first_video_publish(path)); /* idempotent */
  assert(!moonlight_first_video_publish("/path/that/does/not/exist/video"));
  assert(!moonlight_first_video_publish("/dev/full"));
  FILE *f = fopen(target, "w");
  assert(f);
  fputs("untouched", f);
  fclose(f);
  unlink(path);
  assert(link(target, path) == 0);
  assert(!moonlight_first_video_publish(path)); /* Two links: unsafe. */
  in = fopen(target, "r"); assert(in);
  assert(fgets(contents, sizeof(contents), in));
  fclose(in);
  assert(strcmp(contents, "untouched") == 0);
  unlink(path);
  assert(symlink(target, path) == 0);
  assert(!moonlight_first_video_publish(path));
  in = fopen(target, "r"); assert(in);
  assert(fgets(contents, sizeof(contents), in));
  fclose(in);
  assert(strcmp(contents, "untouched") == 0);
  unlink(path);
  assert(mkfifo(path, 0600) == 0);
  assert(!moonlight_receipt_publish(path)); /* Must not block on FIFO. */
  unlink(path);
  assert(moonlight_receipt_publish(NULL)); /* Standalone native invocation. */
  assert(!moonlight_receipt_publish(path));
  FILE *ready = fopen(path, "w");
  assert(ready); fclose(ready);
  assert(moonlight_receipt_publish(path)); /* Connection marker uses same guard. */
  assert(moonlight_receipt_publish_value(path, "stopping\n", true));
  in = fopen(path, "r"); assert(in);
  assert(fgets(contents, sizeof(contents), in) && !strcmp(contents, "ready\n"));
  assert(fgets(contents, sizeof(contents), in) && !strcmp(contents, "stopping\n"));
  fclose(in);
  unlink(path); unlink(target); rmdir(dir);
  puts("PASS: first video receipt, idempotence, invalid path and no symlink following");
}
