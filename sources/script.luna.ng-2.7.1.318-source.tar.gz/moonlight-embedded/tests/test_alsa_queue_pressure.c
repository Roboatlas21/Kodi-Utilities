/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/audio/alsa_queue_pressure.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
  AlsaQueuePressureLog p = {0};
  assert(alsa_queue_pressure_log(&p, 1000000));
  assert(p.events == 1 && p.suppressed == 0);
  assert(!alsa_queue_pressure_log(&p, 1000001));
  assert(!alsa_queue_pressure_log(&p, 5999999));
  assert(p.events == 3 && p.suppressed == 2);
  assert(alsa_queue_pressure_log(&p, 6000000));
  assert(p.events == 4 && p.suppressed == 2);
  assert(!alsa_queue_pressure_log(&p, 6000001));
  assert(!alsa_queue_pressure_log(NULL, 7000000));
  puts("ALSA pressure logging: first event, throttling, and counters passed");
  return 0;
}
