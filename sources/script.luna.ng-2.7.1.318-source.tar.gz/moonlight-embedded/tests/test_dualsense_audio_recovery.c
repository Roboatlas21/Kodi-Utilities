/* Production PCM retirement/opening with independent endpoint ownership. */
#define _GNU_SOURCE
#include <assert.h>
#include "../src/input/dualsense.c"
uint32_t LiGetHostFeatureFlags(void) { return 0; }
int LiSendControllerTouchEvent(uint8_t n,uint8_t t,uint32_t id,float x,float y,float p) {
  (void)n;(void)t;(void)id;(void)x;(void)y;(void)p;return 0;
}
void loop_remove_fd(int fd) { (void)fd; }
void udev_schedule_advanced_retry(void) {}
bool udev_input_identity_for_fd(int fd,char *out,size_t n) { (void)fd;if(n)out[0]=0;return false; }
static int audio_tokens[2], closed_audio;
static pthread_mutex_t close_gate=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t close_wake=PTHREAD_COND_INITIALIZER;
static bool block_close,close_entered,close_released;

/* Default pthread condition variables use CLOCK_REALTIME. No missing
 * worker or lost signal may leave this host regression test running forever. */
static struct timespec close_deadline_after_ms(unsigned milliseconds) {
  struct timespec deadline;
  assert(clock_gettime(CLOCK_REALTIME, &deadline) == 0);
  deadline.tv_sec += milliseconds / 1000U;
  deadline.tv_nsec += (long)(milliseconds % 1000U) * 1000000L;
  if (deadline.tv_nsec >= 1000000000L) {
    ++deadline.tv_sec;
    deadline.tv_nsec -= 1000000000L;
  }
  return deadline;
}
bool ml_ds_audio_haptics_ready(const ml_ds_audio *a) {
  return a == (ml_ds_audio *)&audio_tokens[1];
}
ml_ds_audio *ml_ds_audio_open(int fd, int transport, int event_fd) {
  assert(fd >= 0 && transport == ML_DS_USB && event_fd >= 0);
  return (ml_ds_audio *)&audio_tokens[1];
}
void ml_ds_audio_close(ml_ds_audio *a) {
  pthread_mutex_lock(&close_gate);
  if(a&&block_close) {
    close_entered=true;pthread_cond_broadcast(&close_wake);
    const struct timespec release_deadline = close_deadline_after_ms(8000);
    while (!close_released) {
      const int wait_rc = pthread_cond_timedwait(
          &close_wake, &close_gate, &release_deadline);
      assert(wait_rc == 0); /* Never let the simulated blocked driver hang CI. */
    }
  }
  if(a)++closed_audio;
  pthread_mutex_unlock(&close_gate);
}
int main(void) {
  int event = open("/dev/null", O_RDONLY), other = open("/dev/zero", O_RDONLY);
  assert(event >= 0 && other >= 0);
  struct stat st; assert(fstat(event, &st) == 0);
  moonlight_dualsense active = {.fd = event, .transport = ML_DS_USB,
      .event_rdev = st.st_rdev, .listening = true, .gyro_scale = {1.0f/16.0f,1.0f/16.0f,1.0f/16.0f},
      .audio = (ml_ds_audio *)&audio_tokens[0]};
  bridges = &active;
  assert(dualsense_retry_audio(&active, event));
  assert(!active.audio && active.listening && bridges == &active);
  assert(dualsense_cleanup_pending_for(event));
  assert(!dualsense_cleanup_pending_for(other));
  assert(!dualsense_retry_audio(&active, event));
  assert(!active.audio_opening);
  /* Simulate the production dispatcher claim, not just its queue pop.
   * dualsense_close_one() decrements active when the borrowed closer exits.
   * Calling it with active==0 underflows the unsigned count and prevents
   * subsequent cleanup workers from ever starting. */
  pthread_mutex_lock(&bridge_cleanup.lock);
  moonlight_dualsense *retired = bridge_cleanup.head;
  assert(retired && bridge_cleanup.pending == 1 && bridge_cleanup.active == 0);
  bridge_cleanup.head = retired->next;
  if (!bridge_cleanup.head) bridge_cleanup.tail = NULL;
  retired->next = NULL;
  ++bridge_cleanup.active;
  pthread_mutex_unlock(&bridge_cleanup.lock);
  dualsense_close_one(retired);
  assert(closed_audio == 1 && !dualsense_cleanup_pending());
  pthread_mutex_lock(&bridge_cleanup.lock);
  assert(bridge_cleanup.active == 0 && bridge_cleanup.pending == 0);
  pthread_mutex_unlock(&bridge_cleanup.lock);
  assert(!dualsense_retry_audio(&active, event));
  assert(active.audio_opening);
  for (int i=0; i<1000 && !__atomic_load_n(&active.audio_open_done,__ATOMIC_ACQUIRE); ++i)
    usleep(1000);
  assert(dualsense_retry_audio(&active, event));
  assert(active.audio == (ml_ds_audio *)&audio_tokens[1]);
  assert(active.gyro_scale[0] * 1600 == 100.0f);
  assert(!dualsense_retry_audio(&active, event));
  moonlight_dualsense *slow=calloc(1,sizeof(*slow));
  slow->fd=-1;slow->audio=(ml_ds_audio *)&audio_tokens[0];
  block_close=true;assert(dualsense_cleanup_start());queue_cleanup(slow);
  const struct timespec close_deadline = close_deadline_after_ms(5000);
  pthread_mutex_lock(&close_gate);
  while (!close_entered) {
    const int wait_rc = pthread_cond_timedwait(
        &close_wake, &close_gate, &close_deadline);
    assert(wait_rc == 0); /* Timed out waiting for the actual closer. */
  }
  pthread_mutex_unlock(&close_gate);
  struct timespec before,after;clock_gettime(CLOCK_MONOTONIC,&before);
  dualsense_cleanup_shutdown();clock_gettime(CLOCK_MONOTONIC,&after);
  long elapsed=(after.tv_sec-before.tv_sec)*1000+(after.tv_nsec-before.tv_nsec)/1000000;
  assert(elapsed>=200&&elapsed<1000&&dualsense_cleanup_pending());
  /* Shutdown cannot restart while the blocked ALSA closer owns its object. */
  assert(!dualsense_cleanup_start());
  pthread_mutex_lock(&close_gate);close_released=true;pthread_cond_broadcast(&close_wake);
  pthread_mutex_unlock(&close_gate);
  for(int i=0;i<3000&&dualsense_cleanup_pending();++i)usleep(1000);
  assert(!dualsense_cleanup_pending());
  /* Only a finished dispatcher may be revived; its stopping state resets. */
  assert(!bridge_cleanup.dispatcher_detached);
  assert(dualsense_cleanup_start());
  assert(!bridge_cleanup.stopping);
  dualsense_cleanup_shutdown();
  close(event); close(other);
  return 0;
}
