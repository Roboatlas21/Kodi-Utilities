"""AML decoder buffer growth must fail through recoverable stop path."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]


class ResizeTests(unittest.TestCase):
    def test_packet_alloc_failures_request_stream_stop(self):
        aml = (ROOT / 'src/video/aml.c').read_text()
        util = (ROOT / 'src/util.c').read_text()
        self.assertIn('ensure_buf_size_checked(&pkt_buf, &pkt_buf_size,', aml)
        self.assertIn('if (!ensure_buf_size_checked(', aml)
        self.assertEqual(aml.count('if (!ensure_buf_size_checked('), 2)
        submit = aml.split('int aml_submit_decode_unit(', 1)[1]
        self.assertIn('submit_failed = true;', submit)
        self.assertIn('if (aml_failure_callback) aml_failure_callback();', submit)
        self.assertIn('void *replacement = realloc(*buf, required_size);', util)
        self.assertIn('if (!replacement)', util)
        self.assertIn('return false;', util)


if __name__ == '__main__':
    unittest.main()
