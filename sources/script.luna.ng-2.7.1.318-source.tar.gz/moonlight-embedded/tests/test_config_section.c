/* Independently validate the INI section filter used by the native parser. */
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include "../src/config_section.h"
int main(void) {
  bool enabled = false;
  assert(moonlight_config_section_header("address = old\n", &enabled) == 0);
  assert(!enabled);
  assert(moonlight_config_section_header("  [Other]\r\n", &enabled) == 1);
  assert(!enabled);
  assert(moonlight_config_section_header("[Moonlight]\n", &enabled) == 1);
  assert(enabled);
  assert(moonlight_config_section_header(" [Audio] ; note\n", &enabled) == 1);
  assert(!enabled);
  assert(moonlight_config_section_header(" [Moonlight] # settings\n", &enabled) == 1);
  assert(enabled);
  assert(moonlight_config_section_header("[Moonlight\n", &enabled) == -1);
  assert(moonlight_config_section_header("[Moonlight] address = bad\n", &enabled) == -1);
  assert(moonlight_config_section_header("[Moonlight]]\n", &enabled) == -1);
  assert(moonlight_config_section_header("; [Other]\n", &enabled) == 0);
  puts("PASS: INI section detection and malformed header rejection");
  return 0;
}
