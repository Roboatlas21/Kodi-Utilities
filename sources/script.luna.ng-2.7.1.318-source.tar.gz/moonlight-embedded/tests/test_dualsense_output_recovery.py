"""Check that advanced HID output never runs inside common-c's device lock."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


def body(source, start, end):
    first = source.index(start)
    return source[first:source.index(end, first + len(start))]


class DualSenseOutputRecoveryTests(unittest.TestCase):
    def test_host_callbacks_only_queue_writes(self):
        evdev = (ROOT / "src/input/evdev.c").read_text()
        led = body(evdev, "void evdev_set_controller_led(", "void evdev_set_adaptive_triggers(")
        adaptive = body(evdev, "void evdev_set_adaptive_triggers(", "void evdev_receive_haptics(")
        flush = body(evdev, "static int evdev_flush_dualsense_output(", "bool evdev_retry_dualsense_bridges(")
        for callback in (led, adaptive):
            self.assertIn("pthread_mutex_lock(&devices_mutex)", callback)
            self.assertIn("evdev_wake_dualsense_output();", callback)
            self.assertNotIn("dualsense_led(", callback)
            self.assertNotIn("dualsense_adaptive(", callback)
        self.assertIn("dualsense_led_try(bridge,", flush)
        self.assertIn("dualsense_adaptive_try(bridge,", flush)
        self.assertLess(flush.index("pthread_mutex_unlock(&devices_mutex)"),
                        flush.index("dualsense_led_try(bridge,"))
        self.assertLess(flush.index("pthread_mutex_unlock(&devices_mutex)"),
                        flush.index("dualsense_adaptive_try(bridge,"))
        self.assertIn("EFD_NONBLOCK | EFD_CLOEXEC", evdev)
        self.assertIn("ML_DS_SEND_RETRY", flush)
        self.assertIn("dualsense_output_retry_fd", evdev)
        self.assertIn("evdev_retry_dualsense_output_later()", flush)
        self.assertIn("dev->ds_led_revision == led_revision", flush)
        self.assertIn("dev->ds_adaptive_revision == adaptive_revision", flush)
        self.assertIn("timerfd_create(CLOCK_MONOTONIC", evdev)
        self.assertIn("static unsigned dualsense_output_retry_ms = 10", evdev)
        self.assertIn("dualsense_output_retry_ms < 250U", evdev)
        self.assertIn("else dualsense_output_retry_ms = 10", flush)

    def test_failed_bridge_does_not_retire_normal_gamepad(self):
        ds = (ROOT / "src/input/dualsense.c").read_text()
        evdev = (ROOT / "src/input/evdev.c").read_text()
        failure = body(ds, "static void dualsense_mark_failed(moonlight_dualsense *d) {",
                       "void dualsense_detach(")
        repair = body(evdev, "bool evdev_retry_dualsense_bridges(void) {",
                      "void evdev_start()")
        self.assertIn("dualsense_release_touches(d);", failure)
        self.assertIn("udev_schedule_advanced_retry();", failure)
        self.assertIn("loop_remove_fd(d->fd)", failure)
        self.assertNotIn("evdev_remove(", failure)
        self.assertIn("dev->dualsense = NULL;", repair)
        self.assertIn("dualsense_detach(old);", repair)
        self.assertIn("dualsense_attach(dev->fd", repair)
        self.assertIn("send_controller_arrival(dev);", repair)
        self.assertIn("dualsense_cleanup_pending_for(dev->fd)", repair)
        self.assertIn("dev->ds_motion_rates[0]", repair)
        self.assertIn("dev->ds_motion_rates[1]", repair)
        self.assertIn("dev->ds_led_desired", repair)
        self.assertIn("dev->ds_adaptive_desired", repair)
        for disabled in ("dualsense_capabilities(", "dualsense_speaker_owner(",
                         "dualsense_waveform_active("):
            self.assertIn(disabled, ds)
        self.assertIn("!dualsense_hid_healthy(d)", ds)


if __name__ == "__main__":
    unittest.main()
