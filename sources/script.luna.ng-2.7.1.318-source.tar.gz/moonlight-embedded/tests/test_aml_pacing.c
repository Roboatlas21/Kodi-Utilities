/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/video/aml_pacing.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
  assert(aml_pacing_wait_limit(NULL) == 0U);
  assert(aml_pacing_wait_limit("latency") == 0U);
  assert(aml_pacing_wait_limit("low-latency") == 1U);
  assert(aml_pacing_wait_limit("adaptive") == 1U);
  assert(aml_pacing_is_adaptive("adaptive"));
  assert(!aml_pacing_is_adaptive("balanced"));
  assert(!aml_pacing_is_adaptive(NULL));
  assert(aml_pacing_wait_limit("balanced") == 3U);
  assert(aml_pacing_wait_limit("garbage") == 0U);

  unsigned int head = 3, count = 4;
  assert(!aml_pacing_complete_qbuf(-1, 16, &head, &count));
  assert(head == 3 && count == 4); /* Failed QBUF retains ownership/index. */

  assert(aml_pacing_complete_qbuf(0, 16, &head, &count));
  assert(head == 4 && count == 3);

  head = 15; count = 1;
  assert(aml_pacing_complete_qbuf(0, 16, &head, &count));
  assert(head == 0 && count == 0);

  head = 2; count = 0;
  assert(!aml_pacing_complete_qbuf(0, 16, &head, &count));
  assert(head == 2 && count == 0);
  /* A four-frame burst retains only the newest frame in Low Latency,
   * yet a failed QBUF still retains the exact buffer ownership. */
  const unsigned int max_waiting = aml_pacing_wait_limit("low-latency");
  head = 14; count = 4;
  unsigned int dropped = 0;
  assert(!aml_pacing_complete_qbuf(-1, 16, &head, &count));
  assert(head == 14 && count == 4);
  while (count > max_waiting) {
    assert(aml_pacing_complete_qbuf(0, 16, &head, &count));
    dropped++;
  }
  assert(dropped == 3 && count == 1 && head == 1);

  /* Existing Balanced mode retains three frames for the same burst. */
  head = 14; count = 4; dropped = 0;
  while (count > aml_pacing_wait_limit("balanced")) {
    assert(aml_pacing_complete_qbuf(0, 16, &head, &count));
    dropped++;
  }
  assert(dropped == 1 && count == 3 && head == 15);
  puts("AML pacing modes and QBUF ownership tests passed");
  return 0;
}
