"""Deferred Kodi recovery must be nonblocking, short lived and item-bound."""
import fcntl
import json
import os
import stat
import threading
import time
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

xbmc = sys.modules.setdefault('xbmc', types.ModuleType('xbmc'))
xbmcvfs = sys.modules.setdefault('xbmcvfs', types.ModuleType('xbmcvfs'))
from resources.lib.util import kodirestore


class DeferredSeekTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.player = mock.Mock()
        self.player.isPlaying.return_value = False
        self.mocked = [
            mock.patch.object(xbmc, 'executebuiltin', create=True),
            mock.patch.object(xbmc, 'Player', return_value=self.player, create=True),
            mock.patch.object(xbmcvfs, 'translatePath',
                              return_value=str(self.root), create=True),
        ]
        for patch in self.mocked:
            patch.start()
            self.addCleanup(patch.stop)

    def test_schedules_one_second_plugin_callback_without_exposing_uri(self):
        token = kodirestore.schedule_seek('smb://nas/private/movie.mkv', 120.5)
        self.assertRegex(token, r'^[0-9a-f]{32}$')
        state = self.root / kodirestore.STATE_NAME
        self.assertTrue(state.exists())
        self.assertEqual(os.stat(state).st_mode & 0o777, 0o600)
        command = xbmc.executebuiltin.call_args.args[0]
        self.assertIn('AlarmClock(', command)
        self.assertIn('00:00:01,silent,false)', command)
        self.assertIn('action=restore_seek&token=' + token, command)
        self.assertNotIn('smb://', command)
        self.assertNotIn('private', command)
        self.player.seekTime.assert_not_called()

    def test_playback_starts_after_failed_handoff_and_seeks_exact_item(self):
        token = kodirestore.schedule_seek('smb://nas/movie.mkv', 421.0)
        self.assertFalse(kodirestore.retry_pending_seek(token))
        self.assertTrue((self.root / kodirestore.STATE_NAME).exists())
        self.player.isPlaying.return_value = True
        self.player.getPlayingFile.return_value = 'smb://nas/movie.mkv'
        self.assertTrue(kodirestore.retry_pending_seek(token))
        self.player.seekTime.assert_called_once_with(421.0)
        self.assertFalse((self.root / kodirestore.STATE_NAME).exists())

    def test_different_playback_never_receives_the_saved_seek(self):
        token = kodirestore.schedule_seek('smb://nas/old.mkv', 91.0)
        self.player.isPlaying.return_value = True
        self.player.getPlayingFile.return_value = 'smb://nas/new.mkv'
        self.assertFalse(kodirestore.retry_pending_seek(token))
        self.player.seekTime.assert_not_called()
        self.assertFalse((self.root / kodirestore.STATE_NAME).exists())

    def test_expired_restore_does_not_seek(self):
        token = kodirestore.schedule_seek('smb://nas/old.mkv', 12.0)
        self.player.isPlaying.return_value = True
        self.player.getPlayingFile.return_value = 'smb://nas/old.mkv'
        with mock.patch.object(kodirestore.time, 'time',
                               return_value=kodirestore.time.time() + 20):
            self.assertFalse(kodirestore.retry_pending_seek(token))
        self.player.seekTime.assert_not_called()
        self.assertFalse((self.root / kodirestore.STATE_NAME).exists())

    def test_pending_record_contains_no_plaintext_playback_uri_or_credentials(self):
        uri = 'smb://private_user:PRIVATE_PASSWORD@secret-nas/TopSecret/movie.mkv'
        token = kodirestore.schedule_seek(uri, 99.0)
        text = (self.root / kodirestore.STATE_NAME).read_text()
        record = json.loads(text)
        self.assertNotIn('uri', record)
        self.assertNotIn(uri, text)
        self.assertNotIn('PRIVATE_PASSWORD', text)
        self.assertNotIn('secret-nas', text)
        self.assertEqual(record['schema'], 2)
        self.assertEqual(record['token'], token)
        self.assertEqual(len(record['digest']), 64)
        self.player.isPlaying.return_value = True
        self.player.getPlayingFile.return_value = uri
        self.assertTrue(kodirestore.retry_pending_seek(token))
        self.player.seekTime.assert_called_once_with(99.0)

    def test_old_plaintext_state_is_deleted_when_luna_starts(self):
        old = (self.root / kodirestore.STATE_NAME)
        old.write_text(json.dumps({
            'token': 'a' * 32, 'uri': 'smb://user:password@nas/movie.mkv',
            'position': 90, 'expires': kodirestore.time.time() + 100}))
        old.chmod(0o600)
        self.assertTrue(kodirestore.cleanup_expired_seek())
        self.assertFalse(old.exists())

    def test_expired_pending_record_is_deleted_on_startup(self):
        kodirestore.schedule_seek('smb://nas/movie.mkv', 3.0)
        with mock.patch.object(kodirestore.time, 'time',
                               return_value=kodirestore.time.time() + 30):
            self.assertTrue(kodirestore.cleanup_expired_seek())
        self.assertFalse((self.root / kodirestore.STATE_NAME).exists())

    def test_lock_prevents_old_retirement_from_deleting_new_state(self):
        first = kodirestore.schedule_seek('smb://nas/first.mkv', 13.0)
        entered = threading.Event()
        allow = threading.Event()
        outcomes = []
        self.player.isPlaying.return_value = True

        def slow_original():
            entered.set()
            allow.wait(timeout=4)
            return 'smb://nas/first.mkv'

        self.player.getPlayingFile.side_effect = slow_original
        consumer = threading.Thread(
            target=lambda: outcomes.append(kodirestore.retry_pending_seek(first)))
        consumer.start()
        self.assertTrue(entered.wait(timeout=3))
        newer = []

        def replace_pending():
            newer.append(kodirestore.schedule_seek('smb://nas/next.mkv', 24.0))

        producer = threading.Thread(target=replace_pending)
        producer.start()
        self.assertTrue(producer.is_alive())
        allow.set()
        consumer.join(timeout=4)
        producer.join(timeout=4)
        self.assertFalse(consumer.is_alive())
        self.assertFalse(producer.is_alive())
        self.assertEqual(outcomes, [True])
        self.assertEqual(json.loads((self.root / kodirestore.STATE_NAME).read_text())
                         ['token'], newer[0])
        self.player.seekTime.assert_called_once_with(13.0)

    def test_replaced_state_does_not_seek_from_older_alarm(self):
        old = kodirestore.schedule_seek('smb://nas/old.mkv', 120.0)
        newer = kodirestore.schedule_seek('smb://nas/new.mkv', 60.0)
        self.player.isPlaying.return_value = True
        self.player.getPlayingFile.return_value = 'smb://nas/new.mkv'
        self.assertFalse(kodirestore.retry_pending_seek(old))
        self.assertTrue((self.root / kodirestore.STATE_NAME).exists())
        self.assertTrue(kodirestore.retry_pending_seek(newer))
        self.player.seekTime.assert_called_once_with(60.0)

    def test_locked_seek_has_a_deadline_and_does_not_overwrite(self):
        lock = self.root / kodirestore.LOCK_NAME
        with open(lock, 'a+b') as holder:
            # Mirror the mode required by production's secure lock-file check.
            # Otherwise the test fails on permissions before exercising timeout.
            os.fchmod(holder.fileno(), 0o600)
            fcntl.flock(holder.fileno(), fcntl.LOCK_EX)
            with mock.patch.object(kodirestore, 'LOCK_WAIT_SECONDS', 0.16):
                start = time.monotonic()
                with self.assertRaisesRegex(TimeoutError, 'pending-seek lock'):
                    kodirestore.schedule_seek('smb://nas/movie.mkv', 12)
                elapsed = time.monotonic() - start
            self.assertLess(elapsed, 1.5)
            self.assertFalse((self.root / kodirestore.STATE_NAME).exists())
            fcntl.flock(holder.fileno(), fcntl.LOCK_UN)
        token = kodirestore.schedule_seek('smb://nas/movie.mkv', 12)
        self.assertEqual(len(token), 32)

    def test_malformed_nested_and_growth_limited_state_fails_closed(self):
        path = self.root / kodirestore.STATE_NAME
        # Within the 32-KiB bound, but beyond the JSON nesting limit.
        raw = '[' * 100 + '0' + ']' * 100
        path.write_text(raw)
        path.chmod(0o600)
        self.assertIsNone(kodirestore._read(path))
        self.assertEqual(path.read_text(), raw)
        self.assertTrue(kodirestore.cleanup_expired_seek())
        self.assertFalse(path.exists())
        path.write_bytes(b' ' * (32768 + 1))
        path.chmod(0o600)
        self.assertIsNone(kodirestore._read(path))
        self.assertFalse(kodirestore.cleanup_expired_seek())
        self.assertEqual(path.stat().st_size, 32769)

    def test_seek_state_world_readable_is_rejected(self):
        token = kodirestore.schedule_seek('smb://nas/movie.mkv', 12.5)
        path = self.root / kodirestore.STATE_NAME
        path.chmod(0o644)
        self.assertIsNone(kodirestore._read(path))
        self.assertFalse(kodirestore.retry_pending_seek(token))
        self.player.seekTime.assert_not_called()

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_named_pipe_lock_never_blocks_state_action(self):
        lock = self.root / kodirestore.LOCK_NAME
        os.mkfifo(lock)
        start = time.monotonic()
        with self.assertRaises(OSError):
            kodirestore.schedule_seek('smb://nas/movie.mkv', 12)
        self.assertLess(time.monotonic() - start, 1.5)

    def test_malformed_token_cannot_open_any_file(self):
        self.assertFalse(kodirestore.retry_pending_seek('../etc/passwd'))
        self.assertFalse(kodirestore.retry_pending_seek(None))
        self.player.seekTime.assert_not_called()

    def test_dangling_or_attacker_symlink_is_not_followed(self):
        victim = self.root / 'victim'
        victim.write_text('secret')
        (self.root / kodirestore.STATE_NAME).symlink_to(victim)
        self.assertFalse(kodirestore.retry_pending_seek('1' * 32))
        self.assertEqual(victim.read_text(), 'secret')

    def test_failed_alarm_removes_private_pending_state(self):
        xbmc.executebuiltin.side_effect = RuntimeError('timer unavailable')
        with self.assertRaisesRegex(RuntimeError, 'timer unavailable'):
            kodirestore.schedule_seek('smb://nas/old.mkv', 10.0)
        self.assertFalse((self.root / kodirestore.STATE_NAME).exists())


if __name__ == '__main__':
    unittest.main()
