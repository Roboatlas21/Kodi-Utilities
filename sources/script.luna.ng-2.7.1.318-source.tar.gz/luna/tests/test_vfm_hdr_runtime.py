"""Decoder replacement must be read-only before Kodi stops, and reversible."""
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

from resources.lib.util import vfmruntime as runtime


class HdrDecoderRuntimeTests(unittest.TestCase):
    def test_preflight_has_no_rmmod(self):
        def module_info(field, _path):
            # The bundled decoder VERSION and the resident stock decoder
            # srcversion are separate identities, verified independently.
            return {'version': 'moonlight-hdr1',
                    'srcversion': 'STOCK_SRC_1234'}[field]

        def read_text(path, *args, **kwargs):
            if str(path).endswith('/parameters/multiplanar'):
                return 'N\n'
            if str(path).endswith('/srcversion'):
                return 'STOCK_SRC_1234\n'
            raise AssertionError('Unexpected sysfs read: %s' % path)

        with patch.object(runtime, '_module_info', side_effect=module_info), \
             patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             patch.object(Path, 'read_text', autospec=True, side_effect=read_text), \
             patch.object(Path, 'is_file', return_value=True), \
             patch.object(runtime, '_stock_decoder_module',
                          return_value=Path('/stock/amvdec_ports.ko')), \
             patch.object(runtime.subprocess, 'run') as run:
            backup = runtime.prepare_hdr_decoder(Path('/bundle/amvdec_ports.ko'))
        self.assertEqual(backup, (Path('/stock/amvdec_ports.ko'), '0', 'stock-v1'))
        run.assert_not_called()

    def test_patched_decoder_requires_owned_rollback_journal(self):
        # A patched decoder left by another session must not be silently
        # reused: doing so would strand Kodi without a trusted stock image.
        with patch.object(runtime, '_module_info', return_value='moonlight-hdr1'), \
             patch.object(runtime, '_loaded_module_version', return_value='moonlight-hdr1'), \
             patch.object(runtime, '_check_loaded_module_build') as identity, \
             patch.object(runtime, '_stock_decoder_module') as find:
            with self.assertRaisesRegex(
                    runtime.VfmRuntimeError, 'without a session rollback journal'):
                runtime.prepare_hdr_decoder(Path('/bundle/amvdec_ports.ko'))
        find.assert_not_called()
        identity.assert_called_once_with('amvdec_ports', Path('/bundle/amvdec_ports.ko'))

    def test_wrong_bundle_never_unloads_decoder(self):
        with patch.object(runtime, '_module_info', return_value=''), \
             patch.object(runtime, '_stock_decoder_module') as find:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'ownership support'):
                runtime.prepare_hdr_decoder(Path('/bundle/amvdec_ports.ko'))
        find.assert_not_called()

    def _simulate_failure(self, stage):
        state = {'decoder': 'stock-v1'}
        calls = []
        release = '4.9.test'
        journal = Path('/bundle/.luna-session.ABCD1234.decoder-state')
        original = (Path('/stock/amvdec_ports.ko'), '0', 'stock-v1')

        def save_journal(path, snapshot):
            self.assertEqual(path, journal)
            self.assertEqual(snapshot, original)
            self.assertEqual(state['decoder'], 'stock-v1')
            calls.append(['journal', str(path)])

        def recover_from_journal(path):
            self.assertEqual(path, journal)
            calls.append(['recover', str(path)])
            # Recovery's real SHA/provenance validation is covered by the
            # decoder-journal suite. Here exercise the real rollback command
            # path after durable ownership has been established.
            runtime._restore_stock_decoder(original)

        def version(name):
            return state['decoder'] if name == 'amvdec_ports' else None

        def run(args, **kw):
            calls.append(list(args))
            if args[:2] == ['rmmod', 'amvdec_ports']:
                state['decoder'] = None
            elif args[:2] == ['insmod', '/bundle/modules/4.9.test/amvdec_ports.ko']:
                if stage == 'decoder':
                    raise subprocess.CalledProcessError(1, args)
                state['decoder'] = 'moonlight-hdr1'
            elif args[:2] == ['insmod', '/bundle/modules/4.9.test/moonlight_vfm.ko']:
                raise subprocess.CalledProcessError(1, args)
            elif args[:2] == ['insmod', '/stock/amvdec_ports.ko']:
                state['decoder'] = 'stock-v1'
            return subprocess.CompletedProcess(args, 0)

        def exists(path):
            if str(path) == '/sys/module/amvdec_ports':
                return state['decoder'] is not None
            if str(path) == '/sys/module/moonlight_vfm':
                return False
            return False

        def module_info(field, _module):
            if field == 'vermagic':
                return release + ' SMP'
            if field == 'srcversion':
                return 'STOCK_SRC_1234'
            if field == 'version':
                return '6'
            raise AssertionError('Unexpected modinfo field %r' % field)

        def read_text(path, *args, **kwargs):
            if str(path).endswith('/srcversion'):
                return 'STOCK_SRC_1234\n'
            if str(path).endswith('/parameters/multiplanar'):
                return 'N\n'
            raise AssertionError('Unexpected sysfs read: %s' % path)

        with patch.object(runtime, 'verify_bundle', return_value={
                  'kernel_release': release,
                  'module_order': ['amvdec_ports.ko', 'moonlight_vfm.ko']}), \
             patch.object(runtime, 'check_loaded_bridge'), \
             patch.object(runtime, '_module_info', side_effect=module_info), \
             patch.object(runtime, 'prepare_hdr_decoder', return_value=(
                          Path('/stock/amvdec_ports.ko'), '0', 'stock-v1')), \
             patch.object(runtime, '_loaded_module_version', side_effect=version), \
             patch.object(runtime.os, 'uname',
                          return_value=type('U', (), {'release': release})()), \
             patch.object(Path, 'exists', new=exists), \
             patch.object(Path, 'is_file', return_value=True), \
             patch.object(Path, 'read_text', autospec=True, side_effect=read_text), \
             patch.object(runtime.subprocess, 'run', side_effect=run), \
             patch.object(runtime, '_journal_save', side_effect=save_journal) as saved, \
             patch.object(runtime, 'recover_decoder',
                          side_effect=recover_from_journal) as recovered, \
             patch.object(runtime, '_verify_loaded_stock_decoder') as stock_verified, \
             patch.object(runtime, '_verify_stock_multiplanar') as mode_verified:
            with self.assertRaises(subprocess.CalledProcessError):
                runtime.load_modules(Path('/bundle'), journal)
        saved.assert_called_once_with(journal, original)
        recovered.assert_called_once_with(journal)
        stock_verified.assert_called_once_with(Path('/stock/amvdec_ports.ko'),
                                               'stock-v1')
        mode_verified.assert_called_once_with('0')
        self.assertEqual(state['decoder'], 'stock-v1')
        # The journal must be recorded before ANY destructive module action.
        self.assertEqual(calls[0], ['journal', str(journal)])
        self.assertEqual(calls[1], ['rmmod', 'amvdec_ports'])
        self.assertEqual([item[0] for item in calls].count('recover'), 1)
        self.assertEqual(calls[-1],
                         ['insmod', '/stock/amvdec_ports.ko', 'multiplanar=0'])

    def test_failed_decoder_install_restores_stock(self):
        self._simulate_failure('decoder')

    def test_failed_bridge_install_restores_stock(self):
        self._simulate_failure('bridge')

    def test_failure_to_restore_is_not_reported_as_success(self):
        # The source identity is available; simulate the actual stock insmod
        # failing. Do not accidentally fail the test at the earlier modinfo
        # preflight, which now correctly refuses unknown source identities.
        failure = subprocess.CalledProcessError(
            1, ['insmod', '/stock/amvdec_ports.ko', 'multiplanar=0'])
        with patch.object(runtime, '_module_info', return_value='STOCK_SRC_1234'), \
             patch.object(runtime, '_loaded_module_version', return_value=None), \
             patch.object(Path, 'exists', return_value=False), \
             patch.object(runtime.subprocess, 'run', side_effect=failure) as run:
            with self.assertRaises(subprocess.CalledProcessError):
                runtime._restore_stock_decoder(
                    (Path('/stock/amvdec_ports.ko'), '0', 'stock-v1'))
        run.assert_called_once_with(
            ['insmod', '/stock/amvdec_ports.ko', 'multiplanar=0'],
            timeout=15, check=True)

    def test_unknown_stock_source_identity_refuses_rollback_before_unload(self):
        # Strict fail-closed rollback is intentional and must not be relaxed
        # just to satisfy older VFM fixtures.
        with patch.object(runtime, '_module_info', return_value=''), \
             patch.object(runtime.subprocess, 'run') as run:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'source identity'):
                runtime._restore_stock_decoder(
                    (Path('/stock/amvdec_ports.ko'), '0', 'stock-v1'))
        run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
