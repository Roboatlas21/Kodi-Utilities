"""Keep recovery dialogs immediate and deferred seeks bound to the old URI."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class RecoveryWiringTests(unittest.TestCase):
    def test_alarm_callback_is_dispatchable_without_native_binary(self):
        addon = (ROOT / 'addon.py').read_text()
        self.assertIn("('diagnostics', 'restore_seek', 'settings')", addon)
        self.assertIn("elif action == 'restore_seek':", addon)
        self.assertIn("retry_pending_seek(args.get('token', [None])[0])", addon)
        self.assertIn('handled_directory = True', addon)

    def test_plugin_startup_cleans_old_plaintext_and_expired_seek_state(self):
        addon = (ROOT / 'addon.py').read_text()
        module = (ROOT / 'resources/lib/util/kodirestore.py').read_text()
        self.assertIn('cleanup_expired_seek()', addon)
        self.assertIn('def cleanup_expired_seek():', module)
        self.assertIn('STATE_SCHEMA = 2', module)
        # The lock must be nonblocking, with a finite retry deadline.
        self.assertIn('fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)', module)
        self.assertIn('deadline = time.monotonic() + LOCK_WAIT_SECONDS', module)
        self.assertIn('except BlockingIOError:', module)
        self.assertIn("raise TimeoutError('Timed out waiting for pending-seek lock')", module)
        self.assertIn('fcntl.flock(fd, fcntl.LOCK_UN)', module)
        self.assertNotIn("'uri': uri", module)

    def test_blocking_seek_poll_is_gone(self):
        helper = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text()
        restore = helper.split('def _restore_kodi_playback(player, previous):', 1)[1].split(
            'def _begin_local_stream_transition(', 1)[0]
        self.assertNotIn('time.sleep(', restore)
        self.assertNotIn('range(100)', restore)
        self.assertIn('schedule_seek(uri, position, paused=paused)', restore)
        self.assertIn('if ready and opened == uri:', restore)

    def test_input_path_preflight_occurs_before_playback_transition(self):
        addon = (ROOT / 'addon.py').read_text()
        helper = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text()
        self.assertIn('inputdevices.resolve_selectors(records, all_devices)', addon)
        self.assertLess(addon.index('inputdevices.resolve_selectors(records, all_devices)'),
                        addon.rindex("persistSetting('input_device_selectors_v2'"))
        launch = helper.split('def launch_game(self, game_id', 1)[1]
        self.assertIn('except inputdevices.InputPathLimitExceeded', launch)
        self.assertLess(launch.index('self.config_helper.configure()'),
                        launch.index('self._begin_local_stream_transition('))


if __name__ == '__main__':
    unittest.main()
