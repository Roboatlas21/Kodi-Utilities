"""VFM manifests must not allocate a multi-gigabyte immutable bundle."""
import json
from pathlib import Path
import tempfile
import unittest

from resources.lib.util.vfmruntime import (
    MAX_VERIFIED_BUNDLE_BYTES, VfmRuntimeError, verify_bundle,
)
from test_vfm_runtime import fixture


class VfmAggregateBudgetTests(unittest.TestCase):
    def test_small_verified_bundle_and_exact_bytes_still_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            fixture(root)
            manifest, files = verify_bundle(root, collect_bytes=True)
            self.assertEqual(len(files), len(manifest['objects']) + 1)
            self.assertEqual(files['manifest.json'], (root / 'manifest.json').read_bytes())

    def test_manifest_exceeding_aggregate_limit_is_rejected_before_any_elf_read(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manifest = fixture(root)
            self.assertEqual(MAX_VERIFIED_BUNDLE_BYTES, 256 * 1024 * 1024)
            for entry in manifest['objects'].values():
                entry['size'] = 64 * 1024 * 1024
            (root / 'manifest.json').write_text(json.dumps(manifest))
            for collect in (False, True):
                with self.subTest(collect=collect):
                    with self.assertRaisesRegex(VfmRuntimeError, 'aggregate size limit'):
                        verify_bundle(root, collect_bytes=collect)

    def test_invalid_declared_sizes_fail_before_opening_binary(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manifest = fixture(root)
            name = next(iter(manifest['objects']))
            for bad in (True, '64', -1, 64 * 1024 * 1024 + 1):
                manifest['objects'][name]['size'] = bad
                (root / 'manifest.json').write_text(json.dumps(manifest))
                with self.subTest(bad=bad):
                    with self.assertRaisesRegex(VfmRuntimeError, 'Invalid experimental file size'):
                        verify_bundle(root)


if __name__ == '__main__':
    unittest.main()
