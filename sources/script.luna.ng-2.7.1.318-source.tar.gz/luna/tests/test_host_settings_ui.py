"""Selected-host pairing and Kodi settings close-before-action regressions."""
import ast
import sys
import time
import types
import unittest
from pathlib import Path
from unittest import mock
from xml.etree import ElementTree
from resources.lib.util.hostcontext import host_identity

ROOT = Path(__file__).resolve().parents[1]
FUNCTIONS = {
    '_setPairingStatus', '_connection_options', 'syncPairingStatus', 'settings', 'pair', 'rePair',
    'pairFromApplications',
}


class HostSettingsUiTests(unittest.TestCase):
    def setUp(self):
        source = ast.parse((ROOT / 'addon.py').read_text(encoding='utf-8'))
        functions = [node for node in source.body if isinstance(node, ast.FunctionDef)
                     and node.name in FUNCTIONS]
        self.assertEqual({node.name for node in functions}, FUNCTIONS)
        self.values = {
            'host_addr': 'host-A',
            'pair_status_host': 'host-A',
            'pair_status_context': host_identity('host-A'),
            'paired_state': 'true',
        }
        self.pair_calls = []
        self.unpair_calls = []
        self.native_dumps = []
        self.cache_clears = []
        self.remote_paired = {'host-A': True, 'host-B': True}
        self.options = {}
        self.after_pair = lambda: None
        owner = self

        class Addon:
            def getSetting(self, key):
                return owner.values.get(key, '')

            def setSettingString(self, key, value):
                owner.values[key] = value

            def setSettingBool(self, key, value):
                owner.values[key] = 'true' if value else 'false'

            def getLocalizedString(self, key):
                return ''

            def openSettings(self):
                return None

        self.addon = Addon()

        class Configuration:
            config = {'host_addr': 'host-A'}

            def configure(self, dump=True):
                self.config['host_addr'] = owner.addon.getSetting('host_addr')

            def host_options(self):
                return dict(owner.options)

            def dump(self):
                owner.native_dumps.append(self.config['host_addr'])

        self.config = Configuration()

        class Host:
            def __init__(self, address):
                self.address = address

            def has_pairing_keys(self):
                return True

            def has_trusted_pin(self):
                return True

            def pair_status(self):
                return owner.remote_paired.get(self.address, False)

        class Helper:
            def __init__(self, _addon, config, _logger):
                self.config_helper = config
                self.paired_address = None
                self.paired_context = None
                self.pair_success = False
                self.last_unpair_error = None

            def _host_options(self):
                return {}

            def _host(self, address):
                return Host(address)

            def pair(self, expected_address=None, expected_options=None):
                self.config_helper.configure()
                address = expected_address or self.config_helper.config['host_addr']
                options = dict(owner.options if expected_options is None
                               else expected_options)
                owner.pair_calls.append(address)
                self.paired_address = address
                self.paired_context = host_identity(address, options)
                self.pair_success = True
                owner.remote_paired[address] = True
                owner.after_pair()

            def unpair(self):
                owner.unpair_calls.append(
                    self.config_helper.config['host_addr'])
                return True

        module_host = types.ModuleType('resources.lib.util.hostapi')
        module_host.Host = Host
        module_helper = types.ModuleType('resources.lib.util.moonlighthelper')
        module_helper.MoonlightHelper = Helper
        self.modules = {module_host.__name__: module_host,
                        module_helper.__name__: module_helper}
        self.saved_modules = {key: sys.modules.get(key) for key in self.modules}
        sys.modules.update(self.modules)
        self.addCleanup(self._restore_modules)

        self.dialog = mock.Mock()
        self.dialog.yesno.return_value = True
        self.scope = {
            'addon': self.addon,
            'config_helper': self.config,
            'logger': mock.Mock(),
            'xbmcgui': types.SimpleNamespace(Dialog=lambda: self.dialog),
            'persistSetting': self.addon.setSettingString,
            'persistBoolSetting': self.addon.setSettingBool,
            '_clearApplicationListCache': lambda: self.cache_clears.append(True),
            'retryApplications': mock.Mock(),
        }
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=functions, type_ignores=[])), str(ROOT / 'addon.py'),
            'exec'), self.scope)

    def _restore_modules(self):
        for key, previous in self.saved_modules.items():
            if previous is None:
                sys.modules.pop(key, None)
            else:
                sys.modules[key] = previous

    def test_host_buttons_commit_editor_before_running_plugin(self):
        tree = ElementTree.parse(ROOT / 'resources/settings.xml')
        for ident in ('test', 'repair_host', 'unpair_host',
                      'forget_trusted_server'):
            with self.subTest(action=ident):
                action = tree.find(".//setting[@id='%s']" % ident)
                self.assertIsNotNone(action)
                self.assertEqual(
                    action.findtext("./control/close"), 'true')
        pair = tree.find(".//setting[@id='test']")
        self.assertIsNone(pair.find('./dependencies'))
        self.assertIsNotNone(tree.find(".//setting[@id='pair_status_host']"))
        self.assertIsNotNone(tree.find(".//setting[@id='host_addr_initialized']"))

    def test_switching_host_uses_new_ip_without_unpairing_old_host(self):
        self.values['host_addr'] = 'host-B'
        # Kodi still displays the previous host's global paired boolean.
        self.assertTrue(self.scope['rePair']())
        self.assertEqual(self.pair_calls, ['host-B'])
        self.assertEqual(self.unpair_calls, [])
        self.assertEqual(self.values['host_addr'], 'host-B')
        self.assertEqual(self.values['pair_status_host'], 'host-B')
        self.assertEqual(self.native_dumps, ['host-B'])
        self.assertIn('host-B', self.values['pair_status_display'])

    def test_pairing_returning_to_trusted_host_never_forces_unpair(self):
        self.values.update({'host_addr': 'host-A', 'pair_status_host': 'host-B'})
        self.assertTrue(self.scope['pair']())
        self.assertEqual(self.unpair_calls, [])
        self.assertEqual(self.values['pair_status_host'], 'host-A')

    def test_normal_pair_does_not_publish_previous_port_or_keydir(self):
        for key, changed in (('port', '48089'),
                             ('keydir', '/tmp/replaced-client-keys')):
            with self.subTest(key=key):
                self.options.clear()
                self.after_pair = lambda k=key, v=changed: self.options.__setitem__(k, v)
                self.values['paired_state'] = 'false'
                self.values['pair_status_context'] = host_identity('host-A')
                self.cache_clears.clear()
                self.native_dumps.clear()
                self.pair_calls.clear()
                self.assertFalse(self.scope['pair']())
                self.assertEqual(self.pair_calls, ['host-A'])
                self.assertEqual(self.native_dumps, [])
                self.assertEqual(self.cache_clears, [])
                self.assertEqual(self.values['paired_state'], 'false')
                self.assertEqual(self.values['pair_status_context'],
                                 host_identity('host-A'))
                self.after_pair = lambda: None

    def test_settings_close_fallback_detects_same_ip_context_edits(self):
        for options in ({'port': '48089'},
                        {'keydir': '/tmp/alternate-pairing-keys'}):
            with self.subTest(options=options):
                self.options.clear()
                self.options.update(options)
                self.values['pair_status_host'] = 'host-A'
                self.values['pair_status_context'] = host_identity('host-A')
                self.scope['syncPairingStatus'] = mock.Mock()
                self.scope['settings']()
                self.scope['syncPairingStatus'].assert_called_once()

    def test_settings_rechecks_actual_host_after_edit(self):
        observed = []
        self.values['pair_status_host'] = 'host-B'
        self.addon.openSettings = lambda: self.values.__setitem__(
            'host_addr', 'host-B')
        def refresh():
            observed.append(self.values['host_addr'])
            self.values['pair_status_host'] = self.values['host_addr']
        self.scope['syncPairingStatus'] = refresh
        self.scope['settings']()
        self.assertEqual(observed, ['host-B'])
        self.assertEqual(self.config.config['host_addr'], 'host-B')
        self.assertEqual(len(self.cache_clears), 1)

    def test_unreachable_host_does_not_block_opening_settings(self):
        self.values['pair_status_host'] = 'different-host'
        seen = []
        self.addon.openSettings = lambda: seen.append('opened')
        self.scope['syncPairingStatus'] = lambda: seen.append('network')
        self.scope['settings']()
        self.assertEqual(seen, ['opened', 'network'])

    def test_live_service_skips_blocking_close_time_status(self):
        self.values['pair_status_host'] = 'different-host'
        self.addon.openSettings = lambda: self.values.__setitem__('host_addr', 'host-B')
        self.scope['syncPairingStatus'] = mock.Mock()
        self.scope['xbmcgui'].Window = lambda _id: types.SimpleNamespace(
            setProperty=lambda *_: None,
            getProperty=lambda key: 'ready' if key ==
                'Luna.Status.ServiceHealth' else str(time.monotonic()))
        self.scope['settings']()
        self.assertEqual(self.values['host_addr'], 'host-B')
        self.assertEqual(self.cache_clears, [True])
        self.scope['syncPairingStatus'].assert_not_called()

    def test_committed_ip_queues_async_check_after_fast_close(self):
        self.values['pair_status_host'] = 'host-A'
        state = {}
        class Window:
            def setProperty(self, key, value):
                state[key] = value
            def getProperty(self, key):
                if key == 'Luna.Status.ServiceHeartbeat':
                    return str(time.monotonic())
                if key == 'Luna.Status.ServiceHealth':
                    return 'ready'
                return state.get(key, '')
        self.scope['xbmcgui'].Window = lambda ident: Window()
        self.addon.openSettings = lambda: self.values.__setitem__(
            'host_addr', 'host-B')
        self.scope['syncPairingStatus'] = mock.Mock()
        self.scope['settings']()
        self.assertEqual(self.values['host_addr'], 'host-B')
        self.assertEqual(state['Luna.Status.PendingHost'], 'host-B')
        self.assertIn('Luna.Status.PendingContext', state)
        self.assertTrue(state['Luna.Status.PendingToken'])
        self.scope['syncPairingStatus'].assert_not_called()

    def test_recent_but_unhealthy_heartbeat_uses_close_time_fallback(self):
        self.values['pair_status_host'] = 'different-host'
        callbacks = []
        self.scope['xbmcgui'].Window = lambda _id: types.SimpleNamespace(
            setProperty=lambda *_: None,
            getProperty=lambda key: 'error' if key ==
                'Luna.Status.ServiceHealth' else str(time.monotonic()))
        self.scope['syncPairingStatus'] = lambda: callbacks.append('sync')
        self.scope['settings']()
        self.assertEqual(callbacks, ['sync'])

    def test_settings_uses_login_service_and_keeps_close_time_fallback(self):
        self.addon.openSettings = lambda: self.values.__setitem__(
            'host_addr', 'host-B')
        self.scope['settings']()
        self.assertEqual(self.values['host_addr'], 'host-B')
        self.assertEqual(self.values['pair_status_host'], 'host-B')
        self.assertEqual(len(self.cache_clears), 1)
        self.assertEqual(self.config.config['host_addr'], 'host-B')
        # No per-modal worker is spawned by the plugin itself.
        source = (ROOT / 'addon.py').read_text(encoding='utf-8')
        modal = source.split('def settings():', 1)[1].split(
            'def saveDiagnosticReport():', 1)[0]
        self.assertNotIn('threading.Thread', modal)
        self.assertNotIn('LiveHostStatusWatcher', modal)

    def test_settings_reopen_signals_service_even_without_ip_change(self):
        stamps = []
        class Home:
            def setProperty(self, key, value):
                stamps.append((key, value))
        self.scope['xbmcgui'].Window = lambda ident: Home()
        with mock.patch('time.monotonic_ns', side_effect=[1001, 1002]):
            self.scope['settings']()
            self.scope['settings']()
        self.assertEqual(stamps, [
            ('Luna.Status.OpenToken', '1001'),
            ('Luna.Status.OpenToken', '1002')])

    def test_invalid_native_config_still_allows_settings_recovery(self):
        # An unreadable legacy moonlight.conf must not prevent opening Kodi
        # Settings, the one UI action allowed during config recovery.
        self.config.config_error = ValueError('legacy config')
        self.values['pair_status_host'] = 'host-B'
        opened = []
        self.addon.openSettings = lambda: opened.append(True)
        self.scope['syncPairingStatus'] = mock.Mock()
        self.scope['settings']()
        self.assertEqual(opened, [True])
        self.scope['syncPairingStatus'].assert_not_called()

    def test_refresh_status_labels_checked_endpoint(self):
        self.values['host_addr'] = 'host-B'
        self.scope['syncPairingStatus']()
        self.assertEqual(self.values['pair_status_host'], 'host-B')
        self.assertEqual(self.values['paired_state'], 'true')
        self.assertIn('host-B', self.values['pair_status_display'])

    def test_failed_applist_does_not_repair_a_verified_host(self):
        self.scope['pair'] = mock.Mock()
        self.scope['rePair'] = mock.Mock()
        self.scope['syncPairingStatus'] = lambda: True
        self.scope['pairFromApplications']()
        self.scope['pair'].assert_not_called()
        self.scope['rePair'].assert_not_called()
        self.scope['retryApplications'].assert_called_once()

    def test_genuinely_unpaired_host_starts_new_pairing(self):
        self.scope['syncPairingStatus'] = lambda: False
        self.scope['pairFromApplications']()
        self.assertEqual(self.pair_calls, ['host-A'])
        self.scope['retryApplications'].assert_called_once()


if __name__ == '__main__':
    unittest.main()
