"""No-follow, descriptor-pinned reads for Luna XML and cached artwork."""
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest import mock

from resources.lib.util import safefile


class BoundedFileTests(unittest.TestCase):
    def test_valid_and_oversized_regular_files(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'file'
            path.write_bytes(b'abc')
            data, info = safefile.read_regular_bytes(path, 3)
            self.assertEqual(data, b'abc')
            self.assertEqual(info.st_ino, path.stat().st_ino)
            with self.assertRaises(safefile.UnsafeRegularFile):
                safefile.read_regular_bytes(path, 2)

    def test_symlink_directory_and_dangling_symlink_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / 'target'
            target.write_bytes(b'secret')
            path = root / 'file'
            path.symlink_to(target)
            with self.assertRaisesRegex(safefile.UnsafeRegularFile, 'symlink'):
                safefile.read_regular_bytes(path, 1024)
            path.unlink()
            path.symlink_to('missing')
            with self.assertRaises(safefile.UnsafeRegularFile):
                safefile.read_regular_bytes(path, 1024)
            path.unlink()
            path.mkdir()
            with self.assertRaises(safefile.UnsafeRegularFile):
                safefile.read_regular_bytes(path, 1024)
            path.rmdir()
            with self.assertRaises(FileNotFoundError):
                safefile.read_regular_bytes(path, 1024)
            self.assertEqual(target.read_bytes(), b'secret')

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_fifo_read_does_not_block(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'pipe'
            os.mkfifo(path)
            errors = []
            def attempt():
                try:
                    safefile.read_regular_bytes(path, 1024)
                except BaseException as error:
                    errors.append(error)
            worker = threading.Thread(target=attempt, daemon=True)
            worker.start()
            worker.join(timeout=2)
            self.assertFalse(worker.is_alive(), 'A named pipe blocked Luna')
            self.assertEqual(len(errors), 1)
            self.assertIsInstance(errors[0], safefile.UnsafeRegularFile)

    def test_renamed_path_uses_original_inode_and_bytes(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'source'
            new = Path(td) / 'replacement'
            path.write_bytes(b'OLD')
            old_info = path.stat()
            new.write_bytes(b'NEW')
            original_open = os.open
            def replace_after_open(filename, flags, *args, **kwargs):
                fd = original_open(filename, flags, *args, **kwargs)
                os.replace(new, path)
                return fd
            with mock.patch.object(safefile.os, 'open',
                                   side_effect=replace_after_open):
                data, info = safefile.read_regular_bytes(path, 3)
            self.assertEqual(data, b'OLD')
            self.assertEqual(info.st_ino, old_info.st_ino)
            self.assertEqual(path.read_bytes(), b'NEW')

    def test_growth_after_fstat_does_not_bypass_size_limit(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'source'
            path.write_bytes(b'old')
            raw_fstat = os.fstat
            def expand_after_fstat(fd):
                metadata = raw_fstat(fd)
                with open(path, 'ab') as f:
                    f.write(b'x' * 1024)
                return metadata
            with mock.patch.object(safefile.os, 'fstat',
                                   side_effect=expand_after_fstat):
                with self.assertRaises(safefile.UnsafeRegularFile):
                    safefile.read_regular_bytes(path, 3)


if __name__ == '__main__':
    unittest.main()
