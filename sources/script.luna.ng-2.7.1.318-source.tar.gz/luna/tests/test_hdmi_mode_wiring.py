"""Kodi handoff must own the display before a mode switch and restore it before Kodi."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'resources' / 'launchscripts' / 'coreelec'


class HdmiModeWiringTests(unittest.TestCase):
    def test_matching_defaults_on_but_respects_user_choice(self):
        settings = ET.parse(ROOT / 'resources' / 'settings.xml')
        option = settings.find(".//setting[@id='match_hdmi_mode']")
        self.assertIsNotNone(option)
        self.assertEqual(option.findtext('default'), 'true')
        helper = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text()
        self.assertIn("'1' if self.plugin.getSettingBool('match_hdmi_mode') else '0'", helper)

    def test_mode_switch_is_after_kodi_stop_and_before_native_stream(self):
        source = (SCRIPTS / 'launch.sh').read_text()
        self.assertLess(source.index('kodi_stopped=1'),
                        source.index('hdmimode.py" apply'))
        self.assertLess(source.index('hdmimode.py" apply'),
                        source.index('luna_write_receipt "$session.native-launch-prepared"'))
        self.assertIn('if [ "${MOONLIGHT_MATCH_HDMI_MODE:-0}" = 1 ]; then', source)
        self.assertIn('elif ! luna_timeout -k 2 10 python3', source)
        helper = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text()
        self.assertLess(helper.index('hdmimode.check(snapshot)'),
                        helper.index('self._begin_local_stream_transition(',
                                     helper.index('def launch_game(')))
        self.assertLess(helper.index('selected_profile = store.get(app_id)'),
                        helper.index('hdmimode.check(snapshot)'))
        self.assertLess(helper.index('if current != \'0\' and current != app_id:'),
                        helper.index('selected_profile = store.get(app_id)'))
        mode = (ROOT / 'resources/lib/util/hdmimode.py').read_text()
        self.assertIn('current, target = check(stream_config, mode_node, cap_node)',
                      mode)
        self.assertIn('"$stream_config"', source)
        self.assertIn('LUNA_DISPLAY_MODE_PATH=$DISPLAY_MODE_PATH', source)

    def test_regular_and_watchdog_recovery_restore_before_kodi(self):
        launch = (SCRIPTS / 'launch.sh').read_text()
        watchdog = (SCRIPTS / 'kodi-watchdog.sh').read_text()
        cleanup = launch.split('cleanup() {', 1)[1].split('trap cleanup 0', 1)[0]
        self.assertLess(cleanup.index('hdmimode.py" restore'),
                        cleanup.index('hdmigamemode.py" restore'))
        self.assertLess(cleanup.index('hdmigamemode.py" restore'),
                        cleanup.index('"$SYSTEMCTL" start "$KODI_UNIT"'))
        self.assertIn('"$hdmi_mode_recovered" -eq 1', cleanup)
        self.assertIn('if [ "$(kodi_service_state)" != inactive ]', cleanup)
        recovery = watchdog.split('# Restore original HDMI output mode', 1)[1]
        self.assertLess(recovery.index('hdmimode.py" restore'),
                        recovery.index('hdmigamemode.py" restore'))
        self.assertLess(recovery.index('hdmimode.py" restore'),
                        recovery.index('"$SYSTEMCTL" start "$KODI_UNIT"'))
        self.assertIn('"$hdmi_mode_recovered" -ne 1', recovery)
        self.assertIn('if [ "$(kodi_service_state)" != inactive ]', recovery)

    def test_session_retirement_keeps_unrestored_mode_journals(self):
        owner = (SCRIPTS / 'session-ownership.sh').read_text()
        launcher = (SCRIPTS / 'launch.sh').read_text()
        self.assertIn('"$ru_session.displaymode-state"', owner)
        self.assertIn('"$cs_session.displaymode-state"', owner)
        self.assertIn('displaymode-state aml-state;', owner)
        self.assertIn('"$previous.displaymode-state"', launcher)
        self.assertIn('hdmi_mode_state="$session.displaymode-state"', launcher)


if __name__ == '__main__':
    unittest.main()
