"""Kodi audio keepalive must survive failed JSON-RPC acknowledgements."""
import json
import sys
import types
import unittest

from resources.lib.util.kodiaudio import kodi_setting, restore_saved_streamsilence


class KodiAudioRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.saved = {'saved_streamsilence': '8'}
        self.plugin = types.SimpleNamespace(
            getSetting=lambda name: self.saved.get(name, ''),
            setSettingString=lambda name, value: self.saved.__setitem__(name, value))
        self.current = 0
        self.set_result = 'OK'
        self.ignore_writes = False
        self.requests = []
        kodi = types.ModuleType('xbmc')
        kodi.executeJSONRPC = self.handle
        previous = sys.modules.get('xbmc')
        sys.modules['xbmc'] = kodi
        self.addCleanup(lambda: sys.modules.__setitem__('xbmc', previous)
                        if previous is not None else sys.modules.pop('xbmc', None))

    def handle(self, payload):
        req = json.loads(payload)
        self.requests.append(req)
        if req['method'] == 'Settings.GetSettingValue':
            return json.dumps({'jsonrpc': '2.0', 'id': 1,
                               'result': {'value': self.current}})
        if self.set_result == 'error':
            return json.dumps({'jsonrpc': '2.0', 'id': 1,
                               'error': {'code': -32602, 'message': 'Rejected'}})
        if self.set_result == 'malformed':
            return '{'
        if not self.ignore_writes:
            self.current = req['params']['value']
        return json.dumps({'jsonrpc': '2.0', 'id': 1,
                           'result': self.set_result})

    def test_restore_requires_confirmation_and_clears_backup_once(self):
        self.assertTrue(restore_saved_streamsilence(self.plugin))
        self.assertEqual(self.current, 8)
        self.assertEqual(self.saved['saved_streamsilence'], '')
        self.assertEqual([r['method'] for r in self.requests],
                         ['Settings.GetSettingValue', 'Settings.SetSettingValue',
                          'Settings.GetSettingValue'])

    def test_previously_restored_value_needs_no_second_write(self):
        self.current = 8
        self.assertTrue(restore_saved_streamsilence(self.plugin))
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.saved['saved_streamsilence'], '')

    def test_json_rpc_error_is_retryable(self):
        self.set_result = 'error'
        self.assertFalse(restore_saved_streamsilence(self.plugin))
        self.assertEqual(self.saved['saved_streamsilence'], '8')
        self.set_result = 'OK'
        self.assertTrue(restore_saved_streamsilence(self.plugin))
        self.assertEqual(self.saved['saved_streamsilence'], '')

    def test_unacknowledged_write_and_bad_readback_do_not_clear_backup(self):
        for result, ignore in [('NO', False), ('OK', True),
                               ('malformed', False)]:
            with self.subTest(result=result):
                self.saved['saved_streamsilence'] = '8'
                self.current = 0
                self.set_result = result
                self.ignore_writes = ignore
                self.assertFalse(restore_saved_streamsilence(self.plugin))
                self.assertEqual(self.saved['saved_streamsilence'], '8')

    def test_malformed_backup_is_never_submitted_to_kodi(self):
        for raw in ('-1', 'not-a-number', '2.5', '999999999999'):
            with self.subTest(raw=raw):
                self.saved['saved_streamsilence'] = raw
                self.requests.clear()
                self.assertFalse(restore_saved_streamsilence(self.plugin))
                self.assertEqual(self.requests, [])

    def test_kodi_binding_exception_retains_backup(self):
        import xbmc
        xbmc.executeJSONRPC = lambda _payload: (_ for _ in ()).throw(
            Exception('Kodi JSON-RPC unavailable'))
        self.assertFalse(restore_saved_streamsilence(self.plugin))
        self.assertEqual(self.saved['saved_streamsilence'], '8')

    def test_setting_write_rejects_error_envelope(self):
        self.set_result = 'error'
        self.assertFalse(kodi_setting('audiooutput.streamsilence', 0))


if __name__ == '__main__':
    unittest.main()
