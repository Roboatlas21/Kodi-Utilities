"""The confirmed CoreELEC host, port and keydir cannot change mid-action."""
import ast
from pathlib import Path
import sys
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
CALLS = {'_connection_options', '_pairing_context_current',
         '_confirmed_pairing_action_allowed', '_setPairingStatus',
         'syncPairingStatus', 'pair', 'rePair', 'unpairHost',
         'forgetTrustedServer'}


class CoreELECConfirmedHostTests(unittest.TestCase):
    def setUp(self):
        self.settings = {'host_addr': 'host-A', 'pair_status_host': 'host-A',
                         'paired_state': 'true'}
        self.options = {'port': '48990', 'keydir': '/tmp/host-A-keys'}
        self.unpaired = []
        self.forgot = []
        self.paired = []
        self.host_queries = []
        self.when_unpair = lambda: None
        self.when_forget = lambda: None
        self.cache_clears = 0
        test = self

        class Addon:
            def getSetting(self, key):
                return test.settings.get(key, '')
            def getLocalizedString(self, key):
                return ''
            def setSettingString(self, key, value):
                test.settings[key] = value
            def setSettingBool(self, key, value):
                test.settings[key] = 'true' if value else 'false'

        class Config:
            config = {'host_addr': 'host-A'}
            def configure(self, dump=True):
                self.config['host_addr'] = test.settings['host_addr']
            def host_options(self):
                return dict(test.options)
            def dump(self):
                pass

        class Host:
            def __init__(self, address):
                self.address = address
            def has_trusted_pin(self):
                return True
            def pair_status(self):
                test.host_queries.append(self.address)
                return True
            def has_pairing_keys(self):
                return True

        class Helper:
            def __init__(self, addon, config, logger):
                self.config_helper = config
                self.last_unpair_error = None
                self.last_trust_error = None
                self.last_unpair_unverified = False
                self.paired_address = None
                self.paired_context = None
                self.pair_success = False
                self._frozen_host_options = None
            def _host(self, address):
                return Host(address)
            def _host_options(self):
                return dict(test.options)
            def pair(self, expected_address=None, expected_options=None):
                address = expected_address or test.settings['host_addr']
                test.paired.append((address, dict(expected_options or {})))
                self.paired_address = address
                from resources.lib.util.hostcontext import host_identity
                self.paired_context = host_identity(
                    address, expected_options if expected_options is not None
                    else test.options)
                self.pair_success = True
            def unpair(self, expected_address=None, expected_options=None):
                test.unpaired.append((expected_address, dict(expected_options)))
                test.when_unpair()
                return True
            def forget_trusted_server(self, address, expected_options=None):
                test.forgot.append((address, dict(expected_options)))
                test.when_forget()
                return True

        self.addon = Addon()
        self.config = Config()
        self.dialog = mock.Mock()
        self.dialog.yesno.return_value = True
        self.module = types.ModuleType('resources.lib.util.moonlighthelper')
        self.module.MoonlightHelper = Helper
        self.prior_module = sys.modules.get(self.module.__name__)
        sys.modules[self.module.__name__] = self.module
        self.addCleanup(self.restore_module)
        tree = ast.parse((ROOT / 'addon.py').read_text())
        functions = [node for node in tree.body
                     if isinstance(node, ast.FunctionDef) and node.name in CALLS]
        self.assertEqual(set(node.name for node in functions), CALLS)
        self.scope = {
            'addon': self.addon, 'config_helper': self.config,
            'logger': mock.Mock(),
            'xbmcgui': types.SimpleNamespace(Dialog=lambda: self.dialog),
            'xbmc': types.SimpleNamespace(getLocalizedString=lambda _id: ''),
            'persistSetting': self.addon.setSettingString,
            'persistBoolSetting': self.addon.setSettingBool,
            '_clearApplicationListCache': self.clear_cache,
            'retryApplications': mock.Mock(),
        }
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=functions, type_ignores=[])), 'addon.py', 'exec'),
            self.scope)

    def restore_module(self):
        if self.prior_module is None:
            sys.modules.pop(self.module.__name__, None)
        else:
            sys.modules[self.module.__name__] = self.prior_module

    def clear_cache(self):
        self.cache_clears += 1

    def reset_case(self):
        self.settings.clear()
        self.settings.update({'host_addr': 'host-A',
                              'pair_status_host': 'host-A',
                              'paired_state': 'true'})
        self.options.clear()
        self.options.update({'port': '48990',
                             'keydir': '/tmp/host-A-keys'})
        self.config.config['host_addr'] = 'host-A'
        self.unpaired.clear()
        self.forgot.clear()
        self.paired.clear()
        self.host_queries.clear()
        self.when_unpair = lambda: None
        self.when_forget = lambda: None
        self.cache_clears = 0
        self.dialog.reset_mock()
        self.dialog.yesno.side_effect = None
        self.dialog.yesno.return_value = True

    def assert_no_destructive_action(self):
        self.assertEqual(self.unpaired, [])
        self.assertEqual(self.forgot, [])
        self.assertEqual(self.paired, [])
        self.assertEqual(self.settings['pair_status_host'], 'host-A')
        self.assertEqual(self.settings['paired_state'], 'true')

    def test_address_changed_during_each_confirmation_cancels(self):
        for action in ('unpairHost', 'rePair', 'forgetTrustedServer'):
            with self.subTest(action=action):
                self.reset_case()
                def change(*args, **kwargs):
                    self.settings['host_addr'] = 'host-B'
                    return True
                self.dialog.yesno.side_effect = change
                self.assertFalse(self.scope[action]())
                self.assert_no_destructive_action()

    def test_port_or_keydir_changed_during_each_confirmation_cancels(self):
        for key, value in (('port', '48991'),
                           ('keydir', '/tmp/host-B-keys')):
            for action in ('unpairHost', 'rePair', 'forgetTrustedServer'):
                with self.subTest(option=key, action=action):
                    self.reset_case()
                    def change(*args, **kwargs):
                        self.options[key] = value
                        return True
                    self.dialog.yesno.side_effect = change
                    self.assertFalse(self.scope[action]())
                    self.assert_no_destructive_action()

    def test_cancellation_has_no_native_side_effects(self):
        for action in ('unpairHost', 'rePair', 'forgetTrustedServer'):
            with self.subTest(action=action):
                self.reset_case()
                self.dialog.yesno.return_value = False
                self.assertFalse(self.scope[action]())
                self.assert_no_destructive_action()

    def test_confirmation_passes_immutable_context_to_unpair_and_forget(self):
        for action in ('unpairHost', 'rePair', 'forgetTrustedServer'):
            with self.subTest(action=action):
                self.reset_case()
                self.assertTrue(self.scope[action]())
                target = self.unpaired if action != 'forgetTrustedServer' else self.forgot
                self.assertEqual(target, [('host-A', {
                    'port': '48990', 'keydir': '/tmp/host-A-keys'})])
                if action == 'rePair':
                    self.assertEqual(self.paired, [('host-A', {
                        'port': '48990', 'keydir': '/tmp/host-A-keys'})])
                self.assertEqual(self.settings['pair_status_host'], 'host-A')
                self.assertNotIn('host-B', self.host_queries)

    def test_host_changed_during_native_unpair_does_not_rewrite_new_status(self):
        for action in ('unpairHost', 'rePair'):
            with self.subTest(action=action):
                self.reset_case()
                self.when_unpair = lambda: self.settings.__setitem__(
                    'host_addr', 'host-B')
                result = self.scope[action]()
                self.assertEqual(result, action == 'unpairHost')
                self.assertEqual(self.unpaired[0][0], 'host-A')
                self.assertEqual(self.paired, [])
                self.assertEqual(self.settings['pair_status_host'], 'host-A')

    def test_host_changed_during_certificate_reset_does_not_rewrite_new_status(self):
        self.when_forget = lambda: self.settings.__setitem__(
            'host_addr', 'host-B')
        self.assertTrue(self.scope['forgetTrustedServer']())
        self.assertEqual(self.forgot[0][0], 'host-A')
        self.assertEqual(self.settings['pair_status_host'], 'host-A')


if __name__ == '__main__':
    unittest.main()
