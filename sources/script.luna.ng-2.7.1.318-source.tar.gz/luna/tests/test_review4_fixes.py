"""Endpoint isolation and bounded background work from the CoreELEC review."""
import ast
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch
import test_host_cache as fixture
sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))
import artwork_service as service
from resources.lib.util import hostcontext, hostapi, resumestate
from resources.lib.util.confighelper import ConfigHelper
from resources.lib.util.library import Library
from resources.lib.util.streamprofiles import StreamProfiles
from resources.lib.util.diagnosticreport import redact
from resources.lib.util.moonlighthelper import MoonlightHelper


class Review4Tests(unittest.TestCase):
    def test_custom_endpoints_isolate_state_and_default_keys_are_preserved(self):
        a, b = {'port': '48000'}, {'port': '49000'}
        with tempfile.TemporaryDirectory() as td:
            first = Library(td, 'pc', a); second = Library(td, 'pc', b)
            first.add_folder('Games'); first.assign('42', 'Games')
            self.assertIsNone(second.folder_of('42'))
            StreamProfiles(td, 'pc', a).set('42', 'desktop_4k60')
            self.assertIsNone(StreamProfiles(td, 'pc', b).get('42'))
            with patch.dict(os.environ, {'LUNA_RESUME_CONTEXT': first.host_key}):
                resumestate.set_last_run(Path(td, 'settings.xml'), 'Desktop', 'pc', '42')
            text = Path(td, 'settings.xml').read_text()
            self.assertIn(first.host_key, text); self.assertNotIn(second.host_key, text)
            self.assertEqual(hostcontext.host_identity(' PC '),
                             Library.host_identity('pc', {'port': '47989'}))

    def test_cache_request_and_artwork_capture_options_once(self):
        with tempfile.TemporaryDirectory() as td:
            h = MoonlightHelper.__new__(MoonlightHelper)
            h.config_helper = types.SimpleNamespace(
                config={'host_addr': 'pc'}, binary_path=td,
                host_options=Mock(side_effect=[{'port': '48000'}, {'port': '49000'}]))
            observed = []
            class Host:
                def __init__(self, address, **kw): observed.append(kw)
                def applist(self): return [('42', 'From A')]
            with patch.object(hostapi, 'Host', Host), patch.object(
                    service.xbmcvfs, 'translatePath', return_value=td, create=True):
                self.assertEqual(h.cached_games()[0][1], 'From A')
            self.assertEqual(observed[0]['http_port'], 48000)
            cache_key = hostcontext.host_identity('pc', {'port': '48000'})
            self.assertEqual(json.loads(Path(td, 'applist-' + cache_key + '.json').read_text())['host'],
                             cache_key)
            job = next(Path(td, 'artwork-jobs').glob('*.json'))
            self.assertEqual(json.loads(job.read_text())['host_options'], {'port': '48000'})
            h.config_helper.host_options.assert_called_once()

    def test_quit_borrows_exact_preflight_snapshot(self):
        with tempfile.TemporaryDirectory() as td:
            snapshot = Path(td, 'original.conf')
            snapshot.write_text('[Moonlight]\naddress=pc\nport=48000\n')
            h = MoonlightHelper.__new__(MoonlightHelper); h.logger = Mock()
            h.config_helper = types.SimpleNamespace(binary_path=td+'/', addon_path=td,
                    create_host_lookup_snapshot=Mock(side_effect=AssertionError('must not reload')))
            def run(command, **kw):
                self.assertEqual(command[-2:], ['-config', str(snapshot)])
                self.assertEqual(kw['env']['LUNA_STREAM_CONFIG'], str(snapshot))
                self.assertIn('port=48000', snapshot.read_text())
                return Mock(returncode=0)
            with patch('resources.lib.util.moonlighthelper.subprocess.run', side_effect=run):
                self.assertTrue(h.quit_game('pc', snapshot=str(snapshot)))
            self.assertTrue(snapshot.exists())

    def test_relative_keydir_and_native_snapshot_resolve_to_same_store(self):
        with tempfile.TemporaryDirectory() as td:
            c = ConfigHelper.__new__(ConfigHelper); c.binary_path=td+'/'
            c.config_path=str(Path(td, 'moonlight.conf')); c.config={'host_addr':'pc'}
            Path(c.config_path).write_text('[Moonlight]\naddress=pc\nkeydir=keys\nport=48000\n')
            h=MoonlightHelper.__new__(MoonlightHelper); h.config_helper=c
            self.assertEqual(h._host('pc').key_dir, str(Path(td, 'keys')))
            with h._native_host_command('unpair','pc') as (cmd, env):
                self.assertIn('keydir = '+str(Path(td,'keys')), Path(cmd[-1]).read_text())
                owned=cmd[-1]
            self.assertFalse(Path(owned).exists())

    def test_key_deletion_is_scoped_and_never_recursive(self):
        with tempfile.TemporaryDirectory() as td:
            a=Path(td,'active'); b=Path(td,'other'); a.mkdir(); b.mkdir()
            for root in (a,b):
                (root/'client.pem').write_text('credential')
                (root/'important.txt').write_text('keep')
            (a/'key.pem').symlink_to(b/'important.txt')
            self.assertEqual(hostcontext.remove_pairing_keys(str(a)),2)
            self.assertTrue((b/'client.pem').exists()); self.assertTrue((a/'important.txt').exists())
            self.assertEqual((b/'important.txt').read_text(),'keep')

    def test_custom_http_port_discovers_and_pins_remapped_https(self):
        hostapi._port_hints.clear()
        h=hostapi.Host('pc',http_port=48000,port=47995); h._spki_pin=b'pin'
        first=Mock(); first.connect.side_effect=ConnectionRefusedError()
        second=Mock(); second.getresponse.return_value=Mock(status=200,read=lambda n:b'ok')
        with patch.object(h,'_context'), patch.object(h,'_unique_id',return_value='a'*16), \
             patch.object(h,'_advertised_https_port',return_value=50000) as discover, \
             patch.object(hostapi,'spki_sha256',return_value=b'pin'), \
             patch.object(hostapi.httplib,'HTTPSConnection',side_effect=[first,second]) as conn:
            self.assertEqual(h._get('/serverinfo',[]),b'ok')
            self.assertEqual(conn.call_args.args[1],50000); discover.assert_called_once()
        hostapi._port_hints.clear()

    def test_repeated_requests_compact_without_resetting_backoff(self):
        with tempfile.TemporaryDirectory() as td:
            jobs=Path(td); key=hostcontext.host_identity('pc')
            work=jobs/(key+'.work')
            work.write_text(json.dumps({'host':'pc','ids':['1'],'host_options':{},'retry_at':9999999999}))
            for _ in range(100):
                (jobs/(key+'.json')).write_text('{"host":"pc","ids":["1"]}')
                service.compact_jobs(jobs)
            self.assertEqual(len(list(jobs.glob('*.work'))),1)
            self.assertEqual(json.loads(work.read_text())['retry_at'],9999999999)
            self.assertEqual(len(list(jobs.glob('*.json'))),0)

    def test_artwork_yields_and_keeps_new_generation_during_fetch(self):
        with tempfile.TemporaryDirectory() as td:
            jobs=Path(td); key=hostcontext.host_identity('pc'); work=jobs/(key+'.work')
            work.write_text(json.dumps({'host':'pc','ids':['1','2','3','4','5']}))
            seen=[]
            def fetch(address, app_id, **kw):
                seen.append(app_id)
                (jobs/(key+'.json')).write_text('{"host":"pc","ids":["6"],"refresh":true}')
                return '/image'
            monitor=Mock(abortRequested=lambda:False)
            with patch.object(MoonlightHelper,'_art_if_present',return_value=None), \
                 patch.object(MoonlightHelper,'boxart_path',side_effect=fetch), \
                 patch.object(service.xbmcaddon,'Addon',return_value=Mock(getSetting=lambda k:'other'),create=True):
                self.assertFalse(service.process_job(work,monitor))
            self.assertCountEqual(seen,['1','2','3'])
            service.compact_jobs(jobs)
            payload=json.loads(work.read_text())
            self.assertEqual(payload['ids'],['4','5','6']); self.assertTrue(payload['refresh'])

    def test_resume_supplies_captured_connection_guard(self):
        tree=ast.parse((Path(__file__).parents[1]/'addon.py').read_text())
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='resume')
        key=hostcontext.host_identity('pc',{'port':'48000'})
        scope={'_active_resume_session':lambda:('Game','pc','42',key),
               'addon':Mock(getLocalizedString=lambda k:''),'config_helper':Mock(),'logger':Mock(),
               'xbmcgui':Mock(),'xbmc':Mock()}
        scope['xbmcgui'].Dialog.return_value.yesno.return_value=True
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'addon.py','exec'),scope)
        with patch('resources.lib.util.moonlighthelper.MoonlightHelper') as cls:
            scope['resume']()
            self.assertEqual(cls.return_value.launch_game.call_args.kwargs['expected_host'],key)

    def test_known_log_hostname_is_removed(self):
        line=redact('LUNA applications: gaming-pc: [Errno 111] Connection refused')
        self.assertNotIn('gaming-pc',line); self.assertIn('Connection refused',line)
