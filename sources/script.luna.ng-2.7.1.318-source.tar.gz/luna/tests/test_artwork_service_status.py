"""Exercise Luna's live-status service callback without booting Kodi."""
import ast
from pathlib import Path
import threading
import time
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


class HostServiceWiringTests(unittest.TestCase):
    def test_artwork_service_runs_one_coordinator_for_any_settings_entry(self):
        service = (ROOT / 'artwork_service.py').read_text(encoding='utf-8')
        plugin = (ROOT / 'addon.py').read_text(encoding='utf-8')
        self.assertIn("status = live_host_status_coordinator()", service)
        self.assertIn("status.tick()", service)
        self.assertIn("status.stop(timeout=0.2)", service)
        self.assertIn("Window.IsActive(addonsettings)", service)
        self.assertIn("getProperty('Addon.ID') == 'script.luna.ng'", service)
        self.assertIn("threading.Thread(", service)
        self.assertIn("target=_status_tick_loop", service)
        self.assertIn("status_thread is not None and not status_thread.is_alive()", service)
        self.assertIn("status_thread = None", service)
        self.assertIn("status_thread.join(timeout=1)", service)
        self.assertIn("refresh_seconds=8", service)
        self.assertIn("prepare_probe=prepare_host", service)
        self.assertIn("ServiceHeartbeat", service)
        self.assertIn("from resources.lib.util.settingsstore import update_settings", service)
        self.assertNotIn("LiveHostStatusWatcher", plugin)

    def test_status_ticker_is_responsive_during_blocked_artwork(self):
        # Run the real ticker function extracted from the service; simulate
        # artwork blocking independently instead of relying on wall-clock
        # timing of a live Sunshine HTTP request.
        source = ast.parse((ROOT / 'artwork_service.py').read_text(encoding='utf-8'))
        selected = [node for node in source.body
                    if isinstance(node, ast.FunctionDef) and node.name in (
                        '_status_tick_with_heartbeat', '_status_shutdown_heartbeat',
                        '_status_tick_loop')]
        self.assertEqual(len(selected), 3)
        properties = {}
        home = types.SimpleNamespace(
            setProperty=lambda key, value: properties.__setitem__(key, value),
            clearProperty=lambda key: properties.pop(key, None))
        scope = {
            'xbmc': types.SimpleNamespace(log=lambda *_: None, LOGWARNING=2),
            'xbmcgui': types.SimpleNamespace(Window=lambda _id: home),
            'time': time,
        }
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=selected, type_ignores=[])),
            'artwork_service.py', 'exec'), scope)
        stop = threading.Event()
        ticks = []
        status = types.SimpleNamespace(tick=lambda: ticks.append(time.monotonic()))
        monitor = types.SimpleNamespace(abortRequested=lambda: False)
        # This thread represents an artwork fetch stalled on its own network.
        blocked = threading.Event()
        artwork = threading.Thread(target=lambda: blocked.wait(2), daemon=True)
        status_thread = threading.Thread(
            target=scope['_status_tick_loop'], args=(status, monitor, stop),
            daemon=True)
        artwork.start()
        status_thread.start()
        try:
            deadline = time.monotonic() + 1.5
            while len(ticks) < 2 and time.monotonic() < deadline:
                time.sleep(0.02)
            self.assertTrue(artwork.is_alive())
            self.assertGreaterEqual(len(ticks), 2)
        finally:
            stop.set()
            blocked.set()
            status_thread.join(timeout=1)
            artwork.join(timeout=1)
        self.assertFalse(status_thread.is_alive())
        self.assertNotIn('Luna.Status.ServiceHeartbeat', properties)
        self.assertEqual(properties['Luna.Status.ServiceHealth'], 'stopped')

    def test_error_heartbeat_is_invalidated_and_fallback_reports_health(self):
        source = ast.parse((ROOT / 'artwork_service.py').read_text(encoding='utf-8'))
        helpers = [node for node in source.body
                   if isinstance(node, ast.FunctionDef)
                   and node.name == '_status_tick_with_heartbeat']
        scope = {'xbmc': types.SimpleNamespace(
            LOGWARNING=2, log=lambda *_: None), 'time': time}
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=helpers, type_ignores=[])),
            'artwork_service.py', 'exec'), scope)
        props = {}
        home = types.SimpleNamespace(
            getProperty=lambda key: props.get(key, ''),
            setProperty=lambda key, value: props.__setitem__(key, value),
            clearProperty=lambda key: props.pop(key, None))
        running = mock.Mock(tick=lambda: None)
        broken = mock.Mock(tick=lambda: (_ for _ in ()).throw(RuntimeError('boom')))
        tick = scope['_status_tick_with_heartbeat']
        self.assertTrue(tick(running, home, 'fallback'))
        self.assertEqual(props['Luna.Status.ServiceHealth'], 'ready')
        self.assertIn('Luna.Status.ServiceHeartbeat', props)
        self.assertFalse(tick(broken, home, 'ticker'))
        self.assertEqual(props['Luna.Status.ServiceHealth'], 'error')
        self.assertNotIn('Luna.Status.ServiceHeartbeat', props)
        self.assertTrue(tick(running, home, 'fallback'))
        self.assertEqual(props['Luna.Status.ServiceHealth'], 'ready')
        self.assertIn('Luna.Status.ServiceHeartbeat', props)

    def test_service_status_write_never_replaces_host_address(self):
        source = ast.parse((ROOT / 'artwork_service.py').read_text(encoding='utf-8'))
        selected = [node for node in source.body
                    if isinstance(node, ast.FunctionDef)
                    and node.name == 'live_host_status_coordinator']
        self.assertEqual(len(selected), 1)
        values = {'host_addr': '10.0.0.60', 'paired_state': 'false'}
        stored = []
        writer = mock.Mock()
        ui_open = [True]
        active_addon = ['script.luna.ng']
        open_token = ['first']
        props = {'Luna.Status.PendingToken': '',
                 'Luna.Status.PendingHost': '',
                 'Luna.Status.CompletedToken': ''}
        logs = []
        context_options = {}

        class Addon:
            def getSetting(self, name):
                return values.get(name, '')
            def getLocalizedString(self, _ident):
                return ''
            def setSettingString(self, name, value):
                values[name] = value
            def setSettingBool(self, name, value):
                values[name] = 'true' if value else 'false'

        fake_addon = Addon()
        def factory(reader, active, check, publish, log_error=None,
                    read_revision=None, refresh_seconds=45,
                    prepare_probe=None, read_pending=None,
                    acknowledge_pending=None, read_identity=None):
            return types.SimpleNamespace(read=reader, active=active,
                                         check=check, publish=publish,
                                         log_error=log_error,
                                         revision=read_revision,
                                         refresh_seconds=refresh_seconds,
                                         prepare_probe=prepare_probe,
                                         identity=read_identity,
                                         pending=read_pending,
                                         acknowledge=acknowledge_pending)
        state = {
            'xbmcaddon': types.SimpleNamespace(Addon=lambda *_: fake_addon),
            'xbmc': types.SimpleNamespace(
                getCondVisibility=lambda _condition: ui_open[0],
                log=lambda *args: logs.append(args), LOGWARNING=2),
            'xbmcgui': types.SimpleNamespace(Window=lambda ident:
                types.SimpleNamespace(
                    getProperty=lambda key:
                        active_addon[0] if ident == 10140 and key == 'Addon.ID' else
                        open_token[0] if ident == 10000 and
                        key == 'Luna.Status.OpenToken' else props.get(key, ''),
                    setProperty=lambda key, value: props.__setitem__(key, value),
                    clearProperty=lambda key: props.__setitem__(key, ''))),
            'xbmcvfs': types.SimpleNamespace(
                translatePath=lambda path: '/test-luna/settings.xml'),
            'ServiceStatusCoordinator': factory,
            'probe_pairing_state': lambda _host: 'paired',
            'update_settings': lambda path, updates:
                stored.append((path, dict(updates))),
            'Logger': mock.Mock,
            'ConfigHelper': lambda *_: types.SimpleNamespace(
                config_error=None, host_options=lambda: dict(context_options)),
            'MoonlightHelper': mock.Mock,
        }
        tree = ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[]))
        exec(compile(tree, 'artwork_service.py', 'exec'), state)
        status = state['live_host_status_coordinator']()
        self.assertTrue(status.active())
        self.assertEqual(status.revision(), 'first')
        self.assertEqual(status.refresh_seconds, 8)
        self.assertTrue(callable(status.prepare_probe))
        self.assertTrue(callable(status.identity))
        self.assertIs(status.check, state['probe_pairing_state'])
        status.log_error('TimeoutError')
        self.assertIn('TimeoutError', logs[-1][0])
        self.assertNotIn('status: str', logs[-1][0])
        status.publish('10.0.0.60', 'paired')
        self.assertEqual(values['host_addr'], '10.0.0.60')
        self.assertEqual(values['pair_status_host'], '10.0.0.60')
        self.assertEqual(values['paired_state'], 'true')
        self.assertIn('Paired', values['pair_status_display'])
        # Kodi owns the live settings modal. Do not race its eventual save
        # with an out-of-band settings.xml replacement while it is open.
        self.assertEqual(len(stored), 0)
        self.assertEqual(values['host_addr'], '10.0.0.60')
        # Same host: rechecking must not hide previously verified actions.
        status.publish('10.0.0.60', 'checking')
        self.assertEqual(values['paired_state'], 'true')
        self.assertEqual(len(stored), 0)
        # Same IP but a new native port must never retain the old trust
        # identity or previously verified paired flag while checking.
        initial_context = values['pair_status_context']
        context_options['port'] = '48089'
        status.publish('10.0.0.60', 'checking')
        self.assertEqual(values['paired_state'], 'false')
        self.assertNotEqual(values['pair_status_context'], initial_context)
        context_options.clear()
        status.publish('10.0.0.60', 'paired')
        # A genuinely different host cannot reuse the prior paired flag.
        values['host_addr'] = '10.0.0.61'
        status.publish('10.0.0.61', 'checking')
        self.assertEqual(values['paired_state'], 'false')
        values['host_addr'] = '10.0.0.60'
        status.publish('10.0.0.60', 'identity_changed')
        self.assertEqual(values['paired_state'], 'false')
        self.assertIn('identity changed', values['pair_status_display'])
        # Post-close acknowledgement is the safe moment to serialize the
        # status on disk. It must not rewrite host_addr.
        props['Luna.Status.PendingToken'] = 'closed-dialog-1'
        props['Luna.Status.PendingHost'] = '10.0.0.60'
        ui_open[0] = False
        status.publish('10.0.0.60', 'paired')
        self.assertEqual(len(stored), 1)
        self.assertEqual(set(stored[0][1]), {
            'pair_status_host', 'pair_status_context',
            'pair_status_display', 'paired_state'})
        self.assertEqual(values['host_addr'], '10.0.0.60')
        baseline = len(stored)
        props['Luna.Status.PendingToken'] = ''
        status.publish('10.0.0.60', 'unavailable')
        self.assertEqual(len(stored), baseline)
        ui_open[0] = True
        status.publish('10.0.0.59', 'paired')
        self.assertEqual(len(stored), baseline)
        active_addon[0] = 'plugin.video.unrelated'
        self.assertFalse(status.active())
        status.publish('10.0.0.60', 'unavailable')
        self.assertEqual(len(stored), baseline)
        active_addon[0] = 'script.luna.ng'
        self.assertTrue(status.active())
        # The exact address may be checked after Settings has closed.
        ui_open[0] = False
        props['Luna.Status.PendingToken'] = 'request-3'
        props['Luna.Status.PendingHost'] = '10.0.0.60'
        self.assertEqual(status.pending(), ('request-3','10.0.0.60',''))
        status.publish('10.0.0.60', 'paired')
        self.assertEqual(len(stored), baseline + 1)
        status.acknowledge('request-3', '10.0.0.60')
        self.assertEqual(props['Luna.Status.CompletedToken'], 'request-3')
        self.assertEqual(props['Luna.Status.PendingToken'], 'request-3')
        self.assertEqual(props['Luna.Status.PendingHost'], '10.0.0.60')
        self.assertEqual(status.pending(), ('','',''))
        status.publish('10.0.0.60', 'unavailable')
        self.assertEqual(len(stored), baseline + 1)
        # Race: a fresh settings invocation writes its own host/token while
        # an older request is being acknowledged. The older acknowledgement
        # must NEVER clear the new request's properties.
        props['Luna.Status.PendingHost'] = '10.0.0.61'
        props['Luna.Status.PendingToken'] = 'request-4'
        status.acknowledge('request-3', '10.0.0.60')
        self.assertEqual(status.pending(), ('request-4', '10.0.0.61', ''))
        self.assertEqual(props['Luna.Status.CompletedToken'], 'request-3')


if __name__ == '__main__':
    unittest.main()
