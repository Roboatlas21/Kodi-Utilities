"""Bounded state readers must not follow paths or block Kodi on FIFOs."""
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest import mock

from resources.lib.util import safejson


class SafeJsonFileTests(unittest.TestCase):
    def test_missing_and_valid_json(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'state.json'
            with self.assertRaises(FileNotFoundError):
                safejson.read_bounded_json(path, 1000)
            path.write_text('{"host":"one"}', encoding='utf-8')
            obj, metadata = safejson.read_bounded_json(path, 1000, with_stat=True)
            self.assertEqual(obj, {'host': 'one'})
            self.assertEqual(metadata.st_ino, path.stat().st_ino)
            self.assertEqual(safejson.read_bounded_json(path, 1000), obj)

    def test_symlinks_directories_corruption_and_size_limits(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / 'protected.json'
            target.write_text('{"protected":true}')
            source = root / 'state.json'
            source.symlink_to(target)
            with self.assertRaises(safejson.UnsafeJsonFile):
                safejson.read_bounded_json(source, 100)
            source.unlink()
            source.symlink_to('absent.json')
            with self.assertRaises(safejson.UnsafeJsonFile):
                safejson.read_bounded_json(source, 100)
            source.unlink()
            source.mkdir()
            with self.assertRaises(safejson.UnsafeJsonFile):
                safejson.read_bounded_json(source, 100)
            source.rmdir()
            source.write_bytes(b' ' * 101)
            with self.assertRaises(safejson.UnsafeJsonFile):
                safejson.read_bounded_json(source, 100)
            source.write_text('{broken', encoding='utf-8')
            with self.assertRaises(safejson.UnsafeJsonFile):
                safejson.read_bounded_json(source, 100)
            self.assertEqual(target.read_text(), '{"protected":true}')

    def test_deep_nesting_is_corruption_not_unhandled_recursion(self):
        import sys
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'state.json'
            depth = sys.getrecursionlimit() + 128
            data = '[' * depth + '0' + ']' * depth
            path.write_text(data)
            with self.assertRaises(safejson.UnsafeJsonFile):
                safejson.read_bounded_json(path, 1024 * 1024)
            self.assertEqual(path.read_text(), data)

    def test_explicit_json_depth_limit_and_quoted_brackets(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'state.json'
            limit = safejson.MAX_JSON_NESTING
            path.write_text('[' * limit + '0' + ']' * limit)
            self.assertIsInstance(safejson.read_bounded_json(path, 1024), list)

            for payload in (
                '[' * (limit + 1) + '0' + ']' * (limit + 1),
                '{"item":' * (limit + 1) + 'null' + '}' * (limit + 1),
            ):
                path.write_text(payload)
                with self.assertRaisesRegex(safejson.UnsafeJsonFile,
                                            'nesting exceeds safe limit'):
                    safejson.read_bounded_json(path, 2048)

            # Even escaped quotes and thousands of brackets inside strings
            # are scalar data, not nested JSON containers.
            scalar = {'literal': '[{]' * 512, 'escaped': 'quote " and \\ backslash'}
            path.write_text(json.dumps(scalar), encoding='utf-8')
            self.assertEqual(safejson.read_bounded_json(path, 8192), scalar)

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_fifo_without_writer_does_not_hang_the_reader(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'pipe.json'
            os.mkfifo(path)
            errors = []
            def read_pipe():
                try:
                    safejson.read_bounded_json(path, 1024)
                except BaseException as exc:
                    errors.append(exc)
            worker = threading.Thread(target=read_pipe, daemon=True)
            worker.start()
            worker.join(timeout=2)
            self.assertFalse(worker.is_alive(), 'Opening an unwritten FIFO blocked')
            self.assertEqual(len(errors), 1)
            self.assertIsInstance(errors[0], safejson.UnsafeJsonFile)

    def test_renamed_path_cannot_mix_old_json_with_new_mtime(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'state.json'
            incoming = Path(td) / 'incoming.json'
            path.write_text('{"revision":"old"}')
            original_time = int(time.time()) - 500
            os.utime(path, (original_time, original_time))
            incoming.write_text('{"revision":"new"}')
            original_open = os.open
            def replace_after_open(name, flags, *args, **kwargs):
                fd = original_open(name, flags, *args, **kwargs)
                os.replace(incoming, path)
                return fd
            with mock.patch.object(safejson.os, 'open',
                                   side_effect=replace_after_open):
                obj, metadata = safejson.read_bounded_json(
                    path, 1024, with_stat=True)
            self.assertEqual(obj, {'revision': 'old'})
            self.assertEqual(metadata.st_mtime, original_time)
            self.assertEqual(json.loads(path.read_text()), {'revision': 'new'})

    def test_growth_after_fstat_remains_bounded(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'state.json'
            path.write_text('{"small":true}')
            original_fstat = os.fstat
            def grow_after_size_check(fd):
                metadata = original_fstat(fd)
                with open(path, 'ab') as out:
                    out.write(b' ' * 2048)
                return metadata
            with mock.patch.object(safejson.os, 'fstat',
                                   side_effect=grow_after_size_check):
                with self.assertRaises(safejson.UnsafeJsonFile):
                    safejson.read_bounded_json(path, 128)


if __name__ == '__main__':
    unittest.main()
