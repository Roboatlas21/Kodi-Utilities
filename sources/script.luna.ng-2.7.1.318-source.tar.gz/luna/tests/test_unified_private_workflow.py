"""Static regression checks for the public-to-private CI feature migration."""
from pathlib import Path
import unittest
import json
import subprocess
import textwrap

ROOT = Path(__file__).resolve().parents[1]
UNIFIED = ROOT / ".github/workflows/unified-luna-ng.yml"
PACKAGE = ROOT / ".github/workflows/build-luna-ng.yml"
VALIDATOR = ROOT / "packaging/validate_private.sh"


class UnifiedWorkflowTests(unittest.TestCase):
    def test_moonlight_candidate_budget_and_comparison_cache(self):
        source = UNIFIED.read_text()
        start = source.index('          find_moonlight_artifact() {')
        end = source.index('          # Reusable Moonlight calls', start)
        selector = textwrap.dedent(source[start:end])
        sha = 'a' * 40
        old = 'b' * 40
        def run(rows, compatibility, artifact):
            fixture = json.dumps({'workflow_runs': [dict(
                id=i, display_title='CoreELEC21-NG source='+built+' correlation=test',
                status='completed', conclusion='success', head_branch='feat/coreelec-ng')
                for i, built in rows]})
            script = selector + "\nsource_repo=fixture; sha=" + sha + "\n"
            script += "paginated_listing() { cat <<'JSON'\n" + fixture + "\nJSON\n}\n"
            script += 'compatible_source() { ' + compatibility + '; }\n'
            script += 'artifact_ready() { ' + artifact + '; }\nfind_moonlight_artifact'
            return subprocess.run(['bash', '-euo', 'pipefail'], input=script,
                                  text=True, capture_output=True, timeout=5)
        repeated = run([(i, old) for i in range(50)], 'echo compare >&2; return 1', 'return 1')
        self.assertEqual(repeated.returncode, 1)
        self.assertEqual(repeated.stderr.count('compare'), 1)
        self.assertIn('budget exhausted', repeated.stderr)
        exact = run([(i, sha) for i in range(50)], 'return 1', 'echo artifact >&2; return 1')
        self.assertEqual(exact.stderr.count('artifact\n'), 10)
        self.assertIn('budget exhausted', exact.stderr)
        timed = run([(1, old), (2, old)], 'SECONDS=$((SECONDS + 181)); return 0',
                    'echo unexpected >&2; return 0')
        self.assertEqual(timed.returncode, 1)
        self.assertNotIn('unexpected', timed.stderr)
        priority = run([(1, old), (2, sha)], 'echo unexpected >&2; return 0', 'return 0')
        self.assertEqual(priority.returncode, 0, priority.stderr)
        self.assertEqual(priority.stdout.strip(), '2|'+sha+'|fixture')
        self.assertNotIn('unexpected', priority.stderr)

    def test_build_entry_guard_before_checkout(self):
        import os
        source = UNIFIED.read_text()
        start = source.index('      - name: Require the matrix launcher for builds')
        end = source.index('      - name: Check out exact private Luna', start)
        block = source[start:end]
        self.assertIn('if: ${{ !inputs.validate_only }}', block)
        script = textwrap.dedent(block.split('        run: |\n', 1)[1])
        for ref, event, expected in (
                ('matrix', 'workflow_dispatch', 0),
                ('feat/vortex-ng', 'workflow_dispatch', 1),
                ('matrix', 'push', 1)):
            env = dict(os.environ, GITHUB_REPOSITORY='Roboatlas21/Luna',
                       GITHUB_EVENT_NAME=event,
                       WORKFLOW_REF='Roboatlas21/Luna/.github/workflows/unified-luna-ng.yml@refs/heads/'+ref)
            result = subprocess.run(['bash'], input=script, env=env,
                                    text=True, capture_output=True, timeout=5)
            self.assertEqual(result.returncode, expected, result.stderr)
        self.assertIn('jobs?filter=all&per_page=100', source)

    def test_artifact_discovery_paginates_and_bounds_search(self):
        source = UNIFIED.read_text()
        start = source.index('          paginated_listing() {')
        end = source.index('          artifact_ready() {', start)
        helper = textwrap.dedent(source[start:end])
        # Run the actual workflow shell functions with deterministic API pages.
        runs = [{'id': i, 'display_title': 'unrelated', 'payload': 'x' * 2048, 'status': 'completed',
                 'conclusion': 'success', 'head_branch': 'feat/coreelec-ng'}
                for i in range(100)]
        sha = 'a' * 40
        match = dict(id=321, display_title='CoreELEC21-NG source='+sha+' correlation=test',
                     status='completed', conclusion='success', head_branch='feat/coreelec-ng')
        first = json.dumps({'workflow_runs': runs})
        second = json.dumps({'workflow_runs': [match]})
        fixture = """
repo_api() {
  case "$2" in
    *page=1) cat <<'FIRST'
%s
FIRST
;;
    *page=2) cat <<'SECOND'
%s
SECOND
;;
    *) return 2;;
  esac
}
""" % (first, second)
        start = source.index('          find_moonlight_artifact() {')
        end = source.index('          # Reusable Moonlight calls', start)
        selector = textwrap.dedent(source[start:end])
        setup = 'source_repo=fixture; sha='+sha+'; artifact_ready() { [[ "$2" == 321 ]]; }; compatible_source() { return 1; };\n'
        def run(script):
            return subprocess.run(['bash', '-euo', 'pipefail'], input=script,
                                  capture_output=True, text=True, timeout=10)
        result = run(helper+fixture+selector+setup+'find_moonlight_artifact')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), '321|'+sha+'|fixture')
        limited = run(helper+fixture+selector+setup+
                      'ARTIFACT_SEARCH_MAX_PAGES=1; find_moonlight_artifact')
        self.assertEqual(limited.returncode, 1)
        self.assertIn('budget exhausted', limited.stderr)
        self.assertFalse(limited.stdout)
        error = run(helper+'repo_api() { return 1; }; paginated_listing repo "endpoint?" artifacts')
        self.assertEqual(error.returncode, 1)
        self.assertIn('API failed', error.stderr)
        empty = run(helper+"repo_api() { echo '{\"artifacts\":[]}'; }; paginated_listing repo 'endpoint?' artifacts")
        self.assertEqual(empty.returncode, 0, empty.stderr)
        self.assertEqual(json.loads(empty.stdout), {'artifacts': []})
        # Luna's artifact collection uses the same helper and still excludes
        # expired artifacts before checking native jobs and provenance.
        self.assertIn('paginated_listing "$caller_repo" "repos/$caller_repo/actions/artifacts?" artifacts', source)
        self.assertIn('.expired == false and .size_in_bytes > 0', source)

    def test_private_workflow_is_manual_and_keeps_publishing_separate(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("  workflow_dispatch:", source)
        self.assertIn("  workflow_call:", source)
        self.assertNotIn("  push:", source)
        self.assertIn("  queue: max", source)
        self.assertIn("  queue: max", PACKAGE.read_text())
        self.assertNotIn("repository: Roboatlas21/xbmc-p3i", source)
        self.assertNotIn("repository: Roboatlas21/Luna-build", source)
        self.assertNotIn("git push ", source)
        self.assertNotIn("publish: true", source)

    def test_all_validation_groups_run_before_native_dispatch(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("  preflight:", source)
        self.assertIn("  select-native:\n    needs: preflight", source)
        for group in ("source", "host", "vfm", "audio"):
            self.assertIn(f"bash tests/validate_private_source.sh {group}",
                          source)
        for group in ("luna-python", "luna-launch", "luna-packaging"):
            self.assertIn(f"bash packaging/validate_private.sh {group}",
                          source)
        self.assertIn("luna-ng-private-validation-logs", source)
        self.assertIn("LUNA_PRIVATE_CHECKOUT:", source)
        self.assertIn("tests/validate_private_source.sh extras", source)
        self.assertIn("steps.moonlight_extra_tests.outcome", source)
        self.assertGreaterEqual(source.count("continue-on-error: true"), 8)
        self.assertIn("Report all validation groups and block unverified ARM32 builds",
                      source)

    def test_diagnostics_only_never_dispatches_native(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("validate_only:", source)
        self.assertIn("if: ${{ !inputs.validate_only }}", source)

    def test_exact_source_pair_is_checked_and_packaged(self):
        source = UNIFIED.read_text(encoding="utf-8")
        packaged = PACKAGE.read_text(encoding="utf-8")
        self.assertIn("PREFLIGHT_MOONLIGHT_SHA", source)
        self.assertIn('[[ "$sha" == "$PREFLIGHT_MOONLIGHT_SHA" ]]',
                      source)
        self.assertIn("luna_ref: ${{ needs.preflight.outputs.luna_sha }}",
                      source)
        self.assertIn("ref: ${{ inputs.luna_ref || 'feat/vortex-ng' }}",
                      packaged)
        self.assertIn("ref: ${{ steps.native.outputs.sha }}", packaged)
        self.assertIn("expected_native_sha: ${{ needs.select-native.outputs.native_sha }}",
                      source)
        self.assertIn("native_reuse_policy.py", source)
        self.assertIn("steps.select.outputs.native_sha", source)

    def test_rebuild_dispatches_moonlight_cache_owner_then_exits_without_polling(self):
        source = UNIFIED.read_text(encoding="utf-8")
        for expected in (
                'repos/$source_repo/actions/workflows/coreelec-ng-native.yml/dispatches',
                'inputs[native_source_sha]=$sha',
                'inputs[dispatch_correlation]=$correlation',
                'inputs[continue_luna_publish]=$PUBLISH',
                'inputs[build_vfm_runtime]=$REQUIRE_VFM',
                'reused=deferred',
                'run_id=$RUN_ID',
                'resume_luna_run_id:',
                'resume_native_run_id:',
                'python3 luna/packaging/native_reuse_policy.py',
                'compatible_source "$built"',
                'require_latest_moonlight: false',
                'find_luna_artifact()',
                'find_moonlight_artifact()'):
            self.assertIn(expected, source)
        self.assertNotIn('  native-rebuild:', source)
        self.assertNotIn('sleep 180', source)
        self.assertNotIn('Following Moonlight run', source)
        self.assertNotIn('uses: Roboatlas21/moonlight-embedded/.github/workflows/coreelec-ng-native.yml', source)

    def test_immutable_request_is_uploaded_only_after_full_preflight(self):
        source = UNIFIED.read_text(encoding="utf-8")
        for expected in (
                'Upload immutable native continuation approval',
                'if: ${{ success() && !inputs.validate_only && !inputs.resume_luna_run_id }}',
                'name: luna-ng-native-request',
                'origin_run_attempt',
                '"publish_to_kodi": os.environ["PUBLISH"] == "true"',
                '"include_vfm_runtime": os.environ["VFM"] == "true"',
                'python3 luna/packaging/verify_native_continuation.py',
                'steps.resume_proof.outputs.native_run_id',
                'needs.select-native.outputs.reused == \'true\''):
            self.assertIn(expected, source)
        self.assertIn("  workflow_call:", source)

    def test_pinned_native_provenance_is_checked_again_during_packaging(self):
        source = PACKAGE.read_text(encoding="utf-8")
        for expected in (
                'expected_native_sha:', 'EXPECTED_NATIVE_SHA',
                'run.get("display_title")', 'stamped.group(1) != sha',
                'expected != sha', 'manifest.get("source_git_sha")'):
            self.assertIn(expected, source)
        self.assertNotIn('run["head_branch"] == "feat/coreelec-ng" and run["head_sha"] != sha',
                         source)

    def test_package_reuses_only_exact_trusted_luna_preflight(self):
        unified = UNIFIED.read_text(encoding='utf-8')
        package = PACKAGE.read_text(encoding='utf-8')
        self.assertIn('needs: [preflight, select-native]', unified)
        self.assertIn("needs.select-native.outputs.reused == 'true'", unified)
        self.assertIn('preflight_validated_sha: ${{ needs.preflight.outputs.luna_sha }}', unified)
        self.assertIn('Luna preflight reuse requires a trusted caller', package)
        self.assertIn("steps.luna_validation.outputs.reused != 'true'", package)
        self.assertIn('Run complete Luna Python, Kodi launcher and watchdog tests', package)
        self.assertIn('bash tests/test_launch.sh', package)
        self.assertIn('github.workflow_ref', package)
        self.assertIn('native_artifact_repository:', package)

    def test_caller_owned_native_artifact_requires_successful_native_jobs(self):
        package = PACKAGE.read_text(encoding='utf-8')
        for required in (
                'ARTIFACT_REPO', 'GITHUB_RUN_ID',
                'Reusable native preparation and compilation did not complete successfully',
                'contains("native-rebuild /")',
                'endswith("/ prepare")', 'endswith("/ native")',
                'Roboatlas21/moonlight-embedded',
                'gh run download "$RUN_ID" -R "$ARTIFACT_REPO"',
                'manifest.get("source_git_sha")'):
            self.assertIn(required, package)

    def test_launcher_expected_exit_codes_do_not_emit_assertion_failure(self):
        import re
        launcher = (ROOT / "tests/test_launch.sh").read_text(encoding="utf-8")
        self.assertIn('LUNA_ASSERTION_FAILURE', launcher)
        self.assertIn('if sh "$launcher" Desktop >"$tmp/out" 2>&1; then', launcher)
        self.assertGreaterEqual(launcher.count(
            'if sh "$launcher" Desktop >"$tmp/out" 2>&1; then'), 10)
        self.assertNotRegex(
            launcher,
            r'(?m)^\s*sh "\$launcher" Desktop >\s*"\$tmp/out" 2>&1\n\s*status=\$\?')
        self.assertIn('[[ "$status" == 42 ]]', launcher)
        self.assertIn('[[ "$status" == 127 ]]', launcher)
        self.assertIn('[[ "$status" == 124 ]]', launcher)

    def test_luna_groups_record_logs_and_failure_counts(self):
        source = VALIDATOR.read_text(encoding="utf-8")
        for group in ("luna-python", "luna-launch", "luna-packaging"):
            self.assertIn(group + ")", source)
        self.assertIn("SOURCE_CHECK_FAIL", source)
        self.assertIn("test_aml_recovery.sh", source)
        self.assertIn("resources/lib/util/resumestate.py", source)
        self.assertIn("resources/lib/util/hdmigamemode.py", source)
        self.assertIn("results.tsv", source)
        self.assertIn("if (( failures )); then", source)


if __name__ == "__main__":
    unittest.main()
