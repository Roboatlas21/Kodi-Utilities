"""Fault cases from the third CoreELEC review; no Kodi or network required."""
import ast
import errno
import json
import os
import socket
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
import test_host_cache as fixture
sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))
import artwork_service as service
from resources.lib.util import hostresolve, safejson, confighelper, hdmimode, runtimecheck

class Review3Tests(unittest.TestCase):
    def test_successful_connect_restores_request_timeout(self):
        answers = [[socket.AF_INET,socket.SOCK_STREAM,6,'',['127.0.0.1',443]]] * 20
        connection = Mock(); hostresolve._cache.clear()
        with patch.object(hostresolve.subprocess,'run',return_value=Mock(stdout=json.dumps(answers))), patch.object(hostresolve.socket,'socket',return_value=connection):
            self.assertIs(hostresolve.connect(('host',443),timeout=4),connection)
        self.assertLess(connection.settimeout.call_args_list[0].args[0],0.21)
        self.assertEqual(connection.settimeout.call_args.args[0],4)

    def run_worker(self, root, selected_host='a'):
        # This suite exercises artwork queue recovery, not Kodi's settings
        # constructor or its independent live-status ticker. Use an exact,
        # valid selected host context so obsolete-host filtering stays ON.
        monitor=Mock();monitor.abortRequested.return_value=False;monitor.waitForAbort.return_value=True
        addon=Mock(getSetting=lambda key: selected_host if key=='host_addr' else '')
        config=types.SimpleNamespace(config_error=None, host_options=lambda: {})
        with patch.object(service.xbmcvfs,'translatePath',return_value=str(root),create=True), \
             patch.object(service.xbmc,'Monitor',return_value=monitor,create=True), \
             patch.object(service.xbmc,'getInfoLabel',return_value='',create=True), \
             patch.object(service.xbmcgui,'Window',return_value=Mock(),create=True), \
             patch.object(service.xbmcaddon,'Addon',return_value=addon,create=True), \
             patch.object(service,'ConfigHelper',return_value=config), \
             patch.object(service,'live_host_status_coordinator',return_value=Mock()):
            service.run()

    def test_malformed_job_does_not_kill_valid_successor(self):
        with tempfile.TemporaryDirectory() as td:
            jobs=Path(td,'artwork-jobs');jobs.mkdir()
            (jobs/'a.work').write_text('[]');(jobs/'b.work').write_text('{"host":"b","ids":[]}')
            with patch.object(service,'process_job',return_value=True) as process:self.run_worker(td, 'b')
            self.assertEqual(process.call_count,1)
            self.assertEqual(list(jobs.glob('*.work')),[])

    def test_temporary_open_failure_retains_valid_work(self):
        with tempfile.TemporaryDirectory() as td:
            jobs=Path(td,'artwork-jobs');jobs.mkdir();job=jobs/'a.work'
            job.write_text('{"host":"a","ids":["1"]}')
            real_open=os.open
            def fail_job(path,*args,**kw):
                if os.fspath(path)==str(job):raise OSError(errno.EMFILE,'temporary')
                return real_open(path,*args,**kw)
            with patch.object(safejson.os,'open',side_effect=fail_job):self.run_worker(td)
            self.assertEqual(json.loads(job.read_text())['ids'],['1'])

    def test_permanent_old_failure_does_not_starve_new_job(self):
        with tempfile.TemporaryDirectory() as td:
            jobs=Path(td,'artwork-jobs');jobs.mkdir()
            for name,ident in [('a.work','1'),('a.json','2')]:
                (jobs/name).write_text(json.dumps({'host':'a','ids':[ident]}))
            seen=[]
            def fetch(address, app_id, **kw):
                seen.append(app_id)
                return None if app_id == '1' else '/image'
            with patch.object(fixture.MoonlightHelper, '_art_if_present', return_value=None), patch.object(fixture.MoonlightHelper, 'boxart_path', side_effect=fetch):
                # Both jobs belong to the currently selected canonical host.
                # A different host must not consume this worker at all.
                self.run_worker(td, 'a')
            self.assertCountEqual(seen,['1','2'])
            remaining=list(jobs.glob('*.work'))
            self.assertEqual(len(remaining),1)
            self.assertEqual(json.loads(remaining[0].read_text())['ids'],['1'])

    def test_failed_refresh_keeps_image_but_retries_request(self):
        with tempfile.TemporaryDirectory() as td:
            helper=fixture.MoonlightHelper.__new__(fixture.MoonlightHelper)
            folder=Path(td,helper._host_cache_key('a'));folder.mkdir()
            image=folder/'1.png';image.write_bytes(fixture.sample_png('old'))
            job=Path(td,'a.work');job.write_text('{"host":"a","ids":["1"],"refresh":true}')
            monitor=Mock();monitor.abortRequested.return_value=False
            with patch.object(service.xbmcvfs,'translatePath',return_value=td,create=True),patch('resources.lib.util.hostapi.Host') as host:
                host.return_value.boxart.return_value=None
                self.assertFalse(service.process_job(job,monitor))
            self.assertEqual(image.read_bytes(),fixture.sample_png('old'))
            self.assertEqual(json.loads(job.read_text())['attempts'],1)

    def test_native_and_python_lookup_keep_custom_context(self):
        with tempfile.TemporaryDirectory() as td:
            config=confighelper.ConfigHelper.__new__(confighelper.ConfigHelper)
            config.config_path=str(Path(td,'moonlight.conf'));config.config={'host_addr':'a'}
            Path(config.config_path).write_text('[Moonlight]\naddress=a\nport=48000\nkeydir=/storage/custom\n')
            snapshot=Path(config.create_host_lookup_snapshot()).read_text()
            self.assertIn('port = 48000',snapshot);self.assertIn('keydir = /storage/custom',snapshot)
            helper=fixture.MoonlightHelper.__new__(fixture.MoonlightHelper);helper.config_helper=config
            host=helper._host('a')
            self.assertEqual((host.http_port,host.key_dir),(48000,'/storage/custom'))
            default=fixture.MoonlightHelper.__new__(fixture.MoonlightHelper)
            self.assertNotEqual(helper._host_cache_key('a'),default._host_cache_key('a'))

    def test_quick_play_captures_host_before_dialog(self):
        root=Path(__file__).resolve().parents[1];tree=ast.parse((root/'addon.py').read_text())
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='quickPlay')
        config=Mock(config={'host_addr':'a'});helper=Mock();helper._host_identity.side_effect=__import__('resources.lib.util.hostcontext',fromlist=['host_identity']).host_identity;helper.list_games_detailed.return_value=[('42','A game',None)]
        def select(*a,**kw):config.config['host_addr']='b';return 0
        scope={'addon':Mock(getLocalizedString=lambda k:'Apps'),'config_helper':config,'logger':Mock(),'xbmcgui':types.SimpleNamespace(ListItem=Mock,Dialog=lambda:Mock(select=select)),'xbmc':Mock()}
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'addon.py','exec'),scope)
        with patch('resources.lib.util.moonlighthelper.MoonlightHelper',return_value=helper):scope['quickPlay']()
        from resources.lib.util.resumestate import host_identity
        self.assertEqual(helper.launch_game.call_args.kwargs['expected_host'],host_identity('a'))

    def test_fractional_named_mode_is_not_exact(self):
        with tempfile.TemporaryDirectory() as td:
            mode=Path(td,'mode');cap=Path(td,'cap');conf=Path(td,'conf')
            mode.write_text('1080p60hz');cap.write_text('1080p60hz')
            conf.write_text('[Moonlight]\nwidth=1920\nheight=1080\nfps=60\n')
            Path(td,'vinfo').write_text('sync_duration_num: 60000\nsync_duration_den: 1001\n')
            with self.assertRaises(hdmimode.HdmiModeUnavailable):hdmimode.check(conf,mode,cap)
            Path(td,'vinfo').write_text('sync_duration_num: 60\nsync_duration_den: 1\n')
            self.assertEqual(hdmimode.check(conf,mode,cap),('1080p60hz','1080p60hz'))

    def test_vfm_limits_apply_without_hdmi_matching(self):
        with tempfile.TemporaryDirectory() as td:
            conf=Path(td,'conf');conf.write_text('[Moonlight]\nwidth=7680\nheight=4320\nfps=60\n')
            with self.assertRaises(ValueError):runtimecheck.check_stream_geometry(conf,'aml-vfm')
            conf.write_text('[Moonlight]\nwidth=3840\nheight=2160\nfps=60\n')
            runtimecheck.check_stream_geometry(conf,'aml-vfm')

    def test_paused_playback_state_survives_rollback(self):
        player=Mock(getPlayingFile=lambda:'movie',getTime=lambda:30.0,getPlayingItem=lambda:None)
        with patch.object(sys.modules['xbmc'],'getCondVisibility',return_value=True,create=True):
            record=fixture.MoonlightHelper._capture_kodi_playback(player)
        self.assertTrue(record[3]);player.isPlaying.side_effect=[False,True]
        with patch.object(sys.modules['xbmc'],'getCondVisibility',return_value=False,create=True):
            self.assertTrue(fixture.MoonlightHelper._restore_kodi_playback(player,record))
        player.pause.assert_called_once();player.seekTime.assert_called_once_with(30.0)
