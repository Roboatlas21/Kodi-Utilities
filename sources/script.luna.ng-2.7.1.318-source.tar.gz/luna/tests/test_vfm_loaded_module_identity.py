"""Fail-closed loaded module identity and consistent stock path policy."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

from resources.lib.util import vfmruntime as runtime


class LoadedModuleIdentityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.bundle = self.root / 'moonlight_vfm.ko'
        self.bundle.write_bytes(b'patched module')
        self.sys = self.root / 'sys' / 'module'
        (self.sys / 'moonlight_vfm').mkdir(parents=True)

    def test_matching_srcversion_allows_reuse(self):
        (self.sys / 'moonlight_vfm' / 'srcversion').write_text('ABC123\n')
        with mock.patch.object(runtime, '_module_info', return_value='ABC123'):
            runtime._check_loaded_module_build('moonlight_vfm', self.bundle, self.sys)

    def test_same_version_but_different_build_requires_reboot(self):
        (self.sys / 'moonlight_vfm' / 'srcversion').write_text('OLD123\n')
        with mock.patch.object(runtime, '_module_info', return_value='NEW123'):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Reboot CoreELEC'):
                runtime._check_loaded_module_build('moonlight_vfm', self.bundle, self.sys)

    def test_missing_loaded_or_bundled_identity_never_proves_match(self):
        with mock.patch.object(runtime, '_module_info', return_value='NEW123'):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Reboot CoreELEC'):
                runtime._check_loaded_module_build('moonlight_vfm', self.bundle, self.sys)
        (self.sys / 'moonlight_vfm' / 'srcversion').write_text('NEW123\n')
        with mock.patch.object(runtime, '_module_info', return_value=''):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Reboot CoreELEC'):
                runtime._check_loaded_module_build('moonlight_vfm', self.bundle, self.sys)

    def test_invalid_module_information_fails_closed(self):
        with mock.patch.object(runtime, '_module_info',
                               side_effect=subprocess.TimeoutExpired('modinfo', 5)):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Reboot CoreELEC'):
                runtime._check_loaded_module_build('moonlight_vfm', self.bundle, self.sys)

    def test_preflight_bridge_checks_identity_not_only_module_version(self):
        original_exists = Path.exists
        original_read = Path.read_text

        def exists(path):
            return (str(path) == '/sys/module/moonlight_vfm' or
                    original_exists(path))

        def read(path, *args, **kwargs):
            if str(path) == '/sys/module/moonlight_vfm/version':
                return '6\n'
            return original_read(path, *args, **kwargs)

        with mock.patch.object(Path, 'exists', new=exists), \
             mock.patch.object(Path, 'read_text', new=read), \
             mock.patch.object(runtime, '_check_loaded_module_build',
                               side_effect=runtime.VfmRuntimeError('Stale resident module')) as verify:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Stale resident module'):
                runtime.check_loaded_bridge(self.bundle)
        verify.assert_called_once_with('moonlight_vfm', self.bundle)

    def test_old_patched_or_missing_decoder_requires_reboot(self):
        module = self.root / 'amvdec_ports.ko'
        module.write_bytes(b'patched decoder')
        with mock.patch.object(runtime, '_module_info',
                               return_value='moonlight-hdr1'), \
             mock.patch.object(runtime, '_loaded_module_version',
                               return_value='moonlight-hdr1'), \
             mock.patch.object(runtime, '_check_loaded_module_build'):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Reboot CoreELEC'):
                runtime.prepare_hdr_decoder(module)
        with mock.patch.object(runtime, '_module_info',
                               return_value='moonlight-hdr1'), \
             mock.patch.object(runtime, '_loaded_module_version',
                               return_value=None):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Reboot CoreELEC'):
                runtime.prepare_hdr_decoder(module)

    def test_stock_decoder_loaded_build_matches_trusted_module(self):
        module = self.root / 'amvdec_ports.ko'
        module.write_bytes(b'stock kernel module')
        directory = self.sys / 'amvdec_ports'
        directory.mkdir(parents=True)
        (directory / 'srcversion').write_text('MATCHED_SRC\n')
        with mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_module_info', return_value='MATCHED_SRC'):
            runtime._verify_loaded_stock_decoder(module, 'stock-v1', self.sys)

    def test_coreelec21_metadata_less_stock_is_accepted_only_with_provenance(self):
        module = self.root / 'trusted' / 'media_modules-aml' / 'amvdec_ports.ko'
        module.parent.mkdir(parents=True)
        module.write_bytes(b'stock image')
        # The generic bridge fixture must not be present for a pristine
        # stock-only CoreELEC boot (its existence is correctly rejected).
        (self.sys / 'moonlight_vfm').rmdir()
        sys_module = self.sys / 'amvdec_ports'
        params = sys_module / 'parameters'
        params.mkdir(parents=True)
        (params / 'multiplanar').write_text('N\n')
        proc_modules = self.root / 'proc-modules'
        proc_modules.write_text('amvdec_ports 167936 0 - Live 0xffffff8002160000 (O)\n')
        release = '4.9.269'

        metadata = {
            # Actual CoreELEC 21 / Linux 4.9.269 stock module metadata.
            'name': '',
            'vermagic': release + ' SMP preempt mod_unload modversions aarch64',
            'version': '',
            'srcversion': '',
        }

        def info(field, path):
            return metadata[field]

        with mock.patch.object(runtime.os, 'uname',
                               return_value=type('U', (), {'release': release})()), \
             mock.patch.object(runtime, '_stock_module_roots',
                               return_value=(module.parent.parent,)), \
             mock.patch.object(runtime, '_module_info', side_effect=info):
            # Both missing and correctly populated names are legitimate.
            runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)
            metadata['name'] = 'amvdec_ports'
            runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)
            metadata['name'] = ''
            # A missing name must not weaken version, source, or kernel checks.
            for field, invalid in (('name', 'unrelated_module'),
                                   ('vermagic', '4.9.268 SMP'),
                                   ('version', 'moonlight-hdr1'),
                                   ('srcversion', 'mismatched-source')):
                expected = metadata[field]
                metadata[field] = invalid
                with self.subTest(field=field), self.assertRaisesRegex(
                        runtime.VfmRuntimeError, 'provenance or metadata changed'):
                    runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)
                metadata[field] = expected
            verify_real = runtime._coreelec21_metadata_less_stock
            with mock.patch.object(runtime, '_loaded_module_version', return_value=''), \
                 mock.patch.object(runtime, '_coreelec21_metadata_less_stock',
                                   side_effect=lambda path, sys_module_root='/sys/module':
                                       verify_real(path, sys_module_root, proc_modules)):
                runtime._verify_loaded_stock_decoder(module, '', self.sys)
            (params / 'multiplanar').unlink()
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'multiplanar'):
                runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)
            (params / 'multiplanar').write_text('N\n')
            proc_modules.unlink()
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'loaded stock decoder modules'):
                runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)
            proc_modules.write_text('amvdec_ports 167936 0 - Unloading 0x00\n')
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'not live'):
                runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)
            proc_modules.write_text('amvdec_ports 167936 0 - Live 0x00\n')
            with mock.patch.object(runtime, '_module_info',
                                   side_effect=lambda field, path:
                                       'tampered' if field == 'srcversion' else info(field, path)):
                with self.assertRaisesRegex(runtime.VfmRuntimeError, 'provenance'):
                    runtime._coreelec21_metadata_less_stock(module, self.sys, proc_modules)

    def test_metadata_less_fallback_rejects_untrusted_paths_and_kernels(self):
        path = self.root / 'amvdec_ports.ko'
        path.write_bytes(b'untrusted')
        with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Untrusted'):
            runtime._coreelec21_metadata_less_stock(path, require_loaded=False)
        trusted = self.root / 'media_modules-aml' / 'amvdec_ports.ko'
        trusted.parent.mkdir()
        trusted.write_bytes(b'module')
        with mock.patch.object(runtime.os, 'uname',
                               return_value=type('U', (), {'release': '5.15.0'})()):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Untrusted'):
                runtime._coreelec21_metadata_less_stock(trusted, require_loaded=False)

    def test_stock_decoder_version_label_cannot_hide_different_build(self):
        module = self.root / 'amvdec_ports.ko'
        module.write_bytes(b'stock kernel module')
        directory = self.sys / 'amvdec_ports'
        directory.mkdir(parents=True)
        (directory / 'srcversion').write_text('OTHER_SRC\n')
        with mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_module_info', return_value='MATCHED_SRC'):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime._verify_loaded_stock_decoder(module, 'stock-v1', self.sys)
        (directory / 'srcversion').unlink()
        with mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_module_info', return_value='MATCHED_SRC'):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime._verify_loaded_stock_decoder(module, 'stock-v1', self.sys)

    def test_stock_rollback_does_not_accept_label_only(self):
        module = self.root / 'amvdec_ports.ko'
        module.write_bytes(b'stock kernel module')
        with mock.patch.object(runtime, '_module_info', return_value='MATCHED_SRC'), \
             mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_verify_loaded_stock_decoder',
                               side_effect=runtime.VfmRuntimeError('srcversion mismatch; recovery retained')) as check, \
             mock.patch.object(runtime.subprocess, 'run') as run:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime._restore_stock_decoder((module, '0', 'stock-v1'))
            check.assert_called_once_with(module, 'stock-v1')
            run.assert_not_called()

    def test_reload_must_verify_stock_srcversion_before_journal_clear(self):
        module = self.root / 'amvdec_ports.ko'
        module.write_bytes(b'stock kernel module')
        with mock.patch.object(runtime, '_module_info', return_value='MATCHED_SRC'), \
             mock.patch.object(runtime, '_loaded_module_version', return_value=None), \
             mock.patch.object(runtime, '_verify_loaded_stock_decoder',
                               side_effect=runtime.VfmRuntimeError('stock srcversion mismatch; recovery retained')) as check, \
             mock.patch.object(Path, 'exists', return_value=False), \
             mock.patch.object(runtime.subprocess, 'run') as run:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime._restore_stock_decoder((module, '0', 'stock-v1'))
            run.assert_called_once_with(
                ['insmod', str(module), 'multiplanar=0'], timeout=15, check=True)
            check.assert_called_once_with(module, 'stock-v1')

    def test_preflight_rejects_unverifiable_stock_before_module_swap(self):
        module = self.root / 'patched-amvdec_ports.ko'
        module.write_bytes(b'patched kernel module')
        with mock.patch.object(runtime, '_module_info', return_value='moonlight-hdr1'), \
             mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_stock_decoder_module', return_value=self.bundle), \
             mock.patch.object(runtime, '_verify_loaded_stock_decoder',
                               side_effect=runtime.VfmRuntimeError('stock build missing; recovery retained')) as check, \
             mock.patch.object(Path, 'read_text', return_value='0'), \
             mock.patch.object(runtime.subprocess, 'run') as run:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime.prepare_hdr_decoder(module)
            check.assert_called_once_with(self.bundle, 'stock-v1')
            run.assert_not_called()

    def test_stock_multiplanar_readback_matches_kernel_boolean_notation(self):
        mode = self.root / 'multiplanar'
        for observed, expected in (('0', '0'), ('N', '0'), ('1', '1'), ('Y', '1')):
            with self.subTest(observed=observed):
                mode.write_text(observed + '\n')
                runtime._verify_stock_multiplanar(expected, mode)

    def test_stock_multiplanar_mismatch_or_missing_file_keeps_recovery(self):
        mode = self.root / 'multiplanar'
        mode.write_text('1\n')
        with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
            runtime._verify_stock_multiplanar('0', mode)
        mode.unlink()
        with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
            runtime._verify_stock_multiplanar('0', mode)
        with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
            runtime._verify_stock_multiplanar('unexpected', mode)

    def test_loaded_stock_requires_original_multiplanar_before_success(self):
        module = self.root / 'amvdec_ports.ko'
        module.write_bytes(b'stock module')
        with mock.patch.object(runtime, '_module_info', return_value='SRC'), \
             mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_verify_loaded_stock_decoder') as identity, \
             mock.patch.object(runtime, '_verify_stock_multiplanar',
                               side_effect=runtime.VfmRuntimeError('mode mismatch; recovery retained')) as mode, \
             mock.patch.object(runtime.subprocess, 'run') as commands:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime._restore_stock_decoder((module, '0', 'stock-v1'))
            identity.assert_called_once_with(module, 'stock-v1')
            mode.assert_called_once_with('0')
            commands.assert_not_called()

    def test_stock_candidate_cannot_escape_allowed_roots(self):
        release = os.uname().release
        trusted = self.root / 'modules' / release
        trusted.mkdir(parents=True)
        candidate = trusted / 'amvdec_ports.ko'
        candidate.write_bytes(b'kernel module')
        outside = self.root / 'untrusted' / 'amvdec_ports.ko'
        outside.parent.mkdir()
        outside.write_bytes(b'other module')
        (trusted / 'alias.ko').symlink_to(outside)
        with mock.patch.object(runtime, '_stock_module_roots',
                               return_value=(trusted,)):
            self.assertTrue(runtime._stock_module_path_allowed(candidate, release))
            self.assertFalse(runtime._stock_module_path_allowed(outside, release))
            self.assertFalse(runtime._stock_module_path_allowed(trusted / 'alias.ko', release))

    def test_discovery_skips_modinfo_path_outside_recovery_roots(self):
        release = os.uname().release
        trusted = self.root / 'modules' / release
        trusted.mkdir(parents=True)
        candidate = trusted / 'amvdec_ports.ko'
        candidate.write_bytes(b'kernel module')
        outside = self.root / 'outside' / 'amvdec_ports.ko'
        outside.parent.mkdir()
        outside.write_bytes(b'other module')

        def info(field, path):
            return release + ' SMP' if field == 'vermagic' else ''
        original_is_file = Path.is_file

        def is_file(path):
            if str(path) == '/sys/module/amvdec_ports/srcversion':
                return False
            return original_is_file(path)

        with mock.patch.object(runtime, '_stock_module_roots', return_value=(trusted,)), \
             mock.patch.object(runtime.subprocess, 'run', return_value=
                               subprocess.CompletedProcess([], 0, stdout=str(outside) + '\n')), \
             mock.patch.object(runtime, '_module_info', side_effect=info), \
             mock.patch.object(Path, 'is_file', new=is_file):
            self.assertEqual(runtime._stock_decoder_module(), candidate.resolve())
            # A plausible in-tree module with a different stock version is
            # not a valid rollback image for the currently running decoder.
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'Cannot find'):
                runtime._stock_decoder_module('a-different-stock-version')


if __name__ == '__main__':
    unittest.main()
