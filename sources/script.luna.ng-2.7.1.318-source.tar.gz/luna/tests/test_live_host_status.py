"""Service-owned host checking: no Kodi install or external network needed."""
import threading
import time
import unittest
from resources.lib.util.livehoststatus import ServiceStatusCoordinator, probe_pairing_state
from resources.lib.util.hostapi import HostIdentityError


class CoordinatorTests(unittest.TestCase):
    def setUp(self):
        self.address = 'host-A'
        self.opened = True
        self.messages = []
        self.errors = []
        self.clock = 0
        self.probes = []
        self.revision = ''
        self.pending_token = ''
        self.pending_address = ''
        self.acknowledged = []

    def pending(self):
        return self.pending_token, self.pending_address

    def acknowledge(self, token, address):
        self.acknowledged.append((token, address))
        if (token, address) == self.pending():
            self.pending_token = ''
            self.pending_address = ''

    def coord(self, probe=None, prepare=None, identity=None):
        def default(address):
            self.probes.append(address)
            return 'paired'
        return ServiceStatusCoordinator(
            lambda: self.address, lambda: self.opened, probe or default,
            lambda address, result: self.messages.append((address, result)),
            self.errors.append, clock=lambda: self.clock,
            retry_seconds=10, refresh_seconds=45,
            read_revision=lambda: self.revision, prepare_probe=prepare,
            read_pending=self.pending, acknowledge_pending=self.acknowledge,
            read_identity=identity)

    def until(self, condition, coordinator=None):
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            if coordinator is not None:
                coordinator.tick()
            if condition():
                return
            time.sleep(.01)
        self.fail('Timed out awaiting host check')

    def test_open_checks_and_refreshes_same_ip_on_reopen(self):
        c = self.coord()
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-A','paired')], c)
        self.clock = 1
        c.tick()
        self.assertEqual(self.probes, ['host-A'])
        self.opened = False
        c.tick()
        self.opened = True
        c.tick()
        self.until(lambda: len(self.probes) == 2, c)
        c.stop()

    def test_revision_discards_old_result_even_with_same_ip(self):
        entered = threading.Event()
        release = threading.Event()
        calls = []
        def probe(address):
            calls.append(address)
            if len(calls) == 1:
                entered.set()
                release.wait(2)
                return 'unpaired'
            return 'paired'
        c = self.coord(probe)
        self.revision = 'first'
        c.tick()
        self.assertTrue(entered.wait(1))
        self.revision = 'second'  # quick close/reopen between ticker reads
        self.clock = 1
        c.tick()
        release.set()
        self.until(lambda: self.messages[-1:] == [('host-A','paired')], c)
        self.assertNotIn(('host-A','unpaired'), self.messages)
        self.assertEqual(calls, ['host-A', 'host-A'])
        c.stop()

    def test_port_or_keydir_change_discards_inflight_paired_result(self):
        from resources.lib.util.hostcontext import host_identity
        for option, second in (('port', '48089'),
                               ('keydir', '/tmp/alternate-pairing-keys')):
            with self.subTest(option=option):
                self.setUp()
                self.options = {}
                first_started, release_first = threading.Event(), threading.Event()
                seen = []
                def identity(address):
                    return host_identity(address, self.options)
                def prepare(address):
                    return (address, identity(address))
                def probe(request):
                    seen.append(request)
                    if len(seen) == 1:
                        first_started.set()
                        release_first.wait(2)
                        return 'paired'  # Stale result must never be shown.
                    return 'unpaired'
                c = self.coord(probe, prepare, identity)
                try:
                    c.tick()
                    self.assertTrue(first_started.wait(1))
                    self.options[option] = second
                    c.tick()  # Same IP and same settings session.
                    release_first.set()
                    self.until(lambda: self.messages[-1:] ==
                               [('host-A', 'unpaired')], c)
                    self.assertNotIn(('host-A', 'paired'), self.messages)
                    self.assertEqual(len(seen), 2)
                    self.assertNotEqual(seen[0][1], seen[1][1])
                finally:
                    release_first.set()
                    c.stop()

    def test_closing_invalidates_in_flight_request(self):
        entered = threading.Event()
        release = threading.Event()
        def probe(address):
            entered.set()
            release.wait(2)
            return 'paired'
        c = self.coord(probe)
        c.tick()
        self.assertTrue(entered.wait(1))
        self.opened = False
        c.tick()
        release.set()
        time.sleep(.03)
        self.assertNotIn(('host-A','paired'), self.messages)
        c.stop()

    def test_slow_check_not_discarded_by_refresh_timer(self):
        started = threading.Event()
        release = threading.Event()
        def probe(address):
            self.probes.append(address)
            started.set()
            release.wait(2)
            return 'paired'
        c = ServiceStatusCoordinator(
            lambda: self.address, lambda: self.opened, probe,
            lambda address, state: self.messages.append((address, state)),
            self.errors.append, clock=lambda: self.clock,
            read_revision=lambda: self.revision, refresh_seconds=8)
        c.tick()
        self.assertTrue(started.wait(1))
        self.clock = 9  # Past periodic refresh, but the request is still live.
        for _ in range(5):
            c.tick()
        self.assertEqual(self.probes, ['host-A'])
        self.assertEqual(self.messages, [('host-A', 'checking')])
        release.set()
        self.until(lambda: self.messages[-1:] == [('host-A', 'paired')], c)
        self.assertEqual(self.probes, ['host-A'])
        self.assertEqual(self.messages.count(('host-A', 'checking')), 1)
        c.stop()

    def test_rapid_close_requests_postclose_host_verification(self):
        self.opened = False
        self.address = 'host-B'
        self.pending_token = 'token-2'
        self.pending_address = 'host-B'
        c = self.coord()
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-B','paired')], c)
        self.assertEqual(self.probes, ['host-B'])
        self.assertEqual(self.acknowledged, [('token-2', 'host-B')])
        self.assertEqual(self.pending(), ('', ''))
        c.tick()
        self.assertEqual(self.probes, ['host-B'])
        c.stop()

    def test_postclose_token_is_bound_to_original_connection_context(self):
        from resources.lib.util.hostcontext import host_identity
        self.opened = False
        self.pending_token = 'old-settings-token'
        self.pending_address = 'host-A'
        self.port = '48089'
        originally_requested = host_identity('host-A', {'port': '47990'})
        def pending():
            return (self.pending_token, self.pending_address,
                    originally_requested)
        c = ServiceStatusCoordinator(
            lambda: self.address, lambda: self.opened,
            lambda addr: self.probes.append(addr) or 'paired',
            lambda address, state: self.messages.append((address, state)),
            clock=lambda: self.clock,
            read_pending=pending,
            acknowledge_pending=self.acknowledge,
            read_identity=lambda addr: host_identity(
                addr, {'port': self.port}))
        c.tick()
        self.assertEqual(self.probes, [])
        self.assertEqual(self.messages, [])
        self.assertEqual(self.acknowledged, [])
        # A new post-close request captures this selected port instead.
        originally_requested = host_identity('host-A', {'port': '48089'})
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-A', 'paired')], c)
        self.assertEqual(self.acknowledged, [('old-settings-token', 'host-A')])
        c.stop()

    def test_no_background_request_while_settings_closed(self):
        self.opened = False
        c = self.coord()
        c.tick()
        self.assertEqual(self.probes, [])
        self.assertEqual(self.messages, [])
        c.stop()

    def test_stale_postclose_result_cannot_replace_new_pending_host(self):
        self.opened = False
        started = threading.Event()
        release = threading.Event()
        def probe(addr):
            self.probes.append(addr)
            if addr == 'host-A':
                started.set()
                release.wait(2)
            return 'paired'
        self.pending_token = 'old'
        self.pending_address = 'host-A'
        c = self.coord(probe)
        c.tick()
        self.assertTrue(started.wait(1))
        self.address = 'host-B'
        self.pending_token = 'new'
        self.pending_address = 'host-B'
        c.tick()
        release.set()
        self.until(lambda: self.messages[-1:] == [('host-B','paired')], c)
        self.assertNotIn(('old','host-A'), self.acknowledged)
        self.assertEqual(self.acknowledged, [('new','host-B')])
        c.stop()

    def test_unavailable_retries_unchanged_ip(self):
        results = iter(['unavailable','paired'])
        def probe(address):
            self.probes.append(address)
            return next(results)
        c = self.coord(probe)
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-A','unavailable')], c)
        self.clock = 9
        c.tick()
        self.assertEqual(len(self.probes), 1)
        self.clock = 10
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-A','paired')], c)
        self.assertEqual(self.probes, ['host-A','host-A'])
        c.stop()

    def test_pending_latest_host_without_second_network_worker(self):
        started = threading.Event()
        release = threading.Event()
        def probe(address):
            self.probes.append(address)
            if address == 'host-A':
                started.set()
                release.wait(2)
            return 'paired'
        c = self.coord(probe)
        c.tick()
        self.assertTrue(started.wait(1))
        first = c._worker
        self.address = 'host-B'
        c.tick()
        self.assertIs(first, c._worker)
        release.set()
        self.until(lambda: self.messages[-1:] == [('host-B','paired')], c)
        self.assertNotIn(('host-A','paired'), self.messages)
        c.stop()

    def test_queued_request_survives_finished_worker(self):
        class Finished:
            def is_alive(self):
                return False
            def join(self, timeout=None):
                return None
        c = self.coord()
        c._last_session = ('dialog', self.revision)
        c._last_address = self.address
        c._last_identity = self.address
        c._next_probe = 45
        c._queued = ('host-A', c._generation, 'host-A')
        c._worker = Finished()
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-A','paired')], c)
        c.stop()

    def test_no_network_for_empty_ip(self):
        self.address = ''
        c = self.coord()
        c.tick()
        self.assertEqual(self.messages, [('', 'unconfigured')])
        self.assertEqual(self.probes, [])
        c.stop()

    def test_worker_never_calls_kodi_publisher(self):
        network_thread = []
        publisher_thread = []
        def probe(request):
            network_thread.append(threading.current_thread().name)
            return 'paired'
        def publish(address, result):
            publisher_thread.append(threading.current_thread().name)
        c = ServiceStatusCoordinator(
            lambda: self.address, lambda: self.opened,
            probe, publish, self.errors.append)
        c.tick()
        self.until(lambda: publisher_thread.count('MainThread') >= 2, c)
        self.assertEqual(network_thread, ['LunaStatusNetwork'])
        self.assertEqual(set(publisher_thread), {'MainThread'})
        c.stop()

    def test_shutdown_is_bounded_and_suppresses_late_errors(self):
        entered = threading.Event()
        release = threading.Event()
        def probe(address):
            entered.set()
            release.wait(2)
            raise OSError('server timeout')
        c = self.coord(probe)
        c.tick()
        self.assertTrue(entered.wait(1))
        before = time.monotonic()
        c.stop(timeout=0.05)
        self.assertLess(time.monotonic() - before, 0.3)
        count = len(self.messages)
        release.set()
        time.sleep(.03)
        self.assertEqual(len(self.messages), count)
        self.assertEqual(self.errors, []) # no Kodi logger post shutdown

    def test_prepare_runs_on_ticker_not_network_worker(self):
        prepare_names = []
        def prepare(address):
            prepare_names.append(threading.current_thread().name)
            return {'host': address}
        def probe(request):
            self.probes.append(request['host'])
            return 'paired'
        c = self.coord(probe, prepare)
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-A','paired')], c)
        self.assertEqual(prepare_names, ['MainThread'])
        c.stop()

    def test_failed_publish_does_not_drop_next_host(self):
        def publish(address, result):
            if result == 'paired' and address == 'host-A':
                raise OSError('Kodi settings write failed')
            self.messages.append((address, result))
        c = ServiceStatusCoordinator(
            lambda: self.address, lambda: self.opened,
            lambda _: 'paired', publish, clock=lambda: self.clock)
        c.tick()
        self.until(lambda: bool(c._finished), None)
        with self.assertRaises(OSError):
            c.tick()
        self.address = 'host-B'
        c.tick()
        self.until(lambda: self.messages[-1:] == [('host-B','paired')], c)
        c.stop()

    def test_certificate_identity_change_is_not_host_unavailable(self):
        def mismatched_host(_host):
            raise HostIdentityError('untrusted server public key')
        c = self.coord(mismatched_host)
        c.tick()
        self.until(lambda: self.messages[-1:] ==
                   [('host-A', 'identity_changed')], c)
        self.assertIn('HostIdentityError', self.errors)
        c.stop()

    def test_pin_required_and_remote_verified(self):
        class Host:
            def __init__(self, keys, pin, paired):
                self.keys, self.pin, self.paired = keys, pin, paired
            def has_pairing_keys(self): return self.keys
            def has_trusted_pin(self): return self.pin
            def pair_status(self): return self.paired
        self.assertEqual(probe_pairing_state(Host(False,True,True)), 'unpaired')
        self.assertEqual(probe_pairing_state(Host(True,False,True)), 'needs_pin')
        self.assertEqual(probe_pairing_state(Host(True,True,True)), 'paired')
        self.assertEqual(probe_pairing_state(Host(True,True,False)), 'unpaired')


if __name__ == '__main__':
    unittest.main()
