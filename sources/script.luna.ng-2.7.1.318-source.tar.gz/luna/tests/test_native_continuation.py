"""Fail-closed Luna/Moonlight callback provenance and approval contracts."""
import copy
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_native_continuation", ROOT / "packaging/verify_native_continuation.py")
PROOF = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROOF)
ORIGIN_ID = "41481786178"
NATIVE_ID = "41482592164"
MOON_SHA = "a" * 40
LUNA_SHA = "b" * 40


def fixture():
    request = {
        "schema": "luna-ng-native-request-v1",
        "origin_run_id": int(ORIGIN_ID),
        "origin_run_attempt": 1,
        "luna_sha": LUNA_SHA,
        "moonlight_sha": MOON_SHA,
        "release_version": "2.7.1.312",
        "publish_to_kodi": True,
        "include_vfm_runtime": True,
    }
    origin = {
        "id": int(ORIGIN_ID), "event": "workflow_dispatch",
        "path": PROOF.LUNA_WORKFLOW, "head_branch": "matrix",
        "head_repository": {"full_name": PROOF.LUNA_REPO},
        "run_attempt": 1, "status": "completed", "conclusion": "success",
    }
    origin_jobs = {
        "jobs": [
            {"name": name, "run_id": int(ORIGIN_ID), "run_attempt": 1,
             "status": "completed", "conclusion": "success"}
            for name in ("unified / preflight", "unified / select-native")
        ],
    }
    native = {
        "id": int(NATIVE_ID), "event": "workflow_dispatch",
        "path": PROOF.MOONLIGHT_WORKFLOW,
        "head_branch": "feat/coreelec-ng",
        "head_repository": {"full_name": PROOF.MOONLIGHT_REPO},
        "display_title": (
            f"CoreELEC21-NG source={MOON_SHA} correlation=luna-{ORIGIN_ID}-1"),
        "status": "in_progress", "conclusion": None,
    }
    native_jobs = {
        "jobs": [
            {"name": name, "run_id": int(NATIVE_ID),
             "status": "completed", "conclusion": "success"}
            for name in ("prepare", "native")
        ],
    }
    native_artifacts = {
        "artifacts": [
            {"name": name, "expired": False, "size_in_bytes": 4096}
            for name in ("moonlight-coreelec21-ng-arm32",
                         "moonlight-coreelec21-ng-vfm-runtime")
        ]
    }
    return [request, origin, origin_jobs, native, native_jobs, native_artifacts]


class VerifiedContinuationTests(unittest.TestCase):
    def verify(self, data=None, publish=True, vfm=True):
        return PROOF.verify(*(data or fixture()), ORIGIN_ID, NATIVE_ID, publish, vfm)

    def test_partial_selection_rerun_preserves_preflight_approval(self):
        data = fixture()
        data[1]["run_attempt"] = 2
        data[2]["jobs"][1]["run_attempt"] = 2
        data[3]["display_title"] = (
            f"CoreELEC21-NG source={MOON_SHA} correlation=luna-{ORIGIN_ID}-2")
        self.assertEqual(self.verify(data)["luna_sha"], LUNA_SHA)
        for job in (0, 1):
            invalid = copy.deepcopy(data)
            invalid[2]["jobs"][job]["run_attempt"] = 3
            with self.subTest(job=job), self.assertRaises(ValueError):
                self.verify(invalid)
        data[3]["display_title"] = (
            f"CoreELEC21-NG source={MOON_SHA} correlation=luna-{ORIGIN_ID}-3")
        with self.assertRaises(ValueError):
            self.verify(data)

    def test_full_rerun_binds_new_approval_and_both_jobs(self):
        data = fixture()
        data[0]["origin_run_attempt"] = 2
        data[1]["run_attempt"] = 2
        for job in data[2]["jobs"]:
            job["run_attempt"] = 2
        data[3]["display_title"] = (
            f"CoreELEC21-NG source={MOON_SHA} correlation=luna-{ORIGIN_ID}-2")
        self.assertEqual(self.verify(data)["luna_sha"], LUNA_SHA)

    def test_native_callback_can_finish_during_parent_run(self):
        data = fixture()
        actual = self.verify(data)
        self.assertEqual(actual["luna_sha"], LUNA_SHA)
        self.assertEqual(actual["moonlight_sha"], MOON_SHA)
        self.assertEqual(actual["native_run_id"], NATIVE_ID)
        data[3].update(status="completed", conclusion="success")
        self.assertEqual(self.verify(data), actual)

    def test_failed_native_workflow_cannot_resume(self):
        data = fixture()
        data[3].update(status="completed", conclusion="failure")
        with self.assertRaises(ValueError):
            self.verify(data)

    def test_original_preflight_must_have_succeeded(self):
        for case in ("preflight", "selection", "original-run"):
            data = fixture()
            if case == "original-run":
                data[1]["conclusion"] = "failure"
            else:
                data[2]["jobs"][0 if case == "preflight" else 1]["conclusion"] = "failure"
            with self.subTest(case=case), self.assertRaises(ValueError):
                self.verify(data)

    def test_refuse_release_without_original_publish_approval(self):
        data = fixture()
        data[0]["publish_to_kodi"] = False
        with self.assertRaisesRegex(ValueError, "approval"):
            self.verify(data, publish=True)
        self.assertEqual(self.verify(data, publish=False)["luna_sha"], LUNA_SHA)

    def test_vfm_selection_is_bound_to_original_request(self):
        data = fixture()
        with self.assertRaisesRegex(ValueError, "approval"):
            self.verify(data, vfm=False)
        data[5]["artifacts"][1]["expired"] = True
        with self.assertRaises(ValueError):
            self.verify(data)

    def test_correlation_binds_original_run_id_and_attempt(self):
        for replacement in (
                f"CoreELEC21-NG source={MOON_SHA} correlation=luna-{ORIGIN_ID}-2",
                f"CoreELEC21-NG source={MOON_SHA} correlation=luna-99999999-1",
                f"CoreELEC21-NG source={'c' * 40} correlation=luna-{ORIGIN_ID}-1"):
            data = fixture()
            data[3]["display_title"] = replacement
            with self.subTest(title=replacement), self.assertRaises(ValueError):
                self.verify(data)

    def test_reject_wrong_source_repositories_and_run_types(self):
        cases = (
            (1, "head_branch", "feat/vortex-ng"),
            (1, "event", "repository_dispatch"),
            (3, "head_branch", "master"),
            (3, "event", "push"),
        )
        for index, attr, bad in cases:
            data = fixture()
            data[index][attr] = bad
            with self.subTest(index=index, attr=attr), self.assertRaises(ValueError):
                self.verify(data)

    def test_native_jobs_must_both_pass_for_current_run(self):
        for name in ("prepare", "native"):
            data = fixture()
            for job in data[4]["jobs"]:
                if job["name"] == name:
                    job["conclusion"] = "skipped"
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.verify(data)
        data = fixture()
        data[4]["jobs"][0]["run_id"] = 12345678
        with self.assertRaises(ValueError):
            self.verify(data)

    def test_artifact_must_exist_unexpired_and_nonempty(self):
        for prop, value in (("size_in_bytes", 0), ("expired", True)):
            data = fixture()
            data[5]["artifacts"][0][prop] = value
            with self.subTest(prop=prop), self.assertRaises(ValueError):
                self.verify(data)
        data = fixture()
        data[5]["artifacts"].clear()
        with self.assertRaises(ValueError):
            self.verify(data)

    def test_request_rejects_invalid_sha_attempt_and_schema(self):
        for key, value in (
                ("schema", "legacy"),
                ("origin_run_attempt", -1),
                ("luna_sha", "not-a-sha"),
                ("moonlight_sha", "a" * 39),
                ("release_version", "2.7.1"),
                ("publish_to_kodi", "true"),
                ("include_vfm_runtime", "true")):
            data = fixture()
            data[0][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.verify(data)


if __name__ == "__main__":
    unittest.main()
