"""Duplicate titles must resolve to the app the user actually selected."""
from urllib.parse import parse_qs, urlsplit
import unittest

from resources.lib.util.appidentity import canonical_app_id, launch_url


class AppIdentityTests(unittest.TestCase):
    def test_duplicate_titles_keep_different_native_application_ids(self):
        first = launch_url('plugin://script.luna.ng', 'Desktop', '42')
        second = launch_url('plugin://script.luna.ng', 'Desktop', '99')
        self.assertNotEqual(first, second)
        self.assertEqual(parse_qs(urlsplit(first).query)['appid'], ['42'])
        self.assertEqual(parse_qs(urlsplit(second).query)['appid'], ['99'])
        self.assertEqual(parse_qs(urlsplit(first).query)['game'], ['Desktop'])
        self.assertEqual(parse_qs(urlsplit(second).query)['game'], ['Desktop'])

    def test_rename_keeps_the_same_exact_app(self):
        original = launch_url('plugin://script.luna.ng', 'Old Name', 42)
        renamed = launch_url('plugin://script.luna.ng', 'New Name', '0000000042')
        self.assertEqual(parse_qs(urlsplit(original).query)['appid'], ['42'])
        self.assertEqual(parse_qs(urlsplit(renamed).query)['appid'], ['42'])

    def test_reject_missing_invalid_and_oversized_ids(self):
        for value in (None, True, '', '-1', '12.0', '12x', '2147483648',
                      '0' * 1024):
            with self.subTest(value=str(value)[:12]):
                with self.assertRaises(ValueError):
                    canonical_app_id(value)
        self.assertEqual(canonical_app_id('0'), '0')
        self.assertEqual(canonical_app_id('2147483647'), '2147483647')


if __name__ == '__main__':
    unittest.main()
