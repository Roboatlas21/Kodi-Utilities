"""Native reuse can never mask a change to compiled Moonlight inputs."""
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
FILE = ROOT / "packaging/native_reuse_policy.py"
spec = importlib.util.spec_from_file_location("native_reuse_policy", FILE)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


def compare(changes, status="ahead", ahead=1):
    return {"status": status, "ahead_by": ahead,
            "files": [{"filename": file, "status": "modified"}
                      for file in changes]}


class NativeReusePolicyTests(unittest.TestCase):
    def test_docs_tests_and_check_workflow_may_reuse_native(self):
        self.assertTrue(policy.reusable(compare([
            "docs/guide.md", "tests/test_aml.py",
            ".github/workflows/coreelec-ng-checks.yml",
        ])))

    def test_compiled_source_and_build_recipes_require_rebuild(self):
        for file in ("src/video/aml.c", "packaging/coreelec-ng/package.mk",
                     "third_party/moonlight-common-c", "CMakeLists.txt",
                     ".github/workflows/coreelec-ng-native.yml",
                     "kernel/moonlight-vfm/driver.c"):
            with self.subTest(file=file):
                self.assertFalse(policy.reusable(compare([file])))

    def test_renames_from_source_to_docs_cannot_hide_native_change(self):
        changed = compare(["docs/archived.c"])
        changed["files"][0].update(
            status="renamed", previous_filename="src/video/aml.c")
        self.assertFalse(policy.reusable(changed))

    def test_missing_or_truncated_history_is_not_reused(self):
        self.assertFalse(policy.reusable(compare([], ahead=1)))
        self.assertFalse(policy.reusable(compare(["docs/x"], ahead=101)))
        self.assertFalse(policy.reusable(compare(["docs/x"], status="diverged")))
        self.assertFalse(policy.reusable(compare(["docs/x"] * 300)))
        self.assertFalse(policy.reusable({"status": "ahead", "ahead_by": 1}))
        self.assertFalse(policy.reusable(compare(["docs/x"], ahead=0)))

    def test_identical_commit_is_reusable(self):
        self.assertTrue(policy.reusable(compare([], status="identical", ahead=0)))


if __name__ == "__main__":
    unittest.main()
