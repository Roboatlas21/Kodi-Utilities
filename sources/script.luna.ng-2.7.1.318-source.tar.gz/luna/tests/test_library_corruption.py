"""Preserve an existing folders.json when it is damaged or inaccessible."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from resources.lib.util.library import Library, LibraryDataError


class FolderCorruptionTests(unittest.TestCase):
    def test_missing_library_is_initialized_normally(self):
        with tempfile.TemporaryDirectory() as tmp:
            lib = Library(tmp, host='host-a')
            self.assertTrue(lib.add_folder('Games'))
            self.assertEqual(Library(tmp, host='host-a').folders(), ['Games'])

    def test_malformed_and_incomplete_existing_documents_are_not_overwritten(self):
        documents = ('{broken', '[]', '{}', '{"folders":42}',
                     '{"folders":["Games"]}', '{"assign_by_host":{}}',
                     '{"folders":[]}',
                     '{"folders":["Games"],"assign_by_host":{"host":"bad"}}')
        for raw in documents:
            with self.subTest(raw=raw), tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / 'folders.json'
                path.write_text(raw)
                lib = Library(tmp, host='host-a')
                for action in (lambda: lib.folders(), lambda: lib.add_folder('New'),
                               lambda: lib.migrate_legacy()):
                    with self.assertRaises(LibraryDataError):
                        action()
                self.assertEqual(path.read_text(), raw)

    def test_explicit_empty_legacy_assignments_still_migrate(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'folders.json'
            path.write_text(json.dumps({
                'folders': ['Games'], 'assign': {}}))
            lib = Library(tmp, host='host-a')
            self.assertEqual(lib.folders(), ['Games'])
            self.assertTrue(lib.add_folder('New'))
            self.assertEqual(Library(tmp, host='host-a').folders(),
                             ['Games', 'New'])

    def test_directory_errors_complete_the_failed_kodi_listing(self):
        source = (Path(__file__).resolve().parents[1] / 'addon.py').read_text()
        handler = source.split('except LibraryDataError as error:', 1)[1].split(
            'except InvalidInputSelection', 1)[0]
        self.assertIn("args.get('action', [None])[0] == 'apps'", handler)
        self.assertIn('endOfDirectory(addon_handle, succeeded=False)', handler)

    def test_fifo_and_oversized_folders_fail_without_replacing_state(self):
        import os
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'folders.json'
            if hasattr(os, 'mkfifo'):
                os.mkfifo(path)
                with self.assertRaises(LibraryDataError):
                    Library(td, host='host-a').add_folder('New')
                self.assertTrue(path.exists())
                path.unlink()
            oversized = b' ' * (1024 * 1024 + 1)
            path.write_bytes(oversized)
            with self.assertRaises(LibraryDataError):
                Library(td, host='host-a').add_folder('New')
            self.assertEqual(path.read_bytes(), oversized)

    def test_existing_broken_symlink_cannot_be_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'folders.json'
            path.symlink_to('missing-backup.json')
            with self.assertRaises(LibraryDataError):
                Library(tmp, host='host-a').add_folder('Games')
            self.assertTrue(path.is_symlink())

    def test_save_at_exact_byte_limit_and_reject_next_edit(self):
        from resources.lib.util import library as library_module
        with tempfile.TemporaryDirectory() as td:
            expected = {'folders': ['Snow ☃'], 'assign_by_host': {}}
            limit = len(json.dumps(
                expected, ensure_ascii=False, indent=1).encode('utf-8'))
            path = Path(td) / 'folders.json'
            with mock.patch.object(library_module, 'MAX_FOLDER_BYTES', limit):
                lib = Library(td, host='host-a')
                self.assertTrue(lib.add_folder('Snow ☃'))
                original = path.read_bytes()
                self.assertEqual(len(original), limit)
                self.assertFalse(lib.add_folder('Second'))
                self.assertEqual(path.read_bytes(), original)
                self.assertEqual(Library(td, host='host-a').folders(), ['Snow ☃'])
                self.assertFalse(list(Path(td).glob('.folders.*')))

    def test_read_failure_does_not_save_empty_library(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'folders.json'
            initial = json.dumps({'folders':['Existing'], 'assign_by_host':{}})
            path.write_text(initial)
            import os
            original_open = os.open
            def failing_open(name, *args, **kwargs):
                if os.fspath(name) == os.fspath(path):
                    raise PermissionError('denied')
                return original_open(name, *args, **kwargs)
            # The safe reader deliberately bypasses builtins.open, so fault
            # injection must target the descriptor-level os.open boundary.
            with mock.patch('resources.lib.util.safejson.os.open',
                            side_effect=failing_open):
                with self.assertRaises(LibraryDataError):
                    Library(tmp).add_folder('New')
            self.assertEqual(path.read_text(), initial)


if __name__ == '__main__':
    unittest.main()
