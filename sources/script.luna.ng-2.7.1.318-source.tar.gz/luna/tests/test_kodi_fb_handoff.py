"""Exercise GUI-ready framebuffer reveal without booting Kodi."""
import ast
import os
from pathlib import Path
import stat
import tempfile
import time
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]


class KodiFrameHandoffTests(unittest.TestCase):
    def test_reveal_waits_for_new_window_and_refuses_symlinks(self):
        tree = ast.parse((ROOT / 'artwork_service.py').read_text(encoding='utf-8'))
        selected = [n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == '_reveal_kodi_gui_when_ready']
        self.assertEqual(len(selected), 1)
        now = [1.]
        window = ['']
        logs = []
        scope = {
            'os': os, 'stat': stat, 'Path': Path,
            'time': types.SimpleNamespace(monotonic=lambda: now[0]),
            'xbmc': types.SimpleNamespace(getInfoLabel=lambda _: window[0],
                                          log=lambda *v: logs.append(v),
                                          LOGINFO=1, LOGWARNING=2)
        }
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=selected, type_ignores=[])), 'artwork_service.py', 'exec'), scope)
        reveal = scope['_reveal_kodi_gui_when_ready']
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            fb0, fb1 = root / 'fb0', root / 'fb1'
            fb0.write_text('1')
            fb1.write_text('1')
            receipt = root / '.luna-session.12345678.kodi-reveal'
            receipt.write_text('pending\n')
            self.assertIsNone(reveal(root, None, 0, fb0, fb1))
            self.assertEqual(fb0.read_text(), '1')
            window[0] = 'Home'
            now[0] = 3
            since = reveal(root, None, 0, fb0, fb1)
            self.assertEqual(since, 3)
            self.assertTrue(receipt.exists())
            now[0] = 3.7
            reveal(root, since, 0, fb0, fb1)
            self.assertEqual(fb0.read_text(), '0')
            self.assertEqual(fb1.read_text(), '0')
            self.assertFalse(receipt.exists())

            fb0.write_text('1')
            link = root / '.luna-session.ABCDEFGH.kodi-reveal'
            link.symlink_to(root / 'other')
            (root / 'other').write_text('pending\n')
            reveal(root, None, 0, fb0, fb1)
            self.assertEqual(fb0.read_text(), '1')
            self.assertTrue(link.is_symlink())

    def test_missing_gui_label_gets_bounded_service_fallback(self):
        tree = ast.parse((ROOT / 'artwork_service.py').read_text())
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                        and n.name == '_reveal_kodi_gui_when_ready')
        logs = []
        scope = {'os': os, 'stat': stat, 'Path': Path,
                 'time': types.SimpleNamespace(monotonic=lambda: 15),
                 'xbmc': types.SimpleNamespace(
                     getInfoLabel=lambda _: '', log=lambda *a: logs.append(a),
                     LOGINFO=1, LOGWARNING=2)}
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=[function], type_ignores=[])), '<test>', 'exec'), scope)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            receipt = root / '.luna-session.12345678.kodi-reveal'
            receipt.write_text('pending\n')
            fb0 = root / 'fb0'
            fb0.write_text('1')
            scope['_reveal_kodi_gui_when_ready'](root, None, 0, fb0, root / 'absent')
            self.assertEqual(fb0.read_text(), '0')
            self.assertFalse(receipt.exists())

    def test_recovery_fallback_never_unblanks_during_another_stream(self):
        launch = (ROOT / 'resources/launchscripts/coreelec/launch.sh').read_text()
        display = (ROOT / 'resources/launchscripts/coreelec/display-recovery.sh').read_text()
        watchdog = (ROOT / 'resources/launchscripts/coreelec/kodi-watchdog.sh').read_text()
        self.assertIn('MOONLIGHT_DEFER_KODI_FB_REVEAL=1', launch)
        self.assertIn('unset MOONLIGHT_DEFER_KODI_FB_REVEAL', launch)
        self.assertIn('LUNA_DEFER_KODI_FB_REVEAL=', launch)
        self.assertIn('fb_target=1', display)
        self.assertIn('luna_reveal_fallback()', watchdog)
        self.assertIn('flock -n 8', watchdog)
        self.assertIn('[ "$(kodi_service_state)" != active ]', watchdog)
        self.assertIn('LUNA_TEARDOWN_V1', launch)


if __name__ == '__main__':
    unittest.main()
