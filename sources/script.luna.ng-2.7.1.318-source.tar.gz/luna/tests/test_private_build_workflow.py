"""Regression checks for the private Luna package-build workflow."""
import importlib.util
import io
import json
import tarfile
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / ".github/workflows/build-luna-ng.yml"
SCRIPT = ROOT / "packaging/verify_vfm_runtime.py"
SPEC = importlib.util.spec_from_file_location("private_vfm", SCRIPT)
VFM = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VFM)
SHA = "a" * 40


class PrivateBuildWorkflowTests(unittest.TestCase):
    def test_private_workflow_manual_only_and_pinned(self):
        source = WORKFLOW.read_text(encoding="utf-8")
        for required in (
                "  workflow_dispatch:", "  workflow_call:", "KODI_LUNA_READ_TOKEN",
                "require_latest_moonlight", "gh run download",
                "ref: ${{ steps.native.outputs.sha }}", "submodules: recursive",
                "python3 -m unittest discover -s tests -v",
                "bash tests/test_launch.sh", "luna-ng-release-lock-v1",
                "SHA256SUMS", "include_vfm_runtime", "package-addon.py"):
            self.assertIn(required, source)
        for forbidden in ("  push:", "repository: Roboatlas21/xbmc-p3i",
                          "repository: Roboatlas21/Luna-build", "git push"):
            self.assertNotIn(forbidden, source)

    def test_explicit_source_pin_is_not_rejected_for_different_run_head(self):
        source = WORKFLOW.read_text(encoding="utf-8")
        for required in (
                'expected_native_sha:', 'EXPECTED_NATIVE_SHA',
                'run.get("display_title")',
                'CoreELEC21-NG source=',
                'stamped.group(1) != sha',
                'expected != sha',
                'Legacy native artifact differs from workflow HEAD'):
            self.assertIn(required, source)
        self.assertNotIn(
            'run["head_branch"] == "feat/coreelec-ng" and run["head_sha"] != sha',
            source)

    def test_vfm_runtime_sha_and_extraction(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = root / "vfm.tar.gz"
            data = json.dumps({
                "schema": "luna-ng-vfm-v1",
                "moonlight_source_git_sha": SHA,
                "objects": {},
            }).encode("utf-8")
            with tarfile.open(archive, "w:gz") as tar:
                item = tarfile.TarInfo("manifest.json")
                item.size = len(data)
                tar.addfile(item, io.BytesIO(data))
            result = VFM.verify_and_extract(archive, root / "extracted", SHA)
            self.assertEqual(result["moonlight_source_git_sha"], SHA)
            with self.assertRaisesRegex(ValueError, "source revision"):
                VFM.verify_and_extract(archive, root / "wrong", "b" * 40)

    def test_vfm_runtime_rejects_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = root / "malicious.tar.gz"
            with tarfile.open(archive, "w:gz") as tar:
                item = tarfile.TarInfo("../escape")
                item.size = 1
                tar.addfile(item, io.BytesIO(b"x"))
            with self.assertRaisesRegex(ValueError, "Unsafe"):
                VFM.verify_and_extract(archive, root / "destination", SHA)


if __name__ == "__main__":
    unittest.main()
