"""Local-only log collection must never upload private diagnostics."""
import importlib.util
import os
from pathlib import Path
import stat
import tempfile
import types
import unittest
import zipfile
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / 'resources/lib/util/diagnosticreport.py'
spec = importlib.util.spec_from_file_location('luna_diagnostics', SCRIPT)
report = importlib.util.module_from_spec(spec)
spec.loader.exec_module(report)


class DiagnosticReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.kodi = self.root / 'kodi.log'
        (self.root / 'logfile').write_text('Luna connecting to https://user:pass@192.168.1.10/?token=abc123\n')
        self.kodi.write_text('password = secretValue\nemail=person@example.com\nMAC aa:bb:cc:dd:ee:ff\n')

    def test_report_is_private_redacted_and_never_uploaded(self):
        with mock.patch.object(report.subprocess, 'run') as run:
            path = report.create_text_report(
                self.root, self.kodi, kernel_output='GPU error from fe80::aabb:1 and 10.0.0.1\n')
        self.assertFalse(run.called)
        self.assertEqual(path.parent, self.root / 'diagnostics')
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(path.parent.stat().st_mode), 0o700)
        text = path.read_text()
        for protected in ['192.168.1.10', '10.0.0.1', 'fe80::aabb:1', 'abc123',
                          'secretValue', 'person@example.com', 'aa:bb:cc:dd:ee:ff',
                          'https://user:pass', 'paste.coreelec.org']:
            self.assertNotIn(protected, text)
        self.assertIn('LOCAL FILE ONLY', text)
        self.assertIn('Nothing was uploaded', text)
        self.assertIn('Luna session log', text)
        self.assertIn('Kodi log', text)
        self.assertIn('Kernel log', text)
        self.assertIn('have been masked', text)
        self.assertIn('connecting', text)
        self.assertEqual((self.root / 'logfile').read_text(),
                         'Luna connecting to https://user:pass@192.168.1.10/?token=abc123\n')

    def test_report_includes_previous_kodi_launch_timings(self):
        old = self.root / 'kodi.old.log'
        old.write_text('LUNA_LAUNCH_TIMING_V1 source=kodi '
                       'stage=runtime-validation step_ms=52 total_ms=180\n')
        report_path = report.create_text_report(self.root, self.kodi, kernel_output='')
        body = report_path.read_text()
        self.assertIn('Previous Kodi log (launch preflight)', body)
        self.assertIn('stage=runtime-validation', body)
        self.assertIn('step_ms=52', body)

    def test_two_reports_get_distinct_paths_and_originals_stay_unchanged(self):
        first = report.create_text_report(self.root, self.kodi, kernel_output='failure 1\n')
        second = report.create_text_report(self.root, self.kodi, kernel_output='failure 2\n')
        self.assertNotEqual(first, second)
        self.assertIn('failure 1', first.read_text())
        self.assertIn('failure 2', second.read_text())

    def test_malicious_report_directory_symlink_is_refused(self):
        external = self.root / 'external'
        external.mkdir()
        (self.root / 'diagnostics').symlink_to(external, target_is_directory=True)
        with self.assertRaises((OSError, FileExistsError)):
            report.create_text_report(self.root, self.kodi, kernel_output='hello')
        self.assertEqual(list(external.iterdir()), [])

    def test_symlinked_source_log_not_followed(self):
        secret = self.root / 'secret'
        secret.write_text('secret_should_not_leak=CONFIDENTIAL')
        self.kodi.unlink()
        self.kodi.symlink_to(secret)
        local = report.create_text_report(self.root, self.kodi, kernel_output='')
        self.assertNotIn('CONFIDENTIAL', local.read_text())
        self.assertIn('not available: log could not be read safely', local.read_text())

    def test_large_logs_are_bounded(self):
        self.kodi.write_text(('line\n' * 1200) + ('end marker\n'))
        local = report.create_text_report(self.root, self.kodi, kernel_output='')
        self.assertLess(local.stat().st_size, 25000)
        self.assertIn('end marker', local.read_text())

    def test_recovery_events_survive_thousands_of_later_debug_samples(self):
        early = ('Unrecoverable frame 781: lost data from 10.0.0.59 '
                 'token=very-secret-123\n')
        normal = 'NET_DIAG_V1 udp_datagrams=+400 abandon_events=+0\n'
        (self.root / 'logfile').write_text(
            early + (normal * 3500) + 'ordinary session finished\n')
        path = report.create_text_report(self.root, self.kodi, kernel_output='')
        body = path.read_text()
        self.assertIn('significant events throughout session', body)
        self.assertIn('Unrecoverable frame 781', body)
        self.assertNotIn('very-secret-123', body)
        self.assertNotIn('10.0.0.59', body)
        self.assertIn('ordinary session finished', body)
        self.assertLess(path.stat().st_size, 150000)

    def test_many_events_keep_first_spaced_and_last_bounded(self):
        log = self.root / 'logfile'
        log.write_text(''.join(
            'Sending RFI request for unrecoverable frame %d\n' % i
            for i in range(1200)))
        events = report._read_log_highlights(log)
        self.assertIn('frame 0', events)
        self.assertIn('frame 1199', events)
        self.assertIn('Selected ', events)
        self.assertLessEqual(len(events.splitlines()),
                             report.MAX_HIGHLIGHT_FIRST +
                             report.MAX_HIGHLIGHT_WINDOWS +
                             report.MAX_HIGHLIGHT_RECENT + 1)

    def test_event_scanner_respects_byte_window_and_rejects_symlinks(self):
        log = self.root / 'logfile'
        log.write_text('Unrecoverable frame 1\n' + ('quiet line\n' * 500) +
                       'Unrecoverable frame 2\n')
        with mock.patch.object(report, 'MAX_HIGHLIGHT_SCAN_BYTES', 500):
            highlights = report._read_log_highlights(log)
        self.assertNotIn('frame 1', highlights)
        self.assertIn('frame 2', highlights)
        other = self.root / 'secret-source'
        other.write_text('Unrecoverable frame 999\n')
        symlink = self.root / 'not-a-safe-log'
        symlink.symlink_to(other)
        self.assertEqual(report._read_log_highlights(symlink), '')

    def test_default_report_api_returns_zip_bundle(self):
        result = report.create_report(self.root, self.kodi, kernel_output='')
        self.assertEqual(result.suffix, '.zip')
        with zipfile.ZipFile(result) as archive:
            self.assertIn('summary.txt', archive.namelist())
            self.assertIn('logs/luna-session.log', archive.namelist())

    def test_bundle_keeps_full_available_session_timeline_not_only_tail(self):
        # More than 300 per-second samples must remain in the full log.
        old = ('Unrecoverable frame 781: missing shards\n'
               'Connecting to 10.0.0.59 token=secret123\n')
        network = ''.join(
            'NET_DIAG_V1 udp_datagrams=+%d abandoned_data=+0\n' % i
            for i in range(2400))
        (self.root / 'logfile').write_text(
            old + network + 'STREAM_DIAG_V1 sink_fps=60\n')
        bundle = report.create_report_bundle(
            self.root, self.kodi, kernel_output='kernel line\n')
        self.assertEqual(bundle.suffix, '.zip')
        self.assertEqual(stat.S_IMODE(bundle.stat().st_mode), 0o600)
        with zipfile.ZipFile(bundle) as archive:
            self.assertEqual(set(archive.namelist()),
                             set(report.BUNDLE_OUTPUT_LIMITS))
            complete = archive.read('logs/luna-session.log').decode()
            summary = archive.read('summary.txt').decode()
            self.assertIn('Unrecoverable frame 781', complete)
            self.assertIn('udp_datagrams=+0', complete)
            self.assertIn('udp_datagrams=+2399', complete)
            self.assertIn('STREAM_DIAG_V1 sink_fps=60', complete)
            self.assertIn('Archive coverage', summary)
            self.assertIn('Unrecoverable frame 781', summary)
            self.assertIn('kernel line', archive.read('logs/kernel.log').decode())
            for sensitive in ('10.0.0.59', 'secret123'):
                self.assertNotIn(sensitive, complete)
                self.assertNotIn(sensitive, summary)

    def test_bundle_redacts_multiline_credentials_and_pem_in_full_log(self):
        content = (
            'Start of session\n'
            '<ns:api_key method="testing">\n'
            'known_short_secret\n'
            '</ns:api_key>\n'
            '-----BEGIN PRIVATE KEY-----\n'
            'another_raw_secret\n'
            '-----END PRIVATE KEY-----\n'
            'Video receiver: 42 accepted packets\n')
        (self.root / 'logfile').write_text(content)
        private = report.create_report_bundle(
            self.root, self.kodi, kernel_output='')
        exported = report.export_report(private, self.root / 'share')
        for archive_path in (private, exported):
            with zipfile.ZipFile(archive_path) as archive:
                full = archive.read('logs/luna-session.log').decode()
                self.assertNotIn('known_short_secret', full)
                self.assertNotIn('another_raw_secret', full)
                self.assertIn('Video receiver: 42 accepted packets', full)
                self.assertIn('[PEM DATA REDACTED]', full)
                self.assertIn('[XML CREDENTIAL BLOCK REDACTED]', full)
        self.assertEqual((self.root / 'logfile').read_text(), content)
        self.assertEqual(stat.S_IMODE(exported.stat().st_mode), 0o644)

    def test_bundle_coverage_explicit_when_old_source_bytes_excluded(self):
        (self.root / 'logfile').write_text(
            'OLDEST RAW RECORD MUST NOT APPEAR\n' +
            'NET_DIAG_V1 active=1\n' * 200 +
            'LATEST RECORD\n')
        small = tuple(
            (label, member, 200 if member == 'logs/luna-session.log' else cap)
            for label, member, cap in report.BUNDLE_MEMBERS)
        with mock.patch.object(report, 'BUNDLE_MEMBERS', small):
            bundle = report.create_report_bundle(
                self.root, self.kodi, kernel_output='')
        with zipfile.ZipFile(bundle) as archive:
            full = archive.read('logs/luna-session.log').decode()
            summary = archive.read('summary.txt').decode()
        self.assertNotIn('OLDEST RAW RECORD', full)
        self.assertIn('LATEST RECORD', full)
        self.assertIn('older bytes unavailable', summary)

    def test_truncated_window_inside_pem_or_xml_never_exposes_secret(self):
        # Both the ZIP member and its summary/highlight sources must carry
        # credential state from before their independent byte cutoffs.
        fixtures = (
            ('-----BEGIN PRIVATE KEY-----\n', '-----END PRIVATE KEY-----\n'),
            ('<session_token>\n', '</session_token>\n'),
        )
        for opener, closer in fixtures:
            with self.subTest(opener=opener):
                secret = 'short_unknown_secret_not_tagged_on_each_line'
                (self.root / 'logfile').write_text(
                    'startup\n' + opener +
                    (secret + '\n') * 20 + closer +
                    'NET_DIAG_V1 udp_datagrams=+17\n')
                narrow = tuple(
                    (name, member, 75 if member == 'logs/luna-session.log' else n)
                    for name, member, n in report.BUNDLE_MEMBERS)
                with mock.patch.object(report, 'BUNDLE_MEMBERS', narrow), \
                     mock.patch.object(report, 'MAX_SOURCE_BYTES', 75), \
                     mock.patch.object(report, 'MAX_HIGHLIGHT_SCAN_BYTES', 75):
                    bundle = report.create_report_bundle(
                        self.root, self.kodi, kernel_output='')
                with zipfile.ZipFile(bundle) as archive:
                    combined = '\n'.join(
                        archive.read(name).decode('utf-8')
                        for name in archive.namelist())
                self.assertNotIn(secret, combined)
                self.assertIn('udp_datagrams=+17', combined)

    def test_ambiguous_context_before_cutoff_omits_log_safely(self):
        text = ('-----BEGIN PRIVATE KEY-----\n' +
                'secret_in_unverified_record\n' * 50)
        (self.root / 'logfile').write_text(text)
        with mock.patch.object(report, 'BUNDLE_CONTEXT_SCAN_MAX_BYTES', 200), \
             mock.patch.object(report, 'MAX_SOURCE_BYTES', 80), \
             mock.patch.object(report, 'MAX_HIGHLIGHT_SCAN_BYTES', 80):
            bundle = report.create_report_bundle(self.root, self.kodi,
                                                 kernel_output='')
        with zipfile.ZipFile(bundle) as archive:
            combined = '\n'.join(
                archive.read(name).decode('utf-8')
                for name in archive.namelist())
        self.assertNotIn('secret_in_unverified_record', combined)
        self.assertIn('(omitted: log exceeds safe credential-context scan)',
                      combined)

    def test_rolling_native_samples_join_full_session_zip_after_budget(self):
        previous = self.root / 'native-diagnostics.rolling.1'
        current = self.root / 'native-diagnostics.rolling.0'
        previous.write_text('NET_DIAG_V1 abandoned_data=+14\n'
                            'user token=secret14\n')
        current.write_text('NET_DIAG_V1 abandoned_data=+19\n')
        bundle = report.create_report_bundle(
            self.root, self.kodi, kernel_output='')
        shared = report.export_report(bundle, self.root / 'share')
        for candidate in (bundle, shared):
            with zipfile.ZipFile(candidate) as archive:
                old = archive.read('logs/native-rolling-previous.log').decode()
                newest = archive.read('logs/native-rolling-current.log').decode()
                self.assertIn('abandoned_data=+14', old)
                self.assertIn('abandoned_data=+19', newest)
                self.assertNotIn('secret14', old)
                self.assertIn('Native rolling diagnostics', archive.read(
                    'summary.txt').decode())
        self.assertEqual(previous.read_text(),
                         'NET_DIAG_V1 abandoned_data=+14\nuser token=secret14\n')

    def test_previous_native_log_survives_next_launch_in_redacted_zip(self):
        original = 'STREAM_DIAG_V1 last_session=+4\npassword=private-one\n'
        (self.root / 'logfile.old').write_text(original)
        (self.root / 'logfile').write_text('STREAM_DIAG_V1 current_session=+2\n')
        bundle = report.create_report_bundle(self.root, self.kodi,
                                             kernel_output='')
        with zipfile.ZipFile(bundle) as archive:
            old = archive.read('logs/luna-session-previous.log').decode()
            current = archive.read('logs/luna-session.log').decode()
            self.assertIn('last_session=+4', old)
            self.assertNotIn('private-one', old)
            self.assertIn('current_session=+2', current)
            self.assertNotIn('last_session=+4', current)
        self.assertEqual((self.root / 'logfile.old').read_text(), original)

    def test_prior_session_rolling_diagnostics_stay_separate_and_redacted(self):
        (self.root / 'native-diagnostics.prior.session').write_text(
            '.luna-session.1234abcd\n')
        (self.root / 'native-diagnostics.prior.1').write_text(
            'NET_DIAG_V1 prior_start=+17\n')
        (self.root / 'native-diagnostics.prior.0').write_text(
            'NET_DIAG_V1 prior_end=+29\npassword=prior-secret\n')
        (self.root / 'native-diagnostics.rolling.0').write_text(
            'NET_DIAG_V1 new_session=+3\n')
        bundle = report.create_report_bundle(self.root, self.kodi,
                                            kernel_output='')
        with zipfile.ZipFile(bundle) as archive:
            previous = archive.read('logs/native-prior-current.log').decode()
            current = archive.read('logs/native-rolling-current.log').decode()
            self.assertIn('prior_end=+29', previous)
            self.assertNotIn('prior-secret', previous)
            self.assertIn('new_session=+3', current)
            self.assertNotIn('prior_end=+29', current)
            self.assertIn('1234abcd',
                          archive.read('logs/native-prior-session-id.txt').decode())

    def test_bundle_symlink_source_not_read_or_archived(self):
        secret = self.root / 'private-elsewhere'
        secret.write_text('RAW PRIVATE SIGNAL 8413\n')
        self.kodi.unlink()
        self.kodi.symlink_to(secret)
        bundle = report.create_report_bundle(
            self.root, self.kodi, kernel_output='')
        with zipfile.ZipFile(bundle) as archive:
            kodi = archive.read('logs/kodi.log').decode()
            self.assertIn('not available', kodi)
            self.assertNotIn('RAW PRIVATE SIGNAL', kodi)
        self.assertEqual(secret.read_text(), 'RAW PRIVATE SIGNAL 8413\n')

    def test_bundle_export_rechecks_redaction_and_keeps_private_source(self):
        bundle = report.create_report_bundle(
            self.root, self.kodi, kernel_output='')
        with zipfile.ZipFile(bundle, 'r') as archive:
            saved = {name: archive.read(name) for name in archive.namelist()}
        saved['logs/kodi.log'] = (
            b'password=do_not_publish\n'
            b'<session_token>\nplaintext_in_xml\n</session_token>\n')
        # Simulate an untrusted change made to the locally owned ZIP after
        # creation. SMB export must re-redact, not just copy archive bytes.
        with zipfile.ZipFile(bundle, 'w') as archive:
            for name, body in saved.items():
                archive.writestr(name, body)
        private_before = bundle.read_bytes()
        shared = report.export_report(bundle, self.root / 'share')
        self.assertEqual(private_before, bundle.read_bytes())
        with zipfile.ZipFile(shared) as archive:
            safe = archive.read('logs/kodi.log').decode()
        self.assertNotIn('do_not_publish', safe)
        self.assertNotIn('plaintext_in_xml', safe)
        self.assertIn('[XML CREDENTIAL BLOCK REDACTED]', safe)

    def test_bundle_rejects_unexpected_zip_member_before_publication(self):
        bundle = report.create_report_bundle(
            self.root, self.kodi, kernel_output='')
        with zipfile.ZipFile(bundle, 'a') as archive:
            archive.writestr('../unsafe.txt', 'password=TOPSECRET')
        target = self.root / 'share'
        with self.assertRaises(OSError):
            report.export_report(bundle, target)
        self.assertFalse((target / 'Luna' / bundle.name).exists())

    def test_bundle_export_fails_closed_on_oversized_zip_entry(self):
        bundle = report.create_report_bundle(
            self.root, self.kodi, kernel_output='')
        limits = dict(report.BUNDLE_OUTPUT_LIMITS)
        limits['logs/luna-session.log'] = 1
        with mock.patch.object(report, 'BUNDLE_OUTPUT_LIMITS', limits):
            with self.assertRaises(OSError):
                report.export_report(bundle, self.root / 'share')
        self.assertTrue(bundle.exists())
        self.assertFalse((self.root / 'share' / 'Luna' / bundle.name).exists())

    def test_report_ui_uses_zip_not_legacy_text_summary(self):
        with mock.patch.object(report, 'create_report',
                               return_value=Path('/test/report.zip')) as builder, \
             mock.patch.object(report, 'export_report',
                               return_value=Path('/share/report.zip')), \
             mock.patch.object(report, 'show_in_kodi') as shown:
            self.assertTrue(report.save_report_with_dialog(
                self.root, self.kodi))
        builder.assert_called_once()
        shown.assert_called_once_with(Path('/share/report.zip'))

    def test_missing_logs_still_produce_local_report(self):
        (self.root / 'logfile').unlink()
        self.kodi.unlink()
        with mock.patch.object(report.subprocess, 'run', side_effect=OSError('no dmesg')):
            local = report.create_text_report(self.root, self.kodi)
        self.assertIn('not available', local.read_text())

    def test_bearer_pin_xml_and_pem_redaction(self):
        value = ('Authorization: Bearer supersecret\n'
                 'PIN=1122\n<token>abcPRIVATE</token>\n'
                 '-----BEGIN PRIVATE KEY-----\nsecretblock\n'
                 '-----END PRIVATE KEY-----\n')
        redacted = report.redact(value)
        for secret in ['supersecret', '1122', 'abcPRIVATE', 'secretblock']:
            self.assertNotIn(secret, redacted)
        self.assertIn('[PEM DATA REDACTED]', redacted)

    def test_short_prefixed_credentials_are_scrubbed_in_log_formats(self):
        fixtures = (
            'session_token=abc123\n'
            'api_token: xyz12\n'
            'my_password: nope123\n'
            '"session_token": "json12"\n'
            "'service.auth_token': 'tiny17'\n"
            'SESSION_TOKEN = capital18\n'
            'the_api_key = foo19\n'
            'module.secret = bar20\n'
            'Decoder: dropped 2 frames\n')
        result = report.redact(fixtures)
        for value in ('abc123', 'xyz12', 'nope123', 'json12', 'tiny17',
                      'capital18', 'foo19', 'bar20'):
            self.assertNotIn(value, result)
        self.assertIn('Decoder: dropped 2 frames', result)
        # Export applies a second redaction pass; it must remain safe.
        self.assertEqual(report.redact(result), result)

    def test_multiline_prefixed_xml_credentials_are_scrubbed(self):
        content = (
            '<session_token>\nshortXMLvalue\n</session_token>\n'
            '<ns:api_key method="AUTO">\nscopedXMLvalue\n</ns:api_key>\n'
            '<my_password>passwordXMLvalue</my_password>\n'
            '<system><state>Decoder ready</state></system>\n')
        cleaned = report.redact(content)
        for value in ('shortXMLvalue', 'scopedXMLvalue', 'passwordXMLvalue'):
            self.assertNotIn(value, cleaned)
        self.assertIn('Decoder ready', cleaned)

    def test_short_credentials_do_not_reappear_in_samba_export(self):
        content = (
            'connection to VM failed\n'
            'session_token=short41\n'
            'api_token = short42\n'
            'my_password: short43\n'
            '{"session_token": "short44"}\n'
            '<session_token>\nshort45\n</session_token>\n'
            'Decoder: frame pacing delay 7 ms\n')
        (self.root / 'logfile').write_text(content, encoding='utf-8')
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        shared = report.export_report(private, self.root / 'share')
        for body in (private.read_text(encoding='utf-8'),
                     shared.read_text(encoding='utf-8')):
            for word in ('short41', 'short42', 'short43', 'short44', 'short45'):
                self.assertNotIn(word, body)
            self.assertIn('Decoder: frame pacing delay 7 ms', body)
        # Never rewrite raw input logs, even when they contain credentials.
        self.assertEqual((self.root / 'logfile').read_text(encoding='utf-8'),
                         content)

    def test_native_pairing_pin_and_free_text_hostname_are_redacted(self):
        raw = (
            'Please enter the following PIN on the target PC: 8293\n'
            'Connecting to gaming-vm...\n'
            'Paired with desktop-pc.local\n'
            'Sunshine host is gamerbox\n'
            'Peer user@game-pc.local\n'
            'Decoder recovered after timeout\n')
        cleaned = report.redact(raw)
        for sensitive in ('8293', 'gaming-vm', 'desktop-pc.local',
                          'gamerbox', 'user@game-pc.local'):
            self.assertNotIn(sensitive, cleaned)
        self.assertIn('connecting to', cleaned.lower())
        self.assertIn('Decoder recovered after timeout', cleaned)

    def test_real_coreelec_and_jellyfin_identity_formats_never_escape(self):
        raw = (
            '[dhd-wlan0] wl_cfg80211_connect : Connecting with AP '
            'ssid "TheNewFunkyMonkey", len (17), sec=wpa2psk\n'
            '## CoreELEC Addon ## system::set_hostname ## ChrisELEC\n'
            'onSuccessfulConnection with server RocketCloud\n'
            'No session yet for device b9bf58c8-5aca-4a66-a772-495b8d8084fb\n'
            'Decoder: dropped 2 frames\n')
        once = report.redact(raw)
        for private in ('TheNewFunkyMonkey', 'ChrisELEC', 'RocketCloud',
                        'b9bf58c8-5aca-4a66-a772-495b8d8084fb'):
            self.assertNotIn(private, once)
        for marker in ('[SSID REDACTED]', '[HOST REDACTED]', '[UUID REDACTED]'):
            self.assertIn(marker, once)
        self.assertIn('Decoder: dropped 2 frames', once)
        self.assertEqual(report.redact(once), once)

        (self.root / 'logfile').write_text(raw)
        private = report.create_text_report(self.root, self.kodi, kernel_output=raw)
        shared = report.export_report(private, self.root / 'share')
        for value in (private.read_text(), shared.read_text()):
            for secret in ('TheNewFunkyMonkey', 'ChrisELEC', 'RocketCloud',
                           'b9bf58c8-5aca-4a66-a772-495b8d8084fb'):
                self.assertNotIn(secret, value)
            self.assertIn('Decoder: dropped 2 frames', value)

    def test_smb_export_redacts_plain_language_identifiers(self):
        (self.root / 'logfile').write_text(
            'Please enter the following PIN on the target PC: 3498\n'
            'Connecting to PC-LIVINGROOM...\n'
            'Paired with windows-vm\n'
            'Decoder: dropped 7 frames\n')
        original = report.create_text_report(self.root, self.kodi, kernel_output='')
        exported = report.export_report(original, self.root / 'shared')
        text = exported.read_text()
        for sensitive in ('3498', 'PC-LIVINGROOM', 'windows-vm'):
            self.assertNotIn(sensitive, text)
        self.assertIn('dropped 7 frames', text)
        self.assertEqual(exported.stat().st_mode & 0o777, 0o644)

    def test_export_is_atomic_readable_redacted_and_preserves_original(self):
        (self.root / 'logfile').write_text(
            'Authorization: Bearer OPENKEY\n'
            'Cookie: session=otherkey\n'
            'Host=private-machine\n'
            'secret location /storage/.kodi/userdata/passwords.xml\n'
            'User at C:\\Users\\Private\\myfile.txt\n'
            'Source \\\\NAS\\Movies\\Private.mkv\n'
            'opaque 0123456789abcdef0123456789abcdef0123456789abcdef\n'
            'Video decoder: frame ready\n')
        private = report.create_text_report(self.root, self.kodi, kernel_output='warning')
        share_root = self.root / 'samba-logfiles'
        exported = report.export_report(private, share_root)
        self.assertEqual(exported.parent, share_root / 'Luna')
        self.assertEqual(exported.name, private.name)
        self.assertEqual(stat.S_IMODE(exported.stat().st_mode), 0o644)
        self.assertEqual(stat.S_IMODE(exported.parent.stat().st_mode), 0o755)
        self.assertEqual(stat.S_IMODE(private.stat().st_mode), 0o600)
        text = exported.read_text()
        for value in ('OPENKEY', 'otherkey', 'private-machine', 'passwords.xml',
                      'C:\\Users\\Private', '\\\\NAS\\Movies', 
                      '0123456789abcdef0123456789abcdef0123456789abcdef'):
            self.assertNotIn(value, text)
        self.assertIn('Video decoder: frame ready', text)
        self.assertIn('Nothing was uploaded', text)
        self.assertTrue(private.exists())

    def test_export_rejects_symlink_folder_and_refuses_overwrite(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        outside = self.root / 'outside'
        outside.mkdir()
        share = self.root / 'share'
        share.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(OSError):
            report.export_report(private, share)
        self.assertFalse(list(outside.iterdir()))
        share.unlink()
        exported = report.export_report(private, share)
        before = exported.read_bytes()
        with self.assertRaises(FileExistsError):
            report.export_report(private, share)
        self.assertEqual(before, exported.read_bytes())

    def test_export_rejects_arbitrary_source_and_does_not_publish(self):
        plain = self.root / 'luna-diagnostics-unknown.txt'
        plain.write_text('PRIVATE RAW FILE')
        shared = self.root / 'share'
        with self.assertRaises(OSError):
            report.export_report(plain, shared)
        self.assertFalse((shared / 'Luna' / plain.name).exists())

    def test_export_confirmation_has_no_review_prompt_or_upload(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        shared = report.export_report(private, self.root / 'share')
        dialog = mock.Mock()
        import sys
        with mock.patch.dict(
                sys.modules, {'xbmcgui': types.SimpleNamespace(Dialog=lambda: dialog)}):
            report.show_in_kodi(shared)
        dialog.ok.assert_called_once()
        dialog.yesno.assert_not_called()
        dialog.textviewer.assert_not_called()
        self.assertIn('Saved redacted', dialog.ok.call_args.args[1])
        self.assertIn('CoreELEC', dialog.ok.call_args.args[1])

    def test_export_directory_swap_before_open_is_rejected(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        share = self.root / 'share'
        outside = self.root / 'outside'
        outside.mkdir()
        real_open = os.open
        swapped = [False]

        def replace_before_open(path, flags, *args, **kwargs):
            if path == 'Luna' and kwargs.get('dir_fd') is not None:
                (share / 'Luna').rename(share / 'Luna-original')
                (share / 'Luna').symlink_to(outside, target_is_directory=True)
                swapped[0] = True
            return real_open(path, flags, *args, **kwargs)

        with mock.patch.object(report.os, 'open', side_effect=replace_before_open):
            with self.assertRaises(OSError):
                report.export_report(private, share)
        self.assertTrue(swapped[0])
        self.assertEqual(list(outside.iterdir()), [])
        self.assertTrue(private.exists())

    def test_export_directory_swap_during_link_uses_open_fd(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        share = self.root / 'share'
        outside = self.root / 'outside'
        outside.mkdir()
        real_link = os.link
        swapped = [False]

        def replace_during_link(src, dst, *args, **kwargs):
            (share / 'Luna').rename(share / 'Luna-original')
            (share / 'Luna').symlink_to(outside, target_is_directory=True)
            swapped[0] = True
            return real_link(src, dst, *args, **kwargs)

        with mock.patch.object(report.os, 'link', side_effect=replace_during_link):
            with self.assertRaisesRegex(OSError, 'directory changed'):
                report.export_report(private, share)
        self.assertTrue(swapped[0])
        self.assertEqual(list(outside.iterdir()), [])
        anchored = share / 'Luna-original' / private.name
        self.assertTrue(anchored.exists())
        self.assertIn('LOCAL FILE ONLY', anchored.read_text())
        self.assertTrue(private.exists())

    def test_export_rejects_symlinked_ancestor(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        outside = self.root / 'outside'
        outside.mkdir()
        shortcut = self.root / 'shortcut'
        shortcut.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(OSError):
            report.export_report(private, shortcut / 'share')
        self.assertEqual(list(outside.iterdir()), [])

    def test_export_read_only_or_permission_error_preserves_private_report(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        original = private.read_bytes()
        share = self.root / 'share'
        real_mkdir = os.mkdir

        def fail_directory_creation(path, *args, **kwargs):
            if path == 'Luna' and kwargs.get('dir_fd') is not None:
                raise OSError(30, 'Read-only filesystem')
            return real_mkdir(path, *args, **kwargs)

        with mock.patch.object(report.os, 'mkdir', side_effect=fail_directory_creation):
            with self.assertRaises(OSError):
                report.export_report(private, share)
        self.assertEqual(private.read_bytes(), original)
        self.assertFalse((share / 'Luna').exists())

    def test_export_failed_link_cleans_unpublished_temporary(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        original = private.read_bytes()
        share = self.root / 'share'
        with mock.patch.object(report.os, 'link',
                               side_effect=PermissionError('Access denied')):
            with self.assertRaises(PermissionError):
                report.export_report(private, share)
        self.assertEqual(list((share / 'Luna').iterdir()), [])
        self.assertEqual(private.read_bytes(), original)

    def test_export_rejects_changed_report_inode_after_hardlink(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        original = private.read_bytes()
        share = self.root / 'share'
        real_link = os.link

        def replace_target_after_link(src, dst, *args, **kwargs):
            result = real_link(src, dst, *args, **kwargs)
            target = share / 'Luna' / dst
            target.unlink()
            target.write_text('an unrelated replacement file')
            return result

        with mock.patch.object(report.os, 'link',
                               side_effect=replace_target_after_link):
            with self.assertRaisesRegex(OSError, 'destination changed'):
                report.export_report(private, share)
        self.assertEqual(private.read_bytes(), original)

    def test_export_rejects_share_root_swap_after_hardlink(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        share = self.root / 'share'
        outside = self.root / 'outside'
        outside.mkdir()
        real_link = os.link

        def replace_share_after_link(src, dst, *args, **kwargs):
            result = real_link(src, dst, *args, **kwargs)
            share.rename(self.root / 'share-original')
            share.symlink_to(outside, target_is_directory=True)
            return result

        with mock.patch.object(report.os, 'link',
                               side_effect=replace_share_after_link):
            with self.assertRaises(OSError):
                report.export_report(private, share)
        self.assertEqual(list(outside.iterdir()), [])
        self.assertTrue((self.root / 'share-original' / 'Luna' / private.name).exists())
        self.assertTrue(private.exists())

    def test_shared_report_handler_preserves_created_private_file(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        dialog = mock.Mock()
        import sys
        with mock.patch.dict(sys.modules, {
                'xbmcgui': types.SimpleNamespace(Dialog=lambda: dialog)}), \
             mock.patch.object(report, 'create_report', return_value=private), \
             mock.patch.object(report, 'export_report',
                               side_effect=OSError('Read-only SMB share')), \
             mock.patch.object(report, 'show_in_kodi') as show:
            errors = []
            self.assertFalse(report.save_report_with_dialog(
                self.root, self.kodi, log_failure=errors.append))
        self.assertEqual(errors, ['OSError'])
        self.assertTrue(private.exists())
        self.assertIn(str(private), dialog.ok.call_args.args[1])
        self.assertIn('Private redacted report saved to:',
                      dialog.ok.call_args.args[1])
        show.assert_not_called()

    def test_shared_report_handler_reports_private_creation_error(self):
        dialog = mock.Mock()
        import sys
        with mock.patch.dict(sys.modules, {
                'xbmcgui': types.SimpleNamespace(Dialog=lambda: dialog)}), \
             mock.patch.object(report, 'create_report',
                               side_effect=PermissionError('Private storage denied')), \
             mock.patch.object(report, 'export_report') as exported:
            self.assertFalse(report.save_report_with_dialog(self.root, self.kodi))
        exported.assert_not_called()
        self.assertIn('Could not create the private diagnostic report',
                      dialog.ok.call_args.args[1])
        self.assertNotIn('Private redacted report saved to:',
                         dialog.ok.call_args.args[1])

    def test_shared_report_handler_confirms_success(self):
        private = report.create_text_report(self.root, self.kodi, kernel_output='')
        exported = self.root / 'share' / 'Luna' / private.name
        with mock.patch.object(report, 'create_report', return_value=private), \
             mock.patch.object(report, 'export_report', return_value=exported), \
             mock.patch.object(report, 'show_in_kodi') as show:
            self.assertTrue(report.save_report_with_dialog(self.root, self.kodi))
        show.assert_called_once_with(exported)


if __name__ == '__main__':
    unittest.main()
