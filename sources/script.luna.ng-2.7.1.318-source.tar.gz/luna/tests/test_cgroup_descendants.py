"""Exact/descendant systemd cgroup ownership checks."""
from pathlib import Path
import subprocess
import tempfile
import unittest


SHELL = (Path(__file__).resolve().parents[1] /
         'resources/launchscripts/coreelec/session-ownership.sh')


class CgroupDescendantTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.proc = Path(self.tmp.name) / 'cgroup'
        self.group = '/system.slice/luna-ng-session-123.service'

    def check(self, path, requested=None):
        self.proc.write_text('0::' + path + '\n')
        return subprocess.run(
            ['sh', '-c', '. "$1"; luna_proc_in_cgroup "$2" "$3"',
             'luna-test', str(SHELL), str(self.proc), requested or self.group],
            capture_output=True, text=True).returncode

    def test_exact_session(self):
        self.assertEqual(self.check(self.group), 0)

    def test_nested_and_deeply_nested_sessions(self):
        self.assertEqual(self.check(self.group + '/app'), 0)
        self.assertEqual(self.check(self.group + '/app/worker'), 0)

    def test_similarly_named_sibling_is_not_a_descendant(self):
        self.assertEqual(self.check(self.group + 'extra'), 1)
        self.assertEqual(self.check('/system.slice/other.service'), 1)

    def test_invalid_root_or_missing_proof_fails_closed(self):
        self.assertEqual(self.check(self.group, requested='/'), 2)
        self.proc.unlink()
        result = subprocess.run(
            ['sh', '-c', '. "$1"; luna_proc_in_cgroup "$2" "$3"',
             'luna-test', str(SHELL), str(self.proc), self.group],
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)


if __name__ == '__main__':
    unittest.main()
