"""Regression guard: Luna's existing Debug switch owns pacing diagnostics.

No second settings toggle, no implicit frame graph activation, and no
change to frame-pacing defaults or the selected video pipeline.
"""
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
settings = ET.parse(root / "resources/settings.xml").getroot()
debug = settings.find(".//setting[@id='debug_mode']")
assert debug is not None and debug.attrib["type"] == "boolean"
assert debug.findtext("default") == "false"
assert settings.find(".//setting[@id='pacing_diagnostics']") is None
helper = (root / "resources/lib/util/moonlighthelper.py").read_text()
assert "env['MOONLIGHT_STREAM_DIAGNOSTICS'] = (" in helper
assert "'1' if self.plugin.getSettingBool('debug_mode') else '0'" in helper
assert "env['MOONLIGHT_FRAME_PACING'] = frame_pacing" in helper
print("Luna debug-only pacing diagnostics wiring unchanged")
