"""Validate the native-bundle safety checks and Kodi ZIP file layout."""
import hashlib
import importlib.util
import io
import json
import subprocess
import stat
import struct
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path
from xml.etree import ElementTree

SCRIPT = Path(__file__).resolve().parents[1] / "packaging" / "package_ng.py"
spec = importlib.util.spec_from_file_location("luna_ng_packaging", SCRIPT)
package_ng = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package_ng)


def fake_elf(elf_class=1, machine=40):
    data = bytearray(64)
    data[:4] = bytes((127,)) + b"ELF"
    data[4] = elf_class
    data[5] = 1
    struct.pack_into("<H", data, 18, machine)
    return bytes(data)


def write_bundle(path, *, elf_class=1, omit=None, bad_entry=None,
                 wrong_digest=False, no_manifest=False, source_sha=None):
    if source_sha is None:
        source_sha = package_ng.read_pinned_source_revision(SCRIPT.parents[1])
    with tarfile.open(path, "w:gz") as tar:
        objects = {}
        for name in sorted(package_ng.NATIVE_FILES):
            if name == omit:
                continue
            content = fake_elf(elf_class)
            if name == "bin/coreelec-ng/moonlight":
                content += package_ng.FIRST_VIDEO_BIN_TOKEN
            elif name == "lib/coreelec-ng/libmoonlight-aml.so":
                content += package_ng.FIRST_VIDEO_AML_TOKEN
            item = tarfile.TarInfo("./" + name)
            item.mode = 0o755
            item.size = len(content)
            tar.addfile(item, io.BytesIO(content))
            expected = package_ng.EXPECTED_LIB_SONAMES.get(name)
            needed = (["libgamestream.so.4", "libc.so.6"] if name.startswith("bin/")
                      else ["libamcodec.so", "libc.so.6"] if name.endswith("libmoonlight-aml.so")
                      else ["libmoonlight-common.so.4"] if name.endswith("libgamestream.so.4")
                      else ["libc.so.6"])
            objects[name] = {"class": "ELF32", "machine": "ARM",
                             "size": len(content),
                             "sha256": hashlib.sha256(content).hexdigest(),
                             "needed": needed, "soname": expected,
                             "interpreter": "/lib/ld-linux-armhf.so.3" if name.startswith("bin/")
                             else None, "e_flags": 0}
        if wrong_digest:
            objects["bin/coreelec-ng/moonlight"]["sha256"] = "f" * 64
        if not no_manifest:
            manifest = {
                "schema": package_ng.SCHEMA,
                "source_git_sha": source_sha,
                "capabilities": [package_ng.FIRST_VIDEO_CAPABILITY],
                "target": "Amlogic-ce/Amlogic-ng/arm",
                "objects": objects,
                "assets": {
                    "bin/coreelec-ng/gamecontrollerdb.txt": {
                        "size": len(("# SDL mappings\n" + "03000000000000000000000000000000,Test Controller,a:b0\n"*5).encode()),
                        "sha256": hashlib.sha256(("# SDL mappings\n" + "03000000000000000000000000000000,Test Controller,a:b0\n"*5).encode()).hexdigest(),
                    }
                },
                "external_needed": ["libamcodec.so", "libc.so.6"],
                "external_library_check": "not verified on target device",
            }
            content = json.dumps(manifest, sort_keys=True).encode("utf-8")
            item = tarfile.TarInfo("./runtime-manifest.json")
            item.size = len(content)
            tar.addfile(item, io.BytesIO(content))
        if not no_manifest:
            map_name = "bin/coreelec-ng/gamecontrollerdb.txt"
            data = ("# SDL mappings\n" + "03000000000000000000000000000000,Test Controller,a:b0\n"*5).encode()
            item = tarfile.TarInfo("./" + map_name)
            item.size = len(data)
            tar.addfile(item, io.BytesIO(data))
        if bad_entry:
            item = tarfile.TarInfo(bad_entry)
            item.size = 2
            tar.addfile(item, io.BytesIO(b"ok"))


class KodiPackageTests(unittest.TestCase):
    @staticmethod
    def _write_fake_source_lock(source, revision):
        # The real Moonlight assembler separately pins the manifest blob.
        # These fixtures simulate an already-verified allowlist.
        blob = (source / 'addon.xml').read_bytes()
        (source.parent / 'source-lock.json').write_text(json.dumps({
            'schema': 'luna-public-source-snapshot-v1',
            'sources': {'luna': {
                'repository': 'Roboatlas21/Luna',
                'revision': revision,
                'files': {'addon.xml': {
                    'blob_sha': hashlib.sha1(
                        b'blob ' + str(len(blob)).encode('ascii') + b'\0' + blob
                    ).hexdigest(),
                    'mode': '100644',
                }},
            }},
        }))

    def test_package_preserves_layout_and_executable_bit(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            source = base / "luna"
            source.mkdir()
            (source / "packaging").mkdir()
            (source / package_ng.SOURCE_PIN).write_text(
                (SCRIPT.parents[1] / package_ng.SOURCE_PIN).read_text())
            (source / "addon.xml").write_text(
                '<addon id="script.luna.ng" name="Luna" version="2.7.1.309" '
                'provider-name="Vortex"><requires /></addon>')
            (source / "addon.py").write_text("print('hello')\n")
            (source / "resources").mkdir()
            (source / "resources" / "test.txt").write_text("test")
            # A nested 'lib' is a Kodi Python module directory, NOT the
            # top-level native lib directory excluded from the source walk.
            internal = source / "resources" / "lib" / "util"
            internal.mkdir(parents=True)
            (internal / "helper.py").write_text("value = 42\n")
            safe = source / "resources" / "launchscripts" / "coreelec"
            safe.mkdir(parents=True)
            (safe / "launch.sh").write_text("#!/bin/sh\nexit 0\n")
            (safe / "kodi-watchdog.sh").write_text("#!/bin/sh\nexit 0\n")
            # The real launcher sources this helper; the synthetic source
            # must contain it too or the ZIP assertion is guaranteed to fail.
            (safe / "clock.sh").write_text("#!/bin/sh\nluna_monotonic_seconds() { :; }\n")
            unsafe = source / "resources" / "launchscripts" / "coreelec_usb_new"
            unsafe.mkdir(parents=True)
            (unsafe / "launch.sh").write_text(
                "#!/bin/sh\necho 0 > /sys/bus/usb/devices/1-1/authorized\n")
            (source / ".github").mkdir()
            (source / ".github" / "ignored.yml").write_text("secret")
            bundle = base / "native.tar.gz"
            output = base / "luna-ng.zip"
            write_bundle(bundle)
            version = package_ng.package(source, bundle, output)
            self.assertEqual(version, "2.7.1.309")

            with zipfile.ZipFile(output) as package:
                names = set(package.namelist())
                self.assertIn("script.luna.ng/addon.py", names)
                self.assertIn("script.luna.ng/bin/coreelec-ng/gamecontrollerdb.txt", names)
                self.assertEqual(
                    package.read("script.luna.ng/bin/coreelec-ng/moonlight.conf"),
                    b"# Generated by Luna from Kodi settings on launch.\n[Moonlight]\n")
                manifest_name = "script.luna.ng/runtime-manifest.json"
                self.assertIn(manifest_name, names)
                self.assertEqual(
                    json.loads(package.read(manifest_name))["schema"],
                    package_ng.SCHEMA)
                self.assertIn("script.luna.ng/resources/test.txt", names)
                self.assertIn("script.luna.ng/resources/lib/util/helper.py", names)
                self.assertNotIn("script.luna.ng/.github/ignored.yml", names)
                safe_launcher = "script.luna.ng/resources/launchscripts/coreelec/launch.sh"
                self.assertIn(safe_launcher, names)
                self.assertIn(
                    "script.luna.ng/resources/launchscripts/coreelec/kodi-watchdog.sh",
                    names)
                clock = "script.luna.ng/resources/launchscripts/coreelec/clock.sh"
                self.assertIn(clock, names)
                self.assertEqual((package.getinfo(clock).external_attr >> 16) & 0o777, 0o755)
                self.assertNotIn(
                    "script.luna.ng/resources/launchscripts/coreelec_usb_new/launch.sh",
                    names)
                self.assertEqual(
                    (package.getinfo(safe_launcher).external_attr >> 16) & 0o777,
                    0o755)
                self.assertTrue(package.read(safe_launcher).startswith(b"#!/bin/sh"))
                binary = "script.luna.ng/bin/coreelec-ng/moonlight"
                self.assertIn(binary, names)
                self.assertEqual((package.getinfo(binary).external_attr >> 16) & 0o777, 0o755)
                addon = ElementTree.fromstring(package.read("script.luna.ng/addon.xml"))
                self.assertEqual(addon.get("version"), "2.7.1.309")
                self.assertEqual(addon.get("id"), "script.luna.ng")
                self.assertEqual(package_ng.ADDON_ID, 'script.luna.ng')
                self.assertFalse(any(x.startswith('script.luna/') for x in names))

    def test_real_luna_checkout_package_handoff(self):
        """Assemble the actual repository layout using synthetic ARM32 objects."""
        with tempfile.TemporaryDirectory() as tmp:
            root = SCRIPT.parents[1]
            bundle = Path(tmp) / "native.tar.gz"
            output = Path(tmp) / "luna-ng-installable.zip"
            write_bundle(bundle)
            package_ng.package(root, bundle, output)
            with zipfile.ZipFile(output) as archive:
                names = set(archive.namelist())
                required = {
                    "script.luna.ng/addon.xml",
                    "script.luna.ng/addon.py",
                    "script.luna.ng/resources/launchscripts/coreelec/tsync.sh",
                    "script.luna.ng/resources/settings.xml",
                    "script.luna.ng/resources/lib/core/logger.py",
                    "script.luna.ng/resources/lib/util/audiodevices.py",
                    "script.luna.ng/resources/lib/util/confighelper.py",
                    "script.luna.ng/resources/lib/util/moonlighthelper.py",
                    "script.luna.ng/resources/lib/util/runtimecheck.py",
                    "script.luna.ng/resources/launchscripts/coreelec/launch.sh",
                    "script.luna.ng/resources/launchscripts/coreelec/kodi-watchdog.sh",
                    "script.luna.ng/resources/launchscripts/coreelec/clock.sh",
                    "script.luna.ng/resources/launchscripts/coreelec/prescript.sh",
                    "script.luna.ng/resources/launchscripts/coreelec/postscript.sh",
                    "script.luna.ng/resources/statics/loading.mp4",
                    "script.luna.ng/bin/coreelec-ng/moonlight",
                    "script.luna.ng/bin/coreelec-ng/moonlight.conf",
                    "script.luna.ng/bin/coreelec-ng/gamecontrollerdb.txt",
                    "script.luna.ng/lib/coreelec-ng/libmoonlight-aml.so",
                    "script.luna.ng/lib/coreelec-ng/libgamestream.so.4",
                    "script.luna.ng/lib/coreelec-ng/libmoonlight-common.so.4",
                    "script.luna.ng/lib/coreelec-ng/libcec.so.6",
                    "script.luna.ng/runtime-manifest.json",
                }
                self.assertTrue(required <= names, sorted(required - names))
                for name in required:
                    if name.endswith(".sh"):
                        self.assertTrue(archive.read(name).startswith(b"#!/bin/sh"))
                        self.assertEqual(
                            (archive.getinfo(name).external_attr >> 16) & 0o777, 0o755)
                self.assertNotIn(
                    "script.luna.ng/resources/launchscripts/coreelec_usb_new/prescript.sh",
                    names)
                self.assertNotIn(
                    "script.luna.ng/resources/launchscripts/coreelec_praxis/launch.sh",
                    names)
                for unused in ('cog.png', 'update.png', 'zerotier.png'):
                    self.assertNotIn('script.luna.ng/resources/icons/' + unused, names)
                self.assertNotIn('script.luna.ng/icon.png', names)
                self.assertNotIn('script.luna.ng/fanart.jpg', names)
                self.assertIsNone(archive.testzip())

    def test_git_tracked_checkout_excludes_ignored_local_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            root = base / 'luna'
            root.mkdir()
            (root / 'addon.xml').write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            (root / 'addon.py').write_text('print("committed")\n')
            (root / '.gitignore').write_text('.idea/\n.vscode/\n*.private\n')
            subprocess.run(['git', 'init', '-q', str(root)], check=True)
            subprocess.run(['git', '-C', str(root), 'add', '.'], check=True)
            subprocess.run(['git', '-C', str(root),
                            '-c', 'user.name=Luna Tests',
                            '-c', 'user.email=luna-tests@example.invalid',
                            'commit', '-q', '-m', 'Test packaging'], check=True)
            rev = subprocess.check_output(
                ['git', '-C', str(root), 'rev-parse', 'HEAD'],
                text=True).strip()
            (root / '.idea').mkdir()
            (root / '.idea' / 'workspace.xml').write_text('local IDE config')
            (root / 'session.private').write_text('local build note')
            # Git deliberately suppresses these tracked edits in porcelain
            # status; packaging must use immutable HEAD objects instead.
            subprocess.run(['git', '-C', str(root), 'update-index',
                            '--skip-worktree', 'addon.xml', 'addon.py'],
                           check=True)
            (root / 'addon.xml').write_text(
                '<addon id="script.luna.ng" version="9.9.9" />')
            (root / 'addon.py').write_text('print("hidden local edit")\n')
            self.assertEqual(subprocess.check_output(
                ['git', '-C', str(root), 'status', '--porcelain'],
                text=True).strip(), '')
            native = base / 'native.tar.gz'
            write_bundle(native, source_sha='c' * 40)
            release = base / 'release-lock.json'
            release.write_text(json.dumps({
                'schema': package_ng.RELEASE_LOCK_SCHEMA,
                'luna_revision': rev, 'moonlight_revision': 'c' * 40,
            }))
            output = base / 'release.zip'
            package_ng.package(root, native, output, release_lock=release)
            with zipfile.ZipFile(output) as archive:
                names = archive.namelist()
                self.assertIn('script.luna.ng/addon.py', names)
                self.assertEqual(archive.read('script.luna.ng/addon.py'),
                                 b'print("committed")\n')
                addon = ElementTree.fromstring(archive.read('script.luna.ng/addon.xml'))
                self.assertEqual(addon.get('version'), '1.0.0')
                self.assertNotIn('script.luna.ng/.idea/workspace.xml', names)
                self.assertNotIn('script.luna.ng/session.private', names)

    def test_locked_package_is_immutable_when_worktree_changes_midwrite(self):
        from unittest import mock
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            root = base / 'luna'
            root.mkdir()
            (root / 'addon.xml').write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            (root / 'addon.py').write_text('print("committed")\n')
            subprocess.run(['git', 'init', '-q', str(root)], check=True)
            subprocess.run(['git', '-C', str(root), 'add', '.'], check=True)
            subprocess.run(['git', '-C', str(root),
                            '-c', 'user.name=Luna Tests',
                            '-c', 'user.email=luna-tests@example.invalid',
                            'commit', '-q', '-m', 'Test packaging'], check=True)
            sha = subprocess.check_output(
                ['git', '-C', str(root), 'rev-parse', 'HEAD'],
                text=True).strip()
            native = base / 'native.tar.gz'
            write_bundle(native, source_sha='c' * 40)
            release = base / 'release-lock.json'
            release.write_text(json.dumps({
                'schema': package_ng.RELEASE_LOCK_SCHEMA,
                'luna_revision': sha, 'moonlight_revision': 'c' * 40,
            }))
            output = base / 'release.zip'
            original_zip_entry = package_ng.zip_entry

            def change_after_snapshot(archive, name, data, executable=False):
                if name == 'addon.xml':
                    # Simulate a local editor changing a tracked file while
                    # the ZIP is being written; the package must not see it.
                    (root / 'addon.py').write_text('print("raced")\n')
                original_zip_entry(archive, name, data, executable)

            with mock.patch.object(package_ng, 'zip_entry',
                                   side_effect=change_after_snapshot):
                package_ng.package(root, native, output, release_lock=release)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(archive.read('script.luna.ng/addon.py'),
                                 b'print("committed")\n')
                self.assertIsNone(archive.testzip())

    def test_verified_export_rechecks_source_file_digests(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            source = base / 'luna'
            source.mkdir()
            (source / 'addon.xml').write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            self._write_fake_source_lock(source, 'b' * 40)
            (source / 'addon.xml').write_text(
                '<addon id="script.luna.ng" version="9.9.9" />')
            bundle = base / 'native.tar.gz'
            write_bundle(bundle, source_sha='c' * 40)
            lock = base / 'release-lock.json'
            lock.write_text(json.dumps({
                'schema': package_ng.RELEASE_LOCK_SCHEMA,
                'luna_revision': 'b' * 40,
                'moonlight_revision': 'c' * 40,
            }))
            output = base / 'should-not-exist.zip'
            with self.assertRaisesRegex(ValueError, 'Changed authenticated'):
                package_ng.package(source, bundle, output, release_lock=lock,
                                   verified_snapshot_revision='b' * 40)
            self.assertFalse(output.exists())

    def test_release_lock_accepts_a_newer_explicit_native_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "luna"
            root.mkdir()
            (root / "addon.xml").write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            bundle = Path(tmp) / "native.tar.gz"
            output = Path(tmp) / "complete.zip"
            write_bundle(bundle, source_sha="c" * 40)
            lock = Path(tmp) / "release-lock.json"
            revisions = {"schema": package_ng.RELEASE_LOCK_SCHEMA,
                         "luna_revision": "b" * 40,
                         "moonlight_revision": "c" * 40}
            lock.write_text(json.dumps(revisions))
            self._write_fake_source_lock(root, "b" * 40)
            (root / "locally-ignored.txt").write_text("private build note")
            package_ng.package(root, bundle, output, release_lock=lock,
                               verified_snapshot_revision="b" * 40)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(json.loads(archive.read(
                    "script.luna.ng/release-lock.json")), revisions)
                self.assertNotIn("script.luna.ng/locally-ignored.txt",
                                 archive.namelist())

    def test_release_lock_rejects_unverified_gitless_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "luna"
            root.mkdir()
            (root / "addon.xml").write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, source_sha="c" * 40)
            lock = Path(tmp) / "release-lock.json"
            lock.write_text(json.dumps({
                "schema": package_ng.RELEASE_LOCK_SCHEMA,
                "luna_revision": "b" * 40,
                "moonlight_revision": "c" * 40}))
            with self.assertRaisesRegex(ValueError, "separately verified"):
                package_ng.package(root, bundle, Path(tmp) / "bad.zip",
                                   release_lock=lock)
            with self.assertRaisesRegex(ValueError, "separately verified"):
                package_ng.package(root, bundle, Path(tmp) / "bad2.zip",
                                   release_lock=lock,
                                   verified_snapshot_revision="a" * 40)

    def test_release_lock_rejects_wrong_native_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "luna"
            root.mkdir()
            (root / "addon.xml").write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, source_sha="c" * 40)
            lock = Path(tmp) / "release-lock.json"
            lock.write_text(json.dumps({
                "schema": package_ng.RELEASE_LOCK_SCHEMA,
                "luna_revision": "b" * 40,
                "moonlight_revision": "d" * 40}))
            output = Path(tmp) / "mismatch.zip"
            with self.assertRaisesRegex(ValueError, "does not match"):
                package_ng.package(root, bundle, output, release_lock=lock,
                                   verified_snapshot_revision="b" * 40)
            self.assertFalse(output.exists())

    def test_release_lock_rejects_malformed_or_symlinked_documents(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "release-lock.json"
            for value in ("{}", '{"schema":"invalid"}', "{"):
                path.write_text(value)
                with self.assertRaises(ValueError):
                    package_ng.read_release_lock(path)
            path.unlink()
            path.symlink_to("other")
            with self.assertRaises(ValueError):
                package_ng.read_release_lock(path)

    def test_atomic_publish_keeps_existing_zip_after_midwrite_failure(self):
        from unittest import mock
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            source = base / "luna"
            source.mkdir()
            (source / "addon.xml").write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            bundle = base / "native.tar.gz"
            write_bundle(bundle)
            output = base / "working.zip"
            original = b"last-known-good-addon"
            output.write_bytes(original)
            # Source provenance is checked before writing any ZIP members.
            # Supply the authenticated fixture so this test actually
            # reaches the injected midwrite failure.
            self._write_fake_source_lock(source, "a" * 40)
            with mock.patch.object(package_ng, "zip_entry",
                                   side_effect=OSError("injected ZIP writer failure")):
                with self.assertRaisesRegex(OSError, "injected"):
                    package_ng.package(source, bundle, output,
                        release_lock=self._atomic_release_lock(base),
                        verified_snapshot_revision="a" * 40)
            self.assertEqual(output.read_bytes(), original)
            self.assertFalse(list(base.glob(".luna-package-*.zip")))

    @staticmethod
    def _atomic_release_lock(base):
        path = base / "lock.json"
        path.write_text(json.dumps({
            "schema": package_ng.RELEASE_LOCK_SCHEMA,
            "luna_revision": "a" * 40,
            "moonlight_revision": package_ng.read_pinned_source_revision(SCRIPT.parents[1])}))
        return path

    def test_atomic_publish_keeps_existing_zip_after_verification_failure(self):
        from unittest import mock
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            source = base / "luna"
            source.mkdir()
            (source / "addon.xml").write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            bundle = base / "native.tar.gz"
            write_bundle(bundle)
            output = base / "working.zip"
            output.write_bytes(b"unchanged")
            # testzip runs only after all archive entries have been written.
            self._write_fake_source_lock(source, "a" * 40)
            with mock.patch.object(package_ng.zipfile.ZipFile, "testzip",
                                   return_value="simulated-corruption"):
                with self.assertRaisesRegex(ValueError, "ZIP corruption"):
                    package_ng.package(source, bundle, output,
                                       release_lock=self._atomic_release_lock(base),
                        verified_snapshot_revision="a" * 40)
            self.assertEqual(output.read_bytes(), b"unchanged")
            self.assertFalse(list(base.glob(".luna-package-*.zip")))

    def test_package_rejects_stale_but_well_formed_native_revision(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = SCRIPT.parents[1]
            bundle = Path(tmp) / "native.tar.gz"
            output = Path(tmp) / "stale.zip"
            write_bundle(bundle, source_sha="b" * 40)
            with self.assertRaisesRegex(ValueError, "does not match"):
                package_ng.package(root, bundle, output)
            self.assertFalse(output.exists())

    def test_package_rejects_missing_explicit_source_pin(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "addon.xml").write_text(
                '<addon id="script.luna.ng" version="1.0.0" />')
            bundle = root / "native.tar.gz"
            write_bundle(bundle)
            with self.assertRaisesRegex(ValueError, "pinned Moonlight source"):
                package_ng.package(root, bundle, root.parent / "unissued.zip")

    def test_rejects_aarch64_no_executable(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, elf_class=2)
            with self.assertRaisesRegex(ValueError, "ARM ELF"):
                package_ng.native_members(bundle)

    def test_rejects_incomplete_bundle(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, omit="lib/coreelec-ng/libmoonlight-aml.so")
            with self.assertRaisesRegex(ValueError, "Missing native"):
                package_ng.native_members(bundle)

    def test_rejects_bundle_without_libcec_runtime(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, omit="lib/coreelec-ng/libcec.so.6")
            with self.assertRaisesRegex(ValueError, "Missing native"):
                package_ng.native_members(bundle)

    def test_missing_first_video_capability_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "native.tar.gz"
            write_bundle(path)
            with tarfile.open(path, "r:gz") as archive:
                members = [(item.name, archive.extractfile(item).read())
                           for item in archive.getmembers() if item.isfile()]
            with tarfile.open(path, "w:gz") as archive:
                for name, data in members:
                    if name.endswith("runtime-manifest.json"):
                        manifest = json.loads(data)
                        manifest.pop("capabilities")
                        data = json.dumps(manifest).encode()
                    entry = tarfile.TarInfo(name)
                    entry.size = len(data)
                    archive.addfile(entry, io.BytesIO(data))
            with self.assertRaisesRegex(ValueError, "first-video"):
                package_ng.native_members(path)

    def test_unknown_source_commit_cannot_be_packaged(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, source_sha="unknown")
            with self.assertRaisesRegex(ValueError, "source revision"):
                package_ng.native_members(bundle)

    def test_manifest_returns_validated_document(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle)
            result = package_ng.native_members(bundle)
            manifest = package_ng.verify_runtime_manifest(result)
            self.assertEqual(manifest["source_git_sha"],
                             package_ng.read_pinned_source_revision(SCRIPT.parents[1]))

    def test_rejects_mismatched_native_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, wrong_digest=True)
            with self.assertRaisesRegex(ValueError, "digest mismatch"):
                package_ng.native_members(bundle)

    def test_manifest_free_legacy_bundle_cannot_be_installed(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            output = Path(tmp) / "must-not-exist.zip"
            write_bundle(bundle, no_manifest=True)
            with self.assertRaisesRegex(ValueError, "Missing native runtime manifest"):
                package_ng.native_members(bundle)
            with self.assertRaisesRegex(ValueError, "Missing native runtime manifest"):
                package_ng.package(SCRIPT.parents[1], bundle, output)
            self.assertFalse(output.exists())

    def test_rejects_unexpected_archive_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "native.tar.gz"
            write_bundle(bundle, bad_entry="../escape")
            with self.assertRaisesRegex(ValueError, "unsafe"):
                package_ng.native_members(bundle)


if __name__ == "__main__":
    unittest.main()
