"""A legacy INI must show actionable recovery instead of breaking Kodi startup."""
import ast
from pathlib import Path
import sys
import types
import unittest
from unittest import mock

sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))

ROOT = Path(__file__).resolve().parents[1]


class MoonlightConfigRecoveryTests(unittest.TestCase):
    def test_dialog_is_clear_and_does_not_log_config_values(self):
        module = ast.parse((ROOT / 'addon.py').read_text(encoding='utf-8'))
        fn = [n for n in module.body if isinstance(n, ast.FunctionDef)
              and n.name == 'showMoonlightConfigRecovery']
        self.assertEqual(len(fn), 1)
        scope = {}
        exec(compile(ast.Module(body=fn, type_ignores=[]), 'addon.py', 'exec'),
             scope)
        logger = mock.Mock()
        dialog = mock.Mock()
        scope['logger'] = logger
        scope['xbmcgui'] = types.SimpleNamespace(Dialog=lambda: dialog)
        from resources.lib.util.confighelper import MoonlightConfigFormatError
        problem = MoonlightConfigFormatError(
            '/storage/.kodi/addons/script.luna.ng/bin/coreelec-ng/moonlight.conf',
            'missing [Moonlight] section / sectionless format')
        scope['showMoonlightConfigRecovery'](problem)
        dialog.ok.assert_called_once()
        self.assertEqual(dialog.ok.call_args.args[0],
                         'Moonlight configuration needs repair')
        message = dialog.ok.call_args.args[1]
        self.assertIn('moonlight.conf.backup', message)
        self.assertIn('[Moonlight]', message)
        self.assertIn('file has NOT been changed', message)
        self.assertIn('reopen Luna', message)
        self.assertIn('script.luna.ng', message)
        self.assertNotIn('secret-value', logger.error.call_args.args[0])

    def test_import_error_is_handled_before_plugin_actions(self):
        source = (ROOT / 'addon.py').read_text(encoding='utf-8')
        self.assertIn('config_helper.config_error is not None', source)
        self.assertIn("not in ('diagnostics', 'restore_seek', 'settings')", source)
        self.assertIn('except MoonlightConfigFormatError as error:', source)
        self.assertLess(source.index('config_helper.config_error is not None'),
                        source.index("if 'action' in args:"))
        self.assertGreater(source.index('config_helper.config_error is not None'),
                           source.index('cleanup_expired_seek()'))
        self.assertGreater(source.index('config_helper.config_error is not None'),
                           source.index('restore_saved_streamsilence(addon)'))
        self.assertLess(source.index('config_helper.config_error is not None'),
                        source.index('config_helper.binary_path is None'))

    def test_parser_never_recovers_sectionless_addresses(self):
        source = (ROOT / 'resources/lib/util/confighelper.py').read_text(
            encoding='utf-8')
        self.assertNotIn('def _address_from_conf', source)
        self.assertNotIn("sectioned = any(", source)
        self.assertIn('parsed.read_file(io.StringIO(rendered))', source)
        self.assertIn('config = self._read_sectioned_conf()', source)
        self.assertIn('existing = self._read_sectioned_conf()', source)
        self.assertIn('ConfigParser(strict=True, interpolation=None)', source)


if __name__ == '__main__':
    unittest.main()
