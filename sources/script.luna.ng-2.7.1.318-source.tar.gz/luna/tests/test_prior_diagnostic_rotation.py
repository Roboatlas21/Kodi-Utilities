"""Exercise the exact launcher diagnostic rotation without running Kodi or systemd."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / 'resources/launchscripts/coreelec/launch.sh'


class PriorDiagnosticRotationTests(unittest.TestCase):
    def test_short_intervening_session_does_not_relabel_older_rolling_logs(self):
        source = LAUNCHER.read_text()
        start = source.index('if [ -f "$LOG" ]; then mv -f "$LOG" "$LOG.old"')
        stop = source.index('luna_launch_mark launcher-preparation', start)
        rotation = source[start:stop + len('luna_launch_mark launcher-preparation')]
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'logfile').write_text('First session\n')
            (root / 'native-diagnostics.rolling.0').write_text('first sample\n')
            def rotate(session):
                command = (
                    'LOG="$1"; session="$2"; '
                    'luna_write_receipt() { printf "%s\\n" "$2" > "$1"; }; '
                    'luna_launch_mark() { :; };\n' + rotation)
                subprocess.run(['sh', '-c', command, 'sh',
                                str(root / 'logfile'), session], check=True)
            rotate('.luna-session.aaaaaaaa')  # First -> second
            self.assertEqual((root / 'native-diagnostics.prior.0').read_text(),
                             'first sample\n')
            (root / 'logfile').write_text('Short second session\n')
            rotate('.luna-session.bbbbbbbb')  # Second -> third; no rolling
            self.assertFalse((root / 'native-diagnostics.prior.0').exists())
            self.assertEqual(
                (root / 'native-diagnostics.prior.session').read_text(),
                '.luna-session.aaaaaaaa\n')
            self.assertEqual((root / 'native-diagnostics.session').read_text(),
                             '.luna-session.bbbbbbbb\n')
            self.assertEqual((root / 'logfile.old').read_text(),
                             'Short second session\n')


if __name__ == '__main__':
    unittest.main()
