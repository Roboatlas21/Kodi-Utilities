"""Exercise the real grouped Luna validator's per-check timeout reporting."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = ROOT / 'packaging/validate_private.sh'


class ValidationTimeoutTests(unittest.TestCase):
    def test_stalled_check_fails_and_subsequent_check_is_recorded(self):
        script = VALIDATOR.read_text(encoding='utf-8')
        begin = script.index('run_checked() {')
        end = script.index('\ncase "$group" in', begin)
        function = script[begin:end]
        with tempfile.TemporaryDirectory() as folder:
            harness = (
                'set -uo pipefail\n'
                'group=luna-python\n'
                'log_dir="$TEST_VALIDATION_DIR"\n'
                'check_timeout=1\n'
                'checks=0\n'
                'failures=0\n'
                'printf "check\\tresult\\texit_code\\tlog\\n" > "$log_dir/results.tsv"\n'
                + function + '\n'
                + "run_checked stalled bash -c 'sleep 5'\n"
                + 'run_checked later true\n'
                + '(( checks == 2 && failures == 1 ))\n'
            )
            result = subprocess.run(
                ['bash', '-c', harness], text=True, capture_output=True,
                timeout=8, env={**os.environ, 'TEST_VALIDATION_DIR': folder})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('SOURCE_CHECK_TIMEOUT group=luna-python check=stalled',
                          result.stderr)
            self.assertIn('SOURCE_CHECK_PASS group=luna-python check=later',
                          result.stdout)
            table = (Path(folder) / 'results.tsv').read_text()
            self.assertIn('stalled\tFAIL\t124', table)
            self.assertIn('later\tPASS\t0', table)


if __name__ == '__main__':
    unittest.main()
