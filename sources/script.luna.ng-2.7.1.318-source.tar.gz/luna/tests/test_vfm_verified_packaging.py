"""The VFM release packager must use only immutable, source-locked bytes."""
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import zipfile

from resources.lib.util import vfmruntime, safefile, safejson
from test_vfm_runtime import fixture
from test_package_ng import package_ng, write_bundle


class VerifiedVfmPackagingTests(unittest.TestCase):
    def test_verifier_returns_bytes_before_a_path_can_change(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            fixture(root)
            manifest, contents = vfmruntime.verify_bundle(root, collect_bytes=True)
            target = root / "lib/libavcodec.so.62"
            verified = contents["lib/libavcodec.so.62"]
            self.assertEqual(verified, target.read_bytes())
            self.assertEqual(contents["manifest.json"], (root / "manifest.json").read_bytes())
            target.write_bytes(b"replaced after validation")
            self.assertEqual(contents["lib/libavcodec.so.62"], verified)
            self.assertIn("lib/libavcodec.so.62", manifest["objects"])

    def test_packager_does_not_import_mutable_readers_or_reopen_vfm_files(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            vfm = base / "vfm"
            fixture(vfm)
            native = base / "standard.tar.gz"
            write_bundle(native)
            output = base / "output.zip"
            original_read = Path.read_bytes

            def refuse_vfm_reopen(path):
                if str(path).startswith(str(vfm) + "/"):
                    raise AssertionError("Packager reopened VFM file after verification")
                return original_read(path)

            with mock.patch.object(safefile, "read_regular_bytes",
                                   side_effect=AssertionError("mutable reader used")), \
                 mock.patch.object(safejson, "read_bounded_json",
                                   side_effect=AssertionError("mutable JSON reader used")), \
                 mock.patch.object(Path, "read_bytes", refuse_vfm_reopen):
                package_ng.package(Path(__file__).resolve().parents[1], native,
                                   output, vfm_directory=vfm)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(archive.read("script.luna.ng/vfm/manifest.json"),
                                 original_read(vfm / "manifest.json"))


if __name__ == "__main__":
    unittest.main()
