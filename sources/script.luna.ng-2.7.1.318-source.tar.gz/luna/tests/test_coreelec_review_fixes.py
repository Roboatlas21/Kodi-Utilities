"""Failure-oriented coverage for the CoreELEC review changes."""
import json
import os
import socket
import struct
import subprocess
import tempfile
import unittest
import zlib
from pathlib import Path
from unittest.mock import patch
from test_ng_runtimecheck import make_package
import test_host_cache as cache_fixture
from resources.lib.util.runtimecheck import check_ng_runtime, NativeRuntimeError
from resources.lib.util.artwork import valid_artwork
from resources.lib.util import hostresolve, audiodevices


class RuntimeAndImageTests(unittest.TestCase):
    def test_fifo_manifest_is_rejected_without_blocking(self):
        with tempfile.TemporaryDirectory() as root:
            executable = make_package(root)
            path = Path(root, 'runtime-manifest.json')
            path.unlink()
            os.mkfifo(path)
            with self.assertRaises(NativeRuntimeError):
                check_ng_runtime(root, executable, check_loader=False)

    def test_vfm_preflight_does_not_load_aml_vendor_dependencies(self):
        with tempfile.TemporaryDirectory() as root:
            executable = make_package(root)
            reply = subprocess.CompletedProcess([], 0,
                'Moonlight Embedded\nLUNA_NATIVE_FIRST_VIDEO_READY_V1\n')
            with patch('resources.lib.util.runtimecheck.subprocess.run', return_value=reply) as run:
                self.assertTrue(check_ng_runtime(root, executable,
                    {'MOONLIGHT_VIDEO_PIPELINE': 'aml-vfm'}, check_loader=False))
                self.assertEqual(run.call_count, 1)
                self.assertEqual(run.call_args.args[0][-1], 'help')

    def test_indexed_png_requires_palette_before_image_data(self):
        def chunk(kind, data):
            return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
        prefix = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 3, 0, 0, 0))
        image = chunk(b'IDAT', zlib.compress(b'\x00\x00'))
        palette = chunk(b'PLTE', b'\x00\x00\x00')
        end = chunk(b'IEND', b'')
        self.assertFalse(valid_artwork(prefix + image + end))
        self.assertFalse(valid_artwork(prefix + image + palette + end))
        self.assertTrue(valid_artwork(prefix + palette + image + end))

    def test_resolver_timeout_never_opens_a_socket(self):
        hostresolve._cache.clear()
        with patch.object(hostresolve.subprocess, 'run', side_effect=subprocess.TimeoutExpired('resolve', 4)), patch.object(hostresolve.socket, 'socket') as opened:
            with self.assertRaises(socket.timeout):
                hostresolve.connect(('unavailable-host', 47984))
            opened.assert_not_called()

    def test_busy_probes_share_one_budget_and_deduplicate(self):
        audiodevices._probe_context.current = (3, {})
        try:
            with patch.object(audiodevices.time, 'monotonic', side_effect=[0, 4]), patch.object(audiodevices.os.path, 'exists', return_value=True), patch.object(audiodevices.subprocess, 'check_output', return_value='123') as probe:
                self.assertTrue(audiodevices._busy(1, 0))
                self.assertTrue(audiodevices._busy(1, 0))
                self.assertFalse(audiodevices._busy(2, 0))
                self.assertEqual(probe.call_count, 1)
        finally:
            audiodevices._probe_context.current = None

    def test_unknown_channels_are_not_claimed_as_surround(self):
        with patch.object(audiodevices, 'endpoint_node', return_value=None):
            self.assertIsNone(audiodevices.multichannel('hw:unknown,0'))
        self.assertFalse(audiodevices.multichannel('iec958:CARD=AML'))
        self.assertTrue(audiodevices.multichannel('surround51:CARD=USB'))


class ArtworkWorkerTests(unittest.TestCase):
    setUp = cache_fixture.HostCacheTests.setUp

    def test_listing_queues_artwork_without_downloads(self):
        with patch('resources.lib.util.hostapi.Host') as host:
            host.return_value.applist.return_value = [('7', 'Game')]
            self.assertEqual(self.helper.list_games_detailed(), [('7', 'Game', None)])
            host.return_value.boxart.assert_not_called()
            jobs = list((self.root / 'artwork-jobs').glob('*.json'))
            self.assertEqual(json.loads(jobs[0].read_text())['ids'], ['7'])

    def test_refresh_replaces_valid_art_and_preserves_it_on_failure(self):
        sample = cache_fixture.sample_png
        with patch('resources.lib.util.hostapi.Host') as host:
            host.return_value.boxart.return_value = sample('first')
            path = self.helper.boxart_path('first-host', '7')
            host.return_value.boxart.return_value = sample('second')
            self.helper.boxart_path('first-host', '7', refresh=True)
            self.assertEqual(Path(path).read_bytes(), sample('second'))
            host.return_value.boxart.side_effect = OSError('offline')
            self.assertIsNone(self.helper.boxart_path('first-host', '7', refresh=True))
            self.assertEqual(Path(path).read_bytes(), sample('second'))

    def test_validated_image_skips_repeat_decode_but_not_modified_bytes(self):
        path = self.root / 'image.png'
        path.write_bytes(cache_fixture.sample_png('first'))
        from resources.lib.util import artwork
        with patch.object(artwork, 'valid_artwork', wraps=artwork.valid_artwork) as validate:
            self.assertTrue(self.helper._complete_artwork_file(path))
            self.assertTrue(self.helper._complete_artwork_file(path))
            self.assertEqual(validate.call_count, 1)
            path.write_bytes(b'corrupt')
            self.assertFalse(self.helper._complete_artwork_file(path))

class RecoveryGateTests(unittest.TestCase):
    def test_critical_recovery_defers_kodi_but_framebuffer_only_can_recover(self):
        root = Path(__file__).parents[1] / 'resources/launchscripts/coreelec'
        for filename, end in [('launch.sh', '  if [ "$kodi_handoff_attempted" -eq 1 ]; then'),
                              ('kodi-watchdog.sh', '  # Only disarm when Kodi is actually active')]:
            source = (root / filename).read_text()
            start = source.index('  display_critical=0')
            gate = source[start:source.index(end, start)]
            with tempfile.TemporaryDirectory() as directory:
                session = Path(directory) / 'session'
                for pending, mode_ok, expected in [('critical', 1, 1), ('unverified', 1, 1),
                                                  ('fb0', 1, 0), ('fb0_fb1', 1, 0), ('fb0', 0, 1)]:
                    Path(str(session) + '.display-pending').write_text(pending)
                    script = 'display_recovered=0; hdmi_mode_recovered=$1; session=$2; LOG=$3\n' + gate + '\nexit 0\n'
                    result = subprocess.run(['sh', '-c', script, 'review', str(mode_ok), str(session), str(session) + '.log'], capture_output=True)
                    self.assertEqual(result.returncode, expected, (filename, pending, result.stderr))
