# SPDX-License-Identifier: GPL-3.0-or-later
"""Luna frametime option is explicit, off by default, and OSD-dependent."""
from pathlib import Path
from xml.etree import ElementTree

ROOT=Path(__file__).resolve().parents[1]
root=ElementTree.parse(ROOT/"resources/settings.xml")
setting=root.find(".//setting[@id='frametime_graph']")
assert setting is not None
assert setting.findtext("default")=="false"
assert setting.find("dependencies/dependency") is not None
assert setting.find("dependencies/dependency").attrib.get("setting")=="osd"
code=(ROOT/"resources/lib/util/confighelper.py").read_text()
assert "self.plugin.getSetting('frametime_graph')" in code
assert "self.config['osd'] == 'true' and self.config['frametime_graph'] == 'true'" in code
assert "args += ['-frametime']" in code
strings=(ROOT/"resources/language/resource.language.en_gb/strings.po").read_text()
assert 'msgctxt "#30361"' in strings and 'msgctxt "#30362"' in strings
print("PASS: Luna optional frametime graph and decoder callback help text")
