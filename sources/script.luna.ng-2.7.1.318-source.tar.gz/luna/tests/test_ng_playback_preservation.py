"""Cancelling an NG launch must leave ongoing Kodi playback untouched."""
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

xbmc = sys.modules.setdefault('xbmc', types.ModuleType('xbmc'))
xbmcgui = sys.modules.setdefault('xbmcgui', types.ModuleType('xbmcgui'))
xbmcvfs = sys.modules.setdefault('xbmcvfs', types.ModuleType('xbmcvfs'))
xbmc.LOGERROR = 4
xbmc.LOGINFO = 1

from resources.lib.util.moonlighthelper import MoonlightHelper


class KodiPlaybackPreservationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.snapshot = Path(self.temporary.name) / 'session.conf'
        self.snapshot.write_text(
            '[Moonlight]\naddress = sunshine-a\n'
            'width = 1920\nheight = 1080\nfps = 60\n')
        self.helper = MoonlightHelper.__new__(MoonlightHelper)
        self.helper.config_helper = types.SimpleNamespace(
            binary_path='/addon/bin/coreelec-ng/',
            launchscripts_path='/addon/resources/launchscripts/coreelec/',
            addon_path='/addon/',
            config={'host_addr': 'sunshine-a', 'codec': 'h264'},
            configure=mock.Mock(),
            create_launch_snapshot=lambda: str(self.snapshot))
        # Profile tests exercise launch handoff, not the optional 10s intro.
        self.helper.plugin = types.SimpleNamespace(
            getSettingBool=lambda _name: False)
        self.helper.logger = mock.Mock()
        self.helper.restore_audio = mock.Mock()
        self.helper._stream_environment = mock.Mock(
            return_value={'MOONLIGHT_VIDEO_PIPELINE': 'aml'})
        self.helper._running_ng_app = mock.Mock(
            return_value=('99', None))
        self.helper._ng_conflict_choice = mock.Mock(return_value=0)
        self.helper._launch_coreelec_ng_service = mock.Mock(
            return_value=(False, 'synthetic failed launch'))
        self.player = mock.Mock()
        self.player.isPlaying.return_value = True
        self.dialog = mock.Mock()
        self.patches = [
            mock.patch('resources.lib.util.runtimecheck.check_ng_runtime'),
            mock.patch('resources.lib.util.moonlighthelper.moonlight_environment',
                       return_value={}),
            mock.patch.object(xbmc, 'Player', return_value=self.player,
                              create=True),
            mock.patch.object(xbmc, 'executebuiltin', create=True),
            mock.patch.object(xbmc, 'log', create=True),
            mock.patch.object(xbmcgui, 'Dialog', return_value=self.dialog,
                              create=True),
            mock.patch.object(xbmcvfs, 'translatePath',
                              return_value=str(self.temporary.name),
                              create=True),
        ]
        for patcher in self.patches:
            patcher.start()
            self.addCleanup(patcher.stop)

    def test_pre_submission_exception_restores_kodi_playback(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper._begin_local_stream_transition = mock.Mock(
            return_value=('movie.mkv', 120.0))
        self.helper._restore_kodi_playback = mock.Mock()
        self.helper._launch_coreelec_ng_service.side_effect = ValueError('pre-submit')
        self.helper.launch_game('Desktop', app_id='42')
        self.helper._restore_kodi_playback.assert_called_once_with(
            self.player, ('movie.mkv', 120.0))
        self.assertFalse(self.snapshot.exists())

    def test_post_submission_exception_preserves_native_snapshot(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper._begin_local_stream_transition = mock.Mock(
            return_value=('movie.mkv', 120.0))
        self.helper._restore_kodi_playback = mock.Mock()
        def failed_handoff(*_args):
            self.helper._systemd_submit_attempted = True
            raise RuntimeError('ack interrupted')
        self.helper._launch_coreelec_ng_service.side_effect = failed_handoff
        self.helper.launch_game('Desktop', app_id='42')
        self.helper._restore_kodi_playback.assert_not_called()
        self.assertTrue(self.snapshot.exists())
        self.assertIn('unconfirmed',
                      str(self.dialog.ok.call_args).lower())

    def test_intro_exception_restores_captured_playback(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper.plugin.getSettingBool = lambda name: name == 'show_intro'
        previous = ('movie.mkv', 123.0)
        self.helper._capture_kodi_playback = mock.Mock(return_value=previous)
        self.helper._restore_kodi_playback = mock.Mock()
        self.player.isPlaying.side_effect = [True, False]
        self.player.play.side_effect = RuntimeError('intro unavailable')
        self.helper.launch_game('Desktop', app_id='42')
        self.helper._restore_kodi_playback.assert_called_once_with(self.player, previous)
        self.helper._launch_coreelec_ng_service.assert_not_called()

    def test_quit_poll_allows_sunshine_to_finish_closing_without_kodi_handoff(self):
        self.helper._running_ng_app.side_effect = [
            ('99', None), ('99', None), ('0', None)]
        clock = [100.0]
        def monotonic():
            return clock[0]
        def sleep(seconds):
            clock[0] += seconds
        with mock.patch('resources.lib.util.moonlighthelper.time.monotonic',
                        side_effect=monotonic), mock.patch(
                            'resources.lib.util.moonlighthelper.time.sleep',
                            side_effect=sleep):
            ok, error = self.helper._wait_for_ng_app_stopped(
                '/addon/bin/', {'LUNA_STREAM_CONFIG': str(self.snapshot)}, '42')
        self.assertTrue(ok)
        self.assertIsNone(error)
        self.assertEqual(self.helper._running_ng_app.call_count, 3)
        self.assertLess(clock[0] - 100, 1)
        self.player.stop.assert_not_called()

    def test_quit_poll_is_bounded_and_does_not_commit_a_running_host(self):
        self.helper._running_ng_app.return_value = ('99', None)
        clock = [100.0]
        def monotonic():
            return clock[0]
        def sleep(seconds):
            clock[0] += seconds
        with mock.patch('resources.lib.util.moonlighthelper.time.monotonic',
                        side_effect=monotonic), mock.patch(
                            'resources.lib.util.moonlighthelper.time.sleep',
                            side_effect=sleep):
            ok, error = self.helper._wait_for_ng_app_stopped(
                '/addon/bin/', {}, '42', seconds=1.0)
        self.assertFalse(ok)
        self.assertIn('still reports', error)
        self.assertLessEqual(clock[0] - 100, 1.0)
        self.player.stop.assert_not_called()

    def test_app_status_failure_aborts_switch_immediately(self):
        self.helper._running_ng_app.return_value = (
            None, 'Sunshine identity changed')
        with mock.patch('resources.lib.util.moonlighthelper.time.sleep') as sleep:
            ok, error = self.helper._wait_for_ng_app_stopped(
                '/addon/bin/', {}, '42')
        self.assertFalse(ok)
        self.assertIn('identity changed', error)
        sleep.assert_not_called()

    def test_replacement_waits_for_idle_before_local_transition(self):
        self.helper._ng_conflict_choice.return_value = 2
        self.helper.quit_game = mock.Mock(return_value=True)
        self.helper._running_ng_app.side_effect = [
            ('99', None), ('99', None), ('0', None)]
        self.helper._begin_local_stream_transition = mock.Mock(return_value=None)
        with mock.patch('resources.lib.util.moonlighthelper.time.sleep'):
            self.helper.launch_game('Replacement', app_id='42')
        self.helper.quit_game.assert_called_once()
        self.assertEqual(self.helper._running_ng_app.call_count, 3)
        self.helper._begin_local_stream_transition.assert_called_once()
        self.helper._launch_coreelec_ng_service.assert_called_once()

    def test_invalid_replacement_profile_never_quits_running_app(self):
        self.helper._ng_conflict_choice.return_value = 2
        self.helper.quit_game = mock.Mock(return_value=True)
        with mock.patch('resources.lib.util.streamprofiles.StreamProfiles.get',
                        side_effect=ValueError('damaged profile')):
            self.helper.launch_game('Replacement', app_id='42')
        self.helper.quit_game.assert_not_called()
        self.player.stop.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_not_called()

    def test_cancelled_app_switch_does_not_stop_video_or_play_intro(self):
        self.helper.launch_game('Desktop', app_id='42')
        self.helper._ng_conflict_choice.assert_called_once_with('99', 'Desktop')
        self.player.stop.assert_not_called()
        self.player.play.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_not_called()
        xbmc.executebuiltin.assert_not_called()
        self.assertFalse(self.snapshot.exists())

    def test_unsupported_hdmi_mode_shows_error_without_stopping_kodi(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper._stream_environment.return_value = {
            'MOONLIGHT_VIDEO_PIPELINE': 'aml',
            'MOONLIGHT_MATCH_HDMI_MODE': '1'}
        with mock.patch('resources.lib.util.hdmimode.check',
                        side_effect=ValueError(
                            'The TV does not advertise an exact HDMI mode '
                            'for 3840x2160 at 60 Hz.')) as checker:
            self.helper.launch_game('Desktop', app_id='42')

        checker.assert_called_once_with(str(self.snapshot))
        self.dialog.ok.assert_called_once()
        heading, message = self.dialog.ok.call_args.args
        self.assertEqual(heading, 'HDMI output mode unavailable')
        self.assertIn('3840x2160 at 60 Hz', message)
        self.player.stop.assert_not_called()
        self.player.play.assert_not_called()
        # Remote app-status validation comes before the effective-profile
        # HDMI check. Both still precede any Kodi playback disruption.
        self.helper._running_ng_app.assert_called_once()
        self.helper._launch_coreelec_ng_service.assert_not_called()
        xbmc.executebuiltin.assert_not_called()
        self.assertFalse(self.snapshot.exists())

    def test_hdmi_preflight_off_does_not_access_display(self):
        self.helper._running_ng_app.return_value = ('0', None)
        with mock.patch('resources.lib.util.hdmimode.check') as checker:
            self.helper.launch_game('Desktop', app_id='42')
        checker.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_called_once()

    def test_saved_game_profile_is_used_for_hdmi_check_and_launch(self):
        self.helper.plugin = types.SimpleNamespace(
            getSettingBool=lambda _name: False)
        from resources.lib.util.streamprofiles import StreamProfiles
        StreamProfiles(self.temporary.name, 'sunshine-a').set(
            '42', 'gaming_1080p120')
        effective = Path(self.temporary.name) / 'profile.conf'
        effective.write_text(
            '[Moonlight]\naddress = sunshine-a\nwidth = 1920\n'
            'height = 1080\nfps = 120\n')
        self.helper.config_helper.create_launch_snapshot = mock.Mock(
            side_effect=[str(self.snapshot), str(effective)])
        self.helper._stream_environment.return_value = {
            'MOONLIGHT_VIDEO_PIPELINE': 'aml',
            'MOONLIGHT_MATCH_HDMI_MODE': '1'}
        self.helper._running_ng_app.return_value = ('0', None)
        self.player.isPlaying.side_effect = [True, False]
        with mock.patch('resources.lib.util.hdmimode.check') as checker:
            self.helper.launch_game('A Game', app_id='42')
        self.helper.config_helper.create_launch_snapshot.assert_any_call(
            stream_profile='gaming_1080p120')
        checker.assert_called_once_with(str(effective))
        kwargs = self.helper._launch_coreelec_ng_service.call_args.args
        self.assertEqual(kwargs[2]['LUNA_STREAM_CONFIG'], str(effective))
        self.assertFalse(self.snapshot.exists())
        self.assertFalse(effective.exists())

    def test_resume_running_other_game_uses_its_own_saved_profile(self):
        self.helper.plugin = types.SimpleNamespace(
            getSettingBool=lambda _name: False)
        from resources.lib.util.streamprofiles import StreamProfiles
        store = StreamProfiles(self.temporary.name, 'sunshine-a')
        store.set('42', 'desktop_4k60')
        store.set('99', 'gaming_1080p120')
        effective = Path(self.temporary.name) / 'resumed.conf'
        effective.write_text('[Moonlight]\nwidth = 1920\nheight = 1080\nfps = 120\n')
        self.helper.config_helper.create_launch_snapshot = mock.Mock(
            side_effect=[str(self.snapshot), str(effective)])
        self.helper.list_games_native_detailed = mock.Mock(
            return_value=[('99', 'Already Playing', None)])
        self.helper._ng_conflict_choice.return_value = 1
        self.player.isPlaying.side_effect = [True, False]
        self.helper.launch_game('Requested Game', app_id='42')
        self.helper.config_helper.create_launch_snapshot.assert_any_call(
            stream_profile='gaming_1080p120')
        args = self.helper._launch_coreelec_ng_service.call_args.args
        self.assertEqual(args[0], 'Already Playing')
        self.assertEqual(args[2]['LUNA_APP_ID'], '99')
        self.assertEqual(args[2]['LUNA_STREAM_CONFIG'], str(effective))
        self.assertFalse(self.snapshot.exists())
        self.assertFalse(effective.exists())

    def test_unsaved_application_keeps_global_stream_snapshot(self):
        self.helper.config_helper.create_launch_snapshot = mock.Mock(
            return_value=str(self.snapshot))
        self.helper._running_ng_app.return_value = ('0', None)
        self.player.isPlaying.side_effect = [True, False]
        self.helper.launch_game('Unconfigured', app_id='42')
        self.helper.config_helper.create_launch_snapshot.assert_called_once_with()
        args = self.helper._launch_coreelec_ng_service.call_args.args
        self.assertEqual(args[2]['LUNA_STREAM_CONFIG'], str(self.snapshot))
        self.assertFalse(self.snapshot.exists())

    def test_definitive_handoff_failure_restores_interrupted_video_and_seek(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper._launch_coreelec_ng_service.return_value = (
            False, 'systemd rejected the handoff')
        item = mock.Mock()
        self.player.getPlayingFile.return_value = 'smb://nas/Films/Example.mkv'
        self.player.getPlayingItem.return_value = item
        self.player.getTime.return_value = 175.5
        # Playback active at capture, stopped by transition, idle when
        # restoring, then active after the original file is reopened.
        self.player.isPlaying.side_effect = [True, False, False, True]
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_called_once()
        self.player.play.assert_called_once_with(
            'smb://nas/Films/Example.mkv', listitem=item)
        self.player.seekTime.assert_called_once_with(175.5)
        self.helper._launch_coreelec_ng_service.assert_called_once()
        self.dialog.ok.assert_called()
        self.assertFalse(self.snapshot.exists())

    def test_slow_network_reopen_uses_deferred_seek_without_sleeping_in_dialog(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.player.getPlayingFile.return_value = 'smb://nas/Films/Delayed.mkv'
        self.player.getTime.return_value = 420.0
        self.player.isPlaying.side_effect = [True, False, False, False]
        with mock.patch('resources.lib.util.kodirestore.schedule_seek') as deferred, \
                mock.patch('resources.lib.util.moonlighthelper.time.sleep') as pause:
            self.helper.launch_game('Desktop', app_id='42')
        deferred.assert_called_once_with('smb://nas/Films/Delayed.mkv', 420.0, paused=False)
        pause.assert_not_called()
        self.player.seekTime.assert_not_called()
        self.dialog.ok.assert_called()


    def test_restore_does_not_seek_different_playing_item(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.player.getPlayingFile.side_effect = [
            'smb://nas/Films/Original.mkv', 'smb://nas/Films/New.mkv']
        self.player.getTime.return_value = 123.0
        self.player.isPlaying.side_effect = [True, False, False, True]
        self.helper.launch_game('Desktop', app_id='42')
        self.player.play.assert_called_once()
        self.player.seekTime.assert_not_called()

    def test_conflicting_host_snapshot_reports_error_before_disruption(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper.config_helper.create_launch_snapshot = mock.Mock(
            side_effect=ValueError('Snapshot contains another host address'))
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_not_called()
        self.player.play.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_not_called()
        self.assertIn('launch snapshot rejected', self.dialog.ok.call_args.args[0])

    def test_input_path_overflow_aborts_before_disrupting_kodi(self):
        from resources.lib.util.inputdevices import InputPathLimitExceeded
        self.helper.config_helper.configure.side_effect = InputPathLimitExceeded(
            '33 explicit paths exceed the native maximum of 32')
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_not_called()
        self.helper._running_ng_app.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_not_called()
        self.assertIn('Too many selected input devices',
                      self.dialog.ok.call_args.args[0])

    def test_successful_handoff_does_not_restart_prior_playback(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper._launch_coreelec_ng_service.return_value = (True, None)
        self.player.getPlayingFile.return_value = 'smb://nas/Films/Example.mkv'
        self.player.getTime.return_value = 56.0
        self.player.isPlaying.side_effect = [True, False]
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_called_once()
        self.player.play.assert_not_called()
        self.player.seekTime.assert_not_called()

    def test_uncertain_handoff_does_not_compete_with_detached_session(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper._launch_coreelec_ng_service.return_value = (
            None, 'launch acknowledgment pending')
        self.player.getPlayingFile.return_value = 'smb://nas/Films/Example.mkv'
        self.player.getTime.return_value = 56.0
        self.player.isPlaying.side_effect = [True, False]
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_called_once()
        self.player.play.assert_not_called()
        self.player.seekTime.assert_not_called()
        self.assertTrue(self.snapshot.exists())
        self.assertIn('unconfirmed', self.dialog.ok.call_args.args[0].lower())

    def test_failed_handoff_does_not_override_new_user_playback(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.player.getPlayingFile.return_value = 'smb://nas/Films/Example.mkv'
        self.player.getTime.return_value = 19.0
        # A new Kodi item starts playing after the failed handoff.
        self.player.isPlaying.side_effect = [True, False, True]
        self.helper.launch_game('Desktop', app_id='42')
        self.player.play.assert_not_called()
        self.player.seekTime.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_called_once()

    def test_failed_app_status_preflight_preserves_current_video(self):
        self.helper._running_ng_app.return_value = (
            None, 'Sunshine unavailable or unpaired')
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_not_called()
        self.player.play.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_not_called()
        xbmc.executebuiltin.assert_not_called()
        self.dialog.ok.assert_called()
        self.assertFalse(self.snapshot.exists())

    def test_local_transition_only_begins_after_remote_validation(self):
        self.helper._running_ng_app.return_value = ('0', None)
        self.helper.plugin = types.SimpleNamespace(
            getSettingBool=lambda _name: False)
        self.player.isPlaying.side_effect = [True, False]
        self.helper.launch_game('Desktop', app_id='42')
        self.player.stop.assert_called_once()
        self.player.play.assert_not_called()
        self.helper._launch_coreelec_ng_service.assert_called_once()
        xbmc.executebuiltin.assert_any_call('InhibitScreensaver(true)')
        xbmc.executebuiltin.assert_any_call('InhibitScreensaver(false)')
        self.assertFalse(self.snapshot.exists())


if __name__ == '__main__':
    unittest.main()
