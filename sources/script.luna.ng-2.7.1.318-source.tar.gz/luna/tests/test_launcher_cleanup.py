"""The NG cleanup must not reintroduce unsafe launch presets or drop the intro."""
from pathlib import Path
import unittest
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]


class LauncherCleanupTests(unittest.TestCase):
    def test_removed_usb_presets_are_not_available(self):
        launchers = ROOT / 'resources/launchscripts'
        self.assertTrue((launchers / 'coreelec/launch.sh').is_file())
        for obsolete in ('coreelec_usb', 'coreelec_usb_new', 'coreelec_praxis'):
            self.assertFalse((launchers / obsolete).exists())

    def test_legacy_script_picker_and_saved_override_are_not_active(self):
        addon = (ROOT / 'addon.py').read_text(encoding='utf-8')
        config = (ROOT / 'resources/lib/util/confighelper.py').read_text(encoding='utf-8')
        settings = ElementTree.parse(ROOT / 'resources/settings.xml')
        ids = {node.get('id') for node in settings.iter('setting')}
        self.assertNotIn('select_launchscripts', addon)
        self.assertNotIn('selectLaunchscripts', addon)
        self.assertNotIn('launchscript_conf', addon)
        self.assertNotIn('launchscript_conf', config)
        self.assertNotIn('launchscript_conf', ids)
        self.assertNotIn('30016', ids)
        self.assertIn('def _launcher_path(addon_root):', config)

    def test_intro_video_and_toggle_are_still_available(self):
        video = ROOT / 'resources/statics/loading.mp4'
        self.assertTrue(video.is_file())
        self.assertGreater(video.stat().st_size, 1000)
        settings = ElementTree.parse(ROOT / 'resources/settings.xml')
        intro = [node for node in settings.iter('setting')
                 if node.get('id') == 'show_intro']
        self.assertEqual(len(intro), 1)
        self.assertEqual(intro[0].findtext('default'), 'false')
        helper = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text(encoding='utf-8')
        self.assertIn('resources/statics/loading.mp4', helper)

    def test_unused_artwork_removed_but_kodi_metadata_assets_preserved(self):
        self.assertTrue((ROOT / 'resources/icon.png').is_file())
        self.assertTrue((ROOT / 'resources/fanart.jpg').is_file())
        for path in ('icon.png', 'fanart.jpg', 'resources/icons/cog.png',
                     'resources/icons/update.png', 'resources/icons/zerotier.png'):
            self.assertFalse((ROOT / path).exists())

    def test_standard_ng_addon_id_and_update_version(self):
        import re
        settings = ElementTree.parse(ROOT / 'resources/settings.xml')
        self.assertEqual(settings.getroot().get('id'), None)
        self.assertEqual(settings.getroot().find('section').get('id'), 'script.luna.ng')
        metadata = ElementTree.parse(ROOT / 'addon.xml').getroot()
        self.assertEqual(metadata.get('id'), 'script.luna.ng')
        self.assertGreater(tuple(int(x) for x in metadata.get('version').split('.')),
                           (2, 7, 1, 308))
        obsolete = re.compile(r'script[.]luna(?![.]ng)')
        runtime_files = [
            'addon.py',
            'resources/lib/util/moonlighthelper.py',
            'resources/lib/util/kodirestore.py',
            'resources/lib/util/diagnosticreport.py',
            'resources/create_bug_report.sh',
            'resources/launchscripts/coreelec/launch.sh',
            'resources/launchscripts/coreelec/hang-diagnostics.sh',
            'resources/settings.xml',
        ]
        for path in runtime_files:
            with self.subTest(path=path):
                text = (ROOT / path).read_text(encoding='utf-8')
                self.assertIsNone(obsolete.search(text), path)

    def test_old_vortex_import_pipeline_is_not_live(self):
        self.assertFalse((ROOT / '.github/workflows/import-vortex.yml').exists())
        self.assertFalse((ROOT / 'tools/import_vortex.py').exists())


if __name__ == '__main__':
    unittest.main()
