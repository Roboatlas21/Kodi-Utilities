"""Bounded persistent state locks must never follow a link or trap Kodi."""
import fcntl
import os
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest
from unittest import mock

sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))
from resources.lib.util import safelock
from resources.lib.util.library import Library
from resources.lib.util.streamprofiles import StreamProfiles, ProfileDataError
from resources.lib.util.confighelper import ConfigHelper


class SafeLockTests(unittest.TestCase):
    def test_regular_lock_survives_multiple_writers_and_is_never_removed(self):
        with tempfile.TemporaryDirectory() as td:
            lock = Path(td) / 'state.lock'
            with safelock.locked_regular_file(lock, timeout=0.2) as fd:
                first_inode = os.fstat(fd).st_ino
                self.assertEqual(os.fstat(fd).st_mode & 0o777, 0o600)
            with safelock.locked_regular_file(lock, timeout=0.2) as fd:
                self.assertEqual(os.fstat(fd).st_ino, first_inode)
            self.assertEqual(lock.stat().st_ino, first_inode)

    def test_contended_lock_has_finite_monotonic_deadline(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'state.lock'
            with path.open('a+b') as holder:
                fcntl.flock(holder.fileno(), fcntl.LOCK_EX)
                start = time.monotonic()
                with self.assertRaisesRegex(TimeoutError, 'Luna file lock'):
                    with safelock.locked_regular_file(path, timeout=0.12):
                        self.fail('Lock was acquired while held')
                self.assertLess(time.monotonic() - start, 1.0)
            with safelock.locked_regular_file(path, timeout=0.12):
                pass

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_fifo_lock_does_not_block_and_existing_link_is_untouched(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            lock = root / 'state.lock'
            os.mkfifo(lock)
            start = time.monotonic()
            with self.assertRaises(OSError):
                with safelock.locked_regular_file(lock, timeout=0.1):
                    pass
            self.assertLess(time.monotonic() - start, 1.0)
            self.assertTrue(lock.exists())
            lock.unlink()
            target = root / 'target'
            target.write_text('safe')
            lock.symlink_to(target)
            with self.assertRaises(OSError):
                with safelock.locked_regular_file(lock, timeout=0.1):
                    pass
            self.assertEqual(target.read_text(), 'safe')
            lock.unlink()
            lock.mkdir()
            with self.assertRaises(OSError):
                with safelock.locked_regular_file(lock, timeout=0.1):
                    pass

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_all_three_writers_reject_special_lock_without_state_write(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            folders = Library(td, host='sunshine-host')
            folder_lock = root / 'folders.json.lock'
            os.mkfifo(folder_lock)
            self.assertFalse(folders.add_folder('Games'))
            self.assertFalse(folders.migrate_legacy())
            self.assertFalse((root / 'folders.json').exists())
            folder_lock.unlink()

            profiles = StreamProfiles(td, 'sunshine-host')
            profiles_lock = root / 'stream-profiles.json.lock'
            os.mkfifo(profiles_lock)
            with self.assertRaises(ProfileDataError):
                profiles.set('42', 'desktop_4k60')
            self.assertFalse(profiles.path.exists())
            profiles_lock.unlink()

            config = ConfigHelper.__new__(ConfigHelper)
            config.config_path = str(root / 'moonlight.conf')
            config._dump_conf_locked = mock.Mock()
            os.mkfifo(str(config.config_path) + '.lock')
            with self.assertRaises(OSError):
                config._dump_conf()
            config._dump_conf_locked.assert_not_called()
            self.assertFalse(Path(config.config_path).exists())


if __name__ == '__main__':
    unittest.main()
