"""Regression checks for native PIN + subsequent HTTPS pairing stages."""
import unittest
from resources.lib.util.pairing_deadline import PairingDeadline


class PairingDeadlineTests(unittest.TestCase):
    def test_no_pin_expires(self):
        p = PairingDeadline(100)
        self.assertFalse(p.expired(119.9))
        self.assertTrue(p.expired(120))

    def test_pin_response_preserves_native_65_second_request(self):
        p = PairingDeadline(0)
        p.pin_shown(2)
        self.assertFalse(p.expired(66))
        self.assertFalse(p.expired(71))
        self.assertTrue(p.expired(72))

    def test_progress_allows_full_handshake(self):
        p = PairingDeadline(0)
        p.pin_shown(1)
        p.stage('Pairing: Host returned its certificate; verifying identity...', 65)
        self.assertFalse(p.expired(115))
        p.stage('Pairing: Confirming pairing over HTTPS...', 117)
        self.assertFalse(p.expired(165))
        self.assertTrue(p.expired(173))

    def test_repeated_output_never_extends_deadline(self):
        p = PairingDeadline(0)
        p.pin_shown(1)
        label = 'Pairing: Host returned its certificate; verifying identity...'
        p.stage(label, 50)
        before = p.deadline
        p.stage(label, 101)
        p.stage('Response: debug line', 105)
        self.assertEqual(p.deadline, before)
        for i in range(500):
            p.stage('Pairing: another stage ' + str(i), 178)
        self.assertEqual(p.deadline, 180)
        self.assertTrue(p.expired(180))


if __name__ == '__main__':
    unittest.main()
