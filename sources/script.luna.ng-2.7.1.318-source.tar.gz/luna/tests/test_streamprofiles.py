"""Persistent per-app stream presets and safe per-launch config rendering."""
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

from resources.lib.util import streamprofiles as profile_module
from resources.lib.util.streamprofiles import (
    StreamProfiles, ProfileDataError, ProfileCommitError, apply_to_config,
    PROFILE_MODES)


class ProfileTests(unittest.TestCase):
    def test_save_errors_distinguish_commit_from_durability(self):
        real_open, real_fsync = os.open, os.fsync
        for profile in ('gaming_1080p120', None):
            for stage in ('file_sync', 'replace', 'directory_open', 'directory_sync'):
                with self.subTest(profile=profile, stage=stage):
                    self.a.set('42', 'desktop_4k60')
                    def sync(fd):
                        is_dir = stat.S_ISDIR(os.fstat(fd).st_mode)
                        if (stage == 'file_sync' and not is_dir or
                                stage == 'directory_sync' and is_dir):
                            raise OSError('injected sync failure')
                        return real_fsync(fd)
                    def open_file(path, flags, *args, **kwargs):
                        if stage == 'directory_open' and flags & os.O_DIRECTORY:
                            raise OSError('injected directory open failure')
                        return real_open(path, flags, *args, **kwargs)
                    committed = stage.startswith('directory_')
                    expected = ProfileCommitError if committed else ProfileDataError
                    with mock.patch.object(profile_module.os, 'fsync', side_effect=sync), \
                            mock.patch.object(profile_module.os, 'open', side_effect=open_file), \
                            mock.patch.object(profile_module.os, 'replace',
                                              wraps=os.replace) as replace:
                        if stage == 'replace':
                            replace.side_effect = OSError('injected replace failure')
                        with self.assertRaises(expected) as failure:
                            self.a.set('42', profile)
                        self.assertEqual(type(failure.exception), expected)
                    self.assertEqual(self.a.get('42'), profile if committed else 'desktop_4k60')

    def test_explicit_profiles_remove_native_resolution_aliases(self):
        dims = 'width=1280\nheight=720\nfps=60\n'
        inputs = 'input=/dev/input/event1\ninput=/dev/input/event2\n'
        for profile, (width, height, fps) in PROFILE_MODES.items():
            for value in ('true', 'false'):
                aliases = ''.join(key + '=' + value + '\n' for key in ('720', '1080', '4k'))
                for body in (aliases + dims, dims + aliases):
                    with self.subTest(profile=profile, value=value, body=body):
                        result = apply_to_config('[Moonlight]\n' + body + inputs +
                                                 '[Other]\n4k=true\n', profile)
                        moonlight, other = result.split('[Other]')
                        for key in ('720', '1080', '4k'):
                            self.assertNotIn('\n' + key + '=', moonlight)
                        self.assertIn('width = %d\nheight = %d\nfps = %d\n' %
                                      (width, height, fps), moonlight)
                        self.assertIn(inputs, moonlight)
                        self.assertIn('4k=true', other)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.a = StreamProfiles(self.folder, 'HOST A')
        self.a_alias = StreamProfiles(self.folder, 'host a')
        self.b = StreamProfiles(self.folder, 'host b')

    def test_profile_fifo_and_oversize_are_rejected(self):
        path = self.folder / 'stream-profiles.json'
        if hasattr(os, 'mkfifo'):
            os.mkfifo(path)
            with self.assertRaises(ProfileDataError):
                self.a.get('42')
            path.unlink()
        path.write_bytes(b' ' * (1024 * 1024 + 1))
        with self.assertRaises(ProfileDataError):
            self.a.get('42')
        self.assertEqual(path.stat().st_size, 1024 * 1024 + 1)

    def test_presets_and_host_and_id_isolation(self):
        self.assertEqual(PROFILE_MODES['desktop_4k60'], (3840, 2160, 60))
        self.assertEqual(PROFILE_MODES['gaming_1080p120'], (1920, 1080, 120))
        self.assertTrue(self.a.set('0012', 'gaming_1080p120'))
        self.assertEqual(self.a_alias.get(12), 'gaming_1080p120')
        self.assertIsNone(self.a.get('13'))
        self.assertIsNone(self.b.get('12'))
        self.assertTrue(self.b.set('12', 'desktop_4k60'))
        self.assertEqual(self.a.get('12'), 'gaming_1080p120')
        self.assertEqual(self.b.get('12'), 'desktop_4k60')
        self.assertTrue(self.a.set('12', None))
        self.assertIsNone(self.a.get('12'))
        self.assertEqual(self.b.get('12'), 'desktop_4k60')

    def test_profile_write_matches_reader_byte_limit(self):
        payload = {'schema': 1, 'by_host': {
            self.a.key: {'1': 'desktop_4k60'}}}
        limit = len((json.dumps(
            payload, ensure_ascii=False, separators=(',', ':')) + '\n'
            ).encode('utf-8'))
        with mock.patch.object(profile_module, 'MAX_FILE_SIZE', limit):
            self.assertTrue(self.a.set('1', 'desktop_4k60'))
            existing = self.a.path.read_bytes()
            self.assertEqual(len(existing), limit)
            with self.assertRaisesRegex(ProfileDataError, 'limit'):
                self.a.set('2', 'gaming_1080p120')
            self.assertEqual(self.a.path.read_bytes(), existing)
            self.assertEqual(self.a.get('1'), 'desktop_4k60')
            self.assertIsNone(self.a.get('2'))
            self.assertFalse(list(self.folder.glob('.stream-profiles-*.tmp')))

    def test_unchanged_profile_does_not_rewrite(self):
        self.assertFalse(self.a.set('8', None))
        self.assertFalse(self.a.path.exists())
        self.assertTrue(self.a.set('8', 'desktop_4k60'))
        original = self.a.path.stat().st_mtime_ns
        self.assertFalse(self.a.set('8', 'desktop_4k60'))
        self.assertEqual(original, self.a.path.stat().st_mtime_ns)
        self.assertEqual(stat.S_IMODE(self.a.path.stat().st_mode), 0o600)

    def test_rejects_bad_ids_and_preserves_damaged_state(self):
        for ident in ('-1', 'notnum', '2147483648', '000000000000000001'):
            with self.assertRaises(ValueError):
                self.a.set(ident, 'desktop_4k60')
        with self.assertRaises(ValueError):
            self.a.set('9', '4k120')
        self.a.path.write_text('corrupted')
        with self.assertRaises(ProfileDataError):
            self.a.set('9', 'gaming_1080p120')
        self.assertEqual(self.a.path.read_text(), 'corrupted')

    def test_rejects_symlinks_and_does_not_touch_foreign_file(self):
        foreign = self.folder / 'foreign'
        foreign.write_text('do not modify')
        self.a.path.symlink_to(foreign)
        with self.assertRaises(ProfileDataError):
            self.a.set('9', 'desktop_4k60')
        self.assertEqual(foreign.read_text(), 'do not modify')

    def test_overlapping_instances_do_not_overwrite_profiles(self):
        stale = StreamProfiles(self.folder, 'host a')
        fresh = StreamProfiles(self.folder, 'host a')
        self.assertTrue(stale.set('1', 'desktop_4k60'))
        self.assertTrue(fresh.set('2', 'gaming_1080p120'))
        self.assertEqual(stale.get('2'), 'gaming_1080p120')
        self.assertEqual(fresh.get('1'), 'desktop_4k60')

    def test_launch_copy_preserves_repeated_input_devices(self):
        original = ('[Moonlight]\naddress = hosta\nwidth = 1280\nheight = 720\n'
                    'fps = 60\ninput = /dev/input/event1\ninput = /dev/input/event2\n'
                    'codec = h265\n[Extra]\nwidth = 9\n')
        expected = ('[Moonlight]\naddress = hosta\nwidth = 1920\nheight = 1080\n'
                    'fps = 120\ninput = /dev/input/event1\ninput = /dev/input/event2\n'
                    'codec = h265\n[Extra]\nwidth = 9\n')
        self.assertEqual(apply_to_config(original, 'gaming_1080p120'), expected)
        self.assertEqual(apply_to_config(original, 'desktop_4k60').count('input ='), 2)

    def test_invalid_stream_dimensions_fail_without_modification(self):
        for source in ('[Moonlight]\nwidth=1920\nheight=1080\n',
                       '[Moonlight]\nwidth=1920\nwidth=1280\nheight=1080\nfps=60\n',
                       '[Other]\nwidth=1920\nheight=1080\nfps=60\n'):
            with self.assertRaises(ValueError):
                apply_to_config(source, 'gaming_1080p120')


if __name__ == '__main__':
    unittest.main()
