"""Kodi settings.xml must remain bounded and safe through detached updates."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from xml.etree import ElementTree

from resources.lib.util import safefile, safexml
from resources.lib.util.resumestate import set_last_run
from resources.lib.util.settingsstore import update_setting


class SafeSettingsXmlTests(unittest.TestCase):
    def test_regular_settings_roundtrip_and_unchanged_metadata(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'settings.xml'
            set_last_run(path, 'Desktop', 'host-a', '42')
            tree, mode = safexml.read_settings_tree(path)
            self.assertEqual(mode, 0o600)
            self.assertEqual(tree.getroot().findtext(
                'setting[@id="last_run_id"]'), '42')
            update_setting(path, 'paired_state', 'true')
            root = ElementTree.parse(path).getroot()
            self.assertEqual(root.findtext(
                'setting[@id="paired_state"]'), 'true')
            self.assertEqual(root.findtext(
                'setting[@id="last_run"]'), 'Desktop')

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO required')
    def test_fifo_settings_and_fifo_lock_are_never_opened_blocking(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'settings.xml'
            os.mkfifo(path)
            with self.assertRaises(ValueError):
                set_last_run(path, 'Desktop')
            with self.assertRaises(ValueError):
                update_setting(path, 'paired_state', 'true')
            path.unlink()
            path.write_text('<settings/>')
            lock = path.with_name(path.name + '.lock')
            lock.unlink()
            os.mkfifo(lock)
            with self.assertRaises(ValueError):
                set_last_run(path, 'Desktop')
            with self.assertRaises(ValueError):
                update_setting(path, 'paired_state', 'true')
            self.assertEqual(path.read_text(), '<settings/>')

    def test_oversized_and_invalid_xml_never_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'settings.xml'
            data = '<settings>' + (' ' * 512) + '</settings>'
            path.write_text(data)
            with mock.patch.object(safexml, 'MAX_SETTINGS_BYTES', 128):
                with self.assertRaises(ValueError):
                    set_last_run(path, 'Desktop')
                with self.assertRaises(ValueError):
                    update_setting(path, 'paired_state', 'true')
            self.assertEqual(path.read_text(), data)
            path.write_text('<settings><setting>')
            with self.assertRaises(ValueError):
                set_last_run(path, 'Desktop')
            self.assertEqual(path.read_text(), '<settings><setting>')

    def test_output_larger_than_reader_cap_does_not_replace_settings(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'settings.xml'
            path.write_text('<settings><setting id="x">old</setting></settings>')
            original = path.read_bytes()
            # Safe read succeeds, but the proposed new write would not.
            with mock.patch.object(safexml, 'MAX_SETTINGS_BYTES', len(original)):
                with self.assertRaisesRegex(ValueError, 'size limit'):
                    update_setting(path, 'x', 'a' * 200)
            self.assertEqual(path.read_bytes(), original)

    def test_read_uses_file_opened_before_concurrent_rename(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'settings.xml'
            newer = Path(td) / 'new.xml'
            path.write_text('<settings><setting id="x">old</setting></settings>')
            newer.write_text('<settings><setting id="x">new</setting></settings>')
            original_open = os.open
            def swap_after_open(name, flags, *args, **kwargs):
                fd = original_open(name, flags, *args, **kwargs)
                if os.fspath(name) == os.fspath(path):
                    os.replace(newer, path)
                return fd
            with mock.patch.object(safefile.os, 'open',
                                   side_effect=swap_after_open):
                tree, _ = safexml.read_settings_tree(path)
            self.assertEqual(tree.getroot().findtext('setting'), 'old')
            self.assertIn('new', path.read_text())

    def test_resume_cli_imports_helpers_without_kodi_pythonpath(self):
        # launch.sh executes resumestate.py as a file, not as -m resources...
        # Package imports work in Kodi but fail in this real direct-entry path.
        root = Path(__file__).resolve().parents[1]
        script = root / 'resources/lib/util/resumestate.py'
        with tempfile.TemporaryDirectory() as td:
            state = Path(td) / 'settings.xml'
            env = os.environ.copy()
            env.pop('PYTHONPATH', None)
            run = subprocess.run(
                [sys.executable, str(script), 'set', str(state),
                 'Desktop', 'sunshine-a', '42'],
                cwd=td, env=env, capture_output=True, text=True, timeout=12)
            self.assertEqual(run.returncode, 0, run.stderr)
            root_node = ElementTree.parse(state).getroot()
            self.assertEqual(root_node.findtext(
                'setting[@id="last_run_id"]'), '42')

    def test_resume_helper_has_a_bounded_launcher_deadline(self):
        root = Path(__file__).resolve().parents[1]
        launch = (root / 'resources/launchscripts/coreelec/launch.sh').read_text()
        self.assertIn('luna_timeout -k 2 10 python3 "$resume_helper" set', launch)


if __name__ == '__main__':
    unittest.main()
