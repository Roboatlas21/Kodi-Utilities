# SPDX-License-Identifier: GPL-3.0-or-later
"""No Kodi toggle: native DualSense HID support is automatic."""
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
settings = ElementTree.parse(ROOT / "resources/settings.xml")
assert settings.find(".//setting[@id='dualsense_hid']") is None

source = (ROOT / "resources/lib/util/confighelper.py").read_text()
assert "self.plugin.getSetting('dualsense_hid')" not in source
assert "self.config['dualsense_hid']" not in source
assert "config.set('Moonlight', 'dualsensehid'" not in source
# The legacy config entry is scrubbed on the next normal config generation.
assert "config.remove_option('Moonlight', 'dualsensehid')" in source

strings = (ROOT / "resources/language/resource.language.en_gb/strings.po").read_text()
assert 'msgctxt "#30359"' not in strings
assert 'msgctxt "#30360"' not in strings
print("PASS: DualSense is automatic with no toggle or stale config option")
