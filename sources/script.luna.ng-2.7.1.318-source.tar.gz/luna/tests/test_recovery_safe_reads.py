"""Regression guards for recovery readers on hostile local state paths."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from resources.lib.util import (diagnosticreport, hdmigamemode,
                                hdmimode, vfmruntime)


class RecoveryReadSafetyTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)

    def test_vfm_decoder_fifo_and_nested_json_keep_journal_armed(self):
        state = self.root / '.luna-session.ABCD1234.decoder-state'
        with mock.patch.object(vfmruntime, '_restore_stock_decoder') as restore:
            if hasattr(os, 'mkfifo'):
                os.mkfifo(state)
                with self.assertRaises(vfmruntime.VfmRuntimeError):
                    vfmruntime.recover_decoder(state)
                restore.assert_not_called()
                state.unlink()
            state.write_text('[' * 65 + '0' + ']' * 65)
            with self.assertRaises(vfmruntime.VfmRuntimeError):
                vfmruntime.recover_decoder(state)
            self.assertTrue(state.exists())
            restore.assert_not_called()

    def test_vfm_manifest_fifo_and_nested_json_are_rejected(self):
        manifest = self.root / 'manifest.json'
        if hasattr(os, 'mkfifo'):
            os.mkfifo(manifest)
            with self.assertRaises(vfmruntime.VfmRuntimeError):
                vfmruntime.verify_bundle(self.root)
            manifest.unlink()
        manifest.write_text('[' * 65 + '0' + ']' * 65)
        with self.assertRaises(vfmruntime.VfmRuntimeError):
            vfmruntime.verify_bundle(self.root)

    def test_hdmi_mode_fifo_and_oversized_journal_preserve_mode(self):
        state = self.root / 'mode-state'
        mode = self.root / 'mode'
        cap = self.root / 'cap'
        mode.write_text('2160p60hz')
        cap.write_text('1080p120hz\n2160p60hz\n')
        if hasattr(os, 'mkfifo'):
            os.mkfifo(state)
            with self.assertRaises(ValueError):
                hdmimode.restore(state, mode, cap)
            self.assertEqual(mode.read_text(), '2160p60hz')
            state.unlink()
        state.write_text('x' * 4097)
        with self.assertRaises(ValueError):
            hdmimode.restore(state, mode, cap)
        self.assertTrue(state.exists())
        self.assertEqual(mode.read_text(), '2160p60hz')

    def test_hdmi_game_empty_marker_and_fifo_do_not_write_sysfs(self):
        state = self.root / 'game-state'
        state.touch()
        with mock.patch.object(hdmigamemode, 'write') as write:
            hdmigamemode.restore(state)
            write.assert_not_called()
        state.unlink()
        if hasattr(os, 'mkfifo'):
            os.mkfifo(state)
            with mock.patch.object(hdmigamemode, 'write') as write:
                with self.assertRaises(ValueError):
                    hdmigamemode.restore(state)
                write.assert_not_called()
            self.assertTrue(state.exists())

    def test_diagnostics_fifo_source_never_starts_export(self):
        if not hasattr(os, 'mkfifo'):
            self.skipTest('POSIX FIFO required')
        source = self.root / 'luna-diagnostics-test.txt'
        os.mkfifo(source)
        with self.assertRaises(OSError):
            diagnosticreport.export_report(source, self.root / 'share')
        self.assertFalse((self.root / 'share').exists())

    def test_diagnostics_growth_after_fstat_never_exports(self):
        source = self.root / 'luna-diagnostics-test.txt'
        source.write_text('Luna diagnostic report - LOCAL FILE ONLY\nhello\n')
        original = os.fstat
        grown = [False]
        def after_metadata(fd):
            metadata = original(fd)
            if not grown[0]:
                grown[0] = True
                with source.open('ab') as stream:
                    stream.write(b'x' * (4 * 1024 * 1024 + 1))
            return metadata
        with mock.patch.object(diagnosticreport.os, 'fstat',
                               side_effect=after_metadata):
            with self.assertRaises(OSError):
                diagnosticreport.export_report(source, self.root / 'share')
        self.assertFalse((self.root / 'share').exists())


if __name__ == '__main__':
    unittest.main()
