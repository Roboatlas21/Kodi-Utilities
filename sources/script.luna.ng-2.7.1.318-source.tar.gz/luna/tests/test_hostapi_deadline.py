"""Exercise total HTTP body/header deadlines without per-request timers."""
import http.client
import socket
import threading
import time
import unittest
from unittest import mock

from resources.lib.util.hostapi import response_deadline


class ResponseDeadlineTests(unittest.TestCase):
    def _connection(self):
        left, right = socket.socketpair()
        conn = http.client.HTTPConnection('unused-local', 80, timeout=1)
        conn.sock = left
        self.addCleanup(conn.close)
        self.addCleanup(right.close)
        return conn, right

    def test_ordinary_http_headers_and_body_complete_without_timer_thread(self):
        conn, peer = self._connection()
        def respond():
            peer.recv(4096)
            peer.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\npong')
        worker = threading.Thread(target=respond)
        worker.start()
        try:
            with mock.patch('resources.lib.util.hostapi.threading.Timer',
                            side_effect=AssertionError('no timers allowed')):
                with response_deadline(conn, seconds=.4):
                    conn.request('GET', '/serverinfo')
                    response = conn.getresponse()
                    self.assertEqual(response.status, 200)
                    self.assertEqual(response.read(5), b'pong')
        finally:
            worker.join(timeout=1)
        self.assertFalse(worker.is_alive())

    def test_trickling_body_expires_at_total_deadline(self):
        conn, peer = self._connection()
        started = threading.Event()
        def trickle():
            peer.recv(4096)
            peer.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 30\r\n\r\n')
            for _ in range(15):
                if not started.is_set():
                    break
                try:
                    peer.sendall(b'x')
                except OSError:
                    break
                time.sleep(.04)
        worker = threading.Thread(target=trickle)
        started.set()
        worker.start()
        before = time.monotonic()
        try:
            with self.assertRaises(socket.timeout):
                with response_deadline(conn, seconds=.17):
                    conn.request('GET', '/slow')
                    response = conn.getresponse()
                    response.read(31)
            self.assertLess(time.monotonic() - before, .40)
        finally:
            started.clear()
            conn.close()
            peer.close()
            worker.join(timeout=1)

    def test_no_client_timer_and_no_socket_identity_replacement(self):
        conn, peer = self._connection()
        original = conn.sock
        with response_deadline(conn, seconds=1):
            self.assertIsNot(conn.sock, original)
            self.assertIs(conn.sock._sock, original)
        self.assertIs(conn.sock, original)


    def test_close_delimited_responses_retain_socket_until_body_finishes(self):
        # http.client.getresponse() immediately calls HTTPConnection.close()
        # for these response types. The deadline reader must keep a socket
        # makefile reference alive until even a delayed body is consumed.
        for header in (
                b'HTTP/1.0 200 OK\r\nContent-Length: 4\r\n\r\n',
                b'HTTP/1.1 200 OK\r\nContent-Length: 4\r\n'
                b'Connection: close\r\n\r\n'):
            with self.subTest(response=header.split(b'\r\n', 1)[0]):
                conn, peer = self._connection()
                def respond():
                    try:
                        peer.recv(4096)
                        peer.sendall(header)
                        time.sleep(.06)
                        peer.sendall(b'pong')
                    except OSError:
                        pass
                worker = threading.Thread(target=respond)
                worker.start()
                try:
                    with response_deadline(conn, seconds=.4):
                        conn.request('GET', '/serverinfo')
                        response = conn.getresponse()
                        self.assertTrue(response.will_close)
                        self.assertIsNone(conn.sock)
                        self.assertEqual(response.read(4), b'pong')
                finally:
                    worker.join(timeout=1)
                self.assertFalse(worker.is_alive())

    def test_close_delimited_trickling_body_keeps_absolute_deadline(self):
        conn, peer = self._connection()
        finished = threading.Event()
        def respond():
            try:
                peer.recv(4096)
                peer.sendall(b'HTTP/1.0 200 OK\r\nContent-Length: 9\r\n\r\n')
                for _ in range(9):
                    if finished.wait(.04):
                        break
                    peer.sendall(b'x')
            except OSError:
                pass
        worker = threading.Thread(target=respond)
        worker.start()
        started = time.monotonic()
        try:
            with self.assertRaises(socket.timeout):
                with response_deadline(conn, seconds=.14):
                    conn.request('GET', '/slow')
                    response = conn.getresponse()
                    self.assertTrue(response.will_close)
                    response.read(9)
            self.assertLess(time.monotonic() - started, .36)
        finally:
            finished.set()
            conn.close()
            peer.close()
            worker.join(timeout=1)

    def test_timeout_before_body_starts(self):
        conn, peer = self._connection()
        with self.assertRaises(socket.timeout):
            with response_deadline(conn, seconds=.03):
                conn.request('GET', '/noreply')
                conn.getresponse()


if __name__ == '__main__':
    unittest.main()
