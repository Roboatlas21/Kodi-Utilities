"""Ensure shared Moonlight configuration is atomic and per-launch copies are stable."""
import os
import tempfile
import types
import sys
import unittest
from pathlib import Path
from unittest import mock

# Kodi's xbmcaddon module is not installed in the host Python environment.
sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))
from resources.lib.util.confighelper import ConfigHelper, MoonlightConfigFormatError


class SnapshotTests(unittest.TestCase):
    def test_snapshot_uses_original_rendered_settings_after_shared_rewrite(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            helper._launch_config_content = (
                '[Moonlight]\naddress = 192.0.2.10\ncodec = h264\n')
            helper._atomic_config_write(helper.config_path,
                                        helper._launch_config_content)
            snapshot = helper.create_launch_snapshot()
            try:
                self.assertEqual(os.stat(snapshot).st_mode & 0o777, 0o600)
                assert Path(snapshot).read_text().find('192.0.2.10') >= 0
                helper._atomic_config_write(helper.config_path,
                    '[Moonlight]\naddress = 192.0.2.99\n')
                self.assertIn('192.0.2.10', Path(snapshot).read_text())
                self.assertIn('192.0.2.99', Path(helper.config_path).read_text())
            finally:
                os.unlink(snapshot)

    def test_app_profile_creates_distinct_snapshot_without_changing_defaults(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            content = ('[Moonlight]\naddress = sunshine-a\nwidth = 1280\n'
                       'height = 720\nfps = 60\n'
                       'input = /dev/input/event1\ninput = /dev/input/event2\n')
            helper._launch_config_content = content
            base = helper.create_launch_snapshot()
            gaming = helper.create_launch_snapshot(stream_profile='gaming_1080p120')
            desktop = helper.create_launch_snapshot(stream_profile='desktop_4k60')
            try:
                self.assertEqual(Path(base).read_text(), content)
                self.assertEqual(Path(gaming).read_text().count('input ='), 2)
                self.assertIn('width = 1920\nheight = 1080\nfps = 120\n',
                              Path(gaming).read_text())
                self.assertIn('width = 3840\nheight = 2160\nfps = 60\n',
                              Path(desktop).read_text())
                self.assertEqual(helper._launch_config_content, content)
                self.assertFalse(Path(helper.config_path).exists())
                self.assertEqual(os.stat(gaming).st_mode & 0o777, 0o600)
                self.assertNotEqual(base, gaming)
            finally:
                for file_path in (base, gaming, desktop):
                    os.unlink(file_path)

    def test_stale_appid_is_removed_from_shared_and_stream_config(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            Path(helper.config_path).write_text(
                '[Moonlight]\nappid = 99\naddress = old\n'
                'dualsensehid = false\n720 = true\n1080 = false\n4k = true\n'
                '[Other]\noption = preserved\n')
            helper.config = {
                'host_addr': 'host-a', 'resolution': '1280x720',
                'resolution_width': '1280', 'resolution_height': '720',
                'framerate': '60', 'bitrate': 10,
                'packetsize': 1392, 'remote_optimizations': 'auto',
                'local_audio': 'false', 'debug_mode': 'false',
                'audio_device_parameter': 'hw:0,0', 'codec': 'h264',
                'surround': 'false', 'gamepad_mouse': 'false',
                'hdr_flag': 'false', 'cec': 'false', 'osd': 'false',
                'osd_font_size': '20', 'osd_top': '40',
                'osd_interval': '1.5', 'osd_position': 'right',
            }
            helper.plugin = mock.Mock()
            helper.plugin.getSetting.return_value = ''
            helper.logger = mock.Mock()
            with mock.patch(
                    'resources.lib.util.confighelper.audiodevices.list_playback',
                    return_value=[{'alsa': 'surround40:CARD=USB,DEV=0', 'name': 'USB'}]), mock.patch(
                    'resources.lib.util.confighelper.inputdevices.resolve_selectors',
                    return_value=['/dev/input/event6', '/dev/input/event7']):
                helper._dump_conf()
            content = Path(helper.config_path).read_text()
            helper.config['host_addr'] = 'http://invalid-host'
            with self.assertRaises(MoonlightConfigFormatError):
                helper._dump_conf()
            self.assertEqual(Path(helper.config_path).read_text(), content)
            helper.config['host_addr'] = 'host-a'

            self.assertIn('audio = hw:0,0', content)
            self.assertNotIn(mock.call('audio_device_parameter', 'surround40:CARD=USB,DEV=0'),
                             helper.plugin.setSettingString.call_args_list)
            moonlight, other = content.split('[Other]', 1)
            self.assertEqual(moonlight.count('input = '), 2)
            for preset in ('720', '1080', '4k'):
                self.assertNotIn('\n' + preset + ' =', moonlight)
            self.assertIn('input = /dev/input/event6', moonlight)
            self.assertIn('input = /dev/input/event7', moonlight)
            self.assertNotIn('input = ', other)
            self.assertIn('option = preserved', other)
            snapshot = helper.create_launch_snapshot()
            try:
                self.assertNotIn('appid', Path(helper.config_path).read_text())
                self.assertNotIn('dualsensehid', Path(helper.config_path).read_text())
                self.assertNotIn('appid', Path(snapshot).read_text())
            finally:
                os.unlink(snapshot)

    def test_scoped_ipv6_host_and_literal_percent_are_serialized(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            Path(helper.config_path).write_text(
                '[Other]\ndescription = 100% configured\n')
            helper.config = {
                'host_addr': 'fe80::abcd%eth0', 'resolution': '1920x1080',
                'resolution_width': '1920', 'resolution_height': '1080',
                'framerate': '60', 'bitrate': 10,
                'packetsize': 1392, 'remote_optimizations': 'auto',
                'local_audio': 'false', 'debug_mode': 'false',
                'audio_device_parameter': '', 'codec': 'h265',
                'surround': 'false', 'gamepad_mouse': 'false',
                'hdr_flag': 'false', 'cec': 'false', 'osd': 'false',
                'osd_font_size': '20', 'osd_top': '40',
                'osd_interval': '1.5', 'osd_position': 'right',
            }
            helper.plugin = mock.Mock()
            helper.logger = mock.Mock()
            with mock.patch(
                    'resources.lib.util.confighelper.audiodevices.list_playback',
                    return_value=[]), mock.patch(
                    'resources.lib.util.confighelper.inputdevices.load_selectors',
                    return_value=[]), mock.patch(
                    'resources.lib.util.confighelper.inputdevices.resolve_selectors',
                    return_value=[]):
                helper._dump_conf()
            content = Path(helper.config_path).read_text(encoding='utf-8')
            self.assertIn('address = fe80::abcd%eth0', content)
            self.assertIn('description = 100% configured', content)
            saved = helper.create_launch_snapshot()
            try:
                self.assertIn('address = fe80::abcd%eth0',
                              Path(saved).read_text(encoding='utf-8'))
            finally:
                saved_path = Path(saved)
                saved_path.unlink()

    def test_conflicting_addresses_fail_before_creating_a_snapshot(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            helper.config = {'host_addr': 'gaming-vm'}
            for content in (
                '[Moonlight]\naddress = desktop-vm\n',
                '[Moonlight]\naddress = gaming-vm\n[Other]\naddress = desktop-vm\n',
            ):
                helper._launch_config_content = content
                with self.assertRaisesRegex(ValueError, 'host'):
                    helper.create_launch_snapshot()
                self.assertFalse(list(Path(td).glob('.luna-stream-*')))

    def test_saved_address_comes_only_from_moonlight_section(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            Path(helper.config_path).write_text(
                '[Other]\naddress = desktop-vm\n'
                '[Moonlight]\naddress = gaming-vm\n')
            parsed = helper._read_sectioned_conf()
            self.assertEqual(parsed.get('Moonlight', 'address', fallback=''),
                             'gaming-vm')
            Path(helper.config_path).write_text(
                '[Other]\naddress = desktop-vm\n')
            self.assertEqual(helper._read_sectioned_conf().get(
                'Moonlight', 'address', fallback=''), '')
            Path(helper.config_path).write_text('address = legacy-vm\n')
            with self.assertRaisesRegex(MoonlightConfigFormatError, 'sectionless'):
                helper._read_sectioned_conf()

    def test_current_sectioned_host_is_recovered_without_rewriting_file(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            binary = root / 'bin' / 'coreelec-ng'
            binary.mkdir(parents=True)
            config = binary / 'moonlight.conf'
            original = ('# Managed by Luna\n'
                        '[Other]\naddress = never-this-host\n'
                        '[Moonlight]\naddress = gaming-vm\n')
            config.write_text(original, encoding='utf-8')
            addon = types.SimpleNamespace(getAddonInfo=lambda key: str(root))
            settings = mock.Mock()
            settings.getSetting.side_effect = lambda name: (
                '' if name == 'host_addr' else
                '1280x720' if name == 'resolution' else ''
            )
            settings.getSettingInt.return_value = 10
            with mock.patch('xbmcaddon.Addon', return_value=addon, create=True), \
                 mock.patch.object(ConfigHelper, '_find_binary',
                                   return_value=str(binary) + os.sep):
                helper = ConfigHelper(settings, mock.Mock())
            self.assertIsNone(helper.config_error)
            self.assertEqual(helper.config['host_addr'], 'gaming-vm')
            self.assertEqual(config.read_text(encoding='utf-8'), original)

    def test_host_import_is_once_only_and_clearing_does_not_restore_old_ip(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            binary = root / 'bin' / 'coreelec-ng'
            binary.mkdir(parents=True)
            native = binary / 'moonlight.conf'
            original = '[Moonlight]\naddress = 10.0.0.59\n'
            native.write_text(original, encoding='utf-8')
            values = {
                'host_addr': '', 'host_addr_initialized': 'false',
                'resolution': '1280x720',
            }

            class Settings:
                def getSetting(self, key):
                    return values.get(key, '')

                def getSettingInt(self, key):
                    return 10

                def setSettingString(self, key, value):
                    values[key] = value

                def setSettingBool(self, key, value):
                    values[key] = 'true' if value else 'false'

            addon = types.SimpleNamespace(getAddonInfo=lambda key: str(root))
            with mock.patch('xbmcaddon.Addon', return_value=addon, create=True), \
                 mock.patch.object(ConfigHelper, '_find_binary',
                                   return_value=str(binary) + os.sep):
                helper = ConfigHelper(Settings(), mock.Mock())
                self.assertEqual(helper.config['host_addr'], '10.0.0.59')
                self.assertEqual(values['host_addr'], '10.0.0.59')
                self.assertEqual(values['host_addr_initialized'], 'true')
                self.assertEqual(native.read_text(), original)

                # Returning from Kodi's settings dialog with an empty value
                # is a deliberate removal, not a request to import again.
                values['host_addr'] = ''
                helper.configure(dump=False)
                self.assertEqual(helper.config['host_addr'], '')
                self.assertEqual(values['host_addr'], '')
                self.assertEqual(native.read_text(), original)

                values['host_addr'] = '10.0.0.60'
                helper.configure(dump=False)
                self.assertEqual(helper.config['host_addr'], '10.0.0.60')
                self.assertEqual(values['host_addr'], '10.0.0.60')

    def test_default_section_cannot_supply_sunshine_host(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            binary = root / 'bin' / 'coreelec-ng'
            binary.mkdir(parents=True)
            config = binary / 'moonlight.conf'
            config.write_text(
                '[DEFAULT]\naddress = wrong-default-host\n'
                '[Moonlight]\nfps = 60\n',
                encoding='utf-8')
            addon = types.SimpleNamespace(getAddonInfo=lambda key: str(root))
            settings = mock.Mock()
            settings.getSetting.side_effect = lambda key: (
                '1280x720' if key == 'resolution' else ''
            )
            settings.getSettingInt.return_value = 10
            with mock.patch('xbmcaddon.Addon', return_value=addon, create=True), \
                 mock.patch.object(ConfigHelper, '_find_binary',
                                   return_value=str(binary) + os.sep):
                helper = ConfigHelper(settings, mock.Mock())
            self.assertIsNone(helper.config_error)
            self.assertEqual(helper.config['host_addr'], '')
            self.assertIn('wrong-default-host', config.read_text())

    def test_legacy_flat_config_never_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            legacy = (
                '# Old Moonlight configuration\n'
                'address = old-gaming-vm\n'
                'fps = 60\n'
                'bitrate = 10000\n'
            )
            path = Path(helper.config_path)
            path.write_text(legacy, encoding='utf-8')
            with self.assertRaises(MoonlightConfigFormatError) as reason:
                helper._dump_conf()
            self.assertIn('missing [Moonlight] section', reason.exception.reason)
            self.assertIn('has NOT been changed',
                          reason.exception.recovery_message())
            self.assertIn(str(path), reason.exception.recovery_message())
            self.assertEqual(path.read_text(encoding='utf-8'), legacy)
            self.assertFalse(list(Path(td).glob('.luna-config-*')))

    def test_legacy_flat_config_rejected_even_with_saved_kodi_host(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            binary = root / 'bin' / 'coreelec-ng'
            binary.mkdir(parents=True)
            config = binary / 'moonlight.conf'
            content = 'address = legacy-host\nwidth = 1280\n'
            config.write_text(content, encoding='utf-8')
            addon = types.SimpleNamespace(getAddonInfo=lambda key: str(root))
            settings = mock.Mock()
            settings.getSetting.side_effect = lambda name: (
                'new-kodi-host' if name == 'host_addr' else
                '1280x720' if name == 'resolution' else ''
            )
            settings.getSettingInt.return_value = 10
            with mock.patch('xbmcaddon.Addon', return_value=addon, create=True), \
                 mock.patch.object(ConfigHelper, '_find_binary',
                                   return_value=str(binary) + os.sep):
                helper = ConfigHelper(settings, mock.Mock())
            self.assertIsInstance(helper.config_error, MoonlightConfigFormatError)
            self.assertEqual(helper.config['host_addr'], 'new-kodi-host')
            self.assertEqual(config.read_text(encoding='utf-8'), content)
            with mock.patch.object(ConfigHelper, '_find_binary',
                                   return_value=str(binary) + os.sep):
                with self.assertRaises(MoonlightConfigFormatError):
                    helper.configure(dump=False)
                with self.assertRaises(MoonlightConfigFormatError):
                    helper.configure(dump=True)
            self.assertEqual(config.read_text(encoding='utf-8'), content)
            self.assertFalse(list(binary.glob('.luna-config-*')))

    def test_valid_sectioned_config_recovery_and_platform_independent_reader(self):
        for platform in ('CoreELEC21', 'CoreELEC22'):
            with self.subTest(platform=platform), tempfile.TemporaryDirectory() as td:
                helper = ConfigHelper.__new__(ConfigHelper)
                helper.config_path = str(Path(td) / 'moonlight.conf')
                Path(helper.config_path).write_text(
                    '# Existing config\n'
                    '[Other]\naddress = wrong-host\n'
                    '[Moonlight]\naddress = fe80::a%eth0\n'
                    'fps = 60\n', encoding='utf-8')
                parsed = helper._read_sectioned_conf()
                self.assertEqual(parsed.get('Moonlight', 'address'),
                                 'fe80::a%eth0')
                self.assertEqual(parsed.get('Other', 'address'), 'wrong-host')

    def test_malformed_sectioned_file_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            bad = '[Moonlight]\naddress = real-host\n??? broken option\n'
            path = Path(helper.config_path)
            path.write_text(bad)
            with self.assertRaisesRegex(MoonlightConfigFormatError,
                                        'malformed|unknown'):
                helper._read_sectioned_conf()
            self.assertEqual(path.read_text(), bad)


    def test_linux_native_config_syntax_refuses_ambiguous_rewrite(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            for invalid in (
                    '[Moonlight]\naddress: other-vm\n',
                    '[Moonlight]\naddress = other-vm\n  alternate-value\n',
                    '[Moonlight]\nAddress = other-vm\n',
                    '[Moonlight]\naddress = other-vm\nunknown = option\n',
                    '[Moonlight]\naddress = other-vm\n codec = h264\n',
                    '[moonlight]\naddress = other-vm\n',
                    '[Moonlight]\naddress = other-vm\ncodec = nonsense\n',
                    '[Moonlight]\naddress = other-vm\nfps = 0\n',
                    '[Moonlight]\naddress = other-vm\ninput = \n',
                    '[Moonlight]\naddress = other-vm\nsave = overwritten.conf\n',
                    '[Moonlight] extra-suffix\naddress = other-vm\n',
                    '[Moonlight]\naddress = other-vm\rmalformed\n'):
                with self.subTest(data=invalid):
                    path = Path(helper.config_path)
                    path.write_bytes(invalid.encode('utf-8'))
                    with self.assertRaises(MoonlightConfigFormatError):
                        helper._read_sectioned_conf()
                    self.assertEqual(path.read_bytes(), invalid.encode('utf-8'))

    def test_recovery_does_not_open_symlink_fifo_or_directory(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            path = Path(helper.config_path)
            other = Path(td) / 'sensitive.ini'
            other.write_text('[Moonlight]\naddress = unexpected\n')
            path.symlink_to(other)
            with self.assertRaises(MoonlightConfigFormatError):
                helper._read_sectioned_conf()
            self.assertEqual(other.read_text(), '[Moonlight]\naddress = unexpected\n')
            path.unlink()
            if hasattr(os, 'mkfifo'):
                os.mkfifo(path)
                with self.assertRaises(MoonlightConfigFormatError):
                    helper._read_sectioned_conf()
                path.unlink()
            path.mkdir()
            with self.assertRaises(MoonlightConfigFormatError):
                helper._read_sectioned_conf()

    def test_existing_config_rejects_oversize_and_embedded_controls(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            path = Path(helper.config_path)
            for raw in (
                    b'[Moonlight]\naddress = host\n\x00\n',
                    b'[Moonlight]\naddress = host\n\x1b\n',
                    b'[Moonlight]\naddress = host\n' + b'#' * (1024 * 1024)):
                path.write_bytes(raw)
                with self.assertRaises(MoonlightConfigFormatError):
                    helper._read_sectioned_conf()
                self.assertEqual(path.read_bytes(), raw)

    def test_fresh_missing_configuration_allowed(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            config = helper._read_sectioned_conf()
            self.assertEqual(config.sections(), [])
            self.assertFalse(Path(helper.config_path).exists())

    def test_default_ini_address_does_not_become_snapshot_host(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            helper.config = {'host_addr': ''}
            helper._launch_config_content = (
                '[DEFAULT]\naddress = old-host\n'
                '[Moonlight]\nwidth = 1920\nheight = 1080\nfps = 60\n')
            with self.assertRaisesRegex(ValueError, 'host'):
                helper.create_launch_snapshot()
            self.assertFalse(list(Path(td).glob('.luna-stream-*')))

    def test_snapshot_rejects_thirty_three_explicit_input_nodes(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            helper.config = {'host_addr': 'gaming-vm'}
            helper._launch_config_content = (
                '[Moonlight]\naddress = gaming-vm\n' +
                ''.join('input = /dev/input/event%d\n' % i for i in range(33)))
            with self.assertRaisesRegex(ValueError, '33 input paths'):
                helper.create_launch_snapshot()
            self.assertFalse(list(Path(td).glob('.luna-stream-*')))

    def test_read_only_host_lookup_snapshot_never_uses_stale_shared_address(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            helper.config = {'host_addr': 'sunshine-b'}
            Path(helper.config_path).write_text(
                '[Moonlight]\naddress = sunshine-a\nappid = 22\n')
            snapshot = helper.create_host_lookup_snapshot()
            try:
                self.assertEqual(Path(snapshot).read_text(),
                                 '[Moonlight]\naddress = sunshine-b\n')
                self.assertEqual(os.stat(snapshot).st_mode & 0o777, 0o600)
                self.assertIn('sunshine-a', Path(helper.config_path).read_text())
            finally:
                os.unlink(snapshot)

    def test_failed_config_replace_keeps_original_and_cleans_temporary(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'moonlight.conf'
            path.write_text('[Moonlight]\naddress = old\n')
            with mock.patch('resources.lib.util.confighelper.os.replace',
                            side_effect=OSError('injected replace failure')):
                with self.assertRaises(OSError):
                    ConfigHelper._atomic_config_write(
                        str(path), '[Moonlight]\naddress = new\n')
            self.assertIn('address = old', path.read_text())
            self.assertFalse(list(Path(td).glob('.luna-config-*')))

    def test_snapshot_writer_reports_failed_fsync_and_cleans_partial(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            helper._launch_config_content = '[Moonlight]\naddress = host\n'
            with mock.patch('resources.lib.util.confighelper.os.fsync',
                            side_effect=OSError('fsync failed')):
                with self.assertRaises(OSError):
                    helper.create_launch_snapshot()
            self.assertFalse(list(Path(td).glob('.luna-stream-*')))

    def test_repeated_native_inputs_allow_strict_scalar_validation(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            original = ('[Moonlight]\naddress = gaming-vm\n'
                        'input = /dev/input/event1\n'
                        'input = /dev/input/event3\n'
                        '[Other]\nnotes = literal 100%\n')
            Path(helper.config_path).write_text(original)
            parsed = helper._read_sectioned_conf()
            self.assertEqual(parsed.get('Moonlight', 'address'), 'gaming-vm')
            self.assertFalse(parsed.has_option('Moonlight', 'input'))
            self.assertEqual(parsed.get('Other', 'notes'), 'literal 100%')
            self.assertEqual(Path(helper.config_path).read_text(), original)

    def test_duplicate_scalars_or_sections_never_rewritten(self):
        bad = (
            '[Moonlight]\naddress = trusted\naddress = attacker\n',
            '[Moonlight]\nhdr = false\nhdr = true\n',
            '[Moonlight]\naddress = trusted\n[Moonlight]\naddress = other\n',
            '[Moonlight]\ninput = /dev/input/event1\n'
            'input = /dev/input/event2\naddress = trusted\naddress = other\n',
        )
        for content in bad:
            with self.subTest(content=content), tempfile.TemporaryDirectory() as td:
                helper = ConfigHelper.__new__(ConfigHelper)
                helper.config_path = str(Path(td) / 'moonlight.conf')
                path = Path(helper.config_path)
                path.write_text(content)
                with self.assertRaises(MoonlightConfigFormatError):
                    helper._dump_conf()
                self.assertEqual(path.read_text(), content)
                self.assertFalse(list(Path(td).glob('.luna-config-*')))

    def test_excess_inputs_refused_before_rewrite(self):
        with tempfile.TemporaryDirectory() as td:
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.config_path = str(Path(td) / 'moonlight.conf')
            original = '[Moonlight]\naddress = gaming-vm\n' + ''.join(
                'input = /dev/input/event%d\n' % i for i in range(33))
            Path(helper.config_path).write_text(original)
            with self.assertRaisesRegex(MoonlightConfigFormatError, 'input'):
                helper._read_sectioned_conf()
            self.assertEqual(Path(helper.config_path).read_text(), original)


if __name__ == '__main__':
    unittest.main()
