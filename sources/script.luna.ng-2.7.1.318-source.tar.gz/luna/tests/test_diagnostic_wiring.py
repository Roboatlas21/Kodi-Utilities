"""Check manual and early-exit diagnostics use one safe reporting path."""
import ast
import os
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def _extract_function(filename, name, class_name=None):
    tree = ast.parse((ROOT / filename).read_text(encoding='utf-8'))
    nodes = tree.body
    if class_name:
        matches = [item for item in nodes
                   if isinstance(item, ast.ClassDef) and item.name == class_name]
        if len(matches) != 1:
            raise AssertionError('Missing class ' + class_name)
        nodes = matches[0].body
    functions = [item for item in nodes
                 if isinstance(item, ast.FunctionDef) and item.name == name]
    if len(functions) != 1:
        raise AssertionError('Missing function ' + name)
    scope = {}
    exec(compile(ast.Module(body=functions, type_ignores=[]),
                 str(ROOT / filename), 'exec'), scope)
    return scope[name]


class DiagnosticWiringTests(unittest.TestCase):
    def test_legacy_shell_uses_local_python_without_pipe_or_paste(self):
        script = ROOT / 'resources/create_bug_report.sh'
        source = script.read_text()
        self.assertNotIn(' | paste', source)
        self.assertNotIn('bug_report_file', source)
        self.assertIn('diagnosticreport.py', source)
        self.assertIn('--data-dir', source)
        subprocess.run(['sh', '-n', str(script)], check=True)

    def test_both_ui_entrypoints_delegate_to_shared_reporter(self):
        addon = (ROOT / 'addon.py').read_text()
        helper = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text()
        report = (ROOT / 'resources/lib/util/diagnosticreport.py').read_text()
        self.assertIn("?action=diagnostics", addon)
        self.assertIn("elif action == 'diagnostics':", addon)
        self.assertIn('def saveDiagnosticReport():', addon)
        self.assertIn('from resources.lib.util.diagnosticreport import save_report_with_dialog',
                      addon)
        self.assertIn('def _create_local_report(self):', helper)
        self.assertIn('from resources.lib.util.diagnosticreport import save_report_with_dialog',
                      helper)
        self.assertIn('self._create_local_report()', helper)
        self.assertIn('def save_report_with_dialog(', report)
        self.assertNotIn('show_in_kodi(report)', helper)
        self.assertNotIn('def _create_bug_report(', helper)
        self.assertNotIn('paste.coreelec.org', helper)

    def test_no_network_library_in_report_writer(self):
        source = (ROOT / 'resources/lib/util/diagnosticreport.py').read_text()
        for name in ('requests', 'urllib.request', 'http.client',
                     'socket.', 'subprocess.Popen('):
            self.assertNotIn(name, source)

    def test_manual_ui_delegates_and_passes_failure_logger(self):
        action = _extract_function('addon.py', 'saveDiagnosticReport')
        module = types.ModuleType('resources.lib.util.diagnosticreport')
        module.save_report_with_dialog = mock.Mock(return_value=True)
        logger = mock.Mock()
        action.__globals__.update({
            'translatePath': lambda value: '/private/logs',
            'addon_path': '/luna',
            'os': os,
            'logger': logger
        })
        with mock.patch.dict(sys.modules, {
                'resources.lib.util.diagnosticreport': module}):
            self.assertTrue(action())
        call = module.save_report_with_dialog.call_args
        self.assertEqual(call.args, ('/private/logs',))
        self.assertEqual(call.kwargs['kodi_log'], '/private/logs')
        self.assertEqual(call.kwargs['legacy_log'], '/luna/bin/logfile')
        call.kwargs['log_failure']('OSError')
        logger.error.assert_called_once()
        self.assertIn('OSError', logger.error.call_args.args[0])

    def test_early_exit_ui_delegates_and_passes_failure_logger(self):
        action = _extract_function('resources/lib/util/moonlighthelper.py',
                                   '_create_local_report', 'MoonlightHelper')
        module = types.ModuleType('resources.lib.util.diagnosticreport')
        module.save_report_with_dialog = mock.Mock(return_value=False)
        xbmcvfs = types.ModuleType('xbmcvfs')
        xbmcvfs.translatePath = lambda value: '/private/logs'
        logger = mock.Mock()
        helper = types.SimpleNamespace(
            config_helper=types.SimpleNamespace(addon_path='/luna'),
            logger=logger)
        action.__globals__.update({'os': os})
        with mock.patch.dict(sys.modules, {
                'resources.lib.util.diagnosticreport': module,
                'xbmcvfs': xbmcvfs}):
            self.assertFalse(action(helper))
        call = module.save_report_with_dialog.call_args
        self.assertEqual(call.args, ('/private/logs',))
        self.assertEqual(call.kwargs['kodi_log'], '/private/logs')
        self.assertEqual(call.kwargs['legacy_log'], '/luna/bin/logfile')
        call.kwargs['log_failure']('ValueError')
        logger.info.assert_called_once()
        self.assertIn('ValueError', logger.info.call_args.args[0])


if __name__ == '__main__':
    unittest.main()
