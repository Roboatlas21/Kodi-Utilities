"""Behavioral coverage for fallback and persistent artwork recovery."""
import json, socket, struct, tempfile, types, sys, unittest, zlib
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import Mock, patch
import test_host_cache as fixture
sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))
import artwork_service as service
from resources.lib.util import hostresolve, audiodevices, artwork

@contextmanager
def selected_artwork_host(address='a', options=None):
    """Simulate only Kodi's selected host, not a network/status service.

    Use the real canonical identity in artwork_service; mocking that helper
    would hide regressions where a changed port incorrectly refreshes Kodi.
    """
    addon = Mock(getSetting=lambda key: address if key == 'host_addr' else '')
    config = types.SimpleNamespace(
        config_error=None, host_options=lambda: dict(options or {}))
    with patch.object(service.xbmcaddon, 'Addon', return_value=addon, create=True), \
         patch.object(service, 'ConfigHelper', return_value=config), \
         patch.object(service, 'live_host_status_coordinator', return_value=Mock()), \
         patch.object(service.xbmcgui, 'Window', return_value=Mock(), create=True), \
         patch.object(service.xbmc, 'getInfoLabel', return_value='', create=True):
        yield


class ReviewRecoveryTests(unittest.TestCase):
    def test_socket_creation_failure_and_timeout_try_later_address(self):
        answers=[[socket.AF_INET6,socket.SOCK_STREAM,6,'',['::1',1,0,0]],
                 [socket.AF_INET,socket.SOCK_STREAM,6,'',['127.0.0.1',1]]]
        for first in (OSError(97,'family unavailable'), Mock()):
            hostresolve._cache.clear(); second=Mock()
            if not isinstance(first,Exception): first.connect.side_effect=socket.timeout()
            with patch.object(hostresolve.subprocess,'run',return_value=Mock(stdout=json.dumps(answers))), patch.object(hostresolve.socket,'socket',side_effect=[first,second]) as create:
                self.assertIs(hostresolve.connect(('test-host',1)),second)
                self.assertEqual(create.call_count,2)
                if not isinstance(first,Exception): self.assertLessEqual(first.settimeout.call_args.args[0],2)

    def test_layout_capacity_does_not_borrow_card_eld(self):
        for endpoint,wanted,expected in [('surround51:CARD=USB','7.1','5.1'),('surround40:CARD=USB','5.1','false'),('hw:AML,9','7.1','7.1'),('surround71:CARD=USB','7.1','7.1')]:
            self.assertEqual(audiodevices.supported_surround(endpoint,wanted),expected)
        self.assertIsNone(audiodevices.channel_capacity('hw:AML,9'))

    def test_unknown_critical_png_is_rejected(self):
        def chunk(kind):
            data=kind+b'x'
            return struct.pack('>I',1)+data+struct.pack('>I',zlib.crc32(data)&0xffffffff)
        png=fixture.sample_png('one')
        self.assertFalse(artwork.valid_artwork(png[:33]+chunk(b'ABCD')+png[33:]))
        self.assertTrue(artwork.valid_artwork(png[:33]+chunk(b'abCd')+png[33:]))

    def test_interrupted_work_survives_new_job(self):
        with tempfile.TemporaryDirectory() as directory:
            jobs=Path(directory,'artwork-jobs');jobs.mkdir()
            old={'host':'a','ids':['1'],'refresh':True};new={'host':'a','ids':['2'],'refresh':False}
            (jobs/'host.work').write_text(json.dumps(old));(jobs/'host.json').write_text(json.dumps(new))
            monitor=Mock();monitor.abortRequested.return_value=False;monitor.waitForAbort.return_value=True
            processed=[]
            with selected_artwork_host('a'), \
                 patch.object(service.xbmcvfs,'translatePath',return_value=directory,create=True), \
                 patch.object(service.xbmc,'Monitor',return_value=monitor,create=True), \
                 patch.object(service,'process_job',side_effect=lambda p,m:processed.append(json.loads(p.read_text())) or True):
                service.run()
            self.assertEqual(len(processed),1);self.assertEqual(processed[0]['ids'],['1','2']);self.assertTrue(processed[0]['refresh']);self.assertFalse((jobs/'host.json').exists())

    def test_failed_ids_survive_and_success_refreshes_before_later_batch(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory,'job.work');path.write_text(json.dumps({'host':'a','ids':['1','2','3','4']}))
            monitor=Mock();monitor.abortRequested.return_value=False
            fetched=[];refreshed=[]
            def fetch(address,app_id,**kwargs):
                fetched.append(app_id);return None if app_id=='4' else '/image'
            with selected_artwork_host('a'), \
                 patch.object(fixture.MoonlightHelper,'_art_if_present',return_value=None), \
                 patch.object(fixture.MoonlightHelper,'boxart_path',side_effect=fetch), \
                 patch.object(service.xbmc,'getInfoLabel',return_value='script.luna.ng',create=True), \
                 patch.object(service.xbmc,'executebuiltin',side_effect=lambda x:refreshed.append(len(fetched)),create=True):
                self.assertFalse(service.process_job(path,monitor))
            self.assertEqual(refreshed,[3]);retry=json.loads(path.read_text())
            self.assertEqual(retry['ids'],['4']);self.assertEqual(retry['retry_at'],0)
            self.assertEqual(fetched, ['1','2','3'])  # Yield before the next batch.

    def test_stale_connection_cannot_refresh_current_artwork_container(self):
        # Even successful artwork downloads for a different port must not
        # refresh the currently displayed host, despite an identical IP.
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory,'job.work')
            path.write_text(json.dumps({
                'host':'a', 'host_options':{'port':'48089'}, 'ids':['1']}))
            monitor=Mock();monitor.abortRequested.return_value=False
            refreshed=[]
            with selected_artwork_host('a', {'port':'47990'}), \
                 patch.object(fixture.MoonlightHelper,'_art_if_present',return_value=None), \
                 patch.object(fixture.MoonlightHelper,'boxart_path',return_value='/image'), \
                 patch.object(service.xbmc,'getInfoLabel',return_value='script.luna.ng',create=True), \
                 patch.object(service.xbmc,'executebuiltin',side_effect=refreshed.append,create=True):
                self.assertTrue(service.process_job(path,monitor))
            self.assertEqual(refreshed, [])

    def test_thread_exhaustion_retains_work_without_killing_service(self):
        with tempfile.TemporaryDirectory() as directory:
            jobs=Path(directory,'artwork-jobs');jobs.mkdir();path=jobs/'host.work'
            path.write_text(json.dumps({'host':'a','ids':['1']}))
            monitor=Mock();monitor.abortRequested.return_value=False;monitor.waitForAbort.return_value=True
            with selected_artwork_host('a'), \
                 patch.object(service.xbmcvfs,'translatePath',return_value=directory,create=True), \
                 patch.object(service.xbmc,'Monitor',return_value=monitor,create=True), \
                 patch.object(service.concurrent.futures.ThreadPoolExecutor,'submit',side_effect=RuntimeError('thread limit')):
                service.run()
            path=next(jobs.glob('*.work'))
            self.assertEqual(json.loads(path.read_text())['ids'],['1']);self.assertEqual(json.loads(path.read_text())['attempts'],1)

    def test_listing_never_decodes_unvalidated_or_unchanged_png(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory,'image.png');path.write_bytes(fixture.sample_png('one'))
            with patch.object(artwork,'valid_artwork',wraps=artwork.valid_artwork) as decode:
                self.assertFalse(fixture.MoonlightHelper._complete_artwork_file(path,fast_only=True));decode.assert_not_called()
                self.assertTrue(fixture.MoonlightHelper._complete_artwork_file(path))
                with patch('resources.lib.util.moonlighthelper.time.time',return_value=10**12): self.assertTrue(fixture.MoonlightHelper._complete_artwork_file(path,fast_only=True))
                self.assertEqual(decode.call_count,1)
