"""Launch timing must remain observational, with no shortened safety waits."""
import ast
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
LAUNCH = ROOT / 'resources/launchscripts/coreelec/launch.sh'
HELPER = ROOT / 'resources/lib/util/moonlighthelper.py'
RUNTIME = ROOT / 'resources/lib/util/runtimecheck.py'


class LaunchDiagnosticsTests(unittest.TestCase):
    def test_launcher_records_each_independent_phase(self):
        source = LAUNCH.read_text(encoding='utf-8')
        subprocess.run(['sh', '-n', str(LAUNCH)], check=True)
        self.assertIn('luna_monotonic_milliseconds', source)
        self.assertIn('LUNA_LAUNCH_TIMING_V1 source=launcher', source)
        stages = [
            'launcher-preparation', 'watchdog-ready', 'handoff-accepted',
            'kodi-stopped', 'decoder-backend', 'system-tuning',
            'hdmi-mode', 'hdmi-game-mode', 'native-spawn',
            'stream-ready', 'first-video']
        for stage in stages:
            self.assertIn('luna_launch_mark ' + stage, source)
        self.assertEqual(source.count('LUNA_LAUNCH_TIMING=1 "$BIN" stream'), 2)
        self.assertLess(
            source.index('luna_launch_mark stream-ready'),
            source.index('luna_launch_mark first-video'))

    def test_kodi_phases_preserve_intro_and_safety_handoff(self):
        source = HELPER.read_text(encoding='utf-8')
        ast.parse(source)
        self.assertIn('LUNA_LAUNCH_TIMING_V1 source=kodi', source)
        self.assertIn('LUNA_LAUNCH_TIMING_V1 source=runtime', source)
        for stage in ('configuration', 'runtime-validation',
                      'sunshine-app-status', 'stream-profile',
                      'local-transition', 'systemd-handoff'):
            self.assertIn("launch_mark('" + stage + "')", source)
        self.assertIn("if show_intro and not resume_mode:", source)
        self.assertIn("time.sleep(10)", source)
        self.assertIn('LUNA_NG_ACK_WAIT_SECONDS = 6.0', source)
        self.assertIn("stage=systemd-submit", source)
        self.assertIn("stage=handoff-ack", source)

    def test_runtime_validations_are_not_cached(self):
        source = RUNTIME.read_text(encoding='utf-8')
        ast.parse(source)
        for stage in ('manifest', 'file-hashes', 'native-help', 'aml-check'):
            self.assertIn("timing('" + stage + "')", source)
        self.assertIn('for mapping in (objects, assets):', source)
        self.assertIn('[expected, "help"]', source)
        self.assertIn('[expected, "check-aml"]', source)


if __name__ == '__main__':
    unittest.main()
