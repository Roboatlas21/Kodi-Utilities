# Luna — private CoreELEC NG development

Launch Sunshine/GameStream applications directly from Kodi, with Kodi-managed
application lists, artwork, streaming profiles and a protected display handoff.

## Supported target and future platforms

The current private NG package targets **CoreELEC 21 Amlogic-ng ARM32**.
It uses the `resources/launchscripts/coreelec/` systemd launcher, exact
per-session configuration snapshots and a separate Kodi recovery watchdog.

**CoreELEC 22 is planned, not yet implemented or validated.** Launcher routing
is centralized so a future platform can get an explicitly supported handoff
without enabling historical launcher scripts. The older synchronous/audio
handoff is retained in source for compatibility and potential warm-suspend
research; it is not the default NG launch mode.

## Add-on identity and Kodi repository updates

The add-on ID is **`script.luna.ng`**, matching the Kodi Utilities
repository and the installed add-on data directory. The current private
source is version **2.7.1.309**; this is NOT a published release.
The last confirmed public Kodi Utilities feed version is **2.7.1.308**.
A verified ARM32 release must be staged and published in the Kodi Utilities
feed (`addons.xml`, checksum, immutable ZIP and matching GPL sources)
before Kodi can offer an automatic update.

## Complete private GitHub Actions build

The modern build is split between the two **private** source repositories; the
older public `xbmc-p3i/build/luna-ng-snapshot` and `Luna-build` pipelines are
not required.

1. In private `Roboatlas21/moonlight-embedded`, open Actions → **CoreELEC 21 NG ARM32 native build**. Select `feat/coreelec-ng` and run with `build_native=true`, `clean_build=false`. Enable `build_vfm_runtime` only for an experimental VFM build. The workflow runs host checks first and uploads `moonlight-coreelec21-ng-arm32` upon success. Save its numeric Actions run ID.
2. Give the *private Luna* repository a **read-only** Actions secret named `KODI_LUNA_READ_TOKEN`. It must be able to read private `Roboatlas21/moonlight-embedded` repository contents **and Actions artifacts** (fine-grained PAT: repository Contents read and Actions read). A token configured in `Kodi-Utilities-Source` is not automatically available to Luna. Do not give this token write access.
3. Open private `Roboatlas21/Luna` → Actions → **Luna NG private installable build**. Select `feat/vortex-ng` (or use the default `matrix` entrypoint), enter the native run ID, and leave `require_latest_moonlight=true` for a current build. Enable `include_vfm_runtime` only if that *same native run* built VFM.
4. Download the private `luna-ng-<version>` Actions artifact. It contains the installable `script.luna.ng-<version>.zip`, corresponding GPL source archive, SHA256 checksums and exact Luna/Moonlight source lock. Test it on CoreELEC **21 NG ARM32**, not CoreELEC 22 NO ARM64.

The Moonlight and Luna workflows are manual-only for costly compilation and
packaging, respectively. Pushing source does **not** trigger an ARM32 build.
A green host test is not an actual ARM32 compile, and a verified ZIP is not a
successful on-device test. Publishing to the Kodi Utilities feed stays a
**separate explicit operation** in `Kodi-Utilities-Source`; this workflow
cannot publish or alter public repositories.

## Install

Kodi: Settings → Add-ons → Install from zip file.

Use a verified private NG package containing the matching ARM32 Moonlight
runtime; do not install a CoreELEC NO/ARM64 binary on an NG/ARM32 device.
See [Private NG packaging](docs/build-addon-zip.md) for source and runtime checks.

## First launch

1. Open Luna settings and enter the Sunshine host address.
2. Pair the device and enter the displayed PIN on Sunshine.
3. Select an audio output if you need surround sound.

The optional intro video is retained and defaults to OFF. HDMI matching,
frame-pacing and experimental video options are configured through Luna's
settings. A CoreELEC 22 port will require separate runtime and device testing.

## Existing Moonlight configuration recovery

Luna NG generates a sectioned `moonlight.conf` with a `[Moonlight]` section.
This format is shared by CoreELEC 21 and the planned CoreELEC 22 port.
An old, sectionless config (for example, `address = host` without the
header) or a malformed file is **not automatically converted or overwritten**.

If Kodi displays **Moonlight configuration needs repair**:

1. Find `moonlight.conf` at the path displayed in the message. On CoreELEC
   21 NG this is normally
   `/storage/.kodi/addons/script.luna.ng/bin/coreelec-ng/moonlight.conf`.
2. Rename it to `moonlight.conf.backup` through SSH or a file manager; do
   not delete it or copy sensitive contents into a support report.
3. Reopen Luna. The existing Kodi add-on settings and trusted host keys
   are retained; check the Sunshine host in Luna Settings before reconnecting.
   Luna will generate a clean `[Moonlight]` config from Kodi settings.

A normal update of an existing `script.luna.ng` installation using the modern
format requires no migration. The source still preserves the optional intro
and Kodi recovery mechanism.

## Widgets and shortcuts

Kodi and AF3 shortcuts can use Luna's plugin URLs:

- Applications: `plugin://script.luna.ng/?action=apps`
- A folder named Apps: `plugin://script.luna.ng/?action=apps&folder=Apps`
- A folder named PS3: `plugin://script.luna.ng/?action=apps&folder=PS3`

## Credits

- Original add-on: [TheChoconut](https://github.com/TheChoconut/luna)
- Logo and fan art: Ben Bidrava
- Icons and interface refinements: Vortex
- Native streaming: [Moonlight Embedded](https://github.com/moonlight-stream/moonlight-embedded)
