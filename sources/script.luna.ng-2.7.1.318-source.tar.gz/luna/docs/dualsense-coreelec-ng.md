# DualSense and DualSense Edge — automatic enhanced input/audio

Our private CoreELEC NG Moonlight Embedded fork automatically identifies
supported Sony DualSense/Edge USB and Bluetooth controllers. Normal evdev
buttons, sticks and basic FF_RUMBLE remain available if the optional
HIDRAW path cannot be opened. No Luna setting is required.

## Current private source features

- Gyroscope and accelerometer reports, touchpad contacts, battery and RGB
  lightbar control, and adaptive trigger effects.
- Versioned Vibeshine/Vibepollo **48 kHz stereo actuator waveform PCM**
  received through the Nonary moonlight-common-c fork.
- **Bluetooth** waveform actuator playback via the bounded SAxense 142-byte
  raw-HID report path (48 kHz S16LE downsampled to 3 kHz S8 stereo).
- **USB** controller-speaker output and actuator waveforms *only if*
  CoreELEC exposes a four-channel 48 kHz S16LE ALSA endpoint matched to
  the exact physical controller. Speaker audio uses channels 1/2 and
  actuator waveforms use channels 3/4.
- Per-controller owner token, discontinuity and stale-packet checks,
  bounded queues, cleanup and fallback to ordinary rumble.

The updated native source is
`Roboatlas21/moonlight-embedded:feat/coreelec-ng` at
`88cc06902f3a2dda1fe7e60c17399b8ac3b4ab27`.
It uses the Nonary fork of moonlight-common-c; its submodule needs
`git submodule sync --recursive && git submodule update --init --recursive`
in existing clones.

## Important limitations

Neither Bluetooth waveform output nor USB four-channel speaker output has
been tested on an AM6B+ yet. CoreELEC's old kernel may not provide the
required HID report or ALSA endpoint; those capabilities then remain
unavailable. Bluetooth controller-speaker playback is not implemented.

There is still **no Kodi settings toggle**. Legacy `dualsensehid` config
options are removed when Luna writes its next stream configuration.
To troubleshoot raw HID incompatibility, a directly launched native
Moonlight process can set `MOONLIGHT_DUALSENSE_HID=0`.

The Luna source pin at `packaging/moonlight-source-pin.json` remains on
the earlier verified integration baseline. It must not be silently bumped to
the new experimental native revision before a target build and hardware
verification. No installable ZIP or release has been generated here.

## Validation checklist

Test on a spare CoreELEC 21 NG AM6B+: confirm basic gamepad/rumble first,
then Bluetooth waveform packet output, USB four-channel speaker/actuator
routing, two controllers, USB/BT hotplug, host disconnect, regular
Apollo/Sunshine compatibility and reliable Kodi return. Confirm absence of
capability advertisement when an enhanced audio backend is unavailable.

Native protocol design and isolated tests:
`moonlight-embedded/docs/dualsense-pcm-coreelec.md`.
