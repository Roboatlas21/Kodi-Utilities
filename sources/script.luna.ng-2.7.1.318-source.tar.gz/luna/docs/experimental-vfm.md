# Optional ARM32 FFmpeg / VFM prototype

Advanced settings → **Video pipeline** selects either the existing **Amlogic
(standard)** backend (default) or **FFmpeg / VFM (experimental)**.

The prototype requires a Moonlight build with `ENABLE_AML_VFM=ON`, private patched
FFmpeg libraries, a matching `moonlight_vfm.ko`, and compatible stateful V4L2
decoder modules. The kernel module is ARM64; the app and its libraries remain
ARM32. This does not replace CoreELEC, Kodi, or the device tree.

Build instructions and limitations live in Moonlight's
`docs/experimental-vfm.md`. This is source-stage work, not a hardware-validated
release. SDR H.264/HEVC uses NV12; experimental HEVC Main10 HDR10 uses
the original compressed frame and its HDR metadata. The separate HDR toggle
works with either pipeline.
The statistics overlay is allowed with either pipeline;
NG framebuffer graphics requires the updated native Moonlight build.
VFM does not export AML decoder timing counters, so those show n/a.

Package an existing standard native bundle with the optional verified directory:

```sh
python3 packaging/package_ng.py /path/moonlight-coreelec21-ng-arm32.tar.gz \
  --vfm-directory /path/vfm-runtime --output /path/outside/checkout/luna-vfm.zip
```

The optional directory has its own manifest with hashes, ARM32 library checks,
ARM64 module checks, the exact kernel release and module load order. Preflight
checks the bundle and loads the userspace plugin before stopping Kodi. The
independent launcher loads modules after Kodi stops and retains a durable
stock decoder rollback record for the **entire streaming session**. Once
the native process fully exits, launcher cleanup or the independent watchdog
unloads the idle bridge and patched decoder, restores the original stock image
and multiplanar setting, and only then returns Kodi.
If the loader is killed mid-swap or mid-stream, that journal remains armed
until the original decoder is verified and restored.
A failed/unverifiable rollback leaves recovery armed and blocks Kodi restart
until decoder ownership is safe; no forced unload is used.

Bridge version 4 retains the stock decoder activation from version 2 and imports
decoded frames through the existing amvideo display device's DMA configuration.
This addresses the first-frame mapping failure seen with version 2. The launcher
verifies actual V4L2 decoder capabilities and H.264/HEVC/NV12 formats before
starting Moonlight. Version 4 also uses CoreELEC's per-frame freerun flag to
bypass media-clock timestamp gating; this is separate from TV Game Mode/ALLM.
The collector and launcher reject outdated bundled bridges, and the launcher
checks the loaded version again after module setup. Bridge version 6 is required. If an older bridge is
still loaded after updating, Luna asks
for one reboot before stopping Kodi. No decoder modules are forcibly unloaded,
and no installed device tree is changed. DMA mapping, display timing and teardown still need hardware testing.

The launcher and crash-recovery watchdog both accept CoreELEC's decorated tsync
readback (`0: disabled` / `1: enabled`) as well as numeric readback. They write
numeric values and preserve/restore the original state. The observed log already
had tsync disabled; this parsing fix alone is not evidence of a stutter fix.

## Automatic TV Game Mode

Advanced settings → **Automatically request TV Game Mode** is on by default
and can be switched off. An explicitly saved off preference is preserved.
On CoreELEC NG it works with both **Amlogic (standard)** and **FFmpeg / VFM**.
Luna checks HDMI ALLM support, saves the previous HDMI signalling state, and
requests low-latency mode just before launching Moonlight. Normal cleanup and
the independent watchdog restore that state before restarting Kodi, including
failed launches and session crashes. An already-enabled ALLM setting is left
alone. Unsupported displays are skipped without blocking streaming.

The TV must allow automatic game mode. A manually selected picture preset is
controlled by the TV; Luna restores HDMI signalling rather than changing that
preset directly. CoreELEC clears the AVI content hint when ALLM is enabled, so
Luna restores the previous content type as well. HDMI errors are logged to the
session logfile; watchdog errors also appear in the system journal.

A standard package still installs without this directory. Selecting the prototype
then shows a dependency error and leaves Kodi running. It does not silently fall
back to AML. Return the setting to **Amlogic (standard)** to use the existing path.

No GitHub Actions workflow is required to select or locally build this option.

The loader verifies the complete module set and finds a kernel-matched original
`amvdec_ports.ko` before attempting to replace a loaded stock decoder.
Stock-module discovery and crash recovery use the same canonical kernel-module
path allowlist; a path that cannot be safely restored is refused before Kodi
stops. If installation fails, it attempts to release the idle bridge and
restore the original decoder and multiplanar setting. An unverified rollback
is reported explicitly and requires a reboot before another VFM attempt.
There is no force-unload or runtime fallback to the standard AML pipeline.

A resident patched decoder or VFM bridge from an older session without
an active rollback journal now requires a CoreELEC reboot before another
VFM attempt, even when its version and `srcversion` match. Fresh sessions
require a trusted loaded stock decoder and an owned rollback journal before
the module swap. Reboot after installing this change if an earlier test left
the patched decoder or bridge resident. Unverifiable rollback retains the
journal and blocks Kodi restart.

Moonlight connection readiness is separate from first-video progress: AML
signals the first fully accepted compressed unit, while VFM signals its first
accepted decoded frame. Luna waits at most 12 seconds after connection by
default before returning to Kodi if no video data arrives. This does not
guarantee HDMI presentation, and it does not watch further frames after the
first unit. For AML, a separate native guard requests shutdown after a
codec_write has been blocked for 12 seconds, escalating to process exit
after 18 seconds if the vendor driver never returns. Luna's recovery then
restores Kodi. A new native build is necessary to supply this receipt.

VFM crash recovery now reserves 240 seconds for normal cleanup and a
separate recover-only budget that covers the internal restoration deadline
plus recovery-lock wait headroom.

VFM driver installation has its own bounded 60-second timeout by default;
the startup watchdog permits another 20 seconds for Kodi handoff. Native
Moonlight receives a fresh standard 20-second startup deadline once module
setup is complete. An interrupted decoder swap gets a separate bounded
90-second rollback budget; VFM cleanup and the independent recovery watchdog
reserve additional time so they do not kill the rollback halfway through.

## Experimental HDR10

HEVC Main10 now has a separate original-frame import path. See [HDR10](hdr10.md)
for its complete bundle requirements, buffer ownership and device validation
limits. The NV12 DMA-BUF path remains the SDR implementation.

Before Kodi stops, the NG native runtime preflight also requires the explicit
`first-video-ready-v1` capability in its source-attested ARM32 manifest,
checks that the executable and AML decoder library contain the implementation
markers, and verifies the executable advertises the same capability in its
`help` output. An older but otherwise intact native artifact is rejected.
The optional VFM library is independently checked for the matching video
receipt implementation. This requires repackaging with newly built native
artifacts, not only a Luna script update.

A connection that exits before publishing its first video receipt does not
overwrite the confirmed Resume app. During a same-boot recovery, Kodi's handoff
wait respects the watchdog's recovery budget plus lock-acquisition margin
(default 240s per previous session, maximum 360s for an explicitly configured
300s recovery budget), subject to the existing 900s overall cap.

Stock decoder restoration after every VFM session uses exact Kbuild
`srcversion` checks where available, both before stopping Kodi and after
re-inserting the saved module. A differing `srcversion`, or missing metadata outside the narrowly
scoped CoreELEC 21 stock fallback, causes VFM preflight/recovery to fail
closed and retains any outstanding decoder journal.
For the unversioned stock `media_modules-aml/amvdec_ports.ko` on CoreELEC
21 / Linux 4.9, Luna now accepts a narrowly scoped fallback when **both**
module VERSION and srcversion are absent. It requires a trusted kernel-matched
root-owned module path, expected module name/vermagic, a live resident
`amvdec_ports` entry and intact multiplanar parameter. The journal binds
the original on-disk SHA-256 and boot ID, and rollback rechecks this hash
before any module reinsertion. The fallback is **not cryptographic proof**
of already-loaded module bytes: 4.9 does not expose them. It is never
used for patched VFM modules or kernels other than Linux 4.9; metadata
mismatches, unsafe paths, or failed recovery remain hard errors.
Normal AML is unchanged.

All installable Luna NG packages now require the native runtime manifest
and the explicit first-video capability contract. The old
`--allow-legacy-bundle` bypass was removed; older native artifacts must be
rebuilt rather than packaged as seemingly working NG add-ons.


Decoder recovery verifies the loaded stock module's Kbuild
`srcversion` (or the limited CoreELEC 21 unversioned-stock fallback) and
the saved `multiplanar` parameter after restoration. A missing or
mismatched parameter is not silently rewritten while another driver might
own the decoder. The journal stays armed and a reboot/manual inspection
may be required before a new VFM session.

Startup, cleanup, service-stop, and recovery deadlines use monotonic elapsed
seconds from `/proc/uptime`, so NTP/wall-clock adjustments do not shorten or
extend ongoing recovery. New markers carry `mono:` timestamps; existing
epoch-second markers from previous installations remain readable for
one-time recovery of older sessions.
