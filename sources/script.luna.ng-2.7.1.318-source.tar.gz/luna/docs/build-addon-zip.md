# Assemble a CoreELEC 21 NG Luna test ZIP

This combines two independent private repositories **without giving either
repository access to the other's GitHub credentials**.

## Prerequisite: successful native ARM32 build

Download the `moonlight-coreelec21-ng-arm32` artifact from
`Roboatlas21/moonlight-embedded` Actions →
**CoreELEC 21 NG ARM32 native build**. Extract the artifact ZIP. It contains:

- `moonlight-coreelec21-ng-arm32.tar.gz` (native executable + its three
  Moonlight-specific shared libraries).
- `build-info.txt` (ELF/SONAME/DT_NEEDED report).

If the native GitHub Actions run failed or produced no artifact, **stop**.
Do not use Vortex's 64-bit NO package in its place.

## Build the ZIP from your Luna checkout

Check out `Roboatlas21/Luna` branch `feat/vortex-ng` and run:

```sh
# For the current private Moonlight build, create an explicit source pair:
export MOONLIGHT_SHA="$(git -C /path/to/private/moonlight-embedded rev-parse HEAD)"
python3 - <<'PY'
import json, os, subprocess
from pathlib import Path
luna = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
lock = {'schema': 'luna-ng-release-lock-v1',
        'luna_revision': luna, 'moonlight_revision': os.environ['MOONLIGHT_SHA']}
Path('/tmp/luna-ng-release-lock.json').write_text(json.dumps(lock) + '\n')
PY
python3 packaging/package_ng.py \
  /path/to/moonlight-coreelec21-ng-arm32.tar.gz \
  --release-lock /tmp/luna-ng-release-lock.json \
  --output /tmp/script.luna.ng-CoreELEC21-NG-test.zip
```

The Moonlight SHA must be the **same commit recorded in the native bundle's**
verified `runtime-manifest.json`, not simply whichever HEAD is newest.
The Luna SHA must identify the clean checkout being packaged; the packager
verifies the actual Git HEAD and refuses uncommitted edits.

For an immutable Git-less Luna source export, use the separately verified
private VFM assembler (`packaging/coreelec-ng/vfm/package-addon.py` in
Moonlight Embedded). A direct `--release-lock` invocation does **not**
trust a Git-less source directory's self-declared revision.

The packager:

1. Rejects ELF64/AArch64 native files, unexpected archive paths, and
   mismatched native source revisions. Standalone/manual packaging uses
   `packaging/moonlight-source-pin.json` by default. For a new combined build,
   supply `--release-lock /path/to/release-lock.json` with schema
   `luna-ng-release-lock-v1` and the exact full `luna_revision` and
   `moonlight_revision`. The verified pair is recorded inside the final ZIP.
   A local Git checkout's Luna revision is checked automatically; a snapshot
   must be independently verified by the package assembler. This avoids
   circularly updating two moving private HEAD pins.
2. Includes Luna's Python, media, icons, localization, and GPL license.
3. Bundles the executable under `script.luna.ng/bin/coreelec-ng/` and the
   Moonlight-specific libraries under `script.luna.ng/lib/coreelec-ng/`.
4. Preserves the explicit `addon.xml` version (`2.7.1.309` on this private branch) and labels the package as an NG test. Bump the version explicitly before a future update release.
5. Preserves executable permissions for Moonlight and shell scripts.

It intentionally does **not** include CoreELEC's own `libamcodec.so` or
glibc. Those must be supplied by CoreELEC 21 NG.

The resulting ZIP has a `script.luna.ng/` top-level directory and add-on
ID `script.luna.ng`. It upgrades an installed Luna NG add-on with a lower
version while retaining Kodi's add-on settings and existing addon_data path.
This private build is NOT automatically released to the Kodi Utilities feed.

The published Kodi Utilities feed currently lists `2.7.1.308`; the next
source version is `2.7.1.309`. Auto-updates require a verified, matching
ARM32 native bundle plus corresponding GPL source and a higher version in the
public `addons.xml`/checksum. Kodi will not update from an unpublished
private ZIP. Keep the repository enabled and automatic updates configured.

## Checks before installing

```sh
unzip -t /tmp/script.luna.ng-CoreELEC21-NG-test.zip
unzip -l /tmp/script.luna.ng-CoreELEC21-NG-test.zip | grep coreelec-ng
```

A successful cross-build and ZIP check **do not** prove runtime
compatibility. The AM6B+ still needs Sunshine pairing, 1080p60 H.264,
HEVC, audio, input, exit/restart and latency validation per
`docs/am6b-ng-device-tests.md`.

The private `Kodi-Utilities-Source` repository contains the verified
release staging and optional publishing workflow. It keeps native/ frontend
source provenance and updates only Luna NG's own public feed entry.
Do not publish without successful native-build validation and the matching
GPL source archive. GitHub Actions workflows are NOT run by this guide.
