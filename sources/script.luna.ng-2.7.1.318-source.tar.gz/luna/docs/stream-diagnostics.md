# Streaming health logging

Advanced settings → **Enable Moonlight Debug Output** controls health logging
and is off by default. When enabled, Luna records streaming health once per second in its normal session log, including with the
statistics overlay off. It covers AML video submission/decoder queues, transport
packet rates, ALSA callback timing/queue/errors, CPU load and temperature. VFM has
network/audio/system measurements; AML-specific fields show unavailable.

The next add-on release must include the matching verified Moonlight binary.
Changes committed to private sources do not modify the installed version or
the published Kodi Utilities feed.

After a slowdown, exit Moonlight and collect the usual CoreELEC log ZIP. The
current/previous Luna session logs include a timestamped timeline around the
incident. The added rows are limited to one per second (under 8 MiB/hour); other
existing debug/error output is additional. Duplicate OSD text rows are suppressed. Disable debug after collecting a reproduction. There is no additional toggle. Decoder timing summary
and experimental audio resynchronization remain separate settings.

The complete field reference and limitations are in Moonlight's
`docs/stream-diagnostics-coreelec-ng.md`. Missing readings are unavailable rather
than inferred. A log can distinguish likely areas to investigate; it cannot
prove every cause from one counter.

The pinned video library does not populate its recovery/failure/OOS counters.
Those measurements show unavailable instead of misleading zero values.

## Local diagnostic-report privacy

Luna saves private redacted reports and can export a second-scrubbed copy to
the CoreELEC SMB Logfiles share. The redactor recognizes prefixed credential
field names (for example `session_token`, `api_token`, `my_password`),
including short values and XML/JSON and key/value log formats. Sensitive
log lines are withheld as a conservative fallback. Regression tests check
that those values are absent from both private and SMB-readable reports.

No diagnostic process uploads data or sends it to a paste service. The
Logfiles SMB share may be readable by other devices on your LAN. Automated
redaction cannot guarantee safety for arbitrary unstructured secrets; avoid
sharing reports publicly without examining their contents yourself.
