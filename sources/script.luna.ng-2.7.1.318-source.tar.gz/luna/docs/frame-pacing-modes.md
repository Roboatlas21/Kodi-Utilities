# Frame pacing modes (CoreELEC NG)

Luna's Advanced Settings -> Frame Pacing shows **four** modes, in order of
potential queue-related latency:

| UI setting | Environment | Standard AML pipeline | Maximum waiting-frame policy |
| --- | --- | --- | --- |
| Lowest Latency (default) | latency | Direct decoder tunnel | No AMLVIDEO user-space pump |
| Low Latency | low-latency | AMLVIDEO pump | Fixed 1 |
| Adaptive (experimental) | adaptive | AMLVIDEO pump | Dynamically limited to 1..3 |
| Balanced | balanced | AMLVIDEO pump | Fixed 3 |

## Adaptive controller

Adaptive starts with a one-frame limit on every new stream. It compares
consecutive Moonlight-common-c **assembled-frame enqueue intervals** against
the source's presentation timestamp intervals (each clock is used only for
its own deltas). Because enqueue occurs before native decoder submission,
a blocking codec_write does not masquerade as network-arrival jitter.
Out-of-order, discontinuous, source-rate-changing and invalid observations
never count as valid jitter evidence.

Every 2 seconds, after at least 20 eligible observations, growth requires
three late observations making up at least 10% of the eligible sample,
AND a decoded-frame dequeue burst or repeated lack of available decoded
frames while new input arrives. The limit can rise by only one level
(1 -> 2 -> 3), with a 3-second minimum gap between increases.

When the source is stable again, buffering is released one level at a time
after at least 10 seconds without qualifying pressure, plus a 5-second
step cooldown. A stalled or backwards clock resets to the safe 1-frame
target. The policy cannot exceed the existing 3-frame Balanced limit.

The limit is a **maximum waiting-frame cap**, not an allocation or a
guarantee of an extra presentation-delay buffer. Higher limits retain
more decoded frames during bursts but may increase latency. The algorithm
does not change frame timing in the host, DRM, HDMI or the controller path.
Unlike Nonary's desktop VRR pacer, the CoreELEC driver does not expose
exact GPU-ready and display presentation timestamps. Do not claim
equivalent timing or smoother gameplay without device evidence.

**Diagnostics:** the OSD stream header displays Adaptive 1/3, 2/3,
or 3/3 while active. Every level change emits AML_ADAPTIVE_V1 to the
existing session log. No additional stats toggle is required for the
controller to function. No host changes are required.

## Experimental VFM fallback

VFM uses a different pending-frame driver ABI. Choosing Adaptive while
VFM is active uses VFM's existing fixed one-frame pending limit and
prints a clear warning. No driver ABI extension or dynamic VFM
reconfiguration is attempted. Low Latency and Lowest Latency on VFM
still share this same one-frame minimum; Balanced retains two.

## Validation

Existing Low Latency and Balanced behaviors remain unchanged.
Failed QBUF attempts still retain ownership of the dequeued buffer
until the kernel accepts it. Tests cover eligibility, non-reactivity
to single hiccups and source-FPS changes, 1->2->3 growth, recovery,
limits, clock discontinuities and wiring of the fourth Luna option.

Build the private ARM32 Moonlight native client and test on the Ugoos
AM6B+, with identical 4K60 and 1080p120 streams. A/B against the fixed
one- and three-frame modes, watching frame/decoder/sink FPS, real
stuttering, OSD overhead and latency. A mere increase in the waiting
limit does not prove fewer display hitches or a latency improvement.

Luna's packaging/moonlight-source-pin.json remains unchanged until
a deliberately validated native build is selected. No workflows are
required or requested.
