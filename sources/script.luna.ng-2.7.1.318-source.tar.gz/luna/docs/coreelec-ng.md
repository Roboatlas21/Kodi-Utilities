# CoreELEC NG development

This fork is the source-only Kodi launcher for the CoreELEC 21 Moonlight port.

The original TheChoconut Luna source is retained. Vortex's 2026 NO package
(`script.luna-2.7.1.277-f7dc33c8-NO-22.zip`, with internal addon version
2.7.1.279) has been imported for the Kodi UI, settings, app folders, box art
and widget integration. Its compiled AArch64 player is not part of this NG source branch.

## First integration

- Choose native Moonlight based on the architecture of Kodi's Python process.
  Do not assume `uname -m` tells us whether userspace is 32-bit.
- Prefer `bin/coreelec-ng/moonlight` on 32-bit NG and
  `bin/coreelec-no/moonlight` on 64-bit NO.
- Reject an ELF executable with the wrong bitness rather than trying to run it.
- Use the chosen path for pairing, listing, quitting and launching sessions.
- Include the corresponding private library directory in `LD_LIBRARY_PATH`.
- Resume Kodi on normal exits and catchable signals, even on a failed launch.

## Status

This branch currently contains no compiled NG binary and is **not** an
installable, working NG distribution yet. A package assembler exists at
`packaging/package_ng.py`. The exact C decoder modifications are not
recoverable from the ZIP alone. The native fork has an optional,
diagnostic-only `MOONLIGHT_AML_PROFILE=1` timing summary.
In Luna, turn on Advanced → Log Amlogic decoder timing for the next stream,
and turn it off for input-to-display latency benchmarks.

## Validation

- [ ] Verify NG 32-bit executable selection on-device
- [ ] Verify NO 64-bit executable selection on-device
- [ ] Pair with Sunshine and stream 1080p60
- [ ] Test Kodi restoration after normal exit, crash and SIGTERM
- [ ] Test audio + input before repackaging

## VFM/HEVC experimental diagnostics

On a test AM6B+ installation only, Luna now exposes three independent
controls in Advanced/Expert settings. All three default to OFF.

- **Probe Amlogic pipeline (read only)** — records the current kernel VFM
  default chain and HEVC module parameters when starting Moonlight.
- **Experimental HEVC decoder tuning** — writes the two guarded HEVC values
  only for HEVC streams, if the NG kernel reports exactly the known defaults.
- **Experimental direct VFM video route** — switches the idle default chain
  from `decoder amvideo` to a direct H.264 or HEVC provider. It refuses
  unexpected or active VFM routes.

The native source checks for an exact match, and tries to restore original
values after normal exit. SIGKILL, power loss and system crashes prevent
guaranteed restoration of global kernel settings. Keep the two experimental
controls OFF on your primary CoreELEC installation.

See `Roboatlas21/moonlight-embedded:docs/vfm-hevc-experiments.md` for
the kernel evidence, expected values, failure recovery, and benchmark matrix.

No feature parity or end-to-end latency result is implied.

## NG launcher and packaging audit

The default `coreelec/launch.sh` now uses `#!/bin/sh`, and
`test_launch.sh` executes the script directly, validating the shebang
and executable permission rather than masking a bad interpreter.

The NG test ZIP includes only the `resources/launchscripts/coreelec`
launcher. Obsolete USB-reset launch presets have been deleted from the
active source; saved legacy launcher choices are ignored. The safe launcher
resolver can be extended for a separately validated CoreELEC 22 target.

Luna NG requires a sectioned `moonlight.conf`. The parser will not read an
old sectionless host address, and the writer rejects it without changing the
file. Kodi shows a recovery dialog: rename the old config to a backup and
reopen Luna, which generates the standard `[Moonlight]` section using saved
Kodi settings. This contract is platform-independent; it is not a claim that
the CoreELEC 22 native port is already supported.

The source-only fixes do not establish ARM32 playback or Kodi return
under crashes; actual NG device validation remains necessary.

### Stream setup failure status

Moonlight now returns a nonzero process status when `LiStartConnection()`
fails instead of falling through to a successful process exit. The NG launcher
preserves that exact child status, records when Moonlight exits before the
post-connection ready marker, and restores Kodi and session-scoped system state
through the existing cleanup path.

### Confirmed Resume state

Luna no longer writes `last_run` before preflight or service handoff. On
CoreELEC NG, the independent launcher updates Kodi's `last_run` setting only
after Moonlight publishes the post-`LiStartConnection()` ready marker. Failed
preflight, failed systemd dispatch, connection failure and startup timeout leave
the previous Resume entry unchanged. Other launchers update `last_run` only
after a zero exit status. Explicit Resume launches keep the existing value.

### Balanced pacing buffer ownership

The standard AML balanced-pacing mode now requires a Moonlight build that only
advances its local amlvideo ring after `VIDIOC_QBUF` succeeds. A failed kernel
requeue keeps the dequeued buffer owned by Moonlight for a later retry instead of
silently shrinking the capture-buffer pool for the rest of the session. With
Moonlight debug output enabled, interval diagnostics expose these attempts as
`QBufFail`. Luna continues to pass `MOONLIGHT_FRAME_PACING=balanced` unchanged;
the fix itself is in the native Moonlight branch and therefore requires the next
native package.

## Persisted Moonlight device identity

Luna's direct HTTPS helper reads `uniqueid.dat` with the same 16-byte
hexadecimal identity semantics as native Moonlight. A valid persisted ID is
reused. Missing, truncated, malformed or unreadable IDs are explicit errors,
not an invitation to reuse the historic shared `0123456789ABCDEF` identity.
Start native Moonlight to initialize a random per-device ID, then pair that
identity with Sunshine before using Luna's HTTPS application-list or artwork
requests.

## Kodi add-on path normalization

Kodi may return the add-on installation directory with or without a
trailing path separator. `ConfigHelper` now normalizes it once during
initialization; otherwise the existing path concatenations for
`resources/launchscripts`, the intro video, and a fallback configuration
path could incorrectly target `script.lunaresources/...`. Tests cover
both Kodi path styles.

## Native runtime manifest contract

New CoreELEC NG packages now require `runtime-manifest.json` in the
native ARM32 tarball. The packager verifies the manifest's target, ABI,
per-object SHA-256/size, expected SONAMEs, declared dependencies and
dynamic linker path against the actual included native bytes. This
prevents silently combining an old Pannal library with a newer Moonlight
player or accidentally packing an AArch64 executable.

For an earlier build with no manifest, `--allow-legacy-bundle` permits
**explicit** ELF-only test packaging; it is not the default and offers
weaker provenance checks. The collector and packager agree on the
four private objects. Their remaining `external_needed` libraries
must still be verified against the actual CoreELEC 21 device; manifest
validation alone does not establish that the runtime loader can find them.

## Controller database included in NG package

The native artifact now includes and hashes the pinned
`bin/coreelec-ng/gamecontrollerdb.txt` file. Moonlight's default
`get_path()` checks the working directory first, and Luna executes
Moonlight from its architecture-specific `bin/coreelec-ng/` directory.
Without this asset, the standalone ZIP could fail to initialize evdev
mappings on a box that does not have the OS-wide SDL database installed.
The manifest validates both the input data and the four ELF objects.

Vortex's Amlogic module is loaded through `dlopen` and may depend
directly on `libamcodec.so` without an additional `libgamestream`
DT_NEEDED edge. Both native and Luna validators correctly permit this,
while preserving strict SONAME, SHA-256 and executable dependency checks.
## Statistics panel measurements

The OSD setting includes negotiated stream/audio details, measured video and
audio bitrate, host-interface receive Mbps and receive errors/drops, frame-number
gaps and estimated duration, queue-duration estimate, pool usage/peak, separate
ICMP ping/jitter, aggregate CPU usage and Mali GPU utilization. Temperature can
fall back to thermal zones 1–4 and identifies the zone used. Existing detailed
decoder/network counters remain below these rows.

GPU percentage comes from NG's `/sys/class/mpgpu/utilization`; it is GPU
activity, not video-decoder utilization. Hardware decode time and frame-budget
percentage use the pinned standard AML decoder's QoS interface on Linux
4.9.269. VFM and other unsupported decoder timing sources show `n/a`, as do
missing GPU readings and blocked ICMP. NIC receive traffic includes other
traffic on that interface, and frame gaps are not a packet-loss percentage.

These additions require a native build from `packaging/moonlight-source-pin.json`.
Updating the add-on's Python files alone does not upgrade an installed binary.
See the private Moonlight repository's `docs/osd-telemetry.md` for units, source
references, limitations and local validation. Device validation remains pending;
this source change does not start GitHub workflows or publish a release.

## Optional Windows host hardware metrics

Our private Moonlight Embedded client now reads Vibeshine/Vibepollo's optional
read-only hardware metrics endpoint while the Statistics overlay is enabled.
It shows a separate Host row for CPU, GPU, GPU encoder, temperature, and VRAM
where available, without changing the usual local CoreELEC CPU/GPU readings.

**Regular Sunshine and Apollo remain fully compatible.** They do not currently
provide this API, so host CPU/GPU are shown as unavailable; ordinary video,
audio, controllers, and the existing OSD statistics are unaffected. The
collector uses the paired HTTPS certificate and pinned host public key,
requests infrequently on a separate worker, and stops probing unsupported
hosts. The host must offer and enable its telemetry API to show real Windows
hardware utilization; the client does not make up values.

This is in the native source branch only. Luna's currently pinned Moonlight
binary source has not been advanced or rebuilt, and AM6B+ validation remains
pending. See the native client's docs/host-hardware-metrics-coreelec.md.


The optional fourth **Adaptive** pacing mode is detailed in
`docs/frame-pacing-modes.md`. It is a conservative AMLVIDEO queue-limit
experiment; it does not modify the direct tunnel, and VFM retains a
fixed one-frame queue when Adaptive is selected.

## Client frametime graph

Luna's existing Advanced -> Statistics overlay -> Show frametime graph
toggle remains optional and OFF by default. It passes the same -frametime
OSD argument and requires no new menu or host-side feature.

The 240-sample display now separates two different measurements:

- **Green / IN:** spacing between assembled-frame arrivals at the native
  Moonlight decoder callback.
- **Magenta / SUB:** wall time spent inside decoder submission, including
  possible codec-write backpressure (NOT hardware decoder execution time).

The gray dashed reference is requested frame cadence (16.7 ms for 60 FPS;
8.3 ms for 120 FPS). Each lane has a labeled millisecond axis, percentiles
(A average, 95/P95, 99/P99, W worst) and clipped-outlier markers.
The top lane also indicates frame-number gaps (GAP/LOST); the bottom lane
counts callback durations above one and two frame budgets (H1/H2, with
a 1 ms tolerance). These are diagnostics, not confirmed network loss or
physical display hitches.

The existing OSD statistics list decoder/sink frame rates, queue state
and kernel drops independently. The AM6B+ driver still has no verified
per-frame HDMI display-event timestamps, so the graph does not claim to
measure television presentation time or input-to-photon latency.

The chart refreshes at most four times a second, independently of
sysfs/network sampling. It is hidden if the display panel cannot fit,
without losing normal OSD statistics. Disable the overlay for controlled
latency comparisons.

See the native Moonlight docs/frametime-analysis.md. Luna's packaged
native source pin remains unchanged; a new ARM32 build and AM6B+
testing are required before this appears on an installed Kodi box.
