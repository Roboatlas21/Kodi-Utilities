# Unified Luna NG native build handoff

Luna's **Unified Luna NG build** remains the single manual entry point. Native
ARM32 work runs in **Roboatlas21/moonlight-embedded**, preserving that private
repository's existing CoreELEC toolchain and dependency caches. Luna never holds
a runner open to poll Moonlight's build.

## One-time credential requirement

In the **Moonlight private repository** (not Luna), create the GitHub Actions
repository secret `KODI_LUNA_CONTINUATION_TOKEN`. Use a fine-grained personal
access token or GitHub App credential with **Actions: Read and write** permission
on **Roboatlas21/Luna** only. Do not commit the token or print it in logs.

Without this secret, a Luna-correlated Moonlight run fails during `prepare`,
**before** the expensive ARM32 build. Standalone Moonlight runs without a Luna
correlation do not require it.

Luna itself continues using its existing `KODI_LUNA_READ_TOKEN` (Moonlight
Actions read/write and content read) and, for requested publication,
`KODI_UTILITIES_SOURCE_ACTIONS_TOKEN`.

## The one-click flow

1. The manual Luna workflow on `matrix` tests the exact Luna and Moonlight
   source pair once and uploads an immutable `luna-ng-native-request` artifact.
   This artifact records the source revisions, version, and original publish/VFM
   choices.
2. If a verified compatible ARM32 artifact already exists, Luna packages it
   immediately, without compiling.
3. Otherwise Luna dispatches `coreelec-ng-native.yml` into the Moonlight
   repository with the exact source SHA and a unique Luna correlation. The Luna
   selector then finishes, **without waiting or polling**.
4. Moonlight restores its existing ARM32 toolchain and dependency checkpoints,
   validates its source, rebuilds only what changed, and uploads its artifacts.
5. Once Moonlight `prepare` and `native` finish successfully, a separate
   `notify-luna` job dispatches the same `matrix` workflow with the original
   Luna run ID and completed native run ID.
6. The continuation reads the immutable original approval, verifies both
   successful original Luna jobs, checks the exact Moonlight source-stamped
   run and native jobs/artifacts, and packages the approved Luna revision.
   Publication occurs only if the original manual run requested it.

The callback may arrive before Moonlight's notification job has exited.
Packaging allows that short race **only** after authenticating the original
request and confirming the native build and preparation jobs succeeded.

## Failures and recovery

- **Missing callback token:** Moonlight fails early in `prepare`. Add the
  secret; start the one-click Luna build again. No expensive native work ran.
- **Compiler or dependency failure:** Inspect Moonlight's native job. Luna's
  original run cannot complete its package; no public release is attempted.
- **Callback failure after an otherwise successful build:** Use GitHub Actions
  **Re-run failed jobs** on the Moonlight run to retry only `notify-luna`.
  There is no need to rebuild ARM32.
- **Native source changed:** Reuse is blocked unless Luna's conservative
  `native_reuse_policy.py` proves the difference cannot affect compiled
  output. Even a necessary new executable build can restore Moonlight's
  unchanged compiler and dependency caches.
- **Manual Moonlight build:** Uncorrelated standalone native runs still work
  as before and never trigger Luna automatically.

Two additional `matrix` inputs, `resume_luna_run_id` and
`resume_native_run_id`, are reserved for the authenticated completion
callback. Leave both blank for ordinary manual launches.
