# Experimental HDR10 streaming

Streaming settings → **Enable HDR10 (Experimental)** is a separate toggle,
independent of the statistics overlay and off by default.

With either video pipeline selected, enabling HDR requests HEVC Main10,
even if the saved SDR codec is H.264. Turning HDR off restores the saved
SDR codec. The saved codec preference is never overwritten.

**FFmpeg / VFM HDR is experimental.** It uses the decoder's original
compressed 10-bit picture and frame-specific HDR metadata rather than the
8-bit NV12 capture copy. It requires bridge version 6, private FFmpeg's
Main10 integration and the matching `moonlight-hdr1` decoder module in one
complete bundle. These source changes alone do not update an installed box.
After Kodi stops, Luna can replace an idle stock decoder module; a busy
module is never force-unloaded. The original module's path, checksum and
settings are durably journaled before the unload. If installation is interrupted,
Luna's independent watchdog verifies that Moonlight is gone and restores
the stock decoder before Kodi starts. A completed, verified installation
clears that journal and may leave the patched module loaded between games.
If rollback cannot be verified, Kodi restart is deferred instead of hiding
the error; a reboot is the safe recovery. An older loaded bridge requires a reboot.

Enable HDR on the display being streamed by Apollo/Sunshine (including a
virtual display, if used), and use an HDR-capable TV/HDMI connection. HDR
is a request; a host in SDR or a host that cannot provide Main10 may still
produce SDR. Moonlight passes the HEVC stream's colour/SEI metadata to the
Amlogic decoder. CoreELEC's display policy determines HDMI output; Luna
does not force global HDR or Dolby Vision settings.

The updated native player distinguishes `HEVC Main10 negotiated` from
`Host HDR mode: enabled/disabled` in its log. Neither line proves the TV
actually entered HDR. Verify with the TV's signal information, then test
SDR → HDR → Kodi → SDR and repeated AML/VFM switches. In particular check
that colours and Kodi's interface return to normal after exiting.

The setting/config tests run locally. Physical HDR output and recovery
remain unverified until the next native build is tested on the device.
