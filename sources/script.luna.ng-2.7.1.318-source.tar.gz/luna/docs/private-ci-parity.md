# Private Luna / Moonlight CI feature parity

Source of the public design: `Roboatlas21/Luna-build`, especially
`.github/workflows/build-luna-ng.yml` and `scripts/validate-snapshot.sh`.
The public *snapshot checkout* itself is deliberately **not** used in private.

## New unified private entry point

Use `Roboatlas21/Luna` → Actions → **Unified Luna NG build**.
The `matrix` default branch is only the GitHub Actions launcher. The reusable
workflow, checked out Luna source, and Moonlight source remain private:

- Luna: `feat/vortex-ng`
- Moonlight: `feat/coreelec-ng`
- ARM32 native build: `moonlight-embedded/.github/workflows/coreelec-ng-native.yml`

Check **Run all tests without building Moonlight** (the `validate_only`
input) to diagnose failures in a single run **without triggering native
compilation, packaging, or publishing**. With that option unchecked, the
unified workflow validates all groups, reuses a compatible native artifact
when available, otherwise dispatches ARM32 compilation, then packages Luna.

The validated Luna SHA is passed to the Luna packaging workflow as
`luna_ref`. The validated Moonlight SHA is passed to the native workflow
as `native_source_sha`. If Moonlight changes between preflight and
dispatch, the build rejects the unvalidated source instead of silently
switching revisions.

Unified preflight runs the complete Luna Python, launcher, watchdog and
packaging regression groups **once**. Its reusable `build-luna-ng.yml`
packaging job accepts `preflight_validated=true` only from the Unified
workflow and checks the pinned Luna and Moonlight SHAs before skipping the
duplicate test suite. A standalone `build-luna-ng.yml` dispatch still runs
the entire suite by default. The launcher integration script handles
deliberately nonzero mock-process exits in conditional commands so its Bash
`ERR` trap reports only unexpected failures, not normal negative tests.

## One-click update to the Kodi Utilities feed

From **Roboatlas21/Luna → Actions → Unified Luna NG build → Run workflow**,
choose the `matrix` launcher and:

- **Publish to Kodi Utilities**: checked (`publish_to_kodi=true`)
- **Include experimental VFM runtime**: checked for your VFM test build
- **Run all tests without building Moonlight**: unchecked
- **Rebuild Moonlight** and **Bypass native checkpoints**: leave unchecked
  unless you explicitly need a clean build

The single parent workflow now performs this sequence:

1. Verify the private Source Actions token is available.
2. Read the public `Kodi-Utilities/addons.xml`. Use the current Luna source
   version if it is newer; otherwise increment the fourth version component,
   commit the version bump to the private `feat/vortex-ng` branch, and pin
   that source SHA.
3. Run the complete Moonlight/Luna host checks, reuse a valid native/VFM
   artifact or build it, and create the exact installable ZIP plus matching GPL
   source archive.
4. Dispatch the existing manual publishing workflow on
   `Kodi-Utilities-Source/main`. It accepts this in-progress parent **only**
   once the preflight, native-selection and actual package jobs are successful.
5. Re-verify the ZIP/source hashes and VFM source files; stage and push only
   a *new* immutable version to public `Kodi-Utilities/main`, including
   `addons.xml`, its MD5 and matching GPL source archive.
6. Write a private immutable `release-history/luna-ng-<version>.json` receipt
   to `Kodi-Utilities-Source/main`, containing the source SHAs, VFM flag,
   public feed commit and release checksums. The parent reports the Source
   workflow result.

Kodi is **not pushed to over the network** by GitHub. An installed/enabled
`repository.kodi.utilities` with automatic updates enabled picks up the
new version when Kodi next checks its feed. A powered-off box gets it when it
later starts and checks for updates.

### Credentials

- In **Luna** Actions secrets, `KODI_UTILITIES_SOURCE_ACTIONS_TOKEN` needs
  **Actions: Read and write** and **Contents: Read** on the private
  `Roboatlas21/Kodi-Utilities-Source` repository. The existing
  `KODI_LUNA_READ_TOKEN` must still access Moonlight.
- In **Kodi-Utilities-Source**, the existing `KODI_LUNA_READ_TOKEN` must
  read Luna Actions artifacts, and `KODI_UTILITIES_PUBLISH_TOKEN` must be
  able to push to public `Roboatlas21/Kodi-Utilities`.
- Both the launcher on `matrix` and the reusable Luna preflight grant
  `contents:write` to commit a needed version bump. The private Source
  publisher also needs its own `GITHUB_TOKEN` with Contents: Write to
  commit the release-history receipt.

Both release-to-Kodi and the public publisher's `publish` option default to
**off**. The parent aborts if diagnostics-only and publish are selected
together. No other build, push, or diagnostics run publishes to the Kodi feed.

## Public enhancements retained or ported

| Public capability | Private equivalent |
| --- | --- |
| Run every independent check despite other failures | `tests/run_private_host_checks.sh`; `tests/validate_private_source.sh`; `tests/validate_private_source_extras.sh`; `packaging/validate_private.sh` |
| Grouped Moonlight VFM/audio/packaging host checks | Native prepare job plus unified preflight |
| Luna Python/launcher/AML recovery tests | Unified preflight, including `tests/test_aml_recovery.sh` |
| Per-test logs, aggregate table, fail only after collection | Private source checks, native preflight and unified preflight |
| No costly compiler on an ordinary source push | `coreelec-ng-checks.yml`; native job remains manual only |
| Compiled toolchain restored before dependency caches | Private `coreelec-ng-native.yml` |
| Portable host-utility smoke test | Existing `check-host-tools.sh` |
| Toolchain/sysroot/host utility inventory | `packaging/coreelec-ng/toolchain-discovery.py` |
| Single full dependency checkpoint | Private full cache; half checkpoint disabled to reduce duplicate storage |
| Dependency fingerprint independent of Luna packaging | `packaging/coreelec-ng/native-dependency-key.py`, already present |
| Pinned CoreELEC, kernel and media modules | Existing private ARM32 recipe, preserved |
| Build artifact/source integrity verification | Private source locks and native ELF/runtime manifests, preserved |
| Installable archive with optional one-click public feed release | `build-luna-ng.yml` and `publish_to_kodi` on Unified Luna; standalone publishing stays manual |

## Log locations

- Unified preflight: Actions artifact `luna-ng-private-validation-logs`
- Moonlight native preflight: `coreelec-ng-preflight-logs`
- Moonlight source checks: `moonlight-source-validation-logs`
- Native checkpoint inventory: `coreelec-ng-build-logs/toolchain-discovery.json`

Each group writes a TSV results summary plus separate check logs. Any failed
or skipped required group blocks the expensive native job.

The native Moonlight ARM32 and VFM runtime artifacts and the complete Luna
ZIP/source artifacts are configured for 90-day retention, subject to repository
retention limits. The private Luna packaging workflow independently verifies
the exact ELF and VFM runtime before creating the installation ZIP and matching
GPL source archive.

The native reuse policy (`Luna/packaging/native_reuse_policy.py`) permits
reuse across *only* validated Moonlight test/documentation changes. A change
to source code, submodules, build scripts, dependencies, native workflow or an
incomplete GitHub comparison triggers a new native build. The final ZIP's
native SHA always identifies the **actual compiled source**.

The native and unified preflight now both run 21 shared source-only groups from
`Moonlight/tests/validate_private_source_extras.sh` (CEC, ALSA resync,
AML pacing, OSD, DRM and related checks). The same cases are used in the
Moonlight push checks. The unified preflight also sets
`LUNA_PRIVATE_CHECKOUT` so the real cross-repository VFM packaging test runs
rather than silently skipping.


## Deliberate differences

- No public `xbmc-p3i` source snapshot or `Luna-build` dependency.
- No automatic publication on a code push. The **optional** unified
  `publish_to_kodi=true` input chains the Source publisher and public-feed
  push into a single manually approved release run.
- The legacy Kodi Utilities publisher still supports its native-run-ID
  repackaging flow for backwards compatibility. The **new manual**
  `Kodi-Utilities-Source/.github/workflows/publish-unified-luna-ng.yml`
  workflow instead downloads and verifies the exact ZIP, SHA256SUMS and
  corresponding source from a successful Unified Luna run, then stages the
  unmodified archive for the Kodi feed. `publish=false` is the default.
- Experimental VFM packages may also be published to the public
  personal-testing feed when the matching source archive contains the pinned
  VFM patch/build inputs and the existing public FFmpeg/CoreELEC source archive
  parts match that pin. `tools/stage_luna_ng.py` checks these automatically.
  `publish=false` remains the default; no release is automatic.
- The current changes were committed with `[skip ci]` to avoid starting
  more workflows during migration. They require an explicit diagnostics
  run and an end-to-end native build before being considered proven.
