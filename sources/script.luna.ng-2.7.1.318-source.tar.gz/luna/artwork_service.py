"""Kodi-owned artwork worker: directory listing never waits for image requests."""
import concurrent.futures
import threading
import json
import os
import stat
import time
import tempfile
from contextlib import nullcontext
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.util.moonlighthelper import MoonlightHelper
from resources.lib.util.safejson import read_bounded_json
from resources.lib.util.safelock import locked_regular_file
from resources.lib.util.appidentity import canonical_app_id
from resources.lib.util.livehoststatus import ServiceStatusCoordinator, probe_pairing_state
from resources.lib.util.settingsstore import update_settings
from resources.lib.util.confighelper import ConfigHelper
from resources.lib.core.logger import Logger


def _artwork_job_identity(payload):
    """Canonical queue identity, including the saved port and key directory."""
    from resources.lib.util.hostcontext import host_identity, normalize_options
    address = payload.get('host')
    if not isinstance(address, str) or not address:
        raise ValueError('Invalid artwork host identity')
    return host_identity(address, normalize_options(
        payload.get('host_options', {})))


def selected_artwork_identity(config=None):
    """Resolve the user's current connection, not just the address field."""
    from resources.lib.util.hostcontext import host_identity
    addon = xbmcaddon.Addon('script.luna.ng')
    address = (addon.getSetting('host_addr') or '').strip()
    if not address:
        return ''
    context = config or ConfigHelper(addon, Logger())
    # host_options() validates the current native INI on every read. Do not
    # latch ConfigHelper's startup error after the user repairs that file.
    return host_identity(address, context.host_options())


def process_job(path, monitor):
    payload = read_bounded_json(path, 4 * 1024 * 1024)
    address = payload['host']
    ids = payload['ids']
    refresh = payload.get('refresh') is True
    if (not isinstance(address, str) or not address or len(address) > 1024 or
            not isinstance(ids, list) or len(ids) > 20000 or
            any(canonical_app_id(value) != value for value in ids)):
        raise ValueError('Invalid artwork request')
    options = payload.get('host_options', {})
    if (not isinstance(options, dict) or set(options) - {'port', 'keydir'} or
            any(not isinstance(v, str) for v in options.values())):
        raise ValueError('Invalid host context')
    from resources.lib.util.nativeini import validate_and_mask_inputs
    validate_and_mask_inputs('[Moonlight]\n' + ''.join('%s = %s\n' % kv for kv in options.items()))
    helper = MoonlightHelper.__new__(MoonlightHelper)
    from resources.lib.util.hostcontext import normalize_options
    helper._artwork_host_options = normalize_options(options)
    changed = False
    failed = list(payload.get('failed_ids', []))
    if any(canonical_app_id(value) != value for value in failed) or len(failed) > 20000:
        raise ValueError('Invalid failed artwork IDs')
    last_refresh = 0

    def publish(force=False):
        nonlocal changed, last_refresh
        now = time.monotonic()
        if not changed or monitor.abortRequested() or (not force and now - last_refresh < 2):
            return
        try:
            selected_context = selected_artwork_identity()
        except (OSError, ValueError, TypeError, AttributeError):
            selected_context = ''
        if (selected_context == _artwork_job_identity(payload) and
                xbmc.getInfoLabel('Container.PluginName') == 'script.luna.ng'):
            xbmc.executebuiltin('Container.Refresh')
        changed = False
        last_refresh = now

    def fetch(app_id):
        if monitor.abortRequested():
            return None, False
        previous = helper._art_if_present(address, app_id)
        result = helper.boxart_path(address, app_id, refresh=refresh)
        return result, bool(result and (refresh or not previous))

    # A batch has at most three futures; failed IDs alone survive a retry.
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for offset in range(0, min(len(ids), 3), 3):
            if monitor.abortRequested():
                return False
            pending = [(value, pool.submit(fetch, value)) for value in ids[offset:offset + 3]]
            for app_id, future in pending:
                try:
                    result, updated = future.result()
                    changed = updated or changed
                    if not result:
                        failed.append(app_id)
                except Exception:
                    failed.append(app_id)
            publish()
    publish(force=True)
    remaining = ids[3:]
    if remaining or failed:
        payload['ids'] = remaining if remaining else list(dict.fromkeys(failed))
        payload['failed_ids'] = failed if remaining else []
        if remaining:
            payload['retry_at'] = 0
            save_job(path, payload)
        else:
            defer_job(path, payload)
        return False
    return True


ARTWORK_MAX_FAILED_PASSES = 8


def artwork_job_ready(payload, selected_identity, now=None):
    """Only this exact connection may spend workers, not the same IP/other keys."""
    return (_artwork_job_identity(payload) == selected_identity and
            payload.get('suspended') is not True and
            float(payload.get('retry_at', 0)) <=
            (time.time() if now is None else now))


def reactivate_selected_artwork_jobs(jobs, selected_identity):
    """One retry budget when this exact host+port+keydir becomes selected."""
    if not selected_identity:
        return
    for work in sorted(jobs.glob('*.work')):
        try:
            payload = read_bounded_json(work, 4 * 1024 * 1024)
            if (not isinstance(payload, dict) or
                    _artwork_job_identity(payload) != selected_identity or
                    payload.get('suspended') is not True):
                continue
            payload['suspended'] = False
            payload['attempts'] = 0
            payload['retry_at'] = 0
            save_job(work, payload)
        except (OSError, ValueError, TypeError, KeyError):
            pass  # Untrusted jobs are examined by normal compact_jobs.


def defer_job(path, payload=None):
    if payload is None:
        payload = read_bounded_json(path, 4 * 1024 * 1024)
    # Leave the failed IDs available for an explicit retry or host reselect;
    # do not keep pounding an offline host every five minutes forever.
    attempts = min(int(payload.get('attempts', 0)) + 1,
                   ARTWORK_MAX_FAILED_PASSES)
    payload['attempts'] = attempts
    payload['suspended'] = attempts >= ARTWORK_MAX_FAILED_PASSES
    payload['retry_at'] = (0 if payload['suspended'] else
                           time.time() + min(300, 2 ** attempts))
    save_job(path, payload)


def save_job(path, payload):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', dir=path.parent,
                prefix='.retry-', delete=False) as stream:
            temporary = stream.name
            json.dump(payload, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def merge_jobs(old, new):
    """Union generations without letting duplicate retries erase backoff."""
    if old.get('host') != new.get('host') or old.get('host_options', {}) != new.get('host_options', {}):
        raise ValueError('Artwork context mismatch')
    old_ids = list(dict.fromkeys(old['ids'] + old.get('failed_ids', [])))
    new_ids = list(dict.fromkeys(new['ids'] + new.get('failed_ids', [])))
    merged = dict(old)
    upgraded = new.get('refresh') is True and old.get('refresh') is not True
    held = [] if upgraded else old.get('failed_ids', [])
    merged['failed_ids'] = held
    merged['ids'] = list(dict.fromkeys(
        old_ids + new_ids if upgraded else old['ids'] + [i for i in new_ids if i not in held]))
    # Old removed apps must not let an obsolete retry set grow without bound.
    # Retain the newest requested IDs if the host's historical union is larger.
    merged['ids'] = merged['ids'][-20000:]
    merged['failed_ids'] = held[:20000 - len(merged['ids'])]
    merged['refresh'] = old.get('refresh') is True or new.get('refresh') is True
    if old.get('suspended') is True:
        # A fresh queued request happens when a user reopens a host's games
        # or explicitly refreshes its artwork; reuse the preserved failures.
        # Merely ticking the service must never reactivate a suspended job.
        merged['suspended'] = False
        merged['attempts'] = 0
        merged['retry_at'] = 0
    elif upgraded or set(new_ids) - set(old_ids):
        merged['retry_at'] = 0
    return merged


def compact_jobs(jobs):
    """One work file per canonical context, including old UUID generations.

    The worker owns .work files. The producer's stable .json lock serializes
    claims with producer merges; requests arriving during a fetch stay pending.
    """
    from resources.lib.util.hostcontext import host_identity, normalize_options
    for path in sorted(jobs.glob('*.work')) + sorted(jobs.glob('*.json')):
        try:
            with (locked_regular_file(str(path) + '.lock', timeout=0.1)
                  if path.suffix == '.json' else nullcontext()):
                payload = read_bounded_json(path, 4 * 1024 * 1024)
                if not isinstance(payload, dict):
                    raise ValueError('Artwork request must be an object')
                address, ids = payload['host'], payload['ids']
                if (not isinstance(address, str) or not address or len(address) > 1024 or
                        not isinstance(ids, list) or len(ids) > 20000 or
                        any(not isinstance(v, str) or canonical_app_id(v) != v for v in ids)):
                    raise ValueError('Invalid artwork request')
                payload['host_options'] = normalize_options(payload.get('host_options', {}))
                target = jobs / (host_identity(address, payload['host_options']) + '.work')
                if path == target:
                    continue
                try:
                    old = read_bounded_json(target, 4 * 1024 * 1024)
                except (FileNotFoundError, ValueError, TypeError):
                    old = None
                if old is not None:
                    try:
                        payload = merge_jobs(old, payload)
                    except (AttributeError, KeyError, TypeError, ValueError):
                        pass  # Replace damaged old state with the valid request.
                save_job(target, payload)  # Publish union BEFORE removing input.
                path.unlink()
        except (ValueError, TypeError, KeyError):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        except OSError:
            pass  # Retry transient storage failures without discarding work.



def live_host_status_coordinator():
    """Use the existing login service for both Kodi and Luna Settings.

    A single light status ticker is independent of blocking artwork downloads.
    The coordinator allows at most one bounded Sunshine network worker.
    """
    def current_host():
        return xbmcaddon.Addon('script.luna.ng').getSetting('host_addr')

    # One configuration resolver for the service lifetime; host_options()
    # rereads the small native INI on each tick so port/keydir edits affect
    # the generation without starting another network worker.
    context_config = ConfigHelper(xbmcaddon.Addon('script.luna.ng'), Logger())

    def current_identity(address):
        from resources.lib.util.hostcontext import host_identity
        # Re-read validated options instead of latching an earlier parse
        # error: reopening Settings after repairing moonlight.conf must work.
        return host_identity(address, context_config.host_options())

    def settings_open():
        # Kodi 21's CGUIDialogAddonSettings::SetupView publishes Addon.ID
        # on dialog 10140. A generic Window.IsActive alone matches other
        # add-ons and would let Luna overwrite status while they are edited.
        if not xbmc.getCondVisibility('Window.IsActive(addonsettings)'):
            return False
        try:
            return xbmcgui.Window(10140).getProperty('Addon.ID') == 'script.luna.ng'
        except (RuntimeError, TypeError, ValueError):
            return False

    def open_revision():
        # Optional explicit signal from Luna's own settings() entry point.
        # Direct Kodi Settings still works via the dialog Addon.ID property.
        try:
            return xbmcgui.Window(10000).getProperty('Luna.Status.OpenToken')
        except (RuntimeError, TypeError, ValueError):
            return ''

    def read_pending():
        home = xbmcgui.Window(10000)
        token = home.getProperty('Luna.Status.PendingToken')
        completed = home.getProperty('Luna.Status.CompletedToken')
        # Never clear pending fields on completion: a different Settings
        # invocation can update them between separate property operations.
        if not token or token == completed:
            return '', '', ''
        return (token, home.getProperty('Luna.Status.PendingHost'),
                home.getProperty('Luna.Status.PendingContext'))

    def acknowledge_pending(token, address):
        # Acknowledge a completed generation WITHOUT touching either pending
        # field. If Settings published a newer token during this call, that
        # request remains discoverable on the next service tick.
        if token:
            home = xbmcgui.Window(10000)
            if (home.getProperty('Luna.Status.PendingToken') == token and
                    home.getProperty('Luna.Status.PendingHost') == address and
                    home.getProperty('Luna.Status.PendingContext') in
                        ('', current_identity(address))):
                home.setProperty('Luna.Status.CompletedToken', token)

    def prepare_host(address):
        # Kodi addon settings/config are read on the service ticker, never
        # from the network worker that can outlive Kodi service shutdown.
        addon = xbmcaddon.Addon('script.luna.ng')
        logger = Logger()
        config = ConfigHelper(addon, logger)
        if config.config_error is not None:
            raise config.config_error
        return MoonlightHelper(addon, config, logger)._host(address)

    def publish_host_status(address, state):
        if current_host().strip() != address:
            return
        identity = current_identity(address)
        if not settings_open():
            pending_token, pending_host, pending_identity = read_pending()
            if (not pending_token or pending_host != address or
                    (pending_identity and pending_identity != identity)):
                return
        addon = xbmcaddon.Addon('script.luna.ng')
        labels = {
            'unconfigured': addon.getLocalizedString(30324) or 'Not configured',
            'checking': 'Checking pairing...',
            'paired': addon.getLocalizedString(30321) or 'Paired ✓',
            'unpaired': addon.getLocalizedString(30322) or 'Not paired',
            'needs_pin': 'Re-pair to verify Sunshine host identity',
            'identity_changed': 'Sunshine identity changed — verify host and re-pair',
            'unavailable': addon.getLocalizedString(30323) or 'Host unavailable',
        }
        label = labels[state]
        # While checking the SAME host, retain the last verified pairing
        # flag so Repair/Unpair buttons do not flicker. An IP change must
        # never inherit the previous host's pairing state.
        last_verified = (state == 'checking' and
                         addon.getSetting('pair_status_host') == address and
                         addon.getSetting('pair_status_context') == identity and
                         addon.getSetting('paired_state') == 'true')
        values = {
            'pair_status_host': address,
            'pair_status_context': identity,
            'pair_status_display': ('%s — %s' % (address, label) if address else label),
            'paired_state': 'true' if state == 'paired' or last_verified else 'false',
        }
        # Kodi's UI may cache a setting while its modal dialog is open.
        # Use the same atomic on-disk synchronization that Luna's actions do,
        # without altering the user's host_addr or any pairing credentials.
        addon.setSettingString('pair_status_host', values['pair_status_host'])
        addon.setSettingString('pair_status_context', values['pair_status_context'])
        addon.setSettingString('pair_status_display', values['pair_status_display'])
        addon.setSettingBool('paired_state', values['paired_state'] == 'true')
        # While Kodi's Addon Settings modal is open, Kodi owns its live
        # settings cache and eventual dialog save. Writing settings.xml via a
        # second, external transaction here races that modal save. Kodi's API
        # above is the sole live-dialog writer; the verified post-close probe
        # may additionally use our atomic on-disk updater.
        if not settings_open():
            path = xbmcvfs.translatePath(
                'special://profile/addon_data/script.luna.ng/settings.xml')
            update_settings(path, values)

    return ServiceStatusCoordinator(
        current_host, settings_open, probe_pairing_state, publish_host_status,
        log_error=lambda error: xbmc.log(
            'Luna live host status: %s' %
            (error if isinstance(error, str) else type(error).__name__),
            xbmc.LOGWARNING),
        read_revision=open_revision,
        read_identity=current_identity,
        prepare_probe=prepare_host,
        read_pending=read_pending,
        acknowledge_pending=acknowledge_pending,
        # A quick direct-Kodi close/reopen can fall entirely between service
        # polls. Bound stale status to 8 seconds even without an open token.
        refresh_seconds=8)


def _status_tick_with_heartbeat(status, home, label):
    """Only a successfully completed status tick certifies service health.

    Both dedicated ticker and main-loop fallback use the SAME heartbeat.
    Failed ticks invalidate it immediately instead of advertising a live
    coordinator that cannot process pairing-state changes.
    """
    try:
        status.tick()
        home.setProperty('Luna.Status.ServiceHealth', 'ready')
        home.setProperty('Luna.Status.ServiceHeartbeat',
                         str(time.monotonic()))
        return True
    except (OSError, RuntimeError, ValueError) as error:
        try:
            home.clearProperty('Luna.Status.ServiceHeartbeat')
            home.setProperty('Luna.Status.ServiceHealth', 'error')
        except (RuntimeError, TypeError, ValueError):
            pass
        xbmc.log('%s: %s' % (label, type(error).__name__), xbmc.LOGWARNING)
        return False


def _status_shutdown_heartbeat(home):
    if home is None:
        return
    try:
        home.clearProperty('Luna.Status.ServiceHeartbeat')
        home.setProperty('Luna.Status.ServiceHealth', 'stopped')
    except (RuntimeError, TypeError, ValueError):
        pass


def _status_tick_loop(status, monitor, stop_event):
    """Keep lightweight dialog/host-change detection responsive to Kodi."""
    home = xbmcgui.Window(10000)
    try:
        while not stop_event.is_set() and not monitor.abortRequested():
            _status_tick_with_heartbeat(status, home, 'Luna status service tick')
            stop_event.wait(0.2)
    finally:
        _status_shutdown_heartbeat(home)


def _reveal_kodi_gui_when_ready(root, gui_since, service_started,
                                 fb0=Path('/sys/class/graphics/fb0/blank'),
                                 fb1=Path('/sys/class/graphics/fb1/blank')):
    """Release Luna's hidden fb0 only in the fresh Kodi login service.

    The old Kodi page was left in the framebuffer. A new GUI window and one
    event-loop tick allow Kodi to replace it before revealing the OSD. If
    window labels never arrive, the bounded watchdog is a separate fallback.
    No network calls, threads or sleeps are introduced in this service.
    """
    pending = []
    for receipt in root.glob('.luna-session.????????.kodi-reveal'):
        if receipt.is_symlink():
            continue
        try:
            flags = os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0)
            fd = os.open(str(receipt), flags)
            with os.fdopen(fd, 'rb') as handle:
                info = os.fstat(handle.fileno())
                valid = (stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                         and info.st_size == len(b'pending\n')
                         and handle.read(32) == b'pending\n')
            if valid:
                pending.append(receipt)
        except OSError:
            continue
    if not pending:
        return gui_since

    now = time.monotonic()
    try:
        window = (xbmc.getInfoLabel('System.CurrentWindow') or '').strip()
    except (AttributeError, RuntimeError, TypeError, ValueError):
        window = ''
    if window:
        if gui_since is None:
            return now
        if now - gui_since < 0.5:
            return gui_since
    elif now - service_started < 12:
        return None

    try:
        fb0.write_text('0')
        if fb1.exists():
            fb1.write_text('0')
    except OSError as error:
        xbmc.log('LUNA_FB_HANDOFF_V1 phase=kodi-reveal failed=%s' %
                 type(error).__name__, xbmc.LOGWARNING)
        return gui_since

    for receipt in pending:
        try:
            receipt.unlink()
        except OSError:
            pass
    xbmc.log('LUNA_FB_HANDOFF_V1 phase=kodi-reveal source=kodi-service',
             xbmc.LOGINFO)
    return gui_since


def run():
    monitor = xbmc.Monitor()
    root = Path(xbmcvfs.translatePath('special://profile/addon_data/script.luna.ng/'))
    jobs = root / 'artwork-jobs'
    jobs.mkdir(parents=True, exist_ok=True)
    reveal_started = time.monotonic()
    reveal_gui_since = None
    status = live_host_status_coordinator()
    artwork_context_config = ConfigHelper(xbmcaddon.Addon('script.luna.ng'), Logger())
    stop_status = threading.Event()
    status_thread = None
    fallback_home = None
    try:
        with locked_regular_file(str(jobs / 'worker.lock'), timeout=0):
            # One persistent, low-cost ticker; all artwork and network
            # requests run outside it. There is still only one network worker.
            # CoreELEC can refuse thread creation: retain the old synchronous
            # fallback rather than failing the artwork service.
            candidate = threading.Thread(
                target=_status_tick_loop,
                args=(status, monitor, stop_status),
                name='LunaHostStatusTicker', daemon=True)
            try:
                candidate.start()
                status_thread = candidate
            except RuntimeError as error:
                xbmc.log('Luna status ticker unavailable: %s' %
                         type(error).__name__, xbmc.LOGWARNING)
            last_artwork_identity = None
            while not monitor.abortRequested():
                reveal_gui_since = _reveal_kodi_gui_when_ready(
                    root, reveal_gui_since, reveal_started)
                if status_thread is not None and not status_thread.is_alive():
                    # The ticker may die AFTER successful start, e.g. if a
                    # Kodi Window() call fails outside its tick handler.
                    # Never spawn replacement threads on constrained CE21;
                    # move back to the existing main-loop fallback.
                    xbmc.log('Luna status ticker exited; using service-loop fallback',
                             xbmc.LOGWARNING)
                    status_thread = None
                if status_thread is None:
                    if fallback_home is None:
                        try:
                            fallback_home = xbmcgui.Window(10000)
                        except (RuntimeError, TypeError, ValueError):
                            # Status checking remains available without Home
                            # window properties, though the plugin can safely
                            # fall back to its close-time verification.
                            pass
                    if fallback_home is not None:
                        _status_tick_with_heartbeat(
                            status, fallback_home, 'Luna status fallback')
                    else:
                        try:
                            status.tick()
                        except (OSError, RuntimeError, ValueError) as error:
                            xbmc.log('Luna status fallback: %s' %
                                     type(error).__name__, xbmc.LOGWARNING)
                compact_jobs(jobs)
                try:
                    selected_identity = selected_artwork_identity(artwork_context_config)
                except (RuntimeError, OSError, TypeError, ValueError, AttributeError):
                    # Invalid native context cannot authorize an old port's job.
                    selected_identity = ''
                if selected_identity != last_artwork_identity:
                    reactivate_selected_artwork_jobs(jobs, selected_identity)
                    last_artwork_identity = selected_identity
                for work in sorted(jobs.glob('*.work')):
                    if monitor.abortRequested():
                        return
                    try:
                        payload = read_bounded_json(work, 4 * 1024 * 1024)
                        if not isinstance(payload, dict):
                            raise ValueError('Artwork job must be an object')
                        if not artwork_job_ready(payload, selected_identity):
                            continue
                        complete = process_job(work, monitor)
                    except (RuntimeError, OSError):
                        try:
                            defer_job(work)
                        except (OSError, ValueError, TypeError, KeyError):
                            pass
                        complete = False
                    except (ValueError, TypeError, KeyError):
                        complete = True
                    if complete:
                        try:
                            work.unlink(missing_ok=True)
                        except OSError:
                            pass
                if monitor.waitForAbort(1):
                    return
    except TimeoutError:
        pass
    finally:
        stop_status.set()
        status.stop(timeout=0.2)
        if status_thread is not None:
            status_thread.join(timeout=1)
        else:
            _status_shutdown_heartbeat(fallback_home)


if __name__ == '__main__':
    run()
