import os
import stat
import socket
import threading
import tempfile
import io
import time
from contextlib import contextmanager

from resources.lib.util.safefile import read_regular_bytes
from resources.lib.util.hostresolve import connect as bounded_connect
import hashlib
import re

from resources.lib.util.certpin import spki_sha256, CertificatePinError
from resources.lib.util.appidentity import canonical_app_id
from xml.etree import ElementTree
import ssl
import uuid

try:
    import http.client as httplib
except ImportError:
    import httplib

DEFAULT_KEY_DIR = '/storage/.cache/moonlight'
HTTPS_PORT = 47984
HTTP_PORT = 47989
TIMEOUT = 4
MAX_XML_BYTES = 2 * 1024 * 1024
MAX_ART_BYTES = 16 * 1024 * 1024
UNIQUEID_CHARS = 16
_port_hints = {}
_port_hints_lock = threading.Lock()


class _DeadlineRawReader(io.RawIOBase):
    """A buffered HTTPResponse can never reset the absolute socket deadline."""

    def __init__(self, sock, expires):
        super().__init__()
        self._sock = sock
        self._expires = expires
        # socket.makefile() retains a reference to the underlying FD/SSLSocket.
        # http.client closes its Connection immediately for HTTP/1.0 and
        # Connection: close. Without this owner, the response body attempts
        # reads on an already-closed socket and fails with EBADF.
        self._owner = sock.makefile('rb', buffering=0)

    def readable(self):
        return True

    def readinto(self, buffer):
        remaining = self._expires - time.monotonic()
        if remaining <= 0:
            raise socket.timeout('Sunshine response exceeded overall deadline')
        self._sock.settimeout(remaining)
        return self._owner.readinto(buffer)

    def close(self):
        if not self.closed:
            try:
                self._owner.close()
            finally:
                super().close()


class _DeadlineSocket:
    """Connection-local send and read budgeting; no global signals or timer."""

    def __init__(self, sock, expires):
        self._sock = sock
        self._expires = expires

    def _set_remaining(self):
        remaining = self._expires - time.monotonic()
        if remaining <= 0:
            raise socket.timeout('Sunshine response exceeded overall deadline')
        self._sock.settimeout(remaining)

    def sendall(self, data, flags=0):
        payload = memoryview(data)
        while payload:
            self._set_remaining()
            sent = self._sock.send(payload, flags)
            if sent <= 0:
                raise OSError('Sunshine connection closed while sending request')
            payload = payload[sent:]

    def makefile(self, mode='rb', buffering=-1, **kwargs):
        if mode not in ('rb', 'r') or kwargs:
            raise ValueError('Unsupported HTTP response socket mode')
        reader = _DeadlineRawReader(self._sock, self._expires)
        if buffering == 0:
            return reader
        return io.BufferedReader(
            reader, buffer_size=8192 if buffering < 0 else buffering)

    def __getattr__(self, name):
        return getattr(self._sock, name)


@contextmanager
def response_deadline(conn, seconds=8):
    """Bound request transmission, headers and body with ONE monotonic budget.

    Installing the socket wrapper after connect means SSL validation and
    pinning still use the unchanged original socket. The HTTPResponse reader
    gets a deadline-aware makefile, so slow trickling cannot extend the budget
    by triggering fresh per-read socket timeouts. No per-request Python thread
    or signal handler is needed on CoreELEC 21.
    """
    if seconds <= 0:
        raise ValueError('Sunshine response deadline must be positive')
    original = conn.sock
    wrapped = _DeadlineSocket(original, time.monotonic() + seconds)
    conn.sock = wrapped
    try:
        yield
    finally:
        # http.client already sets sock=None when its response will close.
        # Do not resurrect that closed connection or corrupt its lifecycle.
        if conn.sock is wrapped:
            conn.sock = original


class HostError(Exception):
    pass


class HostIdentityError(HostError):
    """Authenticated host public key does not match the saved pairing key."""
    pass


class Host(object):
    def __init__(self, address, key_dir=DEFAULT_KEY_DIR, port=HTTPS_PORT,
                 log=None, http_port=HTTP_PORT, inferred_port=False):
        self.address = address
        self.key_dir = key_dir
        self.port = port
        self.http_port = http_port
        self.inferred_port = inferred_port
        self.log = log or (lambda msg: None)
        self._ctx = None
        self._spki_pin = None
        self._last_pair_status_public = False

    def _pin_path(self):
        endpoint = self.address
        if self.http_port and int(self.http_port) != HTTP_PORT:
            endpoint += '\nport=%d' % int(self.http_port)
        identity = hashlib.sha256(endpoint.encode('utf-8')).hexdigest()
        return os.path.join(self.key_dir, 'server-%s.pem' % identity)

    def has_trusted_pin(self):
        # Existence alone is not authentication. _get() validates the peer
        # public key against the saved certificate before sending a request.
        return os.path.lexists(self._pin_path())

    def _context(self):
        if self._ctx is not None:
            return self._ctx

        cert = os.path.join(self.key_dir, 'client.pem')
        key = os.path.join(self.key_dir, 'key.pem')
        if not os.path.exists(cert) or not os.path.exists(key):
            raise HostError('no pairing keys in %s' % self.key_dir)

        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        # Native Moonlight pins SHA-256 of DER SubjectPublicKeyInfo, NOT the
        # complete certificate. Verify the same public key after TLS connect
        # and BEFORE sending an authenticated request. This permits a
        # renewed self-signed cert retaining its original paired key.
        pinned = self._pin_path()
        self._spki_pin = None
        if os.path.lexists(pinned):
            try:
                # Read the *opened* inode once: a renamed certificate,
                # symlink, FIFO or growing file cannot bypass the 8-KiB limit.
                raw, _ = read_regular_bytes(pinned, 8192)
                if not raw or b'\x00' in raw:
                    raise HostIdentityError('Saved Sunshine certificate is invalid')
                pem = raw.decode('ascii')
                self._spki_pin = spki_sha256(ssl.PEM_cert_to_DER_cert(pem))
            except (OSError, UnicodeError, ValueError, CertificatePinError) as error:
                raise HostIdentityError(
                    'Saved Sunshine host certificate is invalid') from error
        # The handshake permits Sunshine's self-signed certificate; our
        # explicit SPKI check below supplies server identity authentication.
        # Existing hosts without a trusted pin retain legacy behavior.
        ctx.verify_mode = ssl.CERT_NONE
        try:
            cert_bytes, cert_stat = read_regular_bytes(cert, 8192)
            key_bytes, key_stat = read_regular_bytes(key, 32768)
            if cert_stat.st_uid != os.geteuid() or key_stat.st_uid != os.geteuid():
                raise ValueError('Pairing credentials must be owned by this user')
            # SSL accepts paths, not PEM bytes. Private copies ensure it reads
            # exactly the bounded, validated files, never a replaced source.
            # Anonymous copies also disappear if the process is killed.
            with tempfile.TemporaryFile() as cert_copy, tempfile.TemporaryFile() as key_copy:
                for copy, data in ((cert_copy, cert_bytes), (key_copy, key_bytes)):
                    copy.write(data)
                    copy.flush()
                def no_password():
                    raise HostError('Encrypted client keys are unsupported')
                ctx.load_cert_chain('/proc/self/fd/%d' % cert_copy.fileno(),
                                    '/proc/self/fd/%d' % key_copy.fileno(),
                                    password=no_password)
        except (OSError, ValueError) as error:
            raise HostError('Cannot safely load pairing credentials') from error
        try:
            ctx.set_ciphers('DEFAULT:@SECLEVEL=0')
        except ssl.SSLError:
            pass

        self._ctx = ctx
        return ctx

    def _unique_id(self):
        path = os.path.join(self.key_dir, 'uniqueid.dat')
        try:
            # Native Moonlight uses exactly the first 16 hexadecimal bytes.
            # Do not masquerade as the default identity when an existing
            # pairing file is corrupt, unreadable or has an invalid encoding.
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW |
                         os.O_NONBLOCK | os.O_CLOEXEC)
            with os.fdopen(fd, 'rb') as f:
                info = os.fstat(f.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid():
                    raise HostError('Existing Moonlight device ID is not an owned regular file')
                value = f.read(UNIQUEID_CHARS)
        except FileNotFoundError:
            if os.path.lexists(path):
                raise HostError('Existing Moonlight device ID is inaccessible')
            # The native client owns ID initialization and persists a random
            # per-device identity. Inventing the historic shared ID here
            # risks making Python requests refer to a different paired client.
            raise HostError(
                'Moonlight device ID is missing. Start native Moonlight to '
                'initialize a new identity, then pair this device again; '
                'do not restore a shared default ID.')
        except OSError as error:
            raise HostError('Cannot read Moonlight device ID') from error
        if (len(value) != UNIQUEID_CHARS or
                any(byte not in b'0123456789abcdefABCDEF' for byte in value)):
            raise HostError('Existing Moonlight device ID is corrupt or truncated')
        return value.decode('ascii')

    def _advertised_https_port(self):
        """Use public discovery only to locate TLS, never to establish trust.

        A public /serverinfo response is untrusted. The subsequent HTTPS
        connection MUST still match the previously paired SPKI before any
        authenticated request is sent.
        """
        try:
            root = ElementTree.fromstring(self._get_public_serverinfo())
            if root.attrib.get('status_code') != '200':
                return None
            raw = (root.findtext('.//HttpsPort') or '').strip()
            if not re.fullmatch(r'[0-9]{1,5}', raw):
                return None
            port = int(raw)
            return port if 1 <= port <= 65535 else None
        except (OSError, ssl.SSLError, HostError, ElementTree.ParseError,
                TypeError, ValueError):
            return None

    def _get(self, path, params):
        context = self._context()
        # The native PIN handshake is the only permitted unpinned bootstrap.
        if self._spki_pin is None:
            raise HostIdentityError(
                'Sunshine host has no verified certificate; PIN re-pair required')
        query = '&'.join('%s=%s' % (k, v) for k, v in params)
        url = '%s?uniqueid=%s&uuid=%s&%s' % (
            path, self._unique_id(), uuid.uuid4(), query) if query else \
            '%s?uniqueid=%s&uuid=%s' % (path, self._unique_id(), uuid.uuid4())

        maximum = MAX_ART_BYTES if path == '/appasset' else MAX_XML_BYTES
        hint_key = (self.address, self.http_port, self._spki_pin)
        with _port_hints_lock:
            cached_port = _port_hints.get(hint_key)
        port = cached_port if cached_port is not None else self.port
        # Discovery only locates TLS. It cannot authorize a different key.
        # Do this before contacting a guessed port which may host another service.
        if self.inferred_port and cached_port is None:
            advertised = self._advertised_https_port()
            if advertised is not None:
                port = advertised
        for attempt in range(2):
            conn = httplib.HTTPSConnection(self.address, port,
                                           context=context, timeout=TIMEOUT)
            try:
                try:
                    conn._create_connection = bounded_connect
                    conn.connect()
                except (OSError, ssl.SSLError):
                    # Nonstandard Sunshine HTTPS ports are advertised over
                    # public HTTP. Retry only a failed TLS connection,
                    # including custom HTTP endpoints. A TLS identity mismatch
                    # never triggers discovery or an HTTP downgrade.
                    with _port_hints_lock:
                        _port_hints.pop(hint_key, None)
                    if attempt == 0:
                        advertised = self._advertised_https_port()
                        if advertised is not None and advertised != port:
                            port = advertised
                            continue
                    raise
                peer = conn.sock.getpeercert(binary_form=True)
                try:
                    matched = spki_sha256(peer) == self._spki_pin
                except CertificatePinError as error:
                    raise HostIdentityError(
                        'Sunshine presented an invalid certificate') from error
                if not matched:
                    raise HostIdentityError(
                        'Sunshine server public key differs from the paired host')
                with response_deadline(conn):
                    conn.request('GET', url)
                    response = conn.getresponse()
                    body = response.read(maximum + 1)
                if len(body) > maximum:
                    raise HostError('%s response exceeds %s bytes' % (path, maximum))
                if response.status != 200:
                    raise HostError('%s answered with status %s' % (path, response.status))
                # Cache the discovered port only after the pinned HTTPS
                # request actually succeeded.
                self.port = port
                with _port_hints_lock:
                    if len(_port_hints) >= 128:
                        _port_hints.clear()
                    _port_hints[hint_key] = port
                return body
            finally:
                conn.close()

    def _get_public_serverinfo(self):
        """Unauthenticated fallback for the identity whose TLS keys were revoked."""
        path = '/serverinfo'
        url = '%s?uniqueid=%s&uuid=%s' % (
            path, self._unique_id(), uuid.uuid4())
        conn = httplib.HTTPConnection(self.address, self.http_port, timeout=TIMEOUT)
        try:
            conn._create_connection = bounded_connect
            conn.connect()
            with response_deadline(conn):
                conn.request('GET', url)
                response = conn.getresponse()
                body = response.read(MAX_XML_BYTES + 1)
            if len(body) > MAX_XML_BYTES:
                raise HostError('Public serverinfo response exceeds size limit')
            if response.status != 200:
                raise HostError('HTTP pairing verification returned %s' % response.status)
            return body
        finally:
            conn.close()

    @staticmethod
    def parse_applist(body):
        """Parse Sunshine XML without leaking escaped titles into launch names."""
        try:
            root = ElementTree.fromstring(body)
        except (ElementTree.ParseError, TypeError, ValueError) as error:
            raise HostError('Sunshine returned malformed application XML') from error
        status = root.attrib.get('status_code')
        if status != '200':
            raise HostError('Sunshine application request failed (status %s)' % status)
        paired = root.findtext('.//PairStatus')
        if paired is not None and paired.strip() == '0':
            raise HostError('this device is not paired with the host')
        apps = []
        seen = {}
        for app in root.findall('.//App'):
            name = (app.findtext('AppTitle') or '').strip()
            number = (app.findtext('ID') or '').strip()
            if not name:
                raise HostError('Sunshine returned an incomplete application entry')
            try:
                number = canonical_app_id(number)
            except ValueError as error:
                raise HostError('Sunshine returned an invalid application ID') from error
            if number in seen:
                if seen[number] != name:
                    raise HostError('Sunshine returned conflicting application IDs')
                continue
            seen[number] = name
            apps.append((number, name))
        return apps

    def applist(self):
        return self.parse_applist(self._get('/applist', []))

    def has_pairing_keys(self):
        return (os.path.exists(os.path.join(self.key_dir, 'client.pem'))
                and os.path.exists(os.path.join(self.key_dir, 'key.pem')))

    @staticmethod
    def parse_pair_status(body):
        try:
            root = ElementTree.fromstring(body)
        except (ElementTree.ParseError, TypeError, ValueError) as error:
            raise HostError('Sunshine returned malformed pairing status XML') from error
        if root.attrib.get('status_code') != '200':
            raise HostError('Sunshine rejected the pairing status request')
        paired = (root.findtext('.//PairStatus') or '').strip()
        if paired not in ('0', '1'):
            raise HostError('Sunshine did not provide a valid pairing status')
        return paired == '1'

    def pair_status(self, allow_http_fallback=False):
        self._last_pair_status_public = False
        try:
            body = self._get('/serverinfo', [])
        except HostIdentityError:
            # A mismatched trusted key is NOT proof of successful unpair.
            # Never downgrade this security failure to unauthenticated HTTP.
            raise
        except (HostError, OSError, ssl.SSLError):
            if not allow_http_fallback:
                raise
            # Once unpaired, Sunshine may reject our old client certificate.
            # A public serverinfo response still must contain explicit, valid
            # PairStatus=0; unreachable/malformed responses remain errors.
            body = self._get_public_serverinfo()
            self._last_pair_status_public = True
        try:
            return self.parse_pair_status(body)
        except HostError as error:
            # Some servers return an XML authentication rejection with HTTP
            # 200 after revoking the client certificate. Fall back only for
            # that explicit condition, never for malformed or missing data.
            if (not allow_http_fallback or
                    str(error) != 'Sunshine rejected the pairing status request'):
                raise
            public_status = self.parse_pair_status(self._get_public_serverinfo())
            self._last_pair_status_public = True
            return public_status

    def paired(self):
        try:
            return self.pair_status()
        except (HostError, OSError, ssl.SSLError):
            return False

    def boxart(self, app_id):
        try:
            body = self._get('/appasset', [('appid', app_id),
                                           ('AssetType', '2'),
                                           ('AssetIdx', '0')])
        except (HostError, OSError, ssl.SSLError):
            return None

        if body[:4] == b'\x89PNG' or body[:2] == b'\xff\xd8':
            return body
        return None
