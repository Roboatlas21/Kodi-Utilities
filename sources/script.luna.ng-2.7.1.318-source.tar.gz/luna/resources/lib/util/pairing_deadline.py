"""Stage-aware Moonlight pairing timeout, independent of Kodi APIs.

Native Moonlight permits 65 seconds for a pending PIN request, then multiple
15-second challenge/verification exchanges. Repeated output cannot extend the
total duration indefinitely.
"""


class PairingDeadline:
    PIN_PROMPT_SECONDS = 20
    PIN_RESPONSE_SECONDS = 70
    STAGE_SECONDS = 55
    MAX_SECONDS = 180

    def __init__(self, started):
        self.maximum = started + self.MAX_SECONDS
        self.deadline = started + self.PIN_PROMPT_SECONDS
        self._pin_shown = False
        self._stages = set()

    def pin_shown(self, now):
        if self._pin_shown:
            return
        self._pin_shown = True
        self.deadline = min(now + self.PIN_RESPONSE_SECONDS, self.maximum)

    def stage(self, label, now):
        if (not self._pin_shown or not isinstance(label, str) or
                not label.startswith('Pairing: ') or label in self._stages):
            return
        self._stages.add(label)
        self.deadline = min(max(self.deadline, now + self.STAGE_SECONDS),
                            self.maximum)

    def expired(self, now):
        return now >= self.deadline or now >= self.maximum
