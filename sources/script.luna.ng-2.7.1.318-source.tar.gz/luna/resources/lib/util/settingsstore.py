"""Atomic, serialized settings.xml updates shared with Luna Resume state."""
import os
from pathlib import Path
import stat
import sys
import tempfile
from xml.etree import ElementTree

from resources.lib.util.resumestate import _settings_lock
from resources.lib.util.safexml import read_settings_tree, serialize_settings_tree


def update_setting(settings_path, setting_id, value):
    """Keep the single-setting API compatible with native Resume state."""
    return update_settings(settings_path, {setting_id: value})


def update_settings(settings_path, updates):
    """Atomically publish one or more Kodi settings in a single transaction.

    This serializes status and Resume-state writes under the same stable
    <settings.xml>.lock. Never touch the user's edited host_addr when
    publishing unrelated pairing-status fields.
    """
    if (not isinstance(updates, dict) or not updates or len(updates) > 16 or
            any(not isinstance(k, str) or not k or not isinstance(v, str)
                for k, v in updates.items())):
        raise ValueError('Invalid Kodi settings update')
    path = Path(settings_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with _settings_lock(path):
        try:
            tree, mode = read_settings_tree(path)
            root = tree.getroot()
        except FileNotFoundError as error:
            if os.path.lexists(path):
                raise ValueError('Existing Kodi settings path became inaccessible') from error
            mode = 0o600
            root = ElementTree.Element('settings', {'version': '2'})
            root.text = '\n'
            tree = ElementTree.ElementTree(root)

        # Do not construct an XPath from setting_id; removing old duplicates
        # also leaves a single authoritative value for Kodi's next read.
        for setting_id, value in updates.items():
            matches = [node for node in root.findall('setting')
                       if node.get('id') == setting_id]
            if matches:
                node = matches[0]
                for duplicate in matches[1:]:
                    root.remove(duplicate)
            else:
                node = ElementTree.SubElement(root, 'setting', {'id': setting_id})
                node.tail = '\n'
            node.attrib.pop('default', None)
            node.text = value

        serialized = serialize_settings_tree(tree)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(
                    mode='wb', dir=path.parent,
                    prefix=path.name + '.', suffix='.tmp',
                    delete=False) as stream:
                temporary = Path(stream.name)
                os.chmod(temporary, mode)
                stream.write(serialized)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            # Keep the same best-effort directory durability behavior as
            # resumestate.py; the replacement is committed at this point.
            try:
                directory_fd = os.open(str(path.parent),
                                       os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
            except OSError as error:
                print('Luna NG: settings updated but directory fsync failed: %s'
                      % error, file=sys.stderr)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
