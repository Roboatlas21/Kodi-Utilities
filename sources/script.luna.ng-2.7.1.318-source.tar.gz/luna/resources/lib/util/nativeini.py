"""Validate Moonlight's native INI subset before Luna may normalize a file.

This mirrors the original native config_ini.h *syntax*, not its runtime
settings parser. Unrecognized keys/values are never silently made valid by
a subsequent ConfigParser rewrite. Only input= is repeatable.
"""
import re

MAX_BYTES = 1024 * 1024
MAX_ENTRIES = 96
# Native src/config.c long_options, excluding CLI-only -config and -save.
KEYS = frozenset((
    '720', '1080', '4k', 'width', 'height', 'bitrate', 'packetsize',
    'app', 'appid', 'input', 'mapping', 'nosops', 'audio', 'localaudio',
    'platform', 'keydir', 'remote', 'windowed', 'surround', 'fps',
    'codec', 'nounsupported', 'quitappafter', 'viewonly', 'rotate',
    'verbose', 'debug', 'nomouseemulation', 'pin', 'port', 'hdr',
    'cec', 'osd', 'osdargs', 'address', 'sops',
))
BOOL_KEYS = frozenset((
    '720', '1080', '4k', 'nosops', 'localaudio', 'windowed',
    'nounsupported', 'quitappafter', 'viewonly', 'verbose', 'debug',
    'nomouseemulation', 'hdr', 'cec', 'osd', 'sops',
))
NUMBERS = {
    'width': (64, 7680), 'height': (64, 4320),
    'bitrate': (-1, 500000), 'packetsize': (256, 1500),
    'appid': (0, 2147483647), 'fps': (1, 240),
    'pin': (1, 9999), 'port': (1, 65535),
}
HEADER = re.compile(r'^\[([^\]\r\n]+)\][ \t]*(?:[#;].*)?$')
KEY = re.compile(r'^[a-z0-9_-]+$')
ADDRESS = re.compile(r'^[A-Za-z0-9._:\[\]%-]+$')
INTEGER = re.compile(r'^-?[0-9]+$')


class NativeIniError(ValueError):
    """Input would be rejected by the native Moonlight section reader."""


def _validate_value(key, value):
    length = len(value.encode('utf-8'))
    if not length or length > 4095:
        raise NativeIniError('empty or oversized native INI value')
    if key == 'address' and (length > 255 or value in ('.', '..') or
                             not ADDRESS.fullmatch(value)):
        raise NativeIniError('invalid Sunshine address')
    if key == 'keydir' and length >= 4096:
        raise NativeIniError('oversized key directory')
    if key == 'osdargs' and length >= 256:
        raise NativeIniError('oversized OSD arguments')
    if key in BOOL_KEYS and value.lower() not in (
            'true', 'false', 'yes', 'no', '1', '0'):
        raise NativeIniError('invalid native boolean')
    if key in NUMBERS:
        minimum, maximum = NUMBERS[key]
        if not INTEGER.fullmatch(value) or not minimum <= int(value) <= maximum:
            raise NativeIniError('invalid native numeric setting')
    if key == 'rotate' and value not in ('0', '90', '180', '270'):
        raise NativeIniError('invalid rotation')
    if key == 'codec' and value.lower() not in (
            'auto', 'h264', 'h265', 'hevc', 'av1'):
        raise NativeIniError('invalid codec')
    if key == 'surround' and value.lower() not in (
            'stereo', 'false', '5.1', '7.1'):
        raise NativeIniError('invalid surround option')
    if key == 'remote' and value.lower() not in (
            'auto', 'true', 'false', 'yes', 'no'):
        raise NativeIniError('invalid remote option')


def validate_and_mask_inputs(original, max_inputs=32):
    """Return strict-ConfigParser-compatible INI without native input lines.

    C ignores all keys outside [Moonlight]; leave unrelated sections to the
    existing Python reader. Native input lines are validated and replaced by
    comments only for the parser; the original file is never modified here.
    """
    if not isinstance(original, str) or '\x00' in original:
        raise NativeIniError('invalid native INI encoding')
    normalized = original.replace('\r\n', '\n')
    if '\r' in normalized:
        if not normalized.endswith('\r') or '\r' in normalized[:-1]:
            raise NativeIniError('invalid native INI line endings')
        normalized = normalized[:-1]
    rendered = []
    section = None
    found_header = False
    input_count = 0
    entry_count = 0
    for line in normalized.split('\n'):
        stripped = line.strip(' \t')
        if not stripped or stripped.startswith(('#', ';')):
            rendered.append(line)
            continue
        if stripped.startswith('['):
            match = HEADER.fullmatch(stripped)
            if not match:
                raise NativeIniError('malformed native INI section header')
            section = match.group(1)
            if section.lower() == 'moonlight' and section != 'Moonlight':
                raise NativeIniError('noncanonical [Moonlight] section')
            found_header = True
            rendered.append(line)
            continue
        # Lua/Natively sectionless files must not be rewritten as valid INI.
        if section is None:
            raise NativeIniError('missing [Moonlight] section / sectionless format')
        if section != 'Moonlight':
            rendered.append(line)
            continue
        if line.startswith((' ', '\t')):
            # Native accepts indentation, but ConfigParser treats such lines
            # as multiline continuations, silently changing their meaning.
            raise NativeIniError('indented native INI option is ambiguous')
        name, separator, raw_value = line.partition('=')
        key = name.strip(' \t')
        value = raw_value.strip(' \t')
        if not separator or not KEY.fullmatch(key):
            raise NativeIniError('unknown or malformed native INI option')
        if key == 'dualsensehid':
            # Only this explicitly retired Luna toggle is migrated. Native
            # Moonlight never sees it: the managed writer regenerates a file
            # without the option, while the original remains untouched here.
            if value.lower() not in ('true', 'false', 'yes', 'no', '1', '0'):
                raise NativeIniError('invalid retired DualSense setting')
            rendered.append('; Luna retired legacy DualSense toggle')
            continue
        if key not in KEYS:
            raise NativeIniError('unknown or malformed native INI option')
        _validate_value(key, value)
        entry_count += 1
        if entry_count > MAX_ENTRIES:
            raise NativeIniError('too many native INI entries')
        if key == 'input':
            input_count += 1
            if input_count > max_inputs:
                raise NativeIniError('too many native input entries')
            rendered.append('; Luna regenerates selected input rows')
            continue
        rendered.append(line)
    # Empty first-run configuration and unrelated sections without a
    # Moonlight block remain supported by Luna's managed writer.
    if not found_header and normalized.strip(' \t\n'):
        raise NativeIniError('missing [Moonlight] section / sectionless format')
    return '\n'.join(rendered)
