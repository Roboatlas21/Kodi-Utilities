"""Service-owned Sunshine status verification with bounded network workers.

Only the Kodi service ticker reads/writes addon settings. Network workers
consume prepared Host objects; results are tagged by host + settings session.
An expired refresh timer never invalidates a request that is still in flight.
"""
import threading
import time

from resources.lib.util.hostapi import HostIdentityError

STATES = frozenset(('paired', 'unpaired', 'needs_pin', 'unavailable',
                    'identity_changed'))


def probe_pairing_state(host):
    """Verify the selected host; saved pairing keys alone prove nothing."""
    if not host.has_pairing_keys():
        return 'unpaired'
    if not host.has_trusted_pin():
        return 'needs_pin'
    return 'paired' if host.pair_status() else 'unpaired'


class ServiceStatusCoordinator:
    def __init__(self, read_address, is_settings_open, probe, publish,
                 log_error=None, clock=None, retry_seconds=10,
                 refresh_seconds=45, read_revision=None, prepare_probe=None,
                 read_pending=None, acknowledge_pending=None,
                 read_identity=None):
        self._read_address = read_address
        # The exact host is address + normalized port + pairing keydir.
        # Default to address-only for legacy non-Kodi callers.
        self._read_identity = read_identity or (lambda address: address)
        self._is_settings_open = is_settings_open
        self._probe = probe
        self._publish = publish
        self._log_error = log_error or (lambda error: None)
        self._clock = clock or time.monotonic
        self._retry_seconds = retry_seconds
        self._refresh_seconds = refresh_seconds
        self._read_revision = read_revision or (lambda: None)
        self._prepare_probe = prepare_probe or (lambda address: address)
        self._read_pending = read_pending or (lambda: ('', ''))
        self._acknowledge_pending = acknowledge_pending or (lambda token, address: None)
        self._lock = threading.RLock()
        self._worker = None
        self._queued = None
        self._finished = None
        self._active_generation = None
        self._generation = 0
        self._last_address = None
        self._last_identity = None
        self._last_session = None
        self._next_probe = 0
        self._stopped = False

    def _address(self):
        value = self._read_address()
        return value.strip() if isinstance(value, str) else ''

    def _identity(self, address):
        return self._read_identity(address) if address else ''

    def _session(self, address, identity):
        if self._is_settings_open():
            return ('dialog', self._read_revision())
        pending = self._read_pending()
        token, requested = pending[:2]
        # Settings records its connection identity before publishing the
        # pending token. Retain support for older two-field callbacks.
        expected_identity = pending[2] if len(pending) > 2 else None
        if (token and requested == address and
                (not expected_identity or expected_identity == identity)):
            return ('postclose', token)
        return None

    def _publish_current(self, address, generation, result):
        # All Kodi callbacks are invoked on the existing service ticker.
        if (not self._stopped and generation == self._generation and
                self._last_session is not None and
                self._address() == address and
                self._identity(address) == self._last_identity and
                self._session(address, self._last_identity) == self._last_session):
            self._publish(address, result)
            return True
        return False

    def _acknowledge(self, address, generation, delivered):
        if delivered and generation == self._generation and self._last_session:
            if self._last_session[0] == 'postclose':
                self._acknowledge_pending(self._last_session[1], address)

    def _drain(self):
        # The worker never invokes Kodi, writes status, or logs failures.
        # A slow network call may outlive Kodi's service shutdown safely.
        while True:
            with self._lock:
                if self._stopped or self._queued is None:
                    return
                address, generation, request = self._queued
                self._queued = None
                self._active_generation = generation
            try:
                result = self._probe(request)
                if result not in STATES:
                    raise ValueError('Invalid Sunshine status response')
                error_name = None
            except HostIdentityError as error:
                # A pinned Sunshine key mismatch is not a network outage.
                # Never silently trust or replace an unfamiliar certificate.
                result = 'identity_changed'
                error_name = type(error).__name__
            except Exception as error:
                result = 'unavailable'
                error_name = type(error).__name__
            with self._lock:
                if self._active_generation == generation:
                    self._active_generation = None
                if not self._stopped:
                    self._finished = (address, generation, result, error_name)

    def _start_queued_worker(self, now):
        # At most one network worker even if an old host blocks for seconds.
        if self._queued is None:
            return
        if self._worker is not None and self._worker.is_alive():
            return
        thread = threading.Thread(target=self._drain,
                                  name='LunaStatusNetwork', daemon=True)
        try:
            thread.start()
        except RuntimeError as error:
            address, generation, _ = self._queued
            self._queued = None
            self._next_probe = now + self._retry_seconds
            self._log_error(error)
            delivered = self._publish_current(address, generation, 'unavailable')
            self._acknowledge(address, generation, delivered)
            return
        self._worker = thread

    def _enqueue(self, address, now):
        self._generation += 1
        generation = self._generation
        self._finished = None
        self._queued = None
        self._next_probe = now + self._refresh_seconds
        if not address:
            delivered = self._publish_current('', generation, 'unconfigured')
            self._acknowledge('', generation, delivered)
            return
        try:
            request = self._prepare_probe(address)
            if self._identity(address) != self._last_identity:
                # Connection changed while capturing the immutable Host.
                # Next tick will start the new generation; never publish A
                # as though the new port/keydir's pending probe succeeded.
                self._next_probe = now
                return
        except Exception as error:
            self._next_probe = now + self._retry_seconds
            self._log_error(error)
            delivered = self._publish_current(address, generation, 'unavailable')
            self._acknowledge(address, generation, delivered)
            return
        self._queued = (address, generation, request)
        self._publish_current(address, generation, 'checking')
        self._start_queued_worker(now)

    def tick(self):
        with self._lock:
            if self._stopped:
                return
            address = self._address()
            identity = self._identity(address)
            session = self._session(address, identity)
            if session is None:
                if self._last_session is not None:
                    self._generation += 1
                    self._queued = None
                    self._finished = None
                self._last_session = None
                self._last_identity = None
                return
            now = self._clock()
            changed = (address != self._last_address or
                       identity != self._last_identity or
                       session != self._last_session)
            self._last_address = address
            self._last_identity = identity
            self._last_session = session
            if changed:
                self._enqueue(address, now)
                return

            # Process a finished result BEFORE deciding to refresh. In
            # particular, an 8-second refresh timer cannot discard a valid
            # 9-second Sunshine result and restart 'Checking pairing...'.
            if self._finished is not None:
                done_address, generation, result, error_name = self._finished
                self._finished = None
                if generation == self._generation and done_address == address:
                    self._next_probe = now + (
                        self._retry_seconds if result == 'unavailable'
                        else self._refresh_seconds)
                    if error_name:
                        self._log_error(error_name)
                    delivered = self._publish_current(address, generation, result)
                    self._acknowledge(address, generation, delivered)

            pending_current = (self._queued is not None and
                               self._queued[1] == self._generation)
            running_current = self._active_generation == self._generation
            if now >= self._next_probe and not pending_current and not running_current:
                self._enqueue(address, now)
                return
            self._start_queued_worker(now)

    def stop(self, timeout=0.2):
        with self._lock:
            self._stopped = True
            self._generation += 1
            self._queued = None
            self._finished = None
            worker = self._worker
        # Never delay Kodi shutdown for a network call. It cannot publish
        # or invoke Kodi APIs after the coordinator is stopped.
        if worker is not None and worker is not threading.current_thread():
            worker.join(timeout=timeout)
