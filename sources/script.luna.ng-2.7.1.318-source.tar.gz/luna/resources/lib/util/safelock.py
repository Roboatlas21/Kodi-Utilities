"""Bounded, inode-stable locks for Kodi-owned settings and per-host state."""
from contextlib import contextmanager
import fcntl
import os
import stat
import time

LOCK_TIMEOUT_SECONDS = 5.0


@contextmanager
def locked_regular_file(path, timeout=LOCK_TIMEOUT_SECONDS):
    """Take an exclusive lock without following symlinks or blocking on FIFOs.

    Lock files are deliberately never unlinked or atomically replaced; separate
    Kodi invocations must serialize on the same filesystem inode. An existing
    nonregular file is an error, not a reason to create a different lock.
    """
    if not isinstance(timeout, (int, float)) or not 0 <= timeout <= 60:
        raise ValueError('Invalid lock deadline')
    flags = (os.O_RDWR | os.O_CREAT | os.O_NONBLOCK | os.O_NOFOLLOW |
             getattr(os, 'O_CLOEXEC', 0))
    fd = os.open(os.fspath(path), flags, 0o600)
    try:
        metadata = os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode):
            raise OSError('Luna lock path is not a regular file')
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('Timed out waiting for Luna file lock')
                time.sleep(min(0.05, remaining))
        try:
            yield fd
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)
