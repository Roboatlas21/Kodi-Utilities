"""Bound DNS resolution outside Kodi's interpreter, retaining TLS host identity."""
import json
import socket
import subprocess
import time

_cache = {}
_RESOLVE = ('import socket,json,sys; '
            'print(json.dumps(socket.getaddrinfo(sys.argv[1],int(sys.argv[2]),'
            'type=socket.SOCK_STREAM)))')


def socket_host(address):
    """Native-compatible transport host, without rewriting pin/host identity.

    URI authorities may include IPv6 brackets or RFC 6874 %25 zone escapes.
    getaddrinfo instead expects the bare IPv6 address and raw '%' zone.
    Keep the caller's host intact for certificate lookup and HTTPS identity.
    """
    if not isinstance(address, str) or not address or len(address) > 255:
        raise ValueError('Invalid Sunshine socket host')
    bracketed = address.startswith('[')
    if bracketed:
        if not address.endswith(']'):
            raise ValueError('Incomplete IPv6 host brackets')
        value = address[1:-1]
    else:
        value = address
    if ':' not in value:
        if bracketed or ']' in value:
            raise ValueError('Invalid socket host brackets')
        return value
    bare, separator, zone = value.partition('%')
    try:
        socket.inet_pton(socket.AF_INET6, bare)
    except OSError as error:
        raise ValueError('Invalid IPv6 Sunshine host') from error
    if separator:
        if zone.startswith('25'):
            zone = zone[2:]  # URI zone escape: %25eth0 -> %eth0
        if (not zone or '%' in zone or
                any(not (char.isascii() and
                         (char.isalnum() or char in '._~-'))
                    for char in zone)):
            raise ValueError('Invalid IPv6 Sunshine scope')
        return bare + '%' + zone
    return bare


def connect(address, timeout=4, source_address=None):
    host, port = address
    resolved_host = socket_host(host)
    deadline = time.monotonic() + timeout
    # Keep the unmodified identity as the cache key; only the subprocess
    # resolver sees socket syntax without URI brackets or percent escaping.
    key = (host, port)
    cached = _cache.get(key)
    if cached and time.monotonic() < cached[0]:
        results = cached[1]
    else:
        try:
            result = subprocess.run(['python3', '-c', _RESOLVE, resolved_host, str(port)],
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    text=True, timeout=timeout, check=True)
            results = json.loads(result.stdout)
        except (subprocess.SubprocessError, ValueError) as error:
            raise socket.timeout('Sunshine address resolution failed or timed out') from error
        if len(_cache) >= 128:
            _cache.clear()
        _cache[key] = (time.monotonic() + 60, results)
    last_error = socket.timeout('Sunshine connection deadline expired')
    for index, (family, kind, protocol, _, target) in enumerate(results):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        sock = None
        try:
            sock = socket.socket(family, kind, protocol)
            # Reserve a share of the total budget for every remaining address.
            sock.settimeout(remaining / (len(results) - index))
            if source_address:
                sock.bind(source_address)
            sock.connect(tuple(target))
            sock.settimeout(timeout)  # TLS and response reads get the request budget.
            return sock
        except OSError as error:
            last_error = error
            if sock is not None:
                sock.close()
    _cache.pop(key, None)  # A changed address must be retried on the next request.
    raise last_error
