"""Offline Luna diagnostic reports. Nothing in this module uploads logs."""
import datetime
import io
from collections import deque
import ipaddress
import os
from pathlib import Path
import secrets
import re
import stat
import subprocess
import tempfile
import zipfile

MAX_SOURCE_BYTES = 512 * 1024
MAX_SOURCE_LINES = 300
MAX_LINE_LENGTH = 4096
# Scan only the newest bounded region of each regular log; Moonlight's Debug
# sampler itself stops at 32 MiB. Keep event selections in tiny fixed rings.
MAX_HIGHLIGHT_SCAN_BYTES = 32 * 1024 * 1024
MAX_HIGHLIGHT_FIRST = 24
MAX_HIGHLIGHT_RECENT = 96
MAX_HIGHLIGHT_WINDOWS = 12
_HIGHLIGHT_RE = re.compile(
    rb'(?i)(?:unrecoverable frame|sending (?:speculative )?rfi request|'
    rb'network dropped [0-9]+ frames?|depacketizer detected corrupt|'
    rb'video decode unit queue overflow|fec recovery returned corrupt|'
    rb'codec_write\(\).*?(?:error|timeout|failed)|'
    rb'ALSA: (?:incomplete PCM write|Opus decode error)|'
    rb'ALSA_PRESSURE_V1|STREAM_DIAG_LIMIT_V1|'
    rb'LUNA_LAUNCH_TIMING_V1|LUNA_NATIVE_TEARDOWN_V1|'
    rb'AML_PTS_DIAG_V1|'
    rb'NET_DIAG_V1.*?\b(?:abandon_events|late_missing_[a-z0-9_]+|'
    rb'fec_failed_attempts|kernel_udp_drops)=\+[1-9])'
)
DEFAULT_LOGFILES_ROOT = '/storage/logfiles'

# All sources pass through this conservative scrubber before ANY network-share
# copy. Mask unknown secrets too where they resemble credentials or filenames.
# No arbitrary-log redactor can promise to recognize every sensitive value.
_PEM = re.compile(r'(?is)-----BEGIN [^\r\n-]*(?:PRIVATE KEY|CERTIFICATE)-----.*?(?:-----END [^\r\n]+-----|\Z)')
_URL = re.compile(r'(?i)\b(?:https?|ftp|smb|nfs|rtsp|rtmp|plugin)://[^\s<>"\']+')
# Credential fields may have arbitrary prefixes or namespaces:
# session_token, api_token, my_password, service.auth_token, ns:api_key.
# Redact short values too; long-token heuristics cannot protect them.
_CREDENTIAL_SUFFIX = (
    r'(?:password|passwd|passphrase|access[_-]?token|refresh[_-]?token|'
    r'api[_-]?key|private[_-]?key|client[_-]?(?:key|cert)|'
    r'authorization|credentials?|uniqueid|secret|token|pin|'
    r'cookie|oauth|jwt|signature)')
_CREDENTIAL_FIELD = r'(?:[a-z0-9]+[_:.-])*' + _CREDENTIAL_SUFFIX
_XML_SECRET = re.compile(
    r'<(' + _CREDENTIAL_FIELD + r')(?:\s[^<>]*?)?>.*?</\1\s*>',
    re.IGNORECASE | re.DOTALL)
_SECRET = re.compile(
    r'(?<![a-z0-9])["\']?(' + _CREDENTIAL_FIELD + r')["\']?\s*[:=]\s*'
    r'("[^"\r\n]*"|\'[^\'\r\n]*\'|[^\s&;,<>{}]+)',
    re.IGNORECASE)
_BEARER = re.compile(r'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+')
_EMAIL = re.compile(r'(?i)\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')
_MAC = re.compile(r'(?i)\b(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b')
_IPV4 = re.compile(r'(?<![\w.])(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)'
                   r'(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}(?![\w.])')
_IPV6 = re.compile(r'(?i)(?<![\w])(?:[0-9a-f]{0,4}:){2,}[0-9a-f]{0,4}(?:%[\w.-]+)?(?![\w])')
_LOCAL_PATH = re.compile(
    r"(?i)(?<![\w])(?:/(?:storage|home|root|mnt|media|tmp|etc|var/media)/"
    r"[^\s\"'<>()\[\],;]+|[a-z]:\\[^\s\"'<>()\[\],;]+|"
    r"\\\\[a-z0-9_.-]+\\[^\s\"'<>()\[\],;]+)")
_ENDPOINT = re.compile(
    r'(?i)\b(?:host(?:name|_addr)?|server(?:_name|_addr)?|'
    r'address|ssid|serial(?:number)?|device_id|client_id)\s*[:=]\s*'
    r'(?:"[^"\r\n]*"|[^\s&;,<>{}]+)')
_LONG_TOKEN = re.compile(r'(?i)\b(?:[a-f0-9]{32,}|[a-z0-9_-]{48,}={0,2})\b')
# Native Moonlight logs use human phrases instead of key=value syntax.
# Preserve the failure context while hiding the endpoint. A bare local
# hostname need not contain a dot or an IP address.
_HOST_PROSE = re.compile(
    r'(?i)\b((?:(?:re)?connecting|connected|paired|pairing)\s+'
    r'(?:to|with|at)\s+)([^\s,;()<>\[\]]+)')
_HOST_DESCRIPTION = re.compile(
    r'(?i)\b((?:sunshine\s+)?(?:host|server)\s+'
    r'(?:is|at|named|name\s+is|address\s+is)\s+)([^\s,;()<>\[\]]+)')
# Real Kodi/CoreELEC and Jellyfin logs use prose, not key=value fields:
#  - wl_cfg80211_connect: ssid "My Private Network"
#  - CoreELEC Addon: system::set_hostname ## MyBox
#  - Jellyfin: onSuccessfulConnection with server MyServer
#  - Kodi monitor: No session yet for device <UUID>
_WIFI_SSID = re.compile(
    r'(?i)(?<!\[)\bssid\b\s*(?:[:=]\s*)?(?:"[^"\r\n]*"|\'[^\'\r\n]*\'|[a-z0-9_.-]+)')
_CORE_HOSTNAME = re.compile(
    r'(?i)(\bsystem::set_hostname(?:\s+##)?\s+)([a-z0-9_.-]+)')
_SERVER_CONNECTION = re.compile(
    r'(?i)(\b(?:with|to)\s+server\s+)([^\s,;()<>\[\]]+)')
_UUID = re.compile(
    r'(?i)(?<![0-9a-f])[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}(?![0-9a-f])')
_LOGIN_HOST = re.compile(
    r'(?i)(?<![\w])(?:[a-z0-9._~-]+)@(?:[a-z0-9._-]+)(?![\w])')
# Whole lines are withheld when they mention authentication material. This is
# safer than trying to understand every possible server-specific log format.
_SENSITIVE_LINE = re.compile(
    r'\b(?:authorization|proxy.authorization|bearer|cookie|set.cookie|'
    r'password|passwd|passphrase|private.?key|certificate|'
    r'access.?token|refresh.?token|api.?key|apikey|auth.?token|'
    r'pairing.?pin|credentials?|session.?secret|secret.?key|'
    r'uniqueid|oauth|jwt|signature|signed.?request|pin|pairing.?code)\b'
    r'|(?<![a-z0-9])' + _CREDENTIAL_FIELD + r'(?![a-z0-9])',
    re.IGNORECASE)


def redact(text):
    """Mask common secrets and network identities; a human must still review."""
    text = re.sub(r'(?im)(LUNA applications: )[^\r\n]*?: ',
                  r'\1[HOST REDACTED]: ', text)
    text = _PEM.sub('[PEM DATA REDACTED]', text)
    # A byte-limited source can begin inside a PEM block. Include its short
    # final base64 line when the surviving END marker identifies the block.
    text = re.sub(r'(?m)(?:^[ \t]*[A-Za-z0-9+/]+={0,2}[ \t]*\r?\n)+'
                  r'^[ \t]*-----END [^\r\n]+-----',
                  '[PEM TAIL REDACTED]', text)
    text = re.sub(r'(?m)^[ \t]*[A-Za-z0-9+/]{32,}={0,2}[ \t]*$',
                  '[ENCODED DATA REDACTED]', text)
    text = _URL.sub('[URL REDACTED]', text)
    text = _LOCAL_PATH.sub('[LOCAL PATH REDACTED]', text)
    text = _ENDPOINT.sub('[HOST IDENTIFIER REDACTED]', text)
    text = _WIFI_SSID.sub('ssid [SSID REDACTED]', text)
    text = _CORE_HOSTNAME.sub(lambda m: m[1] + '[HOST REDACTED]', text)
    text = _SERVER_CONNECTION.sub(lambda m: m[1] + '[HOST REDACTED]', text)
    text = _HOST_PROSE.sub(lambda m: m[1] + '[HOST REDACTED]', text)
    text = _HOST_DESCRIPTION.sub(lambda m: m[1] + '[HOST REDACTED]', text)
    text = _UUID.sub('[UUID REDACTED]', text)
    text = _LOGIN_HOST.sub('[ACCOUNT AND HOST REDACTED]', text)
    text = _XML_SECRET.sub(lambda m: '<%s>[REDACTED]</%s>' % (m[1], m[1]), text)
    text = _BEARER.sub('Bearer [REDACTED]', text)
    text = _SECRET.sub(lambda m: '%s=[REDACTED]' % m[1], text)
    text = _EMAIL.sub('[EMAIL REDACTED]', text)
    text = _MAC.sub('[MAC REDACTED]', text)
    text = _IPV4.sub('[IPv4 REDACTED]', text)

    def hide_ipv6(match):
        try:
            return '[IPv6 REDACTED]' if isinstance(
                ipaddress.ip_address(match.group(0).split('%', 1)[0]),
                ipaddress.IPv6Address) else match.group(0)
        except ValueError:
            return match.group(0)

    text = _IPV6.sub(hide_ipv6, text)
    text = _LONG_TOKEN.sub('[TOKEN REDACTED]', text)

    def filter_sensitive_line(line):
        # Safe generated markers must be stable across the private ZIP and
        # the mandatory second redaction before Samba publication.
        if line in ('[XML CREDENTIAL BLOCK REDACTED]',
                    '[PEM DATA REDACTED]',
                    '[OVERSIZED LOG RECORD REDACTED]',
                    '[SENSITIVE LOG LINE REDACTED]'):
            return line
        if _SENSITIVE_LINE.search(line):
            # Keep ONLY an authenticated, strictly numeric diagnostic label.
            # A token on the same line must not erase the lost-frame evidence.
            event = re.search(r'(?i)\bUnrecoverable frame [0-9]{1,10}\b',
                              line)
            if event:
                return event.group(0) + ' [SENSITIVE DETAILS REDACTED]'
            return '[SENSITIVE LOG LINE REDACTED]'
        return line

    return '\n'.join(filter_sensitive_line(line) for line in text.split('\n'))


def _bounded_tail(raw):
    """Limit log size, lines, and line length without loading complete files."""
    if isinstance(raw, bytes):
        raw = raw[-MAX_SOURCE_BYTES:].decode('utf-8', 'replace')
    else:
        raw = raw[-MAX_SOURCE_BYTES:]
    raw = redact(raw)
    lines = raw.splitlines()[-MAX_SOURCE_LINES:]
    return '\n'.join(line[:MAX_LINE_LENGTH] for line in lines) + '\n' if lines else '(empty)\n'


def _read_log(path):
    if path is None:
        return '(not configured)\n'
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0)
    flags |= getattr(os, 'O_NONBLOCK', 0)
    try:
        fd = os.open(os.fspath(path), flags)
        with os.fdopen(fd, 'rb') as stream:
            st = os.fstat(stream.fileno())
            if not stat.S_ISREG(st.st_mode):
                return '(not available: source is not a regular file)\n'
            if st.st_size > BUNDLE_CONTEXT_SCAN_MAX_BYTES:
                return '(not available: log too large to verify credential context)\n'
            if st.st_size > MAX_SOURCE_BYTES:
                cutoff = st.st_size - MAX_SOURCE_BYTES
                context = _private_block_before_offset(stream, cutoff)
                stream.seek(cutoff - 1)
                aligned = stream.read(1) == b'\n'
                stream.seek(cutoff)
                if not aligned:
                    # Never output a clipped first record.
                    stream.readline(BUNDLE_LINE_BYTES + 1)
                remaining = max(0, st.st_size - stream.tell())
                selected = io.BytesIO()
                _copy_redacted_lines(
                    stream, selected, remaining, BUNDLE_SUMMARY_BYTES,
                    initial_private_block=context)
                return _bounded_tail(selected.getvalue())
            raw = stream.read(MAX_SOURCE_BYTES)
        return _bounded_tail(raw)
    except OSError:
        return '(not available: log could not be read safely)\n'


def _read_log_highlights(path):
    """Keep early, spaced and recent error events from a bounded log region.

    Read only regular, no-follow files and never store entire large logs in
    memory. Per-line length is capped before selection. A malformed long line
    is skipped rather than surfacing a chopped, potentially unredactable
    secret. All selections are redacted before they enter the report.
    """
    if path is None:
        return ''
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
    flags |= getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NONBLOCK', 0)
    try:
        fd = os.open(os.fspath(path), flags)
        with os.fdopen(fd, 'rb') as stream:
            st = os.fstat(stream.fileno())
            if not stat.S_ISREG(st.st_mode):
                return ''
            if st.st_size > BUNDLE_CONTEXT_SCAN_MAX_BYTES:
                return ''
            start = max(0, st.st_size - MAX_HIGHLIGHT_SCAN_BYTES)
            end = st.st_size
            context = (_private_block_before_offset(stream, start)
                       if start else None)
            stream.seek(start)
            skipping = False
            if start:
                # Position may be in the middle of a multiline/long record.
                fragment = stream.readline(MAX_LINE_LENGTH + 1)
                skipping = not fragment.endswith(b'\n')
            first = []
            windows = [None] * MAX_HIGHLIGHT_WINDOWS
            recent = deque(maxlen=MAX_HIGHLIGHT_RECENT)
            observed = 0
            while stream.tell() < end:
                limit = min(MAX_LINE_LENGTH + 1, end - stream.tell())
                chunk = stream.readline(limit)
                if not chunk:
                    break
                offset = stream.tell()
                if skipping:
                    if chunk.endswith(b'\n'):
                        skipping = False
                    continue
                if len(chunk) > MAX_LINE_LENGTH:
                    skipping = not chunk.endswith(b'\n')
                    continue
                line = chunk.decode('utf-8', 'replace').rstrip('\r\n')
                if context:
                    context = _advance_private_block(context, line)
                    continue
                new_context = _advance_private_block(None, line)
                if (new_context or _PEM_BLOCK_BEGIN.search(line) or
                        _XML_BLOCK_BEGIN.search(line)):
                    context = new_context
                    continue
                if not _HIGHLIGHT_RE.search(chunk):
                    continue
                observed += 1
                item = (offset, chunk.decode('utf-8', 'replace').rstrip('\r\n'))
                if len(first) < MAX_HIGHLIGHT_FIRST:
                    first.append(item)
                index = min(MAX_HIGHLIGHT_WINDOWS - 1,
                            (offset - start) * MAX_HIGHLIGHT_WINDOWS //
                            max(1, end - start))
                windows[index] = item
                recent.append(item)
        if not observed:
            return ''
        unique = {pos: value for pos, value in
                  list(first) + [item for item in windows if item] + list(recent)}
        selected = [value for _pos, value in sorted(unique.items())]
        return ('(Selected %d of %d significant events from the most recent '
                '%d bytes; older or unrecognized events may be absent.)\n' %
                (len(selected), observed, min(st.st_size, MAX_HIGHLIGHT_SCAN_BYTES))
                + redact('\n'.join(selected)) + '\n')
    except OSError:
        return ''


def _kernel_log():
    try:
        result = subprocess.run(['dmesg'], stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, timeout=5,
                                check=False)
    except (OSError, subprocess.TimeoutExpired):
        return '(not available: kernel log collection failed)\n'
    if result.returncode:
        return '(not available: kernel log access denied)\n'
    return _bounded_tail(result.stdout)


def _prune_reports(directory_fd, keep_name, max_count=20, max_bytes=128 * 1024 * 1024):
    """Retain recent Luna reports; never follow or delete unrelated entries."""
    entries = []
    for name in os.listdir(directory_fd):
        if not re.fullmatch(r'luna-diagnostics-[0-9]{8}-[0-9]{6}-[a-z0-9_]+\.(?:txt|zip)', name):
            continue
        try:
            info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1:
                continue
            entries.append((name, info))
        except OSError:
            continue
    entries.sort(key=lambda entry: entry[1].st_mtime_ns, reverse=True)
    size = count = 0
    for name, info in entries:
        count += 1
        size += info.st_size
        if name == keep_name or (count <= max_count and size <= max_bytes):
            continue
        try:
            current = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            if (current.st_dev, current.st_ino) == (info.st_dev, info.st_ino):
                os.unlink(name, dir_fd=directory_fd)
        except OSError:
            pass  # Retention must not discard the newly collected report.


def _report_parts(data_dir, kodi_log=None, legacy_log=None, kernel_output=None):
    """Build one summary and one fixed list of eligible source files."""
    root = Path(data_dir)
    now = datetime.datetime.now(datetime.timezone.utc)
    sources = [
        ('Luna session log', root / 'logfile'),
        ('Kodi log', kodi_log),
    ]
    previous_native = root / 'logfile.old'
    if previous_native.exists() or previous_native.is_symlink():
        sources.append(('Previous Luna native session log', previous_native))
    # Luna's pre-handoff timing is written by Kodi before Kodi is killed.
    # On CoreELEC the previous process's log moves to kodi.old.log when the
    # recovered Kodi starts. Preserve that bounded, redacted source too.
    if kodi_log is not None:
        previous_kodi_log = Path(kodi_log).with_name('kodi.old.log')
        if previous_kodi_log.exists() or previous_kodi_log.is_symlink():
            sources.append(('Previous Kodi log (launch preflight)',
                            previous_kodi_log))
    if legacy_log is not None:
        sources.append(('Legacy native Moonlight log', legacy_log))
    # Native Moonlight writes these only after the shared stderr logfile
    # reaches its 32 MiB periodic-sample budget. The launcher clears old
    # session sidecars before a new native process starts.
    for label, filename in (
            ('Native rolling diagnostics (previous)', 'native-diagnostics.rolling.1'),
            ('Native rolling diagnostics (current)', 'native-diagnostics.rolling.0'),
            ('Prior native session identifier', 'native-diagnostics.prior.session'),
            ('Prior native rolling diagnostics (previous)', 'native-diagnostics.prior.1'),
            ('Prior native rolling diagnostics (current)', 'native-diagnostics.prior.0')):
        candidate = root / filename
        if candidate.exists() or candidate.is_symlink():
            sources.append((label, candidate))
    sections = [(name, _read_log(path)) for name, path in sources]
    # The normal tail is still the easiest way to see how the session ended.
    # Append separate, redacted, bounded evidence from earlier in the stream
    # so a short corruption burst cannot disappear after another 300 lines.
    for name, path in sources:
        highlights = _read_log_highlights(path)
        if highlights:
            sections.append((name + ' - significant events throughout session',
                             highlights))
    kernel = _kernel_log() if kernel_output is None else _bounded_tail(kernel_output)
    sections.append(('Kernel log (last 300 lines)', kernel))
    header = ('Luna diagnostic report - LOCAL FILE ONLY\n'
              'Created (UTC): %s\n'
              'Nothing was uploaded or sent to an external service.\n'
              'Credentials, URLs, paths and network identifiers have been masked.\n'
              % now.isoformat(timespec='seconds'))
    report_text = header + ''.join('\n===== %s =====\n%s' % (name, redact(data))
                                   for name, data in sections)
    return now, sources, report_text, kernel


def _private_reports_directory(data_dir):
    root = Path(data_dir)
    if not root.is_dir():
        root.mkdir(parents=True, mode=0o700, exist_ok=True)
    reports = root / 'diagnostics'
    reports.mkdir(mode=0o700, exist_ok=True)
    info = reports.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
        raise OSError('Unsafe diagnostics folder')
    reports.chmod(0o700)
    return reports


def create_text_report(data_dir, kodi_log=None, legacy_log=None, kernel_output=None):
    """Legacy TXT summary for older integrations; new reports use ZIP."""
    reports = _private_reports_directory(data_dir)
    now, _sources, report_text, _kernel = _report_parts(
        data_dir, kodi_log, legacy_log, kernel_output)
    file_path = None
    try:
        fd, file_path = tempfile.mkstemp(
            prefix='luna-diagnostics-%s-' % now.strftime('%Y%m%d-%H%M%S'),
            suffix='.txt', dir=reports)
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            os.fchmod(out.fileno(), 0o600)
            out.write(report_text)
            out.flush()
            os.fsync(out.fileno())
        directory_fd = os.open(reports, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            _prune_reports(directory_fd, Path(file_path).name)
        finally:
            os.close(directory_fd)
        return Path(file_path)
    except BaseException:
        if file_path is not None:
            Path(file_path).unlink(missing_ok=True)
        raise


# One ZIP contains a quick summary and the full available, redacted session
# timeline, subject to explicit input limits. No raw source is ever archived.
BUNDLE_SESSION_BYTES = 32 * 1024 * 1024
BUNDLE_OTHER_BYTES = 4 * 1024 * 1024
BUNDLE_ROLLING_BYTES = 16 * 1024 * 1024
BUNDLE_KERNEL_BYTES = 512 * 1024
BUNDLE_SUMMARY_BYTES = 4 * 1024 * 1024
BUNDLE_COMPRESSED_BYTES = 64 * 1024 * 1024
BUNDLE_LINE_BYTES = 128 * 1024
# Do not export a log suffix without validating whether an earlier line
# opened a multiline credential. Above this bounded context window, omit the
# log instead of trusting an ambiguous partial snapshot.
BUNDLE_CONTEXT_SCAN_MAX_BYTES = 128 * 1024 * 1024
BUNDLE_MEMBERS = (
    ('Luna session log', 'logs/luna-session.log', BUNDLE_SESSION_BYTES),
    ('Previous Luna native session log', 'logs/luna-session-previous.log',
     BUNDLE_OTHER_BYTES),
    ('Kodi log', 'logs/kodi.log', BUNDLE_OTHER_BYTES),
    ('Previous Kodi log (launch preflight)', 'logs/kodi-previous.log',
     BUNDLE_OTHER_BYTES),
    ('Legacy native Moonlight log', 'logs/moonlight-legacy.log',
     BUNDLE_OTHER_BYTES),
    ('Native rolling diagnostics (previous)', 'logs/native-rolling-previous.log',
     BUNDLE_ROLLING_BYTES),
    ('Native rolling diagnostics (current)', 'logs/native-rolling-current.log',
     BUNDLE_ROLLING_BYTES),
    ('Prior native session identifier', 'logs/native-prior-session-id.txt', 4096),
    ('Prior native rolling diagnostics (previous)', 'logs/native-prior-previous.log',
     BUNDLE_ROLLING_BYTES),
    ('Prior native rolling diagnostics (current)', 'logs/native-prior-current.log',
     BUNDLE_ROLLING_BYTES),
)
# Redaction can expand a line (e.g. several short IPv4 values). Bound ZIP
# output separately from source bytes. All zip members have fixed names.
BUNDLE_OUTPUT_LIMITS = {
    'summary.txt': BUNDLE_SUMMARY_BYTES,
    'logs/kernel.log': BUNDLE_KERNEL_BYTES * 2,
    'logs/luna-session.log': BUNDLE_SESSION_BYTES * 3,
    'logs/luna-session-previous.log': BUNDLE_OTHER_BYTES * 3,
    'logs/kodi.log': BUNDLE_OTHER_BYTES * 3,
    'logs/kodi-previous.log': BUNDLE_OTHER_BYTES * 3,
    'logs/moonlight-legacy.log': BUNDLE_OTHER_BYTES * 3,
    'logs/native-rolling-previous.log': BUNDLE_ROLLING_BYTES * 3,
    'logs/native-rolling-current.log': BUNDLE_ROLLING_BYTES * 3,
    'logs/native-prior-session-id.txt': 4096,
    'logs/native-prior-previous.log': BUNDLE_ROLLING_BYTES * 3,
    'logs/native-prior-current.log': BUNDLE_ROLLING_BYTES * 3,
}
_PEM_BLOCK_BEGIN = re.compile(
    r'(?i)-----BEGIN [^\r\n-]*(?:PRIVATE KEY|CERTIFICATE)-----')
_XML_BLOCK_BEGIN = re.compile(
    r'(?i)<(' + _CREDENTIAL_FIELD + r')(?=[\s>/])')


def _advance_private_block(block, line):
    """Track complete multiline PEM/XML credential blocks."""
    if block:
        kind, name = block
        if kind == 'pem' and '-----END ' in line.upper():
            return None
        if kind == 'xml' and re.search(
                r'</\s*' + re.escape(name) + r'\s*>',
                line, re.IGNORECASE):
            return None
        return block
    pem = _PEM_BLOCK_BEGIN.search(line)
    if pem and not re.search(r'-----END ', line[pem.end():],
                             re.IGNORECASE):
        return ('pem', '')
    xml = _XML_BLOCK_BEGIN.search(line)
    if xml and not re.search(
            r'</\s*' + re.escape(xml.group(1)) + r'\s*>',
            line[xml.end():], re.IGNORECASE):
        return ('xml', xml.group(1))
    return None


def _private_block_before_offset(source, cutoff):
    """Rebuild credential context from complete preceding log records.

    If an oversized preceding record could conceal a block opener, abort
    rather than disclose a line which only looks safe in isolation.
    """
    if cutoff < 0 or cutoff > BUNDLE_CONTEXT_SCAN_MAX_BYTES:
        raise OSError('Log credential context exceeds bounded verification')
    source.seek(0)
    active = None
    while source.tell() < cutoff:
        chunk = source.readline(BUNDLE_LINE_BYTES + 1)
        if not chunk:
            break
        if len(chunk) > BUNDLE_LINE_BYTES:
            raise OSError('Oversized preceding log record hides credential context')
        active = _advance_private_block(
            active, chunk.decode('utf-8', 'replace').rstrip('\r\n'))
    return active


def _copy_redacted_lines(source, dest, byte_limit, output_limit,
                         initial_private_block=None):
    """Stream complete lines through redaction, preserving all normal samples.

    Never copy raw bytes. Omit oversize log records rather than emit potentially
    partial sensitive values; similarly suppress entire multiline PEM/XML
    credential blocks across read boundaries. Restrict both input and output.
    """
    left = byte_limit
    written = 0
    skipping_long_line = False
    private_block = initial_private_block
    copied = False

    def emit(message):
        nonlocal written
        payload = (message + '\n').encode('utf-8')
        if written + len(payload) > output_limit:
            raise OSError('Redacted diagnostic entry exceeds the size limit')
        dest.write(payload)
        written += len(payload)

    while left > 0:
        part = source.readline(min(left, BUNDLE_LINE_BYTES + 1))
        if not part:
            break
        left -= len(part)
        if skipping_long_line:
            if part.endswith(b'\n'):
                skipping_long_line = False
            continue
        if len(part) > BUNDLE_LINE_BYTES or (
                len(part) == BUNDLE_LINE_BYTES + 1 and not part.endswith(b'\n')):
            emit('[OVERSIZED LOG RECORD REDACTED]')
            copied = True
            skipping_long_line = not part.endswith(b'\n')
            continue
        line = part.decode('utf-8', 'replace').rstrip('\r\n')
        if private_block:
            kind, name = private_block
            if kind == 'pem' and '-----END ' in line.upper():
                private_block = None
            elif kind == 'xml' and re.search(
                    r'</\s*' + re.escape(name) + r'\s*>', line,
                    re.IGNORECASE):
                private_block = None
            continue
        pem = _PEM_BLOCK_BEGIN.search(line)
        if pem:
            emit('[PEM DATA REDACTED]')
            copied = True
            if not re.search(r'-----END ', line[pem.end():], re.IGNORECASE):
                private_block = ('pem', '')
            continue
        xml = _XML_BLOCK_BEGIN.search(line)
        if xml and not re.search(
                r'</\s*' + re.escape(xml.group(1)) + r'\s*>',
                line[xml.end():], re.IGNORECASE):
            emit('[XML CREDENTIAL BLOCK REDACTED]')
            copied = True
            private_block = ('xml', xml.group(1))
            continue
        emit(redact(line))
        copied = True
    if not copied:
        emit('(empty)')


def _archive_regular_log(archive, member, path, raw_limit, available=True):
    """Read only a no-follow regular file and explain any truncated window."""
    if not available:
        archive.writestr(member, '(not present in this session)\n')
        return 'not present'
    if path is None:
        archive.writestr(member, '(not configured)\n')
        return 'not configured'
    flags = os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0)
    flags |= getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
    try:
        fd = os.open(os.fspath(path), flags)
    except OSError:
        archive.writestr(member, '(not available: source could not be read safely)\n')
        return 'unavailable'
    with os.fdopen(fd, 'rb') as source:
        st = os.fstat(source.fileno())
        if not stat.S_ISREG(st.st_mode):
            archive.writestr(member, '(not available: source is not regular)\n')
            return 'unavailable'
        end = st.st_size
        start = max(0, end - raw_limit)
        if end > BUNDLE_CONTEXT_SCAN_MAX_BYTES:
            archive.writestr(
                member, '(omitted: log exceeds safe credential-context scan)\n')
            return 'omitted: credential context exceeds bounded scan limit'
        try:
            context = (_private_block_before_offset(source, start)
                       if start else None)
        except OSError:
            archive.writestr(
                member, '(omitted: cannot verify credential context safely)\n')
            return 'omitted: ambiguous credential context'
        source.seek(start)
        if start:
            source.seek(start - 1)
            aligned = source.read(1) == b'\n'
            source.seek(start)
            if not aligned:
                # Skip only the partial leading record. A huge record is
                # drained in bounded reads, never held in memory.
                remaining = end - start
                while remaining:
                    chunk = source.readline(min(remaining, BUNDLE_LINE_BYTES + 1))
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    if chunk.endswith(b'\n'):
                        break
        remaining = max(0, end - source.tell())
        with archive.open(member, 'w', force_zip64=True) as target:
            _copy_redacted_lines(
                source, target, remaining, BUNDLE_OUTPUT_LIMITS[member],
                initial_private_block=context)
        return ('last %d of %d source bytes (older bytes unavailable in '
                'this bundle)' % (end - start, end)) if start else (
                'all %d available source bytes' % end)

def create_report_bundle(data_dir, kodi_log=None, legacy_log=None,
                         kernel_output=None):
    """Create private ZIP: summary plus complete available *redacted* logs."""
    reports = _private_reports_directory(data_dir)
    now, sources, summary, kernel = _report_parts(
        data_dir, kodi_log, legacy_log, kernel_output)
    by_name = dict(sources)
    name = 'luna-diagnostics-' + now.strftime('%Y%m%d-%H%M%S')
    file_path = None
    try:
        fd, file_path = tempfile.mkstemp(prefix=name + '-', suffix='.zip',
                                         dir=reports)
        with os.fdopen(fd, 'w+b') as output:
            os.fchmod(output.fileno(), 0o600)
            with zipfile.ZipFile(
                    output, 'w', compression=zipfile.ZIP_DEFLATED,
                    compresslevel=1, allowZip64=True) as archive:
                notes = []
                for label, member, raw_limit in BUNDLE_MEMBERS:
                    state = _archive_regular_log(
                        archive, member, by_name.get(label), raw_limit,
                        available=label in by_name)
                    notes.append('%s: %s; source cap %d MiB' %
                                 (member, state, raw_limit // (1024 * 1024)))
                # The kernel source is already bounded and redacted by the
                # existing collector. Re-sanitize on export as for all entries.
                archive.writestr('logs/kernel.log', redact(kernel))
                contents = ('\n===== Archive coverage =====\n'
                            'Full available log lines are retained below their '
                            'source byte caps, with sensitive content redacted. '
                            'Unknown secret formats still require human review. '
                            'Oversized records may be suppressed.\n' +
                            '\n'.join(notes) + '\n')
                full_summary = (summary + contents).encode('utf-8')
                if len(full_summary) > BUNDLE_SUMMARY_BYTES:
                    # Retain the identifying header so ZIP export validation
                    # cannot reject a legitimate, unusually verbose summary.
                    prefix = b'Luna diagnostic report - LOCAL FILE ONLY\n'
                    notice = (b'(Readable digest capped at 4 MiB. '
                              b'Full redacted log members remain available.)\n')
                    remaining = BUNDLE_SUMMARY_BYTES - len(prefix) - len(notice)
                    tail = full_summary[-remaining:].decode(
                        'utf-8', 'replace').encode('utf-8')
                    full_summary = prefix + notice + tail[-remaining:]
                archive.writestr('summary.txt', full_summary)
            output.flush()
            os.fsync(output.fileno())
            if os.fstat(output.fileno()).st_size > BUNDLE_COMPRESSED_BYTES:
                raise OSError('Compressed diagnostic bundle exceeds size cap')
        directory_fd = os.open(reports, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            _prune_reports(directory_fd, Path(file_path).name)
        finally:
            os.close(directory_fd)
        return Path(file_path)
    except BaseException:
        if file_path is not None:
            Path(file_path).unlink(missing_ok=True)
        raise


def create_report(data_dir, kodi_log=None, legacy_log=None, kernel_output=None):
    """Default Luna report: a ZIP with summary and full available redacted logs."""
    return create_report_bundle(data_dir, kodi_log, legacy_log, kernel_output)


# Fail closed on Linux (CoreELEC) if directory-relative safety flags are
# unavailable. A verified fd survives pathname replacement by another process.
_EXPORT_DIR_FLAGS = (os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW |
                     getattr(os, 'O_CLOEXEC', 0))


def _open_or_create_directory_chain(path, create=True):
    """Walk the share path by fd, never following symlinks in any component."""
    folder = Path(path)
    current_fd = os.open('/' if folder.is_absolute() else '.', _EXPORT_DIR_FLAGS)
    try:
        for component in folder.parts:
            if component in ('/', '.', ''):
                continue
            if component == '..':
                raise OSError('Parent traversal is not allowed for Logfiles export')
            if create:
                try:
                    os.mkdir(component, mode=0o755, dir_fd=current_fd)
                except FileExistsError:
                    pass
            next_fd = os.open(component, _EXPORT_DIR_FLAGS, dir_fd=current_fd)
            os.close(current_fd)
            current_fd = next_fd
        return current_fd
    except BaseException:
        os.close(current_fd)
        raise


def _open_export_directory(share):
    """Return an owned Luna directory fd; do not reopen it by path."""
    share_fd = _open_or_create_directory_chain(share)
    try:
        root_info = os.fstat(share_fd)
        if (not stat.S_ISDIR(root_info.st_mode) or
                root_info.st_uid != os.geteuid()):
            raise OSError('Unsafe CoreELEC Logfiles root')
        try:
            os.mkdir('Luna', mode=0o755, dir_fd=share_fd)
        except FileExistsError:
            pass
        directory_fd = os.open('Luna', _EXPORT_DIR_FLAGS, dir_fd=share_fd)
        try:
            info = os.fstat(directory_fd)
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
                raise OSError('Unsafe CoreELEC Logfiles directory')
            os.fchmod(directory_fd, 0o755)  # Readable via CoreELEC's SMB share.
            return directory_fd
        except BaseException:
            os.close(directory_fd)
            raise
    finally:
        os.close(share_fd)


def _verify_export_destination(share, directory_fd, filename, expected_inode):
    """Check path still points at the pinned directory and published inode.

    A later rename is inherently possible when returning a pathname, but
    replacing it during export must not be silently reported as success.
    Read-only reopens never create or follow share-directory symlinks.
    """
    current_root = _open_or_create_directory_chain(share, create=False)
    try:
        try:
            current_luna = os.open('Luna', _EXPORT_DIR_FLAGS, dir_fd=current_root)
        except OSError as error:
            # A replaced directory may fail O_NOFOLLOW with ELOOP or ENOTDIR.
            # Both are the expected fail-closed directory-swap outcome.
            raise OSError('CoreELEC Logfiles/Luna directory changed during export') from error
        try:
            pinned = os.fstat(directory_fd)
            current = os.fstat(current_luna)
            if (pinned.st_dev != current.st_dev or
                    pinned.st_ino != current.st_ino):
                raise OSError('CoreELEC Logfiles/Luna directory changed during export')
            actual = os.stat(filename, dir_fd=current_luna,
                             follow_symlinks=False)
            if (not stat.S_ISREG(actual.st_mode) or
                    (actual.st_dev, actual.st_ino) != expected_inode):
                raise OSError('CoreELEC diagnostic destination changed during export')
        finally:
            os.close(current_luna)
    finally:
        os.close(current_root)


def _validate_bundle_zip(source):
    """Reject unbounded, unexpected or dangerous archive members.

    The user-facing export copies *only* the fixed text member list after
    re-redacting it, never arbitrary ZIP contents or stored file attributes.
    """
    expected = set(BUNDLE_OUTPUT_LIMITS)
    with zipfile.ZipFile(source, 'r') as archive:
        info = archive.infolist()
        if len(info) != len(expected) or {item.filename for item in info} != expected:
            raise OSError('Unexpected Luna diagnostic bundle members')
        for item in info:
            if (item.is_dir() or item.flag_bits & 1 or
                    (item.external_attr >> 16) & 0o170000 == stat.S_IFLNK or
                    item.file_size > BUNDLE_OUTPUT_LIMITS[item.filename] or
                    item.compress_size > BUNDLE_COMPRESSED_BYTES):
                raise OSError('Unsafe or oversized Luna diagnostic bundle member')
        with archive.open('summary.txt', 'r') as summary:
            if not summary.read(96).startswith(
                    b'Luna diagnostic report - LOCAL FILE ONLY\n'):
                raise OSError('Missing verified Luna diagnostic summary header')


def _repack_redacted_bundle(source, destination):
    """Re-redact each bounded entry before atomically exposing a ZIP on SMB."""
    source.seek(0)
    _validate_bundle_zip(source)
    source.seek(0)
    with zipfile.ZipFile(source, 'r') as original:
        with zipfile.ZipFile(
                destination, 'w', compression=zipfile.ZIP_DEFLATED,
                compresslevel=1, allowZip64=True) as safe:
            for member in BUNDLE_OUTPUT_LIMITS:
                info = original.getinfo(member)
                with original.open(info, 'r') as before:
                    with safe.open(member, 'w', force_zip64=True) as after:
                        _copy_redacted_lines(before, after, info.file_size,
                                             BUNDLE_OUTPUT_LIMITS[member])
    if destination.tell() > BUNDLE_COMPRESSED_BYTES:
        raise OSError('Redacted share bundle exceeded compressed size cap')


def export_report(report_path, logfiles_root=DEFAULT_LOGFILES_ROOT):
    """Re-sanitize and atomically publish a ZIP (or legacy TXT) via SMB.

    The source is owner-controlled and no-follow, the destination directory
    is held by descriptor, and every ZIP member is re-redacted and bounded.
    Neither source reports nor original logs are modified or uploaded.
    """
    source = Path(report_path)
    if not re.fullmatch(
            r'luna-diagnostics-[0-9]{8}-[0-9]{6}-[a-z0-9_]+\.(?:txt|zip)',
            source.name):
        raise OSError('Unexpected diagnostic filename')
    bundle = source.suffix == '.zip'
    flags = os.O_RDONLY | os.O_NONBLOCK | getattr(os, 'O_NOFOLLOW', 0)
    flags |= getattr(os, 'O_CLOEXEC', 0)
    fd = os.open(str(source), flags)
    with os.fdopen(fd, 'rb') as reader:
        metadata = os.fstat(reader.fileno())
        cap = BUNDLE_COMPRESSED_BYTES if bundle else 4 * 1024 * 1024
        if (not stat.S_ISREG(metadata.st_mode) or
                metadata.st_uid != os.geteuid() or metadata.st_nlink != 1 or
                metadata.st_size < 10 or metadata.st_size > cap):
            raise OSError('Invalid private diagnostic source')
        if bundle:
            try:
                _validate_bundle_zip(reader)
            except (zipfile.BadZipFile, EOFError, RuntimeError,
                    ValueError) as error:
                raise OSError('Invalid Luna diagnostic ZIP source') from error
            reader.seek(0)
            payload = None
        else:
            data = reader.read(4 * 1024 * 1024 + 1)
            if len(data) > 4 * 1024 * 1024:
                raise OSError('Private diagnostic source grew beyond size limit')
            prefix = 'Luna diagnostic report - LOCAL FILE ONLY\n'
            original = data.decode('utf-8', 'replace')
            if not original.startswith(prefix):
                raise OSError('Not a Luna diagnostic report')
            # Legacy TXT reports remain supported for already-created files.
            payload = (prefix + redact(original[len(prefix):])).encode('utf-8')

        share = Path(logfiles_root)
        destination = share / 'Luna'
        directory_fd = _open_export_directory(share)
        temporary = None
        try:
            # O_EXCL/O_NOFOLLOW and the still-open fd protect against
            # concurrent replacement via Samba during publication.
            temporary = '.luna-export-%s.tmp' % secrets.token_hex(16)
            out_flags = (os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW |
                         getattr(os, 'O_CLOEXEC', 0))
            out_fd = os.open(temporary, out_flags, 0o600,
                             dir_fd=directory_fd)
            with os.fdopen(out_fd, 'wb') as stream:
                if bundle:
                    try:
                        _repack_redacted_bundle(reader, stream)
                    except (zipfile.BadZipFile, EOFError, RuntimeError,
                            ValueError) as error:
                        raise OSError('Luna diagnostic ZIP failed validation') from error
                else:
                    stream.write(payload)
                stream.flush()
                os.fchmod(stream.fileno(), 0o644)
                os.fsync(stream.fileno())
                meta = os.fstat(stream.fileno())
                published_inode = (meta.st_dev, meta.st_ino)
                # Publish only after the entire re-sanitized archive is
                # durable; failure leaves an unlinked temporary, not a
                # partially visible report.
                os.link(temporary, source.name, src_dir_fd=directory_fd,
                        dst_dir_fd=directory_fd, follow_symlinks=False)
                os.unlink(temporary, dir_fd=directory_fd)
                temporary = None
                os.fsync(directory_fd)
                _verify_export_destination(share, directory_fd, source.name,
                                           published_inode)
                _prune_reports(directory_fd, source.name)
                return destination / source.name
        finally:
            try:
                if temporary is not None:
                    os.unlink(temporary, dir_fd=directory_fd)
            finally:
                os.close(directory_fd)


def show_in_kodi(path):
    """Show where the locally saved, redacted report is; no review reminder."""
    import xbmcgui
    xbmcgui.Dialog().ok(
        'Luna diagnostic report',
        'Saved redacted diagnostic ZIP (summary and full available logs) to:\n%s\n\n'
        'Windows: \\\\CoreELEC\\Logfiles\\Luna' % path)

def save_report_with_dialog(data_dir, kodi_log=None, legacy_log=None,
                            log_failure=None):
    """Common manual and early-exit path: preserve and report private files."""
    private = None
    try:
        private = create_report(data_dir, kodi_log=kodi_log,
                                legacy_log=legacy_log)
        exported = export_report(private)
    except (OSError, ValueError) as error:
        if log_failure is not None:
            log_failure(type(error).__name__)
        if private is None:
            message = ('Could not create the private diagnostic report. '
                       'Check available storage and permissions.')
        else:
            message = ('Private redacted report saved to:\n%s\n\n'
                       'Could not complete export to CoreELEC Logfiles. '
                       'Check available storage and share permissions.' % private)
        import xbmcgui
        xbmcgui.Dialog().ok('Luna diagnostics', message)
        return False
    show_in_kodi(exported)
    return True


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Write local Luna diagnostics; never upload')
    parser.add_argument('--data-dir', default='/storage/.kodi/userdata/addon_data/script.luna.ng')
    parser.add_argument('--kodi-log', default='/storage/.kodi/temp/kodi.log')
    parser.add_argument('--legacy-log')
    options = parser.parse_args()
    report = create_report(options.data_dir, options.kodi_log,
                           options.legacy_log)
    print(export_report(report))


if __name__ == '__main__':
    main()
