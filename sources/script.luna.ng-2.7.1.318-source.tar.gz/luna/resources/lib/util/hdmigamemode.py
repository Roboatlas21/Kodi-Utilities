"""Session-scoped HDMI ALLM with a durable snapshot for the Kodi watchdog."""
import json
import os
from pathlib import Path
import sys
import tempfile

if __package__:
    from resources.lib.util.safejson import read_bounded_json
else:
    # The launcher and watchdog may execute this file through an isolated
    # Python entry point with no Kodi package on sys.path.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from safejson import read_bounded_json


CONTENT_TYPES = {'off', 'game', 'graphics', 'photo', 'cinema'}


def safe_state_file(path):
    """Reject any recovery journal that is a symlink or non-regular file."""
    state = Path(path)
    if state.is_symlink():
        raise ValueError('HDMI Game Mode journal must not be a symlink')
    if state.exists() and not state.is_file():
        raise ValueError('HDMI Game Mode journal is not a regular file')
    return state


def read(root, name):
    return (root / name).read_text().strip()


def write(root, name, value):
    (root / name).write_text(value + '\n')


def restore(state_file, expected_root=None):
    state_file = safe_state_file(state_file)
    try:
        saved, metadata, raw = read_bounded_json(
            state_file, 4096, allow_empty=True, with_bytes=True)
    except FileNotFoundError:
        return
    # Only the genuinely empty launcher-created sentinel means no ALLM was
    # applied. A nonempty JSON "null" is a corrupt recovery journal.
    if not raw:
        return
    if (not isinstance(saved, dict) or saved.get('schema') != 1 or
            saved.get('allm') != '0' or
            saved.get('content') not in CONTENT_TYPES or
            not isinstance(saved.get('root'), str)):
        raise ValueError('Invalid HDMI state snapshot')
    root = Path(saved['root'])
    # Recovery JSON cannot redirect sysfs writes to an unrelated directory.
    if expected_root is not None and root != Path(expected_root):
        raise ValueError('HDMI recovery path differs from the trusted output')
    current = read(root, 'allm_mode')
    content = read(root, 'contenttype_mode')
    if current not in ('0', '1'):
        raise ValueError('Unexpected HDMI ALLM state during restore')
    if content != saved['content']:
        print('Luna NG: HDMI content mode changed externally; leaving it unchanged')
        if current == '1':
            # A different content hint is not proof that Moonlight's ALLM
            # request was undone. Avoid overwriting the external change,
            # but keep the snapshot until ALLM is confirmed disabled.
            raise OSError('HDMI ALLM still enabled after external content change')
    else:
        # This CoreELEC setter clears ALLM and restores the AVI content hint
        # in one write. Setting allm_mode=0 alone would leave the content hint
        # cleared by ALLM activation, despite its stale sysfs readback.
        write(root, 'contenttype_mode', saved['content'])
        if read(root, 'allm_mode') != '0' or read(root, 'contenttype_mode') != saved['content']:
            raise OSError('HDMI state restoration was not confirmed')
        print('Luna NG: restored HDMI Game Mode signalling before returning to Kodi')
    state_file.unlink()


def enable(state_file, hdmi_root='/sys/class/amhdmitx/amhdmitx0'):
    state_file = safe_state_file(state_file)
    root = Path(hdmi_root)
    if read(root, 'allm_cap') != '1':
        print('Luna NG: connected display does not advertise ALLM; Game Mode skipped')
        return
    original = read(root, 'allm_mode')
    if original == '1':
        print('Luna NG: HDMI ALLM already enabled; preserving the existing setting')
        return
    content = read(root, 'contenttype_mode')
    if original != '0' or content not in CONTENT_TYPES:
        raise ValueError('Unexpected HDMI state; Game Mode skipped')
    # The launcher pre-creates an empty recovery marker. Never overwrite
    # a populated journal from an earlier, unfinished restoration.
    if state_file.exists() and state_file.stat().st_size:
        raise ValueError('Unretired HDMI Game Mode journal blocks a new request')
    saved = {'schema': 1, 'root': str(root), 'allm': original, 'content': content}
    temporary = None
    try:
        fd, temporary = tempfile.mkstemp(
            dir=str(state_file.parent), prefix='.luna-allm-', suffix='.pending')
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(saved, stream, separators=(',', ':'))
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        # Atomic replacement does not follow a target symlink.
        os.replace(temporary, state_file)
        directory = os.open(str(state_file.parent), os.O_RDONLY |
                            getattr(os, 'O_DIRECTORY', 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temporary is not None:
            Path(temporary).unlink(missing_ok=True)
    try:
        write(root, 'allm_mode', '1')
        if read(root, 'allm_mode') != '1':
            raise OSError('HDMI ALLM activation was not confirmed')
    except (OSError, ValueError):
        # A damaged local snapshot must never redirect rollback into an
        # untrusted HDMI directory, even on the error path.
        restore(state_file, root)
        raise
    print('Luna NG: requested TV Game Mode using HDMI ALLM')


if __name__ == '__main__':
    try:
        if len(sys.argv) == 4 and sys.argv[1] == 'enable':
            enable(sys.argv[2], sys.argv[3])
        elif len(sys.argv) == 3 and sys.argv[1] == 'restore':
            restore(sys.argv[2], os.environ.get(
                'LUNA_HDMI_ROOT', '/sys/class/amhdmitx/amhdmitx0'))
        else:
            raise ValueError('Usage: hdmigamemode.py enable STATE HDMI_ROOT | restore STATE')
    except (OSError, ValueError, KeyError, TypeError) as error:
        print('Luna NG: HDMI Game Mode: %s' % error, file=sys.stderr)
        sys.exit(1)
