"""Safe Luna NG loader preflight, run before Kodi or its audio is suspended.

Checks installed bytes against the manifest, then invokes 'moonlight help' to
verify the executable loader and its direct/transitive DT_NEEDED libraries.
Does not start a stream or initialize hardware; probes the selected decoder.
"""
import hashlib
import json
import os
import re
import struct
import subprocess
import time
from resources.lib.util.safefile import read_regular_bytes

class NativeRuntimeError(RuntimeError):
    pass

REQUIRED = {
    "bin/coreelec-ng/moonlight",
    "lib/coreelec-ng/libmoonlight-aml.so",
    "lib/coreelec-ng/libgamestream.so.4",
    "lib/coreelec-ng/libmoonlight-common.so.4",
    "lib/coreelec-ng/libcec.so.6",
}
ASSETS = {"bin/coreelec-ng/gamecontrollerdb.txt"}
FIRST_VIDEO_CAPABILITY = "first-video-ready-v1"
FIRST_VIDEO_BIN_TOKEN = b"LUNA_NATIVE_FIRST_VIDEO_READY_V1"
FIRST_VIDEO_AML_TOKEN = b"MOONLIGHT_VIDEO_READY_FILE"

def check_ng_runtime(addon_path, executable, env=None, check_loader=True,
                     on_timing=None):
    """Verify every launch as before; optionally report timing, never cache it."""
    timing_start = timing_prev = time.monotonic()

    def timing(stage):
        nonlocal timing_prev
        if on_timing is None:
            return
        now = time.monotonic()
        try:
            on_timing(stage, max(0, round((now - timing_prev) * 1000)),
                      max(0, round((now - timing_start) * 1000)))
        except Exception:
            # Diagnostics must never turn a valid native preflight into a failure.
            pass
        timing_prev = now

    root = os.path.abspath(addon_path)
    expected = os.path.join(root, "bin", "coreelec-ng", "moonlight")
    # Do not impose the NG package contract on a system-installed binary
    # or the existing CoreELEC NO/AArch64 release.
    if os.path.abspath(executable) != expected:
        return False
    location = os.path.join(root, "runtime-manifest.json")
    try:
        raw, _ = read_regular_bytes(location, 128 * 1024)
        manifest = json.loads(raw.decode("utf-8"))
    except (OSError, ValueError) as exc:
        raise NativeRuntimeError("Missing or malformed NG runtime manifest") from exc
    if not isinstance(manifest, dict) or (
        manifest.get("schema") != "luna-ng-runtime-v1" or
        manifest.get("target") != "Amlogic-ce/Amlogic-ng/arm"
    ):
        raise NativeRuntimeError("Wrong CoreELEC NG runtime manifest")
    if manifest.get("capabilities") != [FIRST_VIDEO_CAPABILITY]:
        raise NativeRuntimeError(
            "NG native bundle lacks first-video-ready-v1; install a matching newer ARM32 build")
    source_revision = manifest.get("source_git_sha")
    if (not isinstance(source_revision, str) or
            not re.fullmatch(r"[a-f0-9]{40}", source_revision)):
        raise NativeRuntimeError("NG native runtime source revision is unknown or invalid")
    objects = manifest.get("objects")
    assets = manifest.get("assets")
    if (not isinstance(objects, dict) or set(objects) != REQUIRED or
            not isinstance(assets, dict) or set(assets) != ASSETS):
        raise NativeRuntimeError("NG native artifact files do not match manifest")
    timing('manifest')
    native_support = aml_support = False
    for mapping in (objects, assets):
        for name, entry in mapping.items():
            if not isinstance(entry, dict) or not re.fullmatch(r"[a-f0-9]{64}", str(entry.get("sha256"))):
                raise NativeRuntimeError("Invalid native hash entry: " + name)
            size = entry.get("size")
            # Fixed package contents: cap each object and never retain more than
            # one object. Reject growth beyond the declared size during the read.
            limit = 64 * 1024 * 1024 if name in REQUIRED else 8 * 1024 * 1024
            if type(size) is not int or not 0 < size <= limit:
                raise NativeRuntimeError("Invalid native file size: " + name)
            path = os.path.join(root, *name.split("/"))
            try:
                data, _ = read_regular_bytes(path, size)
            except FileNotFoundError as exc:
                raise NativeRuntimeError("Missing native file: " + name) from exc
            except (OSError, ValueError) as exc:
                raise NativeRuntimeError("Unsafe native file or checksum mismatch: " + name) from exc
            if len(data) != size or hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise NativeRuntimeError("Native file checksum mismatch: " + name)
            if name in REQUIRED:
                header = data[:52]
                if (len(header) < 52 or header[:6] != b"\x7fELF\x01\x01" or
                        struct.unpack_from("<H", header, 18)[0] != 40):
                    raise NativeRuntimeError("Not a CoreELEC NG ARM32 ELF: " + name)
            if name == "bin/coreelec-ng/moonlight":
                native_support = FIRST_VIDEO_BIN_TOKEN in data
            elif name == "lib/coreelec-ng/libmoonlight-aml.so":
                aml_support = FIRST_VIDEO_AML_TOKEN in data
            del data
    if not native_support or not aml_support:
        raise NativeRuntimeError(
            "NG native executable or AML library lacks first-video-ready-v1 implementation")
    timing('file-hashes')
    if check_loader:
        interp = objects["bin/coreelec-ng/moonlight"].get("interpreter")
        if not isinstance(interp, str) or not interp.startswith("/"):
            raise NativeRuntimeError("Invalid dynamic loader path")
        if not os.path.isfile(interp):
            raise NativeRuntimeError("Required ARM32 dynamic loader not installed: " + interp)
    try:
        completed = subprocess.run(
            [expected, "help"], cwd=os.path.dirname(expected), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            errors="replace", timeout=6, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise NativeRuntimeError("Moonlight loader smoke test failed") from exc
    if completed.returncode != 0 or "Moonlight Embedded" not in completed.stdout:
        # Omit full stdout; it may include host or local environment details.
        raise NativeRuntimeError(
            "Moonlight help failed (exit %d); verify external ARM32 libraries" %
            completed.returncode)
    if "LUNA_NATIVE_FIRST_VIDEO_READY_V1" not in completed.stdout.splitlines():
        raise NativeRuntimeError(
            "Moonlight native executable does not advertise first-video-ready-v1; "
            "rebuild the ARM32 native package before stopping Kodi")
    timing('native-help')
    # VFM has its own dependency preflight in vfmruntime; AML's vendor
    # library is not used by that pipeline.
    if (env if env is not None else os.environ).get("MOONLIGHT_VIDEO_PIPELINE") == "aml-vfm":
        return True
    # Help never dlopens the AML decoder. Check its required entry points
    # without touching hardware BEFORE handing the display away from Kodi.
    try:
        decoder = subprocess.run(
            [expected, "check-aml"], cwd=os.path.dirname(expected), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            errors="replace", timeout=6, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise NativeRuntimeError("AML decoder dependency preflight failed") from exc
    if (decoder.returncode != 0 or
            "AML decoder dependencies ready" not in (decoder.stdout or "")):
        # The native check-aml action deliberately does not load host settings
        # or contact the host. Show only its AML-specific error line; do not
        # echo arbitrary subprocess output into a Kodi dialog or persistent log.
        detail = ""
        for line in (decoder.stdout or "").splitlines():
            line = line.strip()
            if line.startswith("AML: "):
                detail = "".join(ch for ch in line if ch.isprintable())[:240]
                break
        message = ("AML decoder dependencies or callbacks are unavailable; "
                   "Kodi was not stopped (native exit %s)" % decoder.returncode)
        if detail:
            message += "\n" + detail
        raise NativeRuntimeError(message)
    timing('aml-check')
    return True


def check_stream_geometry(snapshot, pipeline):
    """Reject deterministic decoder failures before Kodi/display handoff."""
    if pipeline not in ('aml', 'aml-vfm'):
        return
    import configparser
    from resources.lib.util.safefile import read_regular_bytes
    from resources.lib.util.nativeini import MAX_BYTES
    parser = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        raw, _ = read_regular_bytes(snapshot, MAX_BYTES)
        parser.read_string(raw.decode('utf-8'))
        width, height, fps = (parser.getint('Moonlight', k) for k in ('width', 'height', 'fps'))
        rotation = parser.getint('Moonlight', 'rotate', fallback=0)
        codec = parser.get('Moonlight', 'codec', fallback='auto').strip().lower()
    except (OSError, UnicodeError, ValueError, configparser.Error) as error:
        raise ValueError('Cannot validate the AML stream configuration.') from error
    if rotation:
        raise ValueError('AML video does not support display rotation; set rotate=0 in moonlight.conf.')
    if pipeline == 'aml':
        return
    if codec == 'av1':
        raise ValueError('AML-VFM supports H.264/HEVC without rotation; disable AV1/rotation.')
    if not (2 <= width <= 4096 and 2 <= height <= 2160 and
            width % 2 == height % 2 == 0 and 1 <= fps <= 120):
        raise ValueError('AML-VFM requires even dimensions up to 4096x2160 and 1–120 FPS.')
