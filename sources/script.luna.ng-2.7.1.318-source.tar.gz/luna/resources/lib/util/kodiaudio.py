"""Verify Kodi's audio keepalive write before discarding saved recovery."""
import json

KEEPALIVE_SETTING = 'audiooutput.streamsilence'
PENDING_SETTING = 'saved_streamsilence'


def _request(method, params):
    import xbmc
    try:
        payload = {'jsonrpc': '2.0', 'id': 1,
                   'method': method, 'params': params}
        response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if (not isinstance(response, dict) or response.get('id') != 1 or
                'error' in response):
            return None
        return response.get('result')
    except Exception:
        # Kodi Python bindings can throw implementation-specific exceptions.
        # Recovery must never abort an otherwise usable plugin action.
        return None


def kodi_setting(name, value=None):
    """Read the setting or return True only for an acknowledged Kodi write."""
    if value is None:
        result = _request('Settings.GetSettingValue', {'setting': name})
        return result['value'] if isinstance(result, dict) and 'value' in result else None
    result = _request('Settings.SetSettingValue',
                      {'setting': name, 'value': value})
    return result == 'OK' or result is True


def restore_saved_streamsilence(plugin):
    """Retain a saved keepalive until a matching Kodi readback succeeds."""
    try:
        raw = plugin.getSetting(PENDING_SETTING)
        if not raw:
            return True
        if not isinstance(raw, str) or not raw.isdecimal() or len(raw) > 9:
            return False
        expected = int(raw)
        actual = kodi_setting(KEEPALIVE_SETTING)
        if type(actual) is not int or actual != expected:
            if not kodi_setting(KEEPALIVE_SETTING, expected):
                return False
            actual = kodi_setting(KEEPALIVE_SETTING)
            if type(actual) is not int or actual != expected:
                return False
        plugin.setSettingString(PENDING_SETTING, '')
        return True
    except Exception:
        # The backup stays intact when Kodi or the settings API is unavailable.
        return False
