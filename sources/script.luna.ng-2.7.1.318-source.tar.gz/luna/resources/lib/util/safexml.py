"""Safe, bounded settings.xml persistence shared by Kodi and detached Luna."""
import stat
from xml.etree import ElementTree

# Support the detached Resume helper's standalone Python invocation as
# well as ordinary Kodi imports through resources.lib.util.
if __package__:
    from resources.lib.util.safefile import read_regular_bytes
else:
    from safefile import read_regular_bytes

MAX_SETTINGS_BYTES = 8 * 1024 * 1024


def read_settings_tree(path):
    """Return (ElementTree, file mode) using one bounded, regular-file fd."""
    raw, info = read_regular_bytes(path, MAX_SETTINGS_BYTES)
    try:
        root = ElementTree.fromstring(raw)
    except (ElementTree.ParseError, ValueError, UnicodeError,
            RecursionError) as error:
        raise ValueError('Kodi settings XML is invalid') from error
    if root.tag != 'settings':
        raise ValueError('Unexpected Kodi settings root')
    return ElementTree.ElementTree(root), stat.S_IMODE(info.st_mode)


def serialize_settings_tree(tree):
    """Never publish settings.xml larger than its own safe reader accepts."""
    try:
        data = ElementTree.tostring(tree.getroot(), encoding='utf-8')
    except (ValueError, UnicodeError, RecursionError) as error:
        raise ValueError('Cannot serialize Kodi settings safely') from error
    if len(data) > MAX_SETTINGS_BYTES:
        raise ValueError('Kodi settings XML exceeds the safe size limit')
    return data
