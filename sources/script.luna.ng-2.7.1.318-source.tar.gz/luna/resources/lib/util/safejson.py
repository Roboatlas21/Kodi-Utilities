"""Read local Kodi JSON state from one bounded, nonblocking regular-file fd."""
import json
import errno
import os
import stat


class UnsafeJsonFile(ValueError):
    """An existing JSON file is unsafe, oversized or invalid."""


# A state file should not require Python's recursion limit to protect JSON
# decoding. This also avoids accepting deeply nested input when another part
# of Kodi has raised that process-wide limit.
MAX_JSON_NESTING = 64


def _check_json_nesting(text):
    """Reject overly nested containers without counting quoted brackets.

    This is a bounded, nonrecursive lexical check; json.loads remains the
    authority for valid string escapes, balanced delimiters and JSON syntax.
    """
    depth = 0
    quoted = False
    escaped = False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in '[{':
            depth += 1
            if depth > MAX_JSON_NESTING:
                raise UnsafeJsonFile('JSON nesting exceeds safe limit')
        elif char in ']}':
            depth -= 1
            if depth < 0:
                raise UnsafeJsonFile('JSON container is not balanced')


def read_bounded_json(path, maximum_bytes, with_stat=False, allow_empty=False, with_bytes=False):
    """Read JSON with the file metadata from the same opened inode.

    FileNotFoundError is reserved for a genuinely missing first-run file.
    Existing symlinks, FIFOs, oversized and corrupt files fail closed.
    """
    if not isinstance(maximum_bytes, int) or maximum_bytes <= 0:
        raise ValueError('Invalid JSON file size limit')
    path = os.fspath(path)
    flags = (os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW |
             getattr(os, 'O_CLOEXEC', 0))
    try:
        fd = os.open(path, flags)
    except FileNotFoundError as error:
        if os.path.lexists(path):
            raise UnsafeJsonFile('Existing JSON path cannot be opened') from error
        raise
    except OSError as error:
        if error.errno in (errno.ELOOP, errno.ENXIO):
            raise UnsafeJsonFile('JSON file cannot be opened safely') from error
        raise
    try:
        with os.fdopen(fd, 'rb') as source:
            metadata = os.fstat(source.fileno())
            if not stat.S_ISREG(metadata.st_mode):
                raise UnsafeJsonFile('JSON source is not a regular file')
            if metadata.st_size < 0 or metadata.st_size > maximum_bytes:
                raise UnsafeJsonFile('JSON file exceeds its size limit')
            raw = source.read(maximum_bytes + 1)
    except OSError as error:
        if error.errno == errno.EISDIR:
            raise UnsafeJsonFile('JSON source is not a regular file') from error
        raise  # I/O failure is not evidence of malformed JSON.
    if len(raw) > maximum_bytes:
        raise UnsafeJsonFile('JSON file grew beyond its size limit')
    if allow_empty and not raw:
        return (None, metadata, raw) if with_bytes else ((None, metadata) if with_stat else None)
    try:
        text = raw.decode('utf-8')
        _check_json_nesting(text)
        document = json.loads(text)
    except UnsafeJsonFile:
        raise
    except (ValueError, UnicodeError, RecursionError) as error:
        raise UnsafeJsonFile('JSON source is invalid') from error
    return (document, metadata, raw) if with_bytes else ((document, metadata) if with_stat else document)
