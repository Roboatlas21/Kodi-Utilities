import configparser
import io
import os
import struct
import tempfile
import fcntl
import stat
import xbmcaddon

from resources.lib.util import audiodevices
from resources.lib.util import inputdevices
from resources.lib.util.safelock import locked_regular_file

class MoonlightConfigFormatError(ValueError):
    """An existing moonlight.conf cannot be safely read as sectioned INI."""

    def __init__(self, path, reason):
        self.path = os.fspath(path)
        self.reason = reason
        super().__init__('Moonlight configuration requires recovery: ' + reason)

    def recovery_message(self):
        return (
            'Luna found an older or invalid moonlight.conf (%s) at:\n%s\n\n'
            'The file has NOT been changed. Rename moonlight.conf to '
            'moonlight.conf.backup using SSH or a file manager, then reopen '
            'Luna and check the Sunshine host in Settings. '
            'Luna will create a new file with a [Moonlight] section. '
            'Do not delete your backup.' % (self.reason, self.path))


class MoonlightSettingsError(MoonlightConfigFormatError):
    """A rejected settings edit leaves the previously valid file intact."""
    def recovery_message(self):
        return ('The new Moonlight settings are invalid (%s). The previous '
                'configuration was preserved. Open Luna Settings and correct '
                'the value before launching again.' % self.reason)


class ConfigHelper:
    config_path = None
    addon_path = None
    binary_path = None
    launchscripts_path = None
    logger = None
    plugin = None
    config = {}

    def __init__(self, plugin, logger):
        self.plugin = plugin
        # Kodi's getAddonInfo('path') may or may not include a trailing
        # separator. Multiple Luna callers append paths directly.
        self.addon_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), '')
        self.logger = logger
        self._reset()
        self.config_error = None
        # Kodi's plug-in module is imported before we can show a dialog.
        # Remember a legacy/malformed configuration instead of crashing at
        # import time; the Kodi entrypoint displays a recovery message.
        try:
            self.configure(False)
        except MoonlightConfigFormatError as error:
            self.config_error = error


    @staticmethod
    def _launcher_path(addon_root):
        """One safe launcher route; extend this resolver for future platforms.

        The systemd-based CoreELEC launcher supports the current NG handoff.
        Historical user-selected script names must never choose executable
        code. CoreELEC 22 can add an explicit runtime target here later.
        """
        return os.path.join(addon_root, 'resources', 'launchscripts', 'coreelec', '')

    def _reset(self):
        for elem in self.config:
            self.config[elem] = None

    def configure(self, dump=True):
        self.binary_path = self._find_binary(self.addon_path, logger=self.logger)

        # get_path("moonlight.conf") checks Moonlight's CWD first. Kodi uses
        # the bundled architecture-specific binary directory as that CWD.
        # /etc/moonlight.conf is not one of get_path()'s default paths.
        bundled_bin = os.path.join(self.addon_path, 'bin')
        managed = (self.binary_path is not None and
                   os.path.commonpath((bundled_bin,
                                       os.path.abspath(self.binary_path))) == bundled_bin)
        if managed:
            self.config_path = os.path.join(self.binary_path, 'moonlight.conf')
        elif os.access('/etc', os.W_OK):
            self.config_path = '/etc/moonlight.conf'
        elif self.binary_path is not None and os.access(self.binary_path, os.W_OK):
            self.config_path = self.binary_path + 'moonlight.conf'
        else:
            self.logger.info('Moonlight binary could not be found. Configuration file saved at %s' % self.addon_path)
            self.config_path = self.addon_path + 'moonlight.conf'
        
        self.launchscripts_path = self._launcher_path(self.addon_path)

        self.config = {
            'host_addr':                    self.plugin.getSetting('host_addr'),
            'resolution':                   self.plugin.getSetting('resolution'),
            'resolution_width':             self.plugin.getSetting('resolution_width'),
            'resolution_height':            self.plugin.getSetting('resolution_height'),
            'codec':                        self.plugin.getSetting('codec'),
            'bitrate':                      self.plugin.getSettingInt('bitrate'),
            'framerate':                    self.plugin.getSetting('framerate'),
            'surround':                     self.plugin.getSetting('surround'),
            'audio_device_parameter':       self.plugin.getSetting('audio_device_parameter'),
            'packetsize':                   self.plugin.getSettingInt('packetsize'),
            'gamepad_mouse':                self.plugin.getSetting('gamepad_mouse'),
            'cec':                          self.plugin.getSetting('cec'),
            'hdr_flag':                     self.plugin.getSetting('hdr_flag'),
            'remote_optimizations':         self.plugin.getSetting('remote_optimizations'),
            'local_audio':                  self.plugin.getSetting('local_audio'),
            'debug_mode':                   self.plugin.getSetting('debug_mode'),
            'osd':                          self.plugin.getSetting('osd'),
            'frametime_graph':              self.plugin.getSetting('frametime_graph'),
            'osd_font_size':                self.plugin.getSetting('osd_font_size'),
            'osd_position':                 self.plugin.getSetting('osd_position'),
            'osd_top':                      self.plugin.getSetting('osd_top'),
            'osd_interval':                 self.plugin.getSetting('osd_interval'),
        }

        # Keep the saved SDR codec/HDR preference intact. Only the effective
        # session configuration changes: both AML and VFM HDR need HEVC
        # Main10 even if the saved SDR codec is H.264.
        hdr_enabled = self.config['hdr_flag'] == 'true'
        self.config['hdr_flag'] = 'true' if hdr_enabled else 'false'
        if hdr_enabled:
            self.config['codec'] = 'h265'

        # Always validate the file, even when Kodi already has a saved host.
        # A legacy flat file is never allowed to reach the native client or
        # the atomic writer as though it were valid sectioned configuration.
        existing = self._read_sectioned_conf()
        self.config_error = None
        # Kodi is the authoritative destination once the one-time migration
        # has completed. In particular, a deliberate empty host must NOT
        # resurrect an old address from moonlight.conf on the next invocation.
        # Only import legacy native settings when this Kodi setting has never
        # been initialized; migrate the value into Kodi as well as memory.
        if self.plugin.getSetting('host_addr_initialized') != 'true':
            if not self.config['host_addr']:
                # ConfigParser.get() inherits [DEFAULT]; only the explicit
                # [Moonlight] address is eligible for migration.
                explicit = existing._sections.get('Moonlight', {})
                imported = (explicit.get('address') or '').strip()
                if imported:
                    self.config['host_addr'] = imported
                    self.plugin.setSettingString('host_addr', imported)
            self.plugin.setSettingBool('host_addr_initialized', True)

        if dump:
            self._dump_conf()

    def _read_sectioned_conf(self):
        """Read modern INI only; leave existing invalid bytes untouched."""
        from resources.lib.util.nativeini import (
            MAX_BYTES, NativeIniError, validate_and_mask_inputs)
        # Native Moonlight rejects symlinks, directories, and FIFOs; Python's
        # normal open() could block indefinitely on a FIFO. Read bounded bytes
        # from one no-follow/nonblocking descriptor before parsing or writing.
        parsed = configparser.ConfigParser(strict=True, interpolation=None)
        try:
            flags = (os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0) |
                     getattr(os, 'O_NOFOLLOW', 0) |
                     getattr(os, 'O_CLOEXEC', 0))
            fd = os.open(self.config_path, flags)
            with os.fdopen(fd, 'rb') as source:
                metadata = os.fstat(source.fileno())
                if not stat.S_ISREG(metadata.st_mode):
                    raise NativeIniError('configuration is not a regular file')
                if metadata.st_size < 0 or metadata.st_size > MAX_BYTES:
                    raise NativeIniError('oversized INI file')
                raw = source.read(MAX_BYTES + 1)
            if len(raw) > MAX_BYTES or any(
                    (byte < 32 and byte not in (9, 10, 13)) or byte == 127
                    for byte in raw):
                raise NativeIniError('oversized or malformed native INI file')
            rendered = validate_and_mask_inputs(
                raw.decode('utf-8'), inputdevices.MAX_ACTIVE_INPUT_PATHS)
            parsed.read_file(io.StringIO(rendered))
        except FileNotFoundError as error:
            # A disappeared/dangling entry is not a safe first-launch file.
            if os.path.lexists(self.config_path):
                raise MoonlightConfigFormatError(
                    self.config_path, 'configuration cannot be read') from error
            pass
        except NativeIniError as error:
            raise MoonlightConfigFormatError(
                self.config_path, str(error)) from error
        except configparser.MissingSectionHeaderError as error:
            raise MoonlightConfigFormatError(
                self.config_path, 'missing [Moonlight] section / sectionless format'
            ) from error
        except configparser.Error as error:
            raise MoonlightConfigFormatError(
                self.config_path, 'malformed INI file') from error
        except UnicodeError as error:
            raise MoonlightConfigFormatError(
                self.config_path, 'invalid text encoding') from error
        except OSError as error:
            raise MoonlightConfigFormatError(
                self.config_path, 'file cannot be read') from error
        return parsed

    def _osd_args(self):
        args = [
            '-font-size', self.config['osd_font_size'] or '20',
            '-y', self.config['osd_top'] or '40',
            '-interval', self.config['osd_interval'] or '1.5',
        ]

        if self.config['osd_position'] == 'left':
            args += ['-x', '20']

        if self.config['debug_mode'] == 'true':
            args += ['-log']

        # The per-frame overlay is an explicit diagnostic view, never
        # enabled for normal streaming or OSD-off sessions.
        if self.config['osd'] == 'true' and self.config['frametime_graph'] == 'true':
            args += ['-frametime']

        return ' '.join(args)

    def dump(self):
        self._dump_conf()

    def _dump_conf(self):
        # Guard read/modify/write as one transaction across Kodi invocations.
        # The file itself is atomically replaced, so readers never see a
        # truncated configuration even if they do not take the lock.
        with locked_regular_file(self.config_path + '.lock'):
            return self._dump_conf_locked()

    def _dump_conf_locked(self):
        # Revalidate while holding the same writer lock: stale Kodi settings
        # must never overwrite a sectionless/invalid pre-existing config.
        config = self._read_sectioned_conf()

        if 'Moonlight' not in config.sections():
            config.add_section('Moonlight')

        # App IDs are per-launch identity, never persistent configuration.
        # A stale appid could silently override a newer name-only launch.
        config.remove_option('Moonlight', 'input')
        config.remove_option('Moonlight', 'appid')
        # Explicit managed dimensions must not be overridden by native presets.
        for preset in ('720', '1080', '4k'):
            config.remove_option('Moonlight', preset)
        # Legacy opt-in has been retired: newer native builds auto-detect
        # compatible DualSense HID devices, so an old "false" must not persist.
        config.remove_option('Moonlight', 'dualsensehid')

        if self.config['host_addr']:
            config.set('Moonlight', 'address', self.config['host_addr'])
        else:
            config.remove_option('Moonlight', 'address')
        
        resolution_width = '1280'
        resolution_height = '720'
        if self.config['resolution'] == 'Custom':
            resolution_width = self.config['resolution_width']
            resolution_height = self.config['resolution_height']
        else:
            res = self.config['resolution'].split('x')
            resolution_width = res[0]
            resolution_height = res[1]

        config.set('Moonlight', 'width', resolution_width)
        config.set('Moonlight', 'height', resolution_height)
        
        
        config.set('Moonlight', 'fps', self.config['framerate'])

        config.set('Moonlight', 'bitrate', str(self.config['bitrate'] * 1000))
        config.set('Moonlight', 'packetsize', str(self.config['packetsize']))
        config.set('Moonlight', 'sops', 'false')
        config.set('Moonlight', 'remote', self.config['remote_optimizations'])
        config.set('Moonlight', 'localaudio', self.config['local_audio'])
        config.set('Moonlight', 'debug', self.config['debug_mode'])
        
        multichannel = True

        if self.config['local_audio'] == 'true':
            config.remove_option('Moonlight', 'audio')
        else:
            device = self.config['audio_device_parameter']

            # Existing, explicitly selected endpoints do not require a
            # fresh aplay/fuser scan for every game launch. The real native
            # ALSA open still rejects an unavailable endpoint rather than
            # silently switching hardware. The audio picker always rescans.
            devices = audiodevices.list_playback() if not device else []
            known = dict((d['alsa'], d['name']) for d in devices)

            # Enumeration is incomplete for custom ALSA aliases and transient
            # devices. Preserve explicit user choices; native ALSA reports an
            # unavailable endpoint instead of silently routing audio elsewhere.

            if not device:
                device = audiodevices.default_device(devices)
                if device:
                    self.plugin.setSettingString('audio_device_parameter', device)
            if device:
                self.plugin.setSettingString('audio_device_display',
                                             known.get(device,
                                                       self.plugin.getSetting('audio_device_display')
                                                       or device))
                multichannel = audiodevices.multichannel(device)
                self.plugin.setSettingString(
                    'audio_multichannel', 'true' if multichannel else 'false')
                config.set('Moonlight', 'audio', device)
            else:
                config.remove_option('Moonlight', 'audio')

        config.set('Moonlight', 'codec', self.config['codec'])
        surround = self.config['surround']
        if self.config['local_audio'] != 'true':
            surround = audiodevices.supported_surround(device, surround)
        if surround != self.config['surround']:
            self.plugin.setSettingString('surround', surround)
            self.config['surround'] = surround
        if surround != 'false' and multichannel is not False:
            config.set('Moonlight', 'surround', surround)
        else:
            config.remove_option('Moonlight', 'surround')
        
        config.set('Moonlight', 'nounsupported', 'false')
        gamepad_mouse = self.config['gamepad_mouse'] != 'false'
        config.set('Moonlight', 'nomouseemulation',
                   'false' if gamepad_mouse else 'true')
        config.set('Moonlight', 'hdr', self.config['hdr_flag'])
        config.set('Moonlight', 'cec',
                   'false' if self.config['cec'] == 'false' else 'true')

        config.set('Moonlight', 'osd', self.config['osd'] or 'false')
        config.set('Moonlight', 'osdargs', self._osd_args())

        selectors = inputdevices.load_selectors(self.plugin)
        paths = inputdevices.resolve_selectors(selectors)

        rendered = io.StringIO()
        config.write(rendered)
        lines = rendered.getvalue().splitlines(keepends=True)
        # Repeated input= entries must belong to [Moonlight], even if custom
        # configuration sections follow it.
        sections = [i for i, line in enumerate(lines)
                    if line.rstrip('\r\n') == '[Moonlight]']
        if len(sections) != 1:
            raise ValueError('Cannot locate the serialized Moonlight section')
        lines[sections[0] + 1:sections[0] + 1] = [
            'input = %s\n' % path for path in paths]
        content = ''.join(lines)
        from resources.lib.util.nativeini import validate_and_mask_inputs
        try:
            validate_and_mask_inputs(content)  # Validate new values before publication.
        except ValueError as error:
            raise MoonlightSettingsError(self.config_path, str(error)) from error
        self._atomic_config_write(self.config_path, content)
        # An individual launch must capture the exact settings rendered by
        # THIS Kodi invocation, not a later update to shared moonlight.conf.
        self._launch_config_content = content
        from resources.lib.util.hostcontext import normalize_options
        self._launch_host_options = normalize_options(
            {key: config._sections['Moonlight'][key] for key in ('port', 'keydir')
             if key in config._sections['Moonlight']}, self.binary_path)
        self.logger.info('[ConfigHelper] - Dumped config to disk.')

    @staticmethod
    def _atomic_config_write(path, content):
        directory = os.path.dirname(path)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(
                    mode='w', encoding='utf-8', dir=directory,
                    prefix='.luna-config-', suffix='.tmp',
                    delete=False) as stream:
                temporary = stream.name
                os.chmod(temporary, 0o600)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    def create_launch_snapshot(self, stream_profile=None):
        """Private immutable-per-invocation config for preflight and stream.

        Applying a saved app preset creates a NEW snapshot; it never changes
        the Kodi-global resolution/FPS or the shared moonlight.conf.
        """
        content = getattr(self, '_launch_config_content', None)
        if content is None:
            raise ValueError('Luna launch configuration has not been generated')
        if stream_profile is not None:
            from resources.lib.util.streamprofiles import apply_to_config
            content = apply_to_config(content, stream_profile)
        # Fail BEFORE creating a stream snapshot if its host doesn't match
        # the host selected for native preflight. Other INI sections cannot
        # supply a second address, even when the native parser ignores them.
        parser = configparser.ConfigParser(strict=False, interpolation=None)
        try:
            parser.read_string(content)
        except configparser.Error as error:
            raise ValueError('Invalid Moonlight launch snapshot') from error
        if not parser.has_section('Moonlight'):
            raise ValueError('Moonlight launch snapshot has no [Moonlight] section')
        # ConfigParser.get() inherits [DEFAULT] values that native Moonlight
        # ignores. A launch requires a host explicitly in [Moonlight].
        address = (parser._sections.get('Moonlight', {}).get('address') or '').strip()
        if not address:
            raise ValueError('Moonlight launch snapshot does not identify a Sunshine host')
        expected = (getattr(self, 'config', None) or {}).get('host_addr') or ''
        if expected and address != expected:
            raise ValueError('Moonlight launch snapshot host differs from selected host')
        if any(parser.has_option(sec, 'address')
               for sec in parser.sections() if sec != 'Moonlight'):
            raise ValueError('Moonlight launch snapshot contains another host address')
        # Keep the explicit input-path bound even for externally modified
        # snapshots (the normal writer already enforces it).
        within_moonlight = False
        count = 0
        for line in content.splitlines():
            value = line.strip()
            if value.startswith('[') and value.endswith(']'):
                within_moonlight = value == '[Moonlight]'
            elif within_moonlight and value.partition('=')[0].strip().lower() == 'input':
                count += 1
        if count > inputdevices.MAX_ACTIVE_INPUT_PATHS:
            raise inputdevices.InputPathLimitExceeded(
                'Snapshot contains %d input paths; native limit is %d' %
                (count, inputdevices.MAX_ACTIVE_INPUT_PATHS))
        folder = os.path.dirname(self.config_path)
        fd, snapshot = tempfile.mkstemp(
            prefix='.luna-stream-', suffix='.conf', dir=folder)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            return snapshot
        except BaseException:
            try:
                os.unlink(snapshot)
            except OSError:
                pass
            raise

    def host_options(self):
        """Effective native connection context, excluding stream-specific options."""
        parser = self._read_sectioned_conf()
        section = parser._sections.get('Moonlight', {})
        from resources.lib.util.hostcontext import normalize_options
        return normalize_options(
            {key: section[key] for key in ('port', 'keydir') if key in section},
            getattr(self, 'binary_path', None) or os.path.dirname(self.config_path))

    def create_host_lookup_snapshot(self, address=None, host_options=None):
        """Bind native discovery to the exact selected host without changing
        moonlight.conf or accepting native autodiscovery/per-host overrides.
        """
        address = (address if address is not None else self.config.get('host_addr') or '').strip()
        if (not address or len(address) > 255 or address.startswith('-') or
                any(char.isspace() or ord(char) < 32 or char == '=' for char in address)):
            raise ValueError('Select a valid Sunshine host before listing applications')
        options = self.host_options() if host_options is None else host_options
        from resources.lib.util.nativeini import validate_and_mask_inputs
        content = '[Moonlight]\naddress = %s\n' % address
        content += ''.join('%s = %s\n' % item for item in options.items())
        validate_and_mask_inputs(content)
        folder = os.path.dirname(self.config_path)
        fd, path = tempfile.mkstemp(
            prefix='.luna-host-', suffix='.conf', dir=folder)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            return path
        except BaseException:
            try:
                os.unlink(path)
            except OSError:
                pass
            raise

    @staticmethod
    def _find_binary(internal_path, logger=None):
        # Diagnose the first attempt without hiding startup failures behind retries.
        elf_class = 1 if struct.calcsize('P') == 4 else 2
        arch = 'coreelec-ng' if elf_class == 1 else 'coreelec-no'
        candidates = [
            os.path.join(internal_path, 'bin', arch, 'moonlight'),
            '/usr/bin/moonlight',
            '/usr/local/bin/moonlight',
            '/storage/moonlight/moonlight',
            os.path.join(internal_path, 'bin', 'moonlight'),
        ]
        for candidate in candidates:
            try:
                if not os.path.isfile(candidate):
                    reason = 'missing'
                elif not os.access(candidate, os.X_OK):
                    reason = 'not executable'
                else:
                    with open(candidate, 'rb') as executable:
                        header = executable.read(5)
                    if len(header) != 5 or header[:4] != bytes((127,)) + b'ELF':
                        reason = 'invalid ELF header'
                    elif header[4] != elf_class:
                        reason = 'wrong ELF class (expected %d, got %d)' % (elf_class, header[4])
                    else:
                        selected = os.path.dirname(candidate) + '/'
                        if logger:
                            bundled = os.path.join(internal_path, 'bin')
                            origin = ('bundled' if os.path.commonpath(
                                (os.path.abspath(candidate), os.path.abspath(bundled))) ==
                                os.path.abspath(bundled) else 'system/external')
                            logger.info('[ConfigHelper] - Selected Moonlight executable: %s (%s, ELF class %d)' %
                                        (candidate, origin, elf_class))
                        return selected
            except OSError as error:
                reason = 'read error: %s' % error
            if logger:
                logger.info('[ConfigHelper] - Moonlight candidate %s: %s' % (candidate, reason))
        if logger:
            logger.info('[ConfigHelper] - No usable Moonlight executable (addon=%s, expected ELF class=%d, candidates=%d)' %
                        (internal_path, elf_class, len(candidates)))
        return None
