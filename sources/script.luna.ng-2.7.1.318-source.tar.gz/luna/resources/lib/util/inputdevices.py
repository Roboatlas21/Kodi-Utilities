import io
import os
import re
import json
import struct


class InvalidInputSelection(ValueError):
    """Saved controller identities are invalid; do not start unfiltered input."""


class InputPathLimitExceeded(InvalidInputSelection):
    """More connected, selected input nodes than this native build supports."""


MAX_ACTIVE_INPUT_PATHS = 32

PROC = '/proc/bus/input/devices'

SYSTEM_NAMES = ('cec_input', 'input_ethrcu', 'input_btrcu', 'gpio_keypad',
                'meson-ir', 'eventlircd')

COVERED_BY_CEC = ('cec_input',)

KEYS_ENOUGH = 8

BTN_LEFT = 272
BTN_TOUCH = 330
BTN_GAMEPAD = 304

EVENT = re.compile(r'\bevent(\d+)\b')
MOUSE = re.compile(r'\bmouse\d+\b')
JOYSTICK = re.compile(r'\bjs\d+\b')


def _blocks():
    try:
        text = io.open(PROC, encoding='utf-8', errors='replace').read()
    except IOError:
        return []
    return [b for b in text.split('\n\n') if b.strip()]


def _kind(handlers):
    if JOYSTICK.search(handlers):
        return 'gamepad'
    if MOUSE.search(handlers):
        return 'mouse'
    if 'kbd' in handlers:
        return 'keyboard'
    return 'other'


def _capability_mask(words, bits_per_word):
    """Decode Linux /sys input bitsets in native unsigned-long words.

    CoreELEC NG is ARM32, while typical development/test machines are 64-bit.
    """
    if bits_per_word not in (32, 64):
        raise ValueError('Unsupported input capability word width')
    value = 0
    maximum = (1 << bits_per_word) - 1
    for index, word in enumerate(reversed(words)):
        part = int(word, 16)
        if part > maximum:
            raise ValueError('Input capability word exceeds native width')
        value |= part << (bits_per_word * index)
    return value


def _event_bitmap(event, kind):
    """Read ABI-neutral evdev capability bytes, or None if unavailable.

    Linux may render sysfs bitsets in native 64-bit words or 32-bit compat
    words. EVIOCGBIT returns a byte bitmap with stable bit numbering instead,
    regardless of Python's word size and the kernel's native unsigned long.
    Only open a strictly named event node, without following symlinks.
    """
    import fcntl
    import os
    import stat
    import sys
    event_types = {'key': (1, 96), 'rel': (2, 2), 'abs': (3, 8)}
    if kind not in event_types or not re.fullmatch(r'event[0-9]+', event):
        return None
    ev_type, length = event_types[kind]
    node = '/dev/input/' + event
    flags = (os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0) |
             getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0))
    try:
        fd = os.open(node, flags)
        try:
            if not stat.S_ISCHR(os.fstat(fd).st_mode):
                return None
            bitmap = bytearray(length)
            # _IOC(_IOC_READ, 'E', 0x20 + ev_type, length)
            command = 0x80000000 | (length << 16) | (ord('E') << 8) | (0x20 + ev_type)
            fcntl.ioctl(fd, command, bitmap, True)
            return int.from_bytes(bitmap, sys.byteorder)
        finally:
            os.close(fd)
    except (OSError, ValueError):
        return None


def _mask(event, kind):
    native = _event_bitmap(event, kind)
    if native is not None:
        return native
    path = '/sys/class/input/%s/device/capabilities/%s' % (event, kind)
    try:
        with io.open(path, encoding='ascii') as source:
            words = source.read().split()
        # Sysfs groups are hexadecimal unsigned-long words, highest first.
        # Preserve zero padding: a 64-bit word can contain only low 32-bit
        # values and still occupy 16 hex columns. lstrip('0') loses the ONLY
        # evidence of the kernel's word width on ARM32 Python/ARM64 kernels.
        if not words or any(len(word) > 16 for word in words):
            raise ValueError('Invalid sysfs input capabilities')
        if any(len(word) > 8 for word in words):
            width = 64
        elif len(words) == 1:
            # A lone short low-value token has the same bit numbering in both
            # layouts. The 64-bit alternative cannot change that result.
            width = struct.calcsize('L') * 8
        elif all(len(word) == 8 for word in words[1:]):
            # The least-significant (all but the first) kernel words are
            # printed at the full native width. A top word may be shorter.
            width = 32
        else:
            # Multiple unpadded short words do not reveal their boundaries.
            # Do not invent controller capability bits on an ambiguous ABI.
            raise ValueError('Ambiguous sysfs input capability word width')
        return _capability_mask(words, width)
    except (IOError, OSError, ValueError):
        return 0


def _usable(event):
    keys = _mask(event, 'key')
    axes = _mask(event, 'abs')
    pointer = _mask(event, 'rel') or axes
    has_button = keys >> BTN_LEFT & 1 or keys >> BTN_TOUCH & 1
    gamepad = keys >> BTN_GAMEPAD & 1

    # Match native evdev's SDL-style joystick classification. Axis-only
    # accelerometers have no keys and must not appear as controllers.
    paired_axes = axes & 3 == 3 or (axes >> 16) & 3 == 3
    joystick_controls = (any(keys >> bit & 1 for bit in (288, 304, 257)) or
                         any(axes >> bit & 1 for bit in range(3, 11)))
    if keys and paired_axes and joystick_controls:
        return True
    if gamepad:
        return True
    if pointer and has_button:
        return True
    return bin(keys).count('1') >= KEYS_ENOUGH


def list_devices():
    devices = []
    for block in _blocks():
        name = phys = uniq = handlers = ''
        for line in block.splitlines():
            if line.startswith('N: Name='):
                name = line.split('=', 1)[1].strip().strip('"')
            elif line.startswith('P: Phys='):
                phys = line.split('=', 1)[1].strip()
            elif line.startswith('U: Uniq='):
                uniq = line.split('=', 1)[1].strip()
            elif line.startswith('H: Handlers='):
                handlers = line.split('=', 1)[1].strip()

        match = EVENT.search(handlers)
        if not match or not name:
            continue

        event = 'event%s' % match.group(1)
        devices.append({
            'name': name,
            'path': '/dev/input/%s' % event,
            'kind': _kind(handlers),
            'system': name in SYSTEM_NAMES,
            'phys': phys,
            'uniq': uniq,
            'usable': _usable(event) and name not in COVERED_BY_CEC,
        })
    return devices


def resolve(names):
    wanted = set(names)
    return [d['path'] for d in list_devices() if d['name'] in wanted]

# New selections keep name + stable evdev identity. U: Uniq is usually the
# Bluetooth address or USB serial; P: Phys identifies a stable USB port when
# uniq is empty/non-unique. Never save eventN: those numbers are reused.
def _valid_text(value, allow_empty=False):
    if (not isinstance(value, str) or '\x00' in value or
            (not allow_empty and not value)):
        return False
    try:
        return len(value.encode('utf-8')) <= 255
    except UnicodeError:
        return False


def _trusted_unique_id(value):
    """Prefer serials/MAC-like IDs; do not bind generic IDs to every port.

    Common kernel 'Uniq' placeholders (zeroes, repeated single characters,
    or generic strings) are insufficient to distinguish controllers.
    """
    if not _valid_text(value):
        return False
    normalized = value.strip().lower()
    if normalized in ('none', 'unknown', 'default', 'generic', 'null',
                      'same', '0', '0000', '1234'):
        return False
    # Match placeholders as WHOLE identifiers, not their hex-looking
    # fragments. For example BT-B is a valid ID: stripping non-hex
    # characters produces 'bb' and previously widened it to a name group.
    compact = re.sub(r'[-:._]', '', normalized)
    if compact and len(set(compact)) == 1:
        return False
    return len(normalized) >= 4 and len(set(normalized)) >= 2


def select_identity(device, peers=None):
    name = device['name']
    peers = peers if peers is not None else [device]
    uniq = device.get('uniq', '') or ''
    unique_now = not any(
        other is not device and other.get('name') == name and
        other.get('uniq') == uniq for other in peers)
    if unique_now and _trusted_unique_id(uniq):
        # Real serials remain valid across port changes and reconnections.
        return {'name': name, 'kind': 'U', 'value': uniq}
    phys = device.get('phys', '') or ''
    if _valid_text(phys) and not any(
            other is not device and other.get('name') == name and
            other.get('phys') == phys for other in peers):
        # No trustworthy serial; bind generic IDs to an explicit endpoint.
        return {'name': name, 'kind': 'P', 'value': phys}
    # A generic ID without a physical path cannot distinguish a second
    # same-model device that connects later. Keep the explicit name group
    # instead of claiming individual identity we cannot reliably verify.
    # No distinguishable physical identity: selecting this name selects all
    # devices that report it. Do not pretend they can be selected separately.
    return {'name': name, 'kind': 'N', 'value': ''}


def _validate_selector(item):
    if not isinstance(item, dict):
        raise ValueError('Invalid saved input selector')
    name, kind, value = item.get('name'), item.get('kind'), item.get('value')
    physical = item.get('phys', '')
    if (not _valid_text(name) or kind not in ('U', 'P', 'N') or
            not _valid_text(value, allow_empty=True) or
            not _valid_text(physical, allow_empty=True) or
            ((kind == 'N') != (value == '')) or
            (kind != 'U' and physical)):
        raise InvalidInputSelection('Invalid saved controller identity')
    record = {'name': name, 'kind': kind, 'value': value}
    if physical:
        record['phys'] = physical
    return record


def load_selectors(plugin):
    raw = plugin.getSetting('input_device_selectors_v2')
    if raw:
        try:
            data = json.loads(raw)
            if (not isinstance(data, dict) or data.get('schema') != 2 or
                    not isinstance(data.get('devices'), list) or
                    len(data['devices']) > 64):
                raise ValueError('Bad selected-input format')
            return [_validate_selector(item) for item in data['devices']]
        except (ValueError, TypeError, UnicodeError) as error:
            raise InvalidInputSelection(
                'Saved controller selection is invalid. Open Luna Settings, '
                'choose Input Devices, and reselect or clear your controllers.'
            ) from error
    # Legacy preferences only stored names. Preserve them until the user
    # visits the picker again and selects per-device identities.
    return [_validate_selector({'name': n, 'kind': 'N', 'value': ''})
            for n in plugin.getSetting('input_devices').split('|') if n]


def serialize_selectors(selectors):
    records = [_validate_selector(item) for item in selectors]
    if len(records) > 64:
        raise InvalidInputSelection(
            'At most 64 controller identities can be saved. '
            'Deselect unused or disconnected controllers.')
    # Validate the actual deduplicated native encoding before saving, including
    # offline identities that do not count towards the active event-path limit.
    encode_selectors(records)
    return json.dumps({'schema': 2, 'devices': records},
                      ensure_ascii=False, separators=(',', ':'))


def match_selector(device, selector):
    if device.get('name') != selector['name']:
        return False
    kind = selector['kind']
    if kind == 'N':
        return True
    field = 'uniq' if kind == 'U' else 'phys'
    return (bool(selector['value']) and
            device.get(field) == selector['value'] and
            (kind != 'U' or not selector.get('phys') or
             device.get('phys') == selector['phys']))


def picker_options(all_devices, saved):
    """Include selected disconnected devices, allowing deliberate deselection.

    Each option contains a currently connected device or a saved offline
    identity. Never drop an offline selection just because it is absent from
    /proc/bus/input/devices while this dialog is open.
    """
    candidates = [device for device in all_devices if device.get('usable') or
                  any(match_selector(device, entry) for entry in saved)]
    options = []
    # Legacy name-only preferences cover all same-name devices, including
    # disconnected ones. Keep that group as its own selected option until
    # explicitly deselected; never auto-migrate it to one online device.
    for entry in saved:
        if entry['kind'] == 'N' and entry not in [
                option['selector'] for option in options]:
            options.append({
                'device': None, 'selector': entry, 'selected': True,
                'offline': not any(d['name'] == entry['name'] for d in candidates),
                'group': True,
            })
    for device in candidates:
        selector = select_identity(device, candidates)
        if any(option['selector'] == selector for option in options):
            continue
        # A legacy composite U+Phys entry can be migrated back to a strong
        # serial without requiring the original port. A weak serial never
        # authorizes a different port without explicit reselection.
        upgraded = any(
            entry['kind'] == 'U' and selector['kind'] == 'U' and
            entry['name'] == selector['name'] and
            entry['value'] == selector['value'] and
            _trusted_unique_id(selector['value'])
            for entry in saved)
        options.append({
            'device': device,
            'selector': selector,
            'selected': upgraded or any(
                match_selector(device, entry) for entry in saved
                if entry['kind'] != 'N'),
            'offline': False,
            'group': False,
        })
    for entry in saved:
        if entry['kind'] == 'N':
            continue
        if (not any(option['selected'] and
                    option['selector']['name'] == entry['name'] and
                    option['selector']['kind'] == 'U' and
                    entry['kind'] == 'U' and
                    option['selector']['value'] == entry['value'] and
                    _trusted_unique_id(entry['value'])
                    for option in options) and
            not any(match_selector(device, entry) for device in candidates) and
            not any(option['selector'] == entry for option in options)):
            options.append({
                'device': None, 'selector': entry, 'selected': True,
                'offline': True, 'group': False,
            })
    return options


def resolve_selectors(selectors, devices=None):
    devices = list_devices() if devices is None else devices
    # Different saved identities may resolve to the same event node. Dedup
    # by path before comparing with the native limit, without discarding any
    # saved offline identities or changing automatic input discovery.
    paths = list(dict.fromkeys(
        d['path'] for d in devices
        if any(match_selector(d, selector) for selector in selectors)))
    if len(paths) > MAX_ACTIVE_INPUT_PATHS:
        raise InputPathLimitExceeded(
            '%d connected input nodes match your selection; Moonlight supports '
            'at most %d explicit paths. Deselect devices or use automatic input.'
            % (len(paths), MAX_ACTIVE_INPUT_PATHS))
    return paths


def encode_selectors(selectors):
    tokens = []
    for raw in selectors:
        selector = _validate_selector(raw)
        name = selector['name'].encode('utf-8').hex()
        value = selector['value'].encode('utf-8').hex()
        token = '%s:%s:%s' % (name, selector['kind'], value)
        if selector.get('phys'):
            token += ':' + selector['phys'].encode('utf-8').hex()
        tokens.append(token)
    result = ','.join(dict.fromkeys(tokens))
    if len(result) > 16384:
        raise InvalidInputSelection(
            'Selected controller identities exceed the native size limit. '
            'Deselect unused or disconnected controllers.')
    return result


KIND_LABELS = {
    'keyboard': 'keyboard',
    'mouse': 'mouse',
    'gamepad': 'gamepad',
    'other': 'other',
}
SYSTEM_LABEL = 'system'


def describe(device, kinds=None, system_label=None):
    kinds = kinds or KIND_LABELS
    mark = ' [%s]' % (system_label or SYSTEM_LABEL) if device['system'] else ''
    return '%s  (%s)%s' % (device['name'],
                           kinds.get(device['kind'], device['kind']), mark)
