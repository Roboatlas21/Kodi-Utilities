"""Bounded, descriptor-pinned reads of on-disk Kodi state and cached assets."""
import errno
import os
import stat


class UnsafeRegularFile(ValueError):
    """The source exists but cannot be safely read as a bounded regular file."""


def read_regular_bytes(path, maximum_bytes):
    """Return (bytes, fstat) from one O_NOFOLLOW/O_NONBLOCK descriptor.

    FileNotFoundError means the pathname was genuinely absent at open time;
    dangling symlinks, FIFOs, directories and oversized files fail closed.
    """
    if type(maximum_bytes) is not int or maximum_bytes < 1:
        raise ValueError('Invalid regular-file size limit')
    path = os.fspath(path)
    flags = (os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW |
             getattr(os, 'O_CLOEXEC', 0))
    try:
        fd = os.open(path, flags)
    except FileNotFoundError as error:
        if os.path.lexists(path):
            raise UnsafeRegularFile('Existing source cannot be opened') from error
        raise
    except OSError as error:
        if error.errno == errno.ELOOP:
            raise UnsafeRegularFile('Refusing symlinked source') from error
        raise UnsafeRegularFile('Source cannot be opened safely') from error
    try:
        with os.fdopen(fd, 'rb') as stream:
            metadata = os.fstat(stream.fileno())
            if not stat.S_ISREG(metadata.st_mode):
                raise UnsafeRegularFile('Source is not a regular file')
            if metadata.st_size < 0 or metadata.st_size > maximum_bytes:
                raise UnsafeRegularFile('Source is too large')
            data = stream.read(maximum_bytes + 1)
    except OSError as error:
        raise UnsafeRegularFile('Source cannot be read safely') from error
    if len(data) > maximum_bytes:
        raise UnsafeRegularFile('Source grew beyond its size limit')
    return data, metadata
