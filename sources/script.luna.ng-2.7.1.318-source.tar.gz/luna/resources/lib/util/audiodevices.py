import json
import os
import re
import subprocess
import time
import threading

_probe_context = threading.local()
_playback_cache_lock = threading.Lock()
_playback_cache_until = 0.0
_playback_cache = ()
from pathlib import Path

LINE = re.compile(r'^card\s+(\d+):.*?device\s+(\d+):\s*(.*?)\s*$')


def card_identifier(number):
    try:
        value = Path('/proc/asound/card%d/id' % number).read_text().strip()
        if re.fullmatch(r'[A-Za-z0-9_-]+', value):
            return value
    except OSError:
        pass
    return str(number)


def resolve_card(value):
    if value.isdecimal():
        return int(value)
    for path in Path('/proc/asound').glob('card[0-9]*/id'):
        try:
            if path.read_text().strip() == value:
                return int(path.parent.name[4:])
        except (OSError, ValueError):
            continue
    return None


def endpoint_node(alsa):
    """Resolve explicit hardware/plugin endpoints; never guess card zero."""
    text = alsa or ''
    match = re.search(r'(?:^|[:,])CARD=([^,]+)', text)
    if match:
        card = resolve_card(match[1])
        dev = re.search(r'(?:^|,)DEV=([0-9]+)(?:,|$)', text)
        device = int(dev[1]) if dev else 0
    else:
        match = re.fullmatch(r'(?:plug)?hw:([^,]+),([0-9]+)', text)
        if not match:
            return None
        card, device = resolve_card(match[1]), int(match[2])
    return (card, device) if card is not None else None


def endpoint_busy(alsa):
    node = endpoint_node(alsa)
    return _busy(*node) if node is not None else False


def _busy(card, device):
    context = getattr(_probe_context, 'current', None)
    key = (card, device)
    if context is not None:
        deadline, cached = context
        if key in cached:
            return cached[key]
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False  # Busy status is advisory, never permission to seize it.
    else:
        remaining = 2
    node = '/dev/snd/pcmC%dD%dp' % (card, device)
    if not os.path.exists(node):
        return False
    try:
        out = subprocess.check_output(['fuser', node], stderr=subprocess.DEVNULL,
                                      encoding='utf-8', errors='replace', timeout=min(2, remaining))
        result = bool(out.strip())
    except (subprocess.SubprocessError, OSError):
        result = False
    if context is not None:
        cached[key] = result
    return result


def list_playback(force=False):
    """Reuse only a recent in-process scan; the explicit picker forces refresh."""
    global _playback_cache, _playback_cache_until
    now = time.monotonic()
    with _playback_cache_lock:
        if not force and now < _playback_cache_until:
            return [dict(device) for device in _playback_cache]
    previous = getattr(_probe_context, 'current', None)
    _probe_context.current = (time.monotonic() + 3, {})
    try:
        devices = _list_playback()
    finally:
        _probe_context.current = previous
    with _playback_cache_lock:
        _playback_cache = tuple(dict(device) for device in devices)
        _playback_cache_until = time.monotonic() + 10
    return devices


def _list_playback():
    try:
        raw = subprocess.check_output(['aplay', '-l'], stderr=subprocess.DEVNULL,
                                      encoding='utf-8', errors='replace', timeout=2)
    except (subprocess.SubprocessError, OSError):
        return []

    devices = []
    for line in raw.splitlines():
        match = LINE.match(line.strip())
        if not match:
            continue

        card, device = int(match.group(1)), int(match.group(2))
        name = match.group(3).replace('[]', '').strip()
        devices.append({
            'alsa': 'hw:%s,%d' % (card_identifier(card), device),
            'name': name,
            'busy': _busy(card, device),
            'dummy': 'dummy' in name.lower(),
        })

    plugins = _plugin_devices()
    # Plugins supplement hardware endpoints; they do not invalidate a saved
    # hw:CARD,DEV selection (including HDMI when USB audio is attached).
    seen = {device['alsa'] for device in plugins}
    return plugins + [device for device in devices if device['alsa'] not in seen]


def _kodi_labels():
    try:
        import xbmc
    except ImportError:
        return {}

    request = json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Settings.GetSettings',
        'params': {'level': 'expert',
                   'filter': {'section': 'system', 'category': 'audio'}},
    })
    try:
        answer = json.loads(xbmc.executeJSONRPC(request))
    except (ValueError, TypeError, RuntimeError):
        return {}

    labels = {}
    for setting in answer.get('result', {}).get('settings', []):
        if setting.get('id') != 'audiooutput.audiodevice':
            continue
        for option in setting.get('options', []):
            value = option.get('value') or ''
            label = option.get('label') or ''
            if not value.startswith('ALSA:') or not label:
                continue
            labels[value[len('ALSA:'):].split('|')[0]] = label
    return labels


def _labels_for(names):
    labels = _kodi_labels()

    parts = {}
    for name in names:
        label = labels.get(name)
        if not label:
            continue
        head = label[len('ALSA: '):] if label.startswith('ALSA: ') else label
        card, _, tail = head.partition(', ')
        parts[name] = (card, tail or card)

    cards = set(card for card, _ in parts.values())
    if len(cards) > 1:
        return dict((n, '%s, %s' % parts[n]) for n in parts)
    return dict((n, parts[n][1]) for n in parts)


def pretty(alsa):
    for device in list_playback():
        if device['alsa'] == alsa:
            return device['name']
    return _labels_for([alsa]).get(alsa, alsa)


PLUGIN_PREFIXES = ('surround', 'iec958')

PLUGIN_DEV = re.compile(r'DEV=(\d+)')


def _plugin_devices():
    try:
        raw = subprocess.check_output(['aplay', '-L'], stderr=subprocess.DEVNULL,
                                      encoding='utf-8', errors='replace', timeout=2)
    except (subprocess.SubprocessError, OSError):
        return []

    devices = []
    name = None
    description = ''

    def flush():
        if not name:
            return
        match = PLUGIN_DEV.search(name)
        device = int(match.group(1)) if match else None
        devices.append({
            'alsa': name,
            'name': description or name,
            'busy': endpoint_busy(name),
            'dummy': False,
        })

    for line in raw.splitlines():
        if line and not line[0].isspace():
            flush()
            name = line.strip() if line.strip().startswith(PLUGIN_PREFIXES) else None
            description = ''
            continue

        if name and line.strip().rstrip(','):
            description = line.strip()

    flush()

    labels = _labels_for([d['alsa'] for d in devices])
    for device in devices:
        if labels.get(device['alsa']):
            device['name'] = labels[device['alsa']]
    return devices


STEREO_ONLY = ('iec958', 'spdif')


def channel_capacity(alsa):
    """Known PCM channel ceiling; None means this endpoint is unverified."""
    if (alsa or '').startswith(STEREO_ONLY):
        return 2
    layout = re.match(r'^surround(40|41|50|51|71)(?:[:,]|$)', alsa or '')
    if layout:
        return {'40': 4, '41': 5, '50': 5, '51': 6, '71': 8}[layout[1]]
    # Card-wide ELD and USB streamN do not establish a PCM-specific mapping.
    # Preserve explicit user choices when we cannot prove that association.
    return None


def multichannel(alsa):
    capacity = channel_capacity(alsa)
    return capacity >= 6 if capacity is not None else None


def supported_surround(alsa, requested):
    capacity = channel_capacity(alsa)
    required = {'5.1': 6, '7.1': 8}.get(requested, 2)
    if capacity is None or capacity >= required:
        return requested
    return '5.1' if capacity >= 6 else 'false'


def default_device(devices=None):
    if devices is None:
        devices = list_playback()

    for prefix in ('surround', 'iec958'):
        for device in devices:
            if device['alsa'].startswith(prefix):
                return device['alsa']

    for device in devices:
        if not device['dummy']:
            return device['alsa']
    return devices[0]['alsa'] if devices else None


def describe(device, busy_label='Busy'):
    name = device['name'] or device['alsa']
    if device['busy']:
        return '%s  (%s)' % (name, busy_label)
    return name
