#!/bin/sh
# Legacy entry point: write a PRIVATE local report. Never upload to a paste service.
set -eu
script_dir="$(CDPATH= cd "$(dirname "$0")" && pwd)"
data_dir="${LUNA_LOG_DIR:-/storage/.kodi/userdata/addon_data/script.luna.ng}"
exec python3 "$script_dir/lib/util/diagnosticreport.py" \
  --data-dir "$data_dir" \
  --kodi-log "/storage/.kodi/temp/kodi.log" \
  --legacy-log "$script_dir/../bin/logfile"
