#!/bin/sh
# Boot-relative elapsed time for detached Luna launch/recovery deadlines.
# NTP and manual changes to wall-clock time must not affect live timeouts.
luna_monotonic_seconds() {
  read -r lu_uptime lu_idle < /proc/uptime || return 1
  lu_seconds="${lu_uptime%%.*}"
  case "$lu_seconds" in ''|*[!0-9]*) return 1 ;; esac
  printf '%s\n' "$lu_seconds"
}

# Millisecond boot-relative clock for observational teardown timings.
# /proc/uptime and shell builtins avoid spawning Python or relying on
# wall-clock time and date(1)'s optional %N support.
luna_monotonic_milliseconds() {
  read -r lc_uptime lc_idle < /proc/uptime || return 1
  case "$lc_uptime" in *.*) ;; *) return 1 ;; esac
  lc_sec="${lc_uptime%%.*}"
  lc_frac="${lc_uptime#*.}"
  case "$lc_sec:$lc_frac" in *[!0-9:]*|:*|*:) return 1 ;; esac
  lc_padded="${lc_frac}000"
  lc_three="${lc_padded%${lc_padded#???}}"
  lc_h="${lc_three%??}"
  lc_t="${lc_three#?}"; lc_t="${lc_t%?}"
  lc_u="${lc_three#??}"
  printf '%s\n' "$((lc_sec * 1000 + lc_h * 100 + lc_t * 10 + lc_u))"
}

luna_duration_stamp() {
  lu_seconds="$(luna_monotonic_seconds)" || return 1
  printf 'mono:%s\n' "$lu_seconds"
}

luna_elapsed_since() {
  lu_stamp="$1"
  case "$lu_stamp" in
    mono:*)
      lu_started="${lu_stamp#mono:}"
      case "$lu_started" in ''|*[!0-9]*) return 1 ;; esac
      [ "${#lu_started}" -le 13 ] || return 1
      lu_now="$(luna_monotonic_seconds)" || return 1
      ;;
    *)
      # One-time compatibility for old on-disk epoch stamps. No new launch
      # creates these; after old sessions retire all active timing is monotonic.
      lu_started="$lu_stamp"
      case "$lu_started" in ''|*[!0-9]*) return 1 ;; esac
      [ "${#lu_started}" -le 13 ] || return 1
      lu_now="$(date +%s)" || return 1
      case "$lu_now" in ''|*[!0-9]*) return 1 ;; esac
      ;;
  esac
  [ "$lu_now" -ge "$lu_started" ] || return 1
  printf '%s\n' "$((lu_now - lu_started))"
}
