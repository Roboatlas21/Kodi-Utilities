#!/usr/bin/env python3
"""Allow an older verified ARM32 binary only when changes cannot affect it.

The native artifact and corresponding source archive retain their original
Moonlight SHA. New documentation/tests may be validated separately, but never
pretend that the old binary was compiled from the newest revision.
"""
import json
import pathlib
import sys

_NON_NATIVE = frozenset({
    "README.md",
    "README.pod",
    "CHANGELOG.md",
    "CHANGELOG",
    ".gitignore",
    ".github/workflows/coreelec-ng-checks.yml",
})


def non_native_path(path):
    return isinstance(path, str) and (
        path.startswith("docs/") or path.startswith("tests/") or path in _NON_NATIVE
    )


def reusable(compare):
    if not isinstance(compare, dict):
        return False
    if compare.get("status") == "identical":
        return compare.get("ahead_by") == 0
    if compare.get("status") != "ahead":
        return False
    commits = compare.get("ahead_by")
    files = compare.get("files")
    if not isinstance(commits, int) or not 1 <= commits <= 100:
        return False
    # REST compare can truncate file lists at 300. Never reuse on uncertainty.
    if not isinstance(files, list) or not 1 <= len(files) < 300:
        return False
    for change in files:
        if not isinstance(change, dict) or not non_native_path(change.get("filename")):
            return False
        if change.get("status") == "renamed" and not non_native_path(
            change.get("previous_filename")
        ):
            return False
    return True


if __name__ == "__main__":
    if len(sys.argv) != 1:
        raise SystemExit("Usage: native_reuse_policy.py < compare-response.json")
    comparison = json.load(sys.stdin)
    if not reusable(comparison):
        print("Native build inputs differ or comparison is incomplete", file=sys.stderr)
        raise SystemExit(1)
    print("Only non-native test/documentation changes; safe to reuse native artifact")
