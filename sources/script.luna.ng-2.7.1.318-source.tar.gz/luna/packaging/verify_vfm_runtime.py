#!/usr/bin/env python3
"""Validate a same-run CoreELEC VFM artifact before private Luna packaging."""
import argparse
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

MAX_MEMBER_BYTES = 1024 * 1024 * 1024
MAX_TOTAL_BYTES = 2 * 1024 * 1024 * 1024
SCHEMA = "luna-ng-vfm-v1"


def verify_and_extract(archive_path, destination, native_sha):
    if not isinstance(native_sha, str) or not re.fullmatch(r"[a-f0-9]{40}", native_sha):
        raise ValueError("Invalid Moonlight revision")
    destination = Path(destination)
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("VFM extraction destination must be empty")
    seen = set()
    total = 0
    with tarfile.open(archive_path, "r:gz") as archive:
        members = []
        manifest_member = None
        for member in archive:
            if member.name in (".", "./") and member.isdir():
                continue
            normalized = PurePosixPath(member.name)
            name = normalized.as_posix()
            if (normalized.is_absolute() or ".." in normalized.parts or
                    "\\" in member.name or not normalized.parts or
                    name in seen or not (member.isfile() or member.isdir()) or
                    member.size > MAX_MEMBER_BYTES):
                raise ValueError("Unsafe VFM archive entry: " + member.name)
            seen.add(name)
            total += member.size
            if total > MAX_TOTAL_BYTES:
                raise ValueError("VFM artifact exceeds bounded size")
            members.append(member)
            if name == "manifest.json":
                if not member.isfile():
                    raise ValueError("VFM manifest is not a file")
                manifest_member = member
        if manifest_member is None:
            raise ValueError("VFM manifest missing")
        with archive.extractfile(manifest_member) as reader:
            manifest = json.load(reader)
        if (not isinstance(manifest, dict) or manifest.get("schema") != SCHEMA or
                manifest.get("moonlight_source_git_sha") != native_sha or
                not isinstance(manifest.get("objects"), dict)):
            raise ValueError("VFM artifact source revision or schema mismatch")
        destination.mkdir(parents=True, exist_ok=True)
        # Python 3.12+ data filter rejects symlink/device/traversal extraction.
        archive.extractall(destination, members=members, filter="data")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("moonlight_sha")
    args = parser.parse_args()
    result = verify_and_extract(args.archive, args.destination, args.moonlight_sha)
    print("Verified VFM source revision:", result["moonlight_source_git_sha"])


if __name__ == "__main__":
    main()
