#!/usr/bin/env python3
"""Verify that a Moonlight build may resume a previously approved Luna run.

The native callback is only a hint, never authorization. Trust the original
successful Luna preflight, its immutable request artifact, the source-stamped
Moonlight run, and both completed Moonlight build jobs.
"""
import argparse
import json
from pathlib import Path
import re

LUNA_REPO = "Roboatlas21/Luna"
MOONLIGHT_REPO = "Roboatlas21/moonlight-embedded"
LUNA_WORKFLOW = ".github/workflows/unified-luna-ng.yml"
MOONLIGHT_WORKFLOW = ".github/workflows/coreelec-ng-native.yml"
SHA = re.compile(r"[0-9a-f]{40}\Z")
VERSION = re.compile(r"[0-9]+(?:\.[0-9]+){3}\Z")
RUN_ID = re.compile(r"[1-9][0-9]{6,}\Z")


def _require(condition, reason):
    if not condition:
        raise ValueError(reason)


def _successful_jobs(payload, run_id, expected, attempts=None):
    jobs = payload.get("jobs") if isinstance(payload, dict) else None
    _require(isinstance(jobs, list) and len(jobs) < 101,
             "Missing or incomplete job inventory")
    matching = {
        j.get("name")
        for j in jobs
        if isinstance(j, dict) and j.get("run_id") == run_id
        and j.get("status") == "completed"
        and j.get("conclusion") == "success"
        and (attempts is None or j.get("run_attempt") == attempts.get(j.get("name")))
    }
    _require(set(expected).issubset(matching),
             "Required preflight/native jobs have not all succeeded")


def _has_artifact(payload, name):
    if not isinstance(payload, dict) or not isinstance(payload.get("artifacts"), list):
        return False
    return any(
        isinstance(item, dict) and item.get("name") == name
        and item.get("expired") is False
        and type(item.get("size_in_bytes")) is int
        and item["size_in_bytes"] > 0
        for item in payload["artifacts"]
    )


def verify(request, origin, origin_jobs, native, native_jobs,
           native_artifacts, origin_id, native_id, publish, vfm):
    _require(isinstance(origin_id, str) and RUN_ID.fullmatch(origin_id),
             "Invalid original Luna run ID")
    _require(isinstance(native_id, str) and RUN_ID.fullmatch(native_id),
             "Invalid native run ID")
    origin_number, native_number = int(origin_id), int(native_id)
    _require(origin_number != native_number, "Native and original run IDs must differ")
    _require(isinstance(request, dict) and
             request.get("schema") == "luna-ng-native-request-v1",
             "Missing authenticated native request record")
    _require(request.get("origin_run_id") == origin_number,
             "Request belongs to a different original Luna run")
    attempt = request.get("origin_run_attempt")
    _require(type(attempt) is int and attempt >= 1,
             "Invalid original run attempt")
    luna_sha = request.get("luna_sha")
    native_sha = request.get("moonlight_sha")
    version = request.get("release_version")
    _require(isinstance(luna_sha, str) and SHA.fullmatch(luna_sha),
             "Invalid recorded Luna source revision")
    _require(isinstance(native_sha, str) and SHA.fullmatch(native_sha),
             "Invalid recorded Moonlight source revision")
    _require(isinstance(version, str) and VERSION.fullmatch(version),
             "Invalid recorded Luna release version")
    _require(type(request.get("publish_to_kodi")) is bool and
             type(request.get("include_vfm_runtime")) is bool,
             "Missing original approval flags")
    _require(request["publish_to_kodi"] is publish and
             request["include_vfm_runtime"] is vfm,
             "Resume request does not match original user approval")

    _require(isinstance(origin, dict) and origin.get("id") == origin_number and
             origin.get("event") == "workflow_dispatch" and
             origin.get("path") == LUNA_WORKFLOW and
             origin.get("head_branch") == "matrix" and
             (origin.get("head_repository") or {}).get("full_name") == LUNA_REPO and
             type(origin.get("run_attempt")) is int and
             origin["run_attempt"] >= attempt and
             origin.get("status") == "completed" and
             origin.get("conclusion") == "success",
             "Original Luna workflow did not finish an approved preflight")
    # Partial reruns retain the successful preflight approval. Bind its job
    # to that recorded attempt and the selection job to the dispatch attempt.
    title = native.get("display_title") if isinstance(native, dict) else None
    match = re.fullmatch(
        rf"CoreELEC21-NG source={native_sha} correlation=luna-{origin_id}-([1-9][0-9]*)",
        title if isinstance(title, str) else "")
    _require(match is not None, "Native run has an invalid source-bound correlation")
    dispatch_attempt = int(match[1])
    _require(attempt <= dispatch_attempt <= origin["run_attempt"],
             "Native dispatch is outside the approved run attempts")
    _successful_jobs(origin_jobs, origin_number, (
        "unified / preflight", "unified / select-native"), {
            "unified / preflight": attempt,
            "unified / select-native": dispatch_attempt,
        })

    _require(isinstance(native, dict) and native.get("id") == native_number and
             native.get("event") == "workflow_dispatch" and
             native.get("path") == MOONLIGHT_WORKFLOW and
             native.get("head_branch") == "feat/coreelec-ng" and
             (native.get("head_repository") or {}).get("full_name") == MOONLIGHT_REPO and
             (native.get("status") == "in_progress" or
              (native.get("status") == "completed" and
               native.get("conclusion") == "success")),
             "Native run does not match the original source-bound request")
    _successful_jobs(native_jobs, native_number, ("prepare", "native"))
    _require(_has_artifact(native_artifacts, "moonlight-coreelec21-ng-arm32"),
             "Verified Moonlight ARM32 artifact unavailable")
    if vfm:
        _require(_has_artifact(native_artifacts, "moonlight-coreelec21-ng-vfm-runtime"),
                 "Requested verified VFM artifact unavailable")
    return {
        "luna_sha": luna_sha,
        "moonlight_sha": native_sha,
        "release_version": version,
        "native_run_id": native_id,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("request", type=Path)
    parser.add_argument("origin", type=Path)
    parser.add_argument("origin_jobs", type=Path)
    parser.add_argument("native", type=Path)
    parser.add_argument("native_jobs", type=Path)
    parser.add_argument("native_artifacts", type=Path)
    parser.add_argument("--origin-id", required=True)
    parser.add_argument("--native-id", required=True)
    parser.add_argument("--publish", choices=("true", "false"), required=True)
    parser.add_argument("--vfm", choices=("true", "false"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        files = [json.loads(path.read_text(encoding="utf-8")) for path in
                 (args.request, args.origin, args.origin_jobs,
                  args.native, args.native_jobs, args.native_artifacts)]
        verified = verify(*files, args.origin_id, args.native_id,
                          args.publish == "true", args.vfm == "true")
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        parser.exit(1, f"Native continuation rejected: {exc}\n")
    with args.output.open("a", encoding="utf-8") as result:
        for key, value in verified.items():
            result.write(f"{key}={value}\n")
    print("Verified original Luna approval and completed Moonlight ARM32 jobs.")


if __name__ == "__main__":
    main()
