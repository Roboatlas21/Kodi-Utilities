#!/usr/bin/env python3
"""Create an installable Luna NG Kodi ZIP from a verified Moonlight ARM32 artifact.

Usage:
  python3 packaging/package_ng.py moonlight-coreelec21-ng-arm32.tar.gz --output luna-ng.zip

This tool never fetches another private repository or installs binaries on a TV.
"""
import argparse
import importlib.util
import hashlib
import io
import json
import posixpath
import re
import subprocess
import stat
import struct
import tempfile
import os
import tarfile
import zipfile
from pathlib import Path, PurePosixPath
from xml.etree import ElementTree

ADDON_ID = "script.luna.ng"

NATIVE_FILES = frozenset({
    "bin/coreelec-ng/moonlight",
    "lib/coreelec-ng/libmoonlight-aml.so",
    "lib/coreelec-ng/libgamestream.so.4",
    "lib/coreelec-ng/libmoonlight-common.so.4",
    "lib/coreelec-ng/libcec.so.6",
})
MANIFEST = "runtime-manifest.json"
ASSETS = frozenset({"bin/coreelec-ng/gamecontrollerdb.txt"})
OPTIONAL_FILES = frozenset({"build-info.txt"})
SCHEMA = "luna-ng-runtime-v1"
FIRST_VIDEO_CAPABILITY = "first-video-ready-v1"
FIRST_VIDEO_BIN_TOKEN = b"LUNA_NATIVE_FIRST_VIDEO_READY_V1"
FIRST_VIDEO_AML_TOKEN = b"MOONLIGHT_VIDEO_READY_FILE"
PRIVATE_SONAMES = frozenset({"libmoonlight-aml.so", "libgamestream.so.4",
                            "libmoonlight-common.so.4", "libcec.so.6"})
EXPECTED_LIB_SONAMES = {
    "lib/coreelec-ng/libmoonlight-aml.so": "libmoonlight-aml.so",
    "lib/coreelec-ng/libgamestream.so.4": "libgamestream.so.4",
    "lib/coreelec-ng/libmoonlight-common.so.4": "libmoonlight-common.so.4",
    "lib/coreelec-ng/libcec.so.6": "libcec.so.6",
}

# Package only the approved systemd CoreELEC launcher. Additional platform
# launchers (including a future CoreELEC 22 implementation) must be opted into
# their own verified packaging target, not picked from arbitrary source dirs.
NG_LAUNCHER = "coreelec"
# Exclude only top-level project/dev folders. In particular, `resources/lib`
# contains Luna's REQUIRED Python modules; rejecting any path component named
# "lib" mistakenly produced a ZIP without those modules.
EXCLUDED_ROOTS = frozenset({
    ".git", ".github", "tests", "docs", "packaging", "tools", "bin", "lib", "vfm",
})
EXCLUDED_CACHE_DIRS = frozenset({"__pycache__", ".pytest_cache"})


def assert_arm32(data, name):
    # ARM ELF32, little-endian, e_machine=40. Do not trust only the extension.
    if (len(data) < 20 or data[:4] != bytes((127,)) + b"ELF"
            or data[4:6] != b"\x01\x01"
            or struct.unpack_from("<H", data, 18)[0] != 40):
        raise ValueError("Not a 32-bit little-endian ARM ELF: " + name)


def verify_runtime_manifest(found):
    if MANIFEST not in found:
        raise ValueError("Missing ARM32 runtime manifest (rebuild from updated collector)")
    if len(found[MANIFEST]) > 128 * 1024:
        raise ValueError("Oversized native runtime manifest")
    try:
        manifest = json.loads(found[MANIFEST].decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as error:
        raise ValueError("Malformed ARM32 runtime manifest") from error
    if not isinstance(manifest, dict) or manifest.get("schema") != SCHEMA:
        raise ValueError("Unsupported ARM32 runtime manifest schema")
    if manifest.get("target") != "Amlogic-ce/Amlogic-ng/arm":
        raise ValueError("Native manifest target does not match CoreELEC 21 NG")
    if manifest.get("capabilities") != [FIRST_VIDEO_CAPABILITY]:
        raise ValueError("Native bundle lacks required first-video-ready-v1 capability")
    source = manifest.get("source_git_sha")
    if not isinstance(source, str) or not re.fullmatch(r"[a-f0-9]{40}", source):
        raise ValueError("Native source revision must be a full lowercase 40-hex commit")
    assets = manifest.get("assets")
    if not isinstance(assets, dict) or set(assets) != ASSETS:
        raise ValueError("Native asset list differs from manifest")
    for name in ASSETS:
        if name not in found or not 100 <= len(found[name]) <= 2 * 1024 * 1024:
            raise ValueError("Missing or invalid native input mapping: " + name)
        expected = assets[name]
        if not isinstance(expected, dict) or (
            expected.get("size") != len(found[name]) or
            expected.get("sha256") != hashlib.sha256(found[name]).hexdigest()
        ):
            raise ValueError("Native input mapping digest mismatch: " + name)
    # Content-checked implementation evidence is required in addition to the
    # manifest claim; source revision or checksum labels alone are insufficient.
    if (FIRST_VIDEO_BIN_TOKEN not in found["bin/coreelec-ng/moonlight"] or
            FIRST_VIDEO_AML_TOKEN not in found["lib/coreelec-ng/libmoonlight-aml.so"]):
        raise ValueError("Native executable or AML module lacks first-video-ready-v1 support")
    objects = manifest.get("objects")
    if not isinstance(objects, dict) or set(objects) != NATIVE_FILES:
        raise ValueError("Native artifact objects differ from manifest")
    external = set()
    for name in NATIVE_FILES:
        obj = objects[name]
        if not isinstance(obj, dict) or (
            obj.get("class") != "ELF32" or obj.get("machine") != "ARM"
        ):
            raise ValueError("Wrong ABI in native manifest: " + name)
        if obj.get("size") != len(found[name]) or (
            obj.get("sha256") != hashlib.sha256(found[name]).hexdigest()
        ):
            raise ValueError("Native object digest mismatch: " + name)
        if obj.get("soname") != EXPECTED_LIB_SONAMES.get(name):
            raise ValueError("Native library SONAME mismatch: " + name)
        if name.startswith("bin/"):
            interp = obj.get("interpreter")
            if not isinstance(interp, str) or not (
                interp.startswith("/lib/") or interp.startswith("/usr/lib/")
            ):
                raise ValueError("Unknown target ARM32 dynamic loader")
        elif obj.get("interpreter") is not None:
            raise ValueError("Unexpected dynamic loader on bundled library")
        needed = obj.get("needed")
        if not isinstance(needed, list) or any(
            not isinstance(lib, str) or not re.fullmatch(r"[A-Za-z0-9_.+-]{1,100}", lib)
            for lib in needed
        ):
            raise ValueError("Invalid dependency manifest for: " + name)
        if len(set(needed)) != len(needed):
            raise ValueError("Repeated dependency in manifest: " + name)
        external.update(lib for lib in needed if lib not in PRIVATE_SONAMES)
    if manifest.get("external_needed") != sorted(external):
        raise ValueError("External dependency list does not match ELF declarations")
    if "libgamestream.so.4" not in objects["bin/coreelec-ng/moonlight"]["needed"]:
        raise ValueError("Missing executable dependency on libgamestream")
    if "libmoonlight-common.so.4" not in (
        objects["lib/coreelec-ng/libgamestream.so.4"]["needed"]
    ):
        raise ValueError("Missing gamestream dependency on moonlight-common")
    # libmoonlight-aml.so is resolved with dlopen(), so a DT_NEEDED edge
    # to gamestream is not required (nor present in Vortex's reference ELF).
    return manifest


def native_members(bundle):
    found = {}
    with tarfile.open(bundle, "r:gz") as tar:
        for member in tar:
            name = posixpath.normpath(member.name)
            if name in (".", ""):
                continue
            if member.isdir():
                continue
            if (name not in NATIVE_FILES | ASSETS | OPTIONAL_FILES | {MANIFEST} or
                    not member.isfile() or
                    member.size > 64 * 1024 * 1024 or
                    name in found):
                raise ValueError("Unexpected or unsafe native archive entry: " + name)
            fileobj = tar.extractfile(member)
            if fileobj is None:
                raise ValueError("Cannot read native archive entry: " + name)
            data = fileobj.read()
            if len(data) != member.size:
                raise ValueError("Truncated native archive entry: " + name)
            if name in NATIVE_FILES:
                assert_arm32(data, name)
            found[name] = data

    if set(found) & NATIVE_FILES != NATIVE_FILES:
        missing = sorted(NATIVE_FILES - set(found))
        raise ValueError("Missing native Moonlight objects: " + ", ".join(missing))
    # All packages created by this tool are installable NG ZIPs; the runtime
    # refuses manifest-free native bundles, so the packager must do the same.
    if MANIFEST not in found:
        raise ValueError("Missing native runtime manifest: rebuild the ARM32 bundle")
    verify_runtime_manifest(found)
    return found


SOURCE_PIN = "packaging/moonlight-source-pin.json"


def read_pinned_source_revision(source):
    pin = Path(source) / SOURCE_PIN
    try:
        if pin.is_symlink() or pin.stat().st_size > 4096:
            raise ValueError("Invalid Moonlight source pin file")
        data = json.loads(pin.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as error:
        raise ValueError("Missing or malformed pinned Moonlight source revision") from error
    sha = data.get("moonlight_embedded") if isinstance(data, dict) and (
        data.get("schema") == "luna-native-source-pin-v1") else None
    if not isinstance(sha, str) or not re.fullmatch(r"[a-f0-9]{40}", sha):
        raise ValueError("Invalid pinned Moonlight source revision")
    return sha


RELEASE_LOCK_SCHEMA = "luna-ng-release-lock-v1"


def read_release_lock(filename):
    """Consume one immutable build's exact Luna/Moonlight revision pair.

    The assembler must first verify that the chosen Luna checkout or exported
    snapshot matches luna_revision. This file is build-time provenance, not a
    mutable cross-repository HEAD pin.
    """
    path = Path(filename)
    try:
        if path.is_symlink() or not 0 < path.stat().st_size <= 4096:
            raise ValueError("Invalid release-lock file")
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as error:
        raise ValueError("Missing or malformed Luna/Moonlight release lock") from error
    if not isinstance(data, dict) or set(data) != {
            "schema", "luna_revision", "moonlight_revision"} or (
            data["schema"] != RELEASE_LOCK_SCHEMA):
        raise ValueError("Invalid Luna/Moonlight release-lock schema")
    for field in ("luna_revision", "moonlight_revision"):
        if not isinstance(data[field], str) or not re.fullmatch(r"[0-9a-f]{40}", data[field]):
            raise ValueError("Invalid %s in release lock" % field)
    return data


def _package_source_files(source, verified_snapshot_revision=None, git_revision=None):
    """Capture exactly one immutable source snapshot for the release ZIP.

    A clean 'git status' is not proof that worktree bytes equal HEAD:
    skip-worktree can hide modifications. A Git checkout therefore uses
    committed blob objects, not paths read from disk later. Verified
    Git-less exports read each allowlisted member once and check its hash.
    """
    if (source / ".git").exists():
        try:
            if git_revision is None:
                git_revision = subprocess.check_output(
                    ["git", "-C", str(source), "rev-parse", "HEAD"],
                    text=True, timeout=5).strip()
            if not isinstance(git_revision, str) or not re.fullmatch(
                    r"[0-9a-f]{40}", git_revision):
                raise ValueError("Invalid committed Luna source revision")
            raw = subprocess.check_output(
                ["git", "-C", str(source), "ls-tree", "-r", "-z", git_revision],
                timeout=10)
        except (OSError, subprocess.SubprocessError) as error:
            raise ValueError("Cannot enumerate committed Luna source tree") from error
        records = []
        for row in raw.split(b"\0"):
            if not row:
                continue
            try:
                metadata, encoded_name = row.split(b"\t", 1)
                mode, kind, digest = metadata.split()
                if (kind != b"blob" or mode not in (b"100644", b"100755") or
                        not re.fullmatch(rb"[0-9a-f]{40}", digest)):
                    raise ValueError("Unexpected Git object in Luna source tree")
            except ValueError as error:
                raise ValueError("Invalid committed Luna source tree entry") from error
            records.append((os.fsdecode(encoded_name), digest.decode("ascii")))
        entries = None
    elif verified_snapshot_revision is not None:
        # The trusted Moonlight assembler authenticates the source-lock
        # manifest against an independent private Git-blob digest pin first.
        manifest_path = source.parent / "source-lock.json"
        try:
            if manifest_path.is_symlink() or not (
                    0 < manifest_path.stat().st_size <= 256000):
                raise ValueError("Invalid authenticated source manifest")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            luna = manifest["sources"]["luna"]
            if (manifest.get("schema") != "luna-public-source-snapshot-v1" or
                    luna.get("repository") != "Roboatlas21/Luna" or
                    luna.get("revision") != verified_snapshot_revision or
                    not isinstance(luna.get("files"), dict) or
                    not luna["files"]):
                raise ValueError("Authenticated Luna export manifest does not match source")
            entries = luna["files"]
            records = [(name, None) for name in entries]
        except (OSError, UnicodeError, TypeError, KeyError, ValueError) as error:
            raise ValueError("Missing or invalid authenticated Luna export manifest") from error
    else:
        # Unlocked manual development packages make no provenance claim.
        return [(p, p.read_bytes()) for p in sorted(source.rglob("*"))
                if p.is_file() and not p.is_symlink()]

    result = []
    for name, digest in records:
        if not isinstance(name, str):
            raise ValueError("Invalid Luna source entry")
        relative = PurePosixPath(name)
        if (relative.is_absolute() or relative.as_posix() != name or
                not relative.parts or any(part in (".", "..") for part in relative.parts)):
            raise ValueError("Unsafe Luna source entry: %r" % name)
        path = source.joinpath(*relative.parts)
        if entries is None:
            # Git objects, not skip-worktree files or a potentially changing
            # disk view, are the authority for a release-locked checkout.
            try:
                content = subprocess.check_output(
                    ["git", "-C", str(source), "cat-file", "blob", digest],
                    timeout=10)
            except (OSError, subprocess.SubprocessError) as error:
                raise ValueError("Cannot read committed Luna source blob: " + name) from error
        else:
            if path.is_symlink() or not path.is_file():
                raise ValueError("Missing or unsafe Luna source file: " + name)
            expected = entries[name]
            if (not isinstance(expected, dict) or
                    expected.get("mode") not in ("100644", "100755")):
                raise ValueError("Invalid authenticated source entry: " + name)
            content = path.read_bytes()
            calculated = hashlib.sha1(
                b"blob " + str(len(content)).encode("ascii") + b"\0" + content
            ).hexdigest()
            if calculated != expected.get("blob_sha"):
                raise ValueError("Changed authenticated Luna source file: " + name)
        result.append((path, content))
    return sorted(result, key=lambda item: item[0])



def versioned_addon_xml(data):
    root = ElementTree.fromstring(data)
    if root.tag != "addon" or root.get("id") != ADDON_ID:
        raise ValueError("Not the expected Luna addon.xml")

    version = root.get("version", "")
    parts = version.split(".")
    if len(parts) < 3 or any(not p.isdecimal() for p in parts):
        raise ValueError("Invalid Kodi addon version: " + version)
    # addon.xml is the single version source. Never silently reuse an old
    # package number or generate the same +1 version on every build.
    next_version = version
    root.set("version", next_version)
    root.set("name", "Luna NG (CoreELEC 21 ARM32 test)")
    root.set("provider-name", "Vortex, Roboatlas21")
    return ElementTree.tostring(root, encoding="utf-8", xml_declaration=True), next_version


def zip_entry(zip_file, path, data, executable=False):
    info = zipfile.ZipInfo(ADDON_ID + "/" + path, date_time=(2026, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    mode = 0o755 if executable else 0o644
    info.external_attr = (stat.S_IFREG | mode) << 16
    zip_file.writestr(info, data)


def package(source, bundle, output, vfm_directory=None, release_lock=None,
            verified_snapshot_revision=None):
    source = Path(source).resolve()
    if not (source / ".git").exists() and not (source / "addon.xml").is_file():
        raise ValueError("Luna repository root must contain addon.xml")
    native = native_members(bundle)
    release = read_release_lock(release_lock) if release_lock is not None else None
    if release is None:
        # Legacy manual packaging defaults to the reviewed native source pin.
        expected_source = read_pinned_source_revision(source)
    else:
        expected_source = release["moonlight_revision"]
        # A local private checkout can be verified directly without depending
        # on a public export or another repo's credentials.
        if (source / ".git").exists():
            try:
                actual_luna = subprocess.check_output(
                    ["git", "-C", str(source), "rev-parse", "HEAD"],
                    text=True, timeout=5).strip()
            except (OSError, subprocess.SubprocessError) as error:
                raise ValueError("Cannot verify local Luna source revision") from error
            if actual_luna != release["luna_revision"]:
                raise ValueError("Luna source revision does not match release lock")
            try:
                dirty = subprocess.check_output(
                    ["git", "-C", str(source), "status", "--porcelain",
                     "--untracked-files=normal"], text=True, timeout=5).strip()
            except (OSError, subprocess.SubprocessError) as error:
                raise ValueError("Cannot verify clean Luna checkout") from error
            if dirty:
                raise ValueError("Luna checkout contains uncommitted changes; "
                                 "cannot label unreviewed bytes with a release commit")
        else:
            # A git-less export cannot prove its own Git revision. Only a
            # separate assembler that checked the immutable export manifest
            # against an externally pinned source may supply this identity.
            if verified_snapshot_revision != release["luna_revision"]:
                raise ValueError("Git-less Luna release-lock source requires a "
                                 "separately verified snapshot revision")
    actual_source = verify_runtime_manifest(native)["source_git_sha"]
    if actual_source != expected_source:
        raise ValueError(
            "Native Moonlight source revision does not match Luna's pinned build: "
            "expected %s, received %s" % (expected_source, actual_source))
    # Materialize immutable bytes once. Everything added to the ZIP must
    # come from these verified bytes, never a later worktree read.
    source_files = _package_source_files(
        source, verified_snapshot_revision,
        git_revision=release["luna_revision"] if release is not None and
        (source / ".git").exists() else None)
    source_bytes = {path.relative_to(source).as_posix(): data
                    for path, data in source_files}
    if "addon.xml" not in source_bytes:
        raise ValueError("Committed Luna source is missing addon.xml")
    vfm_files = {}
    if vfm_directory is not None:
        # Do not execute a locally modified skip-worktree validator either.
        validator_name = 'resources/lib/util/vfmruntime.py'
        validator_content = source_bytes.get(validator_name)
        if validator_content is None:
            raise ValueError("Committed Luna source is missing the VFM validator")
        # The validator's two file readers must come from this same
        # immutable source snapshot. Importing them from sys.path would
        # silently substitute uncommitted or preloaded helper implementations.
        pinned_readers = {}
        for name in ('safefile', 'safejson'):
            relative = 'resources/lib/util/' + name + '.py'
            content = source_bytes.get(relative)
            if content is None:
                raise ValueError('Committed Luna source lacks pinned reader: ' + relative)
            namespace = {'__name__': '_luna_verified_' + name,
                         '__file__': str(source / relative),
                         '__package__': None}
            exec(compile(content, namespace['__file__'], 'exec'), namespace)
            pinned_readers[name] = namespace
        spec = importlib.util.spec_from_loader('vfm_validator', loader=None)
        validator = importlib.util.module_from_spec(spec)
        validator.__file__ = str(source / validator_name)
        validator.__dict__['_LUNA_VERIFIED_READERS'] = (
            pinned_readers['safefile']['read_regular_bytes'],
            pinned_readers['safejson']['read_bounded_json'])
        exec(compile(validator_content, validator.__file__, 'exec'),
             validator.__dict__)
        root = Path(vfm_directory)
        manifest, verified_files = validator.verify_bundle(root, collect_bytes=True)
        for name, data in verified_files.items():
            vfm_files['vfm/' + name] = data
    addon_xml, version = versioned_addon_xml(source_bytes["addon.xml"])

    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if source in output.parents:
        raise ValueError("Output ZIP must be outside the source checkout")

    # Build and validate privately, then atomically publish. A failed write
    # or a failed checksum never destroys an existing working addon.
    fd, staged = tempfile.mkstemp(
        prefix=".luna-package-", suffix=".zip", dir=output.parent)
    os.close(fd)
    try:
        with zipfile.ZipFile(staged, "w", compression=zipfile.ZIP_DEFLATED) as result:
            zip_entry(result, "addon.xml", addon_xml)
            if release is not None:
                # Self-contained record of the exact reviewed source pair.
                zip_entry(result, "release-lock.json",
                          (json.dumps(release, sort_keys=True) + "\n").encode("utf-8"))
            # Unlike the original NO binary directory, this NG add-on does not
            # inherit a sample configuration. Luna rewrites it from Kodi settings,
            # but a safe empty placeholder ensures native get_path() can find it.
            zip_entry(result, "bin/coreelec-ng/moonlight.conf",
                      b"# Generated by Luna from Kodi settings on launch.\n[Moonlight]\n")
            for path, content in source_files:
                rel = path.relative_to(source)
                if (rel.as_posix() == "addon.xml" or
                        rel.parts[0] in EXCLUDED_ROOTS or
                        any(p in EXCLUDED_CACHE_DIRS for p in rel.parts[:-1])):
                    continue
                if len(rel.parts) >= 3 and rel.parts[:2] == ("resources", "launchscripts"):
                    if rel.parts[2] != NG_LAUNCHER:
                        continue
                if rel.suffix in (".pyc", ".pyo") or rel.name.startswith("."):
                    continue
                executable = rel.suffix == ".sh"
                zip_entry(result, rel.as_posix(), content, executable)
            for name, data in sorted(vfm_files.items()):
                zip_entry(result, name, data)
            for name in sorted(native):
                zip_entry(result, name, native[name],
                          executable=(name == "bin/coreelec-ng/moonlight"))
    

        # Read back the complete archive before replacing a published ZIP.
        with zipfile.ZipFile(staged) as result:
            for name in NATIVE_FILES:
                assert_arm32(result.read(ADDON_ID + "/" + name), name)
            if result.testzip():
                raise ValueError("ZIP corruption detected")
        with open(staged, "rb") as file:
            os.fsync(file.fileno())
        os.replace(staged, output)
    finally:
        if os.path.exists(staged):
            os.unlink(staged)
    return version


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("native_bundle", type=Path)
    parser.add_argument("--source", type=Path,
                        default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument('--vfm-directory', type=Path,
                        help='Optional verified ARM32 FFmpeg/VFM prototype bundle')
    parser.add_argument('--release-lock', type=Path,
                        help='Verified immutable Luna/Moonlight revision pair for this build')
    args = parser.parse_args()
    version = package(args.source, args.native_bundle, args.output,
                      vfm_directory=args.vfm_directory,
                      release_lock=args.release_lock)
    print("Created %s (Luna %s)" % (args.output, version))


if __name__ == "__main__":
    main()
