Luna NG CoreELEC 21 ARM32 version: 2.7.1.284
Luna frontend SHA: 3450d1bcede91e827e449ee40e94cbf2f64a9427
Moonlight native SHA: c1ae6949b41676097e549dc15c6a4b31d9ce5053
Native GitHub Actions run: 40261805728
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
