Luna NG CoreELEC 21 ARM32 version: 2.7.1.291
Luna frontend SHA: 97e791e074de1a341af93ab6caee2a0b134ddd33
Moonlight native SHA: fcd33bbc59be93253648ff916b6cb04f678855cb
Native GitHub Actions run: 40552613772
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
