/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 * Copyright (C) 2016 OtherCrashOverride, Daniel Mehrwald
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include <Limelight.h>

#include <sys/utsname.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <codec.h>
#include <errno.h>
#include <pthread.h>

#include <linux/videodev2.h>

#include "../util.h"
#include "video.h"
#include "aml_profile.h"
#include "aml_tuning.h"
#include "../osd/stats.h"

#define SYNC_OUTSIDE 0x02
#define UCODE_IP_ONLY_PARAM 0x08
#define MAX_WRITE_ATTEMPTS 5
#define EAGAIN_SLEEP_TIME 2 * 1000

/*
 * Vortex's CoreELEC NO binary exposes MOONLIGHT_HEVC_RFI=0 to disable
 * reference-frame invalidation when a decoder cannot reliably handle it.
 * Leave upstream behaviour unchanged unless the caller explicitly opts out.
 */
extern DECODER_RENDERER_CALLBACKS decoder_callbacks_aml;

static void __attribute__((constructor)) aml_configure_hevc_rfi(void) {
  const char *rfi = getenv("MOONLIGHT_HEVC_RFI");
  if (rfi != NULL && strcmp(rfi, "0") == 0) {
    decoder_callbacks_aml.capabilities &=
        ~CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC;
    fprintf(stderr, "HEVC reference-frame invalidation disabled (MOONLIGHT_HEVC_RFI=0)\n");
  }
}

static codec_para_t codecParam = { 0 };
static pthread_t displayThread;
static int videoFd = -1;
static volatile bool done = false;
static AmlProfile stream_profile;
static AmlTuning stream_tuning;

/* Cheap opt-in 32-bit atomics; no lock or per-frame print in the video path.
 * These are submission/V4L2-dequeue events, not guaranteed hardware presents. */
static AmlFrameStats osd_stats;
static bool osd_stats_enabled;
static uint32_t last_dequeue_ms;

void aml_osd_snapshot(AmlFrameStats *out) {
  if (!out) return;
  out->submitted = __atomic_load_n(&osd_stats.submitted, __ATOMIC_RELAXED);
  out->dequeued = __atomic_load_n(&osd_stats.dequeued, __ATOMIC_RELAXED);
  out->uses_v4l2 = __atomic_load_n(&osd_stats.uses_v4l2, __ATOMIC_RELAXED);
  out->submit_failures = __atomic_load_n(&osd_stats.submit_failures, __ATOMIC_RELAXED);
  out->codec_eagain = __atomic_load_n(&osd_stats.codec_eagain, __ATOMIC_RELAXED);
  out->idr_frames = __atomic_load_n(&osd_stats.idr_frames, __ATOMIC_RELAXED);
  out->codec_submit_us = __atomic_load_n(&osd_stats.codec_submit_us, __ATOMIC_RELAXED);
  out->codec_submit_samples = __atomic_load_n(&osd_stats.codec_submit_samples, __ATOMIC_RELAXED);
  out->dequeue_gaps_25ms = __atomic_load_n(&osd_stats.dequeue_gaps_25ms, __ATOMIC_RELAXED);
  out->dequeue_gaps_33ms = __atomic_load_n(&osd_stats.dequeue_gaps_33ms, __ATOMIC_RELAXED);
  out->host_samples = __atomic_load_n(&osd_stats.host_samples, __ATOMIC_RELAXED);
  out->host_tenths_ms = __atomic_load_n(&osd_stats.host_tenths_ms, __ATOMIC_RELAXED);
  out->assembly_samples = __atomic_load_n(&osd_stats.assembly_samples, __ATOMIC_RELAXED);
  out->assembly_us = __atomic_load_n(&osd_stats.assembly_us, __ATOMIC_RELAXED);
  out->stream_width = __atomic_load_n(&osd_stats.stream_width, __ATOMIC_RELAXED);
  out->stream_height = __atomic_load_n(&osd_stats.stream_height, __ATOMIC_RELAXED);
  out->codec_family = __atomic_load_n(&osd_stats.codec_family, __ATOMIC_RELAXED);
}

void *pkt_buf = NULL;
size_t pkt_buf_size = 0;

void* aml_display_thread(void* unused) {
  while (!done) {
    struct v4l2_buffer vbuf = { 0 };
    vbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (ioctl(videoFd, VIDIOC_DQBUF, &vbuf) < 0) {
      if (errno == EAGAIN) {
        aml_profile_display_poll(&stream_profile, false);
        usleep(500);
        continue;
      }
      fprintf(stderr, "VIDIOC_DQBUF failed: %d\n", errno);
      break;
    }

    aml_profile_display_poll(&stream_profile, true);
    if (osd_stats_enabled) {
      __atomic_fetch_add(&osd_stats.dequeued, 1, __ATOMIC_RELAXED);
      const uint32_t ms = (uint32_t)(aml_profile_now_us() / 1000);
      if (last_dequeue_ms) {
        const uint32_t gap = ms - last_dequeue_ms;
        if (gap > 25) __atomic_fetch_add(&osd_stats.dequeue_gaps_25ms, 1, __ATOMIC_RELAXED);
        if (gap > 33) __atomic_fetch_add(&osd_stats.dequeue_gaps_33ms, 1, __ATOMIC_RELAXED);
      }
      last_dequeue_ms = ms;
    }
    if (ioctl(videoFd, VIDIOC_QBUF, &vbuf) < 0) {
      fprintf(stderr, "VIDIOC_QBUF failed: %d\n", errno);
      break;
    }
  }
  printf("Display thread terminated\n");
  return NULL;
}

int aml_setup(int videoFormat, int width, int height, int redrawRate, void* context, int drFlags) {
  // Diagnostics are off unless explicitly enabled. No per-frame logging.
  aml_profile_init(&stream_profile, getenv("MOONLIGHT_AML_PROFILE"));
  osd_stats_enabled = getenv("MOONLIGHT_AML_OSD") &&
                      strcmp(getenv("MOONLIGHT_AML_OSD"), "1") == 0;
  memset(&osd_stats, 0, sizeof(osd_stats));
  if (osd_stats_enabled) {
    __atomic_store_n(&osd_stats.stream_width, (uint32_t)width, __ATOMIC_RELAXED);
    __atomic_store_n(&osd_stats.stream_height, (uint32_t)height, __ATOMIC_RELAXED);
    const uint32_t family = (videoFormat & VIDEO_FORMAT_MASK_H264) ? 1 :
                            (videoFormat & VIDEO_FORMAT_MASK_H265) ? 2 : 0;
    __atomic_store_n(&osd_stats.codec_family, family, __ATOMIC_RELAXED);
  }
  last_dequeue_ms = 0;
  done = false;

  codecParam.handle             = -1;
  codecParam.cntl_handle        = -1;
  codecParam.audio_utils_handle = -1;
  codecParam.sub_handle         = -1;
  codecParam.has_video          = 1;
  codecParam.noblock            = 0;
  codecParam.stream_type        = STREAM_TYPE_ES_VIDEO;
  codecParam.am_sysinfo.param   = 0;

#ifdef STREAM_TYPE_FRAME
  codecParam.dec_mode           = STREAM_TYPE_FRAME;
#endif

#ifdef FRAME_BASE_PATH_AMLVIDEO_AMVIDEO
  codecParam.video_path         = FRAME_BASE_PATH_AMLVIDEO_AMVIDEO;
#endif

  if (videoFormat & VIDEO_FORMAT_MASK_H264) {
    if (width > 1920 || height > 1080) {
      codecParam.video_type = VFORMAT_H264_4K2K;
      codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_H264_4K2K;
    } else {
      codecParam.video_type = VFORMAT_H264;
      codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_H264;

      // Workaround for decoding special case of C1, 1080p, H264
      int major, minor;
      struct utsname name;
      uname(&name);
      int ret = sscanf(name.release, "%d.%d", &major, &minor);
      if (ret == 2 && !(major > 3 || (major == 3 && minor >= 14)) && width == 1920 && height == 1080)
          codecParam.am_sysinfo.param = (void*) UCODE_IP_ONLY_PARAM;
    }
  } else if (videoFormat & VIDEO_FORMAT_MASK_H265) {
    codecParam.video_type = VFORMAT_HEVC;
    codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_HEVC;
#ifdef CODEC_TAG_AV1
  } else if (videoFormat & VIDEO_FORMAT_MASK_AV1) {
    codecParam.video_type = VFORMAT_AV1;
    codecParam.am_sysinfo.format = VIDEO_DEC_FORMAT_AV1;
#endif
  } else {
    printf("Video format not supported\n");
    return -1;
  }

  codecParam.am_sysinfo.width = width;
  codecParam.am_sysinfo.height = height;
  codecParam.am_sysinfo.rate = 96000 / redrawRate;
  codecParam.am_sysinfo.param = (void*) ((size_t) codecParam.am_sysinfo.param | SYNC_OUTSIDE);

  aml_tuning_init(&stream_tuning, NULL);
  aml_tuning_configure(&stream_tuning,
      (videoFormat & VIDEO_FORMAT_MASK_H265) != 0,
      getenv("MOONLIGHT_AML_TUNING_PROBE"),
      getenv("MOONLIGHT_AML_VFM"),
      getenv("MOONLIGHT_AML_HEVC_TUNING"));

  int ret;
  if ((ret = codec_init(&codecParam)) != 0) {
    fprintf(stderr, "codec_init error: %x\n", ret);
    aml_tuning_restore(&stream_tuning);
    return -2;
  }

  if ((ret = codec_set_freerun_mode(&codecParam, 1)) != 0) {
    fprintf(stderr, "Can't set Freerun mode: %x\n", ret);
    aml_tuning_restore(&stream_tuning);
    return -2;
  }

  char vfm_map[2048] = {};
  char* eol;
  if (read_file("/sys/class/vfm/map", vfm_map, sizeof(vfm_map) - 1) > 0 && (eol = strchr(vfm_map, '\n'))) {
    *eol = 0;

    // If amlvideo is in the pipeline, we must spawn a display thread
    printf("VFM map: %s\n", vfm_map);
    if (strstr(vfm_map, "amlvideo")) {
      printf("Using display thread for amlvideo pipeline\n");

      videoFd = open("/dev/video10", O_RDONLY | O_NONBLOCK);
      if (videoFd < 0) {
        fprintf(stderr, "Failed to open video device: %d\n", errno);
        aml_tuning_restore(&stream_tuning);
        return -3;
      }

      if (pthread_create(&displayThread, NULL, aml_display_thread, NULL) == 0) {
        __atomic_store_n(&osd_stats.uses_v4l2, 1, __ATOMIC_RELAXED);
      } else {
        fprintf(stderr, "Failed to start V4L2 display thread\n");
        close(videoFd);
        videoFd = -1;
        aml_tuning_restore(&stream_tuning);
        return -3;
      }
    }
  }

  ensure_buf_size(&pkt_buf, &pkt_buf_size, INITIAL_DECODER_BUFFER_SIZE);

  return 0;
}

void aml_cleanup() {
  if (videoFd >= 0) {
    done = true;
    pthread_join(displayThread, NULL);
    close(videoFd);
    videoFd = -1;
  }

  codec_close(&codecParam);
  aml_tuning_restore(&stream_tuning);
  aml_profile_report(&stream_profile, stderr);
  free(pkt_buf);
  pkt_buf = NULL;
  pkt_buf_size = 0;
}

int aml_submit_decode_unit(PDECODE_UNIT decodeUnit) {
  const uint64_t submit_start_us =
      (stream_profile.enabled || osd_stats_enabled) ? aml_profile_now_us() : 0;
  unsigned int write_calls = 0;
  unsigned int eagain_count = 0;

  ensure_buf_size(&pkt_buf, &pkt_buf_size, decodeUnit->fullLength);

  int written = 0, length = 0, errCounter = 0, api;
  PLENTRY entry = decodeUnit->bufferList;
  do {
    memcpy(pkt_buf+length, entry->data, entry->length);
    length += entry->length;
    entry = entry->next;
  } while (entry != NULL);

  // Moonlight's presentation timestamp is now in microseconds. Amlogic's
  // codec_checkin_pts() receives milliseconds here, as in Vortex's NO build.
  // Do not forward the raw microsecond value or use the removed TimeMs field.
  codec_checkin_pts(&codecParam, decodeUnit->presentationTimeUs / 1000);
  const uint64_t write_start_us = stream_profile.enabled ? aml_profile_now_us() : 0;
  while (length > 0) {
    api = codec_write(&codecParam, pkt_buf+written, length);
    if (stream_profile.enabled) write_calls++;
    if (api < 0) {
      if (errno != EAGAIN) {
        fprintf(stderr, "codec_write() error: %x %d\n", errno, api);
        codec_reset(&codecParam);
        break;
      } else {
        if (stream_profile.enabled) eagain_count++;
        if (osd_stats_enabled) __atomic_fetch_add(&osd_stats.codec_eagain, 1, __ATOMIC_RELAXED);
        if (++errCounter == MAX_WRITE_ATTEMPTS) {
          fprintf(stderr, "codec_write() timeout\n");
          break;
        }
        usleep(EAGAIN_SLEEP_TIME);
      }
    } else {
      written += api;
      length -= api;
    }
  }

  if (osd_stats_enabled) {
    __atomic_fetch_add(&osd_stats.submitted, 1, __ATOMIC_RELAXED);
    if (decodeUnit->frameType == FRAME_TYPE_IDR)
      __atomic_fetch_add(&osd_stats.idr_frames, 1, __ATOMIC_RELAXED);
    const uint64_t end_us = aml_profile_now_us();
    if (end_us >= submit_start_us && end_us - submit_start_us <= 1000000) {
      __atomic_fetch_add(&osd_stats.codec_submit_us,
                         (uint32_t)(end_us - submit_start_us), __ATOMIC_RELAXED);
      __atomic_fetch_add(&osd_stats.codec_submit_samples, 1, __ATOMIC_RELAXED);
    }
    if (length) __atomic_fetch_add(&osd_stats.submit_failures, 1, __ATOMIC_RELAXED);
    if (decodeUnit->frameHostProcessingLatency) {
      __atomic_fetch_add(&osd_stats.host_tenths_ms, decodeUnit->frameHostProcessingLatency,
                         __ATOMIC_RELAXED);
      __atomic_fetch_add(&osd_stats.host_samples, 1, __ATOMIC_RELAXED);
    }
    if (decodeUnit->enqueueTimeUs >= decodeUnit->receiveTimeUs) {
      uint64_t dt = decodeUnit->enqueueTimeUs - decodeUnit->receiveTimeUs;
      if (dt <= 1000000) {
        __atomic_fetch_add(&osd_stats.assembly_us, (uint32_t)dt, __ATOMIC_RELAXED);
        __atomic_fetch_add(&osd_stats.assembly_samples, 1, __ATOMIC_RELAXED);
      }
    }
  }
  if (stream_profile.enabled) {
    const uint64_t end_us = aml_profile_now_us();
    AmlProfileSample sample = {
      .bytes = decodeUnit->fullLength,
      // Both timestamps come from moonlight-common-c's own monotonic epoch.
      .assembly_us = decodeUnit->enqueueTimeUs >= decodeUnit->receiveTimeUs ?
          decodeUnit->enqueueTimeUs - decodeUnit->receiveTimeUs : 0,
      .submit_us = end_us >= submit_start_us ? end_us - submit_start_us : 0,
      .write_us = end_us >= write_start_us ? end_us - write_start_us : 0,
      .eagain = eagain_count,
      .write_calls = write_calls,
      .failed = length != 0
    };
    aml_profile_record(&stream_profile, &sample);
  }
  return length ? DR_NEED_IDR : DR_OK;
}

DECODER_RENDERER_CALLBACKS decoder_callbacks_aml = {
  .setup = aml_setup,
  .cleanup = aml_cleanup,
  .submitDecodeUnit = aml_submit_decode_unit,

  // We may delay in aml_submit_decode_unit() for a while, so we can't set CAPABILITY_DIRECT_SUBMIT
  .capabilities = CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC,
};
