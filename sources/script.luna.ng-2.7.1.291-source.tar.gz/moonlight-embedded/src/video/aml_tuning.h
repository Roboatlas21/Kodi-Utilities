/*
 * Experimental Amlogic VFM/HEVC configuration, opt-in only.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef MOONLIGHT_AML_TUNING_H
#define MOONLIGHT_AML_TUNING_H

#include <stdbool.h>
#include <stddef.h>

typedef struct {
  void *ctx;
  int (*read_text)(void *ctx, const char *path, char *text, size_t size);
  int (*write_text)(void *ctx, const char *path, const char *text);
} AmlTuningIo;

typedef struct {
  AmlTuningIo io;
  bool vfm_active;
  bool skip_active;
  bool ref_active;
  char original_vfm[128];
  char expected_vfm[64];
  char original_skip[64];
  char original_ref[128];
} AmlTuning;

void aml_tuning_init(AmlTuning *state, const AmlTuningIo *io);
/* Probe is read-only, apply is refused by default; enable with env == "1". */
void aml_tuning_configure(AmlTuning *state, bool hevc, const char *probe,
                          const char *vfm_opt_in, const char *hevc_opt_in);
void aml_tuning_restore(AmlTuning *state);

#endif
