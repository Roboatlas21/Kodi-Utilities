# CoreELEC 21 NG port

This branch starts at Moonlight Embedded commit `f7dc33c`, the upstream version
identified in Vortex's CoreELEC 22 NO Luna package.

## Target

- Hardware: Ugoos AM6B+ (Amlogic S922X-J).
- OS: Pannal's CoreELEC 21 NG (`PROJECT=Amlogic-ce`,
  `DEVICE=Amlogic-ng`, `ARCH=arm`).
- Native binaries must be built for the **32-bit ARM userspace** and against
  libraries from that CoreELEC tree. The supplied NO build is AArch64 and
  cannot be reused unchanged.
- Start with unmodified upstream Amlogic decoding. Do not assume Vortex's
  proprietary-to-this-build adjustments have been reconstructed.

## Build integration starting point

Pannal's CoreELEC tree already has:
`packages/addons/addon-depends/moonlight-embedded/package.mk`

That recipe currently fetches an older TheChoconut revision and applies
`01-surround-fix.patch`. When adapting the recipe to this source, enable
the equivalent **optional** mapping at CMake configuration time:

```sh
-DENABLE_CORE_ELEC_AUDIO_MAPPING=ON
```

Do **not** simultaneously apply `01-surround-fix.patch` to this fork;
its mapping is now available through the option, and the old context
would likely conflict. Leave the option OFF for non-CoreELEC builds.

The new build must also use compatible moonlight-common-c and libamcodec
headers/libraries. Keep the CoreELEC 21 sysroot and architecture together.

## Validation not yet performed

- [ ] Cross-compile using Pannal's CoreELEC 21 toolchain
- [ ] Verify built executable and libraries are ARM 32-bit ELF
- [ ] Resolve shared libraries against the NG image
- [ ] Pair with Sunshine and launch a 1080p60 H.264 desktop
- [ ] Verify Kodi returns after quit and failure
- [ ] Test stereo, 5.1 and 7.1 channel placement
- [ ] Test HEVC and higher resolutions after baseline works

This document does not indicate that NG playback currently works.

## Verified Vortex native compatibility toggle

Vortex's AArch64 decoder disables HEVC reference-frame invalidation when
`MOONLIGHT_HEVC_RFI=0` is present in the process environment. Our NG source
implements this as an opt-in override, preserving the upstream default.
This is a compatibility/recovery option, **not a proven latency reduction**.

Vortex's VFM mapping and HEVC kernel parameters have been reconstructed
in `src/video/aml_tuning.c` behind three independent environment flags:
`MOONLIGHT_AML_TUNING_PROBE=1` (read-only),
`MOONLIGHT_AML_VFM=1` and `MOONLIGHT_AML_HEVC_TUNING=1`.
The two write-enabled modes remain **OFF by default**. The NG kernel source
confirms both HEVC parameters and the VFM command syntax, but only source-level
mock tests have passed. Device safety, frame pacing and latency remain untested.
See `docs/vfm-hevc-experiments.md`.
