# Experimental VFM routing and HEVC decoder settings

The native Moonlight Amlogic backend can now reproduce two observable parts
of Vortex's CoreELEC 22 NO binary. **All kernel writes are opt-in and OFF by
default.** The safer read-only mode should be tested first.

## What the binary does

The supplied `libmoonlight-aml.so` has strings and setup/cleanup routines
for:

- `rm default` / `add default vdec.h264.00 amvideo`, or
  `vdec.h265.00 amvideo`, followed by `add default decoder amvideo`.
- `/sys/module/amvdec_h265/parameters/nal_skip_policy` set to `0`.
- `/sys/module/amvdec_h265/parameters/ref_frame_mark_flag` set to the
  nine-element array `0,0,0,0,0,0,0,0,0`.

Pannal's *NG* 4.9.269 media-module source exposes both HEVC parameters.
Its default `nal_skip_policy` is `2`, with nine reference-mark flags at
`1`. The kernel's VFM driver accepts the `rm` and `add` commands and
may forcibly unregister an active provider when removing its mapping.

**This is not proof of reduced latency.** It changes how frames are
routed and how HEVC decoding treats error-marked pictures, which may
trade error concealment and stability for presentation behavior.

## Modes (Moonlight process environment)

| Variable | Value | Effect |
|---|---|---|
| `MOONLIGHT_AML_TUNING_PROBE` | `1` | Read-only: report VFM route and HEVC parameter values |
| `MOONLIGHT_AML_HEVC_TUNING` | `1` | For HEVC only: temporarily use the two zeroed HEVC parameters |
| `MOONLIGHT_AML_VFM` | `1` | Temporarily route H.264/HEVC through a direct VFM provider |

Unset or any value other than `1` does nothing.

We **do not** rewrite VFM unless the default chain is precisely idle
`decoder amvideo`. Active providers, `ppmgr`, `deinterlace`, unexpected
chains, missing sysfs nodes, and unusual HEVC defaults are left alone.
The HEVC change is applied only if both original parameters exactly match
the known NG defaults (`2` and nine `1` values).

The original values are saved, and the backend attempts restoration on
normal cleanup, on a failed decoder initialization, and on failures
partway through changing the values. It verifies expected values before
overwriting them so an external change during playback is not silently
replaced. Any failed restoration is reported to stderr/Luna's log.

### Important limitation

VFM and HEVC values are global kernel state, not per-process preferences.
**A forced kill, crash, power loss, or simultaneous video activity can
interrupt restoration.** The C code cannot guarantee rollback after
SIGKILL. Do not enable these modes on a primary daily-driver installation.

If the TV shows a black screen or Kodi does not return, first try a
normal device reboot. On a test box with working SSH, inspect the
`/sys/class/vfm/map` entry before issuing any manual changes. The
original default chain for which this experimental code permits rewriting
is exactly `decoder amvideo`; the appropriate recovery command in that
specific case is `add default decoder amvideo` after removing an
abandoned `default` mapping. **Never issue global VFM removal while
Kodi or another video player is actively playing.**

## Evidence and testing

- Vortex binary: uploaded
  `script.luna-2.7.1.277-f7dc33c8-NO-22.zip`,
  `lib/libmoonlight-aml.so`, disassembly functions `aml_setup`
  and `aml_cleanup`.
- Pannal kernel:
  `pannal/linux-amlogic` branch `amlogic-4.9-20`,
  `drivers/amlogic/media/common/vfm/vfm.c`.
- Pannal media module:
  `pannal/media_modules-aml` branch `amlogic-4.9.269`,
  `drivers/frame_provider/decoder/h265/vh265.c`.

Run host-based mock tests:

```sh
cc -std=c99 -Wall -Wextra -Werror -pedantic -O2 \
  tests/test_aml_tuning.c src/video/aml_tuning.c -o /tmp/test_aml_tuning
/tmp/test_aml_tuning
```

The mock covers opt-out/probe-only behavior, H.264 and HEVC routing,
both parameter writes/restores, active/unknown map refusal, altered
defaults, failed writes, and external changes.

### Recommended on-device sequence

1. First test the unchanged native baseline with both modes off.
2. Enable **read-only probe** on NG, record its actual VFM map and HEVC
   values, then turn it off. An unsupported map is a legitimate skip.
3. Test H.264 1080p60 with VFM only, using a disposable/test CoreELEC
   installation and an SSH recovery path.
4. Test HEVC 1080p60 with the HEVC controls only; then both together.
5. Compare frame pacing, stalls, drops and input-to-photon latency.
   Disable optional profiling for camera-based latency comparisons.
6. Check that the original VFM and HEVC values are restored after
   each normal exit. Repeat session start/stop and Sunshine disconnect.

The experimental features remain unvalidated on an actual AM6B+.
They are not enabled by the CoreELEC build recipe or the source tests.
