#include "../src/video/aml_tuning.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

typedef struct {
  char vfm[1024];
  char skip[64];
  char ref[128];
  int writes;
  int fail_at;
  int remove_effect_on_error;
} Fake;

static int mock_read(void *ctx, const char *path, char *out, size_t size) {
  Fake *f = ctx;
  const char *value = strstr(path, "/vfm/map") ? f->vfm :
    strstr(path, "nal_skip_policy") ? f->skip :
    strstr(path, "ref_frame_mark_flag") ? f->ref : NULL;
  if (!value || !*value || strlen(value) >= size) return -1;
  strcpy(out, value);
  return 0;
}

static int mock_write(void *ctx, const char *path, const char *value) {
  Fake *f = ctx;
  f->writes++;
  if (f->writes == f->fail_at) {
    if (f->remove_effect_on_error && strstr(path, "/vfm/map") &&
        !strcmp(value, "rm default"))
      strcpy(f->vfm, "[01]  dvpath { dvdv(0) amvideo }\n");
    return -1;
  }
  if (strstr(path, "/vfm/map")) {
    if (!strcmp(value, "rm default")) {
      strcpy(f->vfm, "[01]  dvpath { dvdv(0) amvideo }\n");
      return 0;
    }
    if (!strncmp(value, "add default ", 12)) {
      snprintf(f->vfm, sizeof(f->vfm), "[00]  default { %s }\n", value + 12);
      return 0;
    }
    return -1;
  }
  if (strstr(path, "nal_skip_policy")) { strcpy(f->skip, value); return 0; }
  if (strstr(path, "ref_frame_mark_flag")) { strcpy(f->ref, value); return 0; }
  return -1;
}

static void reset(Fake *f, AmlTuning *state) {
  memset(f, 0, sizeof(*f));
  strcpy(f->vfm, "[00]  default { decoder(0) amvideo }\n[01]  dvpath { dvdv(0) amvideo }\n");
  strcpy(f->skip, "2");
  strcpy(f->ref, "1,1,1,1,1,1,1,1,1");
  AmlTuningIo io = {.ctx=f, .read_text=mock_read, .write_text=mock_write};
  aml_tuning_init(state, &io);
}

int main(void) {
  AmlTuning state;
  Fake f;
  reset(&f, &state);
  aml_tuning_configure(&state, true, NULL, NULL, NULL);
  assert(!f.writes);
  aml_tuning_configure(&state, true, "1", NULL, NULL);
  assert(!f.writes);

  reset(&f, &state);
  aml_tuning_configure(&state, true, NULL, "1", "1");
  assert(state.vfm_active && state.skip_active && state.ref_active);
  assert(!strcmp(f.skip, "0") && !strcmp(f.ref, "0,0,0,0,0,0,0,0,0"));
  assert(strstr(f.vfm, "vdec.h265.00 amvideo"));
  aml_tuning_restore(&state);
  assert(!strcmp(f.skip, "2") && !strcmp(f.ref, "1,1,1,1,1,1,1,1,1"));
  assert(strstr(f.vfm, "decoder amvideo"));
  assert(!state.vfm_active && !state.skip_active && !state.ref_active);

  reset(&f, &state);
  aml_tuning_configure(&state, false, NULL, "1", "1");
  assert(state.vfm_active && !state.skip_active && !state.ref_active);
  assert(strstr(f.vfm, "vdec.h264.00 amvideo"));
  aml_tuning_restore(&state);
  assert(strstr(f.vfm, "decoder amvideo"));

  reset(&f, &state);
  strcpy(f.vfm, "[00]  default { decoder(1) amvideo }\n");
  aml_tuning_configure(&state, true, NULL, "1", NULL);
  assert(!f.writes && !state.vfm_active);

  reset(&f, &state);
  strcpy(f.vfm, "[00]  default { decoder(0) deinterlace(0) amvideo }\n");
  aml_tuning_configure(&state, true, NULL, "1", NULL);
  assert(!f.writes);

  reset(&f, &state);
  strcpy(f.skip, "3");
  aml_tuning_configure(&state, true, NULL, NULL, "1");
  assert(!f.writes);

  reset(&f, &state);
  f.fail_at = 2; /* ref write fails; restore skip */
  aml_tuning_configure(&state, true, NULL, NULL, "1");
  assert(!strcmp(f.skip, "2"));
  assert(!state.skip_active && !state.ref_active);

  reset(&f, &state);
  f.fail_at = 2; /* VFM add fails; should be restored */
  aml_tuning_configure(&state, true, NULL, "1", NULL);
  assert(!strcmp(f.vfm, "[00]  default { decoder amvideo }\n"));
  assert(!state.vfm_active);

  reset(&f, &state);
  f.fail_at = 1;  /* sysfs may report failed rm after invalidating mapping */
  f.remove_effect_on_error = 1;
  aml_tuning_configure(&state, true, NULL, "1", NULL);
  assert(strstr(f.vfm, "decoder amvideo"));
  assert(!state.vfm_active);

  reset(&f, &state);
  aml_tuning_configure(&state, true, NULL, NULL, "1");
  strcpy(f.skip, "3"); /* another process changed setting */
  aml_tuning_restore(&state);
  assert(!strcmp(f.skip, "3"));
  assert(!strcmp(f.ref, "1,1,1,1,1,1,1,1,1"));
  puts("All Amlogic VFM/HEVC tuning tests passed");
  return 0;
}
