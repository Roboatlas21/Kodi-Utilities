#!/bin/sh
# Restart Kodi if an independent Luna NG systemd session disappears after
# stopping kodi.service. This service is deliberately outside Kodi and outside
# the Luna session unit.
set -u
[ "$#" -eq 2 ] || exit 2
session_unit="$1"
session="$2"
SYSTEMCTL="${LUNA_SYSTEMCTL:-systemctl}"
KODI_UNIT="${LUNA_KODI_UNIT:-kodi.service}"

case "$session_unit" in
  ''|*[!A-Za-z0-9_.@-]*) exit 2 ;;
esac
[ -r "$session" ] || exit 1

restore_kodi_framebuffers() {
  for blank in "${LUNA_FB0_BLANK:-/sys/class/graphics/fb0/blank}" \
               "${LUNA_FB1_BLANK:-/sys/class/graphics/fb1/blank}"; do
    [ -e "$blank" ] || continue
    [ -w "$blank" ] && printf '0' > "$blank" 2>/dev/null || true
  done
}

printf '%s\n' ready > "$session.ready" || exit 1

while [ -e "$session" ]; do
  if ! "$SYSTEMCTL" is-active --quiet "$session_unit"; then
    break
  fi
  sleep 1
done

# Normal cleanup removes/disarms the marker before the session unit exits.
[ -e "$session" ] || {
  rm -f "$session.ready"
  exit 0
}

armed="$(cat "$session" 2>/dev/null || printf '0')"
if [ "$armed" = 1 ]; then
  restore_kodi_framebuffers
  attempt=0
  while [ "$attempt" -lt 15 ]; do
    if "$SYSTEMCTL" start "$KODI_UNIT"; then
      printf '0\n' > "$session" 2>/dev/null || true
      break
    fi
    attempt=$((attempt + 1))
    sleep 2
  done
fi

rm -f "$session" "$session.ready"
