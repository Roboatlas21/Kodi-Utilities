Luna NG CoreELEC 21 ARM32 corresponding GPLv3 source
Luna: 29f4139cfe486d9e65aa6c2805ddeec8e33de360
Moonlight Embedded: c1ae6949b41676097e549dc15c6a4b31d9ce5053
luna/ has Kodi frontend and packaging helpers
moonlight-embedded/ has native C source, submodules and CoreELEC NG recipe
