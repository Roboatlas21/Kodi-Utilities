#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
cat >"$tmp/killall" <<'EOF'
#!/bin/sh
printf '%s\n' "$*" >> "$CALLS"
EOF
cat >"$tmp/moonlight" <<'EOF'
#!/bin/sh
printf '%s\n' "$*" >> "$CALLS"
exit 42
EOF
chmod +x "$tmp/killall" "$tmp/moonlight"
export CALLS="$tmp/calls" LUNA_LOG_DIR="$tmp/logs" MOONLIGHT_BINARY="$tmp/moonlight"
export PATH="$tmp:$PATH"
launcher="$root/resources/launchscripts/coreelec/launch.sh"
watchdog="$root/resources/launchscripts/coreelec/kodi-watchdog.sh"
grep -Fxq '#!/bin/sh' "$launcher"
grep -Fxq '#!/bin/sh' "$watchdog"
for stage in prescript postscript; do
  helper="$root/resources/launchscripts/coreelec/$stage.sh"
  grep -Fxq '#!/bin/sh' "$helper"
  "$helper" "$tmp" H264
done
sh -n "$launcher"
sh -n "$watchdog"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 42 ]]
grep -q -- '-STOP kodi.bin' "$CALLS"
grep -q -- 'stream -app Desktop' "$CALLS"
grep -q -- '-CONT kodi.bin' "$CALLS"
[[ "$(grep -c -- '-CONT kodi.bin' "$CALLS")" == 1 ]]
[[ -z "$(find "$tmp/logs" -name '.luna-session.*' -print)" ]]
: > "$CALLS"
export MOONLIGHT_BINARY="$tmp/no-binary"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 127 ]]
! grep -q -- '-STOP kodi.bin' "$CALLS"

# A real SIGKILL is not required to test recovery: simulate a zombie launcher
# in a fixture /proc tree and check that the independent worker sends CONT.
mkdir -p "$tmp/proc/424242"
printf '424242 (launch with spaces) Z' >"$tmp/proc/424242/stat"
for i in $(seq 1 18); do printf ' 0' >>"$tmp/proc/424242/stat"; done
printf ' 123456 0\n' >>"$tmp/proc/424242/stat"
: > "$CALLS"
export LUNA_WATCHDOG_TEST_ONLY=1 LUNA_WATCHDOG_TEST_PROC="$tmp/proc"
touch "$tmp/fixture-session"
sh "$watchdog" 424242 123456 "$tmp/fixture-session"
grep -Fq -- '-CONT kodi.bin' "$CALLS"
[[ ! -e "$tmp/fixture-session" ]]
[[ ! -e "$tmp/fixture-session.ready" ]]
echo 'PASS: normal exit, missing binary, and independent zombie rescue'
