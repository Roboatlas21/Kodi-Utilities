Luna NG 2.7.1.305 for CoreELEC 21 NG ARM32, with optional VFM runtime.

This archive contains the exact exported Moonlight and Luna sources, recursive
Moonlight common-code submodules, controller mappings, release-ID transform,
private FFmpeg recipe/nonblocking patch, VFM bridge source, stock CoreELEC build
recipes and patches, stock media module sources, FFmpeg 8.1.2 upstream source,
and libdrm 2.4.120 upstream source. The complete CoreELEC and FFmpeg archives
are supplied as checksummed parts beside this archive in the public repository.
Run python3 upstream/download-sources.py to retrieve and reassemble them.
See SOURCE_PROVENANCE.json for pinned commits
and archive checksums; build-inputs contains the successful build's manifests.
No private Git history or credentials are included.

The stock Linux base is publicly available at the exact recorded revision:
https://github.com/pannal/linux-amlogic/archive/2d0e0cc0db958d8d88f76407ac922f08d9a4004e.tar.gz
Browse the complete kernel source:
https://github.com/pannal/linux-amlogic/tree/2d0e0cc0db958d8d88f76407ac922f08d9a4004e
The kernel source is obtained from that public URL, not embedded in this archive.
Its CoreELEC patches and build configuration are in upstream/CoreELEC-872edca.tar.gz.
The bundled modules use that source and stock CE patches, plus the bridge code
in moonlight-embedded/kernel/moonlight-vfm. The full OS image is not installed.

For the native build use moonlight-embedded/docs/experimental-vfm.md and the
pinned dependencies in build-inputs/source-lock.json. The FFmpeg source archive
is pristine n8.1.2; the CoreELEC DRM PRIME patch and Moonlight nonblocking patch
must both be applied as specified by the build recipes. Stock media modules
also use the patches from the included CoreELEC recipes.

To reproduce this launcher-only update, use the complete native/VFM ZIP from
public run 41093196059, overlay the eight frontend files from luna/ listed in
SOURCE_PROVENANCE.json, and apply the Kodi-ID/version transform. The exact
overlay script and command are in release-tooling/LUNA_NG_PUBLISHING.md under
Luna NG 2.7.1.305.

The published ZIP preserves all native/VFM files and runtime manifests from
2.7.1.304 byte-for-byte. Only addon.xml and the eight frontend files change.
The default pipeline remains AML and existing settings and pairing are retained.

Changes in .305: remove the dependency on an external timeout command omitted
by the pinned CoreELEC BusyBox configuration. Service queries, launch and
recovery retain deadlines using the bundled Python runner. Failed service
queries report a specific dialog and journal reason. Legacy migration retains
its checks for surviving processes and pending recovery metadata.

The original public run passed host validation, ARM32 compilation, and VFM
runtime smoke tests. The updated frontend passed 251 local Luna tests, shell
launcher recovery checks, and nine release packaging tests. Local tests used
a proc namespace adapter for the test container, excluded from this archive.
Physical CoreELEC testing remains pending. No new native build was performed.

SOURCE_PROVENANCE.json identifies the updated frontend separately from the
original native build. build-inputs retains that original build's manifests.
