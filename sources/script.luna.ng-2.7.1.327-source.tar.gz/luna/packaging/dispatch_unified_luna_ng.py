#!/usr/bin/env python3
"""Capture both private branch heads BEFORE submitting a Luna NG build.

Use GitHub CLI authorization with read access to both private repositories
and Actions write access to Luna. This prevents an Actions queue from silently
switching your requested source pair to newer commits.
"""
import argparse
import re
import subprocess

SHA = re.compile(r"[a-f0-9]{40}\Z")


def gh(*args):
    return subprocess.check_output(["gh", *args], text=True).strip()


def source_pair():
    luna = gh("api", "repos/Roboatlas21/Luna/git/ref/heads/feat/vortex-ng",
              "--jq", ".object.sha")
    moonlight = gh("api", "repos/Roboatlas21/moonlight-embedded/git/ref/heads/feat/coreelec-ng",
                   "--jq", ".object.sha")
    if not SHA.fullmatch(luna) or not SHA.fullmatch(moonlight):
        raise ValueError("Could not capture exact source SHAs from both repositories")
    return luna, moonlight


def dispatch_build(luna, moonlight, *, publish=False, diagnostics_only=False,
                   force_native=False, clean_native=False, vfm=False):
    if not SHA.fullmatch(luna) or not SHA.fullmatch(moonlight):
        raise ValueError("Both source SHAs must be exact 40-hex commits")
    if publish and diagnostics_only:
        raise ValueError("Cannot both publish and run diagnostics only")
    arguments = [
        "api", "-X", "POST",
        "repos/Roboatlas21/Luna/actions/workflows/unified-luna-ng.yml/dispatches",
        "-f", "ref=matrix",
        "-f", "inputs[pin_luna_sha]=" + luna,
        "-f", "inputs[pin_moonlight_sha]=" + moonlight,
    ]
    for key, enabled in (
        ("publish_to_kodi", publish),
        ("validate_only", diagnostics_only),
        ("force_native", force_native),
        ("clean_native", clean_native),
        ("include_vfm_runtime", vfm),
    ):
        arguments.extend(("-f", "inputs[" + key + "]=" + str(enabled).lower()))
    gh(*arguments)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--diagnostics-only", action="store_true")
    parser.add_argument("--force-native", action="store_true")
    parser.add_argument("--clean-native", action="store_true")
    parser.add_argument("--vfm", action="store_true")
    args = parser.parse_args()
    if args.publish and args.diagnostics_only:
        parser.error("Cannot publish and run diagnostics only")
    luna, moonlight = source_pair()
    dispatch_build(luna, moonlight, publish=args.publish,
                   diagnostics_only=args.diagnostics_only,
                   force_native=args.force_native,
                   clean_native=args.clean_native,
                   vfm=args.vfm)
    print("Dispatched immutable Luna/Moonlight source pair:")
    print("  Luna:      " + luna)
    print("  Moonlight: " + moonlight)
    print("New commits will not replace either selected source.")


if __name__ == "__main__":
    main()
