#!/usr/bin/env python3
"""Require successful source CI on the exact Luna / Moonlight commit."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def matches(run, repo, workflow, branch, sha):
    if run.get("path") != ".github/workflows/" + workflow:
        return False
    if run.get("event") == "workflow_dispatch" and repo == "Roboatlas21/Luna":
        # Explicitly pinned dispatches may be started from either the
        # matrix Actions entrypoint or the development branch. Both checkout
        # and assert their requested SHA. An unpinned manual run has a
        # different run-name, so it cannot authorize an arbitrary revision.
        return (run.get("head_branch") in (branch, "matrix") and
                run.get("display_title") == "Luna source validation " + sha)
    if run.get("head_branch") != branch:
        return False
    if run.get("event") in ("push", "workflow_dispatch"):
        return run.get("head_sha") == sha
    return False


def latest(runs, repo, workflow, branch, sha):
    matches_for_sha = [r for r in runs if matches(r, repo, workflow, branch, sha)]
    return max(matches_for_sha, key=lambda r: (r.get("created_at", ""), r.get("id", 0)),
               default=None)


def fetch(repo, workflow, sha):
    """Find CI for the exact SHA, then search explicitly pinned dispatches.

    GitHub's head_sha filter finds historical push runs even when many later
    commits have run. Luna's workflow_dispatch can check out a different
    commit, so its run-name carries the verified input SHA.
    """
    endpoint = f"repos/{repo}/actions/workflows/{workflow}/runs"

    def pages(filters, max_pages=12):
        for page in range(1, max_pages + 1):
            path = f"{endpoint}?{filters}&per_page=100&page={page}"
            raw = subprocess.check_output(
                ["gh", "api", path], text=True, timeout=35)
            result = json.loads(raw).get("workflow_runs")
            if not isinstance(result, list):
                raise ValueError("Invalid GitHub workflow-runs response")
            yield from result
            if len(result) < 100:
                return
        raise RuntimeError("Source CI search exceeded its bounded page limit")

    runs = list(pages(f"head_sha={sha}"))
    if repo == "Roboatlas21/Luna":
        runs.extend(pages("event=workflow_dispatch"))
    return runs


def verify(repo, workflow, branch, sha, wait=480, poll=10,
           wait_for_missing=False, fetcher=fetch, clock=time.monotonic,
           sleeper=time.sleep):
    if repo not in ("Roboatlas21/Luna", "Roboatlas21/moonlight-embedded"):
        raise ValueError("Unexpected source repository")
    if not re.fullmatch(r"[0-9a-f]{40}", sha):
        raise ValueError("Invalid pinned source SHA")
    if not re.fullmatch(r"[a-z0-9-]+\.yml", workflow):
        raise ValueError("Invalid source workflow")
    deadline = clock() + wait
    while True:
        run = latest(fetcher(repo, workflow, sha), repo, workflow, branch, sha)
        if run is not None and run.get("status") == "completed":
            if run.get("conclusion") == "success":
                return run
            raise RuntimeError(f"{repo} CI for {sha} finished: "
                               f"{run.get('conclusion')}; {run.get('html_url', '')}")
        if run is None and not wait_for_missing:
            raise RuntimeError(f"No {repo} source-check CI for exact SHA {sha}; "
                               "skipped/older-commit CI cannot authorize a build")
        if clock() >= deadline:
            raise RuntimeError(f"Timed out waiting for {repo} CI at {sha}; "
                               f"run={run.get('html_url', '') if run else 'missing'}")
        sleeper(min(poll, max(0, deadline - clock())))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True)
    p.add_argument("--workflow", required=True)
    p.add_argument("--branch", required=True)
    p.add_argument("--sha", required=True)
    p.add_argument("--wait-for-missing", action="store_true")
    p.add_argument("--wait", type=int, default=480)
    args = p.parse_args()
    report = {"repo": args.repo, "sha": args.sha, "workflow": args.workflow,
              "result": "failure"}
    try:
        if not 0 <= args.wait <= 900:
            raise ValueError("Invalid CI wait budget")
        run = verify(args.repo, args.workflow, args.branch, args.sha,
                     wait=args.wait, wait_for_missing=args.wait_for_missing)
        run_id = int(run["id"])
        url = f"https://github.com/{args.repo}/actions/runs/{run_id}"
        report.update(result="success", run_id=run_id, url=url)
        print(f"SOURCE_CI_PASS {args.repo} {args.sha} {url}", flush=True)
        if os.getenv("GITHUB_OUTPUT"):
            with open(os.environ["GITHUB_OUTPUT"], "a", encoding="utf-8") as out:
                out.write(f"run_id={run_id}\nrun_url={url}\n")
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as ex:
        report["error"] = str(ex)
        print(f"::error::SOURCE_CI_FAIL {ex}", file=sys.stderr, flush=True)
        return 1
    finally:
        if os.getenv("SOURCE_VALIDATION_LOG_DIR"):
            output = Path(os.environ["SOURCE_VALIDATION_LOG_DIR"]) / "repository-ci"
            output.mkdir(parents=True, exist_ok=True)
            name = "luna.json" if args.repo == "Roboatlas21/Luna" else "moonlight.json"
            (output / name).write_text(json.dumps(report, sort_keys=True, indent=2) + "\n",
                                       encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
