#!/usr/bin/env python3
"""Safely recover an approved frozen v2 request as a NEW v4 source-pinned build.

The frozen v2 workflow is never rewritten or bypassed. After authenticating
its original full preflight, this re-dispatches its exact validated source pair
through the corrected v4 pipeline. A new version is reserved after revalidation.
"""
import argparse
import json
import re
import subprocess
import tempfile
from pathlib import Path

SHA = re.compile(r"[a-f0-9]{40}\Z")
RUN_ID = re.compile(r"[1-9][0-9]{6,}\Z")
V2_NATIVE = "ed7c2c01459f3481a2c6c7c59a5b6250fff01a4b"


def gh(*args):
    return subprocess.check_output(["gh", *args], text=True).strip()


def validate(approval, origin, jobs, requested_run):
    if (not isinstance(approval, dict) or
            approval.get("schema") != "luna-ng-native-request-v1" or
            approval.get("origin_run_id") != int(requested_run) or
            approval.get("completion_ref") != "refs/heads/luna-ng-launcher-v2" or
            approval.get("native_workflow_sha") != V2_NATIVE):
        raise ValueError("Not a matching approved frozen v2 build")
    source = approval.get("validation_luna_sha")
    native = approval.get("moonlight_sha")
    if not isinstance(source, str) or not SHA.fullmatch(source) or not isinstance(native, str) or not SHA.fullmatch(native):
        raise ValueError("Legacy request lacks original validated source pair")
    if (type(approval.get("publish_to_kodi")) is not bool or
            type(approval.get("include_vfm_runtime")) is not bool):
        raise ValueError("Legacy publication and VFM permissions are missing")
    if (not isinstance(origin, dict) or origin.get("id") != int(requested_run) or
            origin.get("path") != ".github/workflows/unified-luna-ng.yml" or
            origin.get("head_branch") != "matrix" or
            origin.get("event") != "workflow_dispatch" or
            (origin.get("head_repository") or {}).get("full_name") != "Roboatlas21/Luna"):
        raise ValueError("Original Luna run is not an approved matrix launch")
    attempt = approval.get("origin_run_attempt")
    if type(attempt) is not int or attempt < 1:
        raise ValueError("Invalid original approval attempt")
    passing = [j for j in jobs.get("jobs", []) if isinstance(j, dict) and
               j.get("name") == "unified / preflight" and
               j.get("run_id") == int(requested_run) and
               j.get("run_attempt") == attempt and
               j.get("status") == "completed" and j.get("conclusion") == "success"]
    if len(passing) != 1:
        raise ValueError("Frozen v2 original full preflight did not succeed")
    return source, native, approval["publish_to_kodi"], approval["include_vfm_runtime"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--origin-run-id", required=True)
    parser.add_argument("--dry-run", action="store_true",
                        help="Validate and print the source pair without dispatching")
    args = parser.parse_args()
    if not RUN_ID.fullmatch(args.origin_run_id):
        parser.error("Origin run ID must be a positive GitHub Actions run ID")
    with tempfile.TemporaryDirectory() as temp:
        subprocess.run(["gh", "run", "download", args.origin_run_id,
                        "-R", "Roboatlas21/Luna", "-n", "luna-ng-native-request",
                        "-D", temp], check=True)
        approval = json.loads((Path(temp) / "luna-ng-native-request.json").read_text())
    origin = json.loads(gh("api", "repos/Roboatlas21/Luna/actions/runs/" + args.origin_run_id))
    jobs = json.loads(gh("api", "repos/Roboatlas21/Luna/actions/runs/" +
                         args.origin_run_id + "/jobs?filter=all&per_page=100"))
    luna, moonlight, publish, vfm = validate(approval, origin, jobs, args.origin_run_id)
    print("Validated original frozen v2 approval, reusing exact SOURCE commits:")
    print("  Luna:      " + luna)
    print("  Moonlight: " + moonlight)
    if args.dry_run:
        print("Dry run: no workflow was dispatched.")
        return
    arguments = ["api", "-X", "POST",
                 "repos/Roboatlas21/Luna/actions/workflows/unified-luna-ng.yml/dispatches",
                 "-f", "ref=matrix",
                 "-f", "inputs[pin_luna_sha]=" + luna,
                 "-f", "inputs[pin_moonlight_sha]=" + moonlight,
                 "-f", "inputs[publish_to_kodi]=" + str(publish).lower(),
                 "-f", "inputs[include_vfm_runtime]=" + str(vfm).lower()]
    gh(*arguments)
    print("Dispatched a NEW v4 build with preserved source and original release intent.")
    print("The original frozen v2 run and its version reservation remain unchanged.")


if __name__ == "__main__":
    main()
