#!/usr/bin/env python3
"""Choose a monotonic version without moving the development branch.

A release reserves its version by pushing a unique immutable Git tag on a
metadata-only commit whose parent is the already validated Luna source SHA.
Later development commits never alter the selected source of a running build.
"""
import argparse
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ADDON_ID = "script.luna.ng"
VERSION = re.compile(r"[0-9]+(?:\.[0-9]+){3}\Z")


def parse_version(value):
    if not isinstance(value, str) or not VERSION.fullmatch(value):
        raise ValueError("Expected a four-part numeric Luna version")
    return tuple(int(part) for part in value.split("."))


def published_version(feed):
    root = ET.fromstring(Path(feed).read_bytes())
    if root.tag != "addons":
        raise ValueError("Invalid Kodi repository index")
    found = root.findall(f"addon[@id='{ADDON_ID}']")
    if len(found) != 1:
        raise ValueError("Expected exactly one published Luna NG entry")
    return parse_version(found[0].get("version"))


def versions_from_reservation_refs(path):
    """Parse exact names only; never trust arbitrary ls-remote output."""
    if path is None:
        return ()
    reserved = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        # Input is Git's --refs --tags output, not a list of arbitrary strings.
        match = re.fullmatch(
            r"[0-9a-f]{40}\trefs/tags/luna-ng-reserved-(\d+\.\d+\.\d+\.\d+)",
            line)
        if match:
            reserved.append(parse_version(match[1]))
    return tuple(reserved)


def release_version(addon, feed, reserved_versions=()):
    original = Path(addon).read_text(encoding="utf-8")
    root = ET.fromstring(original)
    if root.tag != "addon" or root.get("id") != ADDON_ID:
        raise ValueError("Unexpected Luna NG add-on identity")
    current = parse_version(root.get("version"))
    published = published_version(feed)
    # Do not accidentally change the major/minor/build line when incrementing.
    if current < published and current[:3] != published[:3]:
        raise ValueError(
            "Published Luna NG is on a different version line; update source addon.xml manually")
    # Reservation tags prevent two asynchronous native builds from assigning
    # the same ZIP version, without changing feat/vortex-ng itself.
    reservations = tuple(reserved_versions)
    if any(not isinstance(value, tuple) or len(value) != 4 or
           any(type(item) is not int or item < 0 for item in value)
           for value in reservations):
        raise ValueError("Invalid Luna reservation version inventory")
    # Historical lower-series reservations remain after an intentional
    # version-line upgrade; they must not block the new 2.8.0.x series.
    # However future-series tags must never silently upgrade a 2.7.1 source.
    if any(value[:3] > current[:3] for value in reservations):
        raise ValueError("Luna reservation belongs to a future version line")
    current_series = tuple(v for v in reservations if v[:3] == current[:3])
    latest = max((current, published, *current_series))
    next_version = (*latest[:3], latest[3] + 1)
    version = ".".join(str(number) for number in next_version)
    marker = re.compile(r'(<addon\b[^>]*\bversion=")([0-9]+(?:\.[0-9]+){3})(")', re.S)
    updated, replacements = marker.subn(lambda m: m.group(1) + version + m.group(3),
                                        original, count=1)
    if replacements != 1 or ET.fromstring(updated).get("version") != version:
        raise ValueError("Cannot update only the Luna addon version")
    return version, updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("addon_xml")
    parser.add_argument("public_addons_xml")
    parser.add_argument("--reservation-refs", type=Path)
    args = parser.parse_args()
    reservations = versions_from_reservation_refs(args.reservation_refs)
    version, content = release_version(
        args.addon_xml, args.public_addons_xml, reservations)
    path = Path(args.addon_xml)
    if path.read_text(encoding="utf-8") != content:
        path.write_text(content, encoding="utf-8")
    print(version)


if __name__ == "__main__":
    main()
