#!/usr/bin/env python3
"""Validate cached native ARM32 artifact bytes before Luna selects a run.

The GitHub Actions artifact index is only a lookup hint. The selected TAR
must independently stamp the pinned source, target, first-video capability,
and the exact immutable native workflow revision.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import tarfile

SHA = re.compile(r"[0-9a-f]{40}\Z")
TARGET = "Amlogic-ce/Amlogic-ng/arm"
MANIFEST_PATHS = {"runtime-manifest.json", "./runtime-manifest.json"}


def native_files_checked(archive):
    # Reuse the same byte-for-byte ELF, dependency, asset, digest and
    # manifest verifier that actually creates the installable Kodi ZIP.
    # A lightweight manifest-only preflight previously accepted a TAR
    # containing no native executable at all.
    spec = importlib.util.spec_from_file_location(
        "luna_ng_native_package", Path(__file__).with_name("package_ng.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.native_members(archive)


def verify(root: Path, source_sha: str, recipe_sha: str) -> bool:
    if not SHA.fullmatch(source_sha) or not SHA.fullmatch(recipe_sha):
        raise ValueError("Missing valid immutable native source or workflow SHA")
    root = Path(root)
    if not (root / "build-info.txt").is_file():
        root = root / "native"
    archive = root / "moonlight-coreelec21-ng-arm32.tar.gz"
    info = root / "build-info.txt"
    if not archive.is_file() or not info.is_file():
        raise ValueError("Incomplete ARM32 artifact")
    if info.stat().st_size > 131072:
        raise ValueError("Oversized native build information")
    lines = info.read_text(encoding="utf-8").splitlines()
    if (lines.count("SOURCE_GIT_SHA=" + source_sha) != 1 or
            lines.count("NATIVE_WORKFLOW_SHA=" + recipe_sha) != 1):
        raise ValueError("Native artifact source or build recipe differs from pinned SHA")
    members = native_files_checked(archive)
    manifest = json.loads(members["runtime-manifest.json"].decode("utf-8"))
    if (not isinstance(manifest, dict) or
            manifest.get("schema") != "luna-ng-runtime-v1" or
            manifest.get("source_git_sha") != source_sha or
            manifest.get("target") != TARGET or
            manifest.get("capabilities") != ["first-video-ready-v1"]):
        raise ValueError("Native manifest does not match exact validated source and ABI")
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact_dir", type=Path)
    parser.add_argument("source_sha")
    parser.add_argument("native_workflow_sha")
    args = parser.parse_args()
    try:
        verify(args.artifact_dir, args.source_sha, args.native_workflow_sha)
    except (OSError, ValueError, json.JSONDecodeError, tarfile.TarError) as exc:
        parser.exit(1, "Cached ARM32 artifact rejected: " + str(exc) + "\n")
    print("Validated cached ARM32 artifact and immutable native workflow recipe")


if __name__ == "__main__":
    main()
