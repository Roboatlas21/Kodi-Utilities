# Frozen Luna NG workflow generations

The manual `matrix` launcher selects the **current** Luna and Moonlight
source commits once per build. Their SHAs do not change during subsequent
native compilation, packaging or publication, even if development advances.

For new builds, these workflow *definitions* are fixed:

| Repository | Frozen workflow branch | Frozen commit |
| --- | --- | --- |
| Luna | `luna-ng-launcher-v2` | `65b0759e71b64dd67b4ae9713425386c6a878749` |
| Moonlight Embedded | `coreelec-ng-native-v2` | `ed7c2c01459f3481a2c6c7c59a5b6250fff01a4b` |
| Kodi Utilities Source | `luna-ng-publish-v2` | `c3ae84be97125dcaa0f341cbf4d6c0c0be08a26d` |

Old in-flight builds may continue with:
- Luna `luna-ng-launcher-v1` at `b06be5b0a909dfb0324c00b255f60e83afa23474`
- Moonlight `coreelec-ng-native-v1` at `cf46940ed5a0f81446129d1fd4a05188cdd052af`
- Publisher `luna-ng-publish-v1` at `3b401d31b9542fefba52c6a4919502ed5bd63ffd`

New builds store the exact native, publisher and completion-workflow SHA in
the immutable Luna approval. The receiving workflow refuses a mismatched
revision, which **fails closed** if a frozen branch is moved.

## Required repository protection

The GitHub app's repository connection cannot administer branch protection.
A repository administrator must complete these settings in GitHub:

1. Luna: **Settings → Rules → Rulesets → New branch ruleset**, target
   `luna-ng-launcher-v*`
2. Moonlight Embedded: add an equivalent ruleset for `coreelec-ng-native-v*`
3. Kodi Utilities Source: add an equivalent ruleset for `luna-ng-publish-v*`

For each ruleset enable **restrict updates** and **restrict deletions**,
keep it active, and allow bypasses only to administrators specifically
authorized to rotate workflows. Do not configure a rule that prevents GitHub
Actions from reading these branches. Verify each ruleset's effective target
and enforcement status on GitHub.

For a workflow change, create **v3** branches rather than modifying an old v1
or v2 ref, update and review the source-pinned workflow constants, then
point `matrix` to the new approved workflow. Do not repoint or delete old
branches while native builds may still be finishing.

## Artifact reuse and retry

- Duplicate requested native compiles serialize on the versioned native ref.
  Once the earlier run finishes, a later run can verify and re-upload its
  exact-SHA artifact rather than recompiling. `force_native` and clean native
  builds bypass this.
- Moonlight's completion callback uses the original Luna run ID and its
  native run ID. It checks for an existing active or successful completion
  before dispatch; recoverable downloads and dispatch checks are bounded.
- A public release must still exceed the version currently advertised in
  Kodi Utilities, even if the original source was selected earlier.

Automatic CI is not required for `[skip ci]` commits. The manual unified
preflight runs all independent validation groups before native compilation.
