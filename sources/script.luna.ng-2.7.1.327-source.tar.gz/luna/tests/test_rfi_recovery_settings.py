"""Exercise the actual launch-setting resolver without a running Kodi."""
import ast
from pathlib import Path
import unittest
from unittest.mock import Mock
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'resources/lib/util/moonlighthelper.py').read_text()
TREE = ast.parse(SOURCE)
FUNCTION = next(n for n in TREE.body if isinstance(n, ast.FunctionDef)
                and n.name == 'rfi_recovery_timeout')
NS = {}
exec(compile(ast.Module(body=[FUNCTION], type_ignores=[]), str(ROOT), 'exec'), NS)


class RecoverySettingTests(unittest.TestCase):
    def test_disabled_overrides_inherited_value(self):
        plugin = Mock()
        plugin.getSettingBool.return_value = False
        env = {'MOONLIGHT_RFI_RECOVERY_MS': '50'}
        method = next(n for n in ast.walk(TREE) if isinstance(n, ast.FunctionDef)
                      and n.name == '_stream_environment')
        assignments = [n for n in ast.walk(method) if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Subscript)
                               and isinstance(t.slice, ast.Constant)
                               and t.slice.value == 'MOONLIGHT_RFI_RECOVERY_MS'
                               for t in n.targets)]
        self.assertEqual(len(assignments), 1)
        local = dict(NS, env=env, self=Mock(plugin=plugin))
        exec(compile(ast.Module(body=assignments, type_ignores=[]), str(ROOT), 'exec'), local)
        self.assertEqual(env['MOONLIGHT_RFI_RECOVERY_MS'], '0')
        plugin.getSettingString.assert_not_called()

    def test_choices_and_invalid_saved_setting(self):
        plugin = Mock()
        plugin.getSettingBool.return_value = True
        for value in ('50', '100', '150', '200', '300', '500'):
            plugin.getSettingString.return_value = value
            self.assertEqual(NS['rfi_recovery_timeout'](plugin), value)
        for value in ('', '-1', '0', '1000', 'garbage'):
            plugin.getSettingString.return_value = value
            self.assertEqual(NS['rfi_recovery_timeout'](plugin), '100')

    def test_ui_defaults_and_dependency(self):
        xml = ET.parse(ROOT / 'resources/settings.xml').getroot()
        enabled = xml.find(".//setting[@id='experimental_rfi_recovery']")
        timeout = xml.find(".//setting[@id='rfi_recovery_timeout_ms']")
        self.assertEqual(enabled.findtext('default'), 'false')
        self.assertEqual(timeout.findtext('default'), '100')
        self.assertEqual([x.text for x in timeout.findall('constraints/options/option')],
                         ['50', '100', '150', '200', '300', '500'])
        dependency = timeout.find('dependencies/dependency')
        self.assertEqual(dependency.attrib['setting'], 'experimental_rfi_recovery')
        self.assertEqual(xml.findtext(".//setting[@id='frame_pacing']/default"), 'latency')


if __name__ == '__main__':
    unittest.main()
