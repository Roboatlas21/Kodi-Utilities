"""Frozen v2 recovery never reinterprets or elevates source approvals."""
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("recover_legacy", ROOT / "packaging/recover_legacy_v2.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
RUN = "41716072910"


def fixture():
    approval = {
        "schema": "luna-ng-native-request-v1",
        "origin_run_id": int(RUN),
        "origin_run_attempt": 1,
        "completion_ref": "refs/heads/luna-ng-launcher-v2",
        "native_workflow_sha": MODULE.V2_NATIVE,
        "validation_luna_sha": "a" * 40,
        "moonlight_sha": "b" * 40,
        "publish_to_kodi": False,
        "include_vfm_runtime": True,
    }
    origin = {
        "id": int(RUN), "path": ".github/workflows/unified-luna-ng.yml",
        "head_branch": "matrix", "event": "workflow_dispatch",
        "head_repository": {"full_name": "Roboatlas21/Luna"},
    }
    jobs = {"jobs": [{
        "run_id": int(RUN), "run_attempt": 1,
        "name": "unified / preflight", "status": "completed",
        "conclusion": "success",
    }]}
    return approval, origin, jobs


class LegacyV2RecoveryTests(unittest.TestCase):
    def test_original_pair_and_permissions_survive(self):
        a, o, j = fixture()
        self.assertEqual(MODULE.validate(a, o, j, RUN), ("a" * 40, "b" * 40, False, True))

    def test_only_v2_full_preflight_can_be_recovered(self):
        for index, key, value in (
            (0, "completion_ref", "refs/heads/luna-ng-launcher-v3"),
            (0, "validation_luna_sha", "broken"),
            (1, "event", "push"),
            (2, None, None),
        ):
            a, o, j = fixture()
            if index == 0: a[key] = value
            elif index == 1: o[key] = value
            else: j["jobs"][0]["conclusion"] = "failure"
            with self.subTest(index=index, key=key), self.assertRaises(ValueError):
                MODULE.validate(a, o, j, RUN)


if __name__ == "__main__":
    unittest.main()
