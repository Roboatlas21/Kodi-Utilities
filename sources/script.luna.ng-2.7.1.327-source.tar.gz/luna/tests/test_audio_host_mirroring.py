"""Host playback must not discard the explicit CoreELEC client ALSA device."""
import configparser
from pathlib import Path
import textwrap
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AudioHostMirroringTests(unittest.TestCase):
    def test_usb_audio_device_and_surround_survive_host_audio_toggle(self):
        source = (ROOT / 'resources/lib/util/confighelper.py').read_text(encoding='utf-8')
        start = source.index('        # Host playback is a Sunshine setting')
        end = source.index("        config.set('Moonlight', 'nounsupported',", start)
        block = textwrap.dedent(source[start:end])
        for local in ('false', 'true'):
            with self.subTest(local_audio=local):
                saved = {}
                class Plugin:
                    def setSettingString(self, key, value): saved[key] = value
                    def getSetting(self, key): return ''
                audio = types.SimpleNamespace(
                    list_playback=lambda: [],
                    default_device=lambda devices: None,
                    multichannel=lambda device: True,
                    supported_surround=lambda device, value: value)
                cfg = {'local_audio': local, 'audio_device_parameter': 'hw:USB,0',
                       'surround': '5.1', 'codec': 'h265'}
                fake = types.SimpleNamespace(config=cfg, plugin=Plugin())
                result = configparser.ConfigParser()
                result.add_section('Moonlight')
                exec(block, {'self': fake, 'config': result, 'audiodevices': audio})
                self.assertEqual(result.get('Moonlight', 'audio'), 'hw:USB,0')
                self.assertEqual(result.get('Moonlight', 'surround'), '5.1')
                self.assertEqual(saved['audio_multichannel'], 'true')
                self.assertEqual(cfg['surround'], '5.1')


if __name__ == '__main__':
    unittest.main()
