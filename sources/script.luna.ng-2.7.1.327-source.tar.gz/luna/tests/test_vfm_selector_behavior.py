"""Run the production cached-VFM guard on real tarballs with fake transport.

Includes source, manifest, checksum, ELF ABI and missing-artifact cases. No
hardware or CoreELEC native compilation is required.
"""
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import tarfile
import tempfile
import unittest

from workflow_shell import extract_shell_functions

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / ".github/workflows/unified-luna-ng.yml").read_text()
SHA = "a" * 40
OTHER = "b" * 40


def elf(module=False, marker=b""):
    header = bytearray(20)
    header[:6] = b"\x7fELF" + bytes([2 if module else 1, 1])
    struct.pack_into("<HH", header, 16, 1 if module else 3, 183 if module else 40)
    return bytes(header) + marker


def make_archive(path, *, source_sha=SHA, bad_digest=False):
    release = "4.9.269"
    files = {
        "lib/libmoonlight-aml-vfm.so": elf(marker=b"MOONLIGHT_VIDEO_READY_FILE"),
        "lib/libavcodec.so.60": elf(),
        "lib/libavutil.so.58": elf(),
        "modules/" + release + "/amvdec_ports.ko": elf(module=True),
        "modules/" + release + "/moonlight_vfm.ko": elf(module=True),
    }
    entries = {
        name: {"size": len(content), "sha256": hashlib.sha256(content).hexdigest()}
        for name, content in files.items()
    }
    if bad_digest:
        entries["lib/libavcodec.so.60"]["sha256"] = "0" * 64
    manifest = {
        "schema": "luna-ng-vfm-v1",
        "kernel_release": release,
        "bridge_version": "6",
        "decoder_version": "moonlight-hdr1",
        "module_order": ["amvdec_ports.ko", "moonlight_vfm.ko"],
        "moonlight_source_git_sha": source_sha,
        "objects": entries,
    }
    files["manifest.json"] = json.dumps(manifest).encode()
    with tarfile.open(path, "w:gz") as tar:
        for name, content in files.items():
            item = tarfile.TarInfo(name)
            item.mode = 0o644
            item.size = len(content)
            tar.addfile(item, io.BytesIO(content))


class VfmCandidateBehaviorTests(unittest.TestCase):
    def check(self, *, repo="fixture", enabled=True, source_sha=SHA,
              bad_digest=False, malformed=False, missing=False):
        helper = extract_shell_functions(WORKFLOW, "vfm_candidate_valid")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "luna").symlink_to(ROOT, target_is_directory=True)
            archive = root / "vfm.tar.gz"
            if malformed:
                archive.write_bytes(b"not a valid gzip archive")
            elif not missing:
                make_archive(archive, source_sha=source_sha, bad_digest=bad_digest)
            downloads = root / "downloads"
            script = r"""
set -euo pipefail
REQUIRE_VFM="$TEST_VFM"
caller_repo=fixture
LUNA_TOKEN=local-test
sha="$TEST_SOURCE"
candidate_deadline=$((SECONDS + 25))
gh() {
  printf '%s\n' "$*" >> "$RUNNER_TEMP/downloads"
  while [[ "$1" != -D ]]; do shift; done
  cp "$RUNNER_TEMP/vfm.tar.gz" "$2/moonlight-coreelec21-ng-vfm-runtime.tar.gz"
}
# GNU timeout can execute external commands, but not a mocked Bash function.
# Keep the production command/argument path and let Python's 20-second process
# deadline bound this isolated test invocation.
timeout() {
  [[ "$1" =~ ^[1-9][0-9]*s$ ]] || return 98
  shift
  "$@"
}
""" + helper + "\nvfm_candidate_valid " + repo + ' 123 "$RUNNER_TEMP/selection"\n'
            env = dict(os.environ, RUNNER_TEMP=str(root), TEST_SOURCE=SHA,
                       TEST_VFM="true" if enabled else "false")
            outcome = subprocess.run(
                ["bash", "-xeuo", "pipefail"], input=script, env=env,
                cwd=root, capture_output=True, text=True, timeout=20)
            count = len(downloads.read_text().splitlines()) if downloads.exists() else 0
            return outcome, count

    def test_valid_artifact_from_either_repository(self):
        for repository in ("fixture", "other-repo"):
            with self.subTest(repository=repository):
                result, count = self.check(repo=repository)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(count, 1)

    def test_malformed_archive_is_rejected(self):
        self.assertNotEqual(self.check(malformed=True)[0].returncode, 0)

    def test_wrong_source_sha_is_rejected(self):
        self.assertNotEqual(self.check(source_sha=OTHER)[0].returncode, 0)

    def test_changed_object_digest_is_rejected(self):
        self.assertNotEqual(self.check(bad_digest=True)[0].returncode, 0)

    def test_missing_archive_is_rejected(self):
        self.assertNotEqual(self.check(missing=True)[0].returncode, 0)

    def test_disabled_vfm_does_not_download(self):
        result, count = self.check(enabled=False, missing=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(count, 0)


if __name__ == "__main__":
    unittest.main()
