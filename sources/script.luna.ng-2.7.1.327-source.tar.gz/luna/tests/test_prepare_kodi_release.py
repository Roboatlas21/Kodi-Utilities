"""One-click Luna release versioning remains immutable and monotonic."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
FILE = ROOT / "packaging/prepare_kodi_release.py"
spec = importlib.util.spec_from_file_location("prepare_kodi_release", FILE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class ReleaseVersionTests(unittest.TestCase):
    def versions(self, source, public):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        addon = root / "addon.xml"
        feed = root / "addons.xml"
        addon.write_text(
            '<?xml version="1.0"?><addon id="script.luna.ng" '
            f'version="{source}" name="Luna" />')
        feed.write_text(
            '<addons><addon id="script.luna.ng" '
            f'version="{public}" /></addons>')
        return addon, feed

    def test_first_release_reserves_above_existing_private_version(self):
        addon, feed = self.versions("2.7.1.309", "2.7.1.308")
        version, updated = module.release_version(addon, feed)
        self.assertEqual(version, "2.7.1.310")
        self.assertIn('version="2.7.1.310"', updated)

    def test_followup_release_increments_only_fourth_component(self):
        addon, feed = self.versions("2.7.1.309", "2.7.1.309")
        version, updated = module.release_version(addon, feed)
        self.assertEqual(version, "2.7.1.310")
        self.assertIn('version="2.7.1.310"', updated)
        self.assertIn('name="Luna"', updated)
        self.assertEqual(addon.read_text().count("2.7.1.309"), 1)

    def test_published_older_line_preserves_higher_source(self):
        addon, feed = self.versions("2.8.0.1", "2.7.1.999")
        self.assertEqual(module.release_version(addon, feed)[0], "2.8.0.2")

    def test_different_published_version_line_is_not_auto_bumped(self):
        addon, feed = self.versions("2.7.1.309", "2.8.0.1")
        with self.assertRaisesRegex(ValueError, "different version line"):
            module.release_version(addon, feed)
        self.assertIn('version="2.7.1.309"', addon.read_text())

    def test_reservation_tags_override_source_and_public_feed(self):
        addon, feed = self.versions("2.7.1.323", "2.7.1.322")
        self.assertEqual(
            module.release_version(addon, feed, ((2, 7, 1, 324),
                                                 (2, 7, 1, 326)))[0],
            "2.7.1.327")

    def test_exact_tag_inventory_parsing_ignores_untrusted_names(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as directory:
            refs = Path(directory) / "tags.txt"
            refs.write_text(
                "a" * 40 + "\trefs/tags/luna-ng-reserved-2.7.1.325\n"
                + "b" * 40 + "\trefs/tags/other-2.7.1.999\n"
                + "c" * 40 + "\trefs/tags/luna-ng-reserved-bad\n"
            )
            self.assertEqual(module.versions_from_reservation_refs(refs),
                             ((2, 7, 1, 325),))

    def test_future_reservation_series_is_never_silently_used(self):
        addon, feed = self.versions("2.7.1.323", "2.7.1.321")
        for reserves in (((2, 8, 0, 1),),
                         ((2, 7, 1, 324), (2, 8, 0, 1))):
            with self.subTest(reserves=reserves):
                with self.assertRaisesRegex(ValueError, "future version line"):
                    module.release_version(addon, feed, reserves)

    def test_intentional_series_upgrade_ignores_older_reservations(self):
        addon, feed = self.versions("2.8.0.1", "2.7.1.999")
        self.assertEqual(
            module.release_version(
                addon, feed, ((2, 7, 1, 450), (2, 7, 1, 1000)))[0],
            "2.8.0.2")
        self.assertEqual(
            module.release_version(
                addon, feed, ((2, 7, 1, 450), (2, 8, 0, 3)))[0],
            "2.8.0.4")

    def test_lower_series_tags_do_not_change_same_series_allocation(self):
        addon, feed = self.versions("2.7.1.323", "2.7.1.321")
        self.assertEqual(
            module.release_version(addon, feed, ((2, 6, 9, 450),))[0],
            "2.7.1.324")

    def test_unpublished_reservation_is_not_reused(self):
        addon, feed = self.versions("2.7.1.400", "2.7.1.400")
        first, text = module.release_version(addon, feed)
        addon.write_text(text)  # durable reservation before native dispatch
        second, _ = module.release_version(addon, feed)
        self.assertEqual(first, "2.7.1.401")
        self.assertEqual(second, "2.7.1.402")

    def test_malformed_public_index_is_rejected(self):
        addon, feed = self.versions("2.7.1.309", "2.7.1.308")
        feed.write_text("<addons></addons>")
        with self.assertRaisesRegex(ValueError, "one published"):
            module.release_version(addon, feed)

    def test_malformed_version_is_rejected(self):
        addon, feed = self.versions("2.7.1.bad", "2.7.1.308")
        with self.assertRaisesRegex(ValueError, "four-part numeric"):
            module.release_version(addon, feed)


if __name__ == "__main__":
    unittest.main()
