"""Native/Python transport normalization parity without network requests."""
import json
import socket
import subprocess
import time
import unittest
from unittest import mock

from resources.lib.util.hostresolve import connect, socket_host, _cache


class SocketHostTests(unittest.TestCase):
    def test_ipv4_and_dns_identity_unchanged(self):
        for host in ('10.0.0.59', 'game-vm.local', 'Sunshine_2'):
            self.assertEqual(socket_host(host), host)

    def test_bare_bracketed_and_scoped_ipv6(self):
        for configured, socket_address in (
                ('::1', '::1'),
                ('[::1]', '::1'),
                ('[fe80::1%lo]', 'fe80::1%lo'),
                ('fe80::1%lo', 'fe80::1%lo'),
                ('fe80::1%25lo', 'fe80::1%lo'),
                ('[fe80::1%25lo]', 'fe80::1%lo')):
            with self.subTest(host=configured):
                self.assertEqual(socket_host(configured), socket_address)

    def test_rejects_malformed_ipv6_scopes_and_brackets(self):
        for invalid in ('', '[]', '[example.com]', '[::1',
                        '::1]', 'host:47989', 'fe80::1%',
                        'fe80::1%25', 'fe80::1%lo%evil',
                        'fe80::1%lo/path', 'fe80::1%lo?token=x'):
            with self.subTest(host=invalid), self.assertRaises(ValueError):
                socket_host(invalid)

    def test_stale_cached_dns_is_refreshed_without_second_user_attempt(self):
        key = ('sunshine.lan', 47989)
        stale = ['192.0.2.99', 47989]
        fresh = ['192.0.2.100', 47989]
        _cache[key] = (time.monotonic() + 60, [
            [socket.AF_INET, socket.SOCK_STREAM, 0, '', stale]])
        attempts = []

        class FakeSocket:
            def settimeout(self, _timeout):
                pass

            def connect(self, target):
                attempts.append(target)
                if target[0] != fresh[0]:
                    raise OSError('stale DNS address')

            def close(self):
                pass

        response = subprocess.CompletedProcess(
            ['python3'], 0,
            stdout=json.dumps([[socket.AF_INET, socket.SOCK_STREAM,
                                0, '', fresh]]))
        try:
            with mock.patch('resources.lib.util.hostresolve.subprocess.run',
                            return_value=response) as resolver, \
                 mock.patch('resources.lib.util.hostresolve.socket.socket',
                            side_effect=lambda *_: FakeSocket()):
                connected = connect(key)
            self.assertIsInstance(connected, FakeSocket)
            self.assertEqual([target[0] for target in attempts],
                             [stale[0], fresh[0]])
            resolver.assert_called_once()
        finally:
            _cache.pop(key, None)

    def test_fresh_dns_failure_does_not_retry_unboundedly(self):
        _cache.clear()
        response = subprocess.CompletedProcess(
            ['python3'], 0,
            stdout=json.dumps([[socket.AF_INET, socket.SOCK_STREAM, 0,
                                '', ['192.0.2.99', 47989]]]))
        class FailedSocket:
            def settimeout(self, *_):
                pass

            def connect(self, *_):
                raise OSError('host offline')

            def close(self):
                pass

        with mock.patch('resources.lib.util.hostresolve.subprocess.run',
                        return_value=response) as resolver, \
             mock.patch('resources.lib.util.hostresolve.socket.socket',
                        side_effect=lambda *_: FailedSocket()):
            with self.assertRaises(OSError):
                connect(('offline.lan', 47989), timeout=1)
        resolver.assert_called_once()

    def test_original_address_not_replaced_before_socket_resolution(self):
        # A failed resolver is sufficient to inspect argv without connecting.
        with mock.patch('resources.lib.util.hostresolve.subprocess.run',
                        side_effect=subprocess.CalledProcessError(1, 'python3')) as run:
            with self.assertRaises(socket.timeout):
                connect(('[fe80::1%25lo]', 47984))
        self.assertEqual(run.call_args.args[0][-2:], ['fe80::1%lo', '47984'])

    def test_actual_getaddrinfo_accepts_normalized_loopback(self):
        results = socket.getaddrinfo(socket_host('[::1]'), 47984,
                                     type=socket.SOCK_STREAM)
        self.assertTrue(any(item[0] == socket.AF_INET6 for item in results))


if __name__ == '__main__':
    unittest.main()
