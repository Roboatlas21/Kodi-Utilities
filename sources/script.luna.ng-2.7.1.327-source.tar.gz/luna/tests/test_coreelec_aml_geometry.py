"""CoreELEC AML profile failures must be caught before stopping Kodi."""
import tempfile
from pathlib import Path
import unittest

from resources.lib.util.runtimecheck import check_stream_geometry


class CoreElecAmlGeometryTests(unittest.TestCase):
    def check(self, width, height, fps, codec='h265', pipeline='aml'):
        with tempfile.TemporaryDirectory() as directory:
            ini = Path(directory) / 'stream.conf'
            ini.write_text(
                '[Moonlight]\nwidth = %s\nheight = %s\nfps = %s\n'
                'codec = %s\nrotate = 0\n' %
                (width, height, fps, codec))
            return check_stream_geometry(str(ini), pipeline)

    def test_common_supported_modes_pass(self):
        for width, height, fps in ((1280, 720, 60),
                                   (1920, 1080, 120),
                                   (3840, 2160, 60)):
            with self.subTest(mode=(width, height, fps)):
                self.assertIsNone(self.check(width, height, fps))

    def test_oversized_invalid_or_overclocked_profiles_fail(self):
        for width, height, fps in ((7680, 4320, 60),
                                   (4096, 2161, 30),
                                   (1921, 1080, 60),
                                   (1920, 1080, 240),
                                   (3840, 2160, 120)):
            with self.subTest(mode=(width, height, fps)):
                with self.assertRaisesRegex(ValueError, 'CoreELEC AML'):
                    self.check(width, height, fps)

    def test_unsupported_am6b_av1_is_blocked(self):
        with self.assertRaisesRegex(ValueError, 'does not support AV1'):
            self.check(1920, 1080, 60, codec='av1')

    def test_vfm_uses_same_conservative_coreelec_limits(self):
        with self.assertRaisesRegex(ValueError, 'CoreELEC AML'):
            self.check(3840, 2160, 120, pipeline='aml-vfm')


if __name__ == '__main__':
    unittest.main()
