"""Guarantee workflow test harnesses load dependent Bash functions."""
import subprocess
import unittest

from workflow_shell import extract_shell_functions


class WorkflowShellTests(unittest.TestCase):
    def test_transitive_dependency_closure_survives_reordering_and_comments(self):
        workflow = """
          action() {
            middle "hello"
          }
          # A moved comment must not affect extraction.
          leaf() {
            printf '%s' "$1"
          }
          middle() {
            leaf "$1"
          }
"""
        script = extract_shell_functions(workflow, "action")
        result = subprocess.run(
            ["bash", "-e"], input=script + "\naction\n",
            capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "hello")

    def test_only_transport_boundary_is_overridden(self):
        workflow = """
          action() {
            transport "hello"
          }
          transport() {
            exit 99
          }
"""
        script = extract_shell_functions(
            workflow, "action", overrides={"transport"})
        self.assertNotIn("exit 99", script)
        result = subprocess.run(
            ["bash", "-e"], input=script +
            "\ntransport() { printf '%s' \"$1\"; }\naction\n",
            capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, "hello")

    def test_ambiguous_missing_or_overridden_functions_raise(self):
        with self.assertRaisesRegex(ValueError, "Missing Bash function"):
            extract_shell_functions("", "missing")
        with self.assertRaisesRegex(ValueError, "Ambiguous duplicate"):
            extract_shell_functions(
                "  action() {\n  }\n  action() {\n  }\n", "action")
        with self.assertRaisesRegex(ValueError, "cannot be overridden"):
            extract_shell_functions("  action() {\n  }\n", "action",
                                    overrides={"action"})


if __name__ == "__main__":
    unittest.main()
