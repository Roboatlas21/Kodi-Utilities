"""Quit only the live app ID on the original authenticated host."""
import ast
from contextlib import contextmanager
import hashlib
from pathlib import Path
import sys
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]


class TestQuitHostGuard(unittest.TestCase):
    def setUp(self):
        parent = self
        self.settings = {'host_addr': 'host-A', 'last_run': 'Desktop', 'last_run_id': '11'}
        self.options = {'port': '47989'}
        self.states = ['11', '11']
        self.confirm, self.quit_ok, self.idle = True, True, True
        self.on_confirm = None
        self.calls, self.messages = [], []

        class Library:
            @staticmethod
            def host_identity(host, options=None):
                value = host.lower().strip() + repr(sorted((options or {}).items()))
                return hashlib.sha256(value.encode()).hexdigest()[:20]
        self.settings['last_run_host'] = Library.host_identity('host-A', self.options)

        class Addon:
            def getSetting(self, key): return parent.settings.get(key, '')
            def setSettingString(self, key, value): parent.settings[key] = value
            def getLocalizedString(self, key): return ''

        class Config:
            binary_path = '/addon/bin/coreelec-ng/'
            config = {'host_addr': 'host-A'}
            def configure(self, dump=True): self.config['host_addr'] = parent.settings['host_addr']

        class Dialog:
            def notification(self, *a, **kw): pass
            def ok(self, title, message): parent.messages.append(message)
            def yesno(self, *a, **kw):
                if parent.on_confirm: parent.on_confirm()
                return parent.confirm

        class Helper:
            def __init__(self, *a): self._selected_address = self._frozen_host_options = None
            def _is_coreelec_ng(self, path): return True
            @contextmanager
            def _native_host_command(self, action, address):
                parent.calls.append(('snapshot', action, address, dict(self._frozen_host_options)))
                yield (['moonlight', action], {'LUNA_STREAM_CONFIG': '/snapshot'})
            def _running_ng_app(self, binary, env, app_id, timeout_seconds=8):
                parent.calls.append(('probe',))
                item = parent.states.pop(0)
                return (None, str(item)) if isinstance(item, Exception) else (item, None)
            def quit_game(self, address, snapshot=None):
                parent.calls.append(('quit', address, snapshot))
                return parent.quit_ok
            def _wait_for_ng_app_stopped(self, *a, **kw):
                parent.calls.append(('wait',))
                return parent.idle, None

        for name, module in [('resources.lib.util.library', types.ModuleType('library')),
                             ('resources.lib.util.moonlighthelper', types.ModuleType('moonlighthelper'))]:
            old = sys.modules.get(name)
            module.Library = Library
            module.MoonlightHelper = Helper
            sys.modules[name] = module
            self.addCleanup(lambda n=name, v=old: (
                sys.modules.pop(n, None) if v is None else sys.modules.__setitem__(n, v)))
        self.ns = {
            'addon': Addon(), 'config_helper': Config(),
            'canonical_app_id': lambda x: str(int(x)),
            '_connection_options': lambda: dict(self.options),
            '_pairing_context_current': lambda addr, opts: (
                self.settings['host_addr'] == addr and self.options == opts),
            'xbmcgui': types.SimpleNamespace(Dialog=Dialog),
            'xbmc': types.SimpleNamespace(getLocalizedString=lambda x: '',
                                          executebuiltin=lambda x: None),
            'logger': types.SimpleNamespace(error=lambda *args: None),
        }
        tree = ast.parse((ROOT / 'addon.py').read_text(encoding='utf-8'))
        names = {'_active_resume_session', 'quitgame'}
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
        assert {n.name for n in nodes} == names
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
                     'addon.py', 'exec'), self.ns)

    def quit(self): return self.ns['quitgame']()
    def quit_calls(self): return [c for c in self.calls if c[0] == 'quit']

    def test_exact_app_quits_and_clears_only_after_idle(self):
        self.assertTrue(self.quit())
        self.assertEqual(self.quit_calls(), [('quit', 'host-A', '/snapshot')])
        self.assertEqual([c[0] for c in self.calls].count('probe'), 2)
        self.assertEqual(self.settings['last_run'], '')

    def test_stale_quit_entry_cannot_close_new_game(self):
        self.states = ['22']
        self.assertFalse(self.quit())
        self.assertEqual(self.quit_calls(), [])
        self.assertEqual(self.settings['last_run'], 'Desktop')

    def test_app_changes_while_dialog_open(self):
        self.states = ['11', '22']
        self.assertFalse(self.quit())
        self.assertEqual(self.quit_calls(), [])

    def test_confirmed_host_and_port_are_immutable(self):
        for mutate in (lambda: self.settings.__setitem__('host_addr', 'host-B'),
                       lambda: self.options.__setitem__('port', '48000')):
            with self.subTest(mutate=mutate):
                self.settings['host_addr'] = 'host-A'
                self.options['port'] = '47989'
                self.states = ['11', '11']
                self.calls.clear()
                self.on_confirm = mutate
                self.assertFalse(self.quit())
                self.assertEqual(self.quit_calls(), [])

    def test_missing_id_cancel_and_probe_failure_never_quit(self):
        self.settings['last_run_id'] = ''
        self.assertFalse(self.quit())
        self.settings['last_run_id'] = '11'
        self.confirm = False
        self.assertFalse(self.quit())
        self.confirm = True
        self.states = [OSError('offline')]
        self.assertFalse(self.quit())
        self.assertFalse(self.quit_calls())

    def test_failed_or_unconfirmed_quit_keeps_saved_resume(self):
        self.quit_ok = False
        self.assertFalse(self.quit())
        self.assertEqual(self.settings['last_run'], 'Desktop')
        self.states = ['11', '11']
        self.quit_ok, self.idle = True, False
        self.assertFalse(self.quit())
        self.assertEqual(self.settings['last_run'], 'Desktop')


if __name__ == '__main__':
    unittest.main()
