"""Real Git regression: build commit 20 remains publishable after 21/22 land.

Git object refs, not mutable development HEAD, authorize the release source.
This runs locally without GitHub, CoreELEC, network access, or publication.
"""
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "prepare_kodi_release", ROOT / "packaging/prepare_kodi_release.py")
versioner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(versioner)


def git(cwd, *args, allow_error=False):
    result = subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, text=True, timeout=10)
    if not allow_error and result.returncode:
        raise AssertionError("git " + " ".join(args) + ": " + result.stderr)
    return result


class ImmutableSourcePublishTests(unittest.TestCase):
    def test_commit20_version_release_survives_dev_commits21_and22(self):
        with tempfile.TemporaryDirectory() as root:
            base = Path(root)
            remote, work = base / "remote.git", base / "work"
            remote.mkdir()
            work.mkdir()
            git(remote, "init", "--bare", "-q")
            git(work, "init", "-q")
            git(work, "config", "user.name", "CI Test")
            git(work, "config", "user.email", "ci@example.invalid")
            git(work, "remote", "add", "origin", str(remote))

            addon = work / "addon.xml"
            code = work / "coreelec_source.py"
            feed = base / "public.xml"
            addon.write_text(
                '<addon id="script.luna.ng" version="2.7.1.323" name="Luna" />')
            code.write_text('CODE_COMMIT_20 = True\n')
            feed.write_text(
                '<addons><addon id="script.luna.ng" version="2.7.1.322" /></addons>')
            git(work, "add", ".")
            git(work, "commit", "-qm", "commit 20 - fully validated source")
            commit20 = git(work, "rev-parse", "HEAD").stdout.strip()
            git(work, "push", "-q", "origin", "HEAD:refs/heads/feat/vortex-ng")

            # The metadata-only release belongs to commit 20, but is NOT
            # pushed onto the developer branch that will receive 21/22.
            addon.write_text(
                '<addon id="script.luna.ng" version="2.7.1.324" name="Luna" />')
            git(work, "add", "addon.xml")
            git(work, "commit", "-qm", "Reserve 2.7.1.324 for commit 20 [skip ci]")
            release_sha = git(work, "rev-parse", "HEAD").stdout.strip()
            git(work, "push", "-q", "origin",
                "HEAD:refs/tags/luna-ng-reserved-2.7.1.324")

            git(work, "reset", "-q", "--hard", commit20)
            for index in (21, 22):
                code.write_text(f'CODE_COMMIT_{index} = True\n')
                git(work, "add", "coreelec_source.py")
                git(work, "commit", "-qm", f"commit {index} [skip ci]")
                git(work, "push", "-q", "origin",
                    "HEAD:refs/heads/feat/vortex-ng")

            development_sha = git(work, "rev-parse", "HEAD").stdout.strip()
            tagged_sha = git(work, "rev-parse", release_sha).stdout.strip()
            self.assertNotEqual(development_sha, tagged_sha)
            self.assertEqual(git(work, "rev-parse", release_sha + "^").stdout.strip(),
                             commit20)
            self.assertEqual(
                git(work, "diff-tree", "--no-commit-id", "--name-only",
                    "-r", release_sha).stdout.strip(), "addon.xml")
            self.assertEqual(git(work, "show", release_sha + ":coreelec_source.py").stdout,
                             "CODE_COMMIT_20 = True\n")
            self.assertEqual(git(work, "show", "HEAD:coreelec_source.py").stdout,
                             "CODE_COMMIT_22 = True\n")

            remote_tag = git(
                work, "ls-remote", "--refs", "--tags", "origin",
                "refs/tags/luna-ng-reserved-*").stdout
            refs = base / "reservations.txt"
            refs.write_text(remote_tag)
            self.assertEqual(
                versioner.versions_from_reservation_refs(refs), ((2, 7, 1, 324),))
            self.assertEqual(versioner.release_version(
                addon, feed, versioner.versions_from_reservation_refs(refs))[0],
                "2.7.1.325")

            # A second build may not overwrite an already reserved version.
            collision = git(work, "push", "origin",
                            "HEAD:refs/tags/luna-ng-reserved-2.7.1.324",
                            allow_error=True)
            self.assertNotEqual(collision.returncode, 0)


if __name__ == "__main__":
    unittest.main()
