"""Regressions for credential boundaries, artwork passes and launch preflight."""
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import tracemalloc
import types
import unittest
from unittest.mock import Mock, patch
import test_review4_fixes as fixture
from resources.lib.util import hostcontext, hostapi, artwork, diagnosticreport, runtimecheck
from resources.lib.util.library import Library

class Review5Tests(unittest.TestCase):
    def test_reset_removes_required_markers_only_for_known_pin_names(self):
        with tempfile.TemporaryDirectory() as td:
            names=['client.pem','key.pem','server-'+hashlib.sha256(b'pc').hexdigest()+'.pem.required']
            for name in names+['unrelated.required']:Path(td,name).write_text('x')
            hostcontext.remove_pairing_keys(td)
            self.assertEqual([p.name for p in Path(td).iterdir()],['unrelated.required'])

    def test_ports_use_independent_pin_paths_and_preserve_default(self):
        a=hostapi.Host('pc',http_port=48000);b=hostapi.Host('pc',http_port=49000)
        self.assertNotEqual(a._pin_path(),b._pin_path())
        self.assertTrue(a._pin_path().endswith(hashlib.sha256(b'pc\nport=48000').hexdigest()+'.pem'))
        self.assertTrue(hostapi.Host('pc')._pin_path().endswith(hashlib.sha256(b'pc').hexdigest()+'.pem'))

    def test_fifo_credentials_are_rejected_without_hanging(self):
        with tempfile.TemporaryDirectory() as td:
            os.mkfifo(Path(td,'client.pem'));Path(td,'key.pem').write_text('x')
            code='from resources.lib.util.hostapi import Host; Host("pc",key_dir='+repr(td)+')._context()'
            result=subprocess.run([sys.executable,'-c',code],env={**os.environ,'PYTHONPATH':str(Path(__file__).resolve().parents[1])},capture_output=True,timeout=3)
            self.assertNotEqual(result.returncode,0)
            self.assertIn(b'Cannot safely load pairing credentials',result.stderr)

    def test_unowned_legacy_folders_remain_unscoped(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td,'folders.json').write_text(json.dumps({'folders':['Old'],'assign':{'42':'Old'}}))
            library=Library(td,'different',{'port':'49000'});library.migrate_legacy()
            self.assertIsNone(library.folder_of('42'))
            self.assertEqual(json.loads(Path(td,'folders.json').read_text())['assign_by_host']['legacy-unscoped'],{'42':'Old'})

    def test_failed_artwork_pass_enters_backoff(self):
        for count in (1,3,4,10):
            with self.subTest(count=count),tempfile.TemporaryDirectory() as td:
                path=Path(td,'job.work');path.write_text(json.dumps({'host':'pc','ids':[str(i) for i in range(1,count+1)]}))
                with patch.object(fixture.service.MoonlightHelper,'_art_if_present',return_value=None),patch.object(fixture.service.MoonlightHelper,'boxart_path',return_value=None):
                    for _ in range((count+2)//3):fixture.service.process_job(path,types.SimpleNamespace(abortRequested=lambda:False))
                payload=json.loads(path.read_text())
                self.assertEqual(len(payload['ids']),count);self.assertGreater(payload['retry_at'],0)
                self.assertEqual(payload['attempts'],1)

    def test_artwork_exhaustion_suspends_until_an_explicit_new_request(self):
        from test_review4_fixes import service
        with tempfile.TemporaryDirectory() as td:
            work = Path(td, 'pc.work')
            payload = {'host': 'pc', 'ids': ['42'], 'failed_ids': [],
                       'attempts': 7}
            service.defer_job(work, payload)
            exhausted = json.loads(work.read_text())
            self.assertEqual(exhausted['attempts'], 8)
            self.assertTrue(exhausted['suspended'])
            self.assertEqual(exhausted['ids'], ['42'])
            self.assertFalse(service.artwork_job_ready(
                exhausted, hostcontext.host_identity('pc')))
            self.assertFalse(service.artwork_job_ready(
                exhausted, hostcontext.host_identity('old-pc')))
            renewed = service.merge_jobs(exhausted,
                                         {'host': 'pc', 'ids': ['42']})
            self.assertFalse(renewed['suspended'])
            self.assertEqual(renewed['attempts'], 0)
            self.assertTrue(service.artwork_job_ready(
                renewed, hostcontext.host_identity('pc')))
            self.assertFalse(service.artwork_job_ready(
                renewed, hostcontext.host_identity('another-host')))
            self.assertEqual(renewed['ids'], ['42'])

    def test_host_selection_reactivates_only_that_host_artwork(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            for name in ('pc-a', 'pc-b'):
                (folder / (name + '.work')).write_text(json.dumps({
                    'host': name, 'ids': ['42'], 'attempts': 8,
                    'suspended': True, 'retry_at': 0}))
            fixture.service.reactivate_selected_artwork_jobs(
                folder, hostcontext.host_identity('pc-a'))
            active = json.loads((folder / 'pc-a.work').read_text())
            sleeping = json.loads((folder / 'pc-b.work').read_text())
            self.assertFalse(active['suspended'])
            self.assertEqual(active['attempts'], 0)
            self.assertEqual(active['ids'], ['42'])
            self.assertTrue(sleeping['suspended'])
            self.assertEqual(sleeping['attempts'], 8)

    def test_same_ip_with_different_port_or_keydir_cannot_use_old_artwork(self):
        from test_review4_fixes import service
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            for label, options in (
                    ('default', {}),
                    ('custom-port', {'port': '48089'}),
                    ('custom-keys', {'keydir': '/tmp/other-pairing-keys'})):
                (folder / (label + '.work')).write_text(json.dumps({
                    'host': 'pc', 'host_options': options,
                    'ids': ['42'], 'attempts': 8, 'suspended': True,
                    'retry_at': 0}))
            chosen = hostcontext.host_identity('pc', {'port': '48089'})
            service.reactivate_selected_artwork_jobs(folder, chosen)
            for label, expected in (('default', False),
                                    ('custom-port', True),
                                    ('custom-keys', False)):
                payload = json.loads((folder / (label + '.work')).read_text())
                self.assertEqual(service.artwork_job_ready(payload, chosen), expected)
                self.assertEqual(payload['suspended'], not expected)
                self.assertEqual(payload['attempts'], 0 if expected else 8)
            self.assertFalse(service.artwork_job_ready(
                {'host': 'pc', 'ids': ['42'], 'retry_at': 0},
                chosen))

    def test_duplicate_request_does_not_restart_incomplete_failure_pass(self):
        old={'host':'pc','ids':['4'],'failed_ids':['1','2','3'],'retry_at':0}
        merged=fixture.service.merge_jobs(old,{'host':'pc','ids':['1','2','3','4']})
        self.assertEqual(merged['ids'],['4']);self.assertEqual(merged['failed_ids'],['1','2','3'])

    def test_clipped_pem_base64_is_redacted(self):
        secret='Ab+/Cd+/Ef+/Gh+/Ij+/Kl+/Mn+/Op+/Qr+/St+/Uv+/Wx+/Yz+/0123456789ABCD'
        for raw in ('AbCd+/==\n-----END PRIVATE KEY-----\n', secret+'\n-----END PRIVATE KEY-----\n', '-----BEGIN PRIVATE KEY-----\n'+(secret+'\n')*28+'-----END PRIVATE KEY-----\n'+'ordinary event\n'*290):
            self.assertNotIn(secret,diagnosticreport.redact(diagnosticreport._bounded_tail(raw)))
            self.assertNotIn('AbCd+/==',diagnosticreport.redact(diagnosticreport._bounded_tail(raw)))

    def test_vfm_rejects_rotation_and_av1_before_handoff(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td,'config')
            for extra in ('rotate=90','codec=av1'):
                p.write_text('[Moonlight]\nwidth=1920\nheight=1080\nfps=60\n'+extra+'\n')
                with self.assertRaises(ValueError):runtimecheck.check_stream_geometry(str(p),'aml-vfm')
                if extra.startswith('rotate='):
                    with self.assertRaisesRegex(ValueError, 'rotate=0'):
                        runtimecheck.check_stream_geometry(str(p),'aml')
                else:
                    with self.assertRaisesRegex(ValueError, 'does not support AV1'):
                        runtimecheck.check_stream_geometry(str(p),'aml')

    def test_aml_rotation_is_rejected_without_restricting_other_pipelines(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td, 'config')
            for rotation in (0, 90, 180, 270):
                p.write_text('[Moonlight]\nwidth=1920\nheight=1080\nfps=120\nrotate=%d\n' % rotation)
                for pipeline in ('aml', 'aml-vfm'):
                    if rotation:
                        with self.assertRaisesRegex(ValueError, 'rotate=0'):
                            runtimecheck.check_stream_geometry(str(p), pipeline)
                    else:
                        runtimecheck.check_stream_geometry(str(p), pipeline)
                runtimecheck.check_stream_geometry(str(p), 'sdl')

    def test_invalid_xdg_values_use_home_cache(self):
        for value in ('','relative'):
            with patch.dict(os.environ,{'XDG_CACHE_DIR':value,'HOME':'/tmp/home'}):
                self.assertEqual(hostcontext.default_key_dir(),'/tmp/home/.cache/moonlight')

    def test_png_validation_streams_large_decompressed_image(self):
        import zlib
        w,h=8192,3000;c=zlib.compressobj();parts=[]
        for _ in range(h):parts.append(c.compress(bytes(w*3+1)))
        parts.append(c.flush())
        def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',b''.join(parts))+chunk(b'IEND',b'')
        tracemalloc.start()
        try:
            self.assertTrue(artwork._valid_png(png))
            self.assertLess(tracemalloc.get_traced_memory()[1],2*1024*1024)
        finally:tracemalloc.stop()

