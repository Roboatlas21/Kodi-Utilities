"""The pre-dispatch helper forwards the exact captured source pair."""
import importlib.util
from pathlib import Path
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "luna_dispatcher", ROOT / "packaging/dispatch_unified_luna_ng.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class ImmutableDispatchTests(unittest.TestCase):
    def test_captures_and_dispatches_the_original_pair(self):
        source = iter(("a" * 40, "b" * 40))
        with mock.patch.object(MODULE, "gh", side_effect=lambda *args: next(source)):
            luna, moonlight = MODULE.source_pair()
        self.assertEqual(luna, "a" * 40)
        self.assertEqual(moonlight, "b" * 40)
        with mock.patch.object(MODULE, "gh") as remote:
            MODULE.dispatch_build(luna, moonlight, publish=True)
        arguments = remote.call_args.args
        self.assertIn("inputs[pin_luna_sha]=" + luna, arguments)
        self.assertIn("inputs[pin_moonlight_sha]=" + moonlight, arguments)
        self.assertIn("inputs[publish_to_kodi]=true", arguments)

    def test_rejects_half_valid_and_incompatible_inputs(self):
        with self.assertRaises(ValueError):
            MODULE.dispatch_build("not-a-sha", "b" * 40)
        with self.assertRaises(ValueError):
            MODULE.dispatch_build("a" * 40, "b" * 40, publish=True,
                                  diagnostics_only=True)


if __name__ == "__main__":
    unittest.main()
