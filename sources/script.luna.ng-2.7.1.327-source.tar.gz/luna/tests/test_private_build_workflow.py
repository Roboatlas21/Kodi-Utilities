"""Regression checks for the private Luna package-build workflow."""
import importlib.util
import io
import json
import os
import subprocess
import textwrap
import tarfile
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / ".github/workflows/build-luna-ng.yml"
SCRIPT = ROOT / "packaging/verify_vfm_runtime.py"
SPEC = importlib.util.spec_from_file_location("private_vfm", SCRIPT)
VFM = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VFM)
SHA = "a" * 40


class PrivateBuildWorkflowTests(unittest.TestCase):
    def test_unified_native_recipe_is_authenticated_during_packaging(self):
        source = WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("expected_native_workflow_sha:", source)
        self.assertIn('EXPECTED_NATIVE_WORKFLOW_SHA: ${{ inputs.expected_native_workflow_sha }}', source)
        self.assertIn('.head_sha == $recipe', source)
        self.assertIn('NATIVE_WORKFLOW_SHA=$EXPECTED_NATIVE_WORKFLOW_SHA', source)
        self.assertIn('refs/heads/luna-ng-launcher-v3', source)

    def test_exact_source_package_auth_accepts_versioned_completion_launchers(self):
        """Execute the packaging preflight, not a list of source-code strings.

        Regression: frozen launcher v6 passed unified preflight/native but
        failed here because the pinned packager trusted only v1..v5.
        All other source and repository checks remain enforced.
        """
        source = WORKFLOW.read_text(encoding="utf-8")
        section = source.split(
            "      - name: Authenticate Luna preflight reuse\n", 1)[1].split(
            "      - name: Run complete Luna Python", 1)[0]
        script = textwrap.dedent(section.split("        run: |\n", 1)[1])
        sha = "a" * 40
        fake_git = (
            'git() {\n'
            '  if [[ "$*" == "-C luna rev-parse HEAD" ]]; then\n'
            '    printf "%s\\n" "$MOCK_LUNA_SHA"\n'
            '  else\n'
            '    return 90\n'
            '  fi\n'
            '}\n'
        )

        def check(branch, *, repo="Roboatlas21/Luna", expected=sha,
                  checkout=sha, validated_code=sha):
            with tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp) / "output"
                summary = Path(tmp) / "summary"
                env = dict(
                    os.environ, GITHUB_REPOSITORY=repo,
                    CALLER_WORKFLOW="Roboatlas21/Luna/.github/workflows/"
                                    "unified-luna-ng.yml@refs/heads/" + branch,
                    VALIDATED_LUNA_SHA=sha, EXPECTED_LUNA_REF=expected,
                    MOCK_LUNA_SHA=checkout, VALIDATED_CODE_SHA=validated_code,
                    GITHUB_OUTPUT=str(out), GITHUB_STEP_SUMMARY=str(summary))
                result = subprocess.run(
                    ["bash", "-euo", "pipefail"], input=fake_git + script,
                    text=True, capture_output=True, env=env, timeout=5)
                return result, out.read_text() if out.exists() else ""

        for branch in ("matrix", *(f"luna-ng-launcher-v{n}" for n in range(1, 9))):
            with self.subTest(approved=branch):
                result, output = check(branch)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn("reused=true", output)
        for branch in ("luna-ng-launcher-v9", "feat/vortex-ng", "other"):
            with self.subTest(unapproved=branch):
                result, output = check(branch)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn("reused=true", output)
        for description, kwargs in (
            ("untrusted repository", dict(repo="another/repo")),
            ("different release", dict(expected="b" * 40)),
            ("different checked-out SHA", dict(checkout="b" * 40)),
            ("invalid validated code SHA", dict(validated_code="invalid")),
        ):
            with self.subTest(guard=description):
                result, output = check("luna-ng-launcher-v8", **kwargs)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn("reused=true", output)

    def test_private_workflow_manual_only_and_pinned(self):
        source = WORKFLOW.read_text(encoding="utf-8")
        for required in (
                "  workflow_dispatch:", "  workflow_call:", "KODI_LUNA_READ_TOKEN",
                "require_latest_moonlight", "gh run download",
                "ref: ${{ steps.native.outputs.sha }}", "submodules: recursive",
                "python3 -m unittest discover -s tests -v",
                "bash tests/test_launch.sh", "luna-ng-release-lock-v1",
                "SHA256SUMS", "include_vfm_runtime", "package-addon.py"):
            self.assertIn(required, source)
        for forbidden in ("  push:", "repository: Roboatlas21/xbmc-p3i",
                          "repository: Roboatlas21/Luna-build", "git push"):
            self.assertNotIn(forbidden, source)

    def test_native_callback_only_failure_does_not_invalidate_packaging(self):
        source = WORKFLOW.read_text(encoding="utf-8")
        self.assertIn('all(. == "notify-luna" or . == "reconcile-luna")', source)
        self.assertIn('.conclusion == "failure"', source)

    def test_explicit_source_pin_is_not_rejected_for_different_run_head(self):
        source = WORKFLOW.read_text(encoding="utf-8")
        for required in (
                'expected_native_sha:', 'EXPECTED_NATIVE_SHA',
                'run.get("display_title")',
                'CoreELEC21-NG source=',
                'stamped.group(1) != sha',
                'expected != sha',
                'Legacy native artifact differs from workflow HEAD'):
            self.assertIn(required, source)
        self.assertNotIn(
            'run["head_branch"] == "feat/coreelec-ng" and run["head_sha"] != sha',
            source)

    def test_unified_snapshot_packaging_ignores_future_branch_head(self):
        workflow = WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("validated_code_sha:", workflow)
        self.assertIn("fetch-depth: 2", workflow)
        self.assertIn("$(git -C luna rev-parse HEAD^)", workflow)
        self.assertIn("Release commit changed more than the addon version", workflow)
        self.assertIn("Confirm checked-out source pair matches the approved build", workflow)
        self.assertNotIn("git/ref/heads/feat/vortex-ng", workflow)
        self.assertNotIn("git/ref/heads/feat/coreelec-ng", workflow)
        self.assertNotIn("Recheck latest sources before exposing installable ZIP", workflow)

    def test_vfm_runtime_sha_and_extraction(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = root / "vfm.tar.gz"
            data = json.dumps({
                "schema": "luna-ng-vfm-v1",
                "moonlight_source_git_sha": SHA,
                "objects": {},
            }).encode("utf-8")
            with tarfile.open(archive, "w:gz") as tar:
                item = tarfile.TarInfo("manifest.json")
                item.size = len(data)
                tar.addfile(item, io.BytesIO(data))
            result = VFM.verify_and_extract(archive, root / "extracted", SHA)
            self.assertEqual(result["moonlight_source_git_sha"], SHA)
            with self.assertRaisesRegex(ValueError, "source revision"):
                VFM.verify_and_extract(archive, root / "wrong", "b" * 40)

    def test_vfm_runtime_rejects_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = root / "malicious.tar.gz"
            with tarfile.open(archive, "w:gz") as tar:
                item = tarfile.TarInfo("../escape")
                item.size = 1
                tar.addfile(item, io.BytesIO(b"x"))
            with self.assertRaisesRegex(ValueError, "Unsafe"):
                VFM.verify_and_extract(archive, root / "destination", SHA)


if __name__ == "__main__":
    unittest.main()
