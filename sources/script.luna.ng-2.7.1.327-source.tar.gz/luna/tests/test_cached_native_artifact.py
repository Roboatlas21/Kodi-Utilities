"""Cached native binaries must be verified before Luna reuses them."""
import importlib.util
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "cached_artifact", ROOT / "packaging/verify_native_cached_artifact.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
SOURCE = "a" * 40
RECIPE = "b" * 40


class CachedNativeArtifactTests(unittest.TestCase):
    def prepare(self, *, source=SOURCE, recipe=RECIPE, manifest=None, duplicate=False):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        directory = Path(temporary.name)
        (directory / "build-info.txt").write_text(
            "SOURCE_GIT_SHA=" + source + "\nNATIVE_WORKFLOW_SHA=" + recipe + "\n")
        payload = manifest if manifest is not None else {
            "schema": "luna-ng-runtime-v1",
            "source_git_sha": source,
            "target": "Amlogic-ce/Amlogic-ng/arm",
            "capabilities": ["first-video-ready-v1"],
        }
        raw = json.dumps(payload).encode()
        archive = directory / "moonlight-coreelec21-ng-arm32.tar.gz"
        with tarfile.open(archive, "w:gz") as output:
            for _ in range(2 if duplicate else 1):
                item = tarfile.TarInfo("./runtime-manifest.json")
                item.size = len(raw)
                output.addfile(item, io.BytesIO(raw))
        return directory

    def test_exact_artifact_passes_only_after_full_native_verification(self):
        full_payload = {
            "schema": "luna-ng-runtime-v1",
            "source_git_sha": SOURCE,
            "target": "Amlogic-ce/Amlogic-ng/arm",
            "capabilities": ["first-video-ready-v1"],
        }
        # The packager validates all ELF32 files/hashes; don't require real
        # ARM binaries in this test of the source/recipe selection boundary.
        with mock.patch.object(MODULE, "native_files_checked",
                               return_value={"runtime-manifest.json": json.dumps(full_payload).encode()}):
            self.assertTrue(MODULE.verify(self.prepare(), SOURCE, RECIPE))

    def test_wrong_recipe_or_source_fails(self):
        directory = self.prepare()
        for source, recipe in ((SOURCE, "c" * 40), ("d" * 40, RECIPE)):
            with self.subTest(source=source, recipe=recipe):
                with self.assertRaises(ValueError):
                    MODULE.verify(directory, source, recipe)

    def test_wrong_manifest_and_duplicates_fail(self):
        bad = {"schema": "luna-ng-runtime-v1", "source_git_sha": SOURCE,
               "target": "wrong", "capabilities": ["first-video-ready-v1"]}
        with mock.patch.object(MODULE, "native_files_checked",
                               return_value={"runtime-manifest.json": json.dumps(bad).encode()}):
            with self.assertRaises(ValueError):
                MODULE.verify(self.prepare(), SOURCE, RECIPE)
        with self.assertRaises(ValueError):
            MODULE.verify(self.prepare(duplicate=True), SOURCE, RECIPE)

    def test_manifest_only_archive_is_not_reusable(self):
        with self.assertRaisesRegex(ValueError, "Missing native"):
            MODULE.verify(self.prepare(), SOURCE, RECIPE)

    def test_rejects_missing_info_and_corrupt_archive(self):
        directory = self.prepare()
        (directory / "build-info.txt").unlink()
        with self.assertRaises(ValueError):
            MODULE.verify(directory, SOURCE, RECIPE)
        directory = self.prepare()
        (directory / "moonlight-coreelec21-ng-arm32.tar.gz").write_bytes(b"invalid")
        with self.assertRaises(tarfile.TarError):
            MODULE.verify(directory, SOURCE, RECIPE)


if __name__ == "__main__":
    unittest.main()
