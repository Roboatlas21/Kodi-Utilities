"""Regression checks for strict, commit-bound source CI authorization."""
import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parents[1] / "packaging" / "source_ci_gate.py"
spec = importlib.util.spec_from_file_location("source_ci_gate", path)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
SHA = "a" * 40
OTHER = "b" * 40
LUNA = "Roboatlas21/Luna"
MOONLIGHT = "Roboatlas21/moonlight-embedded"


def sample(repo=MOONLIGHT, event="push", **changes):
    workflow = "luna-source-checks.yml" if repo == LUNA else "coreelec-ng-checks.yml"
    run = dict(path=".github/workflows/" + workflow, event=event,
               head_sha=SHA, head_branch="feat/vortex-ng" if repo == LUNA else "feat/coreelec-ng",
               display_title="Luna source validation " + SHA if repo == LUNA else "test",
               status="completed", conclusion="success", id=20,
               created_at="2026-11-03T16:00:00Z")
    run.update(changes)
    return run


class SourceCiGateTests(unittest.TestCase):
    def verify(self, rows, repo=MOONLIGHT):
        branch = "feat/vortex-ng" if repo == LUNA else "feat/coreelec-ng"
        workflow = "luna-source-checks.yml" if repo == LUNA else "coreelec-ng-checks.yml"
        return gate.verify(repo, workflow, branch, SHA, wait=0,
                           fetcher=lambda *_: rows, clock=lambda: 0,
                           sleeper=lambda _: None)

    def test_exact_sha_only(self):
        self.assertEqual(self.verify([sample()])["id"], 20)
        for bad in (sample(head_sha=OTHER), sample(head_branch="master"),
                    sample(path=".github/workflows/coreelec-ng-native.yml")):
            with self.subTest(bad=bad), self.assertRaisesRegex(RuntimeError, "No .*source-check"):
                self.verify([bad])

    def test_failed_latest_check_overrides_older_success(self):
        failure = sample(id=21, created_at="2026-11-03T17:00:00Z",
                         conclusion="failure")
        with self.assertRaisesRegex(RuntimeError, "finished: failure"):
            self.verify([sample(), failure])

    def test_explicit_luna_dispatch_pins_checkout_even_after_branch_move(self):
        run = sample(repo=LUNA, event="workflow_dispatch", head_sha=OTHER)
        self.assertEqual(self.verify([run], repo=LUNA)["id"], 20)
        wrong_input = sample(repo=LUNA, event="workflow_dispatch", head_sha=SHA,
                             display_title="Luna source validation " + OTHER)
        with self.assertRaisesRegex(RuntimeError, "No .*source-check"):
            self.verify([wrong_input], repo=LUNA)

    def test_explicit_matrix_dispatch_can_validate_dev_sha_without_confusion(self):
        valid = sample(repo=LUNA, event="workflow_dispatch",
                       head_branch="matrix", head_sha=OTHER,
                       display_title="Luna source validation " + SHA)
        self.assertEqual(self.verify([valid], repo=LUNA)["id"], 20)
        unpinned = sample(repo=LUNA, event="workflow_dispatch",
                          head_branch="matrix", head_sha=OTHER,
                          display_title="Luna manual source validation (development HEAD)")
        with self.assertRaisesRegex(RuntimeError, "No .*source-check"):
            self.verify([unpinned], repo=LUNA)

    def test_moonlight_dispatch_must_match_real_head_sha(self):
        with self.assertRaisesRegex(RuntimeError, "No .*source-check"):
            self.verify([sample(event="workflow_dispatch", head_sha=OTHER)])

    def test_newly_queued_run_can_appear_during_bounded_wait(self):
        clock = [0.0]
        calls = [0]
        def delayed(*_args):
            calls[0] += 1
            return [] if calls[0] < 3 else [sample()]
        def elapse(seconds):
            clock[0] += seconds
        result = gate.verify(MOONLIGHT, "coreelec-ng-checks.yml",
                             "feat/coreelec-ng", SHA, wait=30, poll=5,
                             wait_for_missing=True, fetcher=delayed,
                             clock=lambda: clock[0], sleeper=elapse)
        self.assertEqual(result["id"], 20)
        self.assertEqual(calls[0], 3)

    def test_exact_commit_run_lookup_not_limited_to_newest_unfiltered_page(self):
        import json
        from unittest import mock
        queries = []
        def gh_run(argv, **_kwargs):
            queries.append(argv[-1])
            return json.dumps({"workflow_runs": [sample()] if "head_sha=" in argv[-1]
                               else []})
        with mock.patch.object(gate.subprocess, "check_output",
                               side_effect=gh_run):
            result = gate.fetch(MOONLIGHT, "coreelec-ng-checks.yml", SHA)
        self.assertEqual(len(result), 1)
        self.assertIn("head_sha=" + SHA, queries[0])
        self.assertIn("per_page=100&page=1", queries[0])

    def test_explicit_luna_dispatch_fallback_search(self):
        import json
        from unittest import mock
        queries = []
        def gh_run(argv, **_kwargs):
            queries.append(argv[-1])
            results = ([sample(repo=LUNA, event="workflow_dispatch",
                               head_sha=OTHER)] if "event=workflow_dispatch"
                       in argv[-1] else [])
            return json.dumps({"workflow_runs": results})
        with mock.patch.object(gate.subprocess, "check_output",
                               side_effect=gh_run):
            result = gate.fetch(LUNA, "luna-source-checks.yml", SHA)
        self.assertEqual(len(result), 1)
        self.assertTrue(any("event=workflow_dispatch" in v for v in queries))

    def test_manual_source_check_defaults_to_development_branch(self):
        workflow = (Path(__file__).resolve().parents[1] /
                    ".github/workflows/luna-source-checks.yml").read_text()
        self.assertIn("git/ref/heads/feat/vortex-ng", workflow)
        self.assertIn("steps.selected.outputs.sha", workflow)
        self.assertIn("Luna manual source validation (development HEAD)",
                      workflow)

    def test_queued_cancelled_or_missing_does_not_pass(self):
        with self.assertRaisesRegex(RuntimeError, "No .*source-check"):
            self.verify([])
        with self.assertRaisesRegex(RuntimeError, "Timed out"):
            self.verify([sample(status="queued")])
        with self.assertRaisesRegex(RuntimeError, "finished: cancelled"):
            self.verify([sample(conclusion="cancelled")])


    def test_unified_manual_preflight_checks_all_groups_without_historical_ci(self):
        source = (Path(__file__).resolve().parents[1] /
                  '.github/workflows/unified-luna-ng.yml').read_text()
        self.assertIn('Source commits pinned for this run', source)
        self.assertIn('steps.logs_upload.outcome', source)
        self.assertIn('Confirm checked-out source pair equals selected build-start revisions', source)
        self.assertIn('steps.pinned_sources.outcome', source)
        self.assertIn('Resolve immutable approved Luna source before native continuation', source)
        self.assertLess(source.index('Moonlight ALSA, evdev and telemetry tests'),
                        source.index('Confirm checked-out source pair equals selected build-start revisions'))
        self.assertLess(source.index('Luna package and VFM runtime verification'),
                        source.index('Upload every private validation log'))
        self.assertNotIn('Require Luna CI for pinned source', source)
        self.assertNotIn('Require Moonlight CI for pinned source', source)
        self.assertNotIn('source_ci_gate.py', source)
        self.assertIn('[[ "$built" == "$sha" ]] || continue', source)


if __name__ == "__main__":
    unittest.main()
