"""Static regression checks for the public-to-private CI feature migration."""
from pathlib import Path
import unittest
import json
import subprocess
import textwrap

from workflow_shell import extract_shell_functions

ROOT = Path(__file__).resolve().parents[1]
UNIFIED = ROOT / ".github/workflows/unified-luna-ng.yml"
PACKAGE = ROOT / ".github/workflows/build-luna-ng.yml"
VALIDATOR = ROOT / "packaging/validate_private.sh"


class UnifiedWorkflowTests(unittest.TestCase):
    def test_exact_latest_native_artifact_only_and_budget(self):
        source = UNIFIED.read_text()
        selector = extract_shell_functions(
            source, "find_moonlight_artifact",
            overrides={"paginated_listing", "artifact_ready",
                       "native_jobs_valid", "candidate_valid", "repo_api"})
        sha = 'a' * 40
        old = 'b' * 40

        def run(rows, artifact):
            fixture = json.dumps({'workflow_runs': [dict(
                id=i, display_title='CoreELEC21-NG source='+built+' correlation=test',
                status='completed', conclusion='success', head_branch='feat/coreelec-ng', head_sha='c' * 40)
                for i, built in rows]})
            script = selector + "\nsource_repo=fixture; sha=" + sha + "; PINNED_NATIVE_WORKFLOW_SHA=" + 'c' * 40 + "\n"
            script += "paginated_listing() { cat <<'JSON'\n" + fixture + "\nJSON\n}\n"
            script += 'compatible_source() { echo old-source-considered >&2; return 0; }\n'
            script += 'artifact_ready() { ' + artifact + '; }; native_jobs_valid() { return 0; }; candidate_valid() { return 0; }\nfind_moonlight_artifact'
            return subprocess.run(['bash', '-euo', 'pipefail'], input=script,
                                  text=True, capture_output=True, timeout=5)

        older = run([(i, old) for i in range(50)],
                    'echo should-not-call >&2; return 0')
        self.assertEqual(older.returncode, 1, older.stderr)
        self.assertNotIn('should-not-call', older.stderr)
        self.assertNotIn('old-source-considered', older.stderr)
        exact = run([(i, sha) for i in range(50)],
                    'echo artifact >&2; return 1')
        self.assertEqual(exact.returncode, 1)
        self.assertEqual(exact.stderr.count('artifact\n'), 10)
        self.assertIn('budget exhausted', exact.stderr)
        selected = run([(1, old), (2, sha)], 'return 0')
        self.assertEqual(selected.returncode, 0, selected.stderr)
        self.assertEqual(selected.stdout.strip(), '2|'+sha+'|fixture')
        self.assertIn('[[ "$built" == "$sha" ]] || continue', source)
        self.assertNotIn('for tier in exact compatible; do', source)

    def test_completion_is_routed_to_versioned_immutable_launcher(self):
        source = UNIFIED.read_text(encoding="utf-8")
        package = PACKAGE.read_text(encoding="utf-8")
        self.assertIn('"completion_ref": "refs/heads/luna-ng-launcher-v8"', source)
        self.assertIn('Native completion launcher differs from the immutable approval', source)
        self.assertIn('"completion_launcher_sha": os.environ["COMPLETION_SHA"]', source)
        self.assertIn('"$GITHUB_SHA" == "$pinned_callback_sha"', source)
        self.assertIn('refs/heads/luna-ng-launcher-v1', package)
        self.assertIn('refs/heads/luna-ng-launcher-v2', package)
        self.assertIn('inputs.resume_luna_run_id !=', source)

    def test_build_entry_guard_before_checkout(self):
        import os
        source = UNIFIED.read_text()
        start = source.index('      - name: Require the matrix launcher for builds')
        end = source.index('      - name: Snapshot both current source SHAs', start)
        block = source[start:end]
        self.assertIn('if: ${{ !inputs.validate_only }}', block)
        script = textwrap.dedent(block.split('        run: |\n', 1)[1])
        for ref, event, original, expected in (
                ('matrix', 'workflow_dispatch', '', 0),
                ('luna-ng-launcher-v1', 'workflow_dispatch', '41702286015', 0),
                ('luna-ng-launcher-v5', 'workflow_dispatch', '41702286015', 0),
                ('luna-ng-launcher-v6', 'workflow_dispatch', '41702286015', 0),
                ('luna-ng-launcher-v7', 'workflow_dispatch', '41702286015', 0),
                ('luna-ng-launcher-v8', 'workflow_dispatch', '41702286015', 0),
                ('luna-ng-launcher-v1', 'workflow_dispatch', '', 1),
                ('feat/vortex-ng', 'workflow_dispatch', '41702286015', 1),
                ('matrix', 'workflow_dispatch', '41702286015', 0),
                ('feat/vortex-ng', 'workflow_dispatch', '', 1),
                ('matrix', 'push', '', 1)):
            env = dict(os.environ, GITHUB_REPOSITORY='Roboatlas21/Luna',
                       GITHUB_EVENT_NAME=event, ORIGINAL_RUN=original,
                       WORKFLOW_REF='Roboatlas21/Luna/.github/workflows/unified-luna-ng.yml@refs/heads/'+ref)
            result = subprocess.run(['bash'], input=script, env=env,
                                    text=True, capture_output=True, timeout=5)
            self.assertEqual(result.returncode, expected, result.stderr)
        self.assertIn('jobs?filter=all&per_page=100', source)

    def test_resolve_both_latest_shas_once_before_either_checkout(self):
        source = UNIFIED.read_text(encoding='utf-8')
        selected = source.index('Snapshot both current source SHAs before any checkout')
        luna_checkout = source.index('Check out exact private Luna development source')
        moonlight_checkout = source.index('Check out private Moonlight source and submodules')
        self.assertLess(selected, luna_checkout)
        self.assertLess(selected, moonlight_checkout)
        self.assertIn("ref: ${{ steps.resume_source.outputs.sha || steps.source_pair.outputs.luna_sha }}", source)
        self.assertIn("ref: ${{ steps.source_pair.outputs.moonlight_sha }}", source)
        self.assertIn('Luna checkout did not match the initial source snapshot', source)
        self.assertIn('Moonlight checkout did not match the initial source snapshot', source)

    def test_artifact_discovery_paginates_and_bounds_search(self):
        source = UNIFIED.read_text()
        start = source.index('          paginated_listing() {')
        end = source.index('          artifact_ready() {', start)
        helper = textwrap.dedent(source[start:end])
        # Run the actual workflow shell functions with deterministic API pages.
        runs = [{'id': i, 'display_title': 'unrelated', 'payload': 'x' * 2048, 'status': 'completed',
                 'conclusion': 'success', 'head_branch': 'feat/coreelec-ng', 'head_sha': 'c' * 40}
                for i in range(100)]
        sha = 'a' * 40
        match = dict(id=321, display_title='CoreELEC21-NG source='+sha+' correlation=test',
                     status='completed', conclusion='success', head_branch='feat/coreelec-ng', head_sha='c' * 40)
        first = json.dumps({'workflow_runs': runs})
        second = json.dumps({'workflow_runs': [match]})
        fixture = """
repo_api() {
  case "$2" in
    *page=1) cat <<'FIRST'
%s
FIRST
;;
    *page=2) cat <<'SECOND'
%s
SECOND
;;
    *) return 2;;
  esac
}
""" % (first, second)
        selector = extract_shell_functions(
            source, "find_moonlight_artifact",
            overrides={"paginated_listing", "artifact_ready",
                       "native_jobs_valid", "candidate_valid", "repo_api"})
        setup = 'source_repo=fixture; sha='+sha+'; PINNED_NATIVE_WORKFLOW_SHA='+ 'c'*40 + '; artifact_ready() { [[ "$2" == 321 ]]; }; native_jobs_valid() { return 0; }; candidate_valid() { return 0; }; compatible_source() { return 1; };\n'
        def run(script):
            return subprocess.run(['bash', '-euo', 'pipefail'], input=script,
                                  capture_output=True, text=True, timeout=10)
        result = run(helper+fixture+selector+setup+'find_moonlight_artifact')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), '321|'+sha+'|fixture')
        limited = run(helper+fixture+selector+setup+
                      'ARTIFACT_SEARCH_MAX_PAGES=1; find_moonlight_artifact')
        self.assertEqual(limited.returncode, 1)
        self.assertIn('budget exhausted', limited.stderr)
        self.assertFalse(limited.stdout)
        error = run(helper+'repo_api() { return 1; }; paginated_listing repo "endpoint?" artifacts')
        self.assertEqual(error.returncode, 1)
        self.assertIn('API failed', error.stderr)
        empty = run(helper+"repo_api() { echo '{\"artifacts\":[]}'; }; paginated_listing repo 'endpoint?' artifacts")
        self.assertEqual(empty.returncode, 0, empty.stderr)
        self.assertEqual(json.loads(empty.stdout), {'artifacts': []})
        # Luna's artifact collection uses the same helper and still excludes
        # expired artifacts before checking native jobs and provenance.
        self.assertIn('paginated_listing "$caller_repo" "repos/$caller_repo/actions/artifacts?" artifacts', source)
        self.assertIn('.expired == false and .size_in_bytes > 0', source)

    def test_sha_indexed_native_lookup_precedes_old_history_scanning(self):
        source = UNIFIED.read_text(encoding="utf-8")
        index = 'actions/artifacts?name=moonlight-coreelec21-ng-index-$sha-$PINNED_NATIVE_WORKFLOW_SHA'
        history = 'actions/workflows/coreelec-ng-native.yml/runs?event=workflow_dispatch'
        self.assertIn(index, source)
        self.assertLess(source.index(index), source.index(history))
        self.assertIn('.display_title | startswith("CoreELEC21-NG source=" + $sha', source)
        self.assertIn('[[ "$built" == "$sha" ]] || continue', source)
        self.assertNotIn("compatible_source()", source)

    def test_private_test_zip_receives_upgradeable_unique_version(self):
        source = UNIFIED.read_text(encoding="utf-8")
        reservation = source.split(
            "Reserve version on immutable release tag after successful validation", 1)[1]
        reservation = reservation.split("Record immutable native continuation approval", 1)[0]
        self.assertIn('if: ${{ !inputs.resume_luna_run_id && !inputs.validate_only }}',
                      reservation)
        self.assertNotIn('inputs.publish_to_kodi && !inputs.validate_only', reservation)
        self.assertIn('HEAD:refs/tags/luna-ng-reserved-$version', reservation)
        self.assertIn('steps.release_reservation.outputs.version', source)
        self.assertIn('steps.release_reservation.outputs.luna_sha', source)

    def test_release_version_reserved_only_after_all_groups_pass(self):
        source = UNIFIED.read_text(encoding="utf-8")
        summary = source.index('Report all validation groups and block unverified ARM32 builds')
        reserve = source.index('Reserve version on immutable release tag after successful validation')
        approval = source.index('Record immutable native continuation approval')
        self.assertLess(summary, reserve)
        self.assertLess(reserve, approval)
        self.assertIn('steps.release_reservation.outputs.luna_sha', source)
        self.assertIn('steps.release_reservation.outputs.version', source)
        self.assertIn('"validation_luna_sha": os.environ["VALIDATED_LUNA_SHA"]', source)
        self.assertIn('git -C luna diff-tree --no-commit-id --name-only -r HEAD', source)
        self.assertIn("git -C luna status --porcelain --untracked-files=no", source)
        self.assertIn('Validated Luna checkout is not clean before version reservation', source)
        self.assertIn('HEAD:refs/tags/luna-ng-reserved-$version', source)
        self.assertIn('--reservation-refs', source)
        self.assertNotIn('HEAD:refs/heads/feat/vortex-ng', source)

    def test_new_commits_do_not_cancel_original_build_or_publication(self):
        source = UNIFIED.read_text(encoding="utf-8")
        package = PACKAGE.read_text(encoding="utf-8")
        self.assertIn('Confirm checked-out source pair equals selected build-start revisions', source)
        self.assertIn('steps.pinned_sources.outcome', source)
        self.assertIn('sha="$PREFLIGHT_MOONLIGHT_SHA"', source)
        self.assertIn('HEAD:refs/tags/luna-ng-reserved-$version', source)
        # Only the early source snapshot may query mutable development HEAD.
        # Later validation, selection, packaging and publishing use that pin.
        snapshot = source.index('Snapshot both current source SHAs before any checkout')
        source_pin = source.index('Confirm checked-out source pair equals selected build-start revisions')
        self.assertLess(snapshot, source_pin)
        initial = source[snapshot:source_pin]
        self.assertIn('git/ref/heads/feat/vortex-ng', initial)
        self.assertIn('git/ref/heads/feat/coreelec-ng', initial)
        self.assertNotIn('git/ref/heads/feat/vortex-ng', source[source_pin:])
        self.assertNotIn('git/ref/heads/feat/coreelec-ng', source[source_pin:])
        self.assertNotIn('Verify published source pair is still latest', source)
        self.assertNotIn('Ensure latest Luna and Moonlight heads still match full preflight', source)
        self.assertNotIn('git/ref/heads/feat/vortex-ng', package)
        self.assertNotIn('git/ref/heads/feat/coreelec-ng', package)

    def test_publication_dispatch_uses_run_details_and_deadline_aware_reads(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("-F return_run_details=true", source)
        self.assertIn(".workflow_run_id // empty", source)
        self.assertIn("publication_deadline=$((SECONDS + 6300))", source)
        self.assertIn("for attempt in 1 2 3; do", source)
        self.assertIn('audit="$(jq -er', source)
        self.assertIn('Private publication audit receipt pending', source)

    def test_downstream_native_and_publication_workflow_generations_pinned(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn('ref=coreelec-ng-native-v7', source)
        self.assertIn('inputs[expected_workflow_sha]=cc321b2b3ea613495e2930d9560d7c1eaa53a10e', source)
        self.assertIn('inputs[force_compile]=$FORCE_NATIVE', source)
        self.assertIn('ref=luna-ng-publish-v8', source)
        self.assertIn('PUBLISHER_WORKFLOW_SHA: a7733e9f59bc89effec767fcef10c58797ffcbd7', source)
        self.assertIn('inputs[expected_workflow_sha]=$PUBLISHER_WORKFLOW_SHA', source)
        self.assertIn('"completion_launcher_sha": os.environ["COMPLETION_SHA"]', source)
        self.assertIn('"$GITHUB_SHA" == "$pinned_callback_sha"', source)

    def test_v8_contract_and_completion_receipt_gate(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("Verify pinned Moonlight dispatch input contract", source)
        self.assertIn("native_dispatch_contract.outcome", source)
        self.assertIn("missing = sent - declared", source)
        self.assertIn('refs/heads/luna-ng-launcher-v8', source)
        self.assertIn('completion_duplicate:', source)
        self.assertIn("needs.preflight.outputs.completion_duplicate != 'true'", source)
        self.assertIn('luna-ng-completion-v8-$ORIGINAL_RUN-$NATIVE_RUN', source)
        self.assertIn("needs.publish-kodi.result == 'success'", source)
        self.assertIn("  completion-receipt:", source)

    def test_v5_verifiers_stay_pinned_independently_of_old_build_sources(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("ref: 70ea5db5d26b16daac4f3870d11936c12c9a71d1", source)
        self.assertIn("luna-release-policy/packaging/verify_native_continuation.py", source)
        self.assertIn("luna-release-policy/packaging/verify_native_cached_artifact.py", source)
        self.assertIn("build-luna-ng.yml@fe7f3100c6738bef89573105a54c4e71b41343d8", source)

    def test_current_completion_launcher_is_approved_by_pinned_packager(self):
        """Prevent repeat of v6: an approved native callback rejected at package time."""
        import re
        source = UNIFIED.read_text(encoding="utf-8")
        package = PACKAGE.read_text(encoding="utf-8")
        match = re.search(
            r'"completion_ref": "refs/heads/(luna-ng-launcher-v[0-9]+)"',
            source)
        self.assertIsNotNone(match, "Missing immutable completion approval")
        branch = match.group(1)
        self.assertIn("refs/heads/" + branch, package)
        self.assertIn("git/ref/heads/" + branch, source)
        self.assertIn("refs/heads/" + branch, source.split(
            "      - name: Require the matrix launcher for builds", 1)[1].split(
            "      - name: Snapshot both current source SHAs", 1)[0])
        receipt_version = branch.rsplit("-v", 1)[1]
        self.assertIn("luna-ng-completion-v" + receipt_version + "-$ORIGINAL_RUN-$NATIVE_RUN",
                      source)
        pinned = re.search(
            r'PUBLISHER_WORKFLOW_SHA: ([0-9a-f]{40})', source)
        self.assertIsNotNone(pinned)
        self.assertIn('"publisher_workflow_sha": "' + pinned.group(1) + '"',
                      source)

    def test_dispatch_time_pin_and_native_artifact_content_guards(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn('PINNED_LUNA: ${{ inputs.pin_luna_sha }}', source)
        self.assertIn('PINNED_MOONLIGHT: ${{ inputs.pin_moonlight_sha }}', source)
        self.assertIn('source_mode="captured before workflow_dispatch"', source)
        self.assertIn("native_jobs_valid() {", source)
        self.assertIn("candidate_valid() {", source)
        self.assertIn("verify_native_cached_artifact.py", source)
        self.assertIn("publication_deadline=$((SECONDS + 6300))", source)
        self.assertIn("luna-ng-publish-outcome", source)

    def test_native_reuse_requires_pinned_recipe(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("PINNED_NATIVE_WORKFLOW_SHA: cc321b2b3ea613495e2930d9560d7c1eaa53a10e", source)
        self.assertIn(".head_sha == $recipe", source)
        self.assertIn('"$run_head" == "$PINNED_NATIVE_WORKFLOW_SHA"', source)
        self.assertIn('NATIVE_WORKFLOW_SHA=$PINNED_NATIVE_WORKFLOW_SHA', source)
        self.assertIn('moonlight-coreelec21-ng-index-$sha-$PINNED_NATIVE_WORKFLOW_SHA', source)

    def test_packaging_workflow_definition_is_immutable(self):
        import re
        source = UNIFIED.read_text(encoding="utf-8")
        match = re.search(
            r'uses: Roboatlas21/Luna/\.github/workflows/build-luna-ng\.yml@([a-f0-9]{40})',
            source)
        self.assertIsNotNone(match)
        self.assertNotIn('build-luna-ng.yml@feat/vortex-ng', source)
        self.assertIn('luna_ref: ${{ needs.preflight.outputs.luna_sha }}', source)
        self.assertIn('expected_native_workflow_sha: cc321b2b3ea613495e2930d9560d7c1eaa53a10e', source)
        self.assertIn('Confirm checked-out source pair matches the approved build',
                      PACKAGE.read_text(encoding="utf-8"))

    def test_private_workflow_is_manual_and_keeps_publishing_separate(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("  workflow_dispatch:", source)
        self.assertIn("  workflow_call:", source)
        self.assertNotIn("  push:", source)
        self.assertIn("  queue: max", source)
        self.assertIn("  queue: max", PACKAGE.read_text())
        self.assertNotIn("repository: Roboatlas21/xbmc-p3i", source)
        self.assertNotIn("repository: Roboatlas21/Luna-build", source)
        self.assertNotIn("git push ", source)
        self.assertNotIn("publish: true", source)

    def test_all_validation_groups_run_before_native_dispatch(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("  preflight:", source)
        self.assertIn("  select-native:\n    needs: preflight", source)
        for group in ("source", "host", "vfm", "audio"):
            self.assertIn(f"bash tests/validate_private_source.sh {group}",
                          source)
        for group in ("luna-python", "luna-launch", "luna-packaging"):
            self.assertIn(f"bash packaging/validate_private.sh {group}",
                          source)
        self.assertIn("luna-ng-private-validation-logs", source)
        self.assertIn("LUNA_PRIVATE_CHECKOUT:", source)
        self.assertIn("tests/validate_private_source.sh extras", source)
        self.assertIn("steps.moonlight_extra_tests.outcome", source)
        self.assertGreaterEqual(source.count("continue-on-error: true"), 8)
        self.assertIn("Report all validation groups and block unverified ARM32 builds",
                      source)

    def test_diagnostics_only_never_dispatches_native(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("validate_only:", source)
        self.assertIn("if: ${{ !inputs.validate_only }}", source)

    def test_exact_source_pair_is_checked_and_packaged(self):
        source = UNIFIED.read_text(encoding="utf-8")
        packaged = PACKAGE.read_text(encoding="utf-8")
        self.assertIn("PREFLIGHT_MOONLIGHT_SHA", source)
        self.assertIn('sha="$PREFLIGHT_MOONLIGHT_SHA"', source)
        self.assertIn("luna_ref: ${{ needs.preflight.outputs.luna_sha }}",
                      source)
        self.assertIn("ref: ${{ inputs.luna_ref || 'feat/vortex-ng' }}",
                      packaged)
        self.assertIn("ref: ${{ steps.native.outputs.sha }}", packaged)
        self.assertIn("expected_native_sha: ${{ needs.select-native.outputs.native_sha }}",
                      source)
        self.assertNotIn("native_reuse_policy.py", source)
        self.assertIn("steps.select.outputs.native_sha", source)
        self.assertIn('Confirm checked-out source pair matches the approved build',
                      packaged)

    def test_rebuild_dispatches_moonlight_cache_owner_then_exits_without_polling(self):
        source = UNIFIED.read_text(encoding="utf-8")
        for expected in (
                'repos/$source_repo/actions/workflows/coreelec-ng-native.yml/dispatches',
                'inputs[native_source_sha]=$sha',
                'inputs[dispatch_correlation]=$correlation',
                'inputs[expected_workflow_sha]=cc321b2b3ea613495e2930d9560d7c1eaa53a10e',
                'inputs[force_compile]=$FORCE_NATIVE',
                '-f ref=coreelec-ng-native-v7',
                'inputs[continue_luna_publish]=$PUBLISH',
                'inputs[build_vfm_runtime]=$REQUIRE_VFM',
                'reused=deferred',
                'run_id=$RUN_ID',
                'resume_luna_run_id:',
                'resume_native_run_id:',
                '[[ "$built" == "$sha" ]] || continue',
                'require_latest_moonlight: false',
                'find_luna_artifact()',
                'find_moonlight_artifact()'):
            self.assertIn(expected, source)
        self.assertNotIn('  native-rebuild:', source)
        self.assertNotIn('sleep 180', source)
        self.assertNotIn('Following Moonlight run', source)
        self.assertNotIn('uses: Roboatlas21/moonlight-embedded/.github/workflows/coreelec-ng-native.yml', source)

    def test_immutable_request_is_uploaded_only_after_full_preflight(self):
        source = UNIFIED.read_text(encoding="utf-8")
        for expected in (
                'Upload immutable native continuation approval',
                'if: ${{ success() && !inputs.validate_only && !inputs.resume_luna_run_id }}',
                'name: luna-ng-native-request',
                'origin_run_attempt',
                '"publish_to_kodi": os.environ["PUBLISH"] == "true"',
                '"include_vfm_runtime": os.environ["VFM"] == "true"',
                'python3 luna-release-policy/packaging/verify_native_continuation.py',
                'steps.resume_proof.outputs.native_run_id',
                'needs.select-native.outputs.reused == \'true\''):
            self.assertIn(expected, source)
        self.assertIn("  workflow_call:", source)

    def test_pinned_native_provenance_is_checked_again_during_packaging(self):
        source = PACKAGE.read_text(encoding="utf-8")
        for expected in (
                'expected_native_sha:', 'EXPECTED_NATIVE_SHA',
                'run.get("display_title")', 'stamped.group(1) != sha',
                'expected != sha', 'manifest.get("source_git_sha")'):
            self.assertIn(expected, source)
        self.assertNotIn('run["head_branch"] == "feat/coreelec-ng" and run["head_sha"] != sha',
                         source)

    def test_package_reuses_only_exact_trusted_luna_preflight(self):
        unified = UNIFIED.read_text(encoding='utf-8')
        package = PACKAGE.read_text(encoding='utf-8')
        self.assertIn('needs: [preflight, select-native]', unified)
        self.assertIn("needs.select-native.outputs.reused == 'true'", unified)
        self.assertIn('preflight_validated_sha: ${{ needs.preflight.outputs.luna_sha }}', unified)
        self.assertIn('validated_code_sha: ${{ needs.preflight.outputs.validated_luna_sha }}', unified)
        self.assertIn('Luna preflight reuse requires approved, exact source revisions', package)
        self.assertIn("steps.luna_validation.outputs.reused != 'true'", package)
        self.assertIn('Run complete Luna Python, Kodi launcher and watchdog tests', package)
        self.assertIn('bash tests/test_launch.sh', package)
        self.assertIn('github.workflow_ref', package)
        self.assertIn('native_artifact_repository:', package)

    def test_caller_owned_native_artifact_requires_successful_native_jobs(self):
        package = PACKAGE.read_text(encoding='utf-8')
        for required in (
                'ARTIFACT_REPO', 'GITHUB_RUN_ID',
                'Reusable native preparation and compilation did not complete successfully',
                'contains("native-rebuild /")',
                'endswith("/ prepare")', 'endswith("/ native")',
                'Roboatlas21/moonlight-embedded',
                'gh run download "$RUN_ID" -R "$ARTIFACT_REPO"',
                'manifest.get("source_git_sha")'):
            self.assertIn(required, package)

    def test_launcher_expected_exit_codes_do_not_emit_assertion_failure(self):
        import re
        launcher = (ROOT / "tests/test_launch.sh").read_text(encoding="utf-8")
        self.assertIn('LUNA_ASSERTION_FAILURE', launcher)
        self.assertIn('if sh "$launcher" Desktop >"$tmp/out" 2>&1; then', launcher)
        self.assertGreaterEqual(launcher.count(
            'if sh "$launcher" Desktop >"$tmp/out" 2>&1; then'), 10)
        self.assertNotRegex(
            launcher,
            r'(?m)^\s*sh "\$launcher" Desktop >\s*"\$tmp/out" 2>&1\n\s*status=\$\?')
        self.assertIn('[[ "$status" == 42 ]]', launcher)
        self.assertIn('[[ "$status" == 127 ]]', launcher)
        self.assertIn('[[ "$status" == 124 ]]', launcher)

    def test_luna_groups_record_logs_and_failure_counts(self):
        source = VALIDATOR.read_text(encoding="utf-8")
        for group in ("luna-python", "luna-launch", "luna-packaging"):
            self.assertIn(group + ")", source)
        self.assertIn("SOURCE_CHECK_FAIL", source)
        self.assertIn("test_aml_recovery.sh", source)
        self.assertIn("resources/lib/util/resumestate.py", source)
        self.assertIn("resources/lib/util/hdmigamemode.py", source)
        self.assertIn("results.tsv", source)
        self.assertIn("if (( failures )); then", source)


if __name__ == "__main__":
    unittest.main()
