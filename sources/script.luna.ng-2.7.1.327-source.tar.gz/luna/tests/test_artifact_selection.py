"""Run the production selector with local archives and a fake GitHub transport."""
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile
import textwrap

from workflow_shell import extract_shell_functions
import unittest

ROOT = Path(__file__).resolve().parents[1]
TARGET = 'a' * 40
OLDER_SOURCE = 'b' * 40


class ArtifactSelectionTests(unittest.TestCase):
    def select(self, sources, expired=(), corrupt=(), api_error=False):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            artifacts = []
            for index, source in enumerate(sources, 101):
                artifacts.append(dict(name='moonlight-coreelec21-ng-arm32',
                                      expired=index in expired, size_in_bytes=1024,
                                      workflow_run={'id': index}))
                (root / (str(index) + '.build-info')).write_text(
                    'SOURCE_GIT_SHA=' + source + '\nNATIVE_WORKFLOW_SHA=' + 'c' * 40 + '\n')
                archive = root / (str(index) + '.tar.gz')
                if index in corrupt:
                    archive.write_bytes(b'invalid archive')
                    continue
                data = json.dumps(dict(schema='luna-ng-runtime-v1',
                                       target='Amlogic-ce/Amlogic-ng/arm',
                                       source_git_sha=source)).encode()
                with tarfile.open(archive, 'w:gz') as output:
                    member = tarfile.TarInfo('runtime-manifest.json')
                    member.size = len(data)
                    output.addfile(member, io.BytesIO(data))
            (root / 'artifacts.json').write_text(json.dumps({'artifacts': artifacts}))
            (root / 'downloads').touch()
            source = (ROOT / '.github/workflows/unified-luna-ng.yml').read_text()
            function = extract_shell_functions(
                source, "find_luna_artifact",
                overrides={"paginated_listing", "artifact_ready"})
            script = r'''
set -euo pipefail
caller_repo=fixture
GITHUB_RUN_ID=999
LUNA_TOKEN=fixture
PINNED_NATIVE_WORKFLOW_SHA=$TEST_RECIPE
REQUIRE_VFM=false
artifact_ready() { return 0; }
paginated_listing() {
  if [[ "$API_ERROR" == 1 ]]; then return 1; fi
  if [[ "$3" == artifacts ]]; then cat "$RUNNER_TEMP/artifacts.json"; else
    local id="${2#*/runs/}"; id="${id%%/*}"
    printf '{"jobs":[{"run_id":%s,"status":"completed","conclusion":"success","name":"native-rebuild / prepare"},{"run_id":%s,"status":"completed","conclusion":"success","name":"native-rebuild / native"}]}\n' "$id" "$id"
  fi
}
gh() {
  local id="$3"
  echo "$id" >> "$RUNNER_TEMP/downloads"
  while [[ "$1" != -D ]]; do shift; done
  cp "$RUNNER_TEMP/$id.tar.gz" "$2/moonlight-coreelec21-ng-arm32.tar.gz"
  cp "$RUNNER_TEMP/$id.build-info" "$2/build-info.txt"
}
# Execute fake gh as a shell function; still require every timeout to be bounded.
timeout() {
  [[ "$1" =~ ^[0-9]+s$ && "${1%s}" -gt 0 && "${1%s}" -le 180 ]] || return 99
  shift; "$@"
}
'''
            script += function + '\nfind_luna_artifact\n'
            import os
            env = dict(os.environ, RUNNER_TEMP=str(root), sha=TARGET,
                       API_ERROR=str(int(api_error)), TEST_RECIPE='c' * 40)
            result = subprocess.run(['bash'], input=script, env=env,
                                    capture_output=True, text=True, timeout=15)
            downloads = (root / 'downloads').read_text().splitlines()
            return result, downloads

    def test_older_sources_are_rejected_and_downloaded_once(self):
        result, downloads = self.select([OLDER_SOURCE] * 3)
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertFalse(result.stdout)
        self.assertEqual(downloads, ['101', '102', '103'])

    def test_later_exact_match_wins(self):
        result, downloads = self.select([OLDER_SOURCE, TARGET, OLDER_SOURCE])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), '102|'+TARGET+'|fixture')
        self.assertEqual(downloads, ['101', '102'])

    def test_expired_and_corrupt_candidates_are_not_selected(self):
        result, downloads = self.select([TARGET, TARGET, TARGET],
                                        expired=(101,), corrupt=(102,))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), '103|'+TARGET+'|fixture')
        self.assertEqual(downloads, ['102', '103'])

    def test_candidate_budget_never_falls_back_to_older_source(self):
        result, downloads = self.select([OLDER_SOURCE] * 10 + [TARGET])
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertEqual(len(downloads), 10)
        self.assertIn('budget exhausted', result.stderr)
        self.assertFalse(result.stdout)

    def test_api_error_and_no_exact_source_fail(self):
        for sources, error in (([TARGET], True), (['c' * 40], False), ([], False)):
            with self.subTest(sources=sources, error=error):
                result, _ = self.select(sources, api_error=error)
                self.assertEqual(result.returncode, 1)
                self.assertFalse(result.stdout)

