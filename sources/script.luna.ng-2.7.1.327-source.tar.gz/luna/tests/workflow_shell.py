"""Dependency-closed Bash helper extraction for workflow behavior tests.

Avoid splicing from comment labels or omitting a helper added after a test was
written. Explicit overrides are permitted only for I/O boundaries.
"""
import re
import textwrap

DECLARATION = re.compile(
    r"(?m)^(?P<indent>[ ]+)(?P<name>[A-Za-z_][A-Za-z_0-9]*)\(\) \{$")


def extract_shell_functions(workflow, *targets, overrides=()):
    definitions = {}
    for declaration in DECLARATION.finditer(workflow):
        name = declaration.group("name")
        closing = re.search(
            r"(?m)^" + re.escape(declaration.group("indent")) +
            r"\}[ \t]*(?:#.*)?$", workflow[declaration.end():])
        if not closing:
            raise ValueError("Unclosed Bash function: " + name)
        if name in definitions:
            raise ValueError("Ambiguous duplicate Bash function: " + name)
        definitions[name] = textwrap.dedent(
            workflow[declaration.start():declaration.end()+closing.end()]
        ).strip() + "\n"

    skipped = set(overrides)
    if skipped.intersection(targets):
        raise ValueError("A function under test cannot be overridden")
    seen, result = set(), []

    def include(name):
        if name in seen or name in skipped:
            return
        if name not in definitions:
            raise ValueError("Missing Bash function: " + name)
        seen.add(name)
        body = definitions[name]
        for dependency in definitions:
            if dependency == name or dependency in seen or dependency in skipped:
                continue
            if re.search(r"(?<![-\w])" + re.escape(dependency) +
                         r"[ \t]+(?=[\"'\$A-Za-z0-9_./])", body):
                include(dependency)
        result.append(body)

    for name in targets:
        include(name)
    return "\n".join(result)
