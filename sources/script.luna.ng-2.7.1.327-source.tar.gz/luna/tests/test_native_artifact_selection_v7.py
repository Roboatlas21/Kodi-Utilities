"""Native reuse only accepts exact-source verified ARM32 and VFM artifacts."""
import json
from pathlib import Path
import shutil
import subprocess
import textwrap

from workflow_shell import extract_shell_functions
import unittest

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / '.github/workflows/unified-luna-ng.yml').read_text(encoding='utf-8')


class NativeArtifactSelectionTests(unittest.TestCase):
    def test_callback_reconciliation_failure_does_not_discard_compilation(self):
        if not shutil.which('jq'):
            self.skipTest('jq unavailable')
        fn = extract_shell_functions(
            WORKFLOW, "native_jobs_valid",
            overrides={"paginated_listing"})
        def check(results):
            fixture = json.dumps({'jobs': [
                {'run_id': 123, 'name': name, 'status': 'completed',
                 'conclusion': outcome} for name, outcome in results]})
            script = ("source_repo=fixture\n" + "paginated_listing() { cat <<'JSON'\n" + fixture +
                      "\nJSON\n}\n" + fn + "\nnative_jobs_valid 123\n")
            return subprocess.run(['bash', '-euo', 'pipefail'],
                                  input=script, text=True, capture_output=True,
                                  timeout=5).returncode
        self.assertEqual(check([('prepare', 'success'), ('native', 'success'),
                                ('notify-luna', 'failure'),
                                ('reconcile-luna', 'failure')]), 0)
        self.assertNotEqual(check([('prepare', 'success'), ('native', 'failure'),
                                   ('notify-luna', 'failure')]), 0)
        self.assertNotEqual(check([('prepare', 'success'), ('native', 'success'),
                                   ('other', 'failure')]), 0)

    def test_actual_vfm_archive_is_verified_for_both_artifact_owners(self):
        self.assertIn('vfm_candidate_valid() {', WORKFLOW)
        self.assertIn('vfm_candidate_valid "$source_repo" "$id" "$proof"', WORKFLOW)
        self.assertIn('vfm_candidate_valid "$caller_repo" "$id" "$candidate"', WORKFLOW)
        self.assertIn('-n moonlight-coreelec21-ng-vfm-runtime', WORKFLOW)
        self.assertIn('luna/packaging/verify_vfm_runtime.py', WORKFLOW)
        self.assertIn('from resources.lib.util.vfmruntime import verify_bundle', WORKFLOW)
        self.assertIn('candidate_deadline - SECONDS', WORKFLOW)

    def test_native_recipe_is_frozen_at_v7(self):
        self.assertIn('ref=coreelec-ng-native-v7', WORKFLOW)
        self.assertIn('PINNED_NATIVE_WORKFLOW_SHA: cc321b2b3ea613495e2930d9560d7c1eaa53a10e', WORKFLOW)
        self.assertNotIn('ref=coreelec-ng-native-v6', WORKFLOW)
        self.assertIn('"completion_ref": "refs/heads/luna-ng-launcher-v8"', WORKFLOW)
        self.assertIn('luna-ng-completion-v8-$ORIGINAL_RUN-$NATIVE_RUN', WORKFLOW)


if __name__ == '__main__':
    unittest.main()
