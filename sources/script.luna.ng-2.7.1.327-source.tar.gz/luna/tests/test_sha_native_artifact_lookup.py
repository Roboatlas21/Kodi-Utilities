"""Execute the SHA-indexed native selector with fake GitHub responses."""
import json
import os
from pathlib import Path
import subprocess
import textwrap
import unittest

ROOT = Path(__file__).resolve().parents[1]
SHA = "a" * 40
RECIPE = "c" * 40


def fixture_run(source=SHA, success=True):
    return {
        "id": 555, "event": "workflow_dispatch",
        "path": ".github/workflows/coreelec-ng-native.yml",
        "head_branch": "feat/coreelec-ng",
        "head_sha": RECIPE,
        "status": "completed",
        "conclusion": "success" if success else "failure",
        "display_title": ("CoreELEC21-NG source=" + source +
                          " correlation=manual"),
    }


class ShaIndexSelectorTests(unittest.TestCase):
    def selector(self):
        source = (ROOT / ".github/workflows/unified-luna-ng.yml").read_text()
        start = source.index("          find_moonlight_artifact() {")
        end = source.index("          # Reusable Moonlight calls", start)
        return textwrap.dedent(source[start:end])

    def run_selector(self, index=None, actual=None, history=None, indexed_ok=True):
        if index is None:
            index = {"artifacts": [{"name": "moonlight-coreelec21-ng-index-" + SHA + "-" + RECIPE,
                                    "expired": False, "size_in_bytes": 512,
                                    "workflow_run": {"id": 555}}]}
        if actual is None:
            actual = fixture_run()
        if history is None:
            history = {"workflow_runs": []}
        script = r'''
set -uo pipefail
sha="$TEST_SHA"
source_repo=fixture
REQUIRE_VFM=false
PINNED_NATIVE_WORKFLOW_SHA="$TEST_RECIPE"
paginated_listing() {
  case "$2" in
    *actions/artifacts\?name=*) printf '%s\n' "$TEST_INDEX" ;;
    *actions/workflows/coreelec-ng-native.yml/runs*) printf '%s\n' "$TEST_HISTORY" ;;
    *) return 1 ;;
  esac
}
repo_api() {
  if [[ "$2" == "repos/fixture/actions/runs/555" ]]; then
    printf '%s\n' "$TEST_RUN"
  else
    return 1
  fi
}
artifact_ready() {
  [[ "$2" == 555 && "$TEST_ARTIFACT_VALID" == yes ]]
}
native_jobs_valid() {
  jq -e '.conclusion == "success" or .notify_failed_only == true' <<< "$TEST_RUN" >/dev/null
}
candidate_valid() {
  [[ "$TEST_ARTIFACT_VALID" == yes ]]
}
''' + self.selector() + "\nfind_moonlight_artifact\n"
        env = dict(os.environ, TEST_SHA=SHA, TEST_RECIPE=RECIPE,
                   TEST_INDEX=json.dumps(index), TEST_RUN=json.dumps(actual),
                   TEST_HISTORY=json.dumps(history),
                   TEST_ARTIFACT_VALID="yes" if indexed_ok else "no")
        return subprocess.run(["bash"], input=script, text=True,
                              capture_output=True, env=env, timeout=7)

    def test_valid_index_finds_exact_source_without_history(self):
        output = self.run_selector()
        self.assertEqual(output.returncode, 0, output.stderr)
        self.assertEqual(output.stdout.strip(), "555|" + SHA + "|fixture")

    def test_notification_only_failure_is_eligible_for_reuse(self):
        valid = fixture_run(success=False)
        valid["notify_failed_only"] = True
        output = self.run_selector(actual=valid)
        self.assertEqual(output.returncode, 0, output.stderr)
        self.assertEqual(output.stdout.strip(), "555|" + SHA + "|fixture")

    def test_mismatched_recipe_cannot_reuse_native_artifact(self):
        invalid = fixture_run()
        invalid["head_sha"] = "d" * 40
        output = self.run_selector(actual=invalid)
        self.assertEqual(output.returncode, 1)
        self.assertFalse(output.stdout)

    def test_spoofed_expired_or_failed_index_fails_closed(self):
        bad = [
            self.run_selector(actual=fixture_run("b" * 40)),
            self.run_selector(actual=fixture_run(success=False)),
            self.run_selector(index={"artifacts": [{
                "name": "moonlight-coreelec21-ng-index-" + SHA + "-" + RECIPE,
                "expired": True, "size_in_bytes": 512,
                "workflow_run": {"id": 555}}]}),
            self.run_selector(indexed_ok=False),
        ]
        for run in bad:
            with self.subTest(stdout=run.stdout, stderr=run.stderr):
                self.assertEqual(run.returncode, 1)
                self.assertFalse(run.stdout)


if __name__ == "__main__":
    unittest.main()
