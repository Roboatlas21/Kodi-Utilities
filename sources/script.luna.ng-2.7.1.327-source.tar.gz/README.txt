Luna NG version: 2.7.1.327
Luna commit: 992220fa2e29b50fee500518a17bd7ff2c386933
Moonlight native commit: 2708a764b9c4d4c42953a607b615451abe5e0e05
Moonlight native run: 41831622478
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
