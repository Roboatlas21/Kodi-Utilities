# Experimental reference-frame recovery deadline

Luna's **Faster video recovery (experimental)** setting is off by default.
It exports `MOONLIGHT_RFI_RECOVERY_MS=0` when disabled, overriding inherited
environment settings. When enabled, the initial timeout is 100 ms, with
50, 100, 150, 200, 300 and 500 ms choices. The private CoreELEC runtime accepts
integer values from 50 through 500; absent or invalid values disable it.

This deadline runs from the first reference-frame recovery loss, not from the
latest recovery request. It is checked only when a complete frame arrives and
is still unusable because reference-frame recovery has not completed. On expiry,
the receiver requests an IDR keyframe, flushes queued RFI ranges through the
existing control API, and waits for the keyframe. It never sends damaged frames
to the decoder. Missing or incomplete frames alone do not trigger escalation.

Experimental escalations have a one-second cooldown, including across recovery
episodes. The existing upstream IDR retry/drop-limit behavior remains in place.
Successful complete-frame admission clears the episode; each new stream resets
all experimental state. Logs report configuration, escalation and admission time
using `RFI_RECOVERY_*_V1`. Admission is not a measurement of physical display time.

There is no additional playback buffer, worker, sleep or clock sampling during
healthy playback. A keyframe can create a bandwidth spike; a lower timeout may
unnecessarily escalate normal RFI recovery on slower networks. 100 ms is a test
starting point (six frame periods at 60 fps), not a demonstrated optimum or a
guarantee that recovery will finish within that time. Rebuild both the native
runtime and Luna UI before testing. The common-c source pin is unchanged; the
implementation is applied by the private CoreELEC build overlay.
