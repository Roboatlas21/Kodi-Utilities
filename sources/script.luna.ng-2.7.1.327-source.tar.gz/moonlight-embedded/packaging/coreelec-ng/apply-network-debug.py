#!/usr/bin/env python3
"""Apply the CoreELEC-only network Debug overlay to an unpacked pinned common-c.

This deliberately does NOT modify the git submodule in the source checkout.
Any upstream rebase or unexpected file contents fail closed. Run before CMake
configure because common-c uses aux_source_directory(src) to select sources.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

BASELINES = {
    "VideoStream.c": "1a8268f8b6b6811584546486a421b6ff5672e2e4",
    "RtpVideoQueue.c": "97304f0dbe55a1470a9590ec62e18bc44851f43f",
    "VideoDepacketizer.c": "cfd95368d0f0141ae177111fa9a9a2ab0fcce260",
}
MARKER = '#include "LunaNetDiagnostics.h"'

def git_blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") +
                        b"\0" + data).hexdigest()

def replace_one(text, before, after, name):
    if text.count(before) != 1:
        raise ValueError("Unexpected pinned common-c source at " + name)
    return text.replace(before, after, 1)

def patch_video(s):
    s = replace_one(s, '#include "Limelight-internal.h"\n',
                    '#include "Limelight-internal.h"\n#include "LunaNetDiagnostics.h"\n',
                    "VideoStream include")
    s = replace_one(s, 'void initializeVideoStream(void) {\n',
                    'void initializeVideoStream(void) {\n    LunaNetDebugInit();\n',
                    "VideoStream initialization")
    s = replace_one(s,
                    '        if (err < minSize) {\n            // Runt packet\n            continue;\n        }',
                    '        if (err < minSize) {\n            // Runt packet\n'
                    '            LunaNetDebugCount(LUNA_NET_RUNT, 1);\n'
                    '            continue;\n        }',
                    "VideoStream runt")
    s = replace_one(s,
                    '        if (!receivedDataFromPeer) {\n'
                    '            receivedDataFromPeer = true;',
                    '        const uint64_t net_work_start_us = LunaNetDebugDatagram(err);\n\n'
                    '        if (!receivedDataFromPeer) {\n'
                    '            receivedDataFromPeer = true;',
                    "VideoStream positive UDP receive")
    # VideoStream skips clearly old encrypted frames *before* AES decrypt and
    # before the RTP queue. Count the event, but never trust this unauthenticated
    # frame header for shard recovery or late-missing-data classification.
    s = replace_one(s,
        '            if (encHeader->frameNumber && LE32(encHeader->frameNumber) < RtpvGetCurrentFrameNumber(&rtpQueue)) {\n'
        '                continue;',
        '            if (encHeader->frameNumber && LE32(encHeader->frameNumber) < RtpvGetCurrentFrameNumber(&rtpQueue)) {\n'
        '                LunaNetDebugCount(LUNA_NET_PREDECRYPT_STALE, 1);\n'
        '                continue;',
        "VideoStream encrypted stale early reject")
    s = replace_one(s,
                    '                Limelog("Failed to decrypt video packet!\\n");',
                    '                LunaNetDebugCount(LUNA_NET_DECRYPT_FAILED, 1);\n'
                    '                Limelog("Failed to decrypt video packet!\\n");',
                    "VideoStream decrypt failure")
    s = replace_one(s,
                    '        queueStatus = RtpvAddPacket(&rtpQueue, packet, err, (PRTPV_QUEUE_ENTRY)&buffer[decryptedSize]);',
                    '        queueStatus = RtpvAddPacket(&rtpQueue, packet, err, (PRTPV_QUEUE_ENTRY)&buffer[decryptedSize]);\n'
                    '        LunaNetDebugReceiverWork(net_work_start_us);',
                    "VideoStream valid packet processing")
    s = replace_one(s,
                    '    if (NegotiatedVideoFormat & VIDEO_FORMAT_MASK_PYROWAVE) {\n'
                    '        // A PyroWave frame can be hundreds of packets arriving at line rate.',
                    '#ifdef __linux__\n'
                    '    LunaNetDebugSocketSet(rtpSocket, (uint32_t)requestedBufferSize);\n'
                    '#endif\n\n'
                    '    if (NegotiatedVideoFormat & VIDEO_FORMAT_MASK_PYROWAVE) {\n'
                    '        // A PyroWave frame can be hundreds of packets arriving at line rate.',
                    "VideoStream actual SO_RCVBUF")
    return s

def patch_rtp(s):
    s = replace_one(s, '#include "Limelight-internal.h"\n',
                    '#include "Limelight-internal.h"\n#include "LunaNetDiagnostics.h"\n',
                    "RtpVideoQueue include")
    # RTP sequence numbers are 16-bit, but video frame numbers are 32-bit.
    # The pinned common-c inadvertently used a 16-bit comparison here.
    s = replace_one(s,
        'if (isBefore16(nvPacket->frameIndex, queue->currentFrameNumber)) {',
        'if (isBefore32(nvPacket->frameIndex, queue->currentFrameNumber)) {',
        'RTP 32-bit frame comparison')
    # A late packet will usually fail the sequence-window check BEFORE the
    # normal stale-frame comparison. Inspect its NV header read-only; this
    # cannot change packet acceptance, FEC, or reference recovery policy.
    s = replace_one(s,
        '#include "LunaNetDiagnostics.h"\n',
        '#include "LunaNetDiagnostics.h"\n\n'
        'static void luna_debug_stale_window_packet(PRTP_PACKET packet, int length) {\n'
        '    if (!LunaNetDebugEnabled()) return;\n'
        '    const int offset = sizeof(*packet) + ((packet->header & FLAG_EXTENSION) ? 4 : 0);\n'
        '    if (length < offset + (int)sizeof(NV_VIDEO_PACKET)) return;\n'
        '    const PNV_VIDEO_PACKET nv = (PNV_VIDEO_PACKET)(((char*)packet) + offset);\n'
        '    LunaNetDebugLateFramePacket(LE32(nv->frameIndex),\n'
        '                                packet->sequenceNumber, LE32(nv->fecInfo));\n'
        '}\n',
        'RTP safe late-window observer')
    s = replace_one(s,
                    '            if (packet->sequenceNumber == entry->packet->sequenceNumber) {\n'
                    '                return false;',
                    '            if (packet->sequenceNumber == entry->packet->sequenceNumber) {\n'
                    '                LunaNetDebugCount(LUNA_NET_DUPLICATES, 1);\n'
                    '                return false;',
                    "RTP duplicate")
    s = replace_one(s,
                    '    insertEntryIntoList(&queue->pendingFecBlockList, newEntry);\n\n'
                    '    return true;',
                    '    if (!isFecRecovery) {\n'
                    '        LunaNetDebugCount(isParity ? LUNA_NET_PARITY_ACCEPTED :\n'
                    '                          LUNA_NET_DATA_ACCEPTED, 1);\n'
                    '        if (outOfSequence) LunaNetDebugCount(LUNA_NET_REORDERED, 1);\n'
                    '    }\n'
                    '    insertEntryIntoList(&queue->pendingFecBlockList, newEntry);\n\n'
                    '    return true;',
                    "RTP received classifications")
    s = replace_one(s,
                    '    reed_solomon* rs = NULL;\n'
                    '    unsigned char** packets = calloc(totalPackets, sizeof(unsigned char*));',
                    '    const uint64_t fec_started_us = LunaNetDebugEnabled() ? PltGetMicroseconds() : 0;\n'
                    '    reed_solomon* rs = NULL;\n'
                    '    unsigned char** packets = calloc(totalPackets, sizeof(unsigned char*));',
                    "FEC attempt timing")
    s = replace_one(s,
                    '    if (marks != NULL)\n'
                    '        free(marks);\n\n'
                    '    return ret;',
                    '    if (marks != NULL)\n'
                    '        free(marks);\n\n'
                    '    if (fec_started_us) {\n'
                    '        LunaNetDebugFecWork(fec_started_us);\n'
                    '        LunaNetDebugCount(LUNA_NET_FEC_ATTEMPTS, 1);\n'
                    '        if (ret == 0 && queue->receivedDataPackets < queue->bufferDataPackets) {\n'
                    '            LunaNetDebugCount(LUNA_NET_FEC_RECOVERED_DATA,\n'
                    '                              queue->bufferDataPackets - queue->receivedDataPackets);\n'
                    '        }\n'
                    '        else if (ret != 0) {\n'
                    '            LunaNetDebugCount(LUNA_NET_FEC_FAILED_ATTEMPTS, 1);\n'
                    '        }\n'
                    '    }\n'
                    '    return ret;',
                    "FEC recovery result")
    s = replace_one(s,
                    '        if (queue->pendingFecBlockList.count != 0) {\n'
                    '            // Report the final status of the FEC queue before dropping this frame',
                    '        if (queue->pendingFecBlockList.count != 0) {\n'
                    '            // A block abandoned at the next boundary has missing data,\n'
                    '            // not necessarily packets proven lost by the network.\n'
                    '            if (!(NegotiatedVideoFormat & VIDEO_FORMAT_MASK_PYROWAVE)) {\n'
                    '                LunaNetDebugCount(LUNA_NET_ABANDONED_BLOCKS, 1);\n'
                    '                if (queue->receivedDataPackets < queue->bufferDataPackets)\n'
                    '                    LunaNetDebugCount(LUNA_NET_ABANDONED_DATA,\n'
                    '                                      queue->bufferDataPackets - queue->receivedDataPackets);\n'
                    '                LunaNetDebugFrameAbandoned(queue);\n'
                    '            }\n'
                    '            // Report the final status of the FEC queue before dropping this frame',
                    "RTP abandoned block")
    # Keep reject recording confined to the public packet intake function;
    # do not reclassify the internal recover/depacketizer return values.
    head, function = s.split('int RtpvAddPacket(PRTP_VIDEO_QUEUE queue,', 1)
    if function.count("return RTPF_RET_REJECTED;") < 5:
        raise ValueError("Missing pinned RTP reject sites")
    # Stale packets may be duplicates, genuine delayed packets or replays.
    # Record them separately rather than inflating confirmed duplicate counts.
    function = replace_one(function,
        '        // Reject packets behind our current buffer window\n'
        '        return RTPF_RET_REJECTED;',
        '        // Reject packets behind our current buffer window\n'
        '        LunaNetDebugCount(LUNA_NET_OLD_WINDOW, 1);\n'
        '        luna_debug_stale_window_packet(packet, length);\n'
        '        return RTPF_RET_REJECTED;', 'RTP stale sequence')
    function = replace_one(function,
        '        // Reject frames behind our current frame number\n'
        '        return RTPF_RET_REJECTED;',
        '        // Reject frames behind our current frame number\n'
        '        LunaNetDebugCount(LUNA_NET_OLD_FRAME, 1);\n'
        '        LunaNetDebugLateFramePacket(nvPacket->frameIndex,\n'
        '                                    packet->sequenceNumber, nvPacket->fecInfo);\n'
        '        return RTPF_RET_REJECTED;', 'RTP stale frame')
    function = function.replace('return RTPF_RET_REJECTED;',
                                'LunaNetDebugCount(LUNA_NET_REJECTED, 1);\n        return RTPF_RET_REJECTED;')
    return head + 'int RtpvAddPacket(PRTP_VIDEO_QUEUE queue,' + function

def patch_depacketizer(s):
    s = replace_one(s, '#include "Limelight-internal.h"\n',
                    '#include "Limelight-internal.h"\n#include "LunaNetDiagnostics.h"\n'
                    '#include "LunaRfiRecovery.h"\n'
                    'static LunaRfiRecovery lunaRfiRecovery;\n',
                    "VideoDepacketizer include")
    s = replace_one(s, 'void initializeVideoDepacketizer(int pktSize) {\n',
                    'void initializeVideoDepacketizer(int pktSize) {\n'
                    '    lunaRfiInit(&lunaRfiRecovery, getenv("MOONLIGHT_RFI_RECOVERY_MS"));\n'
                    '    if (lunaRfiRecovery.timeout_ms)\n'
                    '        Limelog("RFI_RECOVERY_CONFIG_V1 timeout_ms=%u cooldown_ms=1000\\n", lunaRfiRecovery.timeout_ms);\n',
                    "RFI experimental initialization")
    s = replace_one(s, '        waitingForRefInvalFrame = true;\n',
                    '        waitingForRefInvalFrame = true;\n'
                    '        if (lunaRfiRecovery.timeout_ms)\n'
                    '            lunaRfiBegin(&lunaRfiRecovery, PltGetMicroseconds() / 1000);\n',
                    "RFI episode begins once")
    before = '                Limelog("Waiting for RFI frame\\n");\n                connectionDetectedFrameLoss(startFrameNumber, frameIndex);'
    after = r'''                if (lunaRfiRecovery.timeout_ms &&
                    lunaRfiEscalate(&lunaRfiRecovery, PltGetMicroseconds() / 1000)) {
                    Limelog("RFI_RECOVERY_ESCALATE_V1 frame=%u elapsed_ms=%llu timeout_ms=%u\n",
                            frameIndex,
                            (unsigned long long)(lunaRfiRecovery.last_request_ms - lunaRfiRecovery.started_ms),
                            lunaRfiRecovery.timeout_ms);
                    waitingForIdrFrame = true;
                    /* Avoid another legacy drop-limit request immediately after
                     * this one. LiRequestIdrFrame flushes queued RFI ranges. */
                    consecutiveFrameDrops = 0;
                    LiRequestIdrFrame();
                }
                else {
                    Limelog("Waiting for RFI frame\n");
                    connectionDetectedFrameLoss(startFrameNumber, frameIndex);
                }'''
    s = replace_one(s, before, after, "RFI deadline at complete frame boundary")
    s = replace_one(s, '            // Clear frame drops\n',
                    '            if (lunaRfiRecovery.active) {\n'
                    '                Limelog("RFI_RECOVERY_COMPLETE_V1 frame=%u elapsed_ms=%llu\\n",\n'
                    '                        frameNumber, (unsigned long long)(PltGetMicroseconds() / 1000 - lunaRfiRecovery.started_ms));\n'
                    '                lunaRfiComplete(&lunaRfiRecovery);\n'
                    '            }\n\n'
                    '            // Clear frame drops\n',
                    "RFI completion after complete frame admission")
    s = replace_one(s, '                    Limelog("Video decode unit queue overflow\\n");',
                    '                    Limelog("Video decode unit queue overflow\\n");\n'
                    '                    LunaNetDebugCount(LUNA_NET_DECODER_QUEUE_OVERFLOWS, 1);',
                    "Video decode queue overflow")
    return s

def apply(root):
    root = Path(root).resolve()
    common_dir = root / "third_party/moonlight-common-c"
    common = common_dir / "src"
    backup = common_dir / ".luna-netdiag-src-backup"
    local = Path(__file__).resolve().parent / "network-debug"
    content = root / "src/osd/net_rx_debug.h"
    if not content.is_file() or not common_dir.is_dir():
        raise ValueError("Missing unpacked common-c sources or private ABI contract")
    # Recover the original source tree if the previous process was killed
    # between the two rename operations. Never discard the only good tree.
    if not common.exists() and backup.is_dir() and not backup.is_symlink():
        backup.rename(common)
    if not common.is_dir() or common.is_symlink() or backup.is_symlink():
        raise ValueError("Missing, unsafe or incomplete common-c source tree")
    patches = {
        "VideoStream.c": patch_video,
        "RtpVideoQueue.c": patch_rtp,
        "VideoDepacketizer.c": patch_depacketizer,
    }
    old = {}
    already = {}
    for name, expected in BASELINES.items():
        path = common / name
        if path.is_symlink():
            raise ValueError("Symlinked pinned common-c source: " + name)
        blob = path.read_bytes()
        current = git_blob_sha(blob)
        old[name] = blob
        if current == expected:
            already[name] = False
        elif MARKER.encode() in blob and b"LunaNetDebug" in blob:
            already[name] = True
        else:
            raise ValueError(f"Refusing an unfamiliar common-c source: {name} ({current})")
    if any(already.values()) and not all(already.values()):
        raise ValueError("Mixed patched/unpatched common-c source, refusing partial overlay")

    stamp = common / ".luna-netdiag-overlay.json"
    if all(already.values()):
        if not stamp.is_file() or stamp.is_symlink():
            raise ValueError("Patched common-c tree lacks its local integrity stamp")
        saved = json.loads(stamp.read_text(encoding="utf-8"))
        if any(saved.get(name) != git_blob_sha(old[name]) for name in BASELINES):
            raise ValueError("Previously patched common-c source changed unexpectedly")
        if ((common / "LunaNetDiagnostics.h").read_bytes() != content.read_bytes()
                or (common / "LunaNetDebug.c").read_bytes() != (local / "LunaNetDebug.c").read_bytes()
                or not (common / "LunaRfiRecovery.h").is_file()
                or (common / "LunaRfiRecovery.h").read_bytes() != (local / "LunaRfiRecovery.h").read_bytes()):
            raise ValueError("Patched common-c observer changed; clean and rebuild package")
        if backup.exists():
            # Only the intact, stamped source tree is authoritative after a
            # completed swap. The previous tree is now a disposable backup.
            if not backup.is_dir() or backup.is_symlink():
                raise ValueError("Unexpected overlay rollback path")
            shutil.rmtree(backup)
        print("Local common-c network Debug observer already installed")
        return

    if backup.exists():
        raise ValueError("Unretired overlay backup prevents a new source swap")
    new = {name: fn(old[name].decode("utf-8")).encode("utf-8")
           for name, fn in patches.items()}
    staging = Path(tempfile.mkdtemp(prefix=".luna-netdiag-src-stage-",
                                   dir=common_dir))
    swapped = False
    try:
        # Never mutate a live/partially patched src directory. Stage every
        # source and generated ABI file on the SAME filesystem first.
        shutil.copytree(common, staging, dirs_exist_ok=True)
        for name, blob in new.items():
            (staging / name).write_bytes(blob)
        shutil.copyfile(content, staging / "LunaNetDiagnostics.h")
        shutil.copyfile(local / "LunaNetDebug.c", staging / "LunaNetDebug.c")
        shutil.copyfile(local / "LunaRfiRecovery.h", staging / "LunaRfiRecovery.h")
        (staging / ".luna-netdiag-overlay.json").write_text(
            json.dumps({name: git_blob_sha(new[name])
                        for name in BASELINES}, sort_keys=True),
            encoding="utf-8")
        # Verify all emitted bytes before switching CMake's source directory.
        for name, blob in new.items():
            if (staging / name).read_bytes() != blob:
                raise ValueError("Staged common-c modification failed verification")
        if ((staging / "LunaNetDiagnostics.h").read_bytes() != content.read_bytes() or
                (staging / "LunaNetDebug.c").read_bytes() !=
                (local / "LunaNetDebug.c").read_bytes() or
                (staging / "LunaRfiRecovery.h").read_bytes() !=
                (local / "LunaRfiRecovery.h").read_bytes()):
            raise ValueError("Staged common-c diagnostic ABI mismatch")

        common.rename(backup)
        try:
            staging.rename(common)
            swapped = True
        except OSError:
            # Ordinary errors restore the original src directory immediately.
            backup.rename(common)
            raise
        # A SIGKILL here leaves BOTH directories. Next invocation verifies
        # the stamped installed tree, then retires the backup.
        shutil.rmtree(backup)
    finally:
        if not swapped and staging.exists() and not staging.is_symlink():
            shutil.rmtree(staging)
    print("Local common-c network Debug observer installed (source pin preserved)")

if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Usage: apply-network-debug.py UNPACKED_MOONLIGHT_SOURCE_ROOT")
        apply(sys.argv[1])
    except (OSError, ValueError) as error:
        print("Network Debug overlay: " + str(error), file=sys.stderr)
        sys.exit(1)
