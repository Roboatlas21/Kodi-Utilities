#ifndef LUNA_RFI_RECOVERY_H
#define LUNA_RFI_RECOVERY_H

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

/* Receive-thread-only state. No frame queue, worker, sleep, or steady-state
 * clock reads. Cooldown survives successful recovery to bound keyframe bursts. */
typedef struct {
    unsigned timeout_ms;
    bool active;
    bool requested;
    uint64_t started_ms;
    uint64_t last_request_ms;
} LunaRfiRecovery;

static void lunaRfiInit(LunaRfiRecovery* state, const char* setting) {
    memset(state, 0, sizeof(*state));
    if (!setting) return;
    unsigned value = 0;
    for (const char* p = setting; *p; ++p) {
        if (*p < '0' || *p > '9' || value > 500) return;
        value = value * 10 + (unsigned)(*p - '0');
    }
    if (value >= 50 && value <= 500) state->timeout_ms = value;
}

static void lunaRfiBegin(LunaRfiRecovery* state, uint64_t now_ms) {
    if (state->timeout_ms && !state->active) {
        state->active = true;
        state->started_ms = now_ms;
    }
}

/* Called only at the end of a fully received frame still blocked by RFI.
 * Missing packets alone never trigger extra keyframes into a dead link. */
static bool lunaRfiEscalate(LunaRfiRecovery* state, uint64_t now_ms) {
    if (!state->active || !state->timeout_ms || now_ms < state->started_ms ||
        now_ms - state->started_ms < state->timeout_ms) return false;
    if (state->requested && (now_ms < state->last_request_ms ||
        now_ms - state->last_request_ms < 1000)) return false;
    state->requested = true;
    state->last_request_ms = now_ms;
    return true;
}

static void lunaRfiComplete(LunaRfiRecovery* state) {
    state->active = false;
}

#endif
