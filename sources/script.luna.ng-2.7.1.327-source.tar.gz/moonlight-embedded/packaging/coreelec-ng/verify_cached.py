#!/usr/bin/env python3
"""Validate complete immutable CoreELEC native/VFM artifacts before cache reuse."""
import argparse
import hashlib
import json
from pathlib import Path
import posixpath
import re
import struct
import tarfile

SHA = re.compile(r"[a-f0-9]{40}\Z")
NATIVE_FILES = {
    "bin/coreelec-ng/moonlight",
    "lib/coreelec-ng/libmoonlight-aml.so",
    "lib/coreelec-ng/libgamestream.so.4",
    "lib/coreelec-ng/libmoonlight-common.so.4",
    "lib/coreelec-ng/libcec.so.6",
}
ASSETS = {"bin/coreelec-ng/gamecontrollerdb.txt"}
MAX_FILE = 64 * 1024 * 1024
MAX_MANIFEST = 128 * 1024


def _members(archive):
    values = {}
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            name = posixpath.normpath(member.name)
            if name == ".":
                continue
            if member.isdir():
                continue
            if (name.startswith("../") or name.startswith("/") or
                    name in values or not member.isfile() or
                    member.size < 0 or member.size > MAX_FILE):
                raise ValueError("Unsafe or duplicate artifact member: " + name)
            handle = bundle.extractfile(member)
            if handle is None:
                raise ValueError("Missing data for " + name)
            with handle:
                data = handle.read(member.size + 1)
            if len(data) != member.size:
                raise ValueError("Invalid member length for " + name)
            values[name] = data
    return values


def _sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def _source(value):
    if not isinstance(value, str) or not SHA.fullmatch(value):
        raise ValueError("Invalid exact private Moonlight source SHA")
    return value


def _manifest(files):
    raw = files.get("manifest.json", files.get("runtime-manifest.json"))
    if raw is None or not 0 < len(raw) <= MAX_MANIFEST:
        raise ValueError("Missing or oversized runtime manifest")
    result = json.loads(raw)
    if not isinstance(result, dict):
        raise ValueError("Invalid runtime manifest")
    return result


def _check_object(files, name, meta, cls, machine):
    data = files.get(name)
    if not isinstance(meta, dict) or data is None or not data:
        raise ValueError("Missing binary or manifest entry: " + name)
    if len(data) != meta.get("size") or _sha_bytes(data) != meta.get("sha256"):
        raise ValueError("Binary digest mismatch: " + name)
    if (len(data) < 52 or data[:6] != b"\x7fELF" + bytes((cls, 1)) or
            struct.unpack_from("<H", data, 18)[0] != machine):
        raise ValueError("Binary ABI mismatch: " + name)
    return data


def verify_native(archive, info, source, recipe):
    _source(source)
    _source(recipe)
    p = Path(info)
    if not p.is_file() or p.stat().st_size > MAX_MANIFEST:
        raise ValueError("Native build-info absent/oversized")
    lines = p.read_text(encoding="utf-8").splitlines()
    if (lines.count("SOURCE_GIT_SHA=" + source) != 1 or
            lines.count("NATIVE_WORKFLOW_SHA=" + recipe) != 1):
        raise ValueError("Native source or recipe metadata differs")
    files = _members(archive)
    m = _manifest(files)
    if (m.get("schema") != "luna-ng-runtime-v1" or
            m.get("source_git_sha") != source or
            m.get("target") != "Amlogic-ce/Amlogic-ng/arm" or
            m.get("capabilities") != ["first-video-ready-v1"]):
        raise ValueError("Native runtime identity differs")
    obj = m.get("objects")
    assets = m.get("assets")
    if (not isinstance(obj, dict) or set(obj) != NATIVE_FILES or
            not isinstance(assets, dict) or set(assets) != ASSETS or
            set(files) != NATIVE_FILES | ASSETS | {"runtime-manifest.json", "build-info.txt"}):
        raise ValueError("Missing, extra or unrecorded native archive objects")
    for name in NATIVE_FILES:
        data = _check_object(files, name, obj[name], 1, 40)
        if name.endswith("/moonlight") and b"LUNA_NATIVE_FIRST_VIDEO_READY_V1" not in data:
            raise ValueError("Native binary lacks first-video support")
        if name.endswith("/libmoonlight-aml.so") and b"MOONLIGHT_VIDEO_READY_FILE" not in data:
            raise ValueError("AML module lacks first-video support")
    for name in ASSETS:
        data = files[name]
        if not 100 <= len(data) <= 2 * 1024 * 1024:
            raise ValueError("Invalid controller mapping asset")
        if len(data) != assets[name].get("size") or _sha_bytes(data) != assets[name].get("sha256"):
            raise ValueError("Controller mapping checksum mismatch")
    return True


def verify_vfm(archive, source, external_manifest=None):
    _source(source)
    files = _members(archive)
    m = _manifest(files)
    order = m.get("module_order")
    obj = m.get("objects")
    release = m.get("kernel_release")
    if (m.get("schema") != "luna-ng-vfm-v1" or
            m.get("moonlight_source_git_sha") != source or
            m.get("bridge_version") != "6" or
            not isinstance(order, list) or len(order) < 4 or
            order[-1] != "moonlight_vfm.ko" or
            len(order) != len(set(order)) or
            "amvdec_ports.ko" not in order or
            not isinstance(release, str) or
            not re.fullmatch(r"[A-Za-z0-9._+-]{1,100}", release) or
            not isinstance(obj, dict) or len(obj) < len(order) + 3):
        raise ValueError("VFM source, decoder or module manifest differs")
    if external_manifest is not None:
        external = Path(external_manifest)
        if not external.is_file() or external.read_bytes() != files["manifest.json"]:
            raise ValueError("VFM index manifest does not match archive")
    if set(obj) != {n for n in files if n != "manifest.json" and not n.startswith("licenses/")}:
        raise ValueError("Unexpected/missing VFM objects")
    if not {"modules/" + release + "/" + n for n in order}.issubset(obj):
        raise ValueError("Missing declared VFM modules")
    if not {"lib/libmoonlight-aml-vfm.so", "lib/libdrm.so.2"}.issubset(obj):
        raise ValueError("Missing VFM libraries")
    for name, meta in obj.items():
        _check_object(files, name, meta, 2 if name.startswith("modules/") else 1,
                      183 if name.startswith("modules/") else 40)
    licenses = [n for n in files if n.startswith("licenses/") and n.endswith(".txt")]
    if len(licenses) != 3:
        raise ValueError("Incomplete VFM license inventory")
    return True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="kind", required=True)
    native = sub.add_parser("native")
    for name in ("archive", "build_info", "source_sha", "workflow_sha"):
        native.add_argument(name)
    vfm = sub.add_parser("vfm")
    vfm.add_argument("archive")
    vfm.add_argument("source_sha")
    vfm.add_argument("manifest")
    args = p.parse_args()
    try:
        if args.kind == "native":
            verify_native(args.archive, args.build_info, args.source_sha, args.workflow_sha)
        else:
            verify_vfm(args.archive, args.source_sha, args.manifest)
    except (OSError, ValueError, UnicodeError, tarfile.TarError, json.JSONDecodeError) as exc:
        p.exit(1, "Cached CoreELEC artifact rejected: " + str(exc) + "\n")
    print("Verified complete cached CoreELEC " + args.kind + " artifact")


if __name__ == "__main__":
    main()
