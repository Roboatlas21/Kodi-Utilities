"""Execute CoreELEC's real USB DualSense arbitration code against a fake clock.

No hardware, kernel modules or Moonlight streaming are needed. This guards
the silence-after-waveform rumble regression with behavior, not source strings.
"""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PCM = ROOT / "src/input/dualsense_pcm.c"


def c_function(source, name):
    match = re.search(
        r"(?m)^(?:static )?(?:bool|void)\s+" + re.escape(name) +
        r"\s*\([^;]*?\)\s*\{", source, re.S)
    if not match:
        raise AssertionError("Missing C implementation: " + name)
    # Follow the actual function's nested braces, not a snapshot of its
    # text or an assumed number of source lines.
    depth = 1
    for index in range(match.end(), len(source)):
        if source[index] == "{":
            depth += 1
        elif source[index] == "}":
            depth -= 1
            if depth == 0:
                return source[match.start():index + 1]
    raise AssertionError("Incomplete C function: " + name)


class DualSenseHapticOwnershipTests(unittest.TestCase):
    def test_silence_releases_usb_rumble_but_preserves_nonzero_tail_and_bluetooth(self):
        compiler = shutil.which("cc")
        if not compiler:
            self.skipTest("C compiler unavailable")
        source = PCM.read_text(encoding="utf-8")
        code = "\n\n".join(c_function(source, name) for name in (
            "ring_clear", "ring_add", "contains_nonzero",
            "ring_contains_nonzero", "usb_waveform_active_locked",
            "ml_ds_audio_playing", "ml_ds_audio_haptics"))
        harness = r"""
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
#define ML_DS_RING_FRAMES 4096U
#define ML_DS_IDLE_US 60000ULL
#define ML_HAPTICS_MAX_FRAMES 240U
typedef struct {
  uint8_t data[ML_DS_RING_FRAMES * 4];
  unsigned read, length;
} pcm_ring;
typedef struct ml_ds_audio {
  int bt_fd;
  pthread_mutex_t lock;
  pthread_cond_t wake;
  bool stop, active, failed, have_act_seq;
  pcm_ring actuator;
  uint64_t last_nonzero_us;
  uint32_t act_seq;
} ml_ds_audio;
static uint64_t clock_us;
static uint64_t now_us(void) { return clock_us; }
""" + code + r"""
int main(void) {
  ml_ds_audio audio = {0};
  audio.bt_fd = -1;
  assert(pthread_mutex_init(&audio.lock, 0) == 0);
  assert(pthread_cond_init(&audio.wake, 0) == 0);
  const uint8_t rumble[4] = {1, 0, 0, 0};
  const uint8_t silent[4] = {0, 0, 0, 0};
  clock_us = 1000000;
  ml_ds_audio_haptics(&audio, 1, rumble, 1);
  assert(ml_ds_audio_playing(&audio));

  /* The USB worker drained the nonzero waveform. */
  ring_clear(&audio.actuator);
  clock_us += 20000;
  ml_ds_audio_haptics(&audio, 2, silent, 1);
  assert(ml_ds_audio_playing(&audio)); /* 60ms grace period */

  ring_clear(&audio.actuator);
  clock_us += 61000;
  ml_ds_audio_haptics(&audio, 3, silent, 1);
  assert(!ml_ds_audio_playing(&audio));
  assert(!audio.active && audio.actuator.length == 0);

  /* A flood of idle host PCM must never steal generic rumble again. */
  for (uint32_t seq = 4; seq < 104; ++seq) {
    clock_us += 5000;
    ml_ds_audio_haptics(&audio, seq, silent, 1);
    assert(!ml_ds_audio_playing(&audio));
    assert(!audio.active && audio.actuator.length == 0);
  }

  ml_ds_audio_haptics(&audio, 104, rumble, 1);
  assert(ml_ds_audio_playing(&audio)); /* New actual waveform takes ownership. */

  /* A stalled USB worker must preserve an undrained nonzero tail. */
  clock_us += 100000;
  assert(ml_ds_audio_playing(&audio));
  ring_clear(&audio.actuator);
  assert(!ml_ds_audio_playing(&audio));

  /* Bluetooth still requires a final silence report from its worker. */
  audio.bt_fd = 12;
  audio.active = true;
  ml_ds_audio_haptics(&audio, 105, silent, 1);
  assert(audio.active);
  pthread_cond_destroy(&audio.wake);
  pthread_mutex_destroy(&audio.lock);
  return 0;
}
"""
        with tempfile.TemporaryDirectory() as folder:
            binary = str(Path(folder) / "dualsense-arbitration")
            compile_result = subprocess.run(
                [compiler, "-x", "c", "-std=c11", "-Wall", "-Wextra",
                 "-Werror", "-pthread", "-o", binary, "-"],
                input=harness, capture_output=True, text=True, timeout=15)
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)
            run = subprocess.run([binary], capture_output=True, text=True, timeout=5)
            self.assertEqual(run.returncode, 0, run.stderr)


if __name__ == "__main__":
    unittest.main()
