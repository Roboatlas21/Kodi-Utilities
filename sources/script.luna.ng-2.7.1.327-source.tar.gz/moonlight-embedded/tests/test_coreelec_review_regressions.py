"""CoreELEC native regressions: USB haptic ownership and frozen callback naming."""
import re
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
PCM = (ROOT / "src/input/dualsense_pcm.c").read_text(encoding="utf-8")
NATIVE = (ROOT / ".github/workflows/coreelec-ng-native.yml").read_text(encoding="utf-8")
BRIDGE = (ROOT / ".github/workflows/promote-coreelec-ng-cache.yml").read_text(encoding="utf-8")


class CoreElecReviewRegressionTests(unittest.TestCase):
    def test_usb_silent_packets_release_rumble_after_real_tail(self):
        self.assertIn("static bool ring_contains_nonzero(", PCM)
        self.assertIn("static bool usb_waveform_active_locked(", PCM)
        self.assertIn("!ring_contains_nonzero(&a->actuator)", PCM)
        self.assertIn("now - a->last_nonzero_us >= ML_DS_IDLE_US", PCM)
        self.assertIn("a->active = false;", PCM)
        self.assertIn("ring_clear(&a->actuator);", PCM)
        self.assertIn("(void)usb_waveform_active_locked(a);", PCM)
        self.assertIn("const bool active = usb_waveform_active_locked(a);", PCM)
        self.assertIn("if (a->bt_fd >= 0 || !a->active) return a->active;", PCM)
        # Do not enqueue a late all-zero packet just because an old waveform
        # once made the persistent active flag true.
        self.assertNotIn("if (a->active || nonzero) {", PCM)

    def test_callback_title_is_correct_for_v5_and_future_launchers(self):
        start = NATIVE.index('          callback_branch="${completion_ref#refs/heads/}"')
        end = NATIVE.index('          # A queued/running/successful identical callback', start)
        section = NATIVE[start:end]
        for branch, expected in [
            ("matrix", "Luna NG completion of 12345678"),
            ("luna-ng-launcher-v1", "Luna NG completion of 12345678"),
            ("luna-ng-launcher-v4", "Luna NG completion of 12345678 native 99999999"),
            ("luna-ng-launcher-v5", "Luna NG completion of 12345678 native 99999999"),
            ("luna-ng-launcher-v10", "Luna NG completion of 12345678 native 99999999"),
        ]:
            script = ('completion_ref=refs/heads/' + branch +
                      '; origin_run=12345678; GITHUB_RUN_ID=99999999;\n' +
                      section + '\nprintf "%s" "$title"\n')
            result = subprocess.run(["bash", "-e"], input=script, text=True,
                                    capture_output=True, timeout=5)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, expected)

    def test_cache_export_provenance_accepts_user_triggered_bot_and_rejects_forgeries(self):
        """Execute the workflow's jq policy, not strings that might be dead code."""
        import copy
        import json
        import shutil

        if not shutil.which("jq"):
            self.skipTest("jq is required to execute the production cache policy")
        match = re.search(
            r"""jq -e --argjson id "\$SOURCE_RUN" '(?P<filter>.*?)' >/dev/null""",
            BRIDGE, re.S)
        self.assertIsNotNone(match, "Cannot locate the live cache export provenance rule")
        jq_filter = match.group("filter")
        run_id = 41765271658

        def accepted(run):
            result = subprocess.run(
                ["jq", "-e", "--argjson", "id", str(run_id), jq_filter],
                input=json.dumps(run), text=True, capture_output=True, timeout=5)
            self.assertIn(result.returncode, (0, 1, 4), result.stderr)
            return result.returncode == 0

        original = {
            "id": run_id,
            "path": ".github/workflows/promote-coreelec-ng-cache.yml",
            "event": "workflow_dispatch",
            "head_branch": "feat/coreelec-ng",
            "repository": {"full_name": "Roboatlas21/moonlight-embedded"},
            "head_repository": {"full_name": "Roboatlas21/moonlight-embedded"},
            "actor": {"login": "github-actions[bot]"},
            "triggering_actor": {"login": "Roboatlas21"},
            "status": "completed",
            "conclusion": "success",
        }
        # The actual export had a bot actor and a human triggering_actor.
        self.assertTrue(accepted(original))
        for actor, triggering in (
            ("Roboatlas21", "Roboatlas21"),
            ("github-actions[bot]", "github-actions[bot]"),
        ):
            fixture = copy.deepcopy(original)
            fixture["actor"]["login"] = actor
            fixture["triggering_actor"]["login"] = triggering
            self.assertTrue(accepted(fixture), (actor, triggering))

        for path, replacement in (
            (("id",), 1234),
            (("path",), ".github/workflows/untrusted.yml"),
            (("event",), "push"),
            (("head_branch",), "master"),
            (("repository", "full_name"), "untrusted/other"),
            (("head_repository", "full_name"), "untrusted/fork"),
            (("actor", "login"), "untrusted-user"),
            (("triggering_actor", "login"), "untrusted-user"),
            (("status",), "queued"),
            (("conclusion",), "failure"),
        ):
            with self.subTest(field=path):
                fixture = copy.deepcopy(original)
                target = fixture
                for segment in path[:-1]:
                    target = target[segment]
                target[path[-1]] = replacement
                self.assertFalse(accepted(fixture), path)

    def test_cache_export_checks_both_successful_jobs_and_unexpired_artifacts(self):
        """Keep proof of both cache contents, not merely a trusted actor."""
        self.assertIn('all($jobs[]; .conclusion == "success")', BRIDGE)
        self.assertIn('.name == "export (toolchain)"', BRIDGE)
        self.assertIn('.name == "export (dependencies)"', BRIDGE)
        self.assertIn('.expired == false', BRIDGE)


if __name__ == "__main__":
    unittest.main()
