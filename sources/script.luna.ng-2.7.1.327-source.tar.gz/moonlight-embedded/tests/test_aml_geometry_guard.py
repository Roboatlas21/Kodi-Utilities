"""Standalone Moonlight must reject unsupported AML profiles before display takeover."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AmlGeometryTests(unittest.TestCase):
    def test_entrypoint_rejects_before_platform_start(self):
        source = (ROOT / "src/main.c").read_text()
        main = source.split("int main(int argc, char* argv[]) {", 1)[1]
        start = main.index("if ((system == AML || system == AML_VFM) &&")
        end = main.index("config.stream.supportedVideoFormats =", start)
        guard = main[start:end]
        for required in ("config.stream.width > 4096", "config.stream.height > 2160",
                         "config.stream.fps > 120", "config.stream.fps > 60",
                         "config.codec == CODEC_AV1", "return EXIT_FAILURE;"):
            self.assertIn(required, guard)
        self.assertLess(main.index("if ((system == AML || system == AML_VFM) &&"),
                        main.index("stream(&server, &config, system,"))
        # Display takeover lives in stream(), defined before main(). File
        # offsets across those functions do not describe execution order.
        self.assertNotIn("platform_start(system)", main)
        stream = source.split("static int stream(", 1)[1].split("int main(", 1)[0]
        self.assertIn("platform_start(system)", stream)
        render = (ROOT / "src/video/aml.c").read_text()
        setup = render.split("int aml_setup(", 1)[1].split("// Diagnostics are off", 1)[0]
        self.assertIn("redrawRate < 1", setup)
        self.assertIn("return -1", setup)


if __name__ == "__main__":
    unittest.main()

