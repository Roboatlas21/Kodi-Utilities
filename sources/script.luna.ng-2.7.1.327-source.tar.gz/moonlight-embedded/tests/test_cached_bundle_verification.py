"""Regression checks for exact native and VFM binary cache validation."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import tarfile
import tempfile
import unittest

P = Path(__file__).resolve().parents[1] / "packaging/coreelec-ng/verify_cached.py"
SPEC = importlib.util.spec_from_file_location("verify_cached", P)
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)
SOURCE, RECIPE = "a" * 40, "b" * 40


def elf(cls, machine, token=b""):
    data = bytearray(b"\x00" * 128)
    data[:6] = b"\x7fELF" + bytes((cls, 1))
    struct.pack_into("<H", data, 18, machine)
    return bytes(data) + token


def archive(path, content):
    with tarfile.open(path, "w:gz") as stream:
        for name, data in content.items():
            item = tarfile.TarInfo("./" + name)
            item.size = len(data)
            stream.addfile(item, io.BytesIO(data))


class ReuseVerificationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.archive = self.root / "artifact.tar.gz"
        self.info = self.root / "build-info.txt"
        self.info.write_text("SOURCE_GIT_SHA=" + SOURCE + "\nNATIVE_WORKFLOW_SHA=" + RECIPE + "\n")

    def native(self):
        files = {n: elf(1, 40,
                        b"LUNA_NATIVE_FIRST_VIDEO_READY_V1" if n.endswith("/moonlight") else
                        b"MOONLIGHT_VIDEO_READY_FILE" if n.endswith("/libmoonlight-aml.so") else b"")
                 for n in MOD.NATIVE_FILES}
        files["bin/coreelec-ng/gamecontrollerdb.txt"] = b"x" * 200
        m = {"schema": "luna-ng-runtime-v1", "source_git_sha": SOURCE,
             "target": "Amlogic-ce/Amlogic-ng/arm",
             "capabilities": ["first-video-ready-v1"],
             "objects": {n: {"size": len(files[n]), "sha256": MOD._sha_bytes(files[n])} for n in MOD.NATIVE_FILES},
             "assets": {"bin/coreelec-ng/gamecontrollerdb.txt": {
                 "size": 200, "sha256": MOD._sha_bytes(b"x" * 200)}}}
        files["runtime-manifest.json"] = json.dumps(m).encode()
        files["build-info.txt"] = self.info.read_bytes()
        return files

    def test_native_exact_archive_passes_and_missing_objects_rejected(self):
        data = self.native()
        archive(self.archive, data)
        self.assertTrue(MOD.verify_native(self.archive, self.info, SOURCE, RECIPE))
        data.pop("lib/coreelec-ng/libcec.so.6")
        archive(self.archive, data)
        with self.assertRaisesRegex(ValueError, "Missing|extra|unrecorded"):
            MOD.verify_native(self.archive, self.info, SOURCE, RECIPE)

    def test_native_digest_change_is_rejected(self):
        data = self.native()
        data["bin/coreelec-ng/moonlight"] += b"tampered"
        archive(self.archive, data)
        with self.assertRaisesRegex(ValueError, "digest"):
            MOD.verify_native(self.archive, self.info, SOURCE, RECIPE)

    def test_recipe_mismatch_rejected(self):
        archive(self.archive, self.native())
        with self.assertRaisesRegex(ValueError, "recipe"):
            MOD.verify_native(self.archive, self.info, SOURCE, "c" * 40)

    def vfm(self):
        rel = "4.9.269"
        order = ["amvdec_ports.ko", "amvdec_mh264.ko", "amvdec_h265.ko", "moonlight_vfm.ko"]
        data = {"modules/" + rel + "/" + name: elf(2, 183) for name in order}
        for lib in ("libmoonlight-aml-vfm.so", "libdrm.so.2", "libavcodec.so.60", "libavutil.so.58"):
            data["lib/" + lib] = elf(1, 40)
        for n in ("FFmpeg-LGPL-2.1.txt", "moonlight-GPL-3.0.txt", "libdrm-notices.txt"):
            data["licenses/" + n] = b"license"
        m = {"schema": "luna-ng-vfm-v1", "moonlight_source_git_sha": SOURCE,
             "kernel_release": rel, "bridge_version": "6", "module_order": order,
             "objects": {n: {"size": len(v), "sha256": MOD._sha_bytes(v)}
                         for n, v in data.items() if not n.startswith("licenses/")}}
        data["manifest.json"] = json.dumps(m).encode()
        return data

    def test_vfm_hashes_and_external_manifest(self):
        data = self.vfm()
        archive(self.archive, data)
        manifest = self.root / "manifest.json"
        manifest.write_bytes(data["manifest.json"])
        self.assertTrue(MOD.verify_vfm(self.archive, SOURCE, manifest))
        data["modules/4.9.269/moonlight_vfm.ko"] += b"corrupt"
        archive(self.archive, data)
        with self.assertRaisesRegex(ValueError, "digest"):
            MOD.verify_vfm(self.archive, SOURCE, manifest)

    def test_vfm_mismatched_manifest_rejected(self):
        data = self.vfm()
        archive(self.archive, data)
        manifest = self.root / "manifest.json"
        manifest.write_text("{}")
        with self.assertRaisesRegex(ValueError, "does not match"):
            MOD.verify_vfm(self.archive, SOURCE, manifest)


if __name__ == "__main__":
    unittest.main()
