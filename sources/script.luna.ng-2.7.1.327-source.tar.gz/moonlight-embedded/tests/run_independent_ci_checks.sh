#!/usr/bin/env bash
# Preserve every independent check's result, even after the first failure.
set -uo pipefail
group="$1"
root="$(cd "$(dirname "$0")/.." && pwd)" || exit 2
cd "$root" || exit 2
log_root="${SOURCE_VALIDATION_LOG_DIR:-${RUNNER_TEMP:-/tmp}/moonlight-source-check-logs}"
log_dir="$log_root/independent-$group"
mkdir -p "$log_dir" || exit 2
printf 'check\tresult\texit_code\tlog\n' > "$log_dir/results.tsv"
checks=0
failures=0
run_checked() {
  local label="$1" limit=180 log code
  shift
  checks=$((checks + 1))
  [[ "$label" == apt-* ]] && limit=240
  printf -v log '%s/%03d-%s.log' "$log_dir" "$checks" "$label"
  printf '::group::Moonlight independent %s / %s\n' "$group" "$label"
  timeout --signal=TERM --kill-after=3s "$limit"s "$@" 2>&1 | tee "$log"
  local status=( ${PIPESTATUS[@]} )
  code=${status[0]}
  if (( code == 0 && status[1] != 0 )); then code=${status[1]}; fi
  printf '::endgroup::\n'
  if (( code != 0 )); then
    failures=$((failures + 1))
    printf 'SOURCE_CHECK_FAIL group=%s check=%s exit=%s log=%s\n' "$group" "$label" "$code" "$log" >&2
    printf '%s\tFAIL\t%s\t%s\n' "$label" "$code" "$log" >> "$log_dir/results.tsv"
  else
    printf 'SOURCE_CHECK_PASS group=%s check=%s\n' "$group" "$label"
    printf '%s\tPASS\t0\t%s\n' "$label" "$log" >> "$log_dir/results.tsv"
  fi
}
case "$group" in
  check01)
    run_checked host-runner-syntax bash -n tests/run_private_host_checks.sh
    run_checked apt-update sudo apt-get update -qq
    run_checked apt-dependencies sudo apt-get install -y --no-install-recommends pkg-config libavcodec-dev libavutil-dev libdrm-dev libasound2-dev libopus-dev libssl-dev libcurl4-openssl-dev libexpat1-dev uuid-dev libevdev-dev libudev-dev
    run_checked vfm-host bash tests/test_vfm_host.sh
    run_checked alsa-write bash tests/test_alsa_bounded_write.sh
    run_checked alsa-init python3 tests/test_alsa_init.py
    for name in test_aml_startup_stall test_video_readiness_wiring test_unique_id_persistence test_client_identity_permissions test_certificate_hex test_pairing_exchange; do
      run_checked "$name" python3 -m unittest discover -s tests -p "$name.py" -v
    done
    run_checked compile-gamestream cc -std=gnu99 -Wall -Wextra -Werror -Wno-unused-parameter -Wno-deprecated-declarations -ffunction-sections -fdata-sections -fsanitize=address,undefined -fno-omit-frame-pointer -Ithird_party/moonlight-common-c/src -Ilibgamestream tests/test_gamestream_protocol.c libgamestream/xml.c -Wl,--gc-sections -lcrypto -lssl -lexpat -l:libuuid.so.1 -o /tmp/test-gamestream-protocol
    run_checked execute-gamestream env ASAN_OPTIONS=detect_leaks=1 /tmp/test-gamestream-protocol
    run_checked app-id-aml python3 -m unittest discover -s tests -p test_app_id_aml_probe.py -v
    for name in test_serverinfo_numeric test_mouse_deadzone test_applist_ids test_controller_count; do
      run_checked "compile-$name" cc -std=gnu99 -Wall -Wextra -Werror "tests/$name.c" -o "/tmp/$name"
      run_checked "execute-$name" "/tmp/$name"
    done
    for name in test_vfm_package_source_lock test_vfm_real_cross_repo; do
      run_checked "$name" python3 -m unittest discover -s tests -p "$name.py" -v
    done
    for name in test_steam_controller_2026_codec test_steam_controller_2026_fallback test_steam_output_queue; do
      run_checked "compile-$name" cc -std=c99 -Wall -Wextra -Werror -pedantic -Ithird_party/moonlight-common-c/src "tests/$name.c" -o "/tmp/$name"
      run_checked "execute-$name" "/tmp/$name"
    done
    run_checked controller-rumble python3 -m unittest discover -s tests -p test_controller_rumble_wiring.py -v
    run_checked steam-integration python3 tests/test_steam_controller_2026_integration.py
    run_checked stream-diagnostics bash tests/test_stream_diagnostics.sh
    run_checked alsa-syntax bash -c 'cc -std=gnu99 -Wall -Wextra -Werror -Wno-unused-parameter -fsyntax-only -Ithird_party/moonlight-common-c/src $(pkg-config --cflags alsa opus) src/audio/alsa.c'
    ;;
  check03)
    run_checked python_test_inventory python3 tests/check_test_inventory.py
    for name in test_native_dependency_key test_private_native_workflow test_coreelec_review_regressions; do
      run_checked "$name" python3 -m unittest discover -s tests -p "$name.py" -v
    done
    ;;
  check04)
    for name in test_native_config_sections test_source_config_guard test_session_config_precedence test_config_lookup_safety test_hdr_config test_gamestream_url_wiring; do
      run_checked "$name" python3 -m unittest discover -s tests -p "$name.py" -v
    done
    for name in test_config_section test_config_ini test_config_numeric test_url_host; do
      run_checked "compile-$name" cc -std=gnu99 -Wall -Wextra -Werror -pedantic "tests/$name.c" -o "/tmp/$name"
      run_checked "execute-$name" "/tmp/$name"
    done
    ;;
  check05)
    run_checked prepare-syntax bash -n packaging/coreelec-ng/prepare-build.sh
    run_checked arch-check grep -Fq ARCH=arm packaging/coreelec-ng/prepare-build.sh
    run_checked audio-check grep -Fq ENABLE_CORE_ELEC_AUDIO_MAPPING=ON packaging/coreelec-ng/package.mk
    run_checked common-check grep -Fq third_party/moonlight-common-c packaging/coreelec-ng/package.mk
    ;;
  check06)
    run_checked host-flags-syntax bash -n packaging/coreelec-ng/patch-host-flags.sh
    run_checked host-tools-syntax bash -n packaging/coreelec-ng/check-host-tools.sh
    run_checked host-portability bash tests/test_host_portability.sh
    ;;
  check07)
    run_checked rtmpdump-syntax bash -n packaging/coreelec-ng/fix-rtmpdump-source.sh
    run_checked rtmpdump-test bash tests/test_rtmpdump_source.sh
    ;;
  check10)
    run_checked vfm-runtime python3 -m unittest discover -s tests -p test_vfm_runtime_build.py -v
    for name in prepare-build.sh smoke-runtime.sh ffmpeg-package.mk driver-package.mk; do
      run_checked "syntax-$name" bash -n "packaging/coreelec-ng/vfm/$name"
    done
    ;;
  check11)
    run_checked build-stage-syntax bash -n packaging/coreelec-ng/build-stage.sh
    run_checked build-stage-test bash tests/test_coreelec_ng_build_stage.sh
    ;;
  ci-selftest)
    run_checked intentional-failure bash -c 'exit 7'
    run_checked independent-success bash -c 'echo still-ran'
    ;;
  *)
    echo "Unsupported independent CI group $group" >&2
    exit 2 ;;
esac
printf 'INDEPENDENT_CI_SUMMARY group=%s checks=%s failures=%s\n' "$group" "$checks" "$failures"
if (( failures )); then
  echo "::error::$failures independent checks failed in $group; later checks still ran."
  exit 1
fi
