#!/usr/bin/env python3
"""Fail preflight if a new Python regression test is silently left unexecuted.

Moonlight uses explicit group inventories rather than unittest discover of
every test_*.py. Keep the few deliberately slow integration cases documented.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SCHEDULES = (
    "tests/run_private_host_checks.sh",
    "tests/validate_private_source.sh",
    "tests/run_independent_ci_checks.sh",
    "tests/validate_private_source_extras.sh",
    ".github/workflows/coreelec-ng-checks.yml",
)
# These are real local integration tests, but unsuitable for every native
# preflight: their delayed HTTP server waits make CI timing noisy and slow.
EXTENDED_ONLY = {
    "test_http_pairing_timeout.py": "33-second real HTTP timing deadlines",
    "test_pairing_errors.py": "delayed native TLS/HTTP pairing integration",
}


def main():
    source = "\n".join((ROOT / path).read_text(encoding="utf-8")
                       for path in SCHEDULES)
    tests = sorted((ROOT / "tests").glob("test_*.py"))
    omitted = [path.name for path in tests
               if path.name not in EXTENDED_ONLY and
               path.name not in source and path.stem not in source]
    if omitted:
        print("CoreELEC source preflight does not run these Python tests:",
              ", ".join(omitted), file=sys.stderr)
        return 1
    exceptions = sorted(set(EXTENDED_ONLY) - {path.name for path in tests})
    if exceptions:
        print("Stale extended-test exemption:", ", ".join(exceptions),
              file=sys.stderr)
        return 1
    print("PASS: %d Python regressions tracked by CI (%d extended timing cases)" %
          (len(tests), len(EXTENDED_ONLY)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
