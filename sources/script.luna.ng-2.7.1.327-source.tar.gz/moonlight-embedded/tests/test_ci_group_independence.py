"""CI must collect all failures within each independent test group."""
from pathlib import Path
import os
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class IndependentSourceChecksTests(unittest.TestCase):
    def test_failure_does_not_hide_later_case_or_logs(self):
        with tempfile.TemporaryDirectory() as folder:
            env = dict(os.environ, SOURCE_VALIDATION_LOG_DIR=folder)
            result = subprocess.run(
                ["bash", str(ROOT / "tests/run_independent_ci_checks.sh"),
                 "ci-selftest"], cwd=ROOT, env=env,
                capture_output=True, text=True, timeout=12)
            self.assertEqual(result.returncode, 1)
            self.assertIn("still-ran", result.stdout)
            results = (Path(folder) / "independent-ci-selftest" /
                       "results.tsv").read_text()
            self.assertIn("intentional-failure\tFAIL\t7", results)
            self.assertIn("independent-success\tPASS\t0", results)

    def test_moonlight_workflow_preserves_groups_with_individual_deadlines(self):
        runner = (ROOT / "tests/run_independent_ci_checks.sh").read_text()
        workflow = (ROOT / ".github/workflows/coreelec-ng-checks.yml").read_text()
        for group in ("check01", "check03", "check04", "check05",
                      "check06", "check07", "check10", "check11"):
            self.assertIn(group + ")", runner)
            self.assertIn("bash tests/run_independent_ci_checks.sh " + group,
                          workflow)
        self.assertIn("timeout --signal=TERM --kill-after=3s", runner)
        self.assertIn("SOURCE_CHECK_FAIL", runner)
        self.assertIn("steps.logs_upload.outcome", workflow)


if __name__ == "__main__":
    unittest.main()
