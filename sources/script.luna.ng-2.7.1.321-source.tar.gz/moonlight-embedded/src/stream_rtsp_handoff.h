/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once

#include <Limelight.h>
#include <stdbool.h>

/*
 * A /launch or /resume response updates serverInfo.rtspSessionUrl. Always
 * snapshot the live SERVER_INFORMATION after gs_start_app() succeeds.
 * Only address is replaced: normalize transport sockets without changing
 * the original paired host, serverinfo fields, or RTSP encryption URL.
 *
 * The caller owns the snapshot on its stream stack until LiStopConnection().
 */
static inline SERVER_INFORMATION moonlight_stream_rtsp_snapshot(
    const SERVER_INFORMATION *live, const char *transport_address) {
  SERVER_INFORMATION result = *live;
  result.address = transport_address;
  return result;
}

/* Keep the two production connection entry points behind one testable
 * dispatch boundary. Both consume the exact same post-launch snapshot.
 * Callback lifetimes and the caller-owned snapshot remain unchanged. */
static inline int moonlight_stream_connect_with_snapshot(
    PSERVER_INFORMATION snapshot, bool embedded,
    PSTREAM_CONFIGURATION config,
    PCONNECTION_LISTENER_CALLBACKS listeners,
    PDECODER_RENDERER_CALLBACKS video,
    PAUDIO_RENDERER_CALLBACKS audio,
    int display_flags, void *audio_device,
    ConnListenerControllerSpeakerPcm speaker,
    ConnListenerSteamHaptic steam_haptic,
    ConnListenerSteamSettings steam_settings) {
  if (embedded) {
    return LiStartConnectionWithSteamController(
        snapshot, config, listeners, video, audio, NULL, display_flags,
        audio_device, 0, speaker, steam_haptic, steam_settings);
  }
  return LiStartConnection(
      snapshot, config, listeners, video, audio, NULL, display_flags,
      audio_device, 0);
}
