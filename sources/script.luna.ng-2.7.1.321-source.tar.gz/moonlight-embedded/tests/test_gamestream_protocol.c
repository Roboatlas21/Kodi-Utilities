/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Exercise the real GameStream client response handlers with in-memory HTTP.
 * No network connection, native decoder, or CoreELEC hardware is needed. */
#define _POSIX_C_SOURCE 200809L
#include <Limelight.h>
#include "../libgamestream/http.h"
#include "../libgamestream/client.h"
#include "../libgamestream/errors.h"
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *fixture_reply;
static int fixture_transport_result = GS_OK;
static char last_request[4096];

static PHTTP_DATA fixture_http_create_data(void) {
  return calloc(1, sizeof(HTTP_DATA));
}
static int fixture_http_request(char *url, PHTTP_DATA data) {
  snprintf(last_request, sizeof(last_request), "%s", url);
  if (fixture_transport_result != GS_OK)
    return fixture_transport_result;
  if (!fixture_reply) return GS_IO_ERROR;
  free(data->memory);
  data->memory = strdup(fixture_reply);
  if (!data->memory) return GS_OUT_OF_MEMORY;
  data->size = strlen(fixture_reply);
  return GS_OK;
}
static void fixture_http_free_data(PHTTP_DATA data) {
  if (data) {
    free(data->memory);
    free(data);
  }
}

/* Include the production client so these are its actual response handlers.
 * Redirect only HTTP I/O and the common-c optional URL query hook. */
#define http_create_data fixture_http_create_data
#define http_request fixture_http_request
#define http_free_data fixture_http_free_data
#define LiGetLaunchUrlQueryParameters() ""
#include "../libgamestream/client.c"
#undef http_create_data
#undef http_request
#undef http_free_data
#undef LiGetLaunchUrlQueryParameters

#include "../src/stream_rtsp_handoff.h"

/* Real gs_start_app() + XML parser; stub only the final common-c connection
 * boundary so the test runs before a cross-compiled ARM/CoreELEC build. */
static const char *expected_rtsp_url;
static const char *expected_socket_host;
static bool expected_encrypted_rtsp;
static int normal_connections;
static int steam_connections;

static void inspect_connection_server_info(PSERVER_INFORMATION info) {
  assert(info && info->address && expected_socket_host);
  assert(strcmp(info->address, expected_socket_host) == 0);
  if (expected_rtsp_url) {
    assert(info->rtspSessionUrl != NULL);
    assert(strcmp(info->rtspSessionUrl, expected_rtsp_url) == 0);
  } else {
    assert(info->rtspSessionUrl == NULL);
  }
  /* This is the scheme that common-c uses to enable encrypted RTSP.
   * The actual common-c wire handshake is not exercised by this mock. */
  assert((info->rtspSessionUrl != NULL &&
          strstr(info->rtspSessionUrl, "rtspenc://") != NULL) ==
         expected_encrypted_rtsp);
}

int LiStartConnection(PSERVER_INFORMATION info,
    PSTREAM_CONFIGURATION stream, PCONNECTION_LISTENER_CALLBACKS listener,
    PDECODER_RENDERER_CALLBACKS video, PAUDIO_RENDERER_CALLBACKS audio,
    void *render, int flags, void *audio_context, int audio_flags) {
  inspect_connection_server_info(info);
  ++normal_connections;
  return 0;
}

int LiStartConnectionWithSteamController(PSERVER_INFORMATION info,
    PSTREAM_CONFIGURATION stream, PCONNECTION_LISTENER_CALLBACKS listener,
    PDECODER_RENDERER_CALLBACKS video, PAUDIO_RENDERER_CALLBACKS audio,
    void *render, int flags, void *audio_context, int audio_flags,
    ConnListenerControllerSpeakerPcm speaker,
    ConnListenerSteamHaptic haptic, ConnListenerSteamSettings settings) {
  inspect_connection_server_info(info);
  ++steam_connections;
  return 0;
}

static SERVER_DATA new_server(void) {
  SERVER_DATA server = {0};
  server.serverInfo.address = "127.0.0.1";
  server.httpPort = 47989;
  server.httpsPort = 47984;
  server.unsupported = true;
  return server;
}

/* The production main passes an uninitialized stack SERVER_DATA to gs_init.
 * Exercise its real ownership reset helper without linking credentials and
 * common-c startup dependencies into this narrow HTTP response harness. */
static void check_server_init_ownership(void) {
  SERVER_DATA server;
  memset(&server, 0xa5, sizeof(server));
  initialize_server_data(&server);
  assert(server.serverInfo.serverInfoAppVersion == NULL);
  assert(server.serverInfo.serverInfoGfeVersion == NULL);
  assert(server.serverInfo.rtspSessionUrl == NULL);
  assert(server.gpuType == NULL && server.gsVersion == NULL);
  assert(server.modes == NULL && server.httpsPort == 0);
}

static void check_server_info_status(void) {
  const char *valid_fields =
      "<currentgame>0</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.1.431.-1</appversion><state>IDLE</state>"
      "<ServerCodecModeSupport>1</ServerCodecModeSupport>"
      "<gputype>GPU</gputype><GsVersion>7</GsVersion>"
      "<GfeVersion>7</GfeVersion><HttpsPort>47984</HttpsPort>";
  char reply[2048];
  const char *headers[] = {
      "status_code='200'", "", "status_code='200oops'",
      "status_code='403' status_message='No access'"
  };
  const int expected[] = {GS_OK, GS_INVALID, GS_INVALID, GS_ERROR};

  for (unsigned i = 0; i < sizeof(headers)/sizeof(headers[0]); ++i) {
    SERVER_DATA server = new_server();
    snprintf(reply, sizeof(reply), "<root %s>%s</root>", headers[i], valid_fields);
    fixture_reply = reply;
    int rc = load_serverinfo(&server, false);
    assert(rc == expected[i]);
    if (rc != GS_OK)
      assert(server.serverMajorVersion == 0);
    else
      assert(server.serverMajorVersion == 7 && server.paired);
    free((char *)server.serverInfo.serverInfoAppVersion);
    free((char *)server.serverInfo.serverInfoGfeVersion);
    free(server.gsVersion);
    free(server.gpuType);
  }
}


static void assert_server_state(const SERVER_DATA *server) {
  assert(server->serverMajorVersion == 7);
  assert(server->paired);
  assert(server->currentGame == 33);
  assert(server->httpsPort == 50000);
  assert(!strcmp(server->serverInfo.serverInfoAppVersion, "7.1.0"));
  assert(!strcmp(server->gpuType, "GPU-A"));
  assert(server->modes && server->modes->width == 1920);
  assert(server->modes->height == 1080 && server->modes->refresh == 60);
}

/* Repeated HTTP/HTTPS discovery must be an atomic replacement. Invalid
 * optional/required fields or a failed second request may not corrupt the
 * already validated server state or leak uncommitted allocations. */
static void check_serverinfo_staged_commit(void) {
  SERVER_DATA server = new_server();
  const char *valid =
      "<root status_code='200'>"
      "<currentgame>33</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.1.0</appversion><state>MJOLNIR_SERVER_BUSY</state>"
      "<ServerCodecModeSupport>1</ServerCodecModeSupport>"
      "<gputype>GPU-A</gputype><GsVersion>7</GsVersion>"
      "<GfeVersion>7</GfeVersion><HttpsPort>50000</HttpsPort>"
      "<DisplayMode><Width>1920</Width><Height>1080</Height>"
      "<RefreshRate>60</RefreshRate></DisplayMode></root>";
  fixture_reply = valid;
  assert(load_serverinfo(&server, false) == GS_OK);
  assert_server_state(&server);
  const char *bad_responses[] = {
      /* Numeric fields must be complete unsigned decimal values, not atoi prefixes. */
      "<root status_code='200'><currentgame>-1</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.1.0</appversion><state>MJOLNIR_SERVER_BUSY</state><HttpsPort>50000</HttpsPort></root>",
      "<root status_code='200'><currentgame>12abc</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.1.0</appversion><state>MJOLNIR_SERVER_BUSY</state><HttpsPort>50000</HttpsPort></root>",
      "<root status_code='200'><currentgame>2147483648</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.1.0</appversion><state>MJOLNIR_SERVER_BUSY</state><HttpsPort>50000</HttpsPort></root>",
      "<root status_code='200'><currentgame>12</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.bad</appversion><state>MJOLNIR_SERVER_BUSY</state><HttpsPort>50000</HttpsPort></root>",
      "<root status_code='200'><currentgame>12</currentgame><PairStatus>1</PairStatus>"
      "<appversion>7.1.0</appversion><ServerCodecModeSupport>1junk</ServerCodecModeSupport>"
      "<state>MJOLNIR_SERVER_BUSY</state><HttpsPort>50000</HttpsPort></root>",
      /* No currentgame. */
      "<root status_code='200'><PairStatus>1</PairStatus>"
      "<appversion>8</appversion><state>MJOLNIR_SERVER_BUSY</state></root>",
      /* Missing or empty pairing and version information. */
      "<root status_code='200'><currentgame>2</currentgame>"
      "<appversion>8</appversion><state>MJOLNIR_SERVER_BUSY</state></root>",
      "<root status_code='200'><currentgame>2</currentgame>"
      "<PairStatus>1</PairStatus><state>MJOLNIR_SERVER_BUSY</state></root>",
      "<root status_code='200'><currentgame>2</currentgame>"
      "<PairStatus>1</PairStatus><appversion>8</appversion><state/></root>",
      "<root status_code='200'><currentgame>2</currentgame>"
      "<PairStatus>bogus</PairStatus><appversion>8</appversion>"
      "<state>MJOLNIR_SERVER_BUSY</state></root>",
      /* An invalid advertised port and a malformed display-mode list. */
      "<root status_code='200'><currentgame>2</currentgame>"
      "<PairStatus>1</PairStatus><appversion>8</appversion>"
      "<state>MJOLNIR_SERVER_BUSY</state><HttpsPort>70000</HttpsPort></root>",
      "<root status_code='200'><currentgame>2</currentgame>"
      "<PairStatus>1</PairStatus><appversion>8</appversion>"
      "<state>MJOLNIR_SERVER_BUSY</state><DisplayMode>"
      "<Width>1920</Width><Height>1080</Height></DisplayMode></root>"
  };
  for (unsigned i = 0; i < sizeof(bad_responses) / sizeof(bad_responses[0]); ++i) {
    fixture_reply = bad_responses[i];
    assert(load_serverinfo(&server, true) == GS_INVALID);
    assert_server_state(&server);
  }
  fixture_transport_result = GS_IO_ERROR;
  fixture_reply = valid;
  assert(load_serverinfo(&server, true) == GS_IO_ERROR);
  fixture_transport_result = GS_OK;
  assert_server_state(&server);

  /* Valid second fetch replaces all old owned fields and decoder modes. */
  fixture_reply =
      "<root status_code='200'><currentgame>0</currentgame>"
      "<PairStatus>0</PairStatus><appversion>8.0.0</appversion>"
      "<state>IDLE</state><gputype>GPU-B</gputype>"
      "<GsVersion>8</GsVersion><GfeVersion>8</GfeVersion>"
      "<HttpsPort>50001</HttpsPort>"
      "<DisplayMode><Width>1280</Width><Height>720</Height>"
      "<RefreshRate>120</RefreshRate></DisplayMode></root>";
  assert(load_serverinfo(&server, true) == GS_OK);
  assert(server.serverMajorVersion == 8 && !server.paired);
  assert(server.currentGame == 0 && server.httpsPort == 50001);
  assert(!strcmp(server.gpuType, "GPU-B"));
  assert(server.modes && server.modes->width == 1280 && !server.modes->next);

  free((char *)server.serverInfo.serverInfoAppVersion);
  free((char *)server.serverInfo.serverInfoGfeVersion);
  free(server.gpuType);
  free(server.gsVersion);
  free_display_modes(server.modes);
}

static void check_applist_status(void) {
  SERVER_DATA server = new_server();
  const char *replies[] = {
      "<root status_code='200'><App><ID>12</ID><AppTitle>Desktop</AppTitle></App></root>",
      "<root><App><ID>12</ID><AppTitle>Desktop</AppTitle></App></root>",
      "<root status_code='200no'><App><ID>12</ID><AppTitle>Desktop</AppTitle></App></root>",
      "<root status_code='403'><App><ID>12</ID><AppTitle>Desktop</AppTitle></App></root>"
  };
  const int expected[] = {GS_OK, GS_INVALID, GS_INVALID, GS_ERROR};
  for (unsigned i = 0; i < sizeof(replies)/sizeof(replies[0]); ++i) {
    fixture_reply = replies[i];
    PAPP_LIST list = NULL;
    int rc = gs_applist(&server, &list);
    assert(rc == expected[i]);
    if (rc == GS_OK) {
      assert(list && list->id == 12 && strcmp(list->name, "Desktop") == 0);
      xml_free_applist(list);
    } else {
      assert(list == NULL);
    }
  }
  fixture_transport_result = GS_OUT_OF_MEMORY;
  fixture_reply = replies[0];
  PAPP_LIST list = NULL;
  assert(gs_applist(&server, &list) == GS_OUT_OF_MEMORY);
  assert(list == NULL);
  fixture_transport_result = GS_OK;
}

static void check_conflicting_app_is_never_resumed(void) {
  SERVER_DATA server = new_server();
  STREAM_CONFIGURATION config = {0};
  config.width = 1920; config.height = 1080; config.fps = 60;
  server.currentGame = 9;
  snprintf(last_request, sizeof(last_request), "untouched");
  fixture_reply = "<root status_code='200'><resume>1</resume></root>";
  assert(gs_start_app(&server, &config, 12, false, false, 0) == GS_WRONG_STATE);
  assert(server.currentGame == 9);
  assert(strcmp(last_request, "untouched") == 0);
  assert(gs_error && strstr(gs_error, "Another Sunshine application"));
}

static void check_launch_resume_values(void) {
  SERVER_DATA server = new_server();
  STREAM_CONFIGURATION config = {0};
  config.width = 1920;
  config.height = 1080;
  config.fps = 60;
  /* Unspecified audio configuration is sufficient for this HTTP contract
   * test; no streaming connection or codec is initialized. */
  const char *replies[] = {
      "<root status_code='200'><gamesession>1</gamesession></root>",
      "<root status_code='200'><resume>1</resume></root>",
      "<root status_code='200'><gamesession>0</gamesession></root>",
      "<root status_code='200'><resume>0</resume></root>",
      "<root status_code='200'/>",
      "<root status_code='200'><gamesession/></root>",
      "<root status_code='200'><gamesession>42</gamesession></root>",
      "<root><gamesession>1</gamesession></root>"
  };
  const int expected[] = {
      GS_OK, GS_OK, GS_FAILED, GS_FAILED,
      GS_INVALID, GS_INVALID, GS_INVALID, GS_INVALID
  };
  for (unsigned i = 0; i < sizeof(replies)/sizeof(replies[0]); ++i) {
    server.currentGame = i == 1 || i == 3 ? 12 : 0;
    const int previous = server.currentGame;
    fixture_reply = replies[i];
    int rc = gs_start_app(&server, &config, 12, false, false, 0);
    assert(rc == expected[i]);
    if (rc == GS_OK)
      assert(server.currentGame == 12);
    else
      assert(server.currentGame == previous);
    if (i == 1 || i == 3)
      assert(strstr(last_request, "/resume?") != NULL);
    else
      assert(strstr(last_request, "/launch?") != NULL);
  }
}


/* A host-side launch cannot be rolled back by a malformed optional RTSP
 * field. Exercise the production parser's 2 MiB field-size limit. */
static void check_accepted_launch_with_oversized_optional_url(void) {
  const char prefix[] =
      "<root status_code='200'><gamesession>1</gamesession><sessionUrl0>";
  const char suffix[] = "</sessionUrl0></root>";
  const size_t payload_size = 2U * 1024U * 1024U + 16;
  const size_t total = sizeof(prefix) - 1 + payload_size + sizeof(suffix);
  char *xml = malloc(total);
  assert(xml);
  memcpy(xml, prefix, sizeof(prefix) - 1);
  memset(xml + sizeof(prefix) - 1, 'x', payload_size);
  memcpy(xml + sizeof(prefix) - 1 + payload_size, suffix, sizeof(suffix));
  SERVER_DATA server = new_server();
  STREAM_CONFIGURATION config = {0};
  config.width = 1920;
  config.height = 1080;
  config.fps = 60;
  server.serverInfo.rtspSessionUrl = strdup("rtsp://stale-previous-session");
  assert(server.serverInfo.rtspSessionUrl);
  fixture_reply = xml;
  assert(gs_start_app(&server, &config, 12, false, false, 0) == GS_OK);
  assert(server.currentGame == 12);
  assert(server.serverInfo.rtspSessionUrl == NULL);
  fixture_reply = NULL;
  free(xml);
}

static void check_optional_rtsp_url_replaces_previous_session(void) {
  SERVER_DATA server = new_server();
  STREAM_CONFIGURATION config = {0};
  config.width = 1920; config.height = 1080; config.fps = 60;
  server.serverInfo.rtspSessionUrl = strdup("rtsp://old");
  assert(server.serverInfo.rtspSessionUrl);
  fixture_reply = "<root status_code='200'><gamesession>1</gamesession>"
                  "<sessionUrl0>rtsp://new-session</sessionUrl0></root>";
  assert(gs_start_app(&server, &config, 12, false, false, 0) == GS_OK);
  assert(server.currentGame == 12);
  assert(server.serverInfo.rtspSessionUrl &&
         strcmp(server.serverInfo.rtspSessionUrl, "rtsp://new-session") == 0);
  free((char *)server.serverInfo.rtspSessionUrl);
}

/* Mock Vibepollo/Sunshine launch responses, but execute the real production
 * gs_start_app() HTTP/XML handling, post-launch snapshot and both connection
 * dispatch paths. This fails on the November 2 early-copy regression when
 * paired with the source-order guard in test_gamestream_url_wiring.py.
 * No TCP socket, display driver or native ARM32 compilation is required. */
static void check_real_rtsp_handoff_with_mock_host(void) {
  struct handoff_case {
    const char *response;
    const char *rtsp_url;
    bool resume;
    bool encrypted;
    bool accepted;
  };
  const struct handoff_case cases[] = {
    {
      "<root status_code='200'><gamesession>1</gamesession>"
      "<sessionUrl0>rtspenc://[2001:db8::1]:48010</sessionUrl0></root>",
      "rtspenc://[2001:db8::1]:48010", false, true, true
    },
    {
      "<root status_code='200'><gamesession>1</gamesession>"
      "<sessionUrl0>rtsp://[2001:db8::1]:48010</sessionUrl0></root>",
      "rtsp://[2001:db8::1]:48010", false, false, true
    },
    {
      "<root status_code='200'><resume>1</resume>"
      "<sessionUrl0>rtspenc://[2001:db8::1]:48011</sessionUrl0></root>",
      "rtspenc://[2001:db8::1]:48011", true, true, true
    },
    {
      "<root status_code='200'><resume>1</resume>"
      "<sessionUrl0>rtsp://[2001:db8::1]:48012</sessionUrl0></root>",
      "rtsp://[2001:db8::1]:48012", true, false, true
    },
    {
      "<root status_code='200'><gamesession>1</gamesession></root>",
      NULL, false, false, true
    },
    {
      "<root status_code='200'><gamesession>1</gamesession>"
      "<sessionUrl0></sessionUrl0></root>",
      NULL, false, false, true
    },
    {
      "<root status_code='200'><gamesession>1</gamesession>"
      "<sessionUrl0>rtspenc://[2001:db8::1]:48010",
      NULL, false, false, false /* Malformed XML must not start RTSP. */
    },
  };

  for (size_t c = 0; c < sizeof(cases) / sizeof(cases[0]); ++c) {
    SERVER_DATA server = new_server();
    server.serverInfo.address = "[2001:db8::1]";
    server.currentGame = cases[c].resume ? 12 : 0;
    STREAM_CONFIGURATION config = {0};
    config.width = 1920;
    config.height = 1080;
    config.fps = 60;
    char transport_address[MOONLIGHT_URL_HOST_CAP];
    assert(moonlight_transport_host(server.serverInfo.address,
                                   transport_address,
                                   sizeof(transport_address)));
    assert(strcmp(transport_address, "2001:db8::1") == 0);

    /* The pre-launch copy has no RTSP URL, reproducing the stale state. */
    SERVER_INFORMATION stale = moonlight_stream_rtsp_snapshot(
        &server.serverInfo, transport_address);
    assert(stale.rtspSessionUrl == NULL);

    fixture_reply = cases[c].response;
    const int result = gs_start_app(&server, &config, 12, false, false, 0);
    if (!cases[c].accepted) {
      assert(result == GS_INVALID);
      assert(server.serverInfo.rtspSessionUrl == NULL);
      continue;
    }
    assert(result == GS_OK);
    assert(server.currentGame == 12);
    assert(strcmp(server.serverInfo.address, "[2001:db8::1]") == 0);
    assert(strstr(last_request, cases[c].resume ? "/resume?" : "/launch?"));

    /* The production handoff helper reads the UPDATED serverinfo. */
    SERVER_INFORMATION fresh = moonlight_stream_rtsp_snapshot(
        &server.serverInfo, transport_address);
    assert(fresh.rtspSessionUrl == server.serverInfo.rtspSessionUrl);
    expected_rtsp_url = cases[c].rtsp_url;
    expected_socket_host = "2001:db8::1";
    expected_encrypted_rtsp = cases[c].encrypted;
    const int normal_before = normal_connections;
    const int steam_before = steam_connections;
    for (int embedded = 0; embedded < 2; ++embedded) {
      assert(moonlight_stream_connect_with_snapshot(
          &fresh, embedded != 0, &config, NULL, NULL, NULL, 0, NULL,
          NULL, NULL, NULL) == 0);
    }
    assert(normal_connections == normal_before + 1);
    assert(steam_connections == steam_before + 1);
    free((char *)server.serverInfo.rtspSessionUrl);
  }
}

static void check_quit_values(void) {
  SERVER_DATA server = new_server();
  const char *replies[] = {
      "<root status_code='200'><cancel>1</cancel></root>",
      "<root status_code='200'><cancel>0</cancel></root>",
      "<root status_code='200'/>",
      "<root status_code='200'><cancel/></root>",
      "<root status_code='200'><cancel>maybe</cancel></root>",
      "<root><cancel>1</cancel></root>"
  };
  const int expected[] = {
      GS_OK, GS_FAILED, GS_INVALID, GS_INVALID, GS_INVALID, GS_INVALID
  };
  for (unsigned i = 0; i < sizeof(replies)/sizeof(replies[0]); ++i) {
    fixture_reply = replies[i];
    assert(gs_quit_app(&server) == expected[i]);
    assert(strstr(last_request, "/cancel?") != NULL);
  }
}

/* Real production URL builders must emit RFC 3986 bracketed IPv6 URLs for
 * status, app list, launch/resume, cancel and unpair on the wire. The pairing
 * handshake itself is checked by the separate source guard (no live PIN). */
static void check_ipv6_request_urls(void) {
  const struct {
    const char *input;
    const char *authority;
  } cases[] = {
    {"192.0.2.10", "192.0.2.10"},
    {"2001:db8::1234", "[2001:db8::1234]"},
    {"[2001:db8::1234]", "[2001:db8::1234]"},
    {"fe80::1234%eth0", "[fe80::1234%25eth0]"}
  };
  const char *serverinfo =
      "<root status_code='200'><currentgame>0</currentgame>"
      "<PairStatus>1</PairStatus><appversion>7.1.0.0</appversion>"
      "<state>IDLE</state><ServerCodecModeSupport>1</ServerCodecModeSupport>"
      "<gputype>GPU</gputype><GsVersion>7</GsVersion>"
      "<GfeVersion>7</GfeVersion><HttpsPort>47984</HttpsPort></root>";
  char prefix[256];
  for (unsigned i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    SERVER_DATA server = new_server();
    server.serverInfo.address = (char *)cases[i].input;
    fixture_reply = serverinfo;
    assert(load_serverinfo(&server, false) == GS_OK);
    snprintf(prefix, sizeof(prefix), "http://%s:47989/serverinfo?",
             cases[i].authority);
    assert(strncmp(last_request, prefix, strlen(prefix)) == 0);

    fixture_reply = "<root status_code='200'><App><ID>12</ID>"
                    "<AppTitle>Desktop</AppTitle></App></root>";
    PAPP_LIST list = NULL;
    assert(gs_applist(&server, &list) == GS_OK);
    snprintf(prefix, sizeof(prefix), "https://%s:47984/applist?",
             cases[i].authority);
    assert(strncmp(last_request, prefix, strlen(prefix)) == 0);
    xml_free_applist(list);

    STREAM_CONFIGURATION config = {0};
    config.width = 1920; config.height = 1080; config.fps = 60;
    fixture_reply = "<root status_code='200'><gamesession>1</gamesession></root>";
    assert(gs_start_app(&server, &config, 12, false, false, 0) == GS_OK);
    snprintf(prefix, sizeof(prefix), "https://%s:47984/launch?",
             cases[i].authority);
    assert(strncmp(last_request, prefix, strlen(prefix)) == 0);

    fixture_reply = "<root status_code='200'><resume>1</resume></root>";
    assert(gs_start_app(&server, &config, 12, false, false, 0) == GS_OK);
    snprintf(prefix, sizeof(prefix), "https://%s:47984/resume?",
             cases[i].authority);
    assert(strncmp(last_request, prefix, strlen(prefix)) == 0);

    fixture_reply = "<root status_code='200'><cancel>1</cancel></root>";
    assert(gs_quit_app(&server) == GS_OK);
    snprintf(prefix, sizeof(prefix), "https://%s:47984/cancel?",
             cases[i].authority);
    assert(strncmp(last_request, prefix, strlen(prefix)) == 0);

    fixture_reply = "<root status_code='200'/>";
    assert(gs_unpair(&server) == GS_OK);
    snprintf(prefix, sizeof(prefix), "http://%s:47989/unpair?",
             cases[i].authority);
    assert(strncmp(last_request, prefix, strlen(prefix)) == 0);

    free((char *)server.serverInfo.serverInfoAppVersion);
    free((char *)server.serverInfo.serverInfoGfeVersion);
    free(server.gpuType);
    free(server.gsVersion);
    free_display_modes(server.modes);
    free((char *)server.serverInfo.rtspSessionUrl);
  }
}

/* GameStream display-mode entries use unsigned dimensions, but stream
 * requests are signed. A negative request must never wrap around when it is
 * compared against the host-advertised mode. */
static void check_invalid_signed_dimensions_are_rejected(void) {
  SERVER_DATA server = new_server();
  DISPLAY_MODE advertised = {0};
  advertised.width = 1920;
  advertised.height = 1080;
  advertised.refresh = 60;
  server.modes = &advertised;
  server.unsupported = false;
  STREAM_CONFIGURATION requested = {0};
  requested.width = 1920;
  requested.height = 1080;
  requested.fps = 60;
  fixture_reply = "<root status_code='200'><gamesession>1</gamesession></root>";
  requested.width = -1;
  assert(gs_start_app(&server, &requested, 12, false, false, 0) ==
         GS_NOT_SUPPORTED_MODE);
  requested.width = 1920;
  requested.height = -1;
  assert(gs_start_app(&server, &requested, 12, false, false, 0) ==
         GS_NOT_SUPPORTED_MODE);
  requested.height = 1080;
  requested.fps = -1;
  assert(gs_start_app(&server, &requested, 12, false, false, 0) ==
         GS_NOT_SUPPORTED_MODE);
  requested.fps = 60;
  requested.width = 0;
  assert(gs_start_app(&server, &requested, 12, false, false, 0) ==
         GS_NOT_SUPPORTED_MODE);
}

int main(void) {
  check_server_init_ownership();
  check_server_info_status();
  check_serverinfo_staged_commit();
  check_applist_status();
  check_launch_resume_values();
  check_conflicting_app_is_never_resumed();
  check_accepted_launch_with_oversized_optional_url();
  check_optional_rtsp_url_replaces_previous_session();
  check_real_rtsp_handoff_with_mock_host();
  check_quit_values();
  check_ipv6_request_urls();
  check_invalid_signed_dimensions_are_rejected();
  puts("PASS: GameStream response status and required session fields");
  return 0;
}
