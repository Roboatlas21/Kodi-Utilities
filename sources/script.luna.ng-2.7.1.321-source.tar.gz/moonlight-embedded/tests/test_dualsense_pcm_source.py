# SPDX-License-Identifier: GPL-3.0-or-later
"""No workflow needed: guard controller PCM integration and lifetime ordering."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def src(path):
    return (ROOT / path).read_text()

main = src("src/main.c")
handoff = src("src/stream_rtsp_handoff.h")
evdev = src("src/input/evdev.c")
dualsense = src("src/input/dualsense.c")
pcm = src("src/input/dualsense_pcm.c")
cmake = src("CMakeLists.txt")
module = src(".gitmodules")
assert "Nonary/moonlight-common-c.git" in module
# The RTSP handoff helper now owns the native connection calls. Validate
# both normal and embedded routes and their original controller callbacks.
assert '#include "stream_rtsp_handoff.h"' in main
assert "moonlight_stream_rtsp_snapshot(&server->serverInfo, transport_address)" in main
assert "moonlight_stream_connect_with_snapshot(" in main
assert "return LiStartConnectionWithSteamController(" in handoff
assert "return LiStartConnection(" in handoff
assert "IS_EMBEDDED(system) ? evdev_receive_haptics : NULL;" in main
assert "config->audio_device, evdev_receive_speaker," in main
assert "sc26_haptic_host, sc26_settings_host);" in main
assert "speaker, steam_haptic, steam_settings);" in handoff
assert "LiSendControllerSpeakerArrivalEvent" in evdev
assert "dualsense_speaker_owner" in evdev
assert "if(speaker)LiSendControllerSpeakerArrivalEvent" in evdev
assert "dualsense_waveform_active" in evdev
assert "dualsense_receive_haptics" in evdev
assert "dualsense_receive_speaker" in evdev
assert "ml_ds_audio_haptics_ready(d->audio)" in dualsense
assert "ml_ds_audio_speaker_ready(d->audio)" in dualsense
assert "ml_ds_audio_close(d->audio)" in dualsense
assert dualsense.index("ml_ds_audio_close(d->audio)") < dualsense.index("if (d->fd >= 0) close(d->fd)")
assert "same physical Sony device" in pcm
assert "strcmp(candidate, usb_path)" in pcm
assert "SND_PCM_NONBLOCK" in pcm
assert '#include "saxense_hid_write.h"' in pcm
assert "ml_sax_hid_write_bounded(&sax_hid_ops, a->bt_fd," in pcm
assert "sax_chunk_ready(a) == ML_SAX_CHUNK_WAIT" in pcm
assert "next == ML_SAX_CHUNK_FULL || next == ML_SAX_CHUNK_TAIL" in pcm
assert "ring_take(&a->actuator, chunk, ML_SAX_SOURCE_FRAMES)" in pcm
assert "ml_sax_next_chunk" in src("src/input/saxense_packet.h")
assert '#include "../audio/alsa_bounded_write.h"' in pcm
assert '#include "../audio/alsa_suspend_recovery.h"' in pcm
assert "if (error == -EINTR) return 0;" in pcm
assert "alsa_recover_bounded(&ds_usb_recovery_ops, ctx, error)" in pcm
assert "alsa_bounded_write(" in pcm
assert "&ds_usb_pcm_ops, a->usb_pcm, out, frames," in pcm
assert "sizeof(out[0]) * 4u" in pcm
assert "result.recovery_attempts == result.successful_recoveries" in pcm
assert "ML_DS_RING_FRAMES" in pcm
assert "frames > ML_HAPTICS_MAX_FRAMES" in pcm
assert "frames > ML_SPEAKER_PCM_MAX_FRAMES" in pcm
assert "pthread_join" in pcm
assert "src/input/dualsense_pcm.c" in cmake
assert "MOONLIGHT_DUALSENSE_HID" in dualsense
assert 'id="dualsense_hid"' not in src("docs/dualsense-coreelec-ng.md")
print("PASS: controller PCM feature gating and old input-path safety contracts")
