"""Optional VFM bundle validation. No Kodi imports and no device mutations."""
import hashlib
import fcntl
import json
import os
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import stat
import tempfile

if '_LUNA_VERIFIED_READERS' in globals():
    # The release packager injects reader functions loaded from the SAME
    # committed source snapshot. Never import mutable worktree helpers.
    read_regular_bytes, read_bounded_json = _LUNA_VERIFIED_READERS
elif __package__:
    from resources.lib.util.safefile import read_regular_bytes
    from resources.lib.util.safejson import read_bounded_json
else:
    try:
        from safefile import read_regular_bytes
        from safejson import read_bounded_json
    except ModuleNotFoundError:
        from resources.lib.util.safefile import read_regular_bytes
        from resources.lib.util.safejson import read_bounded_json


# Explicit total budget for immutable VFM runtime bytes retained by the packager.
# Normal CoreELEC NG libraries and modules are far below 256 MiB.
MAX_VERIFIED_BUNDLE_BYTES = 256 * 1024 * 1024


class VfmRuntimeError(RuntimeError):
    pass


def verify_bundle(directory, kernel_release=None, collect_bytes=False):
    root = Path(directory)
    try:
        manifest_path = root / 'manifest.json'
        if collect_bytes:
            manifest, _manifest_stat, manifest_raw = read_bounded_json(
                manifest_path, 65536, with_bytes=True)
            verified_files = {'manifest.json': manifest_raw}
        else:
            manifest = read_bounded_json(manifest_path, 65536)
        if not isinstance(manifest, dict) or manifest.get('schema') != 'luna-ng-vfm-v1':
            raise VfmRuntimeError('Unsupported experimental pipeline bundle')
        if manifest.get('bridge_version') != '6':
            raise VfmRuntimeError('This VFM bundle needs bridge version 6. Install a complete '
                                  'updated add-on; rebooting cannot update the bundled driver.')
        release = manifest.get('kernel_release', '')
        if not isinstance(release, str) or not re.fullmatch(r'[A-Za-z0-9._+-]+', release):
            raise VfmRuntimeError('Invalid kernel release in experimental bundle')
        if kernel_release is not None and release != kernel_release:
            raise VfmRuntimeError('Experimental drivers are built for %s, running %s' %
                                  (release, kernel_release))
        objects = manifest.get('objects')
        order = manifest.get('module_order')
        if manifest.get('decoder_version') != 'moonlight-hdr1':
            raise VfmRuntimeError('Incomplete VFM runtime: native HDR decoder support is missing')
        if not isinstance(objects, dict) or not objects or len(objects) > 64:
            raise VfmRuntimeError('Invalid experimental file list')
        if (not isinstance(order, list) or not order or
                any(not isinstance(n, str) or not re.fullmatch(r'[A-Za-z0-9_]+\.ko', n)
                    for n in order) or len(order) != len(set(order)) or
                order[-1] != 'moonlight_vfm.ko' or 'amvdec_ports.ko' not in order):
            raise VfmRuntimeError('Invalid experimental module load order')
        modules = {'modules/%s/%s' % (release, n) for n in order}
        libraries = set(objects) - modules
        if ('lib/libmoonlight-aml-vfm.so' not in libraries or
                not any(re.fullmatch(r'lib/libavcodec\.so\.\d+', n) for n in libraries) or
                not any(re.fullmatch(r'lib/libavutil\.so\.\d+', n) for n in libraries) or
                any(not re.fullmatch(
                    r'lib/(libmoonlight-aml-vfm\.so|libavcodec\.so\.\d+|libavutil\.so\.\d+|libdrm\.so\.2)', n)
                    for n in libraries) or not modules <= set(objects)):
            raise VfmRuntimeError('Missing or unexpected experimental libraries/modules')
        # Reject over-budget manifests before reading any large ELF objects.
        # A per-file 64 MiB cap alone permits a multi-gigabyte bundle.
        total = len(manifest_raw) if collect_bytes else 0
        for entry in objects.values():
            size = entry.get('size') if isinstance(entry, dict) else None
            if (type(size) is not int or size < 20 or size > 64 * 1024 * 1024):
                raise VfmRuntimeError('Invalid experimental file size')
            total += size
            if total > MAX_VERIFIED_BUNDLE_BYTES:
                raise VfmRuntimeError('Experimental VFM bundle exceeds aggregate size limit')
        for name, entry in objects.items():
            rel = PurePosixPath(name)
            if rel.is_absolute() or '..' in rel.parts or not isinstance(entry, dict):
                raise VfmRuntimeError('Unsafe experimental file path')
            path = root.joinpath(*rel.parts)
            if any(p.is_symlink() for p in [root, path, *path.parents] if p != p.parent):
                raise VfmRuntimeError('Experimental bundle contains a symlink')
            data, _metadata = read_regular_bytes(path, 64 * 1024 * 1024)
            if not 20 <= len(data) <= 64 * 1024 * 1024:
                raise VfmRuntimeError('Missing or oversized experimental file: ' + name)
            if collect_bytes:
                verified_files[name] = data
            if (entry.get('size') != len(data) or
                    entry.get('sha256') != hashlib.sha256(data).hexdigest()):
                raise VfmRuntimeError('Experimental file checksum mismatch: ' + name)
            if (name == 'lib/libmoonlight-aml-vfm.so' and
                    b'MOONLIGHT_VIDEO_READY_FILE' not in data):
                raise VfmRuntimeError(
                    'Experimental VFM library lacks native first-video-ready-v1 support')
            elf_class, machine, kind = (2, 183, 1) if name in modules else (1, 40, 3)
            if (data[:6] != b'\x7fELF' + bytes([elf_class, 1]) or
                    struct.unpack_from('<HH', data, 16) != (kind, machine)):
                raise VfmRuntimeError('Wrong ELF architecture/type: ' + name)
        return (manifest, verified_files) if collect_bytes else manifest
    except (OSError, ValueError, TypeError, struct.error) as error:
        raise VfmRuntimeError('Incomplete experimental pipeline bundle: %s' % error) from error


def check_runtime(addon_path, executable, env):
    """Verify optional files and FFmpeg capabilities before stopping Kodi."""
    root = Path(addon_path) / 'vfm'
    manifest = verify_bundle(root, os.uname().release)
    check_loaded_bridge(root / 'modules' / manifest['kernel_release'] / 'moonlight_vfm.ko')
    # A loaded, verified stock decoder is mandatory BEFORE Kodi is stopped.
    # A prior VFM session may have left patched modules with no rollback
    # journal; do not take ownership of that unprovable state.
    try:
        prepare_hdr_decoder(root / 'modules' / manifest['kernel_release'] / 'amvdec_ports.ko')
    except (OSError, subprocess.SubprocessError) as error:
        raise VfmRuntimeError(
            'Cannot verify a safe stock decoder rollback before stopping Kodi: %s'
            % error) from error
    # Resident dependencies must be compatible BEFORE stopping Kodi. A
    # module appearing between this preflight and launch is checked again.
    for filename in manifest['module_order']:
        name = filename[:-3]
        if name in ('amvdec_ports', 'moonlight_vfm'):
            continue
        if (Path('/sys/module') / name).exists():
            _verify_resident_vfm_dependency(
                name, root / 'modules' / manifest['kernel_release'] / filename)
    try:
        result = subprocess.run(
            [executable, 'check-vfm'], env=env, cwd=str(Path(executable).parent),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=8, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise VfmRuntimeError('Experimental pipeline library check failed') from error
    if result.returncode or 'AML-VFM userspace dependencies ready' not in result.stdout:
        raise VfmRuntimeError('This Moonlight/FFmpeg build lacks the experimental VFM pipeline. '
                              'Select the standard Amlogic pipeline.')


def check_loaded_bridge(bundle_module=None, *, during_session=False):
    """Distinguish unowned preflight state from the bridge this session loaded.

    Callers MAY accept a resident bridge only after load_modules() has
    durably journaled the original decoder and installed the matching bundle.
    All preflight calls reject any pre-existing VFM bridge, including one
    with a matching version/srcversion, because it lacks rollback ownership.
    """
    if during_session and bundle_module is None:
        raise VfmRuntimeError('Session bridge verification requires its pinned module')
    bridge = Path('/sys/module/moonlight_vfm')
    if not bridge.exists():
        if during_session:
            raise VfmRuntimeError('Session VFM bridge is missing after module installation')
        return
    version = bridge / 'version'
    try:
        loaded_version = version.read_text().strip()
    except OSError as error:
        raise VfmRuntimeError('Cannot read the loaded VFM bridge version') from error
    if loaded_version != '6':
        raise VfmRuntimeError('An older VFM bridge is still loaded. Reboot CoreELEC once '
                              'after this add-on update, then retry VFM.')
    if during_session:
        # This call is only reached after a successful insmod of the exact,
        # SHA-256-verified bundle with a durable original-decoder journal.
        # CoreELEC 21 may omit Kbuild srcversion even for a newly loaded
        # module; that metadata is mandatory for REUSE, but cannot be made
        # mandatory for a directly owned installation.
        bundled_version = _module_info('version', bundle_module)
        if bundled_version != loaded_version:
            raise VfmRuntimeError('New VFM bridge version differs from bundled module')
        expected_src = _module_info('srcversion', bundle_module)
        loaded_src_file = bridge / 'srcversion'
        loaded_src = (loaded_src_file.read_text().strip()
                      if loaded_src_file.is_file() else '')
        # Compare source identity whenever the kernel publishes it. Missing
        # loaded srcversion after a fresh insmod is safe only because this
        # exact invocation owns the installation and rollback journal.
        if loaded_src and loaded_src != expected_src:
            raise VfmRuntimeError('New VFM bridge source version differs from bundle')
    else:
        if bundle_module is not None:
            _check_loaded_module_build('moonlight_vfm', bundle_module)
        raise VfmRuntimeError(
            'A VFM bridge is already resident without an active recovery '
            'journal. Reboot CoreELEC to restore stock playback before VFM.')


def _module_info(field, target):
    result = subprocess.run(
        ['modinfo', '-F', field, str(target)], stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, timeout=5, check=True)
    return result.stdout.strip()


def _loaded_module_version(name):
    root = Path('/sys/module') / name
    if not root.exists():
        return None
    version = root / 'version'
    return version.read_text().strip() if version.is_file() else ''


def _check_loaded_module_build(name, bundle_module, sys_module_root='/sys/module'):
    """Fail closed on stale same-version modules left resident after a build.

    Linux 4.9 exposes the loaded module's Kbuild srcversion in sysfs when
    supported. It must match the exact bundled module, not only VERSION.
    If this kernel does not expose a comparable identity, a reboot is needed
    before reusing the already-loaded experimental module; never silently
    combine a new userspace package with an unverified resident module.
    """
    try:
        expected = _module_info('srcversion', bundle_module)
        loaded = Path(sys_module_root) / name / 'srcversion'
        observed = loaded.read_text().strip() if loaded.is_file() else ''
    except (OSError, subprocess.SubprocessError) as error:
        raise VfmRuntimeError(
            'Cannot verify resident %s module build identity. Reboot CoreELEC '
            'before using this updated VFM bundle.' % name) from error
    if not expected or not observed or observed != expected:
        raise VfmRuntimeError(
            'Resident %s module build identity is missing or differs from '
            'the bundle. Reboot CoreELEC before using this VFM build.' % name)



# Only these stock CoreELEC dependencies can be reused when already resident.
# Luna still installs its own patched decoder and VFM bridge under a durable
# rollback journal. This allowlist follows the pinned VFM module dependency
# closure and must be reviewed when that closure changes.
REUSABLE_VFM_DEPENDENCIES = frozenset((
    'media', 'videodev', 'media_clock', 'firmware',
    'video_framerate_adapter', 'decoder_common',
    'videobuf2_core', 'videobuf2_v4l2', 'v4l2_mem2mem',
    'stream_input', 'v4l2_common', 'videobuf2_memops',
    'videobuf2_dma_contig', 'amvdec_mh264', 'amvdec_h265',
))


def _verify_resident_vfm_dependency(name, bundled_module, *,
                                    sys_module_root='/sys/module',
                                    proc_modules='/proc/modules'):
    """Fail closed unless a known resident dependency belongs to this kernel.

    Prefer matching loaded srcversion. CoreELEC 21 sometimes omits that sysfs
    field, so fall back only to the trusted stock module installed for this
    running kernel, with matching modinfo identity. This is a provenance and
    ABI check, not proof of the in-memory bytes on metadata-less Linux 4.9.
    No module is unloaded, replaced, or adopted as Luna's own decoder.
    """
    if name not in REUSABLE_VFM_DEPENDENCIES:
        raise VfmRuntimeError(
            'VFM module %s is already loaded but is not an approved reusable '
            'CoreELEC dependency; refusing unsafe reuse' % name)
    resident = Path(sys_module_root) / name
    if not resident.exists():
        raise VfmRuntimeError('Resident VFM dependency %s disappeared' % name)
    release = os.uname().release
    try:
        if _module_info('vermagic', bundled_module).split()[:1] != [release]:
            raise VfmRuntimeError(
                'Resident VFM dependency %s has a different bundled kernel ABI' % name)
        bundled_name = _module_info('name', bundled_module).replace('-', '_')
        if bundled_name and bundled_name != name:
            raise VfmRuntimeError(
                'VFM dependency %s has a different bundled module name' % name)
        bundled_version = _module_info('version', bundled_module)
        version_file = resident / 'version'
        loaded_version = (version_file.read_text().strip()
                          if version_file.is_file() else None)
        if loaded_version is not None and loaded_version != bundled_version:
            raise VfmRuntimeError(
                'Resident VFM dependency %s version differs from bundle' % name)
        expected_src = _module_info('srcversion', bundled_module)
        source_file = resident / 'srcversion'
        loaded_src = (source_file.read_text().strip()
                      if source_file.is_file() else '')
        if expected_src and loaded_src:
            if expected_src != loaded_src:
                raise VfmRuntimeError(
                    'Resident VFM dependency %s srcversion differs from bundle' % name)
            return 'loaded srcversion'

        # A missing loaded Kbuild identity is not evidence of a match.
        # Use only the CoreELEC 21 stock image for this running kernel.
        if not re.fullmatch(r'4\.9\.\d+(?:[-+][A-Za-z0-9._-]+)?', release):
            raise VfmRuntimeError(
                'Cannot verify metadata-less resident VFM dependency %s '
                'on this kernel' % name)
        installed_name = _module_info('filename', name)
        module_rows = [parts for parts in
                       (line.split() for line in Path(proc_modules).read_text().splitlines())
                       if parts and parts[0] == name]
        if len(module_rows) > 1 or any(
                len(parts) < 5 or parts[4] != 'Live' for parts in module_rows):
            raise VfmRuntimeError(
                'Resident VFM dependency %s is not live in the kernel' % name)
        if installed_name in ('(builtin)', '(built-in)'):
            # A kernel builtin cannot be swapped by insmod and must not
            # appear as a loadable entry in /proc/modules.
            if module_rows or expected_src or loaded_src:
                raise VfmRuntimeError(
                    'Cannot verify builtin VFM dependency %s source' % name)
            return 'kernel builtin'
        stock = Path(installed_name)
        if (not stock.is_absolute() or not _stock_module_path_allowed(stock, release)
                or not stock.is_file() or stock.is_symlink() or not module_rows):
            raise VfmRuntimeError(
                'Resident VFM dependency %s has no trusted stock module' % name)
        metadata = stock.stat()
        if (not stat.S_ISREG(metadata.st_mode) or
                metadata.st_uid not in (0, os.geteuid()) or
                metadata.st_mode & (stat.S_IWGRP | stat.S_IWOTH)):
            raise VfmRuntimeError(
                'Resident VFM dependency %s stock module is not protected' % name)
        installed_module_name = _module_info('name', stock).replace('-', '_')
        if (installed_module_name not in ('', name) or
                _module_info('vermagic', stock).split()[:1] != [release] or
                _module_info('version', stock) != bundled_version):
            raise VfmRuntimeError(
                'Resident VFM dependency %s stock module ABI differs' % name)
        stock_src = _module_info('srcversion', stock)
        if (expected_src != stock_src or
                (loaded_src and loaded_src != stock_src)):
            raise VfmRuntimeError(
                'Resident VFM dependency %s stock source differs from bundle' % name)
        return 'trusted CoreELEC stock module'
    except (OSError, subprocess.SubprocessError, ValueError) as error:
        raise VfmRuntimeError(
            'Cannot verify resident VFM dependency %s: %s' % (name, error)
        ) from error


def _stock_module_roots(release):
    """The same kernel-matched root allowlist applies before/after a swap."""
    return (Path('/lib/modules') / release,
            Path('/usr/lib/modules') / release,
            Path('/usr/lib/kernel-overlays/base/lib/modules') / release)


def _stock_module_path_allowed(candidate, release):
    resolved = Path(candidate).resolve()
    for root in _stock_module_roots(release):
        trusted = root.resolve()
        if os.path.commonpath((str(trusted), str(resolved))) == str(trusted):
            return True
    return False


def _stock_decoder_module(loaded_version=None):
    """Find a kernel- and source-matched stock decoder before an unload."""
    release = os.uname().release
    dirs = _stock_module_roots(release)
    choices = []
    result = subprocess.run(
        ['modinfo', '-n', 'amvdec_ports'], stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, timeout=5, check=False)
    if result.returncode == 0 and result.stdout.strip().startswith('/'):
        choices.append(Path(result.stdout.strip()))
    for root in dirs:
        if root.is_dir():
            choices.extend(sorted(root.rglob('amvdec_ports.ko')))
    seen = set()
    current_src = Path('/sys/module/amvdec_ports/srcversion')
    expected_src = current_src.read_text().strip() if current_src.is_file() else ''
    for candidate in choices:
        if not candidate.is_file():
            continue
        path = candidate.resolve()
        if not _stock_module_path_allowed(path, release):
            continue
        if path in seen:
            continue
        seen.add(path)
        try:
            if _module_info('vermagic', path).split()[:1] != [release]:
                continue
            candidate_version = _module_info('version', path)
            if (candidate_version == 'moonlight-hdr1' or
                    (loaded_version is not None and candidate_version != loaded_version)):
                continue
            actual_src = _module_info('srcversion', path)
            if expected_src and expected_src != actual_src:
                continue
        except (OSError, subprocess.SubprocessError):
            continue
        return path
    raise VfmRuntimeError(
        'Cannot find an installed stock amvdec_ports.ko that can be restored. '
        'Leaving the original decoder loaded; VFM was not started.')


def _coreelec21_metadata_less_stock(stock_path, sys_module_root='/sys/module',
                                    proc_modules='/proc/modules',
                                    require_loaded=True):
    """Narrow fallback for CoreELEC 21's unversioned stock AML decoder.

    The kernel provides no loaded-image hash when MODULE_VERSION and
    srcversion are both absent, so this is *provenance and state validation*,
    not proof of loaded byte identity. Never use it for patched modules or
    non-4.9 kernels. A journal still binds the original file hash and boot.
    """
    release = os.uname().release
    path = Path(stock_path).resolve()
    if (not re.fullmatch(r'4\.9\.\d+(?:[-+][A-Za-z0-9._-]+)?', release) or
            path.name != 'amvdec_ports.ko' or
            path.parent.name != 'media_modules-aml' or
            not _stock_module_path_allowed(path, release) or
            not path.is_file() or path.is_symlink()):
        raise VfmRuntimeError('Untrusted metadata-less stock decoder; recovery retained')
    metadata = path.stat()
    if (not stat.S_ISREG(metadata.st_mode) or
            metadata.st_uid not in (0, os.geteuid()) or
            metadata.st_mode & (stat.S_IWGRP | stat.S_IWOTH)):
        raise VfmRuntimeError('Unsafe stock decoder ownership or permissions; recovery retained')
    # CoreELEC 21 stock amvdec_ports.ko can omit its modinfo name field.
    # Accept the omission only within the path- and kernel-validated stock fallback.
    if (_module_info('name', path) not in ('', 'amvdec_ports') or
            _module_info('vermagic', path).split()[:1] != [release] or
            _module_info('version', path) or _module_info('srcversion', path)):
        raise VfmRuntimeError('Stock decoder provenance or metadata changed; recovery retained')
    if not require_loaded:
        return
    module = Path(sys_module_root) / 'amvdec_ports'
    try:
        mode = (module / 'parameters' / 'multiplanar').read_text().strip()
    except OSError as error:
        raise VfmRuntimeError('Stock decoder multiplanar unreadable; recovery retained') from error
    if mode not in ('0', '1', 'Y', 'N'):
        raise VfmRuntimeError('Stock decoder multiplanar unavailable; recovery retained')
    if (Path(sys_module_root) / 'moonlight_vfm').exists():
        raise VfmRuntimeError('VFM bridge still loaded during stock verification; recovery retained')
    try:
        lines = Path(proc_modules).read_text().splitlines()
    except OSError as error:
        raise VfmRuntimeError('Cannot read loaded stock decoder modules; recovery retained') from error
    if not any(len(parts) >= 5 and parts[0] == 'amvdec_ports' and
               parts[4] == 'Live' for parts in (line.split() for line in lines)):
        raise VfmRuntimeError('Stock decoder not live in kernel; recovery retained')


def _verify_loaded_stock_decoder(stock_path, version, sys_module_root='/sys/module'):
    """Prefer exact srcversion; use narrow CoreELEC 21 stock checks only
    when BOTH the loaded and trusted file omit srcversion and VERSION.
    """
    if _loaded_module_version('amvdec_ports') != version:
        raise VfmRuntimeError('Stock decoder version differs after rollback; recovery retained')
    try:
        expected = _module_info('srcversion', stock_path)
        loaded = Path(sys_module_root) / 'amvdec_ports' / 'srcversion'
        observed = loaded.read_text().strip() if loaded.is_file() else ''
        if expected and observed and observed == expected:
            return
        if not expected and not observed and version == '':
            _coreelec21_metadata_less_stock(stock_path, sys_module_root)
            return
    except (OSError, subprocess.SubprocessError) as error:
        raise VfmRuntimeError(
            'Cannot verify the resident stock decoder build; recovery retained. '
            'Reboot CoreELEC before using VFM again.') from error
    raise VfmRuntimeError(
        'Stock decoder srcversion missing/mismatched; recovery retained. '
        'Reboot CoreELEC before using VFM again.')


def prepare_hdr_decoder(module):
    """Read-only validation: safe to call before the Kodi handoff."""
    if _module_info('version', module) != 'moonlight-hdr1':
        raise VfmRuntimeError('VFM requires the bundled decoder with native HDR frame ownership support')
    version = _loaded_module_version('amvdec_ports')
    if version is None:
        raise VfmRuntimeError(
            'Stock amvdec_ports is not loaded. Reboot CoreELEC before VFM; '
            'decoder rollback cannot be guaranteed.')
    if version == 'moonlight-hdr1':
        _check_loaded_module_build('amvdec_ports', module)
        raise VfmRuntimeError(
            'A patched decoder is resident without a session rollback '
            'journal. Reboot CoreELEC to restore the stock decoder before VFM.')
    mode = Path('/sys/module/amvdec_ports/parameters/multiplanar').read_text().strip()
    if mode not in ('0', '1', 'N', 'Y'):
        raise VfmRuntimeError('Cannot snapshot the stock decoder multiplanar parameter')
    stock = _stock_decoder_module(version)
    # Refuse an unprovable stock image before Kodi is stopped or a module
    # is unloaded. A future crash must have a verifiable rollback target.
    _verify_loaded_stock_decoder(stock, version)
    return (stock, '1' if mode in ('1', 'Y') else '0', version)


def _verify_stock_multiplanar(original_mode,
                              parameter_path='/sys/module/amvdec_ports/parameters/multiplanar'):
    """Verify the saved global decoder mode before a recovery is disarmed.

    If another owner has changed the mode, do not rewrite it blindly; keep
    the journal so an independent recovery can retry safely.
    """
    if original_mode not in ('0', '1'):
        raise VfmRuntimeError('Invalid saved stock decoder multiplanar mode; recovery retained')
    try:
        observed = Path(parameter_path).read_text().strip()
    except OSError as error:
        raise VfmRuntimeError(
            'Cannot verify stock decoder multiplanar readback; recovery retained'
        ) from error
    normalized = {'Y': '1', '1': '1', 'N': '0', '0': '0'}.get(observed)
    if normalized != original_mode:
        raise VfmRuntimeError(
            'Stock decoder multiplanar mode differs from saved state; recovery retained')


def _restore_stock_decoder(snapshot):
    stock_path, original_mode, original_version = snapshot
    # Validate the rollback image BEFORE unloading the patched decoder.
    # The metadata-less fallback is limited to unversioned CoreELEC 21 stock
    # images; patched modules continue to need explicit build identities.
    try:
        expected_src = _module_info('srcversion', stock_path)
        if not expected_src:
            if original_version != '':
                raise VfmRuntimeError('Stock decoder lacks a source identity; recovery retained')
            _coreelec21_metadata_less_stock(stock_path, require_loaded=False)
    except (OSError, subprocess.SubprocessError) as error:
        raise VfmRuntimeError('Stock decoder build identity unavailable; recovery retained') from error
    current = _loaded_module_version('amvdec_ports')
    if (Path('/sys/module/moonlight_vfm')).exists():
        # Launcher/watchdog confirmed the native process is gone before this
        # operation. A bridge pins the decoder, so unload the quiescent bridge
        # first even when the stock image is already resident.
        # Never force a busy module out from under another owner.
        subprocess.run(['rmmod', 'moonlight_vfm'], timeout=15, check=True)
        if Path('/sys/module/moonlight_vfm').exists():
            raise VfmRuntimeError('VFM bridge remained loaded; recovery retained')
    if current == original_version:
        _verify_loaded_stock_decoder(stock_path, original_version)
        _verify_stock_multiplanar(original_mode)
        return
    if current == 'moonlight-hdr1':
        subprocess.run(['rmmod', 'amvdec_ports'], timeout=15, check=True)
        current = _loaded_module_version('amvdec_ports')
    if current is not None:
        raise VfmRuntimeError('Refusing to replace an unrelated loaded decoder')
    subprocess.run(['insmod', str(stock_path), 'multiplanar=' + original_mode],
                   timeout=15, check=True)
    _verify_loaded_stock_decoder(stock_path, original_version)
    _verify_stock_multiplanar(original_mode)



# This journal exists ONLY while a stock -> patched module swap is incomplete.
# Keep the original module loaded between completed VFM sessions, as before.
# A killed loader cannot erase this record, so either recovery owner can
# reconstruct the original module if replacement was interrupted.
DECODER_JOURNAL_SCHEMA = 'luna-vfm-decoder-rollback-v1'


def _decoder_journal_path(filename):
    path = Path(filename)
    if (not path.is_absolute() or '..' in path.parts or
            not re.fullmatch(r'\.luna-session\.[A-Za-z0-9]{8}\.decoder-state',
                             path.name) or path.parent.is_symlink()):
        raise VfmRuntimeError('Unsafe VFM decoder recovery journal path')
    return path


def _journal_sync_directory(path):
    fd = os.open(str(path.parent), os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _journal_remove(path):
    path.unlink()
    _journal_sync_directory(path)


def _journal_save(filename, original):
    path = _decoder_journal_path(filename)
    if path.exists() or path.is_symlink():
        raise VfmRuntimeError('Unrecovered VFM decoder journal already exists')
    stock, mode, version = original
    record = {
        'schema': DECODER_JOURNAL_SCHEMA,
        'kernel': os.uname().release,
        'boot': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        'stock': str(stock.resolve()),
        'sha256': hashlib.sha256(stock.read_bytes()).hexdigest(),
        'mode': mode,
        'version': version,
    }
    staged = None
    try:
        with tempfile.NamedTemporaryFile(
                mode='w', encoding='utf-8', prefix='.luna-decoder-', suffix='.tmp',
                dir=path.parent, delete=False) as output:
            staged = Path(output.name)
            os.fchmod(output.fileno(), 0o600)
            json.dump(record, output, separators=(',', ':'))
            output.write('\n')
            output.flush()
            os.fsync(output.fileno())
        os.replace(staged, path)
        staged = None
        _journal_sync_directory(path)
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)


def _journal_read(filename):
    path = _decoder_journal_path(filename)
    if not path.exists() and not path.is_symlink():
        return path, None
    try:
        record, st = read_bounded_json(path, 4096, with_stat=True)
    except (OSError, ValueError, RecursionError) as error:
        raise VfmRuntimeError('Malformed VFM decoder recovery journal') from error
    if (not stat.S_ISREG(st.st_mode) or st.st_uid != os.geteuid() or
            st.st_size <= 0 or st.st_size > 4096):
        raise VfmRuntimeError('Invalid VFM decoder recovery journal owner/size')
    if (not isinstance(record, dict) or
            record.get('schema') != DECODER_JOURNAL_SCHEMA or
            not isinstance(record.get('boot'), str) or
            not isinstance(record.get('kernel'), str) or
            not isinstance(record.get('stock'), str) or
            not isinstance(record.get('sha256'), str) or
            not isinstance(record.get('version'), str) or
            record.get('mode') not in ('0', '1')):
        raise VfmRuntimeError('Malformed VFM decoder recovery journal')
    return path, record


def recover_decoder(filename, old_boot=False):
    """Invoked after the session is quiescent, before Kodi regains display."""
    path, record = _journal_read(filename)
    if record is None:
        return
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if old_boot:
        # A different boot reset the installed kernel modules. This path is
        # for reconciling old sessions only; never execute an old insmod.
        if record['boot'] == boot:
            raise VfmRuntimeError('Refusing to retire a live-boot decoder journal')
        _journal_remove(path)
        return
    if record['kernel'] != os.uname().release or record['boot'] != boot:
        raise VfmRuntimeError('Decoder journal belongs to a different kernel/boot')
    stock = Path(record['stock'])
    if not stock.is_absolute() or stock.name != 'amvdec_ports.ko' or stock.is_symlink():
        raise VfmRuntimeError('Invalid stock decoder path in recovery journal')
    release = record['kernel']
    resolved = stock.resolve()
    if not _stock_module_path_allowed(resolved, release):
        raise VfmRuntimeError('Stock decoder path escaped kernel module directories')
    if (not resolved.is_file() or
            hashlib.sha256(resolved.read_bytes()).hexdigest() != record['sha256'] or
            _module_info('vermagic', resolved).split()[:1] != [release] or
            _module_info('version', resolved) != record['version']):
        raise VfmRuntimeError('Stock decoder changed since backup; reboot CoreELEC')
    _restore_stock_decoder((resolved, record['mode'], record['version']))
    _journal_remove(path)


def load_modules(directory, journal=None):
    """Replace a stopped-Kodi decoder with a validated rollback path."""
    root = Path(directory)
    manifest = verify_bundle(root, os.uname().release)
    check_loaded_bridge(root / 'modules' / manifest['kernel_release'] / 'moonlight_vfm.ko')
    modules = [(name, root / 'modules' / manifest['kernel_release'] / name)
               for name in manifest['module_order']]
    # Preflight the entire load set before changing any loaded kernel module.
    for name, module in modules:
        if _module_info('vermagic', module).split()[:1] != [os.uname().release]:
            raise VfmRuntimeError('Kernel mismatch for ' + name)
        if name == 'moonlight_vfm.ko' and _module_info('version', module) != '6':
            raise VfmRuntimeError('Bundled VFM bridge is not version 6')
    decoder = next((m for n, m in modules if n == 'amvdec_ports.ko'), None)
    if decoder is None:
        raise VfmRuntimeError('Missing VFM HDR decoder module')
    original = prepare_hdr_decoder(decoder)
    if original is None or journal is None:
        raise VfmRuntimeError(
            'VFM requires a verified stock decoder and an owned recovery journal')
    attempted_swap = False
    journal_created = False
    bridge_installed = False
    try:
        for name, module in modules:
            if name == 'amvdec_ports.ko' and original is not None:
                # Durable before rmmod: a killed/time-limited Python process
                # leaves enough information for the independent Kodi watchdog.
                if journal is not None:
                    _journal_save(journal, original)
                    journal_created = True
                attempted_swap = True
                result = subprocess.run(
                    ['rmmod', 'amvdec_ports'], stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, text=True, timeout=15, check=False)
                if result.returncode or _loaded_module_version('amvdec_ports') is not None:
                    raise VfmRuntimeError('Stock decoder is busy; refusing VFM replacement')
            if (Path('/sys/module') / name[:-3]).exists():
                resident_name = name[:-3]
                if resident_name in ('amvdec_ports', 'moonlight_vfm'):
                    raise VfmRuntimeError(
                        'Luna-owned VFM module %s appeared during this swap; '
                        'refusing unowned module reuse' % resident_name)
                evidence = _verify_resident_vfm_dependency(
                    resident_name, module)
                print('AML-VFM: reusing resident %s (%s)' %
                      (resident_name, evidence), flush=True)
                continue
            command = ['insmod', str(module)]
            if name == 'amvdec_ports.ko':
                command.append('multiplanar=1')
            subprocess.run(command, timeout=15, check=True)
            if name == 'amvdec_ports.ko' and _loaded_module_version('amvdec_ports') != 'moonlight-hdr1':
                raise VfmRuntimeError('Patched decoder version could not be verified')
            if name == 'moonlight_vfm.ko':
                bridge_installed = True
        if not Path('/dev/moonlight-vfm').exists():
            raise VfmRuntimeError('Experimental VFM bridge device did not appear')
        # A matching version alone is insufficient; require the source-
        # identified module THIS session installed, with the rollback journal
        # still armed. Preflight above continues to reject pre-existing bridges.
        if not journal_created or not bridge_installed:
            raise VfmRuntimeError('VFM modules not installed with recovery ownership')
        bridge_module = next(
            (module for name, module in modules if name == 'moonlight_vfm.ko'), None)
        check_loaded_bridge(bridge_module, during_session=True)
        check_decoder_device()
        # Do NOT retire the stock recovery journal on success. Launcher and
        # watchdog must use it after Moonlight exits, before Kodi resumes.
    except (VfmRuntimeError, OSError, subprocess.SubprocessError) as error:
        if attempted_swap:
            try:
                # Recovery must recheck the journaled stock SHA-256 before
                # reinsertion. Never trust a file changed since the swap.
                if journal_created:
                    recover_decoder(journal)
                else:
                    _restore_stock_decoder(original)
            except (VfmRuntimeError, OSError, subprocess.SubprocessError) as rollback:
                raise VfmRuntimeError(
                    'VFM module setup failed and stock decoder rollback was not verified: '
                    '%s. Reboot CoreELEC before retrying. Initial error: %s' %
                    (rollback, error)) from error
        raise
    # Module ownership persists after successful setup; no forced unload.

def check_decoder_device(sys_root='/sys', dev_root='/dev'):
    """Check the actual stock decoder after module activation, with Kodi stopped."""
    mode = Path(sys_root) / 'module/amvdec_ports/parameters/multiplanar'
    if mode.read_text().strip() not in ('1', 'Y'):
        mode.write_text('1\n')
    if mode.read_text().strip() not in ('1', 'Y'):
        raise VfmRuntimeError('Cannot enable multiplanar output on the stock decoder')

    devices = Path(sys_root) / 'class/video4linux'
    for entry in sorted(devices.glob('video*')):
        if (entry / 'name').read_text().strip() != 'aml-vcodec-dec':
            continue
        path = Path(dev_root) / entry.name
        fd = os.open(path, os.O_RDWR | os.O_NONBLOCK | os.O_CLOEXEC)
        try:
            # These two V4L2 structs contain only fixed-width fields; their
            # ioctl numbers/layouts are identical for ARM32 and ARM64.
            cap = bytearray(104)
            fcntl.ioctl(fd, 0x80685600, cap)  # VIDIOC_QUERYCAP
            caps, device_caps = struct.unpack_from('=II', cap, 84)
            if caps & 0x80000000:  # V4L2_CAP_DEVICE_CAPS
                caps = device_caps
            if caps & 0x04004000 != 0x04004000:  # STREAMING | VIDEO_M2M_MPLANE
                raise VfmRuntimeError('%s lacks streaming/multiplanar decoder capabilities' % path)
            for queue, required in ((10, {b'H264', b'HEVC'}), (9, {b'NV12'})):
                formats = set()
                for index in range(64):
                    desc = bytearray(64)
                    struct.pack_into('=II', desc, 0, index, queue)
                    try:
                        fcntl.ioctl(fd, 0xc0405602, desc)  # VIDIOC_ENUM_FMT
                    except OSError as error:
                        if error.errno != 22:
                            raise
                        break
                    formats.add(bytes(desc[44:48]))
                if not required <= formats:
                    raise VfmRuntimeError('%s lacks required %s formats (reported %s)' %
                                          (path, 'input' if queue == 10 else 'capture',
                                           sorted(f.decode('ascii', 'replace') for f in formats)))
            print('AML-VFM: stock decoder ready at %s (H.264/HEVC, NV12)' % path)
            return
        finally:
            os.close(fd)
    raise VfmRuntimeError('Stock V4L2 decoder device did not appear after runtime activation')


if __name__ == '__main__':
    import sys
    try:
        if len(sys.argv) == 4 and sys.argv[1] == 'load':
            load_modules(sys.argv[2], sys.argv[3])
        elif len(sys.argv) == 3 and sys.argv[1] == 'restore':
            recover_decoder(sys.argv[2])
        elif len(sys.argv) == 3 and sys.argv[1] == 'retire-old-boot':
            recover_decoder(sys.argv[2], old_boot=True)
        else:
            raise VfmRuntimeError('Usage: vfmruntime.py load BUNDLE SESSION.decoder-state | restore SESSION.decoder-state | retire-old-boot SESSION.decoder-state')
    except (VfmRuntimeError, OSError, subprocess.SubprocessError) as error:
        print('AML-VFM: %s' % error, file=sys.stderr)
        sys.exit(1)
