"""Host recovery remains available after Moonlight fails before first video."""
import ast
from contextlib import contextmanager
from pathlib import Path
import sys
import types
import unittest
from unittest import mock

from resources.lib.util.hostcontext import host_identity

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'addon.py'


class HostSessionRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.saved = {'host_addr': 'host-A', 'last_run': '',
                      'last_run_id': '', 'last_run_host': ''}
        self.options = {'port': '47989'}
        self.states = ['42', '42']
        self.quit_calls = []
        self.snapshot_calls = []
        self.confirm = True
        self.on_confirm = None
        self.idle = True
        self.quit_ok = True
        self.messages = []
        test = self

        class Addon:
            def getSetting(self, key):
                return test.saved.get(key, '')
            def setSettingString(self, key, value):
                test.saved[key] = value

        class Config:
            config = {'host_addr': 'host-A'}
            binary_path = '/addon/bin/coreelec-ng/'
            def configure(self, dump=True):
                self.config['host_addr'] = test.saved['host_addr']
            def host_options(self):
                return dict(test.options)

        class Helper:
            def __init__(self, *args):
                self._frozen_host_options = None
                self._selected_address = None
            def _is_coreelec_ng(self, path):
                return True
            @contextmanager
            def _native_host_command(self, action, address):
                test.snapshot_calls.append((action, address,
                                            dict(self._frozen_host_options)))
                yield (['moonlight', action], {'LUNA_STREAM_CONFIG': '/snapshot'})
            def _running_ng_app(self, binary_path, env, app_id, timeout_seconds=12):
                state = test.states.pop(0)
                if isinstance(state, Exception):
                    return None, str(state)
                return state, None
            def quit_game(self, address, snapshot=None):
                test.quit_calls.append((address, snapshot))
                return test.quit_ok
            def _wait_for_ng_app_stopped(self, *a, **kw):
                return test.idle, None

        class Dialog:
            def ok(self, title, message):
                test.messages.append((title, message))
            def yesno(self, *a, **kw):
                if test.on_confirm:
                    test.on_confirm()
                return test.confirm

        module = types.ModuleType('resources.lib.util.moonlighthelper')
        module.MoonlightHelper = Helper
        old = sys.modules.get(module.__name__)
        sys.modules[module.__name__] = module
        self.addCleanup(lambda: (sys.modules.pop(module.__name__, None)
                                 if old is None else
                                 sys.modules.__setitem__(module.__name__, old)))
        tree = ast.parse(SOURCE.read_text(encoding='utf-8'))
        names = {'endHostSession', '_connection_options',
                 '_pairing_context_current'}
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef)
                 and n.name in names]
        self.assertEqual({n.name for n in nodes}, names)
        self.scope = {
            'addon': Addon(), 'config_helper': Config(),
            'logger': mock.Mock(),
            'xbmcgui': types.SimpleNamespace(Dialog=Dialog),
            'xbmc': types.SimpleNamespace(executebuiltin=mock.Mock()),
        }
        exec(compile(ast.fix_missing_locations(
            ast.Module(body=nodes, type_ignores=[])), str(SOURCE), 'exec'),
             self.scope)

    def end(self):
        return self.scope['endHostSession']()

    def test_menu_shows_recovery_even_without_last_run(self):
        source = SOURCE.read_text(encoding='utf-8')
        self.assertIn("base_url + '?action=end_host_session'", source)
        self.assertIn("elif action == 'end_host_session':", source)
        self.assertIn("if (addon.getSetting('host_addr') or '').strip():",
                      source)

    def test_ends_verified_host_after_failed_rtsp_without_last_run(self):
        self.assertTrue(self.end())
        self.assertEqual(self.quit_calls, [('host-A', '/snapshot')])
        self.assertEqual(self.snapshot_calls[0][0:2], ('quit', 'host-A'))
        self.assertIn('no running application', self.messages[-1][1])

    def test_cancel_is_read_only(self):
        self.confirm = False
        self.assertFalse(self.end())
        self.assertEqual(self.quit_calls, [])

    def test_host_idle_is_read_only(self):
        self.states = ['0']
        self.assertFalse(self.end())
        self.assertEqual(self.quit_calls, [])

    def test_unverified_host_is_read_only(self):
        self.states = [OSError('unavailable')]
        self.assertFalse(self.end())
        self.assertEqual(self.quit_calls, [])

    def test_changed_app_after_confirmation_is_read_only(self):
        self.states = ['42', '43']
        self.assertFalse(self.end())
        self.assertEqual(self.quit_calls, [])

    def test_host_address_port_or_keydir_change_cancels(self):
        for key, value in (('host_addr', 'host-B'), ('port', '48000'),
                           ('keydir', '/other-keys')):
            with self.subTest(key=key):
                self.saved['host_addr'] = 'host-A'
                self.options = {'port': '47989'}
                self.states = ['42', '42']
                self.quit_calls.clear()
                self.on_confirm = lambda k=key, v=value: (
                    self.saved.__setitem__(k, v) if k == 'host_addr'
                    else self.options.__setitem__(k, v))
                self.assertFalse(self.end())
                self.assertEqual(self.quit_calls, [])

    def test_failed_quit_never_clears_last_run(self):
        self.saved.update(last_run='Desktop', last_run_id='42',
                          last_run_host=host_identity('host-A'))
        self.quit_ok = False
        self.assertFalse(self.end())
        self.assertEqual(self.saved['last_run'], 'Desktop')

    def test_unconfirmed_idle_never_clears_last_run(self):
        self.saved.update(last_run='Desktop', last_run_id='42',
                          last_run_host=host_identity('host-A'))
        self.idle = False
        self.assertFalse(self.end())
        self.assertEqual(self.saved['last_run'], 'Desktop')

    def test_ends_exact_saved_app_only_after_host_is_idle(self):
        self.saved.update(last_run='Desktop', last_run_id='42',
                          last_run_host=host_identity('host-A'))
        self.assertTrue(self.end())
        self.assertEqual(self.saved['last_run'], '')
        self.assertEqual(self.saved['last_run_host'], '')


if __name__ == '__main__':
    unittest.main()
