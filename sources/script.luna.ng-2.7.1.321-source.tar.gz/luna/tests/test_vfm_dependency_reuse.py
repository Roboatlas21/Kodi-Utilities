"""CoreELEC 21 VFM resident dependency reuse never adopts patched modules."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

from resources.lib.util import vfmruntime as runtime


class VfmResidentModuleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.sys = self.root / 'sys' / 'module'
        self.bundle = self.root / 'bundle' / 'media.ko'
        self.bundle.parent.mkdir()
        self.bundle.write_bytes(b'test bundled module')
        self.stock = self.root / 'stock' / 'media.ko'
        self.stock.parent.mkdir()
        self.stock.write_bytes(b'protected stock module')
        self.proc = self.root / 'modules'
        self.proc.write_text('media 123 0 - Live 0x0000\n')
        (self.sys / 'media').mkdir(parents=True)
        self.metadata = {
            'vermagic': '4.9.269 SMP modversions aarch64',
            'name': '',
            'version': '',
            'srcversion': '',
        }

    def info(self, field, module):
        if field == 'filename':
            return str(self.stock)
        return self.metadata[field]

    def check(self, name='media'):
        return runtime._verify_resident_vfm_dependency(
            name, self.bundle, sys_module_root=self.sys, proc_modules=self.proc)

    def context(self):
        return (
            mock.patch.object(runtime, '_module_info', side_effect=self.info),
            mock.patch.object(runtime, '_stock_module_path_allowed', return_value=True),
            mock.patch.object(runtime.os, 'uname',
                              return_value=type('U', (), {'release': '4.9.269'})()),
        )

    def test_preexisting_coreelec_module_is_reused_with_stock_provenance(self):
        with self.context()[0], self.context()[1], self.context()[2]:
            self.assertEqual(self.check(), 'trusted CoreELEC stock module')

    def test_matching_loaded_srcversion_is_accepted(self):
        (self.sys / 'media' / 'srcversion').write_text('SAME_SOURCE\n')
        self.metadata['srcversion'] = 'SAME_SOURCE'
        with self.context()[0], self.context()[1], self.context()[2]:
            self.assertEqual(self.check(), 'loaded srcversion')

    def test_mismatched_srcversion_is_rejected(self):
        (self.sys / 'media' / 'srcversion').write_text('OTHER_SOURCE\n')
        self.metadata['srcversion'] = 'EXPECTED_SOURCE'
        with self.context()[0], self.context()[1], self.context()[2]:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'srcversion differs'):
                self.check()

    def test_unknown_and_owned_module_cannot_be_reused(self):
        with self.context()[0], self.context()[1], self.context()[2]:
            for name in ('amvdec_ports', 'moonlight_vfm', 'unreviewed_module'):
                with self.subTest(name=name), self.assertRaisesRegex(
                        runtime.VfmRuntimeError, 'not an approved reusable'):
                    self.check(name)

    def test_incompatible_stock_kernel_or_source_is_rejected(self):
        with self.context()[0], self.context()[1], self.context()[2]:
            self.metadata['vermagic'] = '5.15.0 SMP'
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'kernel ABI'):
                self.check()
            self.metadata['vermagic'] = '4.9.269 SMP'
            self.metadata['srcversion'] = 'EXPECTED_SOURCE'
            with mock.patch.object(runtime, '_module_info',
                                   side_effect=lambda field, module:
                                       ('DIFFERENT_SOURCE' if
                                        field == 'srcversion' and
                                        module == self.stock else
                                        self.info(field, module))):
                with self.assertRaisesRegex(runtime.VfmRuntimeError,
                                            'stock source differs'):
                    self.check()

    def test_busy_or_untrusted_resident_module_refuses_reuse(self):
        with self.context()[0], self.context()[1], self.context()[2]:
            self.proc.write_text('media 123 0 - Unloading 0x0000\n')
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'not live'):
                self.check()
            self.proc.write_text('media 123 0 - Live 0x0000\n')
            with mock.patch.object(runtime, '_stock_module_path_allowed',
                                   return_value=False):
                with self.assertRaisesRegex(runtime.VfmRuntimeError,
                                            'no trusted stock module'):
                    self.check()

    def test_builtin_only_reused_when_source_has_no_identity(self):
        with self.context()[0], self.context()[1], self.context()[2], \
             mock.patch.object(runtime, '_module_info',
                               side_effect=lambda field, module:
                                   '(builtin)' if field == 'filename'
                                   else self.info(field, module)):
            self.proc.write_text('')
            self.assertEqual(self.check(), 'kernel builtin')
            self.proc.write_text('media 123 0 - Live 0x0000\n')
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'builtin'):
                self.check()

    def test_running_kernel_without_metadata_requires_coreelec21(self):
        with self.context()[0], self.context()[1], \
             mock.patch.object(runtime.os, 'uname',
                               return_value=type('U', (), {'release': '5.15.2'})()):
            self.metadata['vermagic'] = '5.15.2 SMP'
            with self.assertRaisesRegex(runtime.VfmRuntimeError,
                                        'metadata-less'):
                self.check()

    def test_load_skips_resident_dependencies_but_owns_decoder_and_bridge(self):
        state = {'amvdec_ports': True, 'moonlight_vfm': False}
        seen = []
        def present(path):
            path = str(path)
            if path == '/sys/module/media':
                return True
            if path in ('/sys/module/amvdec_ports', '/sys/module/moonlight_vfm'):
                return state[path.rsplit('/', 1)[-1]]
            return path == '/dev/moonlight-vfm'

        def run(command, **kwargs):
            seen.append(list(command))
            if command[:2] == ['rmmod', 'amvdec_ports']:
                state['amvdec_ports'] = False
            if command[0] == 'insmod':
                if command[1].endswith('/amvdec_ports.ko'):
                    state['amvdec_ports'] = True
                if command[1].endswith('/moonlight_vfm.ko'):
                    state['moonlight_vfm'] = True
            return subprocess.CompletedProcess(command, 0, stdout='')

        with mock.patch.object(runtime, 'verify_bundle', return_value={
                 'kernel_release': '4.9.269',
                 'module_order': ['media.ko', 'amvdec_ports.ko', 'moonlight_vfm.ko']}), \
             mock.patch.object(runtime.os, 'uname',
                               return_value=type('U', (), {'release': '4.9.269'})()), \
             mock.patch.object(runtime, 'check_loaded_bridge'), \
             mock.patch.object(runtime, 'prepare_hdr_decoder',
                               return_value=(self.stock, '0', '')), \
             mock.patch.object(runtime, '_verify_resident_vfm_dependency',
                               return_value='verified') as reuse, \
             mock.patch.object(runtime, '_module_info',
                               side_effect=lambda field, module:
                                   '4.9.269 SMP' if field == 'vermagic'
                                   else '6' if field == 'version' and
                                   str(module).endswith('moonlight_vfm.ko')
                                   else ''), \
             mock.patch.object(runtime, '_loaded_module_version',
                               side_effect=lambda name:
                                   'moonlight-hdr1' if state['amvdec_ports'] else None), \
             mock.patch.object(Path, 'exists', side_effect=present, autospec=True), \
             mock.patch.object(runtime.subprocess, 'run', side_effect=run), \
             mock.patch.object(runtime, '_journal_save') as journal, \
             mock.patch.object(runtime, 'check_decoder_device'):
            runtime.load_modules(self.root, self.root / '.luna-session.ABCD1234.decoder-state')
        reuse.assert_called_once_with('media', self.root / 'modules/4.9.269/media.ko')
        journal.assert_called_once()
        self.assertEqual([cmd[0] for cmd in seen], ['rmmod', 'insmod', 'insmod'])
        self.assertTrue(seen[1][1].endswith('/amvdec_ports.ko'))
        self.assertTrue(seen[2][1].endswith('/moonlight_vfm.ko'))

    def test_preflight_rejects_incompatible_dependency_before_native_launch(self):
        with mock.patch.object(runtime, 'verify_bundle', return_value={
                 'kernel_release': '4.9.269',
                 'module_order': ['media.ko', 'amvdec_ports.ko', 'moonlight_vfm.ko']}), \
             mock.patch.object(runtime, 'check_loaded_bridge'), \
             mock.patch.object(runtime, 'prepare_hdr_decoder'), \
             mock.patch.object(Path, 'exists',
                               side_effect=lambda path: str(path) == '/sys/module/media',
                               autospec=True), \
             mock.patch.object(runtime, '_verify_resident_vfm_dependency',
                               side_effect=runtime.VfmRuntimeError('unverified media')), \
             mock.patch.object(runtime.subprocess, 'run') as native:
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'unverified media'):
                runtime.check_runtime(self.root, '/native/moonlight', {})
            native.assert_not_called()


if __name__ == '__main__':
    unittest.main()
