"""Fast manual diagnostic UI and empty hidden pairing settings regressions."""
import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest import mock
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
DIAG = ROOT / 'resources/lib/util/diagnosticreport.py'
spec = importlib.util.spec_from_file_location('luna_diagnostic_fast_ui', DIAG)
report = importlib.util.module_from_spec(spec)
spec.loader.exec_module(report)


class DiagnosticFastUiTests(unittest.TestCase):
    def test_progress_opens_before_collect_and_closes_before_final_dialog(self):
        sequence = []
        progress = mock.Mock()
        progress.create.side_effect = lambda *a: sequence.append('open')
        progress.update.side_effect = lambda *a: sequence.append('update')
        progress.close.side_effect = lambda: sequence.append('close')
        gui = types.ModuleType('xbmcgui')
        gui.DialogProgress = lambda: progress
        with mock.patch.dict(sys.modules, {'xbmcgui': gui}), \
             mock.patch.object(report, 'create_report',
                               side_effect=lambda *a, **kw:
                                   sequence.append('collect') or Path('/report.zip')), \
             mock.patch.object(report, 'export_report',
                               side_effect=lambda *a:
                                   sequence.append('export') or Path('/share/report.zip')), \
             mock.patch.object(report, 'show_in_kodi',
                               side_effect=lambda *a: sequence.append('result')):
            self.assertTrue(report.save_report_with_dialog(
                '/tmp', show_progress=True))
        self.assertEqual(sequence, [
            'open', 'update', 'collect', 'update', 'export', 'close', 'result'])

    def test_failed_export_closes_progress_before_error_dialog(self):
        sequence = []
        progress = mock.Mock()
        progress.create.side_effect = lambda *a: sequence.append('open')
        progress.update.side_effect = lambda *a: sequence.append('update')
        progress.close.side_effect = lambda: sequence.append('close')
        dialog = mock.Mock()
        dialog.ok.side_effect = lambda *a: sequence.append('failure')
        gui = types.ModuleType('xbmcgui')
        gui.DialogProgress = lambda: progress
        gui.Dialog = lambda: dialog
        with mock.patch.dict(sys.modules, {'xbmcgui': gui}), \
             mock.patch.object(report, 'create_report', return_value=Path('/report.zip')), \
             mock.patch.object(report, 'export_report', side_effect=OSError('offline')):
            self.assertFalse(report.save_report_with_dialog(
                '/tmp', show_progress=True))
        self.assertLess(sequence.index('close'), sequence.index('failure'))

    def test_early_exit_stays_non_progress(self):
        with mock.patch.object(report, 'create_report', return_value=Path('/report.zip')), \
             mock.patch.object(report, 'export_report', return_value=Path('/share/report.zip')), \
             mock.patch.object(report, 'show_in_kodi'):
            self.assertTrue(report.save_report_with_dialog('/tmp'))

    def test_hidden_pairing_status_defaults_allow_empty(self):
        settings = ElementTree.parse(ROOT / 'resources/settings.xml')
        by_id = {element.get('id'): element for element in settings.iter('setting')}
        for name in ('pair_status_host', 'pair_status_context'):
            with self.subTest(name=name):
                self.assertEqual(by_id[name].findtext('constraints/allowempty'), 'true')


if __name__ == '__main__':
    unittest.main()
