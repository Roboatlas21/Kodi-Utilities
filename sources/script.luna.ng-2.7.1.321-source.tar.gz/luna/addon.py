import os
import stat
import subprocess

import sys
import urllib.parse
import re

from xml.etree import ElementTree

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib.util.confighelper import ConfigHelper, MoonlightConfigFormatError
from resources.lib.util.inputdevices import InvalidInputSelection
from resources.lib.util.library import LibraryDataError
from resources.lib.util.appidentity import canonical_app_id, launch_url
from resources.lib.core.logger import Logger 
from xbmcvfs import translatePath

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

logger = Logger()

def getAddonPath(path):
    return translatePath(addon_path + path)


def showMoonlightConfigRecovery(error):
    """Explain manual recovery without exposing configuration contents."""
    logger.error('Luna cannot use moonlight.conf: %s' % error.reason)
    xbmcgui.Dialog().ok('Moonlight configuration needs repair',
                        error.recovery_message())


def ensurePermissions():
    targets = [getAddonPath('/bin/coreelec-ng/moonlight'),
               getAddonPath('/bin/coreelec-no/moonlight'),
               getAddonPath('/bin/moonlight'),
               getAddonPath('/resources/create_bug_report.sh')]

    for root, _dirs, files in os.walk(getAddonPath('/resources/launchscripts')):
        targets += [os.path.join(root, f) for f in files if f.endswith('.sh')]

    for path in targets:
        try:
            mode = os.stat(path).st_mode
            if not mode & stat.S_IXUSR:
                os.chmod(path, mode | 0o111)
        except OSError:
            pass


def _setPairingStatus(paired, label, address=None):
    # A Kodi settings dialog can display status from a previously selected
    # host while the user edits the IP field. Always identify which endpoint
    # was actually checked and never treat a global boolean as proof for
    # another host.
    if address is None:
        address = (addon.getSetting('host_addr') or '').strip()
    persistSetting('pair_status_host', address)
    try:
        from resources.lib.util.hostcontext import host_identity
        context = host_identity(address, _connection_options()) if address else ''
    except (OSError, ValueError, TypeError, AttributeError):
        context = ''
    persistSetting('pair_status_context', context)
    persistSetting('pair_status_display',
                   '%s — %s' % (address, label) if address else label)
    persistBoolSetting('paired_state', paired)


def syncPairingStatus():
    config_helper.configure(dump=False)
    address = (addon.getSetting('host_addr') or '').strip()

    if not address:
        _setPairingStatus(False, addon.getLocalizedString(30324) or 'Not configured')
        return False

    try:
        from resources.lib.util.hostapi import Host
        from resources.lib.util.moonlighthelper import MoonlightHelper
        host = MoonlightHelper(addon, config_helper, logger)._host(address)
        if not host.has_pairing_keys():
            _setPairingStatus(False, addon.getLocalizedString(30322) or 'Not paired')
            return False
        # A host without an established identity pin cannot be called paired.
        if not host.has_trusted_pin():
            _setPairingStatus(False, 'Re-pair to verify Sunshine host identity')
            return False
        paired = host.pair_status()
    except Exception as error:
        logger.info('Pairing status unavailable for %s: %s' % (address, error))
        _setPairingStatus(False, addon.getLocalizedString(30323) or 'Host unavailable')
        return False

    _setPairingStatus(
        paired,
        (addon.getLocalizedString(30321) or 'Paired ✓') if paired
        else (addon.getLocalizedString(30322) or 'Not paired'))
    return paired


def settings():
    before = (addon.getSetting('host_addr') or '').strip()
    # The existing Kodi login service monitors this setting in every addon
    # settings entry point, including direct access from Kodi's add-on menu.
    # Do not create a new network worker on each modal invocation.
    # Notify the already-running status service of this exact opening, even
    # if Settings closes/reopens between its 200 ms observations.
    import time
    try:
        window = getattr(xbmcgui, 'Window', None)
        if window is not None:
            window(10000).setProperty('Luna.Status.OpenToken',
                                     str(time.monotonic_ns()))
    except (RuntimeError, TypeError, ValueError) as error:
        logger.info('Luna live status open signal unavailable: %s' %
                    type(error).__name__)
    # Never contact Sunshine before opening Settings. The user may be here
    # specifically to repair an unreachable IP; the service checks it without
    # blocking the dialog.
    addon.openSettings()

    config_helper.configure()
    after = (addon.getSetting('host_addr') or '').strip()
    if after != before:
        _clearApplicationListCache()

    # A disabled/crashed service has no live watcher; preserve close-time
    # verification then. The heartbeat expires after a real service crash.
    try:
        home = xbmcgui.Window(10000)
        heartbeat = float(home.getProperty('Luna.Status.ServiceHeartbeat'))
        service_ready = (home.getProperty('Luna.Status.ServiceHealth') == 'ready'
                         and 0 <= time.monotonic() - heartbeat < 3)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        service_ready = False
    from resources.lib.util.hostcontext import host_identity
    try:
        selected_context = host_identity(after, _connection_options()) if after else ''
    except (OSError, ValueError, TypeError, AttributeError):
        selected_context = None
    needs_check = (
        getattr(config_helper, 'config_error', None) is None and (
            after != before or addon.getSetting('pair_status_host') != after or
            selected_context is None or
            addon.getSetting('pair_status_context') != selected_context or
            'Checking pairing...' in addon.getSetting('pair_status_display')))
    # Always reconcile once after a healthy modal closes, even if the IP
    # did not change. Kodi may save a cached settings page on close; the
    # service's post-close update is the sole direct XML status writer.
    if (service_ready and getattr(config_helper, 'config_error', None) is None and
            selected_context is not None):
        try:
            # A fresh service heartbeat means only that the service is alive,
            # NOT that it observed the edit before the dialog closed. Queue a
            # one-shot, host-specific check in the existing worker. Never
            # force an HTTP request in the Kodi Settings UI thread.
            home = xbmcgui.Window(10000)
            # Token goes last; the service never treats a partially written
            # host/context pair as a completed pending request.
            home.setProperty('Luna.Status.PendingContext', selected_context)
            home.setProperty('Luna.Status.PendingHost', after)
            home.setProperty('Luna.Status.PendingToken', str(time.monotonic_ns()))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            syncPairingStatus()
    elif needs_check:
        # The Kodi service is disabled or unavailable; retain the original
        # synchronous fallback after Settings is fully closed.
        syncPairingStatus()

def saveDiagnosticReport():
    """Save diagnostics with the same reporting used after a stream failure."""
    from resources.lib.util.diagnosticreport import save_report_with_dialog
    profile = translatePath('special://profile/addon_data/script.luna.ng/')
    kodi_log = translatePath('special://logpath/kodi.log')
    legacy_log = os.path.join(addon_path, 'bin', 'logfile')
    return save_report_with_dialog(
        profile, kodi_log=kodi_log, legacy_log=legacy_log,
        show_progress=True,
        log_failure=lambda kind: logger.error(
            'Luna local diagnostic report failed: %s' % kind))


def _connection_options():
    return config_helper.host_options()


def _pairing_context_current(address, options):
    """Compare all confirmation-time host inputs; never infer a replacement."""
    try:
        config_helper.configure(dump=False)
        selected = (addon.getSetting('host_addr') or
                    config_helper.config.get('host_addr') or '').strip()
        return selected == address and dict(_connection_options()) == options
    except (OSError, ValueError, TypeError):
        return False


def _confirmed_pairing_action_allowed(address, options):
    if _pairing_context_current(address, options):
        return True
    xbmcgui.Dialog().ok(
        'Sunshine host changed',
        'The host, port or pairing key directory changed during confirmation. '
        'No unpair or certificate reset was performed. '
        'Confirm the new connection separately.')
    return False


def _action_host_matches():
    from resources.lib.util.resumestate import host_identity
    selected = host_identity(addon.getSetting('host_addr') or
                             config_helper.config.get('host_addr'), _connection_options())
    if selected and args.get('host', [None])[0] == selected:
        return True
    xbmcgui.Dialog().ok('Sunshine host changed',
                        'Reopen the application list and recreate old favorites '
                        'or widgets before using this action.')
    return False


def launchByName():
    from resources.lib.util.moonlighthelper import MoonlightHelper

    if not _action_host_matches():
        return
    name = args.get('game', [None])[0]
    if not name:
        return

    helper = MoonlightHelper(addon, config_helper, logger)
    helper.launch_game(name, app_id=args.get('appid', [None])[0],
                       expected_host=args['host'][0])
    xbmc.executebuiltin('Container.Refresh')
    del helper

def refreshGames():
    from resources.lib.util.moonlighthelper import MoonlightHelper
    helper = MoonlightHelper(addon, config_helper, logger)
    helper.cached_games(max_age=0)
    if helper.last_host_error:
        xbmcgui.Dialog().notification('Luna refresh',
                                      'Host unavailable. Existing cache preserved.', time=5000)
    xbmc.executebuiltin('Container.Refresh')

def _library(address=None, host_options=None):
    from resources.lib.util.library import Library
    from xbmcvfs import translatePath
    address = address or addon.getSetting('host_addr') or config_helper.config.get('host_addr')
    return Library(translatePath('special://profile/addon_data/script.luna.ng/'), host=address,
                   host_options=_connection_options() if host_options is None else host_options)

def _stream_profiles():
    from resources.lib.util.streamprofiles import StreamProfiles
    from xbmcvfs import translatePath
    address = (addon.getSetting('host_addr') or
               config_helper.config.get('host_addr') or '')
    return StreamProfiles(
        translatePath('special://profile/addon_data/script.luna.ng/'), address, host_options=_connection_options())


def _games(address=None, host_options=None):
    from resources.lib.util.moonlighthelper import MoonlightHelper
    helper = MoonlightHelper(addon, config_helper, logger)
    if address is not None:
        helper._selected_address = address
    if host_options is not None:
        helper._frozen_host_options = dict(host_options)
    try:
        apps = helper.cached_games() or []
        return apps, helper.last_host_error
    except Exception as error:
        logger.error('Unable to load Sunshine applications: %s' % error)
        return [], str(error)
    finally:
        del helper


def _clearApplicationListCache():
    # Preserve offline apps from both the old and newly selected Sunshine
    # hosts. Each new list is isolated by host identity; an IP edit must not
    # delete either list. Preserve legacy folder ownership before later reads.
    if not _library().migrate_legacy():
        logger.error('Unable to preserve legacy folder ownership; cache unchanged')


def retryApplications():
    refreshGames()


def _addApplicationRecoveryItems():
    li = xbmcgui.ListItem(addon.getLocalizedString(30329) or 'Retry')
    li.setArt({'icon': getAddonPath('/resources/icons/refresh.png')})
    xbmcplugin.addDirectoryItem(
        addon_handle, base_url + '?action=retry_apps', li, False)

    li = xbmcgui.ListItem(
        addon.getLocalizedString(30330) or 'Pair / Re-pair Host')
    li.setArt({'icon': getAddonPath('/resources/icons/controller.png')})
    xbmcplugin.addDirectoryItem(
        addon_handle, base_url + '?action=pair_from_apps', li, False)

def _appItem(app_id, name, art, folder, host_key):
    li = xbmcgui.ListItem(name)
    if art:
        li.setArt({'icon': art, 'thumb': art, 'poster': art})

    move = (base_url + '?action=assign&id=' + urllib.parse.quote(app_id) +
            '&host=' + urllib.parse.quote(host_key))
    if folder:
        move += '&folder=' + urllib.parse.quote(folder)
    profile = (base_url + '?action=streamprofile&id=' +
               urllib.parse.quote(app_id) + '&host=' +
               urllib.parse.quote(host_key))
    li.addContextMenuItems([
        ((addon.getLocalizedString(30253) or 'Move to folder...'),
         'RunPlugin(%s)' % move),
        ((addon.getLocalizedString(30354) or 'Streaming profile...'),
         'RunPlugin(%s)' % profile),
    ])
    return li

def showApps(folder=None):
    address = addon.getSetting('host_addr') or config_helper.config.get('host_addr')
    options = _connection_options()
    lib = _library(address, options)
    # Migrate while the old host-tagged cache still identifies its owner.
    if not lib.migrate_legacy():
        xbmcgui.Dialog().notification(
            addon.getLocalizedString(30000),
            'Unable to safely migrate saved folders; application refresh cancelled.',
            time=5000)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return
    apps, host_error = _games(address, options)

    if host_error:
        host_label = address or (addon.getLocalizedString(30324)
                                 or 'Not configured')
        message = ((addon.getLocalizedString(30327)
                    or 'Unable to retrieve applications from %s.')
                   % host_label)
        if apps:
            message += ' ' + (addon.getLocalizedString(30328)
                              or 'Showing cached applications.')
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(30000), message, time=5000)
        else:
            xbmcgui.Dialog().ok(addon.getLocalizedString(30000), message)
        _addApplicationRecoveryItems()
        if not apps:
            xbmcplugin.endOfDirectory(addon_handle)
            return

    folders, loose = lib.split(apps)

    if folder:
        xbmcplugin.setContent(addon_handle, 'games')
        for app_id, name, art in dict(folders).get(folder, []):
            url = launch_url(base_url, name, app_id, lib.host_key)
            xbmcplugin.addDirectoryItem(addon_handle, url,
                                        _appItem(app_id, name, art, folder, lib.host_key), False)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    for name, inside in folders:
        li = xbmcgui.ListItem('%s (%d)' % (name, len(inside)))
        li.setArt({'icon': 'DefaultFolder.png'})
        rename = base_url + '?action=renfolder&folder=' + urllib.parse.quote(name) + '&host=' + lib.host_key
        delete = base_url + '?action=delfolder&folder=' + urllib.parse.quote(name) + '&host=' + lib.host_key
        li.addContextMenuItems([((addon.getLocalizedString(30256) or 'Rename folder'), 'RunPlugin(%s)' % rename),
                                ((addon.getLocalizedString(30257) or 'Delete folder'), 'RunPlugin(%s)' % delete)])
        url = base_url + '?action=apps&folder=' + urllib.parse.quote(name)
        xbmcplugin.addDirectoryItem(addon_handle, url, li, True)

    li = xbmcgui.ListItem((addon.getLocalizedString(30251) or 'New folder...'))
    li.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=newfolder', li, False)

    li = xbmcgui.ListItem(addon.getLocalizedString(30249) or 'Refresh list')
    li.setArt({'icon': getAddonPath('/resources/icons/refresh.png')})
    xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=refresh', li, False)

    if loose:
        xbmcplugin.setContent(addon_handle, 'games')
    for app_id, name, art in loose:
        url = launch_url(base_url, name, app_id, lib.host_key)
        xbmcplugin.addDirectoryItem(addon_handle, url,
                                    _appItem(app_id, name, art, None, lib.host_key), False)

    xbmcplugin.endOfDirectory(addon_handle)

def _folder_feedback(message, failed=False):
    xbmcgui.Dialog().notification(
        'Luna folders', message,
        xbmcgui.NOTIFICATION_ERROR if failed else xbmcgui.NOTIFICATION_INFO,
        time=5000 if failed else 3000)


def newFolder():
    name = xbmcgui.Dialog().input((addon.getLocalizedString(30252) or 'New folder name'))
    name = (name or '').strip()
    if not name:
        return
    lib = _library()
    if name in lib.folders():
        _folder_feedback('This folder already exists.')
    elif not lib.add_folder(name):
        _folder_feedback('Could not save the new folder.', failed=True)
    else:
        xbmc.executebuiltin('Container.Refresh')

def renameFolder():
    if not _action_host_matches():
        return
    old = args.get('folder', [None])[0]
    if not old:
        return
    new = xbmcgui.Dialog().input((addon.getLocalizedString(30256) or 'Rename folder'), defaultt=old)
    new = (new or '').strip()
    if not new or new == old:
        return
    if not _action_host_matches():
        return
    lib = _library()
    folders = lib.folders()
    if old not in folders:
        _folder_feedback('This folder no longer exists.')
    elif new in folders:
        _folder_feedback('A folder with that name already exists.')
    elif not lib.rename_folder(old, new):
        _folder_feedback('Could not save the folder rename.', failed=True)
    else:
        xbmc.executebuiltin('Container.Refresh')

def deleteFolder():
    if not _action_host_matches():
        return
    name = args.get('folder', [None])[0]
    if not name:
        return
    confirmed = xbmcgui.Dialog().yesno(
        (addon.getLocalizedString(30257) or 'Delete folder'),
        (addon.getLocalizedString(30258)
         or 'Delete "%s"?\nApplications will move back to the unsorted list.') % name,
        nolabel=xbmc.getLocalizedString(106), yeslabel=xbmc.getLocalizedString(107))
    if not confirmed:
        return
    if not _action_host_matches():
        return
    lib = _library()
    if name not in lib.folders():
        _folder_feedback('This folder no longer exists.')
    elif not lib.remove_folder(name):
        _folder_feedback('Could not save the folder deletion.', failed=True)
    else:
        xbmc.executebuiltin('Container.Refresh')

def assignApp():
    if not _action_host_matches():
        return
    app_id = args.get('id', [None])[0]
    if not app_id:
        return

    lib = _library()
    folders = lib.folders()
    current = lib.folder_of(app_id)

    targets = [f for f in folders if f != current]

    choices = [(addon.getLocalizedString(30251) or 'New folder...')]
    if current:
        choices.append((addon.getLocalizedString(30255) or 'Remove from "%s"') % current)
    choices += targets

    picked = xbmcgui.Dialog().select((addon.getLocalizedString(30254) or 'Move to folder'), choices)
    if picked == -1:
        return

    if picked == 0:
        name = xbmcgui.Dialog().input((addon.getLocalizedString(30252) or 'New folder name'))
        name = (name or '').strip()
        if not name:
            return
        if name in lib.folders():
            _folder_feedback('Folder already exists. Select it from the list.')
            return
        if not lib.add_folder(name):
            _folder_feedback('Could not save the new folder.', failed=True)
            return
        if not lib.assign(app_id, name):
            _folder_feedback('Folder created, but the app assignment could not be saved.',
                             failed=True)
            return
    elif current and picked == 1:
        if not lib.assign(app_id, None):
            _folder_feedback('Could not remove the app from its folder.', failed=True)
            return
    else:
        index = picked - (2 if current else 1)
        if not 0 <= index < len(targets):
            return
        if not lib.assign(app_id, targets[index]):
            _folder_feedback('Could not save the app folder assignment.', failed=True)
            return

    xbmc.executebuiltin('Container.Refresh')

def chooseStreamProfile():
    """Persist a mode preset against this Sunshine host and exact app ID."""
    from resources.lib.util.streamprofiles import ProfileDataError, ProfileCommitError
    try:
        app_id = canonical_app_id(args.get('id', [None])[0])
        store = _stream_profiles()
        # A stale Kodi context menu from another host must never assign
        # the same numeric app ID to the newly selected Sunshine host.
        if args.get('host', [None])[0] != store.key:
            xbmcgui.Dialog().ok(
                'Streaming profile',
                'The selected Sunshine host changed. Reopen its application list.')
            return
        current = store.get(app_id)
        profiles = [None, 'desktop_4k60', 'gaming_1080p120']
        labels = [
            addon.getLocalizedString(30355) or 'Use Luna default settings',
            addon.getLocalizedString(30356) or 'Quality (4K60)',
            addon.getLocalizedString(30357) or 'Performance (1080p120)',
        ]
        chosen = xbmcgui.Dialog().select(
            addon.getLocalizedString(30354) or 'Streaming profile',
            labels, preselect=profiles.index(current))
        if chosen < 0 or chosen >= len(profiles):
            return
        store.set(app_id, profiles[chosen])
    except ProfileCommitError as error:
        logger.error('Streaming profile committed without confirmed durability: %s' % error)
        xbmcgui.Dialog().ok(
            'Streaming profile save warning',
            'The new profile was applied, but saving it across a power loss '
            'could not be confirmed. %s' % error)
        xbmc.executebuiltin('Container.Refresh')
        return
    except (OSError, ValueError, ProfileDataError) as error:
        logger.error('Unable to update Luna streaming profile: %s' % error)
        xbmcgui.Dialog().ok(
            'Streaming profile could not be saved',
            'Saved profiles were left unchanged. %s' % error)
        return
    xbmcgui.Dialog().notification(
        'Streaming profile',
        'Saved: %s' % labels[chosen], time=3000)
    xbmc.executebuiltin('Container.Refresh')


def _active_resume_session():
    """Return the app and its *specific* confirmed host as one guarded value."""
    from resources.lib.util.library import Library
    address = (addon.getSetting('host_addr') or
               config_helper.config.get('host_addr') or '').strip()
    context_key = Library.host_identity(address, _connection_options())
    if not address or addon.getSetting('last_run_host') != context_key:
        return None
    app = addon.getSetting('last_run')
    app_id = addon.getSetting('last_run_id') or ''
    if app_id:
        try:
            app_id = canonical_app_id(app_id)
        except ValueError:
            return None  # Never interpret a damaged saved ID as another app.
    return (app, address, app_id or None,
            context_key) if app else None


def _active_resume_app():
    session = _active_resume_session()
    return session[0] if session else None


def main():
    li = xbmcgui.ListItem((addon.getLocalizedString(30250) or 'Applications'))
    li.setArt({ 'icon': getAddonPath('/resources/icons/apps.png') })
    xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=apps', li, True)

    li = xbmcgui.ListItem(addon.getLocalizedString(30259)
                          or 'List applications')
    li.setArt({ 'icon': getAddonPath('/resources/icons/list.png') })
    xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=quick_play&refresh=True', li)

    lastrun = _active_resume_app()
    if lastrun:
        li = xbmcgui.ListItem((addon.getLocalizedString(30260) or 'Resume %s') % lastrun)
        li.setArt({ 'icon': getAddonPath('/resources/icons/resume.png') })
        xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=resume', li)

        li = xbmcgui.ListItem((addon.getLocalizedString(30261) or 'Quit %s') % lastrun)
        li.setArt({ 'icon': getAddonPath('/resources/icons/quit.png') })
        xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=quit', li)

    # Quit cannot depend exclusively on last_run: a failed RTSP handshake
    # can leave the host's virtual display active before first video.
    if (addon.getSetting('host_addr') or '').strip():
        li = xbmcgui.ListItem('End active host session (restore display)')
        li.setArt({'icon': getAddonPath('/resources/icons/quit.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle, base_url + '?action=end_host_session', li, False)

    li = xbmcgui.ListItem(addon.getLocalizedString(30368)
                          or 'Save local diagnostic report')
    li.setArt({ 'icon': getAddonPath('/resources/icons/list.png') })
    xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=diagnostics', li, False)

    li = xbmcgui.ListItem(xbmc.getLocalizedString(5))
    li.setArt({ 'icon': getAddonPath('/resources/icons/settings.png') })
    xbmcplugin.addDirectoryItem(addon_handle, base_url + '?action=settings', li)

    xbmcplugin.endOfDirectory(addon_handle)

    del li

def pair(expected_address=None, expected_options=None):
    from resources.lib.util.moonlighthelper import MoonlightHelper

    helper = MoonlightHelper(addon, config_helper, logger)
    if expected_address is None:
        helper.pair()
    else:
        helper.pair(expected_address=expected_address,
                    expected_options=expected_options)

    if helper.pair_success:
        selected = (addon.getSetting('host_addr') or '').strip()
        verified = (helper.paired_address or '').strip()
        # Both ordinary Pair and confirmed Re-Pair must preserve the port and
        # keydir used for native pairing. Matching only the IP can otherwise
        # publish an old port's successful PIN as a different host identity.
        from resources.lib.util.hostcontext import host_identity
        try:
            selected_context = host_identity(selected, _connection_options())
        except (OSError, ValueError, TypeError, AttributeError):
            selected_context = None
        if (not selected or verified != selected or not selected_context or
                selected_context != getattr(helper, 'paired_context', None) or
                (expected_address is not None and not
                 _pairing_context_current(expected_address, expected_options))):
            # Do not probe or rewrite a newly selected connection using
            # another connection's completed PIN transaction.
            xbmcgui.Dialog().ok(
                addon.getLocalizedString(30000),
                'Pairing completed for a different host. '
                'Select the host again to verify its pairing status.')
            return False
        # The Kodi editor already saved the host before this action ran.
        # Never re-write host_addr from a native progress message.
        config_helper.configure(dump=False)
        config_helper.dump()
        _clearApplicationListCache()
        _setPairingStatus(True, addon.getLocalizedString(30321) or 'Paired ✓',
                          selected)
    else:
        syncPairingStatus()

    success = helper.pair_success
    del helper
    return success


def rePair():
    from resources.lib.util.moonlighthelper import MoonlightHelper

    config_helper.configure(dump=False)
    address = (addon.getSetting('host_addr') or '').strip()
    # Re-Pair may remain visible during editing because its old Kodi
    # paired_state belongs to the previous IP. Never unpair a newly selected
    # host based on another host's stale status.
    if (not address or addon.getSetting('pair_status_host') != address or
            addon.getSetting('paired_state') != 'true'):
        return pair()

    options = dict(_connection_options())
    helper = MoonlightHelper(addon, config_helper, logger)
    helper._frozen_host_options = dict(options)
    host = helper._host(address)  # Respect confirmation-time port and keydir.
    if not host.has_trusted_pin():
        return pair()
    try:
        if not host.pair_status():
            return pair()
    except Exception as error:
        syncPairingStatus()
        xbmcgui.Dialog().ok(
            addon.getLocalizedString(30000),
            'Cannot verify the existing pairing for %s: %s' %
            (address, error))
        return False

    if not xbmcgui.Dialog().yesno(
            addon.getLocalizedString(30000),
            'Replace the existing pairing for %s? This disconnects the '
            'currently paired session.' % address,
            nolabel='Cancel', yeslabel='Re-pair'):
        return False

    if not _confirmed_pairing_action_allowed(address, options):
        return False

    if not helper.unpair(expected_address=address, expected_options=options):
        message = helper.last_unpair_error or (
            addon.getLocalizedString(30334)
            or 'Unable to re-pair because the existing host could not be unpaired.')
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), message)
        if _pairing_context_current(address, options):
            syncPairingStatus()
        return False

    if not _pairing_context_current(address, options):
        xbmcgui.Dialog().ok(
            'Sunshine host changed',
            'Unpair completed for %s, but the selected connection changed '
            'before PIN re-pairing. The new host was not modified. '
            'Select the original host again to finish pairing.' % address)
        return False
    _clearApplicationListCache()
    _setPairingStatus(False, addon.getLocalizedString(30322) or 'Not paired',
                      address)
    return pair(expected_address=address, expected_options=options)


def unpairHost():
    from resources.lib.util.moonlighthelper import MoonlightHelper

    config_helper.configure(dump=False)
    address = addon.getSetting('host_addr') or config_helper.config.get('host_addr')
    if not address:
        syncPairingStatus()
        return False
    address = address.strip()
    options = dict(_connection_options())

    confirmed = xbmcgui.Dialog().yesno(
        addon.getLocalizedString(30000),
        (addon.getLocalizedString(30331) or 'Unpair from %s?') % address,
        nolabel=xbmc.getLocalizedString(106),
        yeslabel=xbmc.getLocalizedString(107))
    if not confirmed or not _confirmed_pairing_action_allowed(address, options):
        return False

    helper = MoonlightHelper(addon, config_helper, logger)
    success = helper.unpair(expected_address=address,
                            expected_options=options)
    if success:
        if not _pairing_context_current(address, options):
            xbmcgui.Dialog().ok(
                addon.getLocalizedString(30000),
                'Unpair completed for %s, but the selected connection '
                'changed. Its status was not applied to the new host.' % address)
            return True
        _clearApplicationListCache()
        unverified = getattr(helper, 'last_unpair_unverified', False)
        _setPairingStatus(
            False,
            ('Unpair request completed; status unverified' if unverified
             else (addon.getLocalizedString(30322) or 'Not paired')),
            address)
        xbmcgui.Dialog().ok(
            addon.getLocalizedString(30000),
            ('The native unpair request completed, but Sunshine pairing '
             'status could not be authenticated. Verify the paired devices '
             'in Sunshine before assuming this client was removed.'
             if unverified else
             (addon.getLocalizedString(30332) or 'Host unpaired')))
    else:
        xbmcgui.Dialog().ok(
            addon.getLocalizedString(30000),
            helper.last_unpair_error
            or addon.getLocalizedString(30333)
            or 'Unable to unpair from host.')
        if _pairing_context_current(address, options):
            syncPairingStatus()
    del helper
    return success


def forgetTrustedServer():
    from resources.lib.util.moonlighthelper import MoonlightHelper

    config_helper.configure(dump=False)
    address = (addon.getSetting('host_addr')
               or config_helper.config.get('host_addr') or '').strip()
    if not address:
        xbmcgui.Dialog().ok('Trusted server certificate',
                            'Select a Sunshine host before forgetting its certificate.')
        return False
    options = dict(_connection_options())

    if not xbmcgui.Dialog().yesno(
            'Forget trusted server certificate?',
            ('Remove saved trust for %s?\n\n'
             'Your client keys and Sunshine pairing remain intact. '
             'Proceed only when you expect the server key to have changed. '
             'A new PIN-verified pairing is required afterward.') % address,
            nolabel='Cancel', yeslabel='Forget certificate'):
        return False
    if not _confirmed_pairing_action_allowed(address, options):
        return False
    helper = MoonlightHelper(addon, config_helper, logger)
    if not helper.forget_trusted_server(address, expected_options=options):
        xbmcgui.Dialog().ok('Trusted server certificate',
                            helper.last_trust_error or 'Unable to forget this host.')
        return False
    if not _pairing_context_current(address, options):
        xbmcgui.Dialog().ok(
            'Trusted server certificate',
            'Trust was cleared for %s, but the selected connection changed. '
            'The new host\'s status was not modified.' % address)
        return True
    _clearApplicationListCache()
    _setPairingStatus(False, 'Host trust cleared; PIN re-pair required',
                      address)
    xbmcgui.Dialog().ok(
        'Trusted server certificate',
        'Saved trust for %s was cleared. Use Re-Pair Host to authenticate '
        'the new server key. If Sunshine refuses an existing pairing, '
        'remove this client in Sunshine and try again.' % address)
    return True


def pairFromApplications():
    # A failed application-list request does NOT revoke an existing pairing.
    # Re-verify/retry once; only an actually unpaired host needs the PIN flow.
    if syncPairingStatus():
        retryApplications()
    elif pair():
        retryApplications()

def quickPlay():
    from resources.lib.util.moonlighthelper import MoonlightHelper

    helper = MoonlightHelper(addon, config_helper, logger)
    from resources.lib.util.resumestate import host_identity
    selected_host = helper._host_identity(config_helper.config.get('host_addr'))
    detailed = helper.list_games_detailed()
    if detailed is None:
        detailed = helper.list_games_native_detailed()
    if detailed is not None:
        if not detailed:
            xbmcgui.Dialog().ok(addon.getLocalizedString(30000),
                                'Sunshine returned no applications.')
            return
        items = []
        for _, name, art in detailed:
            li = xbmcgui.ListItem(name)
            if art:
                li.setArt({'icon': art, 'thumb': art, 'poster': art})
            items.append(li)

        chosen = xbmcgui.Dialog().select((addon.getLocalizedString(30250) or 'Applications'), items, useDetails=True)
        if chosen != -1:
            helper.launch_game(detailed[chosen][1], app_id=detailed[chosen][0], expected_host=selected_host)

        xbmc.executebuiltin('Container.Refresh')
        del helper
        return


    # Do not fall back to native name-only listing. On legacy binaries
    # that action can target a different Sunshine host via stale config or
    # autodiscovery, and its row numbers are not stable application IDs.
    xbmcgui.Dialog().ok(
        addon.getLocalizedString(30000),
        helper.last_host_error or
        'Could not verify application IDs for the selected Sunshine host. '
        'Reconnect or update the Luna NG native client and try again.')
    del helper

def resume():
    from resources.lib.util.moonlighthelper import MoonlightHelper
    session = _active_resume_session()
    if not session:
        xbmcgui.Dialog().notification(addon.getLocalizedString(30000),
                                      'No confirmed Resume session for this host.', time=5000)
        return
    confirmed = xbmcgui.Dialog().yesno(
        '', (addon.getLocalizedString(30262) or 'Continue'),
        nolabel=xbmc.getLocalizedString(106),
        yeslabel=xbmc.getLocalizedString(107), autoclose=5000)
    if confirmed and _active_resume_session() == session:
        helper = MoonlightHelper(addon, config_helper, logger)
        helper.launch_game(session[0], resume=True, app_id=session[2],
                           expected_host=session[3])
        del helper

def quitgame():
    from resources.lib.util.moonlighthelper import MoonlightHelper
    session = _active_resume_session()
    if not session:
        xbmcgui.Dialog().notification(addon.getLocalizedString(30000),
                                      'No confirmed Quit session for this host.', time=5000)
        return
    confirmed = xbmcgui.Dialog().yesno(
        '', (addon.getLocalizedString(30263) or 'Confirm to quit'),
        nolabel=xbmc.getLocalizedString(106),
        yeslabel=xbmc.getLocalizedString(107), autoclose=5000)
    if confirmed and _active_resume_session() == session:
        helper = MoonlightHelper(addon, config_helper, logger)
        # Pass the captured host explicitly; never infer Quit's target from
        # moonlight.conf, which might still point to a previous server.
        if helper._host_identity(session[1]) != session[3]:
            return
        if helper.quit_game(session[1]):
            # Do not clear a newer saved session if the settings changed while
            # the native Quit command was running.
            if _active_resume_session() == session:
                addon.setSettingString('last_run', '')
                addon.setSettingString('last_run_host', '')
                addon.setSettingString('last_run_id', '')
            xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30017))
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmcgui.Dialog().ok(
                addon.getLocalizedString(30000),
                'Unable to quit the remote session. Resume has been preserved.')


def endHostSession():
    """Explicit, host-verified recovery Quit, independent of saved last_run.

    Moonlight may fail after Sunshine accepts the game, but before Luna's
    first-video receipt persists Resume state. This action lets the user end
    the live host session without relaunching Kodi/Moonlight or restarting
    Windows. Never change the host automatically after a stream failure.
    """
    from resources.lib.util.hostcontext import host_identity
    from resources.lib.util.moonlighthelper import MoonlightHelper

    address = (addon.getSetting('host_addr') or '').strip()
    if not address:
        xbmcgui.Dialog().ok('End host session',
                            'Select your Sunshine/Vibepollo host first.')
        return False
    try:
        config_helper.configure(dump=False)
        options = dict(_connection_options())
        context = host_identity(address, options)
        if not _pairing_context_current(address, options):
            xbmcgui.Dialog().ok(
                'Host connection changed',
                'The selected host, port or pairing directory changed. '
                'No Quit request was sent.')
            return False
        helper = MoonlightHelper(addon, config_helper, logger)
        binary_path = config_helper.binary_path
        if not binary_path or not helper._is_coreelec_ng(binary_path):
            xbmcgui.Dialog().ok(
                'End host session unavailable',
                'This recovery command requires bundled Luna NG Moonlight.')
            return False
        helper._frozen_host_options = dict(options)
        helper._selected_address = address
        # Both app-status probes and native quit use one host/port/keydir
        # snapshot, not a later mutable moonlight.conf value.
        with helper._native_host_command('quit', address) as (_command, env):
            snapshot = env['LUNA_STREAM_CONFIG']
            running, error = helper._running_ng_app(
                binary_path, env, '0', timeout_seconds=8)
            if error:
                xbmcgui.Dialog().ok(
                    'Cannot verify host session',
                    'No Quit was sent because the host application state '
                    'could not be verified. ' + error)
                return False
            if not running or running == '0':
                xbmcgui.Dialog().ok(
                    'No running host application',
                    'The host reports no running application. No Quit was '
                    'sent. If the physical monitor is still black, use '
                    'Vibepollo virtual-display recovery on Windows.')
                return False
            old_state = (addon.getSetting('last_run'),
                         addon.getSetting('last_run_id'),
                         addon.getSetting('last_run_host'))
            if not xbmcgui.Dialog().yesno(
                    'End active host session?',
                    'Vibepollo/Sunshine reports application ID %s running. '
                    'End it and request display restoration? This can close '
                    'the game/desktop and affect other streaming clients.' %
                    running,
                    nolabel='Keep running', yeslabel='End session'):
                return False
            if not _pairing_context_current(address, options):
                xbmcgui.Dialog().ok(
                    'Host connection changed',
                    'Host, port or pairing directory changed during '
                    'confirmation. No Quit request was sent.')
                return False
            # Refuse to end a different app that became active while the
            # confirmation dialog was open.
            current, error = helper._running_ng_app(
                binary_path, env, '0', timeout_seconds=8)
            if error or current != running:
                xbmcgui.Dialog().ok(
                    'Host session changed',
                    'The host app changed or could not be verified. '
                    'No Quit request was sent.')
                return False
            if not helper.quit_game(address, snapshot=snapshot):
                xbmcgui.Dialog().ok(
                    'Unable to end host session',
                    'The host did not confirm the Quit request. '
                    'Saved Resume state was preserved.')
                return False
            stopped, _stop_error = helper._wait_for_ng_app_stopped(
                binary_path, env, '0', seconds=5.0)
            if not stopped:
                xbmcgui.Dialog().ok(
                    'Host Quit sent',
                    'The host accepted Quit but has not confirmed that the '
                    'application stopped. Check Vibepollo and retry if needed. '
                    'Saved Resume state was preserved.')
                return False
            # Clear only the exact saved state we observed, and only if it
            # belongs to this still-selected host. Never erase another
            # launcher invocation's more recent Resume state.
            if (_pairing_context_current(address, options) and
                    old_state[2] == context and
                    old_state == (addon.getSetting('last_run'),
                                  addon.getSetting('last_run_id'),
                                  addon.getSetting('last_run_host'))):
                addon.setSettingString('last_run', '')
                addon.setSettingString('last_run_id', '')
                addon.setSettingString('last_run_host', '')
            xbmcgui.Dialog().ok(
                'Host session ended',
                'The host now reports no running application. '
                'Vibepollo should release the virtual display; confirm '
                'your physical monitor is restored.')
            xbmc.executebuiltin('Container.Refresh')
            return True
    except (OSError, ValueError, TypeError, RuntimeError) as error:
        logger.error('LUNA host session recovery failed: %s' %
                     type(error).__name__)
        xbmcgui.Dialog().ok(
            'End host session failed',
            'Luna could not safely verify or end the selected host session. '
            'Check Vibepollo before retrying.')
        return False


def unpairByKey():
    from resources.lib.util.hostcontext import default_key_dir, remove_pairing_keys
    directory = _connection_options().get('keydir', default_key_dir())
    if not xbmcgui.Dialog().yesno(
            '', addon.getLocalizedString(30279) + '\n' + directory,
            nolabel=xbmc.getLocalizedString(106), yeslabel=xbmc.getLocalizedString(107)):
        return
    try:
        removed = remove_pairing_keys(directory)
    except FileNotFoundError:
        removed = 0
    except OSError as error:
        xbmcgui.Dialog().ok('Pairing keys', 'Could not remove pairing keys: %s' % error)
        return
    xbmcgui.Dialog().ok('', addon.getLocalizedString(30280 if removed else 30281))

class SettingsPersistenceError(Exception):
    pass


def _persistSettingXml(ident, value):
    """Synchronize explicitly changed settings while Kodi settings is open."""
    from resources.lib.util.settingsstore import update_setting
    path = translatePath('special://profile/addon_data/%s/settings.xml'
                         % addon.getAddonInfo('id'))
    try:
        update_setting(path, ident, value)
    except (OSError, ValueError, TimeoutError, ElementTree.ParseError) as error:
        logger.error('failed to update %s in %s: %s' % (ident, path, error))
        raise SettingsPersistenceError('Could not persist Luna setting: %s' % ident) from error


def persistSetting(ident, value):
    dialog_open = xbmc.getCondVisibility('Window.IsActive(addonsettings)')
    if not dialog_open and addon.getSetting(ident) == value:
        return
    addon.setSettingString(ident, value)
    if dialog_open:
        _persistSettingXml(ident, value)


def persistBoolSetting(ident, value):
    dialog_open = xbmc.getCondVisibility('Window.IsActive(addonsettings)')
    addon.setSettingBool(ident, bool(value))
    if dialog_open:
        _persistSettingXml(ident, 'true' if value else 'false')


def selectAudioDevice():
    from resources.lib.util import audiodevices

    devices = audiodevices.list_playback(force=True)
    if not devices:
        xbmcgui.Dialog().ok(xbmc.getLocalizedString(257),
                            addon.getLocalizedString(30219))
        return

    busy = addon.getLocalizedString(30217) or 'Busy'
    labels = [audiodevices.describe(d, busy) for d in devices]

    index = xbmcgui.Dialog().select(addon.getLocalizedString(30037), labels)
    if index == -1:
        return

    chosen = devices[index]
    if chosen['busy']:
        confirmed = xbmcgui.Dialog().yesno(
            xbmc.getLocalizedString(14117), addon.getLocalizedString(30218),
            nolabel=xbmc.getLocalizedString(106),
            yeslabel=xbmc.getLocalizedString(107))
        if not confirmed:
            return

    persistSetting('audio_device_parameter', chosen['alsa'])
    persistSetting('audio_device_display', chosen['name'])

    multichannel = audiodevices.multichannel(chosen['alsa'])
    persistSetting('audio_multichannel',
                   'true' if multichannel else 'false')
    if multichannel is False and addon.getSetting('surround') != 'false':
        persistSetting('surround', 'false')
        xbmcgui.Dialog().ok(addon.getLocalizedString(30047),
                            addon.getLocalizedString(30266))

def setInputRows(names):
    persistSetting(
        'input_devices_display',
        addon.getLocalizedString(30276 if names else 30272))

def selectInputDevices():
    from resources.lib.util import inputdevices

    all_devices = inputdevices.list_devices()
    invalid_selection = False
    try:
        saved = inputdevices.load_selectors(addon)
    except inputdevices.InvalidInputSelection as error:
        logger.error('Luna saved controller selection is invalid: %s' % error)
        xbmcgui.Dialog().ok(
            'Controller selection needs repair',
            'The saved controller selection is invalid. Reselect your '
            'controllers here (or clear them) to repair it.')
        saved = []
        invalid_selection = True

    options = inputdevices.picker_options(all_devices, saved)
    if not options:
        if invalid_selection:
            if xbmcgui.Dialog().yesno(
                    'Clear invalid controller selection?',
                    'No controllers are currently available. Clear the '
                    'invalid saved selection to restore automatic input?'):
                persistSetting('input_device_selectors_v2',
                               inputdevices.serialize_selectors([]))
                persistSetting('input_devices', '')
                setInputRows([])
        else:
            xbmcgui.Dialog().ok(addon.getLocalizedString(30269),
                                addon.getLocalizedString(30273))
        return

    kinds = {'keyboard': addon.getLocalizedString(30292),
             'mouse':    addon.getLocalizedString(30293),
             'gamepad':  addon.getLocalizedString(30294),
             'other':    addon.getLocalizedString(30295)}
    labels = []
    for option in options:
        device = option['device']
        identity = option['selector']
        if option.get('group'):
            label = identity['name'] + ' [all same-name devices]'
            if option['offline']:
                label += ' [offline]'
        elif option['offline']:
            label = identity['name'] + ' [offline]'
        else:
            label = inputdevices.describe(device, kinds,
                                          addon.getLocalizedString(30296))
        same_name_count = sum(d['name'] == identity['name'] for d in all_devices)
        if not option.get('group') and (
                identity['kind'] == 'N' or same_name_count > 1 or
                option['offline']):
            if identity['kind'] == 'N':
                label += ' [all same-name devices]'
            else:
                detail = identity.get('phys') or identity['value']
                label += ' [%s: ...%s]' % (
                    'port' if identity['kind'] == 'P' else 'device',
                    detail[-12:])
        labels.append(label)

    preselect = [i for i, option in enumerate(options) if option['selected']]
    chosen = xbmcgui.Dialog().multiselect(addon.getLocalizedString(30269),
                                          labels, preselect=preselect)
    if chosen is None:
        return

    records = [options[i]['selector'] for i in chosen]
    # A name-only selector also admits controllers connected in the future.
    # Require explicit acknowledgment when it is newly selected because the
    # device has no reliable individual identity.
    new_groups = sorted({entry['name'] for entry in records
                         if entry['kind'] == 'N' and entry not in saved})
    try:
        inputdevices.resolve_selectors(records, all_devices)
        serialized = inputdevices.serialize_selectors(records)
    except inputdevices.InputPathLimitExceeded as error:
        xbmcgui.Dialog().ok('Too many selected input devices', str(error))
        return
    except inputdevices.InvalidInputSelection as error:
        xbmcgui.Dialog().ok('Controller selection could not be saved', str(error))
        return
    if new_groups and not xbmcgui.Dialog().yesno(
            'Select all matching controllers?',
            'These devices cannot be uniquely identified. Selecting '
            'a name group also allows any future controllers with the '
            'same name: %s. Continue?' % ', '.join(new_groups)):
        return
    names = [entry['name'] for entry in records]
    persistSetting('input_device_selectors_v2', serialized)
    persistSetting('input_devices', '|'.join(names))
    setInputRows(names)

# A manual diagnostic report must remain usable even when native configuration,
# Kodi audio restoration, or network services are unhealthy. Open its progress
# UI before any normal Luna initialization that can delay the action.
if args.get('action', [None])[0] == 'diagnostics':
    saveDiagnosticReport()
    if addon_handle >= 0:
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    sys.exit(0)

ensurePermissions()
config_helper = ConfigHelper(addon, logger)

# Remove expired and old plaintext-URI seek records on every Luna startup.
# Recovery cleanup must never prevent a normal addon action.
try:
    from resources.lib.util.kodirestore import cleanup_expired_seek
    cleanup_expired_seek()
except (OSError, RuntimeError, TypeError, ValueError) as error:
    logger.info('Luna deferred seek cleanup unavailable: %s' %
                type(error).__name__)

# Clearing saved_streamsilence requires a successful Kodi JSON-RPC write and
# readback; a transport-level JSON response may still contain an error.
from resources.lib.util.kodiaudio import restore_saved_streamsilence
if not restore_saved_streamsilence(addon):
    logger.info('LUNA audio: keepalive restoration pending; backup retained')

# After deferred Kodi seek cleanup and audio keepalive recovery, abort normal
# pairing/stream actions for an old or invalid shared moonlight.conf.
# Diagnostics and deferred Kodi playback restoration remain available.
if (config_helper.config_error is not None and
        args.get('action', [None])[0] not in ('diagnostics', 'restore_seek', 'settings')):
    showMoonlightConfigRecovery(config_helper.config_error)
    if addon_handle >= 0:
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    sys.exit(0)

# After restoring Kodi state and validating Moonlight configuration, the
# executable check can safely stop ordinary actions without hiding either.
if (config_helper.binary_path is None and
        args.get('action', [None])[0] not in ('diagnostics', 'restore_seek', 'settings')):
    xbmcgui.Dialog().ok(addon.getLocalizedString(30283),
                        addon.getLocalizedString(30284))
    sys.exit(0)

try:
    from resources.lib.util import audiodevices as _audiodevices
    _names = [n for n in addon.getSetting('input_devices').split('|') if n]
    setInputRows(_names)

    _device = addon.getSetting('audio_device_parameter')
    if _device and args.get('action', [None])[0] in ('settings', 'select_audio_device'):
        persistSetting('audio_device_display', _audiodevices.pretty(_device))
        persistSetting(
            'audio_multichannel',
            'true' if _audiodevices.multichannel(_device) else 'false')
except Exception:
    pass

# ConfigHelper performs the one-time native-host import. Never resurrect
# moonlight.conf's old address after Kodi has committed an empty host.
version = xbmcaddon.Addon().getAddonInfo('version')
if version != addon.getSetting('addon_version'):
    addon.setSetting('addon_version', version)

try:
    handled_directory = False

    if 'action' in args:
        action = args['action'][0]
        if action == 'quick_play':
            quickPlay()
        elif action == 'launch':
            launchByName()
        elif action == 'refresh':
            refreshGames()
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            handled_directory = True
        elif action == 'apps':
            showApps(args.get('folder', [None])[0])
            handled_directory = True
        elif action == 'newfolder':
            newFolder()
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            xbmc.executebuiltin('Container.Refresh')
            handled_directory = True
        elif action == 'assign':
            assignApp()
        elif action == 'streamprofile':
            chooseStreamProfile()
        elif action == 'renfolder':
            renameFolder()
        elif action == 'delfolder':
            deleteFolder()
        elif action == 'resume':
            resume()
        elif action == 'quit':
            quitgame()
        elif action == 'end_host_session':
            endHostSession()
        elif action == 'pair_host':
            pair()
        elif action == 'repair_host':
            rePair()
        elif action == 'unpair_host':
            unpairHost()
        elif action == 'forget_trusted_server':
            forgetTrustedServer()
        elif action == 'retry_apps':
            retryApplications()
        elif action == 'pair_from_apps':
            pairFromApplications()
        elif action == 'select_audio_device':
            selectAudioDevice()
        elif action == 'select_input_devices':
            selectInputDevices()
        elif action == 'unpair_by_key':
            unpairByKey()
        elif action == 'restore_seek':
            from resources.lib.util.kodirestore import retry_pending_seek
            retry_pending_seek(args.get('token', [None])[0])
            # AlarmClock uses RunPlugin, not a navigable Kodi directory.
            handled_directory = True
        elif action == 'settings':
            settings()

    if addon_handle != -1 and not handled_directory:
        main()

except SettingsPersistenceError as error:
    xbmcgui.Dialog().ok('Settings could not be saved', str(error))
except MoonlightConfigFormatError as error:
    # The config may have changed after the initial read, including during
    # a settings write. Never retry a dangerous/ambiguous rewrite.
    showMoonlightConfigRecovery(error)
    if addon_handle >= 0:
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
except LibraryDataError as error:
    logger.error('Luna saved folders cannot be read: %s' % error)
    xbmcgui.Dialog().ok('Saved folders need recovery',
                        'Your saved folders could not be read. Luna has not '
                        'overwritten folders.json. Restore it from backup or '
                        'repair the file before changing folders.')
    if addon_handle >= 0 and args.get('action', [None])[0] == 'apps':
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
except InvalidInputSelection as error:
    logger.error('Luna saved controller selection prevented action: %s' % error)
    xbmcgui.Dialog().ok(
        'Controller selection needs repair',
        'The saved controller identities are invalid. No controller selection '
        'was applied. Open Luna Settings, select Input Devices, and reselect '
        'or clear controllers before retrying.')

del addon
del logger
del config_helper
