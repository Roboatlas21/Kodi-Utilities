Luna NG version: 2.7.1.321
Luna commit: 68d829c1b816d6d4975c622f77eec8201766b185
Moonlight native commit: 8f92b091ffc02f51a578f06c8da56f595f45bbb6
Moonlight native run: 41674551897
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
