#!/bin/sh
set -u
BIN="${MOONLIGHT_BINARY:-moonlight}"
LOG="${LUNA_LOG_DIR:-/storage/.kodi/userdata/addon_data/script.luna}/logfile"
VFM_MAP="${LUNA_VFM_MAP:-/sys/class/vfm/map}"
VIDEO_DISABLE="${LUNA_VIDEO_DISABLE:-/sys/class/video/disable_video}"
VDEC_STATUS="${LUNA_VDEC_STATUS:-/sys/class/vdec/vdec_status}"
SYSTEMCTL="${LUNA_SYSTEMCTL:-systemctl}"
SYSTEMD_RUN="${LUNA_SYSTEMD_RUN:-systemd-run}"
KILLALL="${LUNA_KILLALL:-killall}"
KODI_UNIT="${LUNA_KODI_UNIT:-kodi.service}"
SESSION_UNIT="${LUNA_SESSION_UNIT:-luna-ng-session.service}"
STARTUP_TIMEOUT="${LUNA_STARTUP_TIMEOUT:-20}"
case "$STARTUP_TIMEOUT" in
  ''|*[!0-9]*) STARTUP_TIMEOUT=20 ;;
esac
if [ "$STARTUP_TIMEOUT" -lt 5 ] || [ "$STARTUP_TIMEOUT" -gt 120 ]; then
  STARTUP_TIMEOUT=20
fi
mkdir -p "$(dirname "$LOG")" || exit 1

for command in "$BIN" "$SYSTEMCTL" "$SYSTEMD_RUN" "$KILLALL"; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Required executable not found: $command" >&2
    exit 127
  fi
done

scripts="$(CDPATH='' cd "$(dirname "$0")" && pwd)" || exit 1
bin_dir=''
case "$BIN" in
  */*)
    bin_dir="$(CDPATH='' cd "$(dirname "$BIN")" && pwd)" || {
      echo "Moonlight binary directory is unavailable: $BIN" >&2
      exit 127
    }
    ;;
esac
if [ ! -r "$scripts/kodi-watchdog.sh" ]; then
  echo "Missing Kodi recovery watchdog" >&2
  exit 126
fi

session="$(mktemp "$(dirname "$LOG")/.luna-session.XXXXXXXX")" || exit 1
printf '0\n' > "$session" || exit 1
watchdog_unit="luna-ng-watchdog-$$"
child=''
kodi_stopped=0

restore_kodi_framebuffers() {
  for blank in "${LUNA_FB0_BLANK:-/sys/class/graphics/fb0/blank}" \
               "${LUNA_FB1_BLANK:-/sys/class/graphics/fb1/blank}"; do
    [ -e "$blank" ] || continue
    if [ -w "$blank" ]; then
      printf '0' > "$blank" 2>/dev/null || \
        echo "Failed to unblank Kodi framebuffer: $blank" >&2
    else
      echo "Kodi framebuffer blank control is not writable: $blank" >&2
    fi
  done
}

child_running() {
  [ -n "$child" ] || return 1
  [ -r "/proc/$child/stat" ] || return 1
  line="$(cat "/proc/$child/stat" 2>/dev/null)" || return 1
  fields="${line##*) }"
  state="${fields%% *}"
  case "$state" in Z|X|x) return 1 ;; esac
  kill -0 "$child" 2>/dev/null
}

terminate_orphaned_moonlight() {
  [ -n "$BIN" ] || return 0
  case "$BIN" in /*) expected="$BIN" ;; *) expected="$(command -v "$BIN" 2>/dev/null || printf '%s' "$BIN")" ;; esac

  found=0
  for exe in /proc/[0-9]*/exe; do
    target="$(readlink "$exe" 2>/dev/null)" || continue
    [ "$target" = "$expected" ] || continue
    pid="${exe#/proc/}"
    pid="${pid%/exe}"
    [ "$pid" = "$" ] && continue
    found=1
    echo "Luna NG: terminating orphaned Moonlight pid $pid before Kodi restart" >> "$LOG"
    kill -TERM "$pid" 2>/dev/null || true
  done

  [ "$found" -eq 1 ] || return 0
  sleep 1

  for exe in /proc/[0-9]*/exe; do
    target="$(readlink "$exe" 2>/dev/null)" || continue
    [ "$target" = "$expected" ] || continue
    pid="${exe#/proc/}"
    pid="${pid%/exe}"
    [ "$pid" = "$" ] && continue
    echo "Luna NG: force-killing orphaned Moonlight pid $pid" >> "$LOG"
    kill -KILL "$pid" 2>/dev/null || true
  done
}

reset_moonlight_video_plane() {
  if [ -e "$VIDEO_DISABLE" ]; then
    if [ -w "$VIDEO_DISABLE" ]; then
      printf '1' > "$VIDEO_DISABLE" 2>/dev/null ||         echo "Luna NG: failed to disable Amlogic video plane" >> "$LOG"
    else
      echo "Luna NG: Amlogic video disable control is not writable" >> "$LOG"
    fi
  fi

  if [ -r "$VDEC_STATUS" ] && ! grep -Fq 'No vdec.' "$VDEC_STATUS" 2>/dev/null; then
    attempt=0
    while [ "$attempt" -lt 3 ]; do
      sleep 1
      grep -Fq 'No vdec.' "$VDEC_STATUS" 2>/dev/null && return 0
      attempt=$((attempt + 1))
    done
    echo "Luna NG: decoder still active after Moonlight teardown" >> "$LOG"
  fi
}

startup_ready() {
  [ -n "$child" ] || return 1

  # Input initialization happens immediately after gs_init() succeeds and
  # before the stream connection starts. Seeing any evdev fd therefore proves
  # Moonlight is no longer stuck in Sunshine HTTP/HTTPS startup.
  for fd in /proc/"$child"/fd/*; do
    target="$(readlink "$fd" 2>/dev/null)" || continue
    case "$target" in
      /dev/input/event[0-9]*) return 0 ;;
    esac
  done

  # View-only or unusual input configurations may not open evdev. An active
  # Amlogic decoder is also sufficient proof that startup completed.
  if [ -r /sys/class/vdec/vdec_status ] &&
     ! grep -Fq 'No vdec.' /sys/class/vdec/vdec_status 2>/dev/null; then
    return 0
  fi

  return 1
}

vfm_write() {
  if [ -n "${LUNA_VFM_WRITE_HELPER:-}" ]; then
    "$LUNA_VFM_WRITE_HELPER" "$VFM_MAP" "$1"
  else
    printf '%s' "$1" > "$VFM_MAP"
  fi
}

ensure_ng_vfm_route() {
  case "$BIN" in
    */coreelec-ng/moonlight) ;;
    *) return 0 ;;
  esac

  [ -r "$VFM_MAP" ] || return 0
  [ -w "$VFM_MAP" ] || {
    echo "Luna NG: VFM map is not writable: $VFM_MAP" >&2
    return 1
  }

  default_line="$(grep 'default[[:space:]]*{' "$VFM_MAP" 2>/dev/null | head -n 1)"
  [ -n "$default_line" ] || return 0

  if ! printf '%s\n' "$default_line" | \
       grep -Eq 'default[[:space:]]*\{[[:space:]]*\}'; then
    return 0
  fi

  if ! vfm_write 'rm default' || \
     ! vfm_write 'add default decoder amvideo'; then
    echo "Luna NG: failed to install decoder -> amvideo VFM route" >&2
    return 1
  fi

  default_line="$(grep 'default[[:space:]]*{' "$VFM_MAP" 2>/dev/null | head -n 1)"
  if ! printf '%s\n' "$default_line" | \
       grep -Eq 'default[[:space:]]*\{[[:space:]]*decoder(\([01]\))?[[:space:]]+amvideo[[:space:]]*\}'; then
    echo "Luna NG: decoder -> amvideo VFM route was not confirmed" >&2
    return 1
  fi

  echo "Luna NG: installed decoder -> amvideo VFM route" >> "$LOG"
}

cleanup() {
  rc=$?
  trap - 0

  if [ -n "$child" ] && kill -0 "$child" 2>/dev/null; then
    kill -TERM "$child" 2>/dev/null || true
    wait "$child" 2>/dev/null || true
  fi

  # Do not return display ownership to Kodi while an exact copy of Luna's
  # Moonlight binary is still alive. This catches descendants that escaped
  # the shell's direct child PID bookkeeping.
  terminate_orphaned_moonlight

  # CoreELEC NG's idle state has amvideo disabled. Moonlight enables it for
  # direct VPU output; restore the idle state even if native teardown failed.
  reset_moonlight_video_plane
  restore_kodi_framebuffers

  if [ "$kodi_stopped" -eq 1 ]; then
    if "$SYSTEMCTL" start "$KODI_UNIT"; then
      printf '0\n' > "$session" 2>/dev/null || true
      rm -f "$session" "$session.ready"
    else
      echo "Luna NG: Kodi restart failed; recovery watchdog remains armed" >&2
    fi
  else
    rm -f "$session" "$session.ready"
  fi

  exit "$rc"
}
trap cleanup 0
trap 'exit 129' 1
trap 'exit 130' 2
trap 'exit 143' 15

if [ -f "$LOG" ]; then mv -f "$LOG" "$LOG.old" 2>/dev/null || true; fi

# The watchdog is a separate transient service, so it survives even if this
# session process is killed. It restarts Kodi only when the armed marker says
# Luna stopped Kodi and this session unit disappears unexpectedly.
if ! "$SYSTEMD_RUN" --unit="$watchdog_unit" --collect --quiet --no-block \
    /usr/bin/env \
      "LUNA_SYSTEMCTL=$SYSTEMCTL" \
      "LUNA_KODI_UNIT=$KODI_UNIT" \
      "LUNA_FB0_BLANK=${LUNA_FB0_BLANK:-/sys/class/graphics/fb0/blank}" \
      "LUNA_FB1_BLANK=${LUNA_FB1_BLANK:-/sys/class/graphics/fb1/blank}" \
      /bin/sh "$scripts/kodi-watchdog.sh" "$SESSION_UNIT" "$session"; then
  echo "Unable to start Luna NG Kodi recovery watchdog" >&2
  exit 1
fi

ready=0
tries=0
while [ "$tries" -lt 30 ]; do
  if [ -r "$session.ready" ]; then
    ready=1
    break
  fi
  tries=$((tries + 1))
  sleep 0.1
done
if [ "$ready" -ne 1 ]; then
  echo "Kodi recovery watchdog did not initialize; refusing to stop Kodi" >&2
  exit 1
fi

if "$SYSTEMCTL" is-active --quiet "$KODI_UNIT"; then
  kodi_stopped=1
  printf '1\n' > "$session"

  # Do not let Kodi perform its normal application shutdown here. A graceful
  # kodi.bin exit can execute the user's CEC shutdown action and put the TV
  # into standby just because Luna is starting. Kill only kodi.bin first so
  # evdev/audio/CEC resources are released without Kodi's shutdown callbacks,
  # then stop the wrapper service immediately to cancel Restart=always.
  "$KILLALL" -KILL kodi.bin 2>/dev/null || true

  if ! "$SYSTEMCTL" stop "$KODI_UNIT"; then
    echo "Luna NG: failed to stop $KODI_UNIT" >&2
    exit 1
  fi

  # Kodi owned the GUI/OSD KMS plane before this handoff. CoreELEC 21 NG
  # cannot use Vortex's CE22 pidfd_getfd DRM-fd borrowing path, so authorize
  # Moonlight's OSD renderer to reuse that attached ARGB overlay only while
  # Kodi is explicitly stopped by this launcher.
  export MOONLIGHT_OSD_TAKEOVER=1
else
  unset MOONLIGHT_OSD_TAKEOVER
fi

if ! ensure_ng_vfm_route; then
  echo "Refusing to start Moonlight without a usable Luna NG video route" >&2
  exit 1
fi

if [ -n "$bin_dir" ]; then
  cd "$bin_dir" || {
    echo "Unable to enter Moonlight binary directory: $bin_dir" >&2
    exit 1
  }
fi

"$BIN" stream -app "$@" >> "$LOG" 2>&1 &
child=$!

elapsed=0
while child_running && [ "$elapsed" -lt "$STARTUP_TIMEOUT" ]; do
  if startup_ready; then
    break
  fi
  sleep 1
  elapsed=$((elapsed + 1))
done

if child_running && ! startup_ready; then
  echo "Luna NG: Moonlight startup timed out after ${STARTUP_TIMEOUT}s; restoring Kodi" >> "$LOG"
  kill -TERM "$child" 2>/dev/null || true
  grace=0
  while child_running && [ "$grace" -lt 3 ]; do
    sleep 1
    grace=$((grace + 1))
  done
  child_running && kill -KILL "$child" 2>/dev/null || true
  wait "$child" 2>/dev/null || true
  exit 124
fi

wait "$child"
exit $?
