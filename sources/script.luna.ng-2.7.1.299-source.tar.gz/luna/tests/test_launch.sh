#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

mkdir -p "$tmp/coreelec-ng"
cat >"$tmp/coreelec-ng/moonlight" <<'EOF'
#!/bin/sh
printf 'cwd %s\n' "$(pwd)" >> "$CALLS"
printf 'moonlight %s\n' "$*" >> "$CALLS"
printf 'osd_takeover %s\n' "${MOONLIGHT_OSD_TAKEOVER:-unset}" >> "$CALLS"
if [ "${MOONLIGHT_TEST_HANG:-0}" = 1 ]; then
  trap 'exit 0' TERM
  while :; do sleep 1; done
fi
exit 42
EOF

cat >"$tmp/killall" <<'EOF'
#!/bin/sh
printf 'killall %s\n' "$*" >> "$CALLS"
EOF

cat >"$tmp/systemctl" <<'EOF'
#!/bin/sh
case "$1" in
  is-active)
    unit="$3"
    if [ "$unit" = "kodi.service" ]; then
      [ "$(cat "$KODI_STATE")" = active ]
    else
      [ "$(cat "$SESSION_STATE")" = active ]
    fi
    ;;
  stop)
    printf 'systemctl stop %s\n' "$2" >> "$CALLS"
    printf 'inactive\n' > "$KODI_STATE"
    ;;
  start)
    printf 'systemctl start %s\n' "$2" >> "$CALLS"
    printf 'active\n' > "$KODI_STATE"
    ;;
  *)
    exit 2
    ;;
esac
EOF

cat >"$tmp/systemd-run" <<'EOF'
#!/bin/sh
printf 'systemd-run %s\n' "$*" >> "$CALLS"
last=''
for arg in "$@"; do last="$arg"; done
[ -n "$last" ] || exit 2
: > "$last.ready"
EOF

cat >"$tmp/vfm-write" <<'EOF'
#!/bin/sh
printf '%s\n' "$2" >> "$VFM_CALLS"
case "$2" in
  'rm default')
    : > "$1"
    ;;
  'add default decoder amvideo')
    if [ "${VFM_FAIL_ADD:-0}" = 1 ]; then
      exit 1
    fi
    printf '%s\n' '[00]  default { decoder(0) amvideo}' > "$1"
    ;;
  *)
    exit 1
    ;;
esac
EOF

chmod +x "$tmp/coreelec-ng/moonlight" "$tmp/killall" "$tmp/systemctl" "$tmp/systemd-run" "$tmp/vfm-write"
export CALLS="$tmp/calls" VFM_CALLS="$tmp/vfm-calls"
export KODI_STATE="$tmp/kodi-state" SESSION_STATE="$tmp/session-state"
export LUNA_LOG_DIR="$tmp/logs"
export MOONLIGHT_BINARY="$tmp/coreelec-ng/moonlight"
export LUNA_SYSTEMCTL="$tmp/systemctl"
export LUNA_SYSTEMD_RUN="$tmp/systemd-run"
export LUNA_KILLALL="$tmp/killall"
export LUNA_VFM_MAP="$tmp/vfm-map"
export LUNA_VFM_WRITE_HELPER="$tmp/vfm-write"
export LUNA_VIDEO_DISABLE="$tmp/disable-video"
export LUNA_VDEC_STATUS="$tmp/vdec-status"
export LUNA_FB0_BLANK="$tmp/fb0.blank" LUNA_FB1_BLANK="$tmp/fb1.blank"
printf 'active\n' > "$KODI_STATE"
printf 'active\n' > "$SESSION_STATE"
printf '%s\n' '[00]  default { }' > "$LUNA_VFM_MAP"
printf '1' > "$LUNA_FB0_BLANK"
printf '1' > "$LUNA_FB1_BLANK"
printf '0' > "$LUNA_VIDEO_DISABLE"
printf '%s\n' 'No vdec.' > "$LUNA_VDEC_STATUS"

launcher="$root/resources/launchscripts/coreelec/launch.sh"
watchdog="$root/resources/launchscripts/coreelec/kodi-watchdog.sh"

grep -Fxq '#!/bin/sh' "$launcher"
grep -Fxq '#!/bin/sh' "$watchdog"
sh -n "$launcher"
sh -n "$watchdog"

set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 42 ]]
grep -Fq 'killall -KILL kodi.bin' "$CALLS"
grep -Fq 'systemctl stop kodi.service' "$CALLS"
grep -Fq 'moonlight stream -app Desktop' "$CALLS"
grep -Fq 'osd_takeover 1' "$CALLS"
grep -Fq "cwd $tmp/coreelec-ng" "$CALLS"
grep -Fq 'systemctl start kodi.service' "$CALLS"
grep -Fq -- '--unit=luna-ng-watchdog-' "$CALLS"
! grep -q -- '-STOP kodi.bin' "$CALLS"
! grep -q -- '-CONT kodi.bin' "$CALLS"
kill_line="$(grep -n -F 'killall -KILL kodi.bin' "$CALLS" | head -n1 | cut -d: -f1)"
stop_line="$(grep -n -F 'systemctl stop kodi.service' "$CALLS" | head -n1 | cut -d: -f1)"
[[ "$kill_line" -lt "$stop_line" ]]
grep -Fxq 'rm default' "$VFM_CALLS"
grep -Fxq 'add default decoder amvideo' "$VFM_CALLS"
grep -Eq 'default[[:space:]]*\{[[:space:]]*decoder\(0\)[[:space:]]+amvideo[[:space:]]*\}' "$LUNA_VFM_MAP"
grep -Fq 'Luna NG: installed decoder -> amvideo VFM route' "$LUNA_LOG_DIR/logfile"
[[ "$(cat "$LUNA_FB0_BLANK")" == 0 ]]
[[ "$(cat "$LUNA_FB1_BLANK")" == 0 ]]
[[ "$(cat "$LUNA_VIDEO_DISABLE")" == 1 ]]
[[ "$(cat "$KODI_STATE")" == active ]]
[[ -z "$(find "$tmp/logs" -name '.luna-session.*' -print)" ]]

# Existing non-empty VFM routes must not be replaced.
: > "$CALLS"
: > "$VFM_CALLS"
printf 'active\n' > "$KODI_STATE"
printf '%s\n' '[00]  default { decoder(0) amvideo}' > "$LUNA_VFM_MAP"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 42 ]]
[[ ! -s "$VFM_CALLS" ]]
grep -Fq 'systemctl stop kodi.service' "$CALLS"
grep -Fq 'moonlight stream -app Desktop' "$CALLS"
grep -Fq 'systemctl start kodi.service' "$CALLS"

# A VFM failure after Kodi stops must still restart Kodi.
: > "$CALLS"
: > "$VFM_CALLS"
printf 'active\n' > "$KODI_STATE"
printf '%s\n' '[00]  default { }' > "$LUNA_VFM_MAP"
export VFM_FAIL_ADD=1
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
unset VFM_FAIL_ADD
[[ "$status" == 1 ]]
grep -Fq 'systemctl stop kodi.service' "$CALLS"
grep -Fq 'systemctl start kodi.service' "$CALLS"
! grep -q 'moonlight stream -app' "$CALLS"
grep -Fq 'Refusing to start Moonlight without a usable Luna NG video route' "$tmp/out"
[[ "$(cat "$KODI_STATE")" == active ]]

# Missing binary must fail before Kodi is stopped.
: > "$CALLS"
export MOONLIGHT_BINARY="$tmp/no-binary"
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
[[ "$status" == 127 ]]
! grep -Fq 'killall -KILL kodi.bin' "$CALLS"
! grep -Fq 'systemctl stop kodi.service' "$CALLS"
export MOONLIGHT_BINARY="$tmp/coreelec-ng/moonlight"

# A Moonlight process that never reaches input/video initialization must not
# strand the user with Kodi stopped.
: > "$CALLS"
printf 'active\n' > "$KODI_STATE"
printf '%s\n' '[00]  default { decoder(0) amvideo}' > "$LUNA_VFM_MAP"
export MOONLIGHT_TEST_HANG=1
export LUNA_STARTUP_TIMEOUT=5
set +e
"$launcher" Desktop >"$tmp/out" 2>&1
status=$?
set -e
unset MOONLIGHT_TEST_HANG
unset LUNA_STARTUP_TIMEOUT
[[ "$status" == 124 ]]
grep -Fq 'systemctl stop kodi.service' "$CALLS"
grep -Fq 'systemctl start kodi.service' "$CALLS"
grep -Fq 'Moonlight startup timed out after 5s; restoring Kodi' "$LUNA_LOG_DIR/logfile"
[[ "$(cat "$KODI_STATE")" == active ]]

# Recovery worker restarts Kodi if an armed session disappears unexpectedly.
: > "$CALLS"
printf 'inactive\n' > "$KODI_STATE"
printf 'inactive\n' > "$SESSION_STATE"
printf '1' > "$LUNA_FB0_BLANK"
printf '1' > "$LUNA_FB1_BLANK"
session="$tmp/recovery-session"
printf '1\n' > "$session"
"$watchdog" luna-ng-session.service "$session"
grep -Fq 'systemctl start kodi.service' "$CALLS"
[[ "$(cat "$KODI_STATE")" == active ]]
[[ "$(cat "$LUNA_FB0_BLANK")" == 0 ]]
[[ "$(cat "$LUNA_FB1_BLANK")" == 0 ]]
[[ ! -e "$session" ]]
[[ ! -e "$session.ready" ]]

echo 'PASS: Kodi handoff, startup timeout recovery, VFM safety, and crash recovery'
