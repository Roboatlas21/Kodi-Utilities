Luna NG CoreELEC 21 ARM32 version: 2.7.1.299
Luna frontend SHA: 6583bf2208ad6719a0403ba5316ee1f27e7c80ab
Moonlight native SHA: c31268af13a6a5d4c859e6c9fef4ff56ed2dcb76
Native GitHub Actions run: 40582275261
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
