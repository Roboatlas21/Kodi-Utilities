Luna NG CoreELEC 21 ARM32 version: 2.7.1.298
Luna frontend SHA: 6583bf2208ad6719a0403ba5316ee1f27e7c80ab
Moonlight native SHA: e53801cb7ae9c98efcde2af7cad6155a62cffb2f
Native GitHub Actions run: 40577462687
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
