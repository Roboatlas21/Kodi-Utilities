Luna NG 2.7.1.300 for CoreELEC 21 NG ARM32, with optional VFM runtime.

This archive contains the exact exported Moonlight and Luna sources, recursive
Moonlight common-code submodules, controller mappings, release-ID transform,
private FFmpeg recipe/nonblocking patch, VFM bridge source, stock CoreELEC build
recipes and patches, stock media module sources, FFmpeg 8.1.2 upstream source,
and libdrm 2.4.120 upstream source. The complete CoreELEC and FFmpeg archives
are supplied as checksummed parts beside this archive in the public repository.
Run python3 upstream/download-sources.py to retrieve and reassemble them.
See SOURCE_PROVENANCE.json for pinned commits
and archive checksums; build-inputs contains the successful build's manifests.
No private Git history or credentials are included.

The stock Linux base is publicly available at the exact recorded revision:
https://github.com/pannal/linux-amlogic/archive/2d0e0cc0db958d8d88f76407ac922f08d9a4004e.tar.gz
Browse the complete kernel source:
https://github.com/pannal/linux-amlogic/tree/2d0e0cc0db958d8d88f76407ac922f08d9a4004e
The kernel source is obtained from that public URL, not embedded in this archive.
Its CoreELEC patches and build configuration are in upstream/CoreELEC-872edca.tar.gz.
The bundled modules use that source and stock CE patches, plus the bridge code
in moonlight-embedded/kernel/moonlight-vfm. The full OS image is not installed.

For the native build use moonlight-embedded/docs/experimental-vfm.md and the
pinned dependencies in build-inputs/source-lock.json. The FFmpeg source archive
is pristine n8.1.2; the CoreELEC DRM PRIME patch and Moonlight nonblocking patch
must both be applied as specified by the build recipes. Stock media modules
also use the patches from the included CoreELEC recipes.

To reproduce the Kodi-ID packaging transformation on the completed VFM ZIP:
python3 release-tooling/build_luna_ng.py luna-coreelec21-ng-vfm.zip script.luna.ng-2.7.1.300.zip --version 2.7.1.300 --native-sha 32af94a9b546a43cd2156c271c7ce3d8abe8b50f --allow-new-input

The published ZIP preserves the native and VFM payloads byte-for-byte; only
Kodi identity, version/metadata and corresponding settings/data paths change.
The standard AML pipeline remains the default; VFM is selected in Luna settings.
