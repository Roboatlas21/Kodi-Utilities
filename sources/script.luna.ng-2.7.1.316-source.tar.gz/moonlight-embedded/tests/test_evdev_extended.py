"""Compile production aggregation, arrival and mouse actions against input samples."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def function(source, signature):
    start = source.index(signature)
    end = source.index('\n}\n', start) + 3
    return source[start:end]


class ExtendedInputTests(unittest.TestCase):
    def test_mixed_bindings_capabilities_and_mouse_edges(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        flags = source[source.index('static const unsigned int mapping_button_flags[]'):]
        flags = flags[:flags.index('};') + 2]
        implementation = '\n'.join(function(source, name) for name in (
            'static void send_controller_arrival_locked(',
            'static bool evdev_apply_extra(',
            'static void evdev_gamepad_mouse_edge('))
        harness = r'''
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include <sys/time.h>
#include <linux/input.h>
#include <Limelight.h>
#include "mapping_extended.h"
#define MOUSE_EMULATION_LONG_PRESS_TIME 500
struct input_device {
 void *dev, *dualsense; bool is_gamepad, mouseEmulation;
 struct mapping *map; short controllerId;
 short leftStickX,leftStickY,rightStickX,rightStickY;
 unsigned char leftTrigger,rightTrigger; unsigned int buttonFlags;
 struct timeval btnDownTime; pthread_t meThread;
};
static int axes[8], keys[8], hats[8], presses, releases;
static unsigned arrival_buttons, arrival_caps;
static bool mouseEmulationEnabled = true;
static bool evdev_read_extra(void *ctx,const struct mapping_binding *b,struct mapping_sample *s) {
 (void)ctx; if(b->index >= 8) return false;
 *s=(struct mapping_sample){b->source=='a'?axes[b->index]:b->source=='h'?hats[b->index]:keys[b->index],-32768,32767,0}; return true;
}
static int libevdev_get_id_vendor(void *d) {(void)d;return 0;}
static const char *libevdev_get_name(void *d) {(void)d;return "fixture";}
static bool evdev_supports_rumble(void *d) {(void)d;return false;}
static int dualsense_capabilities(void *d) {(void)d;return 0;}
static void dualsense_set_player(void *d,int i) {(void)d;(void)i;}
static uint64_t dualsense_speaker_owner(void *d) {(void)d;return 0;}
static bool moonlight_gamepad_slot_valid(int i) {return i>=0 && i<16;}
static void evdev_publish_arrival_locked(short i,unsigned char t,unsigned b,unsigned short c,uint64_t o) {
 (void)i;(void)t;(void)o;arrival_buttons=b;arrival_caps=c;
}
static void evdev_send_mouse_button(struct input_device *d,char a,int b) {
 (void)d;(void)b; if(a==BUTTON_ACTION_PRESS) presses++;else releases++;
}
static void evdev_publish_state(int i,int a,int b,int c,int d,int e,int f,int g) {
 (void)i;(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;
}
static void *HandleMouseEmulation(void *d) {(void)d;return NULL;}
'''
        tail = r'''
int main(void) {
 struct input_device d={.is_gamepad=true,.controllerId=0};
 d.map=mapping_parse_override("guid,mixed,leftx:a0,+leftx:b1,a:b0,a:+a1,");
 axes[0]=12000;keys[0]=1;
 evdev_apply_extra(&d);
 assert(d.leftStickX >= 11998 && d.leftStickX <= 12000);
 assert(d.buttonFlags & A_FLAG);
 axes[1]=32767;keys[0]=0;evdev_apply_extra(&d);assert(d.buttonFlags & A_FLAG);
 axes[1]=0;evdev_apply_extra(&d);assert(!(d.buttonFlags & A_FLAG));
 keys[1]=1;evdev_apply_extra(&d);assert(d.leftStickX==32767);
 keys[1]=0;evdev_apply_extra(&d);assert(d.leftStickX >=11998);
 free(d.map);
 d.map=mapping_parse_override("guid,extended,leftshoulder:a4,rightshoulder:a5,lefttrigger:+a2~,righttrigger:+a3~,a:+a1,start:+a6,");
 send_controller_arrival_locked(&d);
 assert((arrival_buttons & (LB_FLAG|RB_FLAG|A_FLAG|PLAY_FLAG)) == (LB_FLAG|RB_FLAG|A_FLAG|PLAY_FLAG));
 assert(arrival_caps & LI_CCAP_ANALOG_TRIGGERS);
 d.mouseEmulation=true;axes[1]=32767;evdev_apply_extra(&d);
 struct input_event event={.value=1};event.input_event_sec=1;
 assert(d.buttonFlags&A_FLAG);evdev_gamepad_mouse_edge(&d,&event,A_FLAG);assert(presses==1);
 axes[1]=0;evdev_apply_extra(&d);event.value=0;
 assert(!(d.buttonFlags&A_FLAG));evdev_gamepad_mouse_edge(&d,&event,A_FLAG);assert(releases==1);
 d.mouseEmulation=false;event.value=1;evdev_gamepad_mouse_edge(&d,&event,PLAY_FLAG);
 event.value=0;event.input_event_sec=2;evdev_gamepad_mouse_edge(&d,&event,PLAY_FLAG);
 assert(d.mouseEmulation);
 event.value=1;evdev_gamepad_mouse_edge(&d,&event,PLAY_FLAG);
 event.value=0;event.input_event_sec=3;evdev_gamepad_mouse_edge(&d,&event,PLAY_FLAG);
 assert(!d.mouseEmulation && releases==6);
 free(d.map);
 /* A button must stay held when a second legacy contributor goes neutral. */
 const char *mappings[]={"guid,legacy,lefttrigger:a0,lefttrigger:b0,dpup:h0.1,dpup:b1,",
   "guid,mixed,lefttrigger:a0,lefttrigger:b0,dpup:h0.1,dpup:b1,+leftx:b2,"};
 for(unsigned scenario=0;scenario<2;scenario++) {
   d.map=mapping_parse_override(mappings[scenario]);
   axes[0]=-32768;keys[0]=1;keys[1]=1;
   d.leftTrigger=0;d.buttonFlags=0;evdev_apply_extra(&d);
   assert(d.leftTrigger==255 && (d.buttonFlags&UP_FLAG));
   /* Analog/hat releases have overwritten the legacy destination fields. */
   d.leftTrigger=0;d.buttonFlags=0;evdev_apply_extra(&d);
   assert(d.leftTrigger==255 && (d.buttonFlags&UP_FLAG));
   keys[1]=0;evdev_apply_extra(&d);assert(!(d.buttonFlags&UP_FLAG));
   /* Keep the analog trigger pressed after the button releases. */
   axes[0]=32767;keys[0]=0;d.leftTrigger=0;evdev_apply_extra(&d);
   assert(d.leftTrigger==255);
   axes[0]=-32768;evdev_apply_extra(&d);assert(d.leftTrigger==0);
   free(d.map);
 }
 /* Shared sources must update every legacy destination, even when each
  * destination has only one contributor. Start from the legacy first match. */
 d.map=mapping_parse_override("guid,fanout,a:b0,b:b0,lefttrigger:b0,leftx:a0,rightx:a0,");
 keys[0]=1;axes[0]=16000;d.buttonFlags=A_FLAG;d.leftTrigger=0;
 d.leftStickX=16000;d.rightStickX=0;
 assert(evdev_apply_extra(&d));
 assert((d.buttonFlags&(A_FLAG|B_FLAG))==(A_FLAG|B_FLAG));
 assert(d.leftTrigger==255 && d.leftStickX==d.rightStickX);
 assert(d.rightStickX>=15998);
 keys[0]=0;axes[0]=0;evdev_apply_extra(&d);
 assert(!(d.buttonFlags&(A_FLAG|B_FLAG)) && d.leftTrigger==0);
 assert(d.leftStickX==d.rightStickX && abs(d.rightStickX)<=1);
 free(d.map);
 /* An unassigned controller cannot toggle mouse mode on a long press. */
 d.controllerId=-1;d.mouseEmulation=false;
 event.value=1;event.input_event_sec=10;evdev_gamepad_mouse_edge(&d,&event,PLAY_FLAG);
 event.value=0;event.input_event_sec=12;evdev_gamepad_mouse_edge(&d,&event,PLAY_FLAG);
 assert(!d.mouseEmulation);
 int previous_presses=presses,previous_releases=releases;
 d.mouseEmulation=true;event.value=1;evdev_gamepad_mouse_edge(&d,&event,A_FLAG);
 event.value=0;evdev_gamepad_mouse_edge(&d,&event,A_FLAG);
 assert(presses==previous_presses && releases==previous_releases);
 return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            cfile = Path(tmp) / 'test.c'
            cfile.write_text(harness + flags + implementation + tail)
            binary = Path(tmp) / 'test'
            subprocess.run(['cc', '-std=gnu99', '-Wall', '-Wextra', '-Werror',
                            '-I'+str(ROOT/'src/input'),
                            '-I'+str(ROOT/'third_party/moonlight-common-c/src'),
                            str(cfile), str(ROOT/'src/input/mapping.c'), '-pthread',
                            '-o', str(binary)], check=True)
            subprocess.run([str(binary)], check=True, timeout=5)
        handler = function(source, 'static bool evdev_handle_event(')
        self.assertIn('unsigned int changed = previousButtons ^ dev->buttonFlags;', handler)
        self.assertLess(handler.index('evdev_apply_extra(dev)'), handler.index('evdev_gamepad_mouse_edge(dev, &edge, flag)'))


    def test_analog_calibration_and_wizard_identity(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        implementation = '\n'.join(function(source, name) for name in (
            'static bool evdev_axis_usable(', 'static short evdev_convert_value(',
            'static unsigned char evdev_convert_value_byte(',
            'static void evdev_mapping_guid('))
        harness = r"""
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "mapping_extended.h"
struct input_event { int value; };
struct input_device { int unused; };
struct input_abs_parms { int min,max,flat,avg; };
struct libevdev { int bus,vendor,product,version; const char *name; };
#define int16_to_le(x) (x)
#define libevdev_get_id_bustype(d) ((d)->bus)
#define libevdev_get_id_vendor(d) ((d)->vendor)
#define libevdev_get_id_product(d) ((d)->product)
#define libevdev_get_id_version(d) ((d)->version)
#define libevdev_get_name(d) ((d)->name)
static struct mapping_sample sample;
static bool read_source(void *ctx, const struct mapping_binding *b, struct mapping_sample *s) {
  (void)ctx; *s = sample; if (b->source != 'a') s->value=0; return true;
}
"""
        tail = r"""
int main(void) {
  const int geometry[][3] = {{-32768,32767,4096},{0,255,4},{-100,100,10}};
  const char *halves[] = {"", "~", "+", "-"};
  struct input_device dev={0};
  int out[27]; bool present[27]; char text[256];
  for (unsigned g=0;g<3;g++) {
    struct input_abs_parms p={geometry[g][0],geometry[g][1],geometry[g][2],0};
    p.avg=(p.min+p.max)/2;
    int values[]={p.min-1,p.min,p.min+p.flat,p.avg-p.flat-1,p.avg-p.flat,
      p.avg,p.avg+p.flat,p.avg+p.flat+1,p.max-1,p.max,p.max+1};
    for (unsigned v=0;v<sizeof(values)/sizeof(values[0]);v++) {
      struct input_event ev={values[v]}; sample=(struct mapping_sample){ev.value,p.min,p.max,p.flat};
      for (unsigned h=0;h<4;h++) {
        if (h>=2) snprintf(text,sizeof(text),"guid,test,lefttrigger:%sa0,lefttrigger:h0.1",halves[h]);
        else snprintf(text,sizeof(text),"guid,test,lefttrigger:a0%s,lefttrigger:h0.1",halves[h]);
        struct mapping *m=mapping_parse_override(text); assert(m);
        mapping_evaluate_extra(m,read_source,NULL,out,present);
        if(out[4]!=evdev_convert_value_byte(&ev,&dev,&p,halves[h][0])) fprintf(stderr,"g=%u v=%d half=%s out=%d expected=%d map=%s\n",g,ev.value,halves[h],out[4],evdev_convert_value_byte(&ev,&dev,&p,halves[h][0]),text);
        assert(out[4]==evdev_convert_value_byte(&ev,&dev,&p,halves[h][0])); free(m);
      }
      for (int reverse=0;reverse<2;reverse++) {
        snprintf(text,sizeof(text),"guid,test,leftx:a0%s,+leftx:b1",reverse?"~":"");
        struct mapping *m=mapping_parse_override(text); assert(m);
        mapping_evaluate_extra(m,read_source,NULL,out,present);
        assert(out[0]==evdev_convert_value(&ev,&dev,&p,reverse)); free(m);
      }
    }
  }
  struct input_abs_parms p={-32768,32767,4096,0}; struct input_event ev={4097};
  assert(evdev_convert_value(&ev,&dev,&p,false)==1);
  p=(struct input_abs_parms){0,255,0,127}; ev.value=255;
  assert(evdev_convert_value_byte(&ev,&dev,&p,'~')==0);
  /* Down is positive SDL Y. Capturing a decreasing raw Down axis sets ~. */
  for (int reversed=0;reversed<2;reversed++) {
    snprintf(text,sizeof(text),"guid,test,lefty:a0%s,righty:a1%s",reversed?"~":"",reversed?"~":"");
    struct mapping *m=mapping_parse_override(text); assert(m);
    p=(struct input_abs_parms){-32768,32767,0,0}; ev.value=reversed?32767:-32768;
    assert(evdev_convert_value(&ev,&dev,&p,!m->reverse_lefty)==32767);
    assert(evdev_convert_value(&ev,&dev,&p,!m->reverse_righty)==32767); free(m);
  }
  struct libevdev d={3,0,0,1,"GenericPad"}; char guid[33];
  evdev_mapping_guid(&d,guid); assert(!strcmp(guid,"0300000047656e657269635061640000"));
  d.vendor=5; evdev_mapping_guid(&d,guid); assert(!strcmp(guid,"0300000047656e657269635061640000"));
  d.product=6; evdev_mapping_guid(&d,guid); assert(!strcmp(guid,"03000000050000000600000001000000"));
  d.vendor=0; d.name=NULL; evdev_mapping_guid(&d,guid); assert(strlen(guid)==32);
  d.name="Long controller name truncated"; evdev_mapping_guid(&d,guid);
  assert(!strcmp(guid,"030000004c6f6e6720636f6e74726f00"));
  return 0;
}
"""
        with tempfile.TemporaryDirectory() as tmp:
            cfile = Path(tmp) / 'test.c'
            cfile.write_text(harness + implementation + tail)
            binary = Path(tmp) / 'test'
            subprocess.run(['cc', '-std=gnu99', '-Wall', '-Wextra', '-Werror',
                            '-fsanitize=undefined', '-fno-sanitize-recover=undefined',
                            '-I'+str(ROOT/'src/input'), str(cfile),
                            str(ROOT/'src/input/mapping.c'), '-o', str(binary)], check=True)
            subprocess.run([str(binary)], check=True, timeout=5)
        self.assertEqual(source.count('evdev_mapping_guid(evdev, str_guid);'), 2)
        for stick in ('Left', 'Right'):
            self.assertIn('evdev_map_abs("'+stick+' Stick Down"', source)


if __name__ == '__main__':
    unittest.main()
