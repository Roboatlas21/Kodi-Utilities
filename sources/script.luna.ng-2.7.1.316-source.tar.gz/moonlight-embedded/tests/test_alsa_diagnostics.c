/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include <alsa/asoundlib.h>
#include <opus_multistream.h>
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <time.h>

static unsigned error_stops;
void loop_request_error_stop(void) { ++error_stops; }

static uint64_t fake_us=1000000;
static unsigned delay_calls;
static int write_error, delay_error;
static unsigned wait_calls;
static int wait_result;
static unsigned blocked_writes, write_delay_us = 25000;
static int fake_clock(clockid_t id, struct timespec *ts) {
  (void)id; ts->tv_sec=fake_us/1000000; ts->tv_nsec=(fake_us%1000000)*1000; return 0;
}
static int fake_decode(OpusMSDecoder *d, const unsigned char *data, opus_int32 n,
                       opus_int16 *out, int count, int fec) {
  (void)d; (void)data; (void)n; (void)out; (void)count; (void)fec; return 240;
}
static snd_pcm_sframes_t fake_write(snd_pcm_t *p, const void *data, snd_pcm_uframes_t n) {
  (void)p; (void)data; fake_us += write_delay_us;
  if (blocked_writes) { --blocked_writes; return -EAGAIN; }
  int rc=write_error; write_error=0; return rc ? rc : (snd_pcm_sframes_t)n;
}
static int fake_recover(snd_pcm_t *p, int err, int silent) {
  (void)p; (void)silent; return err==-EPIPE ? 0 : err;
}
static int fake_delay(snd_pcm_t *p, snd_pcm_sframes_t *frames) {
  (void)p; ++delay_calls; *frames=960; return delay_error;
}
static snd_pcm_state_t pcm_state = SND_PCM_STATE_RUNNING;
static unsigned prepare_calls;
static snd_pcm_state_t fake_state(snd_pcm_t *p) { (void)p; return pcm_state; }
static snd_pcm_sframes_t fake_avail(snd_pcm_t *p) { (void)p; return 2880; }
static snd_pcm_sframes_t fake_forward(snd_pcm_t *p, snd_pcm_uframes_t n) {
  (void)p; (void)n; assert(0); return 0;
}
static int fake_wait(snd_pcm_t *p, int ms) {
  (void)p; assert(ms == 5); ++wait_calls; return wait_result;
}
static int fake_resume(snd_pcm_t *p) { (void)p; assert(0); return -EAGAIN; }
static int fake_drop(snd_pcm_t *p) { (void)p; assert(0); return 0; }
static int fake_prepare(snd_pcm_t *p) { (void)p; ++prepare_calls; pcm_state=SND_PCM_STATE_PREPARED; return 0; }
#define clock_gettime fake_clock
#define opus_multistream_decode fake_decode
#define snd_pcm_writei fake_write
#define snd_pcm_recover fake_recover
#define snd_pcm_delay fake_delay
#define snd_pcm_state fake_state
#define snd_pcm_avail_update fake_avail
#define snd_pcm_forward fake_forward
#define snd_pcm_wait fake_wait
#define snd_pcm_resume fake_resume
#define snd_pcm_drop fake_drop
#define snd_pcm_prepare fake_prepare
#include "../src/audio/alsa.c"

int main(void) {
  short buffer[480];
  pcmBuffer=buffer; handle=(snd_pcm_t *)(uintptr_t)1; decoder=(OpusMSDecoder *)(uintptr_t)1;
  samplesPerFrame=240; audioDiagnosticsEnabled=true;
  alsaStats.channels=2;
  /* This callback harness skips ALSA initialization; supply negotiated PCM geometry. */
  alsaStats.sample_rate=48000;
  alsaStats.buffer_frames=2880;
  active_bounded_ops=&bounded_ops_diagnostics;
  audioDiagnostics.active=1; audioDiagnostics.sample_rate=48000;
  alsa_renderer_decode_and_play_sample("x",1);
  AudioDiagnostics a;
  alsa_diagnostics_snapshot(&a);
  assert(a.callbacks==1 && a.slow_20ms==1 && a.slow_50ms==0 && a.writes==1);
  assert(a.delay_valid && a.delay_frames==960 && delay_calls==1);
  fake_us+=100000;
  write_error=-EPIPE;
  alsa_renderer_decode_and_play_sample("x",1);
  alsa_diagnostics_snapshot(&a);
  assert(a.callbacks==2 && a.callback_gaps_50ms==1 && a.xruns==1);
  assert(a.recover_attempts==1 && a.recoveries==1 && a.failed_packets==0);
  assert(delay_calls==1 && a.slow_20ms==2); /* At most one queue query/second. */
  fake_us+=1000000; write_error=-EAGAIN; delay_error=-EPIPE;
  wait_calls=0; wait_result=-EPIPE;
  alsa_renderer_decode_and_play_sample("x",1);
  alsa_diagnostics_snapshot(&a);
  assert(!a.delay_valid && delay_calls==2 && a.eagain==1 && a.failed_packets==0);
  assert(wait_calls==1 && a.recover_attempts==2 && a.recoveries==2);
  assert(a.failed_packets==0);
  /* The opt-in resync branch publishes its own write/error counters too. */
  alsaResyncEnabled=true;
  alsaResyncConfig=(AlsaResyncConfig){.buffer_frames=2880,.period_frames=960,
                                     .channels=2,.bytes_per_frame=4};
  alsa_renderer_decode_and_play_sample("x",1);
  alsa_diagnostics_snapshot(&a);
  assert(a.writes==alsaResyncStats.write_calls && a.writes==1 && a.eagain==0);
  alsaResyncEnabled=false;
  pcm_state=SND_PCM_STATE_XRUN;
  fake_us += 200000; /* no audio packets for longer than 60-ms buffer */
  alsa_renderer_decode_and_play_sample("x",1);
  assert(prepare_calls == 1 && alsaStats.idle_xrun_rearms == 1);
  pcm_state=SND_PCM_STATE_RUNNING;
  fake_us += 200000; /* live queue must never be reset after a host pause */
  alsa_renderer_decode_and_play_sample("x",1);
  assert(prepare_calls == 1 && alsaStats.idle_xrun_rearms == 1);
  /* The production callback must carry blocked packets without losing them. */
  assert(alsa_pending_queue_configure(
      &alsaPending, alsaPendingStorage, sizeof(alsaPendingStorage), 960, 4));
  write_delay_us = 0;
  wait_result = 0;
  blocked_writes = 3;
  const unsigned long long dropped_before = alsaStats.dropped_frames;
  const unsigned long long failed_before = alsaStats.failed_packets;
  alsa_renderer_decode_and_play_sample("x", 1);
  assert(alsaPending.queued_frames == 240);
  assert(alsaStats.failed_packets == failed_before);
  assert(alsaStats.dropped_frames == dropped_before);
  alsa_renderer_decode_and_play_sample("x", 1);
  assert(alsaPending.queued_frames == 0);
  assert(alsaStats.failed_packets == failed_before);
  assert(alsaStats.dropped_frames == dropped_before);

  /* Persistent backpressure stays bounded to 20 ms. */
  blocked_writes = 15;
  for (int i = 0; i < 5; i++)
    alsa_renderer_decode_and_play_sample("x", 1);
  assert(alsaPending.queued_frames == 960);
  assert(alsaStats.pending_overflow_events == 1);
  assert(alsaStats.dropped_frames == dropped_before + 240);
  alsa_pending_queue_clear(&alsaPending);
  write_delay_us = 25000;
  /* Subsequent recovery/backpressure callbacks changed the counters.
   * Snapshot the state immediately before disabling instrumentation. */
  alsa_diagnostics_snapshot(&a);
  const unsigned calls = a.callbacks;
  const unsigned queue_queries = delay_calls;
  audioDiagnosticsEnabled=false;
  active_bounded_ops=&bounded_ops_normal;
  alsa_renderer_decode_and_play_sample("x",1);
  alsa_diagnostics_snapshot(&a);
  assert(a.callbacks==calls && delay_calls==queue_queries);
  alsaResyncEnabled=true; audioDiagnosticsEnabled=true;
  const unsigned long long zero_before = alsaStats.zero_progress_callbacks;
  wait_result=0; blocked_writes=3;
  alsa_renderer_decode_and_play_sample("x",1);
  assert(alsaStats.zero_progress_callbacks == zero_before + 1);
  alsa_renderer_decode_and_play_sample("x",1);
  assert(alsaStats.zero_progress_callbacks == zero_before + 1);
  write_error=-EIO;
  alsa_renderer_decode_and_play_sample("x",1);
  assert(alsaStats.zero_progress_callbacks == zero_before + 2);
  audioDiagnosticsEnabled=false; blocked_writes=3;
  alsa_renderer_decode_and_play_sample("x",1);
  assert(alsaStats.zero_progress_callbacks == zero_before + 2);
  audioDiagnosticsEnabled=true;
  alsaResyncEnabled=false;
  /* The earlier injected -EIO already requested a stream stop. */
  assert(error_stops == 1);
  assert(alsa_endpoint_result(-ENODEV) == -ENODEV);
  assert(error_stops == 2);
  puts("Actual ALSA callbacks: queue sampling, XRUN recovery, EAGAIN, resync and disabled diagnostics passed");
}
