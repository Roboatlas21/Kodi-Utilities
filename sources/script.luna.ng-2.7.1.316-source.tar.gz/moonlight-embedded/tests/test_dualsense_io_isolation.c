/* Production output queues must not transfer on the input thread. */
#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
static pthread_mutex_t gate=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t wake=PTHREAD_COND_INITIALIZER;
static bool entered,released;
static int stuck_fd=-1,healthy_writes;
static bool retry_forever;
static unsigned retry_attempts;
static unsigned char last_report[128];
ssize_t __wrap_write(int fd,const void *p,size_t n) {
  if(retry_forever){++retry_attempts;errno=EAGAIN;return -1;}
  pthread_mutex_lock(&gate);
  if(fd==stuck_fd) {
    entered=true;pthread_cond_broadcast(&wake);
    while(!released)pthread_cond_wait(&wake,&gate);
  } else {++healthy_writes;memcpy(last_report,p,n);pthread_cond_broadcast(&wake);}
  pthread_mutex_unlock(&gate);return n;
}
#include "../src/input/dualsense.c"
static void test_production_cleanup(void);
int main(void) {
  moonlight_dualsense a={.fd=10,.listening=true,.transport=ML_DS_USB},
                      b={.fd=11,.listening=true,.transport=ML_DS_USB};
  moonlight_dualsense *devices[]={&a,&b};stuck_fd=a.fd;
  for(unsigned i=0;i<2;++i) {
    pthread_mutex_init(&devices[i]->output_lock,NULL);pthread_cond_init(&devices[i]->output_wake,NULL);
    assert(pthread_create(&devices[i]->output_worker,NULL,dualsense_output_worker,devices[i])==0);
    devices[i]->output_started=true;
  }
  assert(dualsense_led_try(&a,1,2,3)==ML_DS_SEND_OK);
  pthread_mutex_lock(&gate);while(!entered)pthread_cond_wait(&wake,&gate);pthread_mutex_unlock(&gate);
  unsigned char left[10]={4},right[10]={5};
  assert(dualsense_adaptive_try(&a,8,1,0,left,NULL)==ML_DS_SEND_OK);
  assert(dualsense_adaptive_try(&a,4,0,2,NULL,right)==ML_DS_SEND_OK);
  assert(dualsense_led_try(&b,7,8,9)==ML_DS_SEND_OK);
  pthread_mutex_lock(&gate);while(!healthy_writes)pthread_cond_wait(&wake,&gate);
  assert(last_report[45]==7&&last_report[46]==8&&last_report[47]==9);
  released=true;pthread_cond_broadcast(&wake);pthread_mutex_unlock(&gate);
  pthread_mutex_lock(&a.output_lock);
  assert(a.output_body[0]==12&&a.output_body[10]==2&&a.output_body[21]==1);
  pthread_mutex_unlock(&a.output_lock);
  for(unsigned i=0;i<2;++i) {
    pthread_mutex_lock(&devices[i]->output_lock);devices[i]->output_stop=true;
    pthread_cond_signal(&devices[i]->output_wake);pthread_mutex_unlock(&devices[i]->output_lock);
    pthread_join(devices[i]->output_worker,NULL);
    pthread_cond_destroy(&devices[i]->output_wake);pthread_mutex_destroy(&devices[i]->output_lock);
  }
  moonlight_dualsense d={.fd=12,.listening=true,.transport=ML_DS_USB,.output_started=true};
  pthread_mutex_init(&d.output_lock,NULL);pthread_cond_init(&d.output_wake,NULL);
  retry_forever=true;
  assert(!pthread_create(&d.output_worker,NULL,dualsense_output_worker,&d));
  assert(dualsense_led_try(&d,1,2,3)==ML_DS_SEND_OK);
  for(int i=0;i<2000&&!__atomic_load_n(&d.output_failed,__ATOMIC_ACQUIRE);++i)usleep(1000);
  assert(__atomic_load_n(&d.output_failed,__ATOMIC_ACQUIRE));
  pthread_mutex_lock(&d.output_lock);d.output_stop=true;pthread_cond_signal(&d.output_wake);pthread_mutex_unlock(&d.output_lock);
  pthread_join(d.output_worker,NULL);assert(retry_attempts==25);retry_forever=false;
  pthread_cond_destroy(&d.output_wake);pthread_mutex_destroy(&d.output_lock);
  test_production_cleanup();
  return 0;
}

void ml_ds_audio_close(ml_ds_audio *audio) { (void)audio; }
static bool calibration_entered, calibration_released, cleanup_finished;
int __wrap_ioctl(int fd,unsigned long request,...) {
  (void)fd;(void)request;
  pthread_mutex_lock(&gate);calibration_entered=true;pthread_cond_broadcast(&wake);
  while(!calibration_released)pthread_cond_wait(&wake,&gate);
  pthread_mutex_unlock(&gate);return -1;
}
static void *close_bridge(void *arg) {
  dualsense_close_one(arg);
  __atomic_store_n(&cleanup_finished,true,__ATOMIC_RELEASE);
  return NULL;
}
static void test_production_cleanup(void) {
  moonlight_dualsense *d=calloc(1,sizeof(*d));
  d->fd=open("/dev/null",O_RDWR);d->transport=ML_DS_USB;
  pthread_mutex_init(&d->output_lock,NULL);pthread_cond_init(&d->output_wake,NULL);
  d->output_started=true;d->output_pending=true;d->calibration_started=true;
  entered=released=false;stuck_fd=d->fd;
  assert(!pthread_create(&d->output_worker,NULL,dualsense_output_worker,d));
  assert(!pthread_create(&d->calibration_worker,NULL,dualsense_calibrate,d));
  pthread_mutex_lock(&gate);
  while(!entered||!calibration_entered)pthread_cond_wait(&wake,&gate);
  pthread_mutex_unlock(&gate);
  bridge_cleanup.pending=1;bridge_cleanup.retiring=d;
  pthread_t closer;assert(!pthread_create(&closer,NULL,close_bridge,d));
  usleep(20000);assert(!__atomic_load_n(&cleanup_finished,__ATOMIC_ACQUIRE));
  pthread_mutex_lock(&gate);released=true;pthread_cond_broadcast(&wake);pthread_mutex_unlock(&gate);
  usleep(20000);assert(!__atomic_load_n(&cleanup_finished,__ATOMIC_ACQUIRE));
  pthread_mutex_lock(&gate);calibration_released=true;pthread_cond_broadcast(&wake);pthread_mutex_unlock(&gate);
  pthread_join(closer,NULL);assert(!dualsense_cleanup_pending());
}
