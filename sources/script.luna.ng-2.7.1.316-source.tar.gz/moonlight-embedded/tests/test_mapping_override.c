/* Compile the actual native mapping parser and test invalid env overrides. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "../src/input/mapping.h"
#include "../src/input/mapping_extended.h"
#include "../src/input/mapping_usable.h"

static bool sample_source(void *ctx, const struct mapping_binding *b,
                          struct mapping_sample *sample) {
  int *values = ctx;
  *sample = (struct mapping_sample){values[b->index], 0, 255, 0};
  return true;
}

static void extended_cases(void) {
  struct mapping *m = mapping_parse_override(
    "11111111111111111111111111111111,First,a:b0,platform:Linux,\n"
    "22222222222222222222222222222222,Second,a:b7,platform:Linux,\n"
    "11111111111111111111111111111111,Wrong,a:b9,platform:iOS,");
  assert(m && m->btn_a == 7 && m->next && m->next->btn_a == 0);
  assert(!m->next->next);
  free(m->next); free(m);
  m = mapping_parse_override("guid,Invalid,a:b65536,leftx:a32768,b:b-65536,x:b1 junk,y:b999999999999999999999,");
  assert(m && !moonlight_mapping_has_usable_bindings(m, 8, 8, 1));
  free(m);
  m = mapping_parse_override("guid,N64,+rightx:b2,-rightx:b4,+lefty:h0.4,-lefty:h0.1,leftshoulder:a5,");
  assert(m && m->extra_count == 5);
  FILE *encoded = tmpfile(); assert(encoded);
  fflush(stdout);
  int saved_stdout = dup(STDOUT_FILENO); assert(saved_stdout >= 0);
  assert(dup2(fileno(encoded), STDOUT_FILENO) >= 0);
  mapping_print(m); fflush(stdout);
  assert(dup2(saved_stdout, STDOUT_FILENO) >= 0); close(saved_stdout);
  rewind(encoded);
  char *line = NULL; size_t capacity = 0;
  assert(getline(&line, &capacity, encoded) > 0);
  struct mapping *roundtrip = mapping_parse(line);
  assert(roundtrip && roundtrip->extra_count == m->extra_count);
  assert(!memcmp(roundtrip->extra, m->extra, m->extra_count * sizeof(m->extra[0])));
  free(roundtrip); free(line); fclose(encoded);

  assert(moonlight_mapping_has_usable_bindings(m, 6, 6, 1));
  int values[6] = {0}, output[27]; bool present[27];
  values[2] = values[4] = 1;
  mapping_evaluate_extra(m, sample_source, values, output, present);
  assert(present[2] && output[2] == 0); /* Opposing buttons cancel. */
  values[2] = 0;
  values[0] = 4; values[5] = 255;
  mapping_evaluate_extra(m, sample_source, values, output, present);
  assert(output[2] == -32767 && output[1] == 32767 && output[15] == 1);
  values[4] = values[0] = values[5] = 0;
  mapping_evaluate_extra(m, sample_source, values, output, present);
  assert(output[2] == 0 && output[1] == 0 && output[15] == 0);
  free(m);
}

static bool stick_sample(void *ctx, const struct mapping_binding *b,
                         struct mapping_sample *sample) {
  (void)b;
  *sample = (struct mapping_sample){*(int *)ctx, -32768, 32767, 4096};
  return true;
}

static void split_stick_deadzone(void) {
  struct mapping *normal = mapping_parse_override("guid,Pad,leftx:a0,");
  struct mapping *split = mapping_parse_override(
      "guid,Pad,+leftx:+a0,-leftx:-a0,");
  assert(normal && split);
  const int samples[] = {-32768, -16000, -4096, -1024, 0, 1024, 4096, 16000, 32767};
  for (unsigned i = 0; i < sizeof(samples) / sizeof(samples[0]); ++i) {
    int raw = samples[i], a[27], b[27]; bool present[27];
    mapping_evaluate_extra(normal, stick_sample, &raw, a, present);
    mapping_evaluate_extra(split, stick_sample, &raw, b, present);
    /* The negative half has 32767 output steps versus 32768 on a full stick. */
    assert(abs(a[0] - b[0]) <= 1);
    if (abs(raw) < 4096) assert(b[0] == 0);
  }
  free(normal); free(split);
  struct mapping *inverted = mapping_parse_override("guid,Pad,+leftx:+a0~,");
  assert(inverted);
  int raw = -1024, out[27]; bool present[27];
  mapping_evaluate_extra(inverted, stick_sample, &raw, out, present);
  assert(out[0] == 0); /* Outside the source half stays inactive when inverted. */
  raw = 32767;
  mapping_evaluate_extra(inverted, stick_sample, &raw, out, present);
  assert(out[0] == 0);
  raw = 1024;
  mapping_evaluate_extra(inverted, stick_sample, &raw, out, present);
  assert(out[0] == 32767);
  free(inverted);
  struct mapping *full = mapping_parse_override("guid,Pad,+leftx:a0,");
  assert(full);
  raw = 0;
  mapping_evaluate_extra(full, stick_sample, &raw, out, present);
  assert(out[0] == 16383); /* Full-source midpoint deliberately maps to half travel. */
  free(full);
}

int main(void) {
  split_stick_deadzone();
  extended_cases();
  static const char text[] = "03000000000000000000000000000000,Example Pad,a:b0,b:b1";
  char original[sizeof(text)];
  memcpy(original, text, sizeof(text));
  struct mapping *valid = mapping_parse_override(text);
  assert(valid != NULL);
  assert(!strcmp(valid->guid, "03000000000000000000000000000000"));
  assert(!strcmp(valid->name, "Example Pad"));
  assert(valid->btn_a == 0 && valid->btn_b == 1);
  assert(!memcmp(text, original, sizeof(text))); /* read-only source unchanged */
  free(valid);
  assert(mapping_parse_override("") == NULL);
  assert(mapping_parse_override("invalid") == NULL);
  assert(mapping_parse_override(NULL) == NULL);

  /* The file loader should not leak descriptors over repeated calls. */
  char filename[] = "/tmp/moonlight-mapping-XXXXXX";
  int fd = mkstemp(filename);
  assert(fd >= 0);
  FILE *f = fdopen(fd, "w");
  assert(f != NULL);
  assert(fprintf(f, "%s\n", text) > 0);
  assert(fprintf(f, "%s,platform:iOS,\n", text) > 0);
  assert(fclose(f) == 0);
  for (int i = 0; i < 64; ++i) {
    struct mapping *item = mapping_load(filename, false);
    assert(item && !item->next && item->btn_a == 0);
    free(item);
  }
  unlink(filename);
  puts("PASS: immutable mapping override, null mapping, repeated file parse");
  return 0;
}
