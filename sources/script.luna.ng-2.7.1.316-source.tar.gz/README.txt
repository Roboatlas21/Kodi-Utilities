Luna NG version: 2.7.1.316
Luna commit: 67a37f2313557a9da87a63d651440330493e00ab
Moonlight native commit: cb7941850c14fd3ef82791c52ea2aece0b93ed00
Moonlight native run: 41518807080
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
