"""Regressions for credential boundaries, artwork passes and launch preflight."""
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import tracemalloc
import types
import unittest
from unittest.mock import Mock, patch
import test_review4_fixes as fixture
from resources.lib.util import hostcontext, hostapi, artwork, diagnosticreport, runtimecheck
from resources.lib.util.library import Library

class Review5Tests(unittest.TestCase):
    def test_reset_removes_required_markers_only_for_known_pin_names(self):
        with tempfile.TemporaryDirectory() as td:
            names=['client.pem','key.pem','server-'+hashlib.sha256(b'pc').hexdigest()+'.pem.required']
            for name in names+['unrelated.required']:Path(td,name).write_text('x')
            hostcontext.remove_pairing_keys(td)
            self.assertEqual([p.name for p in Path(td).iterdir()],['unrelated.required'])

    def test_ports_use_independent_pin_paths_and_preserve_default(self):
        a=hostapi.Host('pc',http_port=48000);b=hostapi.Host('pc',http_port=49000)
        self.assertNotEqual(a._pin_path(),b._pin_path())
        self.assertTrue(a._pin_path().endswith(hashlib.sha256(b'pc\nport=48000').hexdigest()+'.pem'))
        self.assertTrue(hostapi.Host('pc')._pin_path().endswith(hashlib.sha256(b'pc').hexdigest()+'.pem'))

    def test_fifo_credentials_are_rejected_without_hanging(self):
        with tempfile.TemporaryDirectory() as td:
            os.mkfifo(Path(td,'client.pem'));Path(td,'key.pem').write_text('x')
            code='from resources.lib.util.hostapi import Host; Host("pc",key_dir='+repr(td)+')._context()'
            result=subprocess.run([sys.executable,'-c',code],env={**os.environ,'PYTHONPATH':str(Path(__file__).resolve().parents[1])},capture_output=True,timeout=3)
            self.assertNotEqual(result.returncode,0)
            self.assertIn(b'Cannot safely load pairing credentials',result.stderr)

    def test_unowned_legacy_folders_remain_unscoped(self):
        with tempfile.TemporaryDirectory() as td:
            Path(td,'folders.json').write_text(json.dumps({'folders':['Old'],'assign':{'42':'Old'}}))
            library=Library(td,'different',{'port':'49000'});library.migrate_legacy()
            self.assertIsNone(library.folder_of('42'))
            self.assertEqual(json.loads(Path(td,'folders.json').read_text())['assign_by_host']['legacy-unscoped'],{'42':'Old'})

    def test_failed_artwork_pass_enters_backoff(self):
        for count in (1,3,4,10):
            with self.subTest(count=count),tempfile.TemporaryDirectory() as td:
                path=Path(td,'job.work');path.write_text(json.dumps({'host':'pc','ids':[str(i) for i in range(1,count+1)]}))
                with patch.object(fixture.service.MoonlightHelper,'_art_if_present',return_value=None),patch.object(fixture.service.MoonlightHelper,'boxart_path',return_value=None):
                    for _ in range((count+2)//3):fixture.service.process_job(path,types.SimpleNamespace(abortRequested=lambda:False))
                payload=json.loads(path.read_text())
                self.assertEqual(len(payload['ids']),count);self.assertGreater(payload['retry_at'],0)
                self.assertEqual(payload['attempts'],1)

    def test_duplicate_request_does_not_restart_incomplete_failure_pass(self):
        old={'host':'pc','ids':['4'],'failed_ids':['1','2','3'],'retry_at':0}
        merged=fixture.service.merge_jobs(old,{'host':'pc','ids':['1','2','3','4']})
        self.assertEqual(merged['ids'],['4']);self.assertEqual(merged['failed_ids'],['1','2','3'])

    def test_clipped_pem_base64_is_redacted(self):
        secret='Ab+/Cd+/Ef+/Gh+/Ij+/Kl+/Mn+/Op+/Qr+/St+/Uv+/Wx+/Yz+/0123456789ABCD'
        for raw in ('AbCd+/==\n-----END PRIVATE KEY-----\n', secret+'\n-----END PRIVATE KEY-----\n', '-----BEGIN PRIVATE KEY-----\n'+(secret+'\n')*28+'-----END PRIVATE KEY-----\n'+'ordinary event\n'*290):
            self.assertNotIn(secret,diagnosticreport.redact(diagnosticreport._bounded_tail(raw)))
            self.assertNotIn('AbCd+/==',diagnosticreport.redact(diagnosticreport._bounded_tail(raw)))

    def test_vfm_rejects_rotation_and_av1_before_handoff(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td,'config')
            for extra in ('rotate=90','codec=av1'):
                p.write_text('[Moonlight]\nwidth=1920\nheight=1080\nfps=60\n'+extra+'\n')
                with self.assertRaises(ValueError):runtimecheck.check_stream_geometry(str(p),'aml-vfm')
                runtimecheck.check_stream_geometry(str(p),'aml')

    def test_invalid_xdg_values_use_home_cache(self):
        for value in ('','relative'):
            with patch.dict(os.environ,{'XDG_CACHE_DIR':value,'HOME':'/tmp/home'}):
                self.assertEqual(hostcontext.default_key_dir(),'/tmp/home/.cache/moonlight')

    def test_png_validation_streams_large_decompressed_image(self):
        import zlib
        w,h=8192,3000;c=zlib.compressobj();parts=[]
        for _ in range(h):parts.append(c.compress(bytes(w*3+1)))
        parts.append(c.flush())
        def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',b''.join(parts))+chunk(b'IEND',b'')
        tracemalloc.start()
        try:
            self.assertTrue(artwork._valid_png(png))
            self.assertLess(tracemalloc.get_traced_memory()[1],2*1024*1024)
        finally:tracemalloc.stop()
