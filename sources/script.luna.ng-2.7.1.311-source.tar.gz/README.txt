Luna NG version: 2.7.1.311
Luna commit: 0c7ac9c3b195b0d0b511de76da37ae2ff041dba0
Moonlight native commit: f16f2a8f08924ad4276cc33f556b55850c0b2a27
Moonlight native run: 41462006986
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
