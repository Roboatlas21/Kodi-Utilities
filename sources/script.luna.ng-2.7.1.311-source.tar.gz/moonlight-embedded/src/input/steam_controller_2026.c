/* SPDX-License-Identifier: GPL-3.0-or-later
 * Valve Steam Controller (2026) native HID driver for CoreELEC NG.
 * Isolated from the Amlogic decoder. Host callbacks enqueue only.
 * Exact Valve VID/PID and interface selection, no USB reset or unbind.
 */
#define _GNU_SOURCE
#include "steam_controller_2026.h"
#include "steam_controller_2026_protocol.h"
#include "steam_output_queue.h"
#include "steam_controller_initial.h"
#include "evdev.h"
#include "udev.h"
#include "selected_names.h"
#include "../loop.h"
#include <libudev.h>
#include <linux/hidraw.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/timerfd.h>
#include <sys/eventfd.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <time.h>
#include <pthread.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define SC26_LINKS 16
#define SC26_SERVICE_MS 40
#define SC26_RESCAN_MS 2000
#define SC26_STALE_MS 3000
#define SC26_RUMBLE_HOLD_MS 500
#define SC26_HID_READ_LIMIT 32
#define SC26_HID_WRITE_LIMIT 4

typedef struct Sc26Io Sc26Io;
typedef struct {
  Sc26Io *io;
  int fd, player;
  char path[256], hid_parent[256];
  uint16_t product;
  uint8_t transport; /* LI_SCATTR_TRANSPORT_* */
  uint64_t last_state_ms, last_keepalive_ms, rumble_deadline_ms, last_rumble_ms;
  uint32_t generation;
  uint16_t motion_period_ms[2];
  unsigned motion_revision[2], motion_seen[2];
  uint64_t last_motion_ms[2];
  float last_motion[2][3];
  Sc26Touch last_touch[2];
  bool touched[2], have_state, connected, rumble_repeating;
  bool initialized, settings_attempted;
  bool attrs_valid, has_battery, haptic_failed, queue_overflow, settings_overflow;
  LI_STEAM_CONTROLLER_ATTRIBUTES attrs;
  uint8_t battery_state,battery_percent;
  Sc26Frame last_state;
  uint8_t rumble[10];
  Sc26Output queue[SC26_OUTPUTS];
  /* The service thread keeps a failed HID write in flight, ahead of all
   * newly queued commands, until it succeeds or recovery takes ownership. */
  Sc26Output pending_output;
  unsigned queue_count, write_failures, pending_attempts;
  bool pending_valid, keepalive_queued;
} Sc26Link;

static struct {
  pthread_mutex_t lock, publication_lock;
  bool running,online,initializing,rescan_requested;
  bool worker_started, worker_abandoned;
  pthread_t worker;
  struct udev *udev;
  struct udev_monitor *monitor;
  int monitor_fd, timer_fd, wake_fd;
  uint64_t next_scan_ms, poll_epoch;
  Sc26Link links[SC26_LINKS];
} sc26 = {.lock=PTHREAD_MUTEX_INITIALIZER,.publication_lock=PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP,.monitor_fd=-1,.timer_fd=-1,.wake_fd=-1};

/* This backend owns its own poll loop. HID control transfers never run on
 * the shared evdev/CEC loop; only short state publication uses sc26.lock. */
static void sc26_add_fd(int fd, FdHandler cb, int events) {
  (void)fd; (void)cb; (void)events;
}
static void sc26_add_device_fd(int fd, FdHandler cb, FdHandler fault, int events) {
  (void)fd; (void)cb; (void)fault; (void)events;
}
static void sc26_remove_fd(int fd) { (void)fd; }
static bool sc26_running(void) { return __atomic_load_n(&sc26.running, __ATOMIC_ACQUIRE); }
static bool sc26_online(void) { return __atomic_load_n(&sc26.online, __ATOMIC_ACQUIRE); }
void sc26_poll_main(void) {
  if (__atomic_exchange_n(&sc26.rescan_requested, false, __ATOMIC_ACQ_REL))
    udev_rescan_inputs();
}

static uint64_t now_ms(void) {
  struct timespec now;
  if(clock_gettime(CLOCK_MONOTONIC,&now)) return 0;
  return (uint64_t)now.tv_sec*1000+(uint64_t)now.tv_nsec/1000000;
}
static void wake_service(void) {
  pthread_mutex_lock(&sc26.lock);
  const int fd=sc26.wake_fd;
  if(fd>=0&&sc26.running) {
    const uint64_t value=1;
    /* EFD_NONBLOCK: never wait for the input loop from a control worker. */
    (void)write(fd,&value,sizeof(value));
  }
  pthread_mutex_unlock(&sc26.lock);
}
static bool copy_path(char dst[256],const char *src) {
  if(!src||!src[0]||strlen(src)>=256)return false;
  strcpy(dst,src);
  return true;
}
static void reset_link(Sc26Link *l) {
  memset(l,0,sizeof(*l));
  l->fd=-1;l->player=-1;
}
static void update_timer(void) {
  if(sc26.timer_fd<0)return;
  bool active=false;
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].fd>=0) {active=true;break;}
  struct itimerspec t={0};
  if(active) {
    t.it_value.tv_nsec=SC26_SERVICE_MS*1000000L;
    t.it_interval.tv_nsec=SC26_SERVICE_MS*1000000L;
  } else {
    /* Even without a controller, retry enumeration for an already plugged
     * Puck when its controller wakes; no 40ms wakeup overhead in this state. */
    t.it_value.tv_sec=2;
    t.it_interval.tv_sec=2;
  }
  (void)timerfd_settime(sc26.timer_fd,0,&t,NULL);
}

static bool hid_feature(int fd,const uint8_t *data,size_t length) {
  if(fd<0||!data||length!=SC26_FEATURE_LENGTH)return false;
  uint8_t report[SC26_FEATURE_LENGTH];
  memcpy(report,data,sizeof(report));
  return ioctl(fd,HIDIOCSFEATURE(sizeof(report)),report)==(int)sizeof(report);
}
static bool send_settings(Sc26Link *l,bool active) {
  uint8_t setting[SC26_FEATURE_LENGTH];
  sc26_settings(setting,active);
  return hid_feature(l->fd,setting,sizeof(setting));
}
static bool send_output(Sc26Link *l,const Sc26Output *q) {
  if(q->feature) return hid_feature(l->fd,q->data,SC26_FEATURE_LENGTH);
  const ssize_t n=write(l->fd,q->data,q->length);
  return n==q->length;
}
static void stop_effects(Sc26Link *l) {
  const uint8_t zero_rumble[10]={0x80,0,0,0,0,0,0,0,0,0};
  const uint8_t zero_pulse_l[8]={0x81,0,0,0,0,0,0,0};
  const uint8_t zero_pulse_r[8]={0x81,1,0,0,0,0,0,0};
  const uint8_t zero_cmd_l[4]={0x82,0,0,0};
  const uint8_t zero_cmd_r[4]={0x82,1,0,0};
  const uint8_t *reports[]={zero_rumble,zero_pulse_l,zero_pulse_r,zero_cmd_l,zero_cmd_r};
  const size_t lengths[]={10,8,8,4,4};
  for(unsigned i=0;i<5;++i)(void)write(l->fd,reports[i],lengths[i]);
}
/* The host callback only modifies bounded memory; the main-loop service
 * thread owns all I/O. A stop packet can evict a stale ordinary effect. */
static bool enqueue(Sc26Link *link,const uint8_t *report,size_t length,
                    bool feature,bool stop) {
  if(!link)return false;
  return sc26_queue_enqueue(link->queue,&link->queue_count,report,
                             length,feature,stop);
}
static Sc26Link *find_player(unsigned player) {
  if(player>=SC26_MAX_PLAYERS)return NULL;
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].player==(int)player && sc26.links[i].fd>=0)
      return &sc26.links[i];
  return NULL;
}
bool sc26_rumble_host(unsigned short player,unsigned short low,unsigned short high) {
  pthread_mutex_lock(&sc26.lock);
  Sc26Link *l=sc26_running()&&sc26.online?find_player(player):NULL;
  /* Ownership and enqueue success are different contracts: the host callback
   * must NOT route a failed native Steam command to generic evdev. */
  const bool owned=l!=NULL;
  bool notify=false;
  if(l){
    uint8_t report[10];
    sc26_rumble(report,low,high);
    const bool stop=low==0&&high==0;
    const bool accepted=enqueue(l,report,sizeof(report),false,stop);
    if(accepted){
      memcpy(l->rumble,report,sizeof(report));
      const uint64_t now=now_ms();
      l->rumble_repeating=!stop;
      l->rumble_deadline_ms=now+SC26_RUMBLE_HOLD_MS;
      l->last_rumble_ms=now;
      notify=true;
    } else if(stop){
      /* Never silently drop the last rumble STOP. The service loop will
       * issue direct hardware stops and restore the generic evdev backend. */
      l->haptic_failed=true;
      l->queue_overflow=true;
      notify=true;
    }
  }
  pthread_mutex_unlock(&sc26.lock);
  if(notify)wake_service();
  return owned;
}
bool sc26_motion_host(unsigned short player,uint8_t type,uint16_t rate) {
  pthread_mutex_lock(&sc26.lock);
  Sc26Link *l=sc26_running()&&sc26.online?find_player(player):NULL;
  const int index=type==LI_MOTION_TYPE_ACCEL?0:type==LI_MOTION_TYPE_GYRO?1:-1;
  const bool found=l && index>=0;
  if(found){
    if(rate>250)rate=250;
    l->motion_period_ms[index]=rate?(uint16_t)((1000u+rate-1)/rate):0;
    ++l->motion_revision[index];
  }
  pthread_mutex_unlock(&sc26.lock);
  return found;
}
void sc26_haptic_host(uint16_t player,uint8_t length,const uint8_t *report) {
  if(!sc26_valid_haptic(report,length))return;
  pthread_mutex_lock(&sc26.lock);
  Sc26Link *l=sc26_running()&&sc26.online?find_player(player):NULL;
  bool notify=false;
  if(l){
    const bool stop=sc26_haptic_is_stop(report,length);
    const bool accepted=enqueue(l,report,length,false,stop);
    if(accepted){
      notify=true;
      if(report[0]==SC26_REPORT_RUMBLE){
        l->rumble_repeating=!stop;
        memcpy(l->rumble,report,10);
        l->rumble_deadline_ms=now_ms()+SC26_RUMBLE_HOLD_MS;
        l->last_rumble_ms=now_ms();
      }
    } else if(stop){
      l->haptic_failed=true;
      l->queue_overflow=true;
      notify=true;
    }
  }
  pthread_mutex_unlock(&sc26.lock);
  if(notify)wake_service();
}
void sc26_settings_host(uint16_t player,uint8_t cmd,uint8_t count,const uint8_t *triples) {
  pthread_mutex_lock(&sc26.lock);
  Sc26Link *l=sc26_running()&&sc26.online?find_player(player):NULL;
  bool notify=false;
  if(l && l->product==SC26_BLE && !l->haptic_failed) {
    uint8_t command[SC26_FEATURE_LENGTH]={0};
    bool valid=false,accepted=false;
    if(cmd==SC26_LOAD_DEFAULTS && count==0) {
      uint8_t enable[SC26_FEATURE_LENGTH];
      command[0]=SC26_HID_FEATURE;command[1]=SC26_LOAD_DEFAULTS;
      sc26_settings(enable,true);
      valid=true;
      accepted=sc26_queue_enqueue_settings_batch(
          l->queue,&l->queue_count,command,enable);
    } else if(cmd==SC26_SET_SETTINGS && count<=STEAM_SETTINGS_TRIPLES_MAX) {
      if(sc26_relay_settings(command,triples,count)) {
        valid=true;
        accepted=sc26_queue_enqueue_settings_batch(
            l->queue,&l->queue_count,command,NULL);
      }
    }
    if(valid) {
      if(!accepted) {
        /* The queue holds protected stops/features and cannot drop them.
         * Never accept only half a reset or silently lose a host setting:
         * restore generic evdev ownership on the input-service thread. */
        l->haptic_failed=true;
        l->settings_overflow=true;
      }
      notify=true;
    }
  }
  pthread_mutex_unlock(&sc26.lock);
  if(notify)wake_service();
}

/* Only one event node per exact claimed HID parent can be shadowed. This
 * function never matches a generic Xbox/Sony pad merely by event name. */
bool sc26_owns_event_fd(int fd) {
  if(fd<0||!sc26_running())return false;
  struct stat st;
  if(fstat(fd,&st)<0||!S_ISCHR(st.st_mode))return false;
  struct udev *context=udev_new();
  if(!context)return false;
  struct udev_device *event=udev_device_new_from_devnum(context,'c',st.st_rdev);
  struct udev_device *parent=event?
      udev_device_get_parent_with_subsystem_devtype(event,"hid",NULL):NULL;
  const char *path=parent?udev_device_get_syspath(parent):NULL;
  bool owned=false;
  pthread_mutex_lock(&sc26.lock);
  for(unsigned i=0;path&&i<SC26_LINKS;++i) {
    if(sc26.links[i].fd>=0 && !strcmp(sc26.links[i].hid_parent,path)) {
      owned=true;break;
    }
  }
  pthread_mutex_unlock(&sc26.lock);
  if(event)udev_device_unref(event);
  udev_unref(context);
  return owned;
}

static void release_player_inner(Sc26Link *l) {
  pthread_mutex_lock(&sc26.lock);
  const int slot=l->player;
  const bool left=l->touched[0],right=l->touched[1],online=sc26_online();
  if(slot>=0) {
    l->player=-1;l->connected=false;__atomic_store_n(&l->have_state,false,__ATOMIC_RELEASE);
    l->motion_period_ms[0]=l->motion_period_ms[1]=0;
    l->queue_count=0;l->rumble_repeating=false;
    l->pending_valid=false;l->pending_attempts=0;
    l->keepalive_queued=false;
    l->touched[0]=l->touched[1]=false;
  }
  pthread_mutex_unlock(&sc26.lock);
  if(slot<0)return;
  if(online) {
    if(left)LiSendControllerTouchEvent2(slot,LI_TOUCH_EVENT_UP,0,0,0,0,0);
    if(right)LiSendControllerTouchEvent2(slot,LI_TOUCH_EVENT_UP,0,1,0,0,0);
  }
  (void)evdev_steam_release_event(slot,online);
}

static void release_player(Sc26Link *l) {
  pthread_mutex_lock(&sc26.publication_lock);
  release_player_inner(l);
  pthread_mutex_unlock(&sc26.publication_lock);
}
static void retire_io(Sc26Link *l, bool restore);

static void close_link(Sc26Link *l,bool restore) {
  if(l->fd<0)return;
  release_player(l);
  retire_io(l, restore);
  ++sc26.poll_epoch;
  const int fd=l->fd;
  sc26_remove_fd(fd);
  close(fd);
  pthread_mutex_lock(&sc26.lock);
  reset_link(l); /* Host callbacks can no longer enqueue for this player. */
  pthread_mutex_unlock(&sc26.lock);
  update_timer();
  /* Only while streaming: restore the generic evdev backend if native HID
   * output fails or the raw node disappears without a USB driver reset. */
  if(sc26_running()&&sc26_online())
    __atomic_store_n(&sc26.rescan_requested, true, __ATOMIC_RELEASE);
}
static void feature_query(Sc26Link *l,uint8_t command,uint8_t requested,
                          const uint8_t *extra,unsigned bytes,
                          uint8_t out[65],int *length) {
  uint8_t request[64]={1,command,requested};
  if(bytes && extra)memcpy(request+3,extra,bytes);
  *length=0;
  if(!hid_feature(l->fd,request,sizeof(request)))return;
  memset(out,0,65);out[0]=1;
  const int got=ioctl(l->fd,HIDIOCGFEATURE(sizeof(request)),out);
  if(got>=3 && out[0]==1 && out[1]==command) {
    const int avail=got-3;
    *length=(out[2]<avail?out[2]:avail);
  }
}
static void ascii_attr(char dest[16],const uint8_t *src,unsigned length) {
  memset(dest,0,16);
  for(unsigned i=0;i<length&&i<15&&src[i];++i)
    dest[i]=src[i]>=32&&src[i]<=126?(char)src[i]:'?';
}
static void read_attributes(Sc26Link *l) {
  memset(&l->attrs,0,sizeof(l->attrs));
  l->attrs.transport=l->transport;
  uint8_t result[65];int n;
  feature_query(l,SC26_GET_ATTR,0,NULL,0,result,&n);
  for(int i=0;i+5<=n;i+=5) {
    const unsigned tag=result[3+i];
    const uint32_t value=sc26_u32(result+4+i);
    switch(tag){
      case 2:l->attrs.capabilities=value;l->attrs.validMask|=LI_SCATTR_CAPABILITIES;break;
      case 4:l->attrs.firmwareBuildTime=value;l->attrs.validMask|=LI_SCATTR_FIRMWARE_BUILD_TIME;break;
      case 5:l->attrs.radioFirmwareBuildTime=value;l->attrs.validMask|=LI_SCATTR_RADIO_FW_BUILD_TIME;break;
      case 8:l->attrs.dongleFirmwareBuildTime=value;l->attrs.validMask|=LI_SCATTR_DONGLE_FW_BUILD_TIME;break;
      case 9:l->attrs.boardRevision=value;l->attrs.validMask|=LI_SCATTR_BOARD_REVISION;break;
      case 10:l->attrs.bootloaderBuildTime=value;l->attrs.validMask|=LI_SCATTR_BOOTLOADER_BUILD_TIME;break;
    }
  }
  const uint8_t sub=0;
  feature_query(l,SC26_GET_INFO,1,&sub,1,result,&n);
  if(n>=25 && result[3]==0){
    ascii_attr(l->attrs.buildId,result+12,16);
    if(l->attrs.buildId[0])l->attrs.validMask|=LI_SCATTR_BUILD_ID;
    if(!(l->attrs.validMask&LI_SCATTR_FIRMWARE_BUILD_TIME)){
      l->attrs.firmwareBuildTime=sc26_u32(result+4);
      l->attrs.validMask|=LI_SCATTR_FIRMWARE_BUILD_TIME;
    }
    if(!(l->attrs.validMask&LI_SCATTR_BOARD_REVISION)){
      l->attrs.boardRevision=sc26_u32(result+8);
      l->attrs.validMask|=LI_SCATTR_BOARD_REVISION;
    }
  }
  for(uint8_t tag=0;tag<=1;++tag) {
    feature_query(l,SC26_GET_STRING,0x15,&tag,1,result,&n);
    if(n>=2 && result[3]==tag) {
      ascii_attr(tag?l->attrs.unitSerial:l->attrs.boardSerial,result+4,n-1);
      if(l->attrs.unitSerial[0]||l->attrs.boardSerial[0])
        l->attrs.validMask|=LI_SCATTR_SERIALS;
    }
  }
  l->attrs_valid=l->attrs.validMask!=0;
}

/* Blocking HID transfers own a private allocation and duplicated descriptor.
 * The supervisor only submits/harvests; retirement cannot reuse this state.
 * Registry membership prevents overlapping restoration/reopen on one parent. */
struct Sc26Io {
  Sc26Io *next;
  pthread_mutex_t lock;
  pthread_cond_t wake;
  Sc26Link device;
  Sc26Output output;
  bool ready, init_ok, pending, done, ok, retired, restore;
};
static pthread_mutex_t io_registry_lock = PTHREAD_MUTEX_INITIALIZER;
static Sc26Io *io_registry;
static pthread_cond_t io_registry_wake = PTHREAD_COND_INITIALIZER;
static void wait_io_cleanup(const struct timespec *deadline) {
  pthread_mutex_lock(&io_registry_lock);
  while(io_registry)
    if(pthread_cond_timedwait(&io_registry_wake,&io_registry_lock,deadline)!=0)break;
  pthread_mutex_unlock(&io_registry_lock);
}
static bool io_parent_busy(const char *parent) {
  bool busy=false;
  pthread_mutex_lock(&io_registry_lock);
  for(Sc26Io *io=io_registry;io;io=io->next)
    if(!strcmp(parent,io->device.hid_parent)){busy=true;break;}
  pthread_mutex_unlock(&io_registry_lock);
  return busy;
}
static void *io_worker(void *arg) {
  Sc26Io *io=arg;
  Sc26Link *l=&io->device;
  bool ok=true;
  if(l->product!=SC26_BLE) {
    uint8_t probe[65]={1};
    ok=ioctl(l->fd,HIDIOCGFEATURE(sizeof(probe)),probe)>=1;
  }
  if(ok) {
    l->settings_attempted=true;
    ok=send_settings(l,true);
    if(ok)read_attributes(l);
  }
  pthread_mutex_lock(&io->lock);
  io->init_ok=ok;io->ready=true;
  while(!io->retired) {
    while(!io->pending&&!io->retired)pthread_cond_wait(&io->wake,&io->lock);
    if(io->retired)break;
    Sc26Output output=io->output;
    pthread_mutex_unlock(&io->lock);
    ok=send_output(l,&output);
    pthread_mutex_lock(&io->lock);
    io->ok=ok;io->done=true;io->pending=false;
    while(io->done&&!io->retired)pthread_cond_wait(&io->wake,&io->lock);
  }
  bool restore=io->restore;
  pthread_mutex_unlock(&io->lock);
  if(restore&&l->settings_attempted) {stop_effects(l);(void)send_settings(l,false);}
  close(l->fd);
  pthread_mutex_lock(&io_registry_lock);
  Sc26Io **entry=&io_registry;
  while(*entry&&*entry!=io)entry=&(*entry)->next;
  if(*entry)*entry=io->next;
  pthread_cond_broadcast(&io_registry_wake);
  pthread_mutex_unlock(&io_registry_lock);
  pthread_cond_destroy(&io->wake);pthread_mutex_destroy(&io->lock);free(io);
  return NULL;
}
static bool begin_io(Sc26Link *l) {
  Sc26Io *io=calloc(1,sizeof(*io));
  if(!io)return false;
  io->device=*l;
  io->device.fd=fcntl(l->fd,F_DUPFD_CLOEXEC,0);
  if(io->device.fd<0){free(io);return false;}
  pthread_mutex_init(&io->lock,NULL);pthread_cond_init(&io->wake,NULL);
  pthread_mutex_lock(&io_registry_lock);
  io->next=io_registry;io_registry=io;
  pthread_mutex_unlock(&io_registry_lock);
  pthread_t thread;
  if(pthread_create(&thread,NULL,io_worker,io)!=0) {
    pthread_mutex_lock(&io_registry_lock);
    Sc26Io **entry=&io_registry;
    while(*entry&&*entry!=io)entry=&(*entry)->next;
    if(*entry)*entry=io->next;
    pthread_mutex_unlock(&io_registry_lock);
    close(io->device.fd);pthread_cond_destroy(&io->wake);pthread_mutex_destroy(&io->lock);free(io);
    return false;
  }
  l->io=io;pthread_detach(thread);return true;
}
static void retire_io(Sc26Link *l,bool restore) {
  Sc26Io *io=l->io;l->io=NULL;
  if(!io)return;
  pthread_mutex_lock(&io->lock);
  io->restore=restore;io->retired=true;pthread_cond_signal(&io->wake);
  pthread_mutex_unlock(&io->lock); /* Worker now owns its final reference. */
}
/* -1 means in flight, 0/1 means a completed operation. Never wait for HID. */
static int poll_output(Sc26Link *l,const Sc26Output *output) {
  Sc26Io *io=l->io;
  if(!io)return 0;
  pthread_mutex_lock(&io->lock);
  int result=-1;
  if(io->done) {
    result=io->ok?1:0;io->done=false;pthread_cond_signal(&io->wake);
  } else if(!io->pending) {
    io->output=*output;io->pending=true;pthread_cond_signal(&io->wake);
  }
  pthread_mutex_unlock(&io->lock);
  return result;
}

static void announce(Sc26Link *l) {
  if(!sc26_online()||l->player>=0)return;
  /* By default, split two touchpads into two fingers on one emulated DS4
   * touchpad; Vibepollo understands grip and independent click flags too. */
  uint16_t caps=LI_CCAP_ANALOG_TRIGGERS|LI_CCAP_RUMBLE|LI_CCAP_TOUCHPAD|
      LI_CCAP_ACCEL|LI_CCAP_GYRO|LI_CCAP_BATTERY_STATE|
      LI_CCAP_GRIP_SENSE|LI_CCAP_STICK_TOUCH|
      LI_CCAP_STEAM_HAPTIC|LI_CCAP_SC26_BUTTONS;
  if(l->attrs_valid)caps|=LI_CCAP_STEAM_ATTRIBUTES;
  if(l->product==SC26_BLE)caps|=LI_CCAP_STEAM_SETTINGS;
  const uint32_t flags=A_FLAG|B_FLAG|X_FLAG|Y_FLAG|UP_FLAG|DOWN_FLAG|
      LEFT_FLAG|RIGHT_FLAG|LB_FLAG|RB_FLAG|PLAY_FLAG|BACK_FLAG|
      LS_CLK_FLAG|RS_CLK_FLAG|SPECIAL_FLAG|TOUCHPAD_FLAG|MISC_FLAG|
      PADDLE1_FLAG|PADDLE2_FLAG|PADDLE3_FLAG|PADDLE4_FLAG|
      LEFT_GRIP_TOUCH_FLAG|RIGHT_GRIP_TOUCH_FLAG|
      LEFT_STICK_TOUCH_FLAG|RIGHT_STICK_TOUCH_FLAG|
      LEFT_PAD_CLICK_FLAG|RIGHT_PAD_CLICK_FLAG|
      LEFT_TRIGGER_CLICK_FLAG|RIGHT_TRIGGER_CLICK_FLAG;
  int slot=evdev_steam_claim_arrival(LI_CTYPE_STEAM,flags,caps);
  if(slot<0){
    fprintf(stderr,"Steam Controller 2026: no free Sunshine player slots\n");
    return;
  }
  pthread_mutex_lock(&sc26.lock);
  l->player=slot;
  ++l->generation;
  l->touched[0]=l->touched[1]=false;
  pthread_mutex_unlock(&sc26.lock);
  if(l->attrs_valid)
    LiSendSteamControllerAttributesEvent(slot,&l->attrs);
  if(l->has_battery)
    LiSendControllerBatteryEvent(slot,l->battery_state,l->battery_percent);
  fprintf(stderr,"Steam Controller 2026: player %u (%s, capabilities 0x%x)\n",
          slot,l->path,caps);
}
static void send_pads(Sc26Link *l,const Sc26Frame *f) {
  if(!(LiGetHostFeatureFlags()&LI_FF_CONTROLLER_TOUCH_EVENTS))return;
  if(l->player<0)return;
  for(unsigned i=0;i<2;++i) {
    const Sc26Touch *p=&f->pads[i];
    const bool was=l->touched[i],is=p->touched;
    const float x=i?0.5f+p->x*0.5f:p->x*0.5f;
    const float y=p->y;
    if(!is&&!was)continue;
    uint8_t kind=!is?LI_TOUCH_EVENT_UP:was?LI_TOUCH_EVENT_MOVE:LI_TOUCH_EVENT_DOWN;
    if(is&&was&&l->last_touch[i].x==x&&l->last_touch[i].y==y&&
       l->last_touch[i].pressure==p->pressure)continue;
    LiSendControllerTouchEvent2(l->player,kind,0,i,
                               is?x:0,is?y:0,is?p->pressure:0);
    l->touched[i]=is;
    l->last_touch[i]=*p;
    l->last_touch[i].x=x;l->last_touch[i].y=y;
  }
}
static void send_motion(Sc26Link *l,const Sc26Frame *f,uint64_t now) {
  if(l->player<0)return;
  for(unsigned i=0;i<2;++i) {
    uint16_t period=0;
    pthread_mutex_lock(&sc26.lock);
    period=l->motion_period_ms[i];
    if(l->motion_seen[i]!=l->motion_revision[i]) {
      l->last_motion_ms[i]=0;
      l->motion_seen[i]=l->motion_revision[i];
    }
    pthread_mutex_unlock(&sc26.lock);
    if(!period)continue;
    const float *v=i?f->gyro:f->accel;
    if(l->last_motion_ms[i] && now-l->last_motion_ms[i]<period)continue;
    if(l->last_motion_ms[i] && !memcmp(v,l->last_motion[i],sizeof(l->last_motion[i])))
      continue;
    LiSendControllerMotionEvent(l->player,i?LI_MOTION_TYPE_GYRO:LI_MOTION_TYPE_ACCEL,
                                v[0],v[1],v[2]);
    l->last_motion_ms[i]=now;
    memcpy(l->last_motion[i],v,sizeof(l->last_motion[i]));
  }
}
static void process_report_inner(Sc26Link *l,const uint8_t *p,size_t n) {
  if(n<2||!sc26_online())return;
  uint8_t id=p[0];
  if((id==SC26_REPORT_WIRELESS||id==SC26_REPORT_WIRELESS_ALT)&&n>=2) {
    if(p[1]==1)release_player(l);
    return;
  }
  if(id==SC26_REPORT_BATTERY) {
    uint8_t state,percent;
    if(sc26_battery(p,n,&state,&percent)) {
      l->battery_state=state;l->battery_percent=percent;l->has_battery=true;
      if(l->player>=0)LiSendControllerBatteryEvent(l->player,state,percent);
    }
    return;
  }
  Sc26Frame f;
  if(!sc26_decode(p,n,&f))return;
  const uint64_t now=now_ms();
  l->last_state_ms=now;
  if(l->player<0)announce(l);
  if(l->player<0)return;
  if(!l->have_state ||
     l->last_state.buttons!=f.buttons||l->last_state.lt!=f.lt||
     l->last_state.rt!=f.rt||l->last_state.lx!=f.lx||
     l->last_state.ly!=f.ly||l->last_state.rx!=f.rx||l->last_state.ry!=f.ry)
    evdev_publish_state(l->player,(int)f.buttons,
        f.lt,f.rt,f.lx,f.ly,f.rx,f.ry);
  l->connected=true;__atomic_store_n(&l->have_state,true,__ATOMIC_RELEASE);
  l->last_state=f;
  send_pads(l,&f);
  send_motion(l,&f,now);
}
static void process_report(Sc26Link *l,const uint8_t *p,size_t n) {
  pthread_mutex_lock(&sc26.publication_lock);
  process_report_inner(l,p,n);
  pthread_mutex_unlock(&sc26.publication_lock);
}
static int raw_event(int fd) {
  Sc26Link *l=NULL;
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].fd==fd){l=&sc26.links[i];break;}
  if(!l || !l->initialized)return LOOP_OK;
  for(unsigned count=0;count<SC26_HID_READ_LIMIT;++count) {
    uint8_t report[128];
    const ssize_t n=read(fd,report,sizeof(report));
    if(n>0){process_report(l,report,(size_t)n);continue;}
    if(n<0&&errno==EINTR)continue;
    if(n<0&&(errno==EAGAIN||errno==EWOULDBLOCK))break;
    fprintf(stderr,"Steam Controller 2026: lost HID node %s\n",l->path);
    close_link(l,false);
    break;
  }
  return LOOP_OK;
}
/* Only a failed HID link is detached. The stream, other controllers, and
 * monitoring descriptors stay active when a single hidraw FD is invalid. */
static int sc26_raw_fault(int fd) {
  for (unsigned i = 0; i < SC26_LINKS; ++i) {
    Sc26Link *link = &sc26.links[i];
    if (link->fd != fd) continue;
    fprintf(stderr, "Steam Controller 2026: invalid HID descriptor %d; restoring evdev\n", fd);
    close_link(link, false);
    return LOOP_OK;
  }
  sc26_remove_fd(fd); /* Retire an orphan registration, never spin on it. */
  return LOOP_OK;
}

static void service(uint64_t now) {
  for(unsigned i=0;i<SC26_LINKS;++i) {
    Sc26Link *l=&sc26.links[i];
    if(l->fd<0 || !l->initialized)continue;
    if(l->player>=0 && l->last_state_ms &&
       now-l->last_state_ms>SC26_STALE_MS)release_player(l);
    /* Keepalive is a protected queued HID feature report. Enqueue it after
     * this tick's writes, behind every existing command (including a paired
     * BLE reset and re-enable), so sustained haptics cannot starve it and it
     * cannot break reset ordering. The service thread owns HID output. */
    pthread_mutex_lock(&sc26.lock);
    if(!l->haptic_failed && l->rumble_repeating && now>=l->rumble_deadline_ms) {
      uint8_t zero[10];sc26_rumble(zero,0,0);
      if(!enqueue(l,zero,10,false,true)) {
        l->haptic_failed=true;
        l->queue_overflow=true;
      }
      l->rumble_repeating=false;
    } else if(!l->haptic_failed && l->rumble_repeating &&
              now-l->last_rumble_ms>=SC26_SERVICE_MS) {
      (void)enqueue(l,l->rumble,10,false,false);
      l->last_rumble_ms=now;
    }
    unsigned writes=0;
    while(!l->haptic_failed &&
          (l->pending_valid || l->queue_count) &&
          writes++<SC26_HID_WRITE_LIMIT) {
      if(!l->pending_valid) {
        l->pending_output=l->queue[0];
        memmove(&l->queue[0],&l->queue[1],
                (l->queue_count-1)*sizeof(l->queue[0]));
        --l->queue_count;
        l->pending_valid=true;
        l->pending_attempts=0;
      }
      const Sc26Output item=l->pending_output;
      pthread_mutex_unlock(&sc26.lock);
      const int completed=poll_output(l,&item);
      const bool ok=completed>0;
      pthread_mutex_lock(&sc26.lock);
      if(completed<0)break;
      if(ok) {
        l->pending_valid=false;
        l->pending_attempts=0;
        l->write_failures=0;
        if(item.keepalive) {
          l->keepalive_queued=false;
          l->last_keepalive_ms=now;
        }
      } else {
        /* A transient EAGAIN/failed HIDIOCSFEATURE must not discard this
         * command or allow the next (possibly the reset re-enable) through.
         * Retry next 40ms service tick; after three failed attempts, restore
         * generic evdev rather than continuing with partial device state. */
        if(++l->pending_attempts>=3) {
          l->haptic_failed=true;
          l->queue_count=0;
          l->pending_valid=false;
          l->keepalive_queued=false;
        }
        break;
      }
    }
    if(!l->haptic_failed && !l->keepalive_queued &&
       now>=l->last_keepalive_ms &&
       now-l->last_keepalive_ms>=1000) {
      uint8_t setting[SC26_FEATURE_LENGTH];
      sc26_settings(setting,true);
      if(enqueue(l,setting,sizeof(setting),true,true)) {
        /* Keepalives are protected reports and may evict an old ordinary
         * effect, but never either half of a host-requested BLE reset. */
        l->queue[l->queue_count-1].keepalive=true;
        l->keepalive_queued=true;
      }
    }
    /* Host feedback callbacks can mark failure while send_output() runs.
     * Snapshot flags under their mutex before any unlocked logging/recovery. */
    const bool failed=l->haptic_failed;
    const bool stop_overflow=l->queue_overflow;
    const bool settings_overflow=l->settings_overflow;
    pthread_mutex_unlock(&sc26.lock);
    if(failed) {
      fprintf(stderr,
              settings_overflow
                ? "Steam Controller 2026: BLE settings queue saturated, restoring controller on %s\n"
                : stop_overflow
                ? "Steam Controller 2026: critical stop queue saturated, restoring controller on %s\n"
                : "Steam Controller 2026: HID output failed, reverting on %s\n",
              l->path);
      close_link(l,true);
    }
  }
}
static int wake_event(int fd) {
  /* eventfd normally coalesces all wake requests into one read. Bound the
   * unusual sustained-producer case so other input/CEC fds get service. */
  enum { SC26_MAX_WAKE_READS = 8 };
  uint64_t value;
  for (unsigned i = 0; i < SC26_MAX_WAKE_READS; ++i) {
    const ssize_t n = read(fd, &value, sizeof(value));
    if (n == (ssize_t)sizeof(value)) continue;
    if (n < 0 && errno == EINTR) continue;
    break;
  }
  service(now_ms());
  return LOOP_OK;
}
static void scan(void); /* hotplug recheck follows the input-loop helpers */
static void sc26_rearm_monitor(void);
static int timer_event(int fd) {
  uint64_t expirations;
  (void)read(fd,&expirations,sizeof(expirations));
  const uint64_t now=now_ms();
  if(now>=sc26.next_scan_ms) {
    sc26_rearm_monitor();
    scan();
  }
  service(now);
  return LOOP_OK;
}
static bool candidate(const struct hidraw_devinfo *info,int interface) {
  if(info->vendor!=SC26_VID)return false;
  if(info->product==SC26_WIRED)
    return info->bustype==BUS_USB && interface==0;
  if(info->product==SC26_PUCK)
    return info->bustype==BUS_USB && interface>=2 && interface<=5;
  if(info->product==SC26_BLE)
    return info->bustype==BUS_BLUETOOTH;
  return false;
}
static int usb_interface_number(struct udev_device *raw) {
  struct udev_device *usb=udev_device_get_parent_with_subsystem_devtype(raw,"usb","usb_interface");
  const char *value=usb?udev_device_get_sysattr_value(usb,"bInterfaceNumber"):NULL;
  if(!value||strlen(value)>2)return -1;
  char *end=NULL;
  long v=strtol(value,&end,16);
  return end&&*end==0&&v>=0&&v<256?(int)v:-1;
}
static bool registered_path(const char *node) {
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].fd>=0&&!strcmp(sc26.links[i].path,node))return true;
  return false;
}
static bool registered_parent(const char *parent) {
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].fd>=0&&!strcmp(sc26.links[i].hid_parent,parent))return true;
  return false;
}

/* A user-selected input set is authoritative. Native Steam HID is allowed
 * only when an evdev node under the SAME HID parent passes that selector.
 * The ordinary evdev module applies the identical identity policy. */
static bool selected_parent(const char *hid_parent) {
  const char *v2=getenv("MOONLIGHT_INPUT_SELECTORS_V2");
  const char *legacy=getenv("MOONLIGHT_INPUT_NAMES_HEX");
  if(!v2&&!legacy)return true;
  if(!hid_parent||!sc26.udev)return false;
  struct udev_enumerate *scan=udev_enumerate_new(sc26.udev);
  if(!scan)return false;
  bool selected=false;
  if(udev_enumerate_add_match_subsystem(scan,"input")>=0 &&
     udev_enumerate_scan_devices(scan)>=0) {
    struct udev_list_entry *item;
    udev_list_entry_foreach(item,udev_enumerate_get_list_entry(scan)) {
      struct udev_device *event=udev_device_new_from_syspath(
          sc26.udev,udev_list_entry_get_name(item));
      if(!event)continue;
      const char *node=udev_device_get_devnode(event);
      struct udev_device *hid=udev_device_get_parent_with_subsystem_devtype(
          event,"hid",NULL);
      const char *parent=hid?udev_device_get_syspath(hid):NULL;
      if(node&&parent&&!strcmp(parent,hid_parent)) {
        int fd=open(node,O_RDONLY|O_NONBLOCK|O_CLOEXEC);
        if(fd>=0) {
          char name[256]={0},unique[256]={0},phys[256]={0};
          int got=ioctl(fd,EVIOCGNAME(sizeof(name)),name);
          if(got>0&&got<(int)sizeof(name)) {
            got=ioctl(fd,EVIOCGUNIQ(sizeof(unique)),unique);
            if(got<=0||got>=(int)sizeof(unique))unique[0]=0;
            got=ioctl(fd,EVIOCGPHYS(sizeof(phys)),phys);
            if(got<=0||got>=(int)sizeof(phys))phys[0]=0;
            name[255]=unique[255]=phys[255]=0;
            selected=moonlight_selected_identity(v2,legacy,name,unique,phys);
          }
          close(fd);
        }
      }
      udev_device_unref(event);
      if(selected)break;
    }
  }
  udev_enumerate_unref(scan);
  return selected;
}

static void try_raw(struct udev_device *raw) {
  const char *node=udev_device_get_devnode(raw);
  struct udev_device *hid=udev_device_get_parent_with_subsystem_devtype(raw,"hid",NULL);
  const char *parent=hid?udev_device_get_syspath(hid):NULL;
  if(!node||!parent||strlen(node)>=256||strlen(parent)>=256||
     registered_path(node)||registered_parent(parent)||io_parent_busy(parent)||!selected_parent(parent))
    return;
  Sc26Link *slot=NULL;
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].fd<0){slot=&sc26.links[i];break;}
  if(!slot)return;
  int fd=open(node,O_RDWR|O_NONBLOCK|O_CLOEXEC);
  if(fd<0)return; /* Existing generic evdev path must remain untouched. */
  struct hidraw_devinfo info={0};
  const int intf=usb_interface_number(raw);
  if(ioctl(fd,HIDIOCGRAWINFO,&info)<0||!candidate(&info,intf)||
     evdev_steam_conflict_parent(parent)) {
    close(fd);return;
  }
  Sc26Link staging;
  Sc26Link *prepared=&staging;
  reset_link(prepared);
  prepared->fd=fd;
  prepared->product=(uint16_t)info.product;
  prepared->transport=info.product==SC26_PUCK?LI_SCATTR_TRANSPORT_PUCK:
                  info.product==SC26_BLE?LI_SCATTR_TRANSPORT_BLE:
                  LI_SCATTR_TRANSPORT_USB;
  if(!copy_path(prepared->path,node)||!copy_path(prepared->hid_parent,parent)) {
    close(fd);return;
  }

  pthread_mutex_lock(&sc26.lock);
  *slot = staging;
  ++sc26.poll_epoch;
  pthread_mutex_unlock(&sc26.lock);
  sc26_add_device_fd(fd,raw_event,sc26_raw_fault,POLLIN);
  update_timer();
  fprintf(stderr,"Steam Controller 2026: native HID claimed %s (%s interface %d)\n",
          node,slot->product==SC26_BLE?"BLE":slot->product==SC26_PUCK?"Puck":"USB",intf);
  fprintf(stderr,"Steam Controller 2026: do not run controller firmware updates over a stream\n");
}
/* Slow initialization is owned by the HID worker. Metadata is reserved
 * first so the initial launch mask and generic evdev ownership stay stable. */
static void initialize_links(void) {
  for(unsigned i=0;i<SC26_LINKS && sc26_running();++i) {
    Sc26Link *l=&sc26.links[i];
    if(l->fd<0 || l->initialized)continue;
    if(!l->io && !begin_io(l)){close_link(l,false);continue;}
    pthread_mutex_lock(&l->io->lock);
    bool ready=l->io->ready,ok=l->io->init_ok;
    if(ready) {
      l->attrs=l->io->device.attrs;l->attrs_valid=l->io->device.attrs_valid;
      l->settings_attempted=l->io->device.settings_attempted;
    }
    pthread_mutex_unlock(&l->io->lock);
    if(!ready)continue;
    if(!ok){close_link(l,true);continue;}
    l->last_keepalive_ms=now_ms();l->initialized=true;
  }
}

static void scan(void) {
  if(!sc26.udev||!sc26_running())return;
  struct udev_enumerate *e=udev_enumerate_new(sc26.udev);
  if(!e)return;
  if(udev_enumerate_add_match_subsystem(e,"hidraw")>=0 &&
     udev_enumerate_scan_devices(e)>=0) {
    /* A stale link is released when its raw sysfs node disappears. */
    for(unsigned i=0;i<SC26_LINKS;++i) {
      Sc26Link *l=&sc26.links[i];
      if(l->fd<0)continue;
      bool found=false;
      struct udev_list_entry *n;
      udev_list_entry_foreach(n,udev_enumerate_get_list_entry(e)) {
        struct udev_device *d=udev_device_new_from_syspath(sc26.udev,udev_list_entry_get_name(n));
        if(d) {
          const char *path=udev_device_get_devnode(d);
          if(path&&!strcmp(path,l->path))found=true;
          udev_device_unref(d);
        }
        if(found)break;
      }
      if(!found)close_link(l,false);
    }
    struct udev_list_entry *n;
    udev_list_entry_foreach(n,udev_enumerate_get_list_entry(e)) {
      struct udev_device *d=udev_device_new_from_syspath(sc26.udev,udev_list_entry_get_name(n));
      if(d){try_raw(d);udev_device_unref(d);}
    }
  }
  udev_enumerate_unref(e);
  sc26.next_scan_ms=now_ms()+SC26_RESCAN_MS;
}
static int monitor_event(int fd);
static void sc26_drop_monitor(void) {
  if(sc26.monitor_fd>=0)sc26_remove_fd(sc26.monitor_fd);
  sc26.monitor_fd=-1;
  if(sc26.monitor)udev_monitor_unref(sc26.monitor);
  sc26.monitor=NULL;
}

static int sc26_monitor_fault(int fd) {
  if(sc26.monitor_fd==fd) {
    fprintf(stderr,"Steam Controller 2026: udev monitor lost; rescan will reattach\n");
    sc26_drop_monitor();
  } else sc26_remove_fd(fd);
  return LOOP_OK;
}

static void sc26_rearm_monitor(void) {
  if(!sc26_running()||!sc26.udev||sc26.monitor)return;
  struct udev_monitor *monitor=udev_monitor_new_from_netlink(sc26.udev,"udev");
  if(!monitor)return;
  int rc=udev_monitor_filter_add_match_subsystem_devtype(
      monitor,"hidraw",NULL);
  if(rc>=0)rc=udev_monitor_enable_receiving(monitor);
  int fd=rc>=0?udev_monitor_get_fd(monitor):-1;
  if(rc<0||fd<0) {
    udev_monitor_unref(monitor);
    return;
  }
  sc26.monitor=monitor;
  sc26.monitor_fd=fd;
  sc26_add_device_fd(fd,monitor_event,sc26_monitor_fault,POLLIN);
}

static int monitor_event(int fd) {
  if(!sc26.monitor || fd!=sc26.monitor_fd)return LOOP_OK;
  for(int i=0;i<16;++i) {
    errno=0;
    struct udev_device *d=udev_monitor_receive_device(sc26.monitor);
    if(!d) {
      if(errno!=EAGAIN&&errno!=EWOULDBLOCK&&errno!=EINTR)
        sc26_drop_monitor();
      break;
    }
    udev_device_unref(d);
  }
  scan();
  return LOOP_OK;
}
static void sc26_cleanup(void);
static void *sc26_worker(void *unused) {
  (void)unused;
  sc26_rearm_monitor();
  scan();
  __atomic_store_n(&sc26.initializing, false, __ATOMIC_RELEASE);
  __atomic_store_n(&sc26.rescan_requested, true, __ATOMIC_RELEASE);
  update_timer();
  while (sc26_running()) {
    initialize_links();
    struct pollfd fds[SC26_LINKS + 3];
    unsigned count=0;
    fds[count++]=(struct pollfd){.fd=sc26.wake_fd,.events=POLLIN};
    fds[count++]=(struct pollfd){.fd=sc26.timer_fd,.events=POLLIN};
    fds[count++]=(struct pollfd){.fd=sc26.monitor_fd,.events=POLLIN};
    for(unsigned i=0;i<SC26_LINKS;++i)
      if(sc26.links[i].fd>=0 && sc26.links[i].initialized) fds[count++]=(struct pollfd){.fd=sc26.links[i].fd,.events=POLLIN};
    const uint64_t epoch=sc26.poll_epoch;
    bool serviced=false;
    int rc=poll(fds,count,SC26_SERVICE_MS);
    if(rc<0 && errno!=EINTR)break;
    for(unsigned i=0;i<count && sc26_running();++i) {
      if(sc26.poll_epoch!=epoch)break; /* A callback replaced the poll snapshot. */
      if(!fds[i].revents)continue;
      int fd=fds[i].fd;
      if(i==0) { wake_event(fd);serviced=true; }
      else if(i==1) { timer_event(fd);serviced=true; }
      else if(i==2) {
        if(fds[i].revents&(POLLERR|POLLHUP|POLLNVAL))sc26_monitor_fault(fd);
        else monitor_event(fd);
      } else if(fds[i].revents&(POLLERR|POLLHUP|POLLNVAL))sc26_raw_fault(fd);
      else raw_event(fd);
    }
    /* Timer allocation/arming failures cannot disable keepalive/recovery. */
    uint64_t now=now_ms();
    if(now>=sc26.next_scan_ms){sc26_rearm_monitor();scan();}
    if(sc26_running() && !serviced)service(now);
  }
  sc26_cleanup();
  return NULL;
}

bool sc26_start(void) {
  const char *disable=getenv("MOONLIGHT_STEAM_CONTROLLER");
  if(disable && !strcmp(disable,"0"))return false;
  if(sc26_running())return true;
  if(sc26.worker_abandoned || sc26.worker_started)return false;
  sc26.udev=udev_new();
  if(!sc26.udev)return false;
  for(unsigned i=0;i<SC26_LINKS;++i)reset_link(&sc26.links[i]);
  __atomic_store_n(&sc26.running, true, __ATOMIC_RELEASE);
  sc26.wake_fd=eventfd(0,EFD_NONBLOCK|EFD_CLOEXEC);
  sc26.timer_fd=timerfd_create(CLOCK_MONOTONIC,TFD_NONBLOCK|TFD_CLOEXEC);
  if(sc26.wake_fd<0||sc26.timer_fd<0) {sc26_cleanup();return false;}
  sc26_add_fd(sc26.wake_fd,wake_event,POLLIN);
  sc26_add_fd(sc26.timer_fd,timer_event,POLLIN);
  /* Initial metadata scan has no device feature transfers. */
  scan();
  __atomic_store_n(&sc26.initializing, true, __ATOMIC_RELEASE);
  if(pthread_create(&sc26.worker,NULL,sc26_worker,NULL)!=0) {
    __atomic_store_n(&sc26.initializing, false, __ATOMIC_RELEASE);
    sc26_cleanup();
    return false;
  }
  sc26.worker_started=true;
  atexit(sc26_stop);
  return true;
}
/* Direct USB/BLE controllers represent physical pads at HID claim time.
 * A Puck is only a receiver: it must NOT reserve a host slot until a valid
 * controller state arrives. Puck arrivals remain dynamic after connect. */
int sc26_claimed_controller_count(void) {
  int count = 0;
  pthread_mutex_lock(&sc26.lock);
  if (sc26_running()) {
    for (unsigned i = 0; i < SC26_LINKS; ++i)
      if (sc26.links[i].fd >= 0 &&
          sc26_initial_slot_eligible(sc26.links[i].product == SC26_PUCK,
                                     __atomic_load_n(&sc26.links[i].have_state, __ATOMIC_ACQUIRE)))
        ++count;
  }
  pthread_mutex_unlock(&sc26.lock);
  return count;
}
void sc26_set_online(bool online) {
  pthread_mutex_lock(&sc26.publication_lock);
  pthread_mutex_lock(&sc26.lock);
  __atomic_store_n(&sc26.online, online, __ATOMIC_RELEASE);
  pthread_mutex_unlock(&sc26.lock);
  pthread_mutex_unlock(&sc26.publication_lock);
}
static void sc26_cleanup(void) {
  pthread_mutex_lock(&sc26.lock);
  __atomic_store_n(&sc26.running, false, __ATOMIC_RELEASE); /* Reject new host feedback before restoring. */
  pthread_mutex_unlock(&sc26.lock);
  for(unsigned i=0;i<SC26_LINKS;++i)
    if(sc26.links[i].fd>=0)close_link(&sc26.links[i],true);
  pthread_mutex_lock(&sc26.lock);
  __atomic_store_n(&sc26.online, false, __ATOMIC_RELEASE);
  pthread_mutex_unlock(&sc26.lock);
  sc26_drop_monitor();
  if(sc26.udev)udev_unref(sc26.udev);
  sc26.monitor=NULL;sc26.udev=NULL;sc26.monitor_fd=-1;
  if(sc26.timer_fd>=0){sc26_remove_fd(sc26.timer_fd);close(sc26.timer_fd);}
  sc26.timer_fd=-1;
  pthread_mutex_lock(&sc26.lock);
  /* A simultaneous callback must not write a retired eventfd. */
  const int wake=sc26.wake_fd;
  sc26.wake_fd=-1;
  for(unsigned i=0;i<SC26_LINKS;++i)reset_link(&sc26.links[i]);
  pthread_mutex_unlock(&sc26.lock);
  if(wake>=0){sc26_remove_fd(wake);close(wake);}
}

void sc26_stop(void) {
  sc26_set_online(false); /* Drain short in-flight publishers before common-c teardown. */
  if(!sc26.worker_started)return;
  __atomic_store_n(&sc26.running,false,__ATOMIC_RELEASE);
  pthread_mutex_lock(&sc26.lock);
  if(sc26.wake_fd>=0) { uint64_t one=1; (void)write(sc26.wake_fd,&one,sizeof(one)); }
  pthread_mutex_unlock(&sc26.lock);
  struct timespec deadline;
  clock_gettime(CLOCK_REALTIME,&deadline);
  deadline.tv_nsec+=250000000L;
  deadline.tv_sec+=deadline.tv_nsec/1000000000L;
  deadline.tv_nsec%=1000000000L;
  if(pthread_timedjoin_np(sc26.worker,NULL,&deadline)!=0) {
    fprintf(stderr,"Steam Controller: cleanup pending; process recovery owns final teardown\n");
    sc26.worker_abandoned=true;
    pthread_detach(sc26.worker);
  }
  wait_io_cleanup(&deadline); /* Drain actual restorers within the same bound. */
  sc26.worker_started=false;
}
