"""Behavioral coverage for host-bound actions, audio discovery and HTTP limits."""
import ast
from pathlib import Path
import socket
import tempfile
import types
import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit
from resources.lib.util import audiodevices as audio
from resources.lib.util.appidentity import launch_url
from resources.lib.util.hostapi import Host, HostError, response_deadline
from resources.lib.util.resumestate import host_identity
from resources.lib.util import diagnosticreport


class ReviewRegressions(unittest.TestCase):
    def test_stale_and_unbound_actions_are_rejected(self):
        tree = ast.parse((Path(__file__).parents[1] / 'addon.py').read_text())
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                     and node.name == '_action_host_matches']
        addon = Mock()
        addon.getSetting.return_value = 'host-B'
        scope = dict(addon=addon, args={'host': [host_identity('host-A')]},
                     config_helper=types.SimpleNamespace(config={}),
                     xbmcgui=Mock())
        exec(compile(ast.Module(body=functions, type_ignores=[]), '<addon>', 'exec'), scope)
        self.assertFalse(scope['_action_host_matches']())
        scope['args'] = {}
        self.assertFalse(scope['_action_host_matches']())
        scope['args'] = {'host': [host_identity('host-B')]}
        self.assertTrue(scope['_action_host_matches']())
        url = launch_url('plugin://luna', 'Game', '7', host_identity('host-A'))
        self.assertEqual(parse_qs(urlsplit(url).query)['host'], [host_identity('host-A')])

    def test_named_audio_plugin_probes_its_card(self):
        with patch.object(audio, 'resolve_card', return_value=3), \
             patch.object(audio, '_busy', return_value=True) as busy:
            self.assertTrue(audio.endpoint_busy('surround51:CARD=USB,DEV=2'))
            busy.assert_called_once_with(3, 2)
        with patch.object(audio, '_busy') as busy:
            self.assertFalse(audio.endpoint_busy('default'))
            busy.assert_not_called()

    def test_audio_enumeration_timeout_returns_without_hanging(self):
        with patch.object(audio.subprocess, 'check_output',
                          side_effect=audio.subprocess.TimeoutExpired('aplay', 2)) as call:
            self.assertEqual(audio.list_playback(), [])
            self.assertEqual(call.call_args.kwargs['timeout'], 2)

    def test_hardware_id_is_stable_when_available(self):
        with patch.object(audio.Path, 'read_text', return_value='USB_DAC\n'):
            self.assertEqual(audio.card_identifier(2), 'USB_DAC')
        with patch.object(audio.Path, 'read_text', side_effect=OSError):
            self.assertEqual(audio.card_identifier(2), '2')

    def test_conflicting_duplicate_apps_fail_but_identical_duplicates_collapse(self):
        def xml(second):
            return ('<root status_code="200"><App><AppTitle>One</AppTitle><ID>7</ID></App>'
                    '<App><AppTitle>%s</AppTitle><ID>07</ID></App></root>' % second)
        self.assertEqual(Host.parse_applist(xml('One')), [('7', 'One')])
        with self.assertRaises(HostError):
            Host.parse_applist(xml('Two'))

    def test_deadline_interrupts_a_blocked_read(self):
        left, right = socket.socketpair()
        try:
            left.settimeout(1)
            with response_deadline(types.SimpleNamespace(sock=left), seconds=0.03):
                self.assertEqual(left.recv(1), b'')
        finally:
            left.close()
            right.close()

    def test_report_retention_does_not_follow_symlinks_or_delete_other_files(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            unrelated = root / 'personal.txt'
            unrelated.write_text('keep')
            link = root / 'luna-diagnostics-20260101-000000-link.txt'
            link.symlink_to(unrelated)
            for i in range(25):
                (root / ('luna-diagnostics-20260101-000000-%02d.txt' % i)).write_text('report')
            fd = diagnosticreport.os.open(root, diagnosticreport.os.O_RDONLY)
            try:
                diagnosticreport._prune_reports(fd, '', max_count=20)
            finally:
                diagnosticreport.os.close(fd)
            self.assertEqual(len([p for p in root.glob('luna-diagnostics-*.txt')
                                  if not p.is_symlink()]), 20)
            self.assertEqual(unrelated.read_text(), 'keep')
            self.assertTrue(link.is_symlink())
