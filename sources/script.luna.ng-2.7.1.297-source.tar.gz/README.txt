Luna NG CoreELEC 21 ARM32 version: 2.7.1.297
Luna frontend SHA: cf7be8a12257b3291517a7a478ac71b5ca47a824
Moonlight native SHA: 03fdc3ba81d1bf02dad63841236c2c39ab8ac396
Native GitHub Actions run: 40570641235
luna/: frontend code and package recipe
moonlight-embedded/: compiled native source and recursively checked-out submodules
release-tooling/: separate Kodi addon-ID and release-staging tools
