#!/usr/bin/env python3
"""Stage a new Luna NG release without changing existing Kodi add-ons.

Retain all previously published ZIPs and corresponding-source archives.
The public Kodi index advertises only the latest version of script.luna.ng.
"""
import argparse
import hashlib
import pathlib
import re
import shutil
import tarfile
import xml.etree.ElementTree as ET
import zipfile

ADDON_ID = "script.luna.ng"
OTHER_IDS = frozenset({
    "repository.kodi.utilities",
    "script.kodi.utilities.setup",
    "service.cinema.controls",
})
NATIVE = frozenset({
    "bin/coreelec-ng/moonlight",
    "lib/coreelec-ng/libgamestream.so.4",
    "lib/coreelec-ng/libmoonlight-common.so.4",
    "lib/coreelec-ng/libmoonlight-aml.so",
    "bin/coreelec-ng/gamecontrollerdb.txt",
})
VERSION = re.compile(r"[0-9]+(?:\.[0-9]+){2,3}\Z")


def _version(value):
    if not isinstance(value, str) or not VERSION.fullmatch(value):
        raise ValueError("Invalid Kodi addon version: " + str(value))
    return tuple(map(int, value.split(".")))


def stage(feed, addon_zip, source_bundle):
    feed, addon_zip, source_bundle = map(pathlib.Path, (feed, addon_zip, source_bundle))
    with zipfile.ZipFile(addon_zip) as package:
        if package.testzip() is not None:
            raise ValueError("Corrupted Luna NG ZIP")
        names = package.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate ZIP entries")
        if any(not p.startswith(ADDON_ID + "/") or ".." in pathlib.PurePosixPath(p).parts
               for p in names):
            raise ValueError("Unexpected paths in Luna NG ZIP")
        root = ET.fromstring(package.read(ADDON_ID + "/addon.xml"))
        if root.tag != "addon" or root.get("id") != ADDON_ID:
            raise ValueError("Expected independent Luna NG ID")
        version = root.get("version")
        _version(version)
        for member in NATIVE | {"runtime-manifest.json"}:
            if ADDON_ID + "/" + member not in names:
                raise ValueError("Missing verified native file: " + member)

    expected_name = ADDON_ID + "-" + version + ".zip"
    expected_source = ADDON_ID + "-" + version + "-source.tar.gz"
    if addon_zip.name != expected_name or source_bundle.name != expected_source:
        raise ValueError("Version and release filenames differ")
    if source_bundle.stat().st_size < 100000:
        raise ValueError("Corresponding-source archive is missing or too small")
    # A source archive is required for each version; the original source
    # repository may remain private, but the matching source cannot be hidden.
    with tarfile.open(source_bundle, "r:gz") as source:
        names = {n.lstrip("./") for n in source.getnames()}
    for item in (
        "luna/LICENSE.txt",
        "luna/packaging/package_ng.py",
        "moonlight-embedded/LICENSE",
        "moonlight-embedded/packaging/coreelec-ng/package.mk",
        "release-tooling/build_luna_ng.py",
        "README.txt",
    ):
        if item not in names:
            raise ValueError("Incomplete corresponding source: " + item)

    index_path = feed / "addons.xml"
    checksum_path = feed / "addons.xml.md5"
    before = index_path.read_bytes()
    if hashlib.md5(before).hexdigest() != checksum_path.read_text():
        raise ValueError("Current Kodi feed checksum mismatch")
    tree = ET.fromstring(before)
    if tree.tag != "addons":
        raise ValueError("Unexpected repository index root")
    for addon_id in OTHER_IDS:
        if len(tree.findall("addon[@id='%s']" % addon_id)) != 1:
            raise ValueError("Required public addon missing or duplicated: " + addon_id)
    if tree.find("addon[@id='script.luna']") is not None:
        raise ValueError("Refusing to replace the regular Luna addon")

    previous = tree.findall("addon[@id='%s']" % ADDON_ID)
    if len(previous) > 1:
        raise ValueError("Duplicate existing Luna NG addon index entries")
    if previous:
        old = previous[0]
        if _version(version) <= _version(old.get("version")):
            raise ValueError("New Luna NG version must exceed " + old.get("version"))
        position = list(tree).index(old)
        tree.remove(old)
        tree.insert(position, root)
    else:
        tree.append(root)

    destination = feed / ADDON_ID / expected_name
    companion = feed / "sources" / expected_source
    source_index = feed / "sources" / "README.md"
    for target in (destination, companion):
        if target.exists():
            raise FileExistsError("Refusing to overwrite: " + str(target))
    if not source_index.is_file():
        raise ValueError("Missing existing corresponding-source index")
    text = source_index.read_text(encoding="utf-8")
    if expected_name in text or expected_source in text:
        raise FileExistsError("Release already listed in public source index")

    new_entry = (
        "\n\n## Luna NG " + version + "\n\n"
        "Corresponding source: [" + expected_source + "](" + expected_source + "). "
        "Add-on ZIP: [" + expected_name + "](../" + ADDON_ID + "/" + expected_name + "). "
        "Includes the matching Luna frontend, native Moonlight source with "
        "submodules, and the build/repackaging scripts.\n"
    )
    updated_index = ET.tostring(tree, encoding="utf-8", xml_declaration=True)
    digest = hashlib.md5(updated_index).hexdigest()
    destination.parent.mkdir(parents=True, exist_ok=True)
    companion.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(addon_zip, destination)
    shutil.copyfile(source_bundle, companion)
    if hashlib.sha256(destination.read_bytes()).digest() != hashlib.sha256(addon_zip.read_bytes()).digest():
        raise ValueError("Transferred ZIP contents changed")
    index_path.write_bytes(updated_index)
    checksum_path.write_text(digest, encoding="ascii")
    source_index.write_text(text + new_entry, encoding="utf-8")
    return destination, companion, digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--feed", required=True)
    parser.add_argument("--addon", required=True)
    parser.add_argument("--source", required=True)
    args = parser.parse_args()
    print("Staged new Luna NG release:", stage(args.feed, args.addon, args.source))


if __name__ == "__main__":
    main()
