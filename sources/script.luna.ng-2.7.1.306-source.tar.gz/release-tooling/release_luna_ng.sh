#!/usr/bin/env bash
# Prepare and stage a new, independently named Luna NG release.
# Requires checked-out private repositories, a successful native artifact,
# and a checked-out public Kodi feed. Never pushes to GitHub.
set -euo pipefail

if [ "$#" -ne 3 ]; then
  echo "Usage: release_luna_ng.sh VERSION NATIVE_SHA NATIVE_RUN_ID" >&2
  exit 2
fi
VERSION="$1"
NATIVE_SHA="$2"
RUN_ID="$3"
[[ "$VERSION" =~ ^[0-9]+(\.[0-9]+){3}$ ]] || { echo "Invalid version" >&2; exit 2; }
[[ "$NATIVE_SHA" =~ ^[a-f0-9]{40}$ ]] || { echo "Invalid SHA" >&2; exit 2; }
[[ "$RUN_ID" =~ ^[0-9]{7,}$ ]] || { echo "Invalid native run ID" >&2; exit 2; }

test -s native/moonlight-coreelec21-ng-arm32.tar.gz
test -s luna/LICENSE.txt
test -s moonlight-embedded/LICENSE
test -s moonlight-embedded/packaging/coreelec-ng/package.mk
test -s moonlight-embedded/third_party/moonlight-common-c/src/Limelight.h
test -d public-feed/.git
if [ "$(git -C moonlight-embedded rev-parse HEAD)" != "$NATIVE_SHA" ]; then
  echo "Moonlight source checkout differs from the compiled native artifact" >&2
  exit 1
fi
if git -C moonlight-embedded submodule status --recursive | grep -Eq '^[-+]'; then
  echo "Missing or incorrect source submodules" >&2
  exit 1
fi

mkdir -p release-outputs corresponding/luna corresponding/moonlight-embedded corresponding/release-tooling
python3 -m unittest discover -s luna/tests -p test_package_ng.py -v
python3 luna/packaging/package_ng.py native/moonlight-coreelec21-ng-arm32.tar.gz \
  --source luna --output release-outputs/luna-base.zip
python3 tools/build_luna_ng.py release-outputs/luna-base.zip \
  "release-outputs/script.luna.ng-$VERSION.zip" \
  --version "$VERSION" --native-sha "$NATIVE_SHA" --allow-new-input

# The manifest must match the selected run, and every native file must hash.
python3 - "$VERSION" "$NATIVE_SHA" <<'PY'
import hashlib, json, pathlib, sys, xml.etree.ElementTree as ET, zipfile
version, native_sha = sys.argv[1:]
archive = pathlib.Path("release-outputs") / ("script.luna.ng-" + version + ".zip")
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    prefix = "script.luna.ng/"
    addon = ET.fromstring(z.read(prefix + "addon.xml"))
    assert addon.get("id") == "script.luna.ng"
    assert addon.get("version") == version
    manifest = json.loads(z.read(prefix + "runtime-manifest.json"))
    assert manifest["source_git_sha"] == native_sha
    assert manifest["target"] == "Amlogic-ce/Amlogic-ng/arm"
    for path, info in dict(manifest["objects"], **manifest["assets"]).items():
        data = z.read(prefix + path)
        assert len(data) == info["size"]
        assert hashlib.sha256(data).hexdigest() == info["sha256"]
print("Verified isolated Kodi ID and ARM32 manifest hashes")
PY

# Include recursively checked-out native source, frontend and build tooling.
tar --exclude='.git' --exclude='*/.git' --exclude='__pycache__' --exclude='*/__pycache__' --exclude='*.pyc' -C luna -cf - . | tar -C corresponding/luna -xf -
tar --exclude='.git' --exclude='*/.git' --exclude='__pycache__' --exclude='*/__pycache__' --exclude='*.pyc' -C moonlight-embedded -cf - . | tar -C corresponding/moonlight-embedded -xf -
cp tools/build_luna_ng.py tools/stage_luna_ng.py corresponding/release-tooling/
git -C moonlight-embedded submodule status --recursive > corresponding/MOONLIGHT_SUBMODULE_REVISIONS.txt
{
  printf 'Luna NG CoreELEC 21 ARM32 version: %s\n' "$VERSION"
  printf 'Luna frontend SHA: %s\n' "$(git -C luna rev-parse HEAD)"
  printf 'Moonlight native SHA: %s\n' "$NATIVE_SHA"
  printf 'Native GitHub Actions run: %s\n' "$RUN_ID"
  printf '%s\n' 'luna/: frontend code and package recipe'
  printf '%s\n' 'moonlight-embedded/: compiled native source and recursively checked-out submodules'
  printf '%s\n' 'release-tooling/: separate Kodi addon-ID and release-staging tools'
} > corresponding/README.txt
test -s corresponding/luna/LICENSE.txt
test -s corresponding/moonlight-embedded/LICENSE
test -s corresponding/moonlight-embedded/third_party/moonlight-common-c/src/Limelight.h
tar -C corresponding --sort=name --owner=0 --group=0 --numeric-owner \
  --mtime='UTC 2026-01-01 00:00:00' \
  -czf "release-outputs/script.luna.ng-$VERSION-source.tar.gz" .

python3 tools/stage_luna_ng.py --feed public-feed \
  --addon "release-outputs/script.luna.ng-$VERSION.zip" \
  --source "release-outputs/script.luna.ng-$VERSION-source.tar.gz"
git -C public-feed add addons.xml addons.xml.md5 \
  "script.luna.ng/script.luna.ng-$VERSION.zip" \
  sources/README.md "sources/script.luna.ng-$VERSION-source.tar.gz"
git -C public-feed diff --cached --name-only | sort > release-outputs/changed-paths.txt
printf '%s\n' addons.xml addons.xml.md5 \
  "script.luna.ng/script.luna.ng-$VERSION.zip" \
  sources/README.md "sources/script.luna.ng-$VERSION-source.tar.gz" \
  | sort > release-outputs/expected-paths.txt
diff -u release-outputs/expected-paths.txt release-outputs/changed-paths.txt
git -C public-feed diff --cached --check
test -z "$(git -C public-feed diff --name-only)"

python3 - <<'PY'
import hashlib, pathlib, xml.etree.ElementTree as ET
feed=pathlib.Path("public-feed")
index=(feed/"addons.xml").read_bytes()
assert hashlib.md5(index).hexdigest()==(feed/"addons.xml.md5").read_text()
root=ET.fromstring(index)
for addon in ("repository.kodi.utilities","script.kodi.utilities.setup",
              "service.cinema.controls","script.luna.ng"):
    assert len(root.findall("addon[@id='%s']"%addon)) == 1
assert root.find("addon[@id='script.luna']") is None
print("Verified existing Kodi add-ons and only five staged feed files")
PY
echo "Luna NG $VERSION validated and staged; no public push was performed."
