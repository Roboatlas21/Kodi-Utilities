#!/usr/bin/env python3
"""Repackage a CoreELEC 21 ARM32 Luna ZIP under the separate Kodi addon ID.

Default arguments reproduce the original pinned 2.7.1.280 release.
For later versions, pass --version, --native-sha and --allow-new-input.
The native runtime manifest and every bundled native binary digest are verified.
"""
import hashlib
import json
import pathlib
import re
import stat
import sys
import argparse
import xml.etree.ElementTree as ET
import zipfile

OLD = "script.luna"
NEW = "script.luna.ng"
VERSION = "2.7.1.280"
EXPECTED_INPUT = "c1652f6bd653bf33d714a342a926778dfe45f7a31695328716b69352993a979e"
EXPECTED_NATIVE_SHA = "c1ae6949b41676097e549dc15c6a4b31d9ce5053"
PATCH_COUNTS = {
    "addon.py": 2,
    "resources/lib/util/moonlighthelper.py": 3,
    "resources/launchscripts/coreelec/launch.sh": 1,
    "resources/launchscripts/coreelec/hang-diagnostics.sh": 1,
    "resources/settings.xml": 1,
}
NATIVE = (
    "bin/coreelec-ng/moonlight",
    "lib/coreelec-ng/libmoonlight-aml.so",
    "lib/coreelec-ng/libgamestream.so.4",
    "lib/coreelec-ng/libmoonlight-common.so.4",
    "bin/coreelec-ng/gamecontrollerdb.txt",
)


def build(original, output, *, version=VERSION, expected_native_sha=EXPECTED_NATIVE_SHA, expected_input_sha=EXPECTED_INPUT):
    original, output = pathlib.Path(original), pathlib.Path(output)
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    if expected_input_sha is not None and digest != expected_input_sha:
        raise ValueError("Unverified Luna NG input ZIP: " + digest)
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]+){2,3}", version):
        raise ValueError("Invalid version: " + version)
    if not re.fullmatch(r"[a-f0-9]{40}", expected_native_sha):
        raise ValueError("Invalid expected native commit SHA")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(original) as source:
        if source.testzip():
            raise ValueError("Input ZIP failed CRC validation")
        members = source.namelist()
        if len(set(members)) != len(members):
            raise ValueError("Duplicate ZIP members")
        if any(
            not path.startswith(OLD + "/") or ".." in pathlib.PurePosixPath(path).parts
            or "\\" in path or path.startswith("/")
            for path in members
        ):
            raise ValueError("Untrusted input ZIP paths")
        manifest = json.loads(source.read(OLD + "/runtime-manifest.json"))
        if (manifest.get("schema") != "luna-ng-runtime-v1"
                or manifest.get("source_git_sha") != expected_native_sha
                or manifest.get("target") != "Amlogic-ce/Amlogic-ng/arm"):
            raise ValueError("Wrong native binary manifest")
        data_files = {}
        for member in source.infolist():
            rel = member.filename[len(OLD) + 1:]
            if not rel or member.is_dir():
                continue
            if stat.S_ISLNK(member.external_attr >> 16):
                raise ValueError("Symlink in input ZIP: " + rel)
            data = source.read(member)
            if rel == "addon.xml":
                root = ET.fromstring(data)
                if root.tag != "addon" or root.get("id") != OLD:
                    raise ValueError("Unexpected Luna metadata")
                existing_version = root.get("version", "")
                if not re.fullmatch(r"[0-9]+(?:\.[0-9]+){2,3}", existing_version):
                    raise ValueError("Invalid upstream Luna package version")
                root.set("version", version)
                root.set("id", NEW)
                root.set("name", "Luna NG (CoreELEC 21 ARM32 test)")
                meta = root.find("extension[@point='xbmc.addon.metadata']")
                if meta is None:
                    raise ValueError("Missing metadata")
                platform = meta.find("platform")
                if platform is not None:
                    platform.text = "linux"
                license_node = meta.find("license")
                if license_node is None:
                    license_node = ET.SubElement(meta, "license")
                license_node.text = "GPL-3.0-or-later"
                minversion = meta.find("minversion")
                if minversion is None:
                    minversion = ET.SubElement(meta, "minversion")
                minversion.text = "21.0"
                desc = meta.find("description")
                if desc is not None:
                    desc.text = ("Luna Moonlight streaming for CoreELEC 21 NG 32-bit ARM only. "
                                 "Experimental test build; not compatible with CoreELEC 22 NO ARM64.")
                data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            elif rel in PATCH_COUNTS:
                found = data.count(OLD.encode("utf-8"))
                if found != PATCH_COUNTS[rel]:
                    raise ValueError("Unexpected path references in %s: %d" % (rel, found))
                data = data.replace(OLD.encode("utf-8"), NEW.encode("utf-8"))
            data_files[rel] = (member, data)
        for name, info in dict(manifest["objects"], **manifest["assets"]).items():
            b = data_files[name][1]
            if len(b) != info["size"] or hashlib.sha256(b).hexdigest() != info["sha256"]:
                raise ValueError("Native payload modified or missing: " + name)
        if not set(NATIVE) <= set(data_files):
            raise ValueError("Missing native dependency")
        # Complete VFM builds carry a second manifest. Repackaging the Kodi ID
        # must preserve every optional runtime object and its native revision.
        if "vfm/manifest.json" in data_files:
            vfm = json.loads(data_files["vfm/manifest.json"][1])
            if (vfm.get("schema") != "luna-ng-vfm-v1" or
                    vfm.get("moonlight_source_git_sha") != expected_native_sha):
                raise ValueError("Wrong VFM binary manifest")
            for name, info in vfm["objects"].items():
                path = "vfm/" + name
                if path not in data_files:
                    raise ValueError("Missing VFM payload: " + name)
                b = data_files[path][1]
                if len(b) != info["size"] or hashlib.sha256(b).hexdigest() != info["sha256"]:
                    raise ValueError("VFM payload modified: " + name)
        elif any(name.startswith("vfm/") for name in data_files):
            raise ValueError("Missing VFM binary manifest")
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as dest:
            for name, (old, content) in data_files.items():
                info = zipfile.ZipInfo(NEW + "/" + name, date_time=old.date_time)
                info.compress_type = old.compress_type
                info.create_system = old.create_system
                info.external_attr = old.external_attr
                dest.writestr(info, content)
    with zipfile.ZipFile(output) as z:
        if z.testzip() or ET.fromstring(z.read(NEW + "/addon.xml")).get("id") != NEW:
            raise ValueError("Generated NG addon is corrupt")
        for path in (
            "addon.py", "resources/lib/util/confighelper.py",
            "resources/lib/util/moonlighthelper.py",
            "resources/lib/util/runtimecheck.py",
        ):
            compile(z.read(NEW + "/" + path), path, "exec")
    return hashlib.sha256(output.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=pathlib.Path)
    parser.add_argument("output", type=pathlib.Path)
    parser.add_argument("--version", default=VERSION,
                        help="New independent Luna NG version; must increase when publishing")
    parser.add_argument("--native-sha", default=EXPECTED_NATIVE_SHA,
                        help="Exact commit SHA from the successful ARM32 native build")
    parser.add_argument("--allow-new-input", action="store_true",
                        help="Allow an updated Luna package; still verify every native manifest object")
    args = parser.parse_args()
    sha = build(args.original, args.output,
                version=args.version, expected_native_sha=args.native_sha,
                expected_input_sha=None if args.allow_new_input else EXPECTED_INPUT)
    print("Luna NG isolated ZIP SHA256:", sha)


if __name__ == "__main__":
    main()

