Luna NG 2.7.1.306 for CoreELEC 21 NG ARM32, with optional VFM runtime.

This archive contains the exact exported Moonlight and Luna sources, recursive
Moonlight common-code submodules, controller mappings, release-ID transform,
private FFmpeg recipe/nonblocking patch, VFM bridge source, stock CoreELEC build
recipes and patches, stock media module sources, FFmpeg 8.1.2 upstream source,
and libdrm 2.4.120 upstream source. The complete CoreELEC and FFmpeg archives
are supplied as checksummed parts beside this archive in the public repository.
Run python3 upstream/download-sources.py to retrieve and reassemble them.
See SOURCE_PROVENANCE.json for pinned commits
and archive checksums; build-inputs contains the successful build's manifests.
No private Git history or credentials are included.

The stock Linux base is publicly available at the exact recorded revision:
https://github.com/pannal/linux-amlogic/archive/2d0e0cc0db958d8d88f76407ac922f08d9a4004e.tar.gz
Browse the complete kernel source:
https://github.com/pannal/linux-amlogic/tree/2d0e0cc0db958d8d88f76407ac922f08d9a4004e
The kernel source is obtained from that public URL, not embedded in this archive.
Its CoreELEC patches and build configuration are in upstream/CoreELEC-872edca.tar.gz.
The bundled modules use that source and stock CE patches, plus the bridge code
in moonlight-embedded/kernel/moonlight-vfm. The full OS image is not installed.

For the native build use moonlight-embedded/docs/experimental-vfm.md and the
pinned dependencies in build-inputs/source-lock.json. The FFmpeg source archive
is pristine n8.1.2; the CoreELEC DRM PRIME patch and Moonlight nonblocking patch
must both be applied as specified by the build recipes. Stock media modules
also use the patches from the included CoreELEC recipes.

To reproduce this launcher-only update, follow the .306 instructions in
release-tooling/LUNA_NG_PUBLISHING.md using the exact frontend in luna/.
Reuse the original complete native/VFM artifact from public run 41093196059
and the eight-file overlay procedure before the Kodi-ID/version transform.

Compared with .305, the published ZIP changes only addon.xml and launch.sh.
All compiled native/VFM files and manifests are byte-for-byte unchanged.
The launcher now signals previous-session checks before legacy migration,
so Kodi uses its bounded reconciliation wait. Recovery must still be armed
and acknowledged before Kodi stops. Existing pairing/settings are retained.

The new end-to-end test reproduced .305's six-second cancellation with slow
legacy migration and then verified successful handoff after the correction.
A second test verified abandonment leaves Kodi running. All 253 Luna tests,
shell launcher checks and nine packaging tests passed. A local proc namespace
adapter was used for the test environment and is excluded from this archive.
Physical CoreELEC retesting remains pending. No native rebuild was performed.

SOURCE_PROVENANCE.json separates this frontend revision from the original
native build. build-inputs retains that successful build's original manifests.
