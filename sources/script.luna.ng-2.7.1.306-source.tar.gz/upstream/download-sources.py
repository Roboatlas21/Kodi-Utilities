#!/usr/bin/env python3
"""Download and verify the matching CoreELEC and FFmpeg source archives."""
import hashlib,json,pathlib,urllib.request
root=pathlib.Path(__file__).resolve().parent
for archive in json.loads((root/'downloads.json').read_text()):
    chunks=[]
    for part in archive['parts']:
        data=urllib.request.urlopen(part['url']).read()
        assert len(data)==part['size'] and hashlib.sha256(data).hexdigest()==part['sha256'],part['name']
        chunks.append(data)
    data=b''.join(chunks)
    assert len(data)==archive['size'] and hashlib.sha256(data).hexdigest()==archive['sha256'],archive['archive']
    (root/archive['archive']).write_bytes(data)
    print('Verified',archive['archive'])
