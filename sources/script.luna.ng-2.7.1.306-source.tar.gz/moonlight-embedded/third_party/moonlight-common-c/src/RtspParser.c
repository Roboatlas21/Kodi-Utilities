#include "Platform.h"
#include "Rtsp.h"
#include <limits.h>
#include <errno.h>

// Case-insensitive ASCII string comparison for RTSP header names
static int rtspStrCaseCmp(const char* s1, const char* s2) {
    while (*s1 && *s2) {
        char c1 = (*s1 >= 'A' && *s1 <= 'Z') ? (*s1 + ('a' - 'A')) : *s1;
        char c2 = (*s2 >= 'A' && *s2 <= 'Z') ? (*s2 + ('a' - 'A')) : *s2;
        if (c1 != c2) {
            return (unsigned char)c1 - (unsigned char)c2;
        }
        s1++;
        s2++;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

// Check if String s begins with the given prefix
static bool startsWith(const char* s, const char* prefix) {
    return strncmp(s, prefix, strlen(prefix)) == 0;
}

// Trims trailing spaces and tabs from s in place
static void trimTrailingWhitespace(char* s) {
    size_t len = strlen(s);
    while (len > 0 && (s[len - 1] == ' ' || s[len - 1] == '\t')) {
        s[--len] = '\0';
    }
}

// Gets the length of the message
static int getMessageLength(PRTSP_MESSAGE msg) {
    POPTION_ITEM current;

    // Initialize to 1 for null terminator
    size_t count = 1;

    // Add the length of the protocol
    count += strlen(msg->protocol);

    // Add length of request-specific strings
    if (msg->type == TYPE_REQUEST) {
        count += strlen(msg->message.request.command);
        count += strlen(msg->message.request.target);

        // two spaces and \r\n
        count += MESSAGE_END_LENGTH;
    }
    // Add length of response-specific strings
    else {
        char statusCodeStr[16];
        snprintf(statusCodeStr, sizeof(statusCodeStr), "%d", msg->message.response.statusCode);
        count += strlen(statusCodeStr);
        count += strlen(msg->message.response.statusString);
        // two spaces and \r\n
        count += MESSAGE_END_LENGTH;
    }
    // Count the size of the options
    current = msg->options;

    while (current != NULL) {
        count += strlen(current->option);
        count += strlen(current->content);
        // :[space] and \r\n
        count += MESSAGE_END_LENGTH;
        current = current->next;
    }
    // /r/n ending
    count += CRLF_LENGTH;

    count += msg->payloadLength;

    return (int)count;
}

// Check if we're at the end of the message portion marked by \r\n\r\n
static bool checkMessageEnded(char* endCheck, char* messageBuffer, int length, char** payload) {
    if (endCheck <= messageBuffer + length) {
        int remaining = (int)((messageBuffer + length) - endCheck);

        // RTSP over ENet doesn't always have the second CRLF for some reason
        if (remaining == 0) {
            return true;
        }
        // Previous `if` statement already handle situation when two bytes are missing.
        // This is the workaround for the same problem, but for only one byte missing.
        // Sometimes on android emulators last byte or two bytes are missing.
        // This is link to this bug in Goggle Issue Tracker:
        // https://issuetracker.google.com/issues/150758736?pli=1
        else if (remaining == 1 && endCheck[0] == '\r') {
            return true;
        }
        else if (remaining >= 2 && memcmp(endCheck, "\r\n", 2) == 0) {
            // We've encountered the end of the message - mark it thus
            // The payload is the remainder of messageBuffer. If none, then payload = null
            if (remaining > 2) {
                *payload = &endCheck[2];
            }

            return true;
        }
        else if (remaining >= 1 && endCheck[0] == '\n') {
            // End of message marked by bare LF
            if (remaining > 1) {
                *payload = &endCheck[1];
            }

            return true;
        }
    }

    return false;
}

// Terminates current line at lineEnd and returns a pointer to the start of the next line
static char* getNextLine(char* lineEnd, char* bufferEnd) {
    char origEnd = *lineEnd;
    *lineEnd = '\0';
    char* nextLine = lineEnd + 1;
    if (origEnd == '\r' && nextLine < bufferEnd && *nextLine == '\n') {
        nextLine++;
    }
    return nextLine;
}

// Skips spaces and tabs, returning a pointer to the first non-whitespace character
static char* skipSpaces(char* s) {
    while (*s == ' ' || *s == '\t') {
        s++;
    }
    return s;
}

// Extracts the next whitespace-delimited token from *ptr, null-terminates it, and advances *ptr
static char* getNextToken(char** ptr) {
    char* token = skipSpaces(*ptr);
    if (*token == '\0') {
        *ptr = token;
        return NULL;
    }

    char* end = token;
    while (*end != '\0' && *end != ' ' && *end != '\t') {
        end++;
    }

    if (*end != '\0') {
        *end = '\0';
        *ptr = skipSpaces(end + 1);
    }
    else {
        *ptr = end;
    }

    return token;
}

// Given an RTSP message string rtspMessage, parse it into an RTSP_MESSAGE struct msg
int parseRtspMessage(PRTSP_MESSAGE msg, char* rtspMessage, int length) {
    char* protocol;
    char* target;
    char* statusStr;
    char* command;
    char* sequence;
    char flag;
    bool messageEnded = false;

    char* payload = NULL;
    char* opt = NULL;
    int statusCode = 0;
    int sequenceNum;
    int exitCode;
    POPTION_ITEM options = NULL;
    POPTION_ITEM newOpt;

    if (length <= 0) {
        return RTSP_ERROR_MALFORMED;
    }

    // Put the raw message into a string we can use
    char* messageBuffer = malloc(length + 1);
    if (messageBuffer == NULL) {
        exitCode = RTSP_ERROR_NO_MEMORY;
        goto ExitFailure;
    }
    memcpy(messageBuffer, rtspMessage, length);

    // The payload logic depends on a null-terminator at the end
    messageBuffer[length] = '\0';

    char* ptr = messageBuffer;
    char* bufferEnd = messageBuffer + length;

    // Find the end of the start line
    char* lineEnd = strpbrk(ptr, "\r\n");
    if (lineEnd == NULL) {
        exitCode = RTSP_ERROR_MALFORMED;
        goto ExitFailure;
    }

    char* nextLine = getNextLine(lineEnd, bufferEnd);

    ptr = skipSpaces(ptr);

    // The message is a response
    if (startsWith(ptr, "RTSP/")) {
        flag = TYPE_RESPONSE;

        protocol = getNextToken(&ptr);
        char* codeStr = getNextToken(&ptr);
        if (codeStr == NULL) {
            exitCode = RTSP_ERROR_MALFORMED;
            goto ExitFailure;
        }

        char* endPtr;
        errno = 0;
        long val = strtol(codeStr, &endPtr, 10);
        if (endPtr == codeStr || *endPtr != '\0' || errno == ERANGE || val <= 0 || val > INT_MAX) {
            exitCode = RTSP_ERROR_MALFORMED;
            goto ExitFailure;
        }
        statusCode = (int)val;
        statusStr = ptr;
        trimTrailingWhitespace(statusStr);

        target = NULL;
        command = NULL;
    }
    // The message is a request
    else {
        flag = TYPE_REQUEST;

        command = getNextToken(&ptr);
        target = getNextToken(&ptr);
        protocol = getNextToken(&ptr);
        if (target == NULL || protocol == NULL) {
            exitCode = RTSP_ERROR_MALFORMED;
            goto ExitFailure;
        }

        statusStr = NULL;
    }

    if (strcmp(protocol, "RTSP/1.0")) {
        exitCode = RTSP_ERROR_MALFORMED;
        goto ExitFailure;
    }

    ptr = nextLine;

    // Parse remaining options
    while (ptr <= bufferEnd) {
        if (checkMessageEnded(ptr, messageBuffer, length, &payload)) {
            messageEnded = true;
            break;
        }

        lineEnd = strpbrk(ptr, "\r\n");
        if (lineEnd == NULL) {
            break;
        }

        nextLine = getNextLine(lineEnd, bufferEnd);

        char* colon = strchr(ptr, ':');
        if (colon == NULL) {
            exitCode = RTSP_ERROR_MALFORMED;
            goto ExitFailure;
        }

        *colon = '\0';
        opt = skipSpaces(ptr);
        trimTrailingWhitespace(opt);
        if (*opt == '\0') {
            exitCode = RTSP_ERROR_MALFORMED;
            goto ExitFailure;
        }

        char* val = skipSpaces(colon + 1);
        trimTrailingWhitespace(val);

        // Create a new node containing the option and content
        newOpt = (POPTION_ITEM)malloc(sizeof(OPTION_ITEM));
        if (newOpt == NULL) {
            exitCode = RTSP_ERROR_NO_MEMORY;
            goto ExitFailure;
        }
        newOpt->flags = 0;
        newOpt->option = opt;
        newOpt->content = val;
        newOpt->next = NULL;
        insertOption(&options, newOpt);

        ptr = nextLine;
    }

    // If we never encountered the double CRLF, then the message is malformed!
    if (!messageEnded) {
        exitCode = RTSP_ERROR_MALFORMED;
        goto ExitFailure;
    }

    // Get sequence number as an integer
    sequence = getOptionContent(options, "CSeq");
    sequenceNum = SEQ_INVALID;
    if (sequence != NULL) {
        char* endPtr;
        errno = 0;
        long val = strtol(sequence, &endPtr, 10);
        if (endPtr != sequence && *endPtr == '\0' && errno != ERANGE && val >= 0 && val <= INT_MAX) {
            sequenceNum = (int)val;
        }
    }
    // Package the new parsed message into the struct
    if (flag == TYPE_REQUEST) {
        createRtspRequest(msg, messageBuffer, FLAG_ALLOCATED_MESSAGE_BUFFER | FLAG_ALLOCATED_OPTION_ITEMS, command, target,
            protocol, sequenceNum, options, payload, payload ? length - (int)(payload - messageBuffer) : 0);
    }
    else {
        createRtspResponse(msg, messageBuffer, FLAG_ALLOCATED_MESSAGE_BUFFER | FLAG_ALLOCATED_OPTION_ITEMS, protocol, statusCode,
            statusStr, sequenceNum, options, payload, payload ? length - (int)(payload - messageBuffer) : 0);
    }
    return RTSP_ERROR_SUCCESS;

ExitFailure:
    if (options) {
        freeOptionList(options);
    }
    if (messageBuffer) {
        free(messageBuffer);
    }
    return exitCode;
}

// Create new RTSP message struct with response data
void createRtspResponse(PRTSP_MESSAGE msg, char* message, int flags, char* protocol,
    int statusCode, char* statusString, int sequenceNumber, POPTION_ITEM optionsHead, char* payload, int payloadLength) {
    msg->type = TYPE_RESPONSE;
    msg->flags = flags;
    msg->messageBuffer = message;
    msg->protocol = protocol;
    msg->options = optionsHead;
    msg->payload = payload;
    msg->payloadLength = payloadLength;
    msg->sequenceNumber = sequenceNumber;
    msg->message.response.statusString = statusString;
    msg->message.response.statusCode = statusCode;
}

// Create new RTSP message struct with request data
void createRtspRequest(PRTSP_MESSAGE msg, char* message, int flags,
    char* command, char* target, char* protocol, int sequenceNumber, POPTION_ITEM optionsHead, char* payload, int payloadLength) {
    msg->type = TYPE_REQUEST;
    msg->flags = flags;
    msg->protocol = protocol;
    msg->messageBuffer = message;
    msg->options = optionsHead;
    msg->payload = payload;
    msg->payloadLength = payloadLength;
    msg->sequenceNumber = sequenceNumber;
    msg->message.request.command = command;
    msg->message.request.target = target;
}

// Retrieves option content from the linked list given the option title
char* getOptionContent(POPTION_ITEM optionsHead, char* option) {
    POPTION_ITEM current = optionsHead;
    while (current != NULL) {
        // Check if current node is what we're looking for
        if (!rtspStrCaseCmp(current->option, option)) {
            return current->content;
        }
        current = current->next;
    }
    // Not found
    return NULL;
}

// Adds new option opt to the struct's option list
void insertOption(POPTION_ITEM* optionsHead, POPTION_ITEM opt) {
    POPTION_ITEM current = *optionsHead;

    // Empty options list
    if (*optionsHead == NULL) {
        opt->next = NULL;
        *optionsHead = opt;
        return;
    }

    // Traverse the list and insert the new option at the end
    while (current != NULL) {
        // Check for self-insertion
        if (current == opt) {
            LC_ASSERT(current != opt);
            return;
        }

        // Check for duplicate option; if so, replace the option currently there
        if (!rtspStrCaseCmp(current->option, opt->option)) {
            if (current->flags & FLAG_ALLOCATED_OPTION_FIELDS) {
                free(current->option);
                free(current->content);
            }
            current->option = opt->option;
            current->content = opt->content;
            current->flags = opt->flags;
            free(opt);
            return;
        }
        if (current->next == NULL) {
            opt->next = NULL;
            current->next = opt;
            return;
        }
        current = current->next;
    }
}

// Free every node in the message's option list
void freeOptionList(POPTION_ITEM optionsHead) {
    POPTION_ITEM current = optionsHead;
    POPTION_ITEM temp;
    while (current != NULL) {
        temp = current;
        current = current->next;
        if (temp->flags & FLAG_ALLOCATED_OPTION_FIELDS) {
            free(temp->option);
            free(temp->content);
        }
        free(temp);
    }
}

bool appendString(char* dest, int* destOffset, int* destRemainingLength, const char* source) {
    int ret = snprintf(&dest[*destOffset], *destRemainingLength, "%s", source);
    if (ret < 0 || ret >= *destRemainingLength) {
        LC_ASSERT(false);
        return false;
    }

    *destOffset += ret;
    *destRemainingLength -= ret;
    return true;
}

// Serialize the message struct into a string containing the RTSP message
char* serializeRtspMessage(PRTSP_MESSAGE msg, int* serializedLength) {
    int size = getMessageLength(msg);
    int offset = 0;
    char* serializedMessage;
    POPTION_ITEM current = msg->options;
    char statusCodeStr[16];

    serializedMessage = malloc(size);
    if (serializedMessage == NULL) {
        return NULL;
    }

    if (msg->type == TYPE_REQUEST) {
        // command [space]
        if (!appendString(serializedMessage, &offset, &size, msg->message.request.command) || !appendString(serializedMessage, &offset, &size, " ")) {
            goto fail;
        }
        // target [space]
        if (!appendString(serializedMessage, &offset, &size, msg->message.request.target) || !appendString(serializedMessage, &offset, &size, " ")) {
            goto fail;
        }
        // protocol \r\n
        if (!appendString(serializedMessage, &offset, &size, msg->protocol) || !appendString(serializedMessage, &offset, &size, "\r\n")) {
            goto fail;
        }
    }
    else {
        // protocol [space]
        if (!appendString(serializedMessage, &offset, &size, msg->protocol) || !appendString(serializedMessage, &offset, &size, " ")) {
            goto fail;
        }
        // status code [space]
        snprintf(statusCodeStr, sizeof(statusCodeStr), "%d", msg->message.response.statusCode);
        if (!appendString(serializedMessage, &offset, &size, statusCodeStr) || !appendString(serializedMessage, &offset, &size, " ")) {
            goto fail;
        }
        // status str\r\n
        if (!appendString(serializedMessage, &offset, &size, msg->message.response.statusString) || !appendString(serializedMessage, &offset, &size, "\r\n")) {
            goto fail;
        }
    }
    // option content\r\n
    while (current != NULL) {
        if (!appendString(serializedMessage, &offset, &size, current->option) || !appendString(serializedMessage, &offset, &size, ": ")) {
            goto fail;
        }
        if (!appendString(serializedMessage, &offset, &size, current->content) || !appendString(serializedMessage, &offset, &size, "\r\n")) {
            goto fail;
        }
        current = current->next;
    }
    // Final \r\n
    if (!appendString(serializedMessage, &offset, &size, "\r\n")) {
        goto fail;
    }

    // payload
    if (msg->payload != NULL) {
        if (msg->payloadLength > size) {
            goto fail;
        }

        // Add the payload after
        memcpy(&serializedMessage[offset], msg->payload, msg->payloadLength);

        *serializedLength = offset + msg->payloadLength;
    }
    else {
        *serializedLength = offset;
    }

    // Ensure null-termination as reserved by getMessageLength
    serializedMessage[*serializedLength] = '\0';

    return serializedMessage;

fail:
    free(serializedMessage);
    return NULL;
}

// Free everything in a msg struct
void freeMessage(PRTSP_MESSAGE msg) {
    // If we've allocated the message buffer
    if (msg->flags & FLAG_ALLOCATED_MESSAGE_BUFFER) {
        free(msg->messageBuffer);
    }

    // If we've allocated any option items
    if (msg->flags & FLAG_ALLOCATED_OPTION_ITEMS) {
        freeOptionList(msg->options);
    }

    // If we've allocated the payload
    if (msg->flags & FLAG_ALLOCATED_PAYLOAD) {
        free(msg->payload);
    }
}
