/* SPDX-License-Identifier: GPL-3.0-or-later
 * CoreELEC-only local overlay on the pinned Nonary common-c submodule.
 * This adds observation only: no receive policy, retransmit, FEC or jitter
 * deadline changes. The Debug setting is the existing Luna environment flag.
 */
#include "Limelight-internal.h"
#include "LunaNetDiagnostics.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __linux__
#include <sys/stat.h>
#endif

static LunaNetworkDebugV1 net_debug;
static bool net_debug_on;
static int video_socket_fd = -1;
static uint64_t last_datagram_us;
/* Each timing histogram has one producer. An even generation marks a
 * coherent sample, odd means its writer is updating multiple atomics. */
static uint32_t receiver_generation, fec_generation;

/* Inclusive microsecond bucket upper bounds; final bucket is unbounded. */
static const uint32_t boundaries[LUNA_NET_DEBUG_BINS - 1] = {
  100, 250, 500, 1000, 2000, 4000, 8000, 16000, 33000
};

bool LunaNetDebugEnabled(void) {
  return __atomic_load_n(&net_debug_on, __ATOMIC_RELAXED);
}

void LunaNetDebugInit(void) {
  const char *setting = getenv("MOONLIGHT_STREAM_DIAGNOSTICS");
  __atomic_store_n(&net_debug_on, false, __ATOMIC_RELEASE);
  memset(&net_debug, 0, sizeof(net_debug));
  last_datagram_us = 0;
  __atomic_store_n(&receiver_generation, 0, __ATOMIC_SEQ_CST);
  __atomic_store_n(&fec_generation, 0, __ATOMIC_SEQ_CST);
  video_socket_fd = -1;
  if (setting != NULL && strcmp(setting, "1") == 0) {
    net_debug.abi = LUNA_NET_DEBUG_ABI;
    __atomic_store_n(&net_debug_on, true, __ATOMIC_RELEASE);
  }
}

void LunaNetDebugCount(enum LunaNetDebugCounter counter, uint32_t value) {
  if (!LunaNetDebugEnabled() || (unsigned)counter >= LUNA_NET_COUNTERS) return;
  __atomic_fetch_add(&net_debug.counts[counter], value, __ATOMIC_RELAXED);
}

static void record_duration(LunaNetworkTimingV1 *metric, uint32_t *generation,
                            uint64_t start_us,
                            enum LunaNetDebugCounter long_stall) {
  if (!start_us || !LunaNetDebugEnabled()) return;
  const uint64_t now_us = PltGetMicroseconds();
  if (now_us < start_us) return;
  const uint64_t elapsed = now_us - start_us;
  if (elapsed > 1000000U) LunaNetDebugCount(long_stall, 1U);
  /* Publish generation before touching the histogram so the reader cannot
   * see a new sample count paired with an older bucket distribution. */
  __atomic_add_fetch(generation, 1U, __ATOMIC_SEQ_CST);
  /* Extremely long stalls are saturated, not silently excluded. */
  const uint32_t duration = elapsed > UINT32_MAX ? UINT32_MAX : (uint32_t)elapsed;
  unsigned bin = 0;
  while (bin < LUNA_NET_DEBUG_BINS - 1 && duration > boundaries[bin]) ++bin;
  __atomic_fetch_add(&metric->samples, 1U, __ATOMIC_RELAXED);
  __atomic_fetch_add(&metric->sum_16us,
                     (uint32_t)(((uint64_t)duration + 8U) / 16U),
                     __ATOMIC_RELAXED);
  __atomic_fetch_add(&metric->bins[bin], 1U, __ATOMIC_RELAXED);
  uint32_t old = __atomic_load_n(&metric->worst_us, __ATOMIC_RELAXED);
  while (old < duration && !__atomic_compare_exchange_n(
      &metric->worst_us, &old, duration, true,
      __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
  __atomic_add_fetch(generation, 1U, __ATOMIC_SEQ_CST);
}

uint64_t LunaNetDebugDatagram(int bytes) {
  if (bytes <= 0 || !LunaNetDebugEnabled()) return 0;
  const uint64_t now_us = PltGetMicroseconds();
  LunaNetDebugCount(LUNA_NET_UDP_DATAGRAMS, 1);
  LunaNetDebugCount(LUNA_NET_UDP_BYTES, (uint32_t)bytes);
  if (last_datagram_us && now_us > last_datagram_us) {
    const uint64_t gap = now_us - last_datagram_us;
    if (gap > 20000U) LunaNetDebugCount(LUNA_NET_RX_GAP_20MS, 1);
    if (gap > 50000U) LunaNetDebugCount(LUNA_NET_RX_GAP_50MS, 1);
  }
  last_datagram_us = now_us;
  return now_us;
}

void LunaNetDebugReceiverWork(uint64_t start_us) {
  record_duration(&net_debug.receiver_work, &receiver_generation,
                  start_us, LUNA_NET_RX_STALL_GT1S);
}

void LunaNetDebugFecWork(uint64_t start_us) {
  record_duration(&net_debug.fec_work, &fec_generation,
                  start_us, LUNA_NET_FEC_STALL_GT1S);
}

/* Linux doubles the SO_RCVBUF value returned by getsockopt to account for
 * bookkeeping. Half the reported value is a comparable kernel buffer target,
 * not a guarantee of that many bytes of usable UDP payload. */
void LunaNetDebugSocketSet(int fd, uint32_t requested_bytes) {
  if (!LunaNetDebugEnabled()) return;
#ifdef __linux__
  video_socket_fd = fd;
  net_debug.socket_rcvbuf_requested = requested_bytes;
  int value = 0;
  socklen_t length = sizeof(value);
  if (fd >= 0 && getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &value, &length) == 0 &&
      length == sizeof(value) && value > 0) {
    net_debug.socket_rcvbuf_linux_usable = (uint32_t)value / 2U;
    net_debug.socket_rcvbuf_known = 1U;
  }
#else
  (void)fd;
  (void)requested_bytes;
#endif
}

#ifdef __linux__
/* Linux 4.9 exposes per-socket drops in /proc/net/udp{,6}. Match the exact
 * inode from fstat() on OUR video UDP fd; never use netstat global counters.
 * The proc files are read by Luna's independent 1-Hz monitor only. */
static bool proc_socket_drops(const char *path, uint64_t inode, uint32_t *drops) {
  FILE *f = fopen(path, "r");
  if (!f) return false;
  char line[768];
  bool found = false;
  while (fgets(line, sizeof(line), f) != NULL) {
    char *fields[16];
    unsigned n = 0;
    char *save = NULL;
    for (char *p = strtok_r(line, " \t\r\n", &save);
         p != NULL && n < 16; p = strtok_r(NULL, " \t\r\n", &save))
      fields[n++] = p;
    if (n < 13) continue;
    errno = 0;
    char *end = NULL;
    const unsigned long long value = strtoull(fields[9], &end, 10);
    if (errno || end == fields[9] || *end || value != inode) continue;
    errno = 0;
    const unsigned long long count = strtoull(fields[12], &end, 10);
    if (!errno && end != fields[12] && !*end && count <= UINT32_MAX) {
      *drops = (uint32_t)count;
      found = true;
    }
    break;
  }
  fclose(f);
  return found;
}

static bool kernel_socket_drops(uint32_t *drops) {
  struct stat st;
  if (video_socket_fd < 0 || fstat(video_socket_fd, &st) != 0 ||
      !st.st_ino) return false;
  const uint64_t inode = (uint64_t)st.st_ino;
  return proc_socket_drops("/proc/net/udp", inode, drops) ||
         proc_socket_drops("/proc/net/udp6", inode, drops);
}
#endif

/* Exact peer chosen by common-c's RTSP/network negotiation. The OSD opens
 * after connection setup and never reads this while it is being resolved.
 * No DNS re-resolution or guessed address family is involved. */
bool LiGetLunaConnectedPeerV1(struct sockaddr_storage *out, uint32_t size) {
  if (!out || size != sizeof(*out) ||
      (RemoteAddr.ss_family != AF_INET && RemoteAddr.ss_family != AF_INET6))
    return false;
  memcpy(out, &RemoteAddr, sizeof(*out));
  return true;
}

bool LiGetLunaNetworkDebugV1(LunaNetworkDebugV1 *out, uint32_t bytes) {
  if (!out || bytes != sizeof(*out) || !LunaNetDebugEnabled()) return false;
  memset(out, 0, sizeof(*out));
  out->abi = LUNA_NET_DEBUG_ABI;
  for (unsigned i = 0; i < LUNA_NET_COUNTERS; ++i)
    out->counts[i] = __atomic_load_n(&net_debug.counts[i], __ATOMIC_RELAXED);
  LunaNetworkTimingV1 *dst[2] = {&out->receiver_work, &out->fec_work};
  const LunaNetworkTimingV1 *src[2] = {&net_debug.receiver_work, &net_debug.fec_work};
  const uint32_t *generations[2] = {&receiver_generation, &fec_generation};
  for (unsigned j = 0; j < 2; ++j) {
    bool consistent = false;
    for (unsigned attempt = 0; attempt < 64; ++attempt) {
      const uint32_t before =
          __atomic_load_n(generations[j], __ATOMIC_SEQ_CST);
      if (before & 1U) continue;
      dst[j]->samples = __atomic_load_n(&src[j]->samples, __ATOMIC_RELAXED);
      dst[j]->sum_16us = __atomic_load_n(&src[j]->sum_16us, __ATOMIC_RELAXED);
      dst[j]->worst_us = __atomic_load_n(&src[j]->worst_us, __ATOMIC_RELAXED);
      for (unsigned i = 0; i < LUNA_NET_DEBUG_BINS; ++i)
        dst[j]->bins[i] = __atomic_load_n(&src[j]->bins[i], __ATOMIC_RELAXED);
      consistent = __atomic_load_n(generations[j], __ATOMIC_SEQ_CST) == before;
      if (consistent) break;
    }
    if (!consistent) return false; /* A busy writer: retry next sample. */
  }
  out->socket_rcvbuf_requested = net_debug.socket_rcvbuf_requested;
  out->socket_rcvbuf_linux_usable = net_debug.socket_rcvbuf_linux_usable;
  out->socket_rcvbuf_known = net_debug.socket_rcvbuf_known;
#ifdef __linux__
  out->kernel_udp_drops_known = kernel_socket_drops(&out->kernel_udp_drops);
#endif
  return true;
}
