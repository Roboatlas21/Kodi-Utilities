/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_GAMESTREAM_URL_HOST_H
#define MOONLIGHT_GAMESTREAM_URL_HOST_H

#include <arpa/inet.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* A configured host has a 255-byte bound. URI brackets and RFC 6874 zone
 * escaping add a few characters; keep this shared limit comfortably above
 * those additions without allowing unbounded URL-host copying. */
#define MOONLIGHT_URL_HOST_CAP 320U

/* Format ONLY the URI host, not the port, path, or user-controlled query.
 * The original address is intentionally unchanged for pairing identity,
 * normal name resolution and the Moonlight-common-c transport. */
static inline bool moonlight_url_host(const char *address,
                                      char *output, size_t capacity) {
  if (!address || !output || !capacity) return false;
  const size_t length = strlen(address);
  if (length == 0 || length > 255) return false;

  const bool bracketed = address[0] == '[';
  if (bracketed && (length < 4 || address[length - 1] != ']'))
    return false;
  const char *inner = bracketed ? address + 1 : address;
  const size_t inner_length = length - (bracketed ? 2u : 0u);

  /* All address validation is bytewise: URL delimiters and non-ASCII input
   * cannot become a second authority, a path, or query parameters. */
  if (inner_length == 0 || inner_length > 255) return false;
  char host[256];
  memcpy(host, inner, inner_length);
  host[inner_length] = '\0';

  const bool ipv6 = strchr(host, ':') != NULL;
  if (!ipv6) {
    if (bracketed) return false;
    for (size_t i = 0; i < inner_length; ++i) {
      const unsigned char c = (unsigned char)host[i];
      if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_'))
        return false;
    }
    const int n = snprintf(output, capacity, "%s", host);
    return n > 0 && (size_t)n < capacity;
  }

  const char *percent = strchr(host, '%');
  if (percent && strchr(percent + 1, '%')) return false;
  const size_t address_length = percent ? (size_t)(percent - host)
                                        : inner_length;
  if (address_length == 0 || address_length >= INET6_ADDRSTRLEN)
    return false;
  char bare[INET6_ADDRSTRLEN];
  memcpy(bare, host, address_length);
  bare[address_length] = '\0';
  struct in6_addr parsed;
  if (inet_pton(AF_INET6, bare, &parsed) != 1) return false;

  const char *zone = NULL;
  if (percent) {
    zone = percent + 1;
    /* Accept already-escaped RFC 6874 input as well as raw %eth0, without
     * expanding %25eth0 into %2525eth0. Raw zone names beginning with "25"
     * are ambiguous; prefer the standard encoded representation. */
    if (zone[0] == '2' && zone[1] == '5') {
      if (!zone[2]) return false;  /* Empty RFC 6874 zone is not valid. */
      zone += 2;
    }
    if (!*zone) return false;
    for (const unsigned char *p = (const unsigned char *)zone; *p; ++p) {
      if (!( (*p >= 'a' && *p <= 'z') ||
             (*p >= 'A' && *p <= 'Z') ||
             (*p >= '0' && *p <= '9') ||
             *p == '_' || *p == '-' || *p == '.' || *p == '~'))
        return false;
    }
  }
  const int n = zone
      ? snprintf(output, capacity, "[%s%%25%s]", bare, zone)
      : snprintf(output, capacity, "[%s]", bare);
  return n > 0 && (size_t)n < capacity;
}

#endif
