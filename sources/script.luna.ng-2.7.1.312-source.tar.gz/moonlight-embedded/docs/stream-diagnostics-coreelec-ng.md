# Streaming health logging on CoreELEC NG

Luna's Advanced settings → **Enable Moonlight Debug Output** controls this
logging and is off by default. With debug enabled it writes
one `STREAM_DIAG_V1` line per second to the existing session `logfile`, including
when the statistics overlay is off or unavailable. Switch debug off to disable these samples. There is no separate health toggle. A direct native launch can opt in with
`MOONLIGHT_STREAM_DIAGNOSTICS=1`. This requires the updated native binary and
Luna source in the next add-on build; the published 2.7.1.301 package is unchanged.

`STREAM_DIAG_CONFIG_V1` records pipeline, requested dimensions, FPS and bitrate.
`STREAM_DIAG_START_V1` records wall-clock Unix seconds. Samples carry elapsed
`t_ms` and actual `dt_ms`; a delayed sampler is visible as a longer interval.
The first sample establishes baselines. Later `+` values describe that interval,
not lifetime totals. The existing `CodecWriteFail` field remains a lifetime count.

| Evidence | What it can help distinguish |
| --- | --- |
| `Host`, `RTT`, `Assembly`, video/FEC packet rates | Host processing, transport disruption or delayed assembly; the pinned video library does not populate recovery/OOS/error counters, so those fields show `n/a` |
| `cb`, callback age/gaps, `VQ`, `queue_mean_ms`, `queue20` | Video submission activity and time spent waiting in Moonlight's decoder queue; callback gaps alone do not prove a network fault |
| `Submit`, `submit20/50`, `EAGAIN`, `BPWait`, `BPDrop`, `QBufFail`, IDR and write failures | Slow AML submission, input backpressure, failed balanced-pacing buffer returns or reference recovery |
| `Dec`, `Sink`, decoder drops/errors and kernel queue | Decoder throughput versus the display sink's selected-frame changes; sink counts are not physical panel presents |
| `audio=alsa`, callback age/gaps, slow callbacks, PCM delay and its age, XRUN/recovery/failed-packet counts | Audio callback starvation, long writes/recovery, stale queue samples and underruns |
| `SysCPU`, `Th0` | Aggregate device CPU usage and thermal zone 0 temperature; neither alone proves throttling |

`cb_gap50/100` count intervals over 50/100 ms between video submit callbacks.
`submit20/50` count submit calls taking over 20/50 ms. `queue20` counts frames
waiting over 20 ms after common-c enqueues them. These fixed thresholds are
observations, not automatic diagnoses, and must be read alongside configured FPS.
In balanced pacing, a failed `VIDIOC_QBUF` increments `QBufFail`; Moonlight keeps
that dequeued buffer at the head of its local ring and retries it instead of
forgetting the index and shrinking the capture-buffer pool.

Audio `gap50` counts callback gaps over 50 ms; `slow20/50` count callback work
over 20/50 ms. `delay_ms` is signed ALSA PCM delay sampled on the audio thread
at most once per second. Missing/failed delay reads show `n/a`. Always inspect
`delay_age_ms`: an old value is not a current queue reading. PCM `state` uses
ALSA's numeric enum (2=PREPARED, 3=RUNNING, 4=XRUN, 7=SUSPENDED). Counters also
cover the optional ALSA resync path. A stalled callback leaves an increasing
`cb_age_ms` while the independent monitor continues sampling.

The AML detail counters are unavailable in the experimental VFM path and are
marked `native=n/a`; network/audio/system samples remain available. Missing
kernel measurements remain `n/a`. Scalars use lock-free 32-bit publication and
are approximate across concurrent callbacks. Counter deltas and timestamp ages
tolerate 32-bit wrap. Counters are reset for each session.


## Network reception and packet recovery (same Debug toggle)

The CoreELEC private build now overlays instrumentation onto the **exact pinned**
Nonary moonlight-common-c submodule (`3f9c009fe01db573cd29c1f286db5b7fa8a922fc`).
The underlying gitlink is unchanged and Nonary's public fork is not edited.
The CoreELEC build recipe applies the overlay only to the *temporary unpacked
package* before CMake scans common-c source files. Unexpected common-c file
hashes fail the build rather than silently patching the wrong revision.

Debug already sets `MOONLIGHT_STREAM_DIAGNOSTICS=1`. With this flag enabled,
one `NET_DIAG_V1` line is emitted per second alongside the existing health and
pacing lines. The first line is a baseline; all later `+N` values are deltas
since the previous sample, including wrap-safe 32-bit counters.

| Counter | What it actually means |
| --- | --- |
| `udp_datagrams`, `udp_bytes` | UDP datagrams/bytes read by the dedicated video socket, including duplicate, invalid and encrypted packets; **actual receives**, not nominal packets in a frame |
| `data_accepted`, `parity_accepted` | Actual distinct incoming RTP data/parity packets accepted by the FEC reorder queue; reconstructed shards are **not** counted again |
| `reordered`, `duplicates`, `rejected` | Accepted out-of-order packets, observed duplicates and packets rejected by the RTP parser/window; duplicate may also be counted as rejected |
| `runt`, `decrypt_failed` | Too-small UDP datagrams and failed video AES-GCM decryptions |
| `fec_attempts`, `fec_recovered_data`, `fec_failed_attempts` | Invoked Reed–Solomon reconstruction, **successfully reconstructed data shards**, and failed attempts; missing parity packets are not inferred as recovered video |
| `abandoned_data`, `abandoned_blocks` | Outstanding missing data in an **incomplete block abandoned at the next frame/block boundary** (normal H.264/HEVC only); this is **not** a count of packets proven lost on the network |
| `decoder_queue_overflows` | Common-c's bounded 15-frame decode queue overflow and forced IDR recovery |
| `rx_gap20`, `rx_gap50` | Gaps between returned UDP datagrams over 20/50 ms. Normal low-FPS host pacing or idle periods can cause these; they are **not** proven receiver-thread stalls |
| `receiver_work` | Elapsed time spent handling *valid, decrypted and parsed* UDP video packet(s), including FEC work and potential OS preemption, after `recvfrom()` |
| `fec_work` | Elapsed CPU-thread time around each actual FEC reconstruction attempt, including its temporary allocations. This is elapsed time, not isolated CPU execution time |
| `kernel_udp_drops` | Linux **per-socket kernel receive drops** from `/proc/net/udp{,6}` matched by the socket's inode. `n/a` when the kernel or container does not expose it; it is not the entire network path's loss count |
| `rcvbuf_req_bytes`, `rcvbuf_linux_half_bytes` | Requested socket buffer, and half of Linux's doubled `SO_RCVBUF` value; a kernel memory-accounting target, not guaranteed usable UDP payload bytes |

`receiver_work` and `fec_work` have observed counts, 16-us-precision mean,
P95 bucket and P99 bucket. The histogram bins are upper bounds, not exact
quantiles, and `>33000` means the final unbounded bin (microseconds).
Slow `recvfrom()` blocking time is **not** included in `receiver_work`.
The kernel drop counter is sampled by the independent monitor once per second,
never in the hot receive loop. The receiver takes additional monotonic clock
reads only with Debug enabled; it does not switch to `recvmsg` or alter UDP
receive, FEC, jitter, decoder, or buffer policies.

**Important:** The older `VideoPkt/FECpkt` rates in `STREAM_DIAG_V1` come from
frame-header *advertised packet totals*, not actual delivered packets. Use the
new `NET_DIAG_V1` `udp_datagrams/data_accepted/parity_accepted` fields for
observed reception. Video RTP diagnostic fields that have no implementation
are still shown as `n/a` rather than fictional zero loss.

Useful comparison: collect a 4K60 quiet baseline, reproduce stutter at the
same bitrate with host Wi-Fi loaded, and then repeat with the host wired.
Kernel UDP drops rising alongside longer receiver/FEC work suggests pressure
on the client. Arrival jitter without client drops may instead originate from
the host's Wi-Fi, capture or packet scheduling. Neither conclusion is proven
without corroborating host counters and reproduction.

**Build requirements:** `git submodule update --init --recursive` remains
required. The private CoreELEC package overlay now copies the ABI header and
observer implementation into its unpacked common-c tree and applies guarded,
pinned-source modifications. Older installed Luna ZIPs do **not** acquire these
counters until the native ARM32 common library is rebuilt and packaged.
A previous cached Moonlight package should be cleaned and rebuilt.
Tests: `python3 -m unittest discover -s tests -p test_network_debug_overlay.py`
and `bash tests/test_stream_diagnostics.sh`. No GitHub workflow is required
to run these locally.

## Frame pacing evidence (same Debug toggle)

The standard AML decoder now emits a `PACING_DIAG_V1` record every second
alongside the existing stream health record. At normal shutdown it prints a
`PACING_SUMMARY_V1` and a `PACING_TIMING_V1` line per available stage.
The first interval establishes baselines. There is no new Luna setting.

| Signal | Meaning |
| --- | --- |
| `arrival_pairs`, `late`, `early`, `invalid` | Gap between assembled-frame enqueue timestamps compared with the source PTS gap for consecutive frames; invalid/discontinuous observations are excluded |
| `submit`, `write` | Time inside the decoder submission callback and each `codec_write` call |
| `decode_gap` | Spacing between observed decoded V4L2 DQBUF events, not exact decoder completion |
| `poll`, `timeouts` | How long the userspace pump waits for driver readiness |
| `empty_wakes`, `near_wake` | Driver readiness with no locally queued frame, and a frame found within 3 ms in the following loop pass; a *candidate opportunity*, not a confirmed missed TV refresh |
| `depth_iter_mean`, `depth_peak` | Iteration-weighted local queue depth and peak; not time-weighted video delay |
| `cap`, `raises`, `lowers`, `dropped`, `returned` | Adaptive maximum queue limit and pump handoffs/drops; cap does not mean frames were buffered |
| `evidence` | Rough stage hint (arrival/submission/post-wake/mixed/none), not a root-cause diagnosis |

Every timing stage has mean, P95 and P99 histogram bucket statistics. P95/P99
are bucket upper boundaries, not exact percentiles; the value `>132000`
indicates the unbounded last bin (microseconds). Short-interval means have
16 microsecond precision; shutdown means use the full accumulated sum.
Adaptive mode additionally logs `PACING_ADAPT_V1` when its cap changes,
including the qualifying frame, late, burst and empty counts.

Two fixed rings retain at most 64 unusual timing events each (input and
display) in RAM. Up to the latest 12 per ring are logged on shutdown as
`PACING_EVENT_V1`; there are no per-frame disk writes. No additional
decoder IOCTL, sysfs query, buffer, frame drop or pacing decision is
introduced. With Debug OFF no new timing work is performed on the video
threads. Lowest Latency/direct mode has no userspace V4L2 pump; its poll
and decoded-dequeue metrics are unavailable. The experimental VFM pipeline
also lacks these AML-specific records.

**None of these measurements is a physical HDMI presentation timestamp.**
They can identify *where* evidence of uneven delivery accumulates, but
cannot by themselves prove a display refresh was missed or distinguish all
host/network faults.

The monitor starts only after the connection initializes and stops before
connection teardown. Headless logging never opens DRM or claims a display plane.
With health diagnostics active, duplicate OSD text rows are suppressed; the
visual overlay still refreshes at its selected rate. There is no per-frame
health logging or new queue/recovery policy. Most rows are under
1 KB, with a 2304-byte stream-row limit, a 1200-byte pacing-row limit and a
1200-byte network-row limit (combined worst-case under 17 MiB/hour before
existing debug/error rows). The network monitor also performs two short
read-only proc lookups per second at most for kernel socket-drop evidence.
These limits do not include the bounded shutdown summary/events. Existing rotation keeps the previous session; it is not a size cap
within a long session. Disable debug after collecting a reproduction.

After a slowdown, collect the usual CoreELEC log ZIP after exiting Moonlight.
Luna's current/previous session logs provide a timeline through the slowdown.
Compare the affected seconds with normal seconds on either side; do not infer
one cause from lifetime totals or one isolated counter.

Validation: host tests exercise the actual headless monitor with DRM calls
mocked, real ALSA callback code with PCM/Opus calls mocked, interval deltas,
idle stalls, stale/unavailable readings and u32 wrap. Strict host and ARM32
syntax checks cover the audio source, AML backend and monitor. ARM32 formatter
and actual audio-callback tests also execute under QEMU. These tests do not establish
target-device overhead or identify the existing slowdown without a new log.

The earlier, uninstrumented common library only updated its nominal
`packetCountVideo` and `packetCountFec` frame-header totals; they are not
actual UDP receive counts. Existing OSD `FECrec/FECfail/OOS/Invalid`
remain unavailable until populated through a separate verified ABI.
The new private `NET_DIAG_V1` fields instead report explicit observed
packet, FEC and socket stages. Receiver counts do not prove where a
network packet was lost, nor do they measure host capture jitter.
CPU/temperature cannot prove throttling, and timing instrumentation itself
still requires AM6B+ validation before comparing low-latency performance.

### Updated receiver diagnostics

New `NET_DIAG_V1` values `old_window` and `old_frame` count stale
sequence/window and stale-frame rejects separately from confirmed duplicates.
A stale packet might be delayed, replayed or redundant: its classification
does **not** prove which of those occurred.

The instrumentation now retains receiver and FEC timing samples above one
second in the final histogram bin and session worst value. Two new counters
(`rx_stall_gt1s` and `fec_stall_gt1s`) count these extreme observations.
Timing values over the 32-bit microsecond range are saturated, not discarded.

The native integration test now injects reordered, repeated and missing RTP
data into the **real patched** common-c video FEC/reassembly code, using
deterministic Reed-Solomon test doubles to verify recovery accounting. This
is not a replacement for real on-device packet loss/FEC performance tests.

### Session Debug log budget

The native monitor stops **periodic** `STREAM_DIAG_V1`, `PACING_DIAG_V1`
and `NET_DIAG_V1` sampling when the active regular file reaches 32 MiB.
It emits one `STREAM_DIAG_LIMIT_V1` notice, does not truncate or rotate the
open file, and keeps playback and other error/status logging available.
The limit is therefore a periodic-diagnostic budget, not a hard cap on all
native or shell output. Non-file destinations are unaffected.
