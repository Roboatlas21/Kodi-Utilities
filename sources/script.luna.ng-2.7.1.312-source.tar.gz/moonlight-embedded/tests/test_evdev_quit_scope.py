"""A keyboard hot-unplug must discard its pending local exit request."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class InputExitScopeTests(unittest.TestCase):
    def test_exit_intent_is_stored_per_physical_keyboard(self):
        source = (ROOT / "src/input/evdev.c").read_text()
        device = source.split("struct input_device {", 1)[1].split("};", 1)[0]
        handler = source.split("static bool evdev_handle_event(", 1)[1].split(
            "static void evdev_snapshot_mapping_rest(", 1)[0]
        remove = source.split("static void evdev_remove(", 1)[1].split(
            "static bool evdev_axis_usable(", 1)[0]
        self.assertIn("bool pendingQuitOnModifiersUp;", device)
        self.assertIn("dev->pendingQuitOnModifiersUp = true;", handler)
        self.assertIn("dev->pendingQuitOnModifiersUp = false;", handler)
        self.assertIn("dev->pendingQuitOnModifiersUp && dev->modifiers == 0", handler)
        self.assertNotIn("static bool waitingToExitOnModifiersUp", source)
        # The pending state dies with the owned input device and cannot arm
        # a newly attached keyboard or a second controller.
        self.assertIn("free(device);", remove)


if __name__ == "__main__":
    unittest.main()
