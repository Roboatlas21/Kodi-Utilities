#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-or-later
# Use the CoreELEC opengl-meson headers, including its platform_fbdev EGL
# headers, or an installed equivalent. No graphics libraries/hardware needed.
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
includes=()
if [ -n "${FBDEV_OSD_INCLUDE_DIR:-}" ]; then
  includes+=("-I$FBDEV_OSD_INCLUDE_DIR")
fi
${CC:-cc} -std=gnu99 -Wall -Wextra -Werror -O1 -g \
  "${includes[@]}" ${CFLAGS:-} tests/test_osd_fbdev.c src/osd/layout.c src/osd/frametime.c \
  -ldl ${LDFLAGS:-} -o "$work/test_osd_fbdev"
"$work/test_osd_fbdev"
