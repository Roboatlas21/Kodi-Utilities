"""Run production keyboard/button forwarding with two physical sources."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class InputOwnership(unittest.TestCase):
    def test_shared_keys_buttons_and_left_right_modifiers(self):
        source = (ROOT / 'src/input/evdev.c').read_text()
        helpers = source[source.index('static int evdev_mouse_button_index'):source.index('static void evdev_remove')]
        start = source.index('    if (ev->code < sizeof(keyCodes)/sizeof(keyCodes[0])) {')
        end = source.index('\n    } else {', start)
        body = source[start:end] + '\n    }\n    return true;\n}'
        harness = r'''
#include <assert.h>
#include <stdbool.h>
#include <pthread.h>
#include <linux/input.h>
#include <Limelight.h>
#include "keyboard.h"
#define ACTION_MODIFIERS (MODIFIER_SHIFT|MODIFIER_ALT|MODIFIER_CTRL)
#define QUIT_KEY KEY_Q
struct input_device {
 unsigned char held_keys[(KEY_CNT+7)/8]; bool held_mouse_buttons[5];
 char modifiers; bool pendingQuitOnModifiersUp;
};
static struct input_device a,b;
static struct input_device *devices[]={&a,&b};
static int numDevices=2;
static pthread_mutex_t devices_mutex=PTHREAD_MUTEX_INITIALIZER;
static unsigned releases, mouse_releases;
static char last_modifiers;
int LiSendKeyboardEvent(short key,char action,char modifiers) {
 (void)key; if(action==KEY_ACTION_UP) releases++; last_modifiers=modifiers; return 0;
}
int LiSendMouseButtonEvent(char action,int key) {
 (void)key; if(action==BUTTON_ACTION_RELEASE)mouse_releases++;return 0;
}
''' + helpers + '\nstatic bool key(struct input_event *ev, struct input_device *dev) {\n' + body + r'''
static void send(struct input_device *dev,unsigned code,int value) {
 struct input_event ev={.code=code,.value=value};assert(key(&ev,dev));
}
int main(void) {
 send(&a,KEY_LEFTSHIFT,1);send(&a,KEY_RIGHTSHIFT,1);
 send(&a,KEY_LEFTSHIFT,0);assert(last_modifiers & MODIFIER_SHIFT);
 send(&a,KEY_RIGHTSHIFT,0);assert(!(last_modifiers & MODIFIER_SHIFT));
 send(&a,KEY_W,1);send(&b,KEY_W,1);releases=0;
 send(&a,KEY_W,0);assert(releases==0);
 send(&b,KEY_W,0);assert(releases==1);
 send(&a,KEY_LEFTCTRL,1);send(&b,KEY_A,1);
 assert(last_modifiers & MODIFIER_CTRL);
 evdev_send_mouse_button(&a,BUTTON_ACTION_PRESS,BUTTON_LEFT);
 evdev_send_mouse_button(&b,BUTTON_ACTION_PRESS,BUTTON_LEFT);
 evdev_send_mouse_button(&a,BUTTON_ACTION_RELEASE,BUTTON_LEFT);
 assert(mouse_releases==0);
 evdev_send_mouse_button(&b,BUTTON_ACTION_RELEASE,BUTTON_LEFT);
 assert(mouse_releases==1);
 return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'input.c';path.write_text(harness)
            binary=Path(tmp)/'input'
            subprocess.run(['cc','-std=gnu99','-Wall','-Wextra','-Werror','-pthread',
                            '-I'+str(ROOT/'src/input'),
                            '-I'+str(ROOT/'third_party/moonlight-common-c/src'),
                            str(path),'-o',str(binary)],check=True)
            subprocess.run([str(binary)],check=True,timeout=5)
