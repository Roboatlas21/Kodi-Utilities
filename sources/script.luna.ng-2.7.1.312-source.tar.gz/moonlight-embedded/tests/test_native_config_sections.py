"""Exercise the real config.c loader with native host-only stubs, no hardware."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile
import unittest

from test_native_quit_parser import STUBS

ROOT = Path(__file__).resolve().parents[1]

TEST_MAIN = r'''
#include "platform.h"
#include "config.h"
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
  CONFIGURATION c;
  if (argc == 3 &&
      (!strcmp(argv[1], "--atomic") ||
       !strcmp(argv[1], "--atomic-input") ||
       !strcmp(argv[1], "--host-overlay"))) {
    memset(&c, 0, sizeof(c));
    c.address = "previous-trusted-host";
    c.app = "previous-app";
    c.stream.width = 1280; c.stream.height = 720;
    c.stream.fps = 60; c.stream.bitrate = -1;
    c.stream.packetSize = 1392; c.sops = true;
    c.hdr = true; c.cec = true;
    if (!strcmp(argv[1], "--atomic-input")) {
      c.inputs[0] = "previous-input";
      c.inputsCount = 1;
      inputAdded = true;
    }
    CONFIGURATION before = c;
    bool valid = !strcmp(argv[1], "--host-overlay")
        ? config_file_parse_for_host(argv[2], &c, "previous-trusted-host")
        : config_file_parse(argv[2], &c);
    printf("atomic=%d unchanged=%d host=%s fps=%d inputs=%d selected=%d hdr=%d cec=%d\n",
           valid, memcmp(&c, &before, sizeof(c)) == 0,
           c.address, c.stream.fps, c.inputsCount, inputAdded, c.hdr, c.cec);
    return valid ? 0 : 10;
  }
  config_parse(argc, argv, &c);
  printf("host=%s width=%d height=%d fps=%d bitrate=%d packet=%d codec=%d port=%u audio=%d remote=%d inputs=%d sops=%d hdr=%d cec=%d osd=%d selected=%d\n",
         c.address ? c.address : "", c.stream.width, c.stream.height,
         c.stream.fps, c.stream.bitrate, c.stream.packetSize, c.codec,
         (unsigned)c.port, c.stream.audioConfiguration,
         c.stream.streamingRemotely, c.inputsCount,
         c.sops, c.hdr, c.cec, c.osd, inputAdded);
  return 0;
}
'''


class NativeConfigSectionsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which('cc'):
            raise unittest.SkipTest('C compiler unavailable')
        cls.work = tempfile.TemporaryDirectory()
        work = Path(cls.work.name)
        for filename, source in STUBS.items():
            (work / filename).write_text(TEST_MAIN if filename == 'main.c' else source)
        (work / 'input').mkdir()
        (work / 'audio').mkdir()
        (work / 'input/evdev.h').write_text('')
        (work / 'audio/audio.h').write_text('')
        for filename in ('config.c', 'config.h', 'config_numeric.h',
                         'config_section.h', 'config_ini.h'):
            shutil.copyfile(ROOT / 'src' / filename, work / filename)
        shutil.copyfile(ROOT / 'src/input/input_limits.h',
                        work / 'input/input_limits.h')
        cls.binary = work / 'test-ini'
        subprocess.run(
            ['cc', '-std=gnu99', '-D_GNU_SOURCE', '-Wall', '-Wextra',
             '-Wno-unused-parameter', '-I', str(work),
             str(work / 'config.c'), str(work / 'main.c'),
             '-o', str(cls.binary)],
            check=True, capture_output=True, text=True)

    @classmethod
    def tearDownClass(cls):
        cls.work.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.env = dict(os.environ, HOME=str(self.root),
                        XDG_CONFIG_DIR=str(self.root))

    def invoke(self, contents, name='sample.ini', args=None):
        path = self.root / name
        if contents is not None:
            path.write_bytes(contents.encode('utf-8') if isinstance(contents, str)
                             else contents)
        command = [str(self.binary), str(path)] if args is None else \
                  [str(self.binary), *args]
        return subprocess.run(command, cwd=self.root, env=self.env,
                              capture_output=True, text=True, timeout=5)

    def check_valid(self, contents, *pieces):
        proc = self.invoke(contents)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        for piece in pieces:
            self.assertIn(piece, proc.stdout)

    def check_invalid(self, contents):
        proc = self.invoke(contents)
        self.assertNotEqual(proc.returncode, 0, proc.stdout)
        self.assertIn('moonlight', proc.stderr.lower())


    def test_save_produces_sectioned_roundtrip_without_losing_supported_options(self):
        original = self.root / 'settings-from-cli.ini'
        original.write_text(
            '[Moonlight]\naddress = gaming-vm\napp = Desktop\n'
            'width = 1920\nheight = 1080\nfps = 120\n'
            'bitrate = 25000\npacketsize = 1392\ncodec = hevc\n'
            'sops = false\nremote = true\nsurround = 5.1\n'
            'hdr = true\ncec = true\nosd = true\n'
            'nomouseemulation = true\n'
            'input = /dev/input/event1\ninput = /dev/input/event3\n')
        output = self.root / 'saved.ini'
        output.write_text('[Moonlight]\naddress = older-vm\n')
        result = self.invoke(None, args=[
            'quit', '-config', str(original), '-save', str(output)])
        self.assertEqual(result.returncode, 0, result.stderr)
        text = output.read_text()
        self.assertTrue(text.startswith('[Moonlight]\n'), text)
        for entry in ('address = gaming-vm', 'codec = h265', 'hdr = true',
                      'cec = true', 'sops = false', 'remote = true',
                      'surround = 5.1', 'nomouseemulation = true',
                      'input = /dev/input/event1', 'input = /dev/input/event3',
                      'width = 1920', 'fps = 120', 'bitrate = 25000'):
            self.assertIn(entry, text)
        self.assertEqual(text.count('input = '), 2)
        self.assertEqual(output.stat().st_mode & 0o777, 0o600)
        reload = self.invoke(None, args=[
            'quit', '-config', str(output)])
        self.assertEqual(reload.returncode, 0, reload.stderr)
        for value in ('host=gaming-vm', 'width=1920', 'height=1080',
                      'fps=120', 'bitrate=25000', 'inputs=2',
                      'codec=2', 'hdr=1', 'cec=1', 'osd=1'):
            self.assertIn(value, reload.stdout)

    def test_save_failure_preserves_existing_bytes(self):
        source = self.root / 'safe.ini'
        source.write_text('[Moonlight]\naddress = legitimate-vm\nfps = 120\n')
        output = self.root / 'saved.ini'
        before = b'[Moonlight]\naddress = old-value\n'
        output.write_bytes(before)
        injected = 'Desktop\naddress = unintended-vm'
        result = self.invoke(None, args=[
            'quit', '-config', str(source), '-app', injected,
            '-save', str(output)])
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(output.read_bytes(), before)
        self.assertEqual(list(self.root.glob('saved.ini.tmp.*')), [])

    def test_save_never_replaces_symlink_or_directory(self):
        source = self.root / 'safe.ini'
        source.write_text('[Moonlight]\naddress = trusted-vm\n')
        victim = self.root / 'victim.ini'
        before = b'[Moonlight]\naddress = victim-vm\n'
        victim.write_bytes(before)
        shortcut = self.root / 'saved.ini'
        shortcut.symlink_to(victim)
        result = self.invoke(None, args=[
            'quit', '-config', str(source), '-save', str(shortcut)])
        self.assertNotEqual(result.returncode, 0)
        self.assertTrue(shortcut.is_symlink())
        self.assertEqual(victim.read_bytes(), before)
        shortcut.unlink()
        shortcut.mkdir()
        result = self.invoke(None, args=[
            'quit', '-config', str(source), '-save', str(shortcut)])
        self.assertNotEqual(result.returncode, 0)
        self.assertTrue(shortcut.is_dir())

    def test_failed_parse_never_partially_modifies_existing_configuration(self):
        contents = ('[Moonlight]\naddress=untrusted-host\nfps=120\n'
                    'input=/dev/input/event2\nhdr=invalid\n')
        path = self.root / 'failure.ini'
        path.write_text(contents)
        result = self.invoke(None, args=['--atomic', str(path)])
        self.assertEqual(result.returncode, 10)
        self.assertIn(
            'atomic=0 unchanged=1 host=previous-trusted-host fps=60 inputs=0 selected=0',
            result.stdout)


    def test_rejected_overlay_never_commits_untrusted_changes(self):
        contents = ('address=redirected-host\nfps=120\nhdr=false\n'
                    'input=/dev/input/event5\n')
        proc = self.invoke(contents, args=[
            '--host-overlay', str(self.root / 'sample.ini')])
        self.assertEqual(proc.returncode, 10)
        self.assertIn('unchanged=1 host=previous-trusted-host fps=60 inputs=0 selected=0 hdr=1 cec=1',
                      proc.stdout)
        self.assertIn('would redirect selected host', proc.stderr)

    def test_overlay_can_change_settings_without_redirecting(self):
        for contents in ('fps=120\nhdr=false\n',
                         'address=previous-trusted-host\nfps=120\n'):
            with self.subTest(contents=contents):
                proc = self.invoke(contents, args=[
                    '--host-overlay', str(self.root / 'sample.ini')])
                self.assertEqual(proc.returncode, 0, proc.stderr)
                self.assertIn('host=previous-trusted-host fps=120', proc.stdout)

    def test_rejected_stage_preserves_prior_strings_and_inputs(self):
        contents = ('address=tentative-host\napp=tentative-app\n'
                    'input=/dev/input/event3\nmapping=missing-configuration.map\n')
        proc = self.invoke(contents, args=[
            '--atomic', str(self.root / 'sample.ini')])
        self.assertEqual(proc.returncode, 10)
        self.assertIn('atomic=0 unchanged=1 host=previous-trusted-host fps=60 inputs=0 selected=0',
                      proc.stdout)

    def test_failure_preserves_existing_input_selection(self):
        contents = 'fps=120\n' + ''.join(
            'input=/dev/input/event%d\n' % i for i in range(32))
        proc = self.invoke(contents, args=[
            '--atomic-input', str(self.root / 'sample.ini')])
        self.assertEqual(proc.returncode, 10)
        self.assertIn('atomic=0 unchanged=1 host=previous-trusted-host fps=60 inputs=1 selected=1',
                      proc.stdout)

    def test_duplicate_hdr_never_commits(self):
        proc = self.invoke('fps=120\nhdr=true\nhdr=false\n', args=[
            '--atomic', str(self.root / 'sample.ini')])
        self.assertEqual(proc.returncode, 10)
        self.assertIn('atomic=0 unchanged=1', proc.stdout)

    def test_explicit_false_clears_prior_booleans(self):
        proc = self.invoke('hdr=false\ncec=false\nfps=120\n', args=[
            '--atomic', str(self.root / 'sample.ini')])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn('atomic=1 unchanged=0', proc.stdout)
        self.assertIn('hdr=0 cec=0', proc.stdout)

    def test_preexisting_snapshot_does_not_inherit_invalid_defaults(self):
        (self.root / 'moonlight.conf').write_text('address=unsafe\nbad_option=true\n')
        snapshot = self.root / 'luna-private.ini'
        snapshot.write_text('[Moonlight]\naddress=isolated-vm\nfps=120\n')
        self.env['LUNA_STREAM_CONFIG'] = str(snapshot)
        proc = self.invoke(None, args=['quit', '-config', str(snapshot)])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn('host=isolated-vm', proc.stdout)
        self.assertIn('fps=120', proc.stdout)
        del self.env['LUNA_STREAM_CONFIG']
        proc = self.invoke(None, args=['quit', '-config', str(snapshot)])
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn('Default Moonlight configuration rejected', proc.stderr)

    def test_ini_conversion_preserves_common_cli_option_semantics(self):
        self.check_valid(
            '[Moonlight]\nwidth=3840\nheight=2160\nfps=120\n'
            'bitrate=50000\npacketsize=1392\ncodec=HEVC\n'
            'port=47989\nremote=yes\nsurround=5.1\n'
            'hdr=true\ncec=true\nosd=true\n',
            'width=3840', 'height=2160', 'fps=120', 'bitrate=50000',
            'packet=1392', 'codec=2', 'port=47989', 'audio=6',
            'remote=1', 'hdr=1', 'cec=1', 'osd=1')

    def test_invalid_numeric_enum_and_buffer_values_rejected(self):
        for contents in (
            'width=1\n', 'height=0\n', 'fps=0\n', 'fps=241\n',
            'bitrate=0\n', 'bitrate=500001\n', 'packetsize=100\n',
            'appid=-1\n', 'appid=999999999999999999999\n',
            'port=65536\n', 'port=0\n', 'pin=0\n',
            'rotate=13\n', 'remote=maybe\n', 'surround=9.1\n',
            'codec=unsupported\n', 'cec=maybe\n', 'hdr=maybe\n',
            'osdargs=' + 'x' * 256 + '\n',
            'keydir=' + 'x' * 4096 + '\n',
        ):
            with self.subTest(contents=contents[:60]):
                self.check_invalid('address=trusted-vm\n' + contents)

    def test_legacy_flat_and_compact_equals_syntax(self):
        self.check_valid('address=old-host\nfps = 60\ninput=/dev/input/event2\n',
                         'host=old-host', 'fps=60', 'inputs=1', 'selected=1')

    def test_crlf_and_boolean_precedence(self):
        self.check_valid('[Moonlight]\r\naddress=game-vm\r\nfps=120\r\n'
                         'hdr=true\r\ncec = yes\r\nsops=false\r\nosd=true\r\n',
                         'host=game-vm', 'fps=120', 'hdr=1', 'cec=1',
                         'sops=0', 'osd=1')

    def test_only_moonlight_section_changes_host(self):
        self.check_valid('address=untrusted\n[Other]\naddress=other\n'
                         '[Moonlight]\naddress=trusted\nfps=120\n'
                         '[Other]\ninput=/dev/input/event8\n',
                         'host=trusted', 'fps=120', 'inputs=0')

    def test_multiple_input_entries_are_supported(self):
        self.check_valid('[Moonlight]\naddress=padhost\n' +
                         ''.join('input=/dev/input/event%d\n' % n
                                 for n in range(32)),
                         'host=padhost', 'inputs=32', 'selected=1')

    def test_oversized_controller_selection_is_rejected(self):
        self.check_invalid('address=host\n' +
                           ''.join('input=/dev/input/event%d\n' % n
                                   for n in range(33)))

    def test_duplicate_or_conflicting_scalar_settings_fail(self):
        for contents in ('address=first\naddress=second\n',
                         '[Moonlight]\naddress=one\n[Moonlight]\naddress=two\n',
                         'fps=60\nfps=120\n'):
            with self.subTest(contents=contents):
                self.check_invalid(contents)

    def test_nested_config_and_save_directives_are_cli_only(self):
        for directive in ('config', 'save'):
            with self.subTest(directive=directive):
                self.check_invalid('address=host\n%s=sample.ini\n' % directive)

    def test_reject_invalid_values_unknown_settings_and_bad_lines(self):
        for contents in (
            'address=host\nhdr=not-a-boolean\n',
            'address=host\nfps=99999999\n',
            'address=host\ncodec=missing\n',
            'address=host\nmade_up_setting=123\n',
            'address=host\nunknown-line\n',
            'address=host\n[Other] unexpected\n',
            '[Other]\naddress=not-the-host\n',
            'address=host\naddress=\n',
            'address=bad host\n',
            'address=host\nmapping=missing.map\n',
        ):
            with self.subTest(contents=contents):
                self.check_invalid(contents)

    def test_reject_binary_oversized_and_symlinked_files(self):
        for payload in (b'address=host\x00suffix\n', b'a' * (1024 * 1024 + 1),
                        b'address=host\rnot-a-line\n'):
            with self.subTest(payload_size=len(payload)):
                self.check_invalid(payload)
        victim = self.root / 'victim.ini'
        victim.write_text('address=host\n')
        link = self.root / 'sample.ini'
        link.unlink()
        link.symlink_to(victim)
        result = subprocess.run([str(self.binary), str(link)], cwd=self.root,
                                env=self.env, capture_output=True,
                                text=True, timeout=5)
        self.assertNotEqual(result.returncode, 0)

    def test_missing_requested_config_is_not_silently_skipped(self):
        path = self.root / 'missing.ini'
        result = self.invoke(None, args=['quit', '-config', str(path)])
        self.assertNotEqual(result.returncode, 0)


    def test_diagnostic_actions_bypass_corrupted_default_only_without_arguments(self):
        # This fixture executes real config_parse(), which must not rely on
        # the default file for explicit, side-effect-free diagnostics.
        (self.root / 'moonlight.conf').write_text(
            '[Moonlight]\naddress = trusted\naddress = redirected\n')
        for action in ('help', 'check-aml', 'check-vfm'):
            with self.subTest(diagnostic=action):
                proc = self.invoke(None, args=[action])
                self.assertEqual(proc.returncode, 0, proc.stderr)
        for action in ('quit', 'list', 'pair', 'stream'):
            with self.subTest(normal_action=action):
                proc = self.invoke(None, args=[action])
                self.assertNotEqual(proc.returncode, 0)
        # Explicit -config is still parsed; an extra -save must not bypass
        # validation or write anything when the default is malformed.
        proc = self.invoke(None, args=['check-aml', '-config',
                                       str(self.root / 'moonlight.conf')])
        self.assertNotEqual(proc.returncode, 0)
        destination = self.root / 'unexpected.ini'
        proc = self.invoke(None, args=['help', '-save', str(destination)])
        self.assertNotEqual(proc.returncode, 0)
        self.assertFalse(destination.exists())

    def test_unreadable_default_config_is_not_silently_skipped(self):
        if os.geteuid() == 0:
            self.skipTest('Running as root bypasses file permission mode')
        path = self.root / 'moonlight.conf'
        path.write_text('address = other-host\n')
        path.chmod(0)
        self.addCleanup(lambda: path.chmod(0o600))
        result = self.invoke(None, args=['quit'])
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Default Moonlight configuration rejected', result.stderr)

    def test_default_config_searches_selected_xdg_directory(self):
        config_root = self.root / 'xdg'
        config_dir = config_root / 'moonlight'
        config_dir.mkdir(parents=True)
        (config_dir / 'moonlight.conf').write_text('address=xdg-host\nfps=90\n')
        self.env['XDG_CONFIG_DIR'] = str(config_root)
        proc = self.invoke(None, args=['quit'])
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn('host=xdg-host', proc.stdout)
        self.assertIn('fps=90', proc.stdout)

    def test_non_regular_file_rejected_without_blocking(self):
        if not hasattr(os, 'mkfifo'):
            self.skipTest('FIFOs unavailable')
        path = self.root / 'pipe.ini'
        os.mkfifo(path)
        result = self.invoke(None, args=['quit', '-config', str(path)])
        self.assertNotEqual(result.returncode, 0)


if __name__ == '__main__':
    unittest.main()
