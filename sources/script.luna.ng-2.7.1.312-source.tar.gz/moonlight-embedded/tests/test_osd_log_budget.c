/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include "../src/osd/log_budget.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
  FILE *f = tmpfile();
  assert(f);
  int fd = fileno(f);
  assert(!osd_diag_log_budget_reached(fd, OSD_DIAG_LOG_LIMIT_BYTES));
  assert(ftruncate(fd, (off_t)OSD_DIAG_LOG_LIMIT_BYTES - 1) == 0);
  assert(!osd_diag_log_budget_reached(fd, OSD_DIAG_LOG_LIMIT_BYTES));
  assert(ftruncate(fd, (off_t)OSD_DIAG_LOG_LIMIT_BYTES) == 0);
  assert(osd_diag_log_budget_reached(fd, OSD_DIAG_LOG_LIMIT_BYTES));
  assert(!osd_diag_log_budget_reached(fd, OSD_DIAG_LOG_LIMIT_BYTES+1));
  assert(!osd_diag_log_budget_reached(-1, OSD_DIAG_LOG_LIMIT_BYTES));
  fclose(f);
  puts("Debug log sample budget respects size threshold and non-file outputs");
  return 0;
}
