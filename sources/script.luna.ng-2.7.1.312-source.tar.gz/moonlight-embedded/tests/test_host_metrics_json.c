/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/osd/host_metrics_json.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
static int ok(const char *json,HostMetricsSample *s) {
  return host_metrics_parse_json(json,strlen(json),s);
}
int main(void) {
  HostMetricsSample s;
  assert(ok("{\"version\":1,\"interval_ms\":1000,\"cpu\":{\"cpu_usage_percent\":42.25},\"gpus\":[{\"id\":1,\"name\":\"NVIDIA\",\"metrics\":{\"gpu_usage_percent\":72,\"gpu_encoder_percent\":51,\"gpu_temperature_c\":65,\"gpu_vram_used_mb\":6543,\"gpu_vram_usage_percent\":63}}]}",&s));
  assert(s.has_cpu&&s.has_gpu&&s.has_encoder&&s.has_temp&&s.has_vram&&s.has_vram_percent);
  assert(fabs(s.cpu-42.25)<.01&&s.gpu==72&&s.encoder==51&&s.vram_mb==6543);
  assert(ok("{\"version\":1, \"cpu\": { \"cpu_usage_percent\": 42 }, \"gpus\": [{ \"metrics\": { \"gpu_usage_percent\": 67 } }] }",&s));
  assert(s.has_cpu && s.has_gpu && s.cpu==42 && s.gpu==67);
  assert(ok("{\"version\":1,\"cpu\":{},\"gpus\":[]}",&s)&&!s.has_cpu&&!s.has_gpu);
  assert(ok("{\"version\":1,\"cpu\":{\"cpu_usage_percent\":null},\"gpus\":[{\"metrics\":{\"gpu_usage_percent\":0}}, {\"metrics\":{\"gpu_usage_percent\":99}}]}",&s));
  assert(s.has_gpu&&s.gpu==0);
  assert(ok("{\"version\":1,\"gpus\":[{\"metrics\":{}},{\"metrics\":{\"gpu_usage_percent\":60}}]}",&s));
  assert(s.has_gpu&&s.gpu==60);
  assert(!ok("{\"version\":2,\"cpu\":{\"cpu_usage_percent\":99}}",&s));
  assert(!ok("{\"version\":1,\"gpus\":[{\"metrics\":{\"gpu_usage_percent\":12}},]}",&s));
  assert(!ok("{\"version\":1}trailing",&s));
  assert(!ok("{\"version\":1,\"cpu\":{\"cpu_usage_percent\":NaN}}",&s));
  assert(!ok("{\"version\":1,\"unknown\": [",&s));
  puts("host metrics JSON parser: OK");
}
