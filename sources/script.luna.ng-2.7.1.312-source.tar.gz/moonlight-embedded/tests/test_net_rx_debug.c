/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/osd/net_rx_log.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

int main(void) {
  LunaNetworkDebugTracker tracker = {0};
  LunaNetworkDebugV1 a = {0}, b;
  char line[1400];
  a.abi = LUNA_NET_DEBUG_ABI;
  a.counts[LUNA_NET_UDP_DATAGRAMS] = 250;
  a.counts[LUNA_NET_UDP_BYTES] = 50000;
  a.socket_rcvbuf_known = 1;
  a.socket_rcvbuf_requested = 3100000;
  a.socket_rcvbuf_linux_usable = 2097152;
  a.kernel_udp_drops_known = 1;
  a.kernel_udp_drops = 7;

  luna_net_debug_format(&tracker, &a, line, sizeof(line));
  assert(strstr(line, "NET_DIAG_V1 baseline=1"));
  assert(strstr(line, "rcvbuf_linux_half_bytes=2097152"));
  assert(strstr(line, "kernel_udp_drops=n/a"));

  b = a;
  b.counts[LUNA_NET_UDP_DATAGRAMS] += 12;
  b.counts[LUNA_NET_UDP_BYTES] += 12000;
  b.counts[LUNA_NET_DATA_ACCEPTED] += 10;
  b.counts[LUNA_NET_PARITY_ACCEPTED] += 2;
  b.counts[LUNA_NET_REORDERED] += 1;
  b.counts[LUNA_NET_DUPLICATES] += 3;
  b.counts[LUNA_NET_FEC_ATTEMPTS] += 2;
  b.counts[LUNA_NET_FEC_RECOVERED_DATA] += 4;
  b.counts[LUNA_NET_ABANDONED_BLOCKS] += 1;
  b.counts[LUNA_NET_ABANDONED_DATA] += 5;
  b.counts[LUNA_NET_OLD_WINDOW] += 2;
  b.counts[LUNA_NET_OLD_FRAME] += 1;
  b.counts[LUNA_NET_RX_STALL_GT1S] += 1;
  b.counts[LUNA_NET_FEC_STALL_GT1S] += 1;
  b.receiver_work.samples=2;
  b.receiver_work.sum_16us=125; /* mean 1000 microseconds */
  b.receiver_work.bins[3]=1; /* <=1ms */
  b.receiver_work.bins[4]=1; /* <=2ms */
  b.fec_work.samples=1;
  b.fec_work.sum_16us=250; /* 4000 microseconds */
  b.fec_work.bins[5]=1;
  b.receiver_work.worst_us=1400000;
  b.fec_work.worst_us=4000;
  b.kernel_udp_drops=9;

  luna_net_debug_format(&tracker, &b, line, sizeof(line));
  assert(strstr(line, "udp_datagrams=+12 udp_bytes=+12000"));
  assert(strstr(line, "data_accepted=+10 parity_accepted=+2"));
  assert(strstr(line, "fec_attempts=+2 fec_recovered_data=+4"));
  assert(strstr(line, "abandoned_data=+5 abandoned_blocks=+1"));
  assert(strstr(line, "kernel_udp_drops=+2"));
  assert(strstr(line, "old_window=+2 old_frame=+1"));
  assert(strstr(line, "rx_stall_gt1s=+1 fec_stall_gt1s=+1"));
  assert(strstr(line, "worst_session_us=1400000"));
  assert(strstr(line, "receiver_work=(n=2 mean_us=1000 p95_bucket_us=2000 p99_bucket_us=2000 worst_session_us=1400000)"));
  assert(strstr(line, "fec_work=(n=1 mean_us=4000 p95_bucket_us=4000 p99_bucket_us=4000 worst_session_us=4000)"));

  b.kernel_udp_drops_known = 0;
  b.counts[LUNA_NET_UDP_DATAGRAMS] = 0;
  a = b;
  a.counts[LUNA_NET_UDP_DATAGRAMS] = UINT32_MAX;
  tracker.previous = a; /* wrap within one interval */
  luna_net_debug_format(&tracker, &b, line, sizeof(line));
  assert(strstr(line, "udp_datagrams=+1"));
  assert(strstr(line, "kernel_udp_drops=n/a"));

  b.abi = 0;
  luna_net_debug_format(&tracker, &b, line, sizeof(line));
  assert(strstr(line, "unavailable=abi-mismatch"));
  assert(!tracker.initialized);

  char tiny[9];
  memset(tiny, 0x55, sizeof(tiny));
  luna_net_debug_format(&tracker, &b, tiny, 8);
  assert(tiny[7] == 0 && tiny[8] == 0x55);
  puts("Network diagnostics: baseline, FEC, kernel socket drops, percentiles, wrap and ABI guard passed");
  return 0;
}
