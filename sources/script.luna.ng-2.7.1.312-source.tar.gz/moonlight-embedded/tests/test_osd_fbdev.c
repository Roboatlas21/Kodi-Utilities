/* SPDX-License-Identifier: GPL-3.0-or-later
 * Exercise the production renderer against a simulated fbdev/EGL driver.
 * No display, GPU, DRM master, or sysfs writes are used by this test.
 */
#define _GNU_SOURCE
#include <assert.h>
#include <stdarg.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <EGL/fbdev_window.h>
#include <GLES2/gl2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int opens, blanks, unblanks, swaps, surfaces, contexts, initialized;
static int libs, closed, failure, drm_present, hidden;
static int width = 1920, height = 1080;
static bool expect_graph = false;
static int test_open(const char *path, int flags, ...) {
  (void)flags; assert(!strcmp(path,"/dev/fb0")); opens++; return 42;
}
static int test_close(int fd) { assert(fd==42); closed++; return 0; }
static int test_access(const char *path, int mode) {
  (void)mode; assert(!strcmp(path,"/dev/dri/card0")); return drm_present ? 0 : -1;
}
static int test_ioctl(int fd, unsigned long request, ...) {
  assert(fd==42);
  va_list args; va_start(args,request);
  if (request==FBIOBLANK) {
    int mode=va_arg(args,int);
    if (mode==FB_BLANK_UNBLANK) { assert(swaps>0); unblanks++; hidden=0; }
    else { assert(mode==FB_BLANK_POWERDOWN); blanks++; hidden=1; }
  } else if (request==FBIOGET_FSCREENINFO) {
    struct fb_fix_screeninfo *f=va_arg(args,void*);
    strcpy(f->id, failure==1 ? "other fb" : "OSD FB");
  } else if (request==FBIOGET_VSCREENINFO) {
    struct fb_var_screeninfo *v=va_arg(args,void*); v->xres=width; v->yres=height;
  } else assert(!"Unexpected display write/mode change");
  va_end(args); return 0;
}
static void *test_dlopen(const char *path, int flags) {
  (void)flags; assert(!strncmp(path,"/usr/lib/",9));
  if (failure==2) return NULL;
  libs++; return (void*)1;
}
static int test_dlclose(void *p) { assert(p); libs--; return 0; }
static void *test_dlsym(void *, const char *);
static char *test_dlerror(void) { return "simulated load failure"; }
#define open test_open
#define close test_close
#define access test_access
#define ioctl test_ioctl
#define dlopen test_dlopen
#define dlclose test_dlclose
#define dlsym test_dlsym
#define dlerror test_dlerror
#include "../src/osd/fbdev.c"
#undef open
#undef close
#undef access
#undef ioctl
#undef dlopen
#undef dlclose
#undef dlsym
#undef dlerror

EGLDisplay eglGetDisplay(EGLNativeDisplayType d) { (void)d; return (void*)1; }
EGLBoolean eglInitialize(EGLDisplay d,EGLint *a,EGLint *b) {
  (void)d;(void)a;(void)b; if(failure==4)return EGL_FALSE; initialized++;return EGL_TRUE;
}
EGLBoolean eglBindAPI(EGLenum api) { assert(api==EGL_OPENGL_ES_API);return EGL_TRUE; }
EGLBoolean eglChooseConfig(EGLDisplay d,const EGLint *a,EGLConfig *c,EGLint n,EGLint *count) {
  (void)d;(void)n; bool alpha=false,window=false;
  for(;*a!=EGL_NONE;a+=2) { if(*a==EGL_ALPHA_SIZE)alpha=a[1]==8;
    if(*a==EGL_SURFACE_TYPE)window=a[1]==EGL_WINDOW_BIT; }
  assert(alpha&&window);*c=(void*)2;*count=failure==5?0:1;return EGL_TRUE;
}
EGLContext eglCreateContext(EGLDisplay d,EGLConfig c,EGLContext share,const EGLint *a) {
  (void)d;(void)c;(void)share; assert(a[0]==EGL_CONTEXT_CLIENT_VERSION&&a[1]==2);
  if(failure==6)return EGL_NO_CONTEXT;
  contexts++;return(void*)3;
}
EGLSurface eglCreateWindowSurface(EGLDisplay d,EGLConfig c,EGLNativeWindowType w,const EGLint *a) {
  (void)d;(void)c;(void)a;fbdev_window *win=(void*)w;
  assert(hidden&&win->width==width&&win->height==height);
  if(failure==7)return EGL_NO_SURFACE;
  surfaces++;return(void*)4;
}
EGLBoolean eglMakeCurrent(EGLDisplay d,EGLSurface a,EGLSurface b,EGLContext c) {
  (void)d;(void)a;(void)b;return failure==8&&c!=EGL_NO_CONTEXT?EGL_FALSE:EGL_TRUE;
}
EGLBoolean eglQuerySurface(EGLDisplay d,EGLSurface s,EGLint a,EGLint *v) {
  (void)d;(void)s;*v=a==EGL_WIDTH?width:height; if(failure==9)(*v)++;return EGL_TRUE;
}
EGLBoolean eglSwapInterval(EGLDisplay d,EGLint i) { (void)d;assert(i==1);return EGL_TRUE; }
EGLBoolean eglSwapBuffers(EGLDisplay d,EGLSurface s) {
  (void)d;(void)s;if(failure==12)return EGL_FALSE;swaps++;return EGL_TRUE;
}
EGLint eglGetError(void) { return EGL_SUCCESS; }
EGLBoolean eglDestroySurface(EGLDisplay d,EGLSurface s) {
  (void)d;(void)s;assert(hidden);surfaces--;return EGL_TRUE;
}
EGLBoolean eglDestroyContext(EGLDisplay d,EGLContext c) { (void)d;(void)c;contexts--;return EGL_TRUE; }
EGLBoolean eglTerminate(EGLDisplay d) { (void)d;initialized--;return EGL_TRUE; }
EGLBoolean eglReleaseThread(void) { return EGL_TRUE; }
GLuint glCreateShader(GLenum t) { (void)t;return 1; }
void glShaderSource(GLuint s,GLsizei n,const GLchar *const *p,const GLint *l) {(void)s;(void)n;(void)p;(void)l;}
void glCompileShader(GLuint s) {(void)s;}
void glGetShaderiv(GLuint s,GLenum p,GLint *v) {(void)s;(void)p;*v=failure!=10;}
void glDeleteShader(GLuint s) {(void)s;}
GLuint glCreateProgram(void) { return 1; }
void glAttachShader(GLuint p,GLuint s) {(void)p;(void)s;}
void glBindAttribLocation(GLuint p,GLuint i,const GLchar *n) {(void)p;(void)i;(void)n;}
void glLinkProgram(GLuint p) {(void)p;}
void glGetProgramiv(GLuint p,GLenum n,GLint *v) {(void)p;(void)n;*v=failure!=11;}
void glDeleteProgram(GLuint p) {(void)p;}
void glUseProgram(GLuint p) {(void)p;}
void glGenTextures(GLsizei n,GLuint *t) { assert(n==1);*t=1; }
void glDeleteTextures(GLsizei n,const GLuint *t) {(void)n;(void)t;}
void glBindTexture(GLenum t,GLuint i) {(void)t;(void)i;}
void glTexParameteri(GLenum t,GLenum n,GLint v) {(void)t;(void)n;(void)v;}
void glTexImage2D(GLenum t,GLint l,GLint i,GLsizei w,GLsizei h,GLint b,GLenum f,GLenum ty,const void *p) {
  (void)t;(void)l;(void)i;(void)b;assert(w>0&&h>0&&f==GL_RGBA&&ty==GL_UNSIGNED_BYTE);
  const unsigned char *rgba=p;size_t white=0,translucent=0,transparent=0,colored=0;
  for(int k=0;k<w*h;k++,rgba+=4) {
    if(rgba[3]==255) {
      uint32_t pixel;memcpy(&pixel,rgba,sizeof(pixel));
      assert(pixel==0xffffffffu || pixel==0xff707070u ||
             pixel==0xffbebebeu || pixel==0xff00ff00u ||
             pixel==0xffff00ffu);
      if(pixel==0xffffffffu) white++; else colored++;
    } else if(rgba[3]==176) {assert(!rgba[0]&&!rgba[1]&&!rgba[2]);translucent++;}
    else {assert(!rgba[0]&&!rgba[1]&&!rgba[2]&&!rgba[3]);transparent++;}
  }
  assert(white&&translucent);if(failure!=13)assert(transparent);
  if(expect_graph) assert(colored>20);
}
void glViewport(GLint x,GLint y,GLsizei w,GLsizei h) {assert(x>=0&&y>=0&&x+w<=width&&y+h<=height);}
void glClearColor(GLfloat r,GLfloat g,GLfloat b,GLfloat a) {assert(!r&&!g&&!b&&!a);}
void glClear(GLbitfield b) {assert(b==GL_COLOR_BUFFER_BIT);}
void glVertexAttribPointer(GLuint i,GLint s,GLenum t,GLboolean n,GLsizei st,const void *p) {
  (void)i;(void)s;(void)t;(void)n;(void)st;(void)p;
}
void glEnableVertexAttribArray(GLuint i) {(void)i;}
void glDrawArrays(GLenum m,GLint f,GLsizei c) {assert(m==GL_TRIANGLE_STRIP&&f==0&&c==4);}
GLenum glGetError(void) {return GL_NO_ERROR;}
static void *test_dlsym(void *lib,const char *name) {
  assert(lib); if(failure==3&&!strcmp(name,"eglMakeCurrent"))return NULL;
#define RESOLVE(fn) if(!strcmp(name,#fn)){ __typeof__(&fn) f=&fn;void *p;memcpy(&p,&f,sizeof(p));return p; }
  EGL_FUNCTIONS(RESOLVE)
  GL_FUNCTIONS(RESOLVE)
#undef RESOLVE
  assert(!"Unmocked function");return NULL;
}
static void reset(void) {
  assert(libs==0&&surfaces==0&&contexts==0&&initialized==0&&opens==closed);
  opens=closed=blanks=unblanks=swaps=failure=drm_present=0;hidden=1;
}
int main(void) {
  OsdOptions opt={.x=-1,.y=40,.font_size=20,.interval_s=1.5};
  unsetenv("FRAMEBUFFER");unsetenv("MOONLIGHT_OSD_TAKEOVER");
  assert(!osd_fbdev_open(&opt)&&opens==0);
  setenv("MOONLIGHT_OSD_TAKEOVER","1",1);
  setenv("FRAMEBUFFER","/dev/fb1",1);assert(!osd_fbdev_open(&opt)&&opens==0);
  unsetenv("FRAMEBUFFER");drm_present=1;assert(!osd_fbdev_open(&opt)&&opens==0);reset();
  for(int stage=1;stage<=11;stage++) {
    failure=stage;assert(!osd_fbdev_open(&opt));assert(!unblanks&&hidden);reset();
  }
  opt.x=10000;assert(!osd_fbdev_open(&opt));assert(!blanks);reset();opt.x=-1;
  OsdFbdev *s=osd_fbdev_open(&opt);assert(s&&unblanks==0);
  assert(osd_fbdev_draw(s,"RTT 5ms","CPU 12%",NULL)&&unblanks==1&&swaps==1);
  failure=12;assert(!osd_fbdev_draw(s,"RTT 5ms","CPU 12%",NULL)&&unblanks==1);
  osd_fbdev_close(s);assert(hidden);reset();
  /* The native graph adds a bounded panel area and preserves alpha layout.
   * No real display is opened by this mocked test. */
  opt.frametime=true;
  s=osd_fbdev_open(&opt);assert(s);
  OsdFtView graph={.requested_fps=60,.count=4};
  graph.callback_gap_us[0]=16667;graph.callback_gap_us[1]=16667;
  graph.callback_gap_us[2]=25000;graph.callback_gap_us[3]=16667;
  graph.return_gap_us[0]=16667;graph.return_gap_us[1]=16667;
  graph.return_gap_us[2]=28000;graph.return_gap_us[3]=16667;
  expect_graph=true;
  assert(osd_fbdev_draw(s,"RTT 5ms","CPU 12%",&graph));
  expect_graph=false;
  osd_fbdev_close(s);reset();opt.frametime=false;
  /* Boundaries: smallest supported GUI, largest font, fully filled panel. */
  width=640;height=360;opt.font_size=100;opt.y=0;
  s=osd_fbdev_open(&opt);assert(s);failure=13;
  char longline[4096];memset(longline,'W',sizeof(longline)-1);longline[4095]=0;
  assert(osd_fbdev_draw(s,longline,longline,NULL));osd_fbdev_close(s);reset();
  puts("PASS: framebuffer ownership, alpha, geometry, initialization failures and teardown");
}
