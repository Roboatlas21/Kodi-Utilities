#!/usr/bin/env bash
# Build the actual patched Nonary RTP queue in an isolated temporary source
# tree; exercises a real out-of-order packet, duplicate, FEC reconstruction
# request and incomplete-frame expiration without touching the pinned gitlink.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
original="$root/third_party/moonlight-common-c"
test -f "$original/src/RtpVideoQueue.c"
test -f "$original/enet/include/enet/enet.h"
test -f "$original/nanors/rs.h"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
src="$tmp/third_party/moonlight-common-c/src"
mkdir -p "$src" "$tmp/src/osd"
for name in VideoStream.c RtpVideoQueue.c VideoDepacketizer.c; do
  cp "$original/src/$name" "$src/$name"
done
cp "$root/src/osd/net_rx_debug.h" "$tmp/src/osd/net_rx_debug.h"
python3 "$root/packaging/coreelec-ng/apply-network-debug.py" "$tmp"
cc -std=gnu11 -O1 -Wall -Wextra -Werror -Wno-unused-parameter -pthread \
   -D_POSIX_C_SOURCE=200809L \
   -I"$original/src" -I"$src" -I"$original/enet/include" \
   -I"$original/nanors" -I"$original/nanors/deps/obl" \
   "$root/tests/test_network_packet_pipeline.c" \
   "$src/RtpVideoQueue.c" "$src/LunaNetDebug.c" \
   -o "$tmp/pipeline"
"$tmp/pipeline"

# Full Reed-Solomon algorithm, not the deterministic stub above.
cc -std=gnu11 -O1 -Wall -Wextra -Werror -Wno-unused-parameter \
   -I"$original/nanors" -I"$original/nanors/deps/obl" \
   "$root/tests/test_nanors_recovery.c" \
   "$original/nanors/rs.c" \
   "$original/nanors/deps/obl/oblas_common.c" \
   "$original/nanors/deps/obl/oblas_lite.c" \
   -o "$tmp/nanors"
"$tmp/nanors"
