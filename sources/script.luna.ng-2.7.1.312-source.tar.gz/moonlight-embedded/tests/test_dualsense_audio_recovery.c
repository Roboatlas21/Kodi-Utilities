/* Production PCM retirement/opening with independent endpoint ownership. */
#define _GNU_SOURCE
#include <assert.h>
#include "../src/input/dualsense.c"
uint32_t LiGetHostFeatureFlags(void) { return 0; }
int LiSendControllerTouchEvent(uint8_t n,uint8_t t,uint32_t id,float x,float y,float p) {
  (void)n;(void)t;(void)id;(void)x;(void)y;(void)p;return 0;
}
void loop_remove_fd(int fd) { (void)fd; }
void udev_schedule_advanced_retry(void) {}
bool udev_input_identity_for_fd(int fd,char *out,size_t n) { (void)fd;if(n)out[0]=0;return false; }
static int audio_tokens[2], closed_audio;
static pthread_mutex_t close_gate=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t close_wake=PTHREAD_COND_INITIALIZER;
static bool block_close,close_entered,close_released;
bool ml_ds_audio_haptics_ready(const ml_ds_audio *a) {
  return a == (ml_ds_audio *)&audio_tokens[1];
}
ml_ds_audio *ml_ds_audio_open(int fd, int transport, int event_fd) {
  assert(fd >= 0 && transport == ML_DS_USB && event_fd >= 0);
  return (ml_ds_audio *)&audio_tokens[1];
}
void ml_ds_audio_close(ml_ds_audio *a) {
  pthread_mutex_lock(&close_gate);
  if(a&&block_close) {
    close_entered=true;pthread_cond_broadcast(&close_wake);
    while(!close_released)pthread_cond_wait(&close_wake,&close_gate);
  }
  if(a)++closed_audio;
  pthread_mutex_unlock(&close_gate);
}
int main(void) {
  int event = open("/dev/null", O_RDONLY), other = open("/dev/zero", O_RDONLY);
  assert(event >= 0 && other >= 0);
  struct stat st; assert(fstat(event, &st) == 0);
  moonlight_dualsense active = {.fd = event, .transport = ML_DS_USB,
      .event_rdev = st.st_rdev, .listening = true, .gyro_scale = {1.0f/16.0f,1.0f/16.0f,1.0f/16.0f},
      .audio = (ml_ds_audio *)&audio_tokens[0]};
  bridges = &active;
  assert(dualsense_retry_audio(&active, event));
  assert(!active.audio && active.listening && bridges == &active);
  assert(dualsense_cleanup_pending_for(event));
  assert(!dualsense_cleanup_pending_for(other));
  assert(!dualsense_retry_audio(&active, event));
  assert(!active.audio_opening);
  moonlight_dualsense *retired = bridge_cleanup.head;
  bridge_cleanup.head = bridge_cleanup.tail = NULL;
  dualsense_close_one(retired);
  assert(closed_audio == 1 && !dualsense_cleanup_pending());
  assert(!dualsense_retry_audio(&active, event));
  assert(active.audio_opening);
  for (int i=0; i<1000 && !__atomic_load_n(&active.audio_open_done,__ATOMIC_ACQUIRE); ++i)
    usleep(1000);
  assert(dualsense_retry_audio(&active, event));
  assert(active.audio == (ml_ds_audio *)&audio_tokens[1]);
  assert(active.gyro_scale[0] * 1600 == 100.0f);
  assert(!dualsense_retry_audio(&active, event));
  moonlight_dualsense *slow=calloc(1,sizeof(*slow));
  slow->fd=-1;slow->audio=(ml_ds_audio *)&audio_tokens[0];
  block_close=true;assert(dualsense_cleanup_start());queue_cleanup(slow);
  pthread_mutex_lock(&close_gate);
  while(!close_entered)pthread_cond_wait(&close_wake,&close_gate);
  pthread_mutex_unlock(&close_gate);
  struct timespec before,after;clock_gettime(CLOCK_MONOTONIC,&before);
  dualsense_cleanup_shutdown();clock_gettime(CLOCK_MONOTONIC,&after);
  long elapsed=(after.tv_sec-before.tv_sec)*1000+(after.tv_nsec-before.tv_nsec)/1000000;
  assert(elapsed>=200&&elapsed<1000&&dualsense_cleanup_pending());
  pthread_mutex_lock(&close_gate);close_released=true;pthread_cond_broadcast(&close_wake);
  pthread_mutex_unlock(&close_gate);
  for(int i=0;i<1000&&dualsense_cleanup_pending();++i)usleep(1000);
  assert(!dualsense_cleanup_pending());
  close(event); close(other);
  return 0;
}
