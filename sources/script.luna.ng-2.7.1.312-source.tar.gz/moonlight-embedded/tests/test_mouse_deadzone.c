/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/input/mouse_deadzone.h"
#include <assert.h>
int main(void) {
  assert(moonlight_mouse_deadzone(0.0f, 2.0f) == 0.0f);
  assert(moonlight_mouse_deadzone(2.0f, 2.0f) == 0.0f);
  assert(moonlight_mouse_deadzone(-2.0f, 2.0f) == 0.0f);
  assert(moonlight_mouse_deadzone(3.0f, 2.0f) == 1.0f);
  assert(moonlight_mouse_deadzone(-3.0f, 2.0f) == -1.0f);
  assert(moonlight_mouse_deadzone(8.0f, 2.0f) ==
         -moonlight_mouse_deadzone(-8.0f, 2.0f));
  return 0;
}
