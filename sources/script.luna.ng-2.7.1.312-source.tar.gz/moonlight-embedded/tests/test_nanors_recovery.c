/* SPDX-License-Identifier: GPL-3.0-or-later
 * Link the actual pinned nanoRS implementation. No reconstruction stubs.
 * This verifies real parity generation and recovery of missing video shards.
 */
#define _POSIX_C_SOURCE 200809L
#include <rs.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

int main(void) {
  enum { DATA = 4, PARITY = 2, TOTAL = DATA + PARITY, BYTES = 320 };
  uint8_t *shards[TOTAL], reference[DATA][BYTES], marks[TOTAL] = {0};
  for (unsigned i = 0; i < TOTAL; ++i) {
    shards[i] = reed_solomon_aligned_alloc(BYTES);
    assert(shards[i] != NULL);
    memset(shards[i], 0, BYTES);
    if (i < DATA) {
      for (unsigned b = 0; b < BYTES; ++b)
        reference[i][b] = shards[i][b] = (uint8_t)((i * 37U + b * 23U) & 255U);
    }
  }
  reed_solomon_init();
  reed_solomon *code = reed_solomon_new(DATA, PARITY);
  assert(code != NULL);
  assert(reed_solomon_encode(code, shards, TOTAL, BYTES) == 0);

  /* Out-of-order RTP recovery: erase data indexes 1 and 3, retain both
   * real parity shards. Exactly two missing data shards are recoverable. */
  marks[1] = marks[3] = 1;
  memset(shards[1], 0, BYTES);
  memset(shards[3], 0, BYTES);
  assert(reed_solomon_decode(code, shards, marks, TOTAL, BYTES) == 0);
  for (unsigned i = 0; i < DATA; ++i)
    assert(memcmp(shards[i], reference[i], BYTES) == 0);

  /* More missing data than parity is unrecoverable. */
  marks[0] = marks[1] = marks[3] = 1;
  memset(shards[0], 0, BYTES);
  memset(shards[1], 0, BYTES);
  memset(shards[3], 0, BYTES);
  assert(reed_solomon_decode(code, shards, marks, TOTAL, BYTES) != 0);

  reed_solomon_release(code);
  for (unsigned i = 0; i < TOTAL; ++i)
    reed_solomon_free(shards[i]);
  puts("Pinned nanoRS: two missing data shards recovered; excessive loss rejected");
  return 0;
}
