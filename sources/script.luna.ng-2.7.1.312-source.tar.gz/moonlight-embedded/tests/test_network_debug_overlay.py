"""Private CoreELEC network observer is pinned, reproducible, and idempotent."""
import hashlib
import importlib.util
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "packaging/coreelec-ng/apply-network-debug.py"
SPEC = importlib.util.spec_from_file_location("net_overlay", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

class NetworkOverlayTests(unittest.TestCase):
    def setUp(self):
        common = ROOT / "third_party/moonlight-common-c/src"
        if not (common / "VideoStream.c").is_file():
            self.skipTest("Common-c submodule not initialized")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.destination = Path(self.tmp.name)
        sources = self.destination / "third_party/moonlight-common-c/src"
        sources.mkdir(parents=True)
        for name in MODULE.BASELINES:
            shutil.copyfile(common / name, sources / name)
        osd = self.destination / "src/osd"
        osd.mkdir(parents=True)
        shutil.copyfile(ROOT / "src/osd/net_rx_debug.h", osd / "net_rx_debug.h")

    def test_applies_only_to_pinned_unpack_and_is_idempotent(self):
        originals = {}
        common = self.destination / "third_party/moonlight-common-c/src"
        for name, sha in MODULE.BASELINES.items():
            originals[name] = (common / name).read_bytes()
            self.assertEqual(MODULE.git_blob_sha(originals[name]), sha)
        MODULE.apply(self.destination)
        self.assertTrue((common / "LunaNetDebug.c").is_file())
        self.assertTrue((common / "LunaNetDiagnostics.h").is_file())
        for name in originals:
            text = (common / name).read_text()
            self.assertIn('#include "LunaNetDiagnostics.h"', text)
        first = {name:(common / name).read_bytes() for name in originals}
        MODULE.apply(self.destination)
        for name in originals:
            self.assertEqual((common / name).read_bytes(), first[name])
        # Never mutate the original submodule working tree.
        for name in originals:
            self.assertEqual((ROOT / "third_party/moonlight-common-c/src" / name).read_bytes(), originals[name])

    def test_detects_modified_previously_patched_source(self):
        common = self.destination / "third_party/moonlight-common-c/src"
        MODULE.apply(self.destination)
        modified = common / "RtpVideoQueue.c"
        modified.write_bytes(modified.read_bytes() + b"\\n/* unexpected modification */\\n")
        untouched = (common / "VideoStream.c").read_bytes()
        with self.assertRaises(ValueError):
            MODULE.apply(self.destination)
        self.assertEqual((common / "VideoStream.c").read_bytes(), untouched)

    def test_interrupted_swap_restores_original_before_retry(self):
        common = self.destination / "third_party/moonlight-common-c/src"
        backup = common.parent / ".luna-netdiag-src-backup"
        original = (common / "VideoStream.c").read_bytes()
        common.rename(backup)  # Simulate SIGKILL after first directory rename.
        self.assertFalse(common.exists())
        MODULE.apply(self.destination)
        self.assertTrue(common.is_dir())
        self.assertFalse(backup.exists())
        self.assertNotEqual((common / "VideoStream.c").read_bytes(), original)
        MODULE.apply(self.destination)  # Idempotent after recovery.

    def test_failed_staged_rename_rolls_back_all_original_files(self):
        common = self.destination / "third_party/moonlight-common-c/src"
        original = {name:(common / name).read_bytes()
                    for name in MODULE.BASELINES}
        real_rename = Path.rename

        def fail_install(path, target):
            if path.name.startswith(".luna-netdiag-src-stage-"):
                raise OSError("simulated rename failure")
            return real_rename(path, target)

        with mock.patch.object(Path, "rename", fail_install):
            with self.assertRaisesRegex(OSError, "simulated rename"):
                MODULE.apply(self.destination)
        for name, expected in original.items():
            self.assertEqual((common / name).read_bytes(), expected)
        self.assertFalse((common.parent / ".luna-netdiag-src-backup").exists())
        self.assertFalse(list(common.parent.glob(".luna-netdiag-src-stage-*")))

    def test_cleanup_failure_preserves_valid_install_for_retry(self):
        common = self.destination / "third_party/moonlight-common-c/src"
        real_rmtree = shutil.rmtree
        failed = False

        def fail_backup_once(path, *args, **kwargs):
            nonlocal failed
            if not failed and Path(path).name == ".luna-netdiag-src-backup":
                failed = True
                raise OSError("simulated backup cleanup interruption")
            return real_rmtree(path, *args, **kwargs)

        with mock.patch.object(shutil, "rmtree", fail_backup_once):
            with self.assertRaisesRegex(OSError, "backup cleanup"):
                MODULE.apply(self.destination)
        self.assertTrue((common / ".luna-netdiag-overlay.json").is_file())
        self.assertTrue((common.parent / ".luna-netdiag-src-backup").exists())
        MODULE.apply(self.destination)
        self.assertFalse((common.parent / ".luna-netdiag-src-backup").exists())

    def test_rejects_unexpected_upstream_without_partial_write(self):
        common = self.destination / "third_party/moonlight-common-c/src"
        corrupt = common / "RtpVideoQueue.c"
        corrupt.write_bytes(corrupt.read_bytes() + b"\n/* changed */\n")
        original = (common / "VideoStream.c").read_bytes()
        with self.assertRaises(ValueError):
            MODULE.apply(self.destination)
        self.assertEqual((common / "VideoStream.c").read_bytes(), original)
        self.assertFalse((common / "LunaNetDebug.c").exists())

if __name__ == "__main__":
    unittest.main()
