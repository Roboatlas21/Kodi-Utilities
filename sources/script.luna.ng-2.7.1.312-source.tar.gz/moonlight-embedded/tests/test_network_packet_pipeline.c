/* SPDX-License-Identifier: GPL-3.0-or-later
 * Exercise the REAL patched Nonary RTP/FEC queue, not only the log formatter.
 * Synthetic Reed-Solomon reconstruction makes the expected one-shard result
 * deterministic; the production packet admission/ordering, recovered-packet
 * validation, delivery and accounting paths are otherwise unchanged.
 */
#include "Limelight-internal.h"
#include "LunaNetDiagnostics.h"
#include <rs.h>
/* Production common-c defines NDEBUG. The test assertions must stay active. */
#undef NDEBUG
#include <assert.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

int AppVersionQuad[4] = {7, 1, 431, -1};
STREAM_CONFIGURATION StreamConfig;
/* The production selected-peer API reads this common-c connection global.
 * This isolated RTP/FEC test deliberately does not link the real connection.
 */
struct sockaddr_storage RemoteAddr;
CONNECTION_LISTENER_CALLBACKS ListenerCallbacks;
int NegotiatedVideoFormat = VIDEO_FORMAT_H264;
static uint64_t fake_clock = 1000000;
static unsigned delivered, recovered_reports, loss_notices;
static uint32_t recover_base = 200;
static int inject_fec_failure;

uint64_t PltGetMicroseconds(void) { fake_clock += 100; return fake_clock; }
void reed_solomon_init(void) {}
reed_solomon *reed_solomon_new(int data, int parity) {
  reed_solomon *rs = calloc(1, reed_solomon_bufsize(data, parity));
  assert(rs);
  rs->ds = data; rs->ps = parity; rs->ts = data + parity;
  return rs;
}
void reed_solomon_release(reed_solomon *rs) { free(rs); }
int reed_solomon_decode(reed_solomon *rs, uint8_t **packets,
                        uint8_t *marks, int count, int size) {
  if (inject_fec_failure) return -1;
  for (int i = 0; i < rs->ds && i < count; i++) {
    if (!marks[i]) continue;
    memset(packets[i], 0, (size_t)size);
    PRTP_PACKET rtp = (PRTP_PACKET)packets[i];
    rtp->header = FLAG_EXTENSION;
    rtp->sequenceNumber = (uint16_t)(recover_base + (unsigned)i);
    rtp->timestamp = 90000;
    PNV_VIDEO_PACKET nv = (PNV_VIDEO_PACKET)(packets[i] + sizeof(RTP_PACKET) + 4);
    nv->flags = FLAG_CONTAINS_PIC_DATA |
        (i == 0 ? FLAG_SOF : 0) | (i == rs->ds - 1 ? FLAG_EOF : 0);
  }
  return 0;
}
void connectionSendFrameFecStatus(PSS_FRAME_FEC_STATUS status) {
  (void)status; ++recovered_reports;
}
void connectionSawFrame(uint32_t frameIndex) { (void)frameIndex; }
void notifyFrameLost(unsigned int frameNumber, bool speculative) {
  (void)frameNumber; (void)speculative; ++loss_notices;
}
void queueRtpPacket(PRTPV_QUEUE_ENTRY entry) {
  ++delivered;
  /* This test sink owns the packet, as the production depacketizer does. */
  free(entry->packet);
}

static PRTP_PACKET packet(uint32_t frame, uint16_t seq, uint16_t first,
                          unsigned data, unsigned fec_percent, bool end) {
  const size_t len = (size_t)StreamConfig.packetSize + MAX_RTP_HEADER_SIZE;
  char *bytes = calloc(1, len + sizeof(RTPV_QUEUE_ENTRY));
  assert(bytes);
  PRTP_PACKET rtp = (PRTP_PACKET)bytes;
  rtp->header = FLAG_EXTENSION;
  rtp->sequenceNumber = seq; /* VideoRecv has already converted BE to host. */
  rtp->timestamp = 90000U * frame;
  rtp->ssrc = 1;
  PNV_VIDEO_PACKET nv = (PNV_VIDEO_PACKET)(bytes + sizeof(RTP_PACKET) + 4);
  unsigned index = (uint16_t)(seq - first);
  nv->frameIndex = LE32(frame);
  nv->streamPacketIndex = LE32(index << 8);
  nv->flags = (index == 0 ? FLAG_SOF : 0) |
              (end ? FLAG_EOF : FLAG_CONTAINS_PIC_DATA);
  if (!end) nv->flags |= FLAG_CONTAINS_PIC_DATA;
  nv->multiFecFlags = 0x10;
  nv->multiFecBlocks = 0;
  nv->fecInfo = LE32((data << 22) | (index << 12) | (fec_percent << 4));
  return rtp;
}
static void send_packet(PRTP_VIDEO_QUEUE q, uint32_t frame, unsigned seq,
                        unsigned base, unsigned data, unsigned pct,
                        bool end, bool accept) {
  PRTP_PACKET rtp = packet(frame, (uint16_t)seq, (uint16_t)base, data, pct, end);
  PRTPV_QUEUE_ENTRY entry =
      (PRTPV_QUEUE_ENTRY)((char *)rtp + StreamConfig.packetSize + MAX_RTP_HEADER_SIZE);
  const int received_bytes = StreamConfig.packetSize + MAX_RTP_HEADER_SIZE;
  const uint64_t received_at = LunaNetDebugDatagram(received_bytes);
  const int result = RtpvAddPacket(q, rtp, received_bytes, entry);
  LunaNetDebugReceiverWork(received_at);
  assert((result == RTPF_RET_QUEUED) == accept);
  if (result == RTPF_RET_REJECTED) free(rtp);
}
static bool histogram_writer_done;
static void *histogram_writer(void *unused) {
  (void)unused;
  for (unsigned i = 0; i < 20000; ++i) {
    const uint64_t started = PltGetMicroseconds();
    LunaNetDebugReceiverWork(started);
  }
  __atomic_store_n(&histogram_writer_done, true, __ATOMIC_RELEASE);
  return NULL;
}
#define EQ(field, expect) assert(view.counts[field] == (expect))
int main(void) {
  assert(setenv("MOONLIGHT_STREAM_DIAGNOSTICS", "1", 1) == 0);
  LunaNetDebugInit();
  StreamConfig.packetSize = 256;
  RTP_VIDEO_QUEUE q;
  RtpvInitializeQueue(&q);
  /* First frame: an interior out-of-order gap, real duplicate and late
   * already-processed packet, without invoking FEC reconstruction. */
  send_packet(&q, 1, 100, 100, 3, 0, false, true);
  send_packet(&q, 1, 102, 100, 3, 0, true, true);
  send_packet(&q, 1, 102, 100, 3, 0, true, false);
  send_packet(&q, 1, 101, 100, 3, 0, false, true);
  send_packet(&q, 1, 99, 100, 3, 0, false, false);
  assert(delivered == 3);
  /* Second frame: missing interior data shard, sufficient parity present.
   * Invoke production reconstructFrame()/validation/counters through AddPacket. */
  send_packet(&q, 2, 200, 200, 3, 33, false, true);
  send_packet(&q, 2, 202, 200, 3, 33, true, true);
  send_packet(&q, 2, 203, 200, 3, 33, false, true);
  assert(delivered == 6 && recovered_reports == 1);
  /* Third frame: one packet of three arrives. Next frame boundary expires it.
   * The two missing data shards are not reported as proven network loss. */
  send_packet(&q, 3, 300, 300, 3, 0, false, true);
  send_packet(&q, 4, 400, 400, 3, 0, false, true);
  /* Exercise the actual producer's extreme stall path, not only the
   * text formatter's interpretation of synthetic counters. */
  const uint64_t blocked_since = PltGetMicroseconds();
  fake_clock += 2500000U;
  LunaNetDebugReceiverWork(blocked_since);
  LunaNetDebugFecWork(blocked_since);
  LunaNetworkDebugV1 view = {0};
  assert(LiGetLunaNetworkDebugV1(&view, sizeof(view)));
  EQ(LUNA_NET_UDP_DATAGRAMS, 10);
  assert(view.counts[LUNA_NET_UDP_BYTES] == 10U * (256U + MAX_RTP_HEADER_SIZE));
  EQ(LUNA_NET_DATA_ACCEPTED, 7);
  EQ(LUNA_NET_PARITY_ACCEPTED, 1);
  EQ(LUNA_NET_DUPLICATES, 1);
  assert(view.counts[LUNA_NET_REORDERED] >= 1);
  EQ(LUNA_NET_OLD_WINDOW, 1);
  EQ(LUNA_NET_FEC_ATTEMPTS, 1);
  EQ(LUNA_NET_FEC_RECOVERED_DATA, 1);
  EQ(LUNA_NET_ABANDONED_BLOCKS, 1);
  EQ(LUNA_NET_ABANDONED_DATA, 2);
  EQ(LUNA_NET_RX_STALL_GT1S, 1);
  EQ(LUNA_NET_FEC_STALL_GT1S, 1);
  assert(view.receiver_work.worst_us >= 2500000U);
  assert(view.fec_work.worst_us >= 2500000U);
  assert(loss_notices >= 1);
  RtpvCleanupQueue(&q);
  /* Failure path: the actual queue invokes the FEC decoder, records its
   * failed result and retains ownership of the incomplete packet block. */
  RTP_VIDEO_QUEUE failed;
  RtpvInitializeQueue(&failed);
  inject_fec_failure = 1;
  send_packet(&failed, 1, 500, 500, 3, 33, false, true);
  send_packet(&failed, 1, 502, 500, 3, 33, true, true);
  send_packet(&failed, 1, 503, 500, 3, 33, false, true);
  LunaNetworkDebugV1 after_failure = {0};
  assert(LiGetLunaNetworkDebugV1(&after_failure, sizeof(after_failure)));
  assert(after_failure.counts[LUNA_NET_FEC_ATTEMPTS] == 2);
  assert(after_failure.counts[LUNA_NET_FEC_FAILED_ATTEMPTS] == 1);
  RtpvCleanupQueue(&failed);
  pthread_t reader_race;
  histogram_writer_done = false;
  assert(pthread_create(&reader_race, NULL, histogram_writer, NULL) == 0);
  do {
    LunaNetworkDebugV1 concurrently_read = {0};
    if (LiGetLunaNetworkDebugV1(&concurrently_read, sizeof(concurrently_read))) {
      uint64_t buckets = 0;
      for (unsigned i = 0; i < LUNA_NET_DEBUG_BINS; ++i)
        buckets += concurrently_read.receiver_work.bins[i];
      assert(buckets == concurrently_read.receiver_work.samples);
    }
  } while (!__atomic_load_n(&histogram_writer_done, __ATOMIC_ACQUIRE));
  assert(pthread_join(reader_race, NULL) == 0);
  puts("Real common-c RTP/FEC: packet cases and concurrent histogram snapshot consistency passed");
  return 0;
}
