/* SPDX-License-Identifier: GPL-3.0-or-later
 * Optional DualSense and DualSense Edge USB/Bluetooth HID bridge.
 * A matching evdev gamepad owns normal input; this code only handles sensor,
 * touch, battery, LED and adaptive-trigger messages. No HID rebind or EVIOCGRAB.
 */
#define _GNU_SOURCE
#include "dualsense.h"
#include "dualsense_report.h"
#include "dualsense_pcm.h"
#include "udev.h"
#include <ControllerHaptics.h>
#include <ControllerSpeakerPcm.h>
#include "../loop.h"
#include <Limelight.h>
#include <libudev.h>
#include <linux/hidraw.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct moonlight_dualsense {
  struct moonlight_dualsense *next, *retire_next;
  dev_t event_rdev;
  char event_identity[ML_INPUT_IDENTITY_MAX];
  pthread_t output_worker, calibration_worker;
  pthread_mutex_t output_lock;
  pthread_cond_t output_wake;
  bool output_started, output_pending, output_stop, output_failed;
  bool calibration_started, calibration_done, calibration_applied;
  uint8_t output_body[ML_DS_PAYLOAD];
  pthread_t audio_opener;
  bool audio_opening, audio_open_done;
  int audio_event_fd;
  ml_ds_audio *opened_audio;
  float gyro_bias[3], gyro_scale[3], pending_bias[3], pending_scale[3];
  int fd;
  int transport;
  short player; /* Only the native evdev loop assigns player slots. */
  unsigned sequence;
  uint16_t gyro_rate, accel_rate;
  uint64_t last_gyro_us, last_accel_us, last_battery_us;
  uint8_t last_battery_state, last_battery_percent;
  bool battery_known, touch_active[2], effect_active, listening;
  bool hid_failed, stopping;
  uint32_t touch_id[2];
  float touch_x[2], touch_y[2];
  ml_ds_audio *audio; /* Optional, independent haptics/speaker worker. */
};
static moonlight_dualsense *bridges;
static bool completion_pending;
static void notify_completion(void) {
  __atomic_store_n(&completion_pending, true, __ATOMIC_RELEASE);
}
bool dualsense_completions_pending(void) {
  return __atomic_exchange_n(&completion_pending, false, __ATOMIC_ACQ_REL);
}

/* A stalled hidraw/ALSA cleanup must never join on the event-loop thread.
 * Retire bridge ownership on that thread, then finish close/free here.
 * This worker never touches the bridge list or calls common-c host events. */
static struct {
  pthread_mutex_t lock;
  pthread_cond_t wake;
  pthread_t worker;
  moonlight_dualsense *head, *tail, *retiring;
  unsigned pending;
  bool started, stopping;
} bridge_cleanup = {
  .lock = PTHREAD_MUTEX_INITIALIZER,
  .wake = PTHREAD_COND_INITIALIZER
};

static void *dualsense_close_one(void *arg) {
    moonlight_dualsense *d = arg;
    /* Every worker borrows d. Keep its fd and retiring identity alive until
     * all borrowers finish; a blocked device must not block the input loop. */
    if (d->output_started) {
      pthread_mutex_lock(&d->output_lock);
      d->output_stop = true;
      pthread_cond_signal(&d->output_wake);
      pthread_mutex_unlock(&d->output_lock);
      pthread_join(d->output_worker, NULL);
      pthread_cond_destroy(&d->output_wake);
      pthread_mutex_destroy(&d->output_lock);
    }
    if (d->calibration_started)
      pthread_join(d->calibration_worker, NULL);
    if (d->audio_opening) {
      pthread_join(d->audio_opener, NULL);
      ml_ds_audio_close(d->opened_audio);
    }
    ml_ds_audio_close(d->audio);
    d->audio = NULL;
    if (d->fd >= 0) close(d->fd);

    pthread_mutex_lock(&bridge_cleanup.lock);
    moonlight_dualsense **link = &bridge_cleanup.retiring;
    while (*link && *link != d) link = &(*link)->retire_next;
    if (*link) *link = d->retire_next;
    --bridge_cleanup.pending;
    pthread_cond_broadcast(&bridge_cleanup.wake);
    pthread_mutex_unlock(&bridge_cleanup.lock);
    free(d);
    return NULL;
}

static void *dualsense_cleanup_worker(void *unused) {
  (void)unused;
  for (;;) {
    pthread_mutex_lock(&bridge_cleanup.lock);
    while (!bridge_cleanup.head && !bridge_cleanup.stopping)
      pthread_cond_wait(&bridge_cleanup.wake, &bridge_cleanup.lock);
    if (!bridge_cleanup.head && bridge_cleanup.stopping) {
      pthread_mutex_unlock(&bridge_cleanup.lock);
      return NULL;
    }
    moonlight_dualsense *d = bridge_cleanup.head;
    bridge_cleanup.head = d->next;
    if (!bridge_cleanup.head) bridge_cleanup.tail = NULL;
    d->next = NULL;
    pthread_mutex_unlock(&bridge_cleanup.lock);

    pthread_t closer;
    if (pthread_create(&closer, NULL, dualsense_close_one, d) == 0) {
      pthread_detach(closer);
    } else {
      pthread_mutex_lock(&bridge_cleanup.lock);
      d->next = bridge_cleanup.head;
      bridge_cleanup.head = d;
      if (!bridge_cleanup.tail) bridge_cleanup.tail = d;
      pthread_mutex_unlock(&bridge_cleanup.lock);
      struct timespec pause = {.tv_nsec = 250000000};
      nanosleep(&pause, NULL);
    }
  }
}

static bool dualsense_cleanup_start(void) {
  if (bridge_cleanup.started) return true; /* Only main input thread starts. */
  if (pthread_create(&bridge_cleanup.worker, NULL,
                     dualsense_cleanup_worker, NULL) != 0) {
    fprintf(stderr, "DualSense: cleanup worker unavailable; advanced HID disabled\n");
    return false;
  }
  bridge_cleanup.started = true;
  return true;
}

bool dualsense_cleanup_pending(void) {
  pthread_mutex_lock(&bridge_cleanup.lock);
  const bool pending = bridge_cleanup.pending != 0;
  pthread_mutex_unlock(&bridge_cleanup.lock);
  return pending;
}

bool dualsense_cleanup_pending_for(int event_fd) {
  struct stat st;
  if (fstat(event_fd, &st) != 0) return true;
  bool pending = false;
  char identity[ML_INPUT_IDENTITY_MAX] = {0};
  (void)udev_input_identity_for_fd(event_fd, identity, sizeof(identity));
  pthread_mutex_lock(&bridge_cleanup.lock);
  for (moonlight_dualsense *d = bridge_cleanup.retiring; d; d = d->retire_next)
    if (d->event_rdev == st.st_rdev &&
        (!identity[0] || !d->event_identity[0] || !strcmp(identity, d->event_identity))) {
      pending = true; break;
    }
  pthread_mutex_unlock(&bridge_cleanup.lock);
  return pending;
}

void dualsense_cleanup_shutdown(void) {
  if (!bridge_cleanup.started) return;
  pthread_mutex_lock(&bridge_cleanup.lock);
  bridge_cleanup.stopping = true;
  pthread_cond_broadcast(&bridge_cleanup.wake);
  pthread_mutex_unlock(&bridge_cleanup.lock);
  struct timespec deadline;
  if (clock_gettime(CLOCK_REALTIME, &deadline) != 0) {
    pthread_detach(bridge_cleanup.worker);
    bridge_cleanup.started = false;
    return;
  }
  deadline.tv_nsec += 250000000L;
  if (deadline.tv_nsec >= 1000000000L) {
    ++deadline.tv_sec;
    deadline.tv_nsec -= 1000000000L;
  }
  const int rc = pthread_timedjoin_np(bridge_cleanup.worker, NULL, &deadline);
  if (rc != 0) {
    fprintf(stderr, "DualSense: cleanup worker still active (%d); Luna will own process recovery\n", rc);
    pthread_detach(bridge_cleanup.worker);
  }
  pthread_mutex_lock(&bridge_cleanup.lock);
  while (bridge_cleanup.pending) {
    if (pthread_cond_timedwait(&bridge_cleanup.wake, &bridge_cleanup.lock, &deadline) != 0)
      break;
  }
  pthread_mutex_unlock(&bridge_cleanup.lock);
  bridge_cleanup.started = false; /* The stream is shutting down. */
}

static void dualsense_release_touches(moonlight_dualsense *d);
static void dualsense_mark_failed(moonlight_dualsense *d);

bool dualsense_hid_healthy(const moonlight_dualsense *d) {
  return d && d->fd >= 0 &&
         __atomic_load_n(&d->listening, __ATOMIC_ACQUIRE) &&
         !__atomic_load_n(&d->hid_failed, __ATOMIC_ACQUIRE);
}

static uint64_t monotonic_us(void) {
  struct timespec now;
  if (clock_gettime(CLOCK_MONOTONIC, &now) < 0) return 0;
  return (uint64_t)now.tv_sec * 1000000U + (uint64_t)now.tv_nsec / 1000U;
}

/* Only this per-device worker performs output I/O. It never edits loop
 * registrations or publishes host input; failure is harvested on main. */
static int write_report(moonlight_dualsense *d,const uint8_t body[ML_DS_PAYLOAD]) {
  uint8_t report[ML_DS_BT_OUT];size_t length=0;
  if (!ml_ds_output(body,d->transport,d->sequence,report,&length)) return ML_DS_SEND_FAILED;
  ssize_t sent=write(d->fd,report,length);
  if (sent!=(ssize_t)length)
    return sent<0&&(errno==EAGAIN||errno==EWOULDBLOCK||errno==EINTR)?ML_DS_SEND_RETRY:ML_DS_SEND_FAILED;
  d->sequence=(d->sequence+1)&15U;return ML_DS_SEND_OK;
}
static void *dualsense_output_worker(void *arg) {
  moonlight_dualsense *d=arg;
  pthread_mutex_lock(&d->output_lock);
  for (;;) {
    while (!d->output_pending&&!d->output_stop) pthread_cond_wait(&d->output_wake,&d->output_lock);
    if(d->output_stop)break;
    uint8_t body[ML_DS_PAYLOAD];memcpy(body,d->output_body,sizeof(body));
    d->output_pending=false;
    pthread_mutex_unlock(&d->output_lock);
    int result=write_report(d,body);
    if(result==ML_DS_SEND_RETRY) {
      struct timespec delay={.tv_nsec=20000000};nanosleep(&delay,NULL);
    }
    pthread_mutex_lock(&d->output_lock);
    if(result==ML_DS_SEND_RETRY)d->output_pending=true;
    else if(result==ML_DS_SEND_FAILED) {
      __atomic_store_n(&d->output_failed,true,__ATOMIC_RELEASE);notify_completion();
      while(!d->output_stop)pthread_cond_wait(&d->output_wake,&d->output_lock);
      break;
    }
  }
  bool reset=d->effect_active;
  pthread_mutex_unlock(&d->output_lock);
  if(reset) {
    uint8_t body[ML_DS_PAYLOAD]={0};body[0]=0x0c;
    for(unsigned i=0;i<3;++i) {
      if(write_report(d,body)!=ML_DS_SEND_RETRY)break;
      struct timespec delay={.tv_nsec=20000000};nanosleep(&delay,NULL);
    }
  }
  return NULL;
}
static int send_report(moonlight_dualsense *d,const uint8_t body[ML_DS_PAYLOAD]) {
  if(!d||!d->output_started||!dualsense_hid_healthy(d))return ML_DS_SEND_FAILED;
  pthread_mutex_lock(&d->output_lock);
  if(d->output_stop) {pthread_mutex_unlock(&d->output_lock);return ML_DS_SEND_FAILED;}
  /* Coalesce independently addressed fields without losing the other trigger. */
  if(body[1]&0x04) {d->output_body[1]|=0x04;memcpy(d->output_body+44,body+44,3);}
  if(body[0]&0x04) {d->output_body[0]|=0x04;memcpy(d->output_body+10,body+10,11);}
  if(body[0]&0x08) {d->output_body[0]|=0x08;memcpy(d->output_body+21,body+21,11);}
  if(body[0]&0x0c)d->effect_active=true;
  d->output_pending=true;pthread_cond_signal(&d->output_wake);
  pthread_mutex_unlock(&d->output_lock);
  return ML_DS_SEND_OK; /* Desired state accepted; worker owns retry/completion. */
}

int dualsense_led_try(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  if (!d || d->fd < 0) return ML_DS_SEND_FAILED;
  uint8_t body[ML_DS_PAYLOAD] = {0};
  body[1] = 0x04; /* Only the lightbar control bit. */
  body[44] = r;
  body[45] = g;
  body[46] = b;
  return send_report(d, body);
}

void dualsense_led(moonlight_dualsense *d, uint8_t r, uint8_t g, uint8_t b) {
  (void)dualsense_led_try(d, r, g, b);
}

int dualsense_adaptive_try(moonlight_dualsense *d, uint8_t flags,
                           uint8_t left_type, uint8_t right_type,
                           const uint8_t *left, const uint8_t *right) {
  if (!d || d->fd < 0) return ML_DS_SEND_FAILED;
  flags &= 0x0c; /* The host may only select left/right trigger effects. */
  if (!flags) return ML_DS_SEND_OK;
  if (((flags & 0x08) && !left) || ((flags & 0x04) && !right))
    return ML_DS_SEND_FAILED;
  uint8_t body[ML_DS_PAYLOAD] = {0};
  body[0] = flags;
  if (flags & 0x04) {
    body[10] = right_type;
    memcpy(body + 11, right, 10);
  }
  if (flags & 0x08) {
    body[21] = left_type;
    memcpy(body + 22, left, 10);
  }
  const int result = send_report(d, body);
  return result;
}

void dualsense_adaptive(moonlight_dualsense *d, uint8_t flags,
                        uint8_t left_type, uint8_t right_type,
                        const uint8_t *left, const uint8_t *right) {
  (void)dualsense_adaptive_try(d, flags, left_type, right_type, left, right);
}

void dualsense_motion_request(moonlight_dualsense *d, uint8_t type, uint16_t rate) {
  if (!d) return;
  if (rate > 250) rate = 250; /* Bound callback traffic, regardless of host request. */
  if (type == LI_MOTION_TYPE_GYRO)
    __atomic_store_n(&d->gyro_rate, rate, __ATOMIC_RELAXED);
  if (type == LI_MOTION_TYPE_ACCEL)
    __atomic_store_n(&d->accel_rate, rate, __ATOMIC_RELAXED);
}
void dualsense_set_player(moonlight_dualsense *d, short player) {
  if (d && player >= 0 && player < 16) d->player = player;
}
unsigned short dualsense_capabilities(const moonlight_dualsense *d) {
  if (!dualsense_hid_healthy(d)) return 0;
  unsigned short result = LI_CCAP_TOUCHPAD | LI_CCAP_ACCEL | LI_CCAP_GYRO |
                          LI_CCAP_BATTERY_STATE | LI_CCAP_RGB_LED;
  if (ml_ds_audio_haptics_ready(d->audio)) result |= LI_CCAP_HAPTICS_PCM;
  if (ml_ds_audio_speaker_ready(d->audio)) result |= LI_CCAP_PS_SPEAKER_PCM;
  return result;
}

uint64_t dualsense_speaker_owner(const moonlight_dualsense *d) {
  return dualsense_hid_healthy(d) ? ml_ds_audio_speaker_owner(d->audio) : 0;
}
bool dualsense_waveform_active(moonlight_dualsense *d) {
  return dualsense_hid_healthy(d) && ml_ds_audio_playing(d->audio);
}
void dualsense_receive_haptics(moonlight_dualsense *d, uint32_t sequence,
                               const uint8_t *pcm, uint16_t frames) {
  if (dualsense_hid_healthy(d))
    ml_ds_audio_haptics(d->audio, sequence, pcm, frames);
}
void dualsense_receive_speaker(moonlight_dualsense *d, uint64_t owner, uint32_t generation,
                               uint32_t sequence, uint64_t position, uint16_t flags,
                               const uint8_t *pcm, uint16_t frames) {
  if (dualsense_hid_healthy(d))
    ml_ds_audio_speaker(d->audio, owner, generation, sequence, position, flags, pcm, frames);
}

static void send_touch(moonlight_dualsense *d, const ml_ds_sample *sample) {
  if (!(LiGetHostFeatureFlags() & LI_FF_CONTROLLER_TOUCH_EVENTS)) return;
  for (unsigned slot = 0; slot < 2; ++slot) {
    const uint8_t *p = sample->touch[slot];
    const bool active = (p[0] & 0x80) == 0;
    const uint32_t id = (slot << 8) | (p[0] & 0x7f);
    const float x = (float)(p[1] | ((p[2] & 0x0f) << 8)) / 1920.0f;
    const float y = (float)((p[2] >> 4) | (p[3] << 4)) / 1080.0f;
    if (d->touch_active[slot] && (!active || id != d->touch_id[slot])) {
      LiSendControllerTouchEvent((uint8_t)d->player, LI_TOUCH_EVENT_UP,
                                 d->touch_id[slot], d->touch_x[slot], d->touch_y[slot], 0);
      d->touch_active[slot] = false;
    }
    if (!active) continue;
    if (x < 0 || x > 1 || y < 0 || y > 1) continue;
    const bool down = !d->touch_active[slot];
    if (down || x != d->touch_x[slot] || y != d->touch_y[slot])
      LiSendControllerTouchEvent((uint8_t)d->player,
                                 down ? LI_TOUCH_EVENT_DOWN : LI_TOUCH_EVENT_MOVE,
                                 id, x, y, 1.0f);
    d->touch_id[slot] = id;
    d->touch_x[slot] = x;
    d->touch_y[slot] = y;
    d->touch_active[slot] = true;
  }
}

static void send_battery(moonlight_dualsense *d, uint8_t packed, uint64_t now) {
  uint8_t percent = (uint8_t)((packed & 0x0f) * 10 + 5);
  if (percent > 100) percent = 100;
  uint8_t state;
  switch ((packed >> 4) & 15) {
    case 0: state = LI_BATTERY_STATE_DISCHARGING; break;
    case 1: state = LI_BATTERY_STATE_CHARGING; break;
    case 2: state = LI_BATTERY_STATE_FULL; percent = 100; break;
    case 10: case 11: state = LI_BATTERY_STATE_NOT_CHARGING; percent = 0; break;
    default: state = LI_BATTERY_STATE_UNKNOWN; percent = LI_BATTERY_PERCENTAGE_UNKNOWN; break;
  }
  if (d->battery_known && state == d->last_battery_state &&
      percent == d->last_battery_percent && now - d->last_battery_us < 5000000U)
    return;
  LiSendControllerBatteryEvent((uint8_t)d->player, state, percent);
  d->battery_known = true;
  d->last_battery_state = state;
  d->last_battery_percent = percent;
  d->last_battery_us = now;
}

static void process_sample(moonlight_dualsense *d, const ml_ds_sample *s) {
  if (d->player < 0) return; /* Don't send before evdev advertises the controller. */
  const uint64_t now = monotonic_us();
  const uint16_t gyro = __atomic_load_n(&d->gyro_rate, __ATOMIC_RELAXED);
  const uint16_t accel = __atomic_load_n(&d->accel_rate, __ATOMIC_RELAXED);
  /* Raw scale factors from hid-playstation. Calibration/bias is firmware-
   * dependent, so sensor accuracy must be tested with a real pad. */
  if (gyro && (!d->last_gyro_us || now - d->last_gyro_us >= 1000000U / gyro)) {
    LiSendControllerMotionEvent((uint8_t)d->player, LI_MOTION_TYPE_GYRO,
                                (s->gyro[0] - d->gyro_bias[0]) * d->gyro_scale[0], (s->gyro[1] - d->gyro_bias[1]) * d->gyro_scale[1],
                                (s->gyro[2] - d->gyro_bias[2]) * d->gyro_scale[2]);
    d->last_gyro_us = now;
  }
  if (accel && (!d->last_accel_us || now - d->last_accel_us >= 1000000U / accel)) {
    const float scale = 9.80665f / 8192.0f;
    LiSendControllerMotionEvent((uint8_t)d->player, LI_MOTION_TYPE_ACCEL,
                                s->accel[0] * scale, s->accel[1] * scale,
                                s->accel[2] * scale);
    d->last_accel_us = now;
  }
  send_touch(d, s);
  send_battery(d, s->battery, now);
}

static int on_hidraw(int fd) {
  moonlight_dualsense *d = bridges;
  while (d && d->fd != fd) d = d->next;
  if (!d) return LOOP_OK;
  /* Bound work per poll cycle, so controller/raw HID cannot starve CEC. */
  for (unsigned n = 0; n < 32; ++n) {
    uint8_t report[ML_DS_BT_IN];
    const ssize_t got = read(fd, report, sizeof(report));
    if (got > 0) {
      ml_ds_sample sample;
      if (ml_ds_parse(report, (size_t)got, d->transport, &sample))
        process_sample(d, &sample);
      continue;
    }
    if (got < 0 && errno == EINTR) continue;
    if (got < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
    /* Keep ownership for teardown; don't close a descriptor a host callback
     * may be using. Stop polling a disconnected/failed HID link. */
    fprintf(stderr, "DualSense HID input stopped (errno=%d)\n", got < 0 ? errno : 0);
    dualsense_mark_failed(d);
    break;
  }
  return LOOP_OK;
}

static int on_hidraw_fault(int fd) {
  moonlight_dualsense *d = bridges;
  while (d && d->fd != fd) d = d->next;
  if (d) dualsense_mark_failed(d);
  else loop_remove_fd(fd);
  return LOOP_OK;
}

static void *dualsense_calibrate(void *arg) {
  moonlight_dualsense *d = arg;
  uint8_t calibration[41] = {0x05};
  int n = ioctl(d->fd, HIDIOCGFEATURE(sizeof(calibration)), calibration);
  for (unsigned axis = 0; axis < 3; ++axis) {
    d->pending_bias[axis] = 0;
    d->pending_scale[axis] = 1.0f / 16.0f;
    if (n >= 35 && calibration[0] == 0x05) {
      int bias = ml_ds_le16s(calibration + 1 + axis * 2);
      int span = (int)ml_ds_le16s(calibration + 7 + axis * 4) - ml_ds_le16s(calibration + 9 + axis * 4);
      int speed = (int)ml_ds_le16s(calibration + 19) + ml_ds_le16s(calibration + 21);
      float scale = span ? (float)speed / span : 0;
      if (abs(bias) <= 1024 && scale >= 1.0f/32.0f && scale <= 3.0f/32.0f) {
        d->pending_bias[axis] = bias;
        d->pending_scale[axis] = scale;
      }
    }
  }
  __atomic_store_n(&d->calibration_done, true, __ATOMIC_RELEASE);
  notify_completion();
  return NULL;
}
static void *dualsense_open_audio(void *arg) {
  moonlight_dualsense *d = arg;
  d->opened_audio = ml_ds_audio_open(d->fd, d->transport, d->audio_event_fd);
  close(d->audio_event_fd);
  __atomic_store_n(&d->audio_open_done, true, __ATOMIC_RELEASE);
  notify_completion();
  return NULL;
}

static void dualsense_begin_audio(moonlight_dualsense *d, int event_fd) {
  if (d->audio_opening || dualsense_cleanup_pending_for(event_fd)) return;
  int fd = fcntl(event_fd, F_DUPFD_CLOEXEC, 0);
  if (fd < 0) return;
  d->audio_event_fd = fd;
  d->audio_open_done = false;
  if (pthread_create(&d->audio_opener, NULL, dualsense_open_audio, d) != 0) {
    close(fd);
    return;
  }
  d->audio_opening = true;
}

moonlight_dualsense *dualsense_attach(int event_fd, int vendor, int product) {
  /* Auto-detect by default. A process-only environment kill switch is
   * available for driver troubleshooting without a permanent Kodi setting. */
  if (!ml_ds_hid_enabled(getenv("MOONLIGHT_DUALSENSE_HID")))
    return NULL;
  if (vendor != 0x054c || (product != 0x0ce6 && product != 0x0df2))
    return NULL;
  /* Do not claim a new bridge when its teardown cannot be isolated. */
  if (!dualsense_cleanup_start()) return NULL;
  struct stat st;
  if (fstat(event_fd, &st) != 0 || !S_ISCHR(st.st_mode) ||
      dualsense_cleanup_pending_for(event_fd)) return NULL;
  struct udev *u = udev_new();
  if (!u) return NULL;
  struct udev_device *event = udev_device_new_from_devnum(u, 'c', st.st_rdev);
  struct udev_device *parent = event ?
      udev_device_get_parent_with_subsystem_devtype(event, "hid", NULL) : NULL;
  const char *parent_path = parent ? udev_device_get_syspath(parent) : NULL;
  struct udev_enumerate *scan = udev_enumerate_new(u);
  moonlight_dualsense *d = NULL;
  if (parent_path && scan &&
      udev_enumerate_add_match_subsystem(scan, "hidraw") >= 0 &&
      udev_enumerate_scan_devices(scan) >= 0) {
    struct udev_list_entry *entry;
    udev_list_entry_foreach(entry, udev_enumerate_get_list_entry(scan)) {
      struct udev_device *raw = udev_device_new_from_syspath(u, udev_list_entry_get_name(entry));
      if (!raw) continue;
      struct udev_device *raw_parent = udev_device_get_parent_with_subsystem_devtype(raw, "hid", NULL);
      const char *raw_path = raw_parent ? udev_device_get_syspath(raw_parent) : NULL;
      const char *node = udev_device_get_devnode(raw);
      if (node && raw_path && strcmp(raw_path, parent_path) == 0) {
        int fd = open(node, O_RDWR | O_NONBLOCK | O_CLOEXEC);
        if (fd >= 0) {
          struct hidraw_devinfo info;
          if (ioctl(fd, HIDIOCGRAWINFO, &info) == 0 &&
              info.vendor == vendor && info.product == product &&
              (info.bustype == BUS_USB || info.bustype == BUS_BLUETOOTH)) {
            d = calloc(1, sizeof(*d));
            if (d) {
              d->fd = fd;
              d->transport = info.bustype == BUS_USB ? ML_DS_USB : ML_DS_BT;
              d->player = -1;
              d->event_rdev = st.st_rdev;
              (void)udev_input_identity_for_fd(event_fd, d->event_identity, sizeof(d->event_identity));
              for (unsigned axis = 0; axis < 3; ++axis) d->gyro_scale[axis] = 1.0f / 16.0f;
              pthread_mutex_init(&d->output_lock, NULL);
              pthread_cond_init(&d->output_wake, NULL);
              if (pthread_create(&d->output_worker, NULL, dualsense_output_worker, d) != 0) {
                pthread_cond_destroy(&d->output_wake);
                pthread_mutex_destroy(&d->output_lock);
                close(fd); free(d); d = NULL;
                udev_device_unref(raw);
                continue;
              }
              d->output_started = true;
              d->calibration_started = pthread_create(&d->calibration_worker, NULL, dualsense_calibrate, d) == 0;
              dualsense_begin_audio(d, event_fd);
              d->listening = true;
              d->next = bridges;
              bridges = d;
              loop_add_device_fd(fd, on_hidraw, on_hidraw_fault, POLLIN);
              fprintf(stderr, "DualSense HID bridge attached (%s)\n",
                      d->transport == ML_DS_USB ? "USB" : "Bluetooth");
            } else {
              close(fd);
            }
          } else {
            close(fd);
          }
        }
      }
      udev_device_unref(raw);
      if (d) break;
    }
  }
  if (scan) udev_enumerate_unref(scan);
  if (event) udev_device_unref(event);
  udev_unref(u);
  return d;
}

/* Touch contacts are host state, not merely HID-device state. A controller
 * removed while touching must publish UP for each outstanding contact. */
static void dualsense_release_touches(moonlight_dualsense *d) {
  if (!d) return;
  const bool can_send = d->player >= 0 &&
      (LiGetHostFeatureFlags() & LI_FF_CONTROLLER_TOUCH_EVENTS);
  for (unsigned slot = 0; slot < 2; ++slot) {
    if (!d->touch_active[slot]) continue;
    if (can_send)
      LiSendControllerTouchEvent((uint8_t)d->player, LI_TOUCH_EVENT_UP,
                                 d->touch_id[slot], d->touch_x[slot],
                                 d->touch_y[slot], 0);
    d->touch_active[slot] = false;
  }
}

static void dualsense_mark_failed(moonlight_dualsense *d) {
  if (!d || d->stopping ||
      __atomic_exchange_n(&d->hid_failed, true, __ATOMIC_ACQ_REL))
    return;
  if (__atomic_exchange_n(&d->listening, false, __ATOMIC_ACQ_REL))
    loop_remove_fd(d->fd);
  /* Preserve normal evdev controls while clearing host-side touch state. */
  dualsense_release_touches(d);
  udev_schedule_advanced_retry();
}

static void queue_cleanup(moonlight_dualsense *d) {
  pthread_mutex_lock(&bridge_cleanup.lock);
  d->retire_next = bridge_cleanup.retiring;
  bridge_cleanup.retiring = d;
  d->next = NULL;
  if (bridge_cleanup.tail) bridge_cleanup.tail->next = d;
  else bridge_cleanup.head = d;
  bridge_cleanup.tail = d;
  ++bridge_cleanup.pending;
  pthread_cond_signal(&bridge_cleanup.wake);
  pthread_mutex_unlock(&bridge_cleanup.lock);
}

/* Caller holds the evdev lifetime lock. Retire only PCM ownership; keep HID
 * sensors, touch and feedback attached while the cleanup worker closes PCM. */
bool dualsense_retry_audio(moonlight_dualsense *d, int event_fd) {
  if (d && __atomic_load_n(&d->output_failed, __ATOMIC_ACQUIRE)) dualsense_mark_failed(d);
  if (d && !d->calibration_applied && __atomic_load_n(&d->calibration_done, __ATOMIC_ACQUIRE)) {
    memcpy(d->gyro_bias, d->pending_bias, sizeof(d->gyro_bias));
    memcpy(d->gyro_scale, d->pending_scale, sizeof(d->gyro_scale));
    d->calibration_applied = true;
    if (d->calibration_started) {
      pthread_join(d->calibration_worker, NULL);
      d->calibration_started = false;
    }
  }
  if (!dualsense_hid_healthy(d)) return false;
  if (d->audio_opening) {
    if (!__atomic_load_n(&d->audio_open_done, __ATOMIC_ACQUIRE)) return false;
    pthread_join(d->audio_opener, NULL); /* Already complete; no device I/O. */
    d->audio_opening = false;
    d->audio = d->opened_audio;
    d->opened_audio = NULL;
    if (d->audio) return true;
  }
  if (ml_ds_audio_haptics_ready(d->audio)) return false;
  if (d->audio) {
    moonlight_dualsense *retired = calloc(1, sizeof(*retired));
    if (!retired) return false;
    retired->fd = -1;
    retired->event_rdev = d->event_rdev;
    memcpy(retired->event_identity, d->event_identity, sizeof(retired->event_identity));
    retired->audio = d->audio;
    d->audio = NULL;
    queue_cleanup(retired);
    return true;
  }
  dualsense_begin_audio(d, event_fd);
  return false;
}

void dualsense_detach(moonlight_dualsense *d) {
  if (!d) return;
  /* Runs on the input-loop thread: release host contacts, retire polling and
   * unlink the bridge before its background cleanup may free the allocation. */
  d->stopping = true;
  dualsense_release_touches(d);
  if (__atomic_exchange_n(&d->listening, false, __ATOMIC_ACQ_REL))
    loop_remove_fd(d->fd);
  moonlight_dualsense **link = &bridges;
  while (*link && *link != d) link = &(*link)->next;
  if (*link) *link = d->next;

  queue_cleanup(d);
}
