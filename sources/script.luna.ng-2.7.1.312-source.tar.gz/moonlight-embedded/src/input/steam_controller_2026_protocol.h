/* SPDX-License-Identifier: GPL-3.0-or-later
 * Steam Controller (2026/Ibex) HID wire contract, ported from Nonary's
 * SteamControllerCore and the Android Steam Controller USB/BLE driver.
 * Pure helpers allow tests without hardware or libudev.
 */
#ifndef MOONLIGHT_STEAM_SC26_PROTOCOL_H
#define MOONLIGHT_STEAM_SC26_PROTOCOL_H
#include <Limelight.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#define SC26_VID 0x28de
#define SC26_WIRED 0x1302
#define SC26_BLE 0x1303
#define SC26_PUCK 0x1304
#define SC26_HID_FEATURE 0x01
#define SC26_FEATURE_LENGTH 64
#define SC26_MAX_PLAYERS 16
#define SC26_MAX_PADS 2
#define SC26_REPORT_WIRED 0x42
#define SC26_REPORT_STATE 0x45
#define SC26_REPORT_TIMESTAMP 0x47
#define SC26_REPORT_BATTERY 0x43
#define SC26_REPORT_WIRELESS 0x46
#define SC26_REPORT_WIRELESS_ALT 0x79
#define SC26_SET_SETTINGS 0x87
#define SC26_LOAD_DEFAULTS 0x8e
#define SC26_GET_ATTR 0x83
#define SC26_GET_STRING 0xae
#define SC26_GET_INFO 0xf2
#define SC26_REPORT_RUMBLE 0x80
#define SC26_REPORT_PULSE 0x81
#define SC26_REPORT_COMMAND 0x82
#define SC26_REPORT_LFO 0x83
#define SC26_REPORT_SWEEP 0x84
#define SC26_REPORT_SCRIPT 0x85
#define SC26_MAX_HAPTIC_REPORT 12
#define SC26_SETTING_LIZARD 9
#define SC26_SETTING_IMU 48
#define SC26_SETTING_WATCHDOG 71

typedef struct {
  bool touched;
  float x, y, pressure;
} Sc26Touch;
typedef struct {
  uint32_t buttons;
  uint8_t lt,rt;
  int16_t lx,ly,rx,ry;
  Sc26Touch pads[2];
  float gyro[3],accel[3];
} Sc26Frame;

static inline uint16_t sc26_u16(const uint8_t *p) {
  return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}
static inline int16_t sc26_s16(const uint8_t *p) { return (int16_t)sc26_u16(p); }
static inline uint32_t sc26_u32(const uint8_t *p) {
  return (uint32_t)sc26_u16(p) | ((uint32_t)sc26_u16(p+2) << 16);
}
static inline bool sc26_bit(uint32_t bits, unsigned n) { return (bits & (1u << n)) != 0; }
static inline float sc26_clamp01(float v) { return v<0?0:v>1?1:v; }
static inline int16_t sc26_stick(int16_t raw) {
  /* Normalize -32768 to -32767 as in the Moonlight host protocol. */
  return raw == INT16_MIN ? -32767 : raw;
}
static inline uint8_t sc26_trigger(int16_t raw) {
  float normalized=sc26_clamp01(raw / 32767.0f);
  return normalized<=0.13f?0:(uint8_t)(normalized * 255.0f);
}
static inline int sc26_haptic_length(uint8_t id) {
  switch(id) {
    case SC26_REPORT_RUMBLE: return 10;
    case SC26_REPORT_PULSE: return 8;
    case SC26_REPORT_COMMAND: return 4;
    case SC26_REPORT_LFO: return 10;
    case SC26_REPORT_SWEEP: return 9;
    case SC26_REPORT_SCRIPT: return 4;
    default: return 0;
  }
}
static inline bool sc26_valid_haptic(const uint8_t *data,size_t size) {
  if (!data || size==0 || size!=(size_t)sc26_haptic_length(data[0])) return false;
  if ((data[0]==SC26_REPORT_PULSE||data[0]==SC26_REPORT_COMMAND) && data[1]>2)
    return false;
  return true;
}
static inline bool sc26_haptic_is_stop(const uint8_t *p,size_t length) {
  if(!sc26_valid_haptic(p,length)) return false;
  if(p[0]==SC26_REPORT_RUMBLE)
    return p[4]==0&&p[5]==0&&p[7]==0&&p[8]==0;
  /* Ibex pulse: [1] actuator (left/right/both), [2:3] ON duration,
   * [4:5] OFF interval, [6:7] repeat count (little endian).
   * A zero ON time OR zero repeats means no active pulse; these fields
   * are NOT independent left/right amplitudes. Preserve this OR. */
  if(p[0]==SC26_REPORT_PULSE) return (!p[2]&&!p[3])||(!p[6]&&!p[7]);
  if(p[0]==SC26_REPORT_COMMAND) return p[2]==0;
  return false;
}
static inline void sc26_rumble(uint8_t data[10],uint16_t low,uint16_t high) {
  memset(data,0,10);
  data[0]=SC26_REPORT_RUMBLE;
  data[4]=(uint8_t)low;data[5]=(uint8_t)(low>>8);
  data[7]=(uint8_t)high;data[8]=(uint8_t)(high>>8);
}
/* All feature reports are 64 bytes including the report ID. */
static inline void sc26_settings(uint8_t report[SC26_FEATURE_LENGTH],bool active) {
  memset(report,0,SC26_FEATURE_LENGTH);
  report[0]=SC26_HID_FEATURE;
  report[1]=SC26_SET_SETTINGS;
  report[2]=9;
  report[3]=SC26_SETTING_LIZARD;report[4]=(uint8_t)(active?0:1);
  report[6]=SC26_SETTING_IMU;report[7]=(uint8_t)(active?0x18:0);
  report[9]=SC26_SETTING_WATCHDOG;
}
static inline bool sc26_reserved_setting(uint8_t id) {
  return id==9 || id==48 || id==71 || id==49 || id==52 || id==53;
}
static inline size_t sc26_relay_settings(uint8_t out[SC26_FEATURE_LENGTH],
                                         const uint8_t *triples,unsigned count) {
  memset(out,0,SC26_FEATURE_LENGTH);
  out[0]=SC26_HID_FEATURE;out[1]=SC26_SET_SETTINGS;
  if (!triples || count>9) return 0; /* Nonary control callback bound. */
  unsigned kept=0;
  for(unsigned i=0;i<count;++i) {
    if(sc26_reserved_setting(triples[3*i]))continue;
    memcpy(out+3+3*kept,triples+3*i,3);++kept;
  }
  out[2]=(uint8_t)(3*kept);
  return kept ? SC26_FEATURE_LENGTH : 0;
}
static inline bool sc26_decode(const uint8_t *p,size_t length,Sc26Frame *out) {
  /* A non-NULL pointer does not prove even the report-ID byte exists. */
  if(!p || !out || length==0) return false;
  uint8_t id=p[0];
  if(!((id==SC26_REPORT_WIRED&&length>=54) ||
       ((id==SC26_REPORT_STATE||id==SC26_REPORT_TIMESTAMP)&&length>=46)))
    return false;
  const unsigned offset=1, shift=id==SC26_REPORT_TIMESTAMP?2:0;
  const uint32_t b=sc26_u32(p+offset+1);
  uint32_t flags=0;
  static const struct {uint8_t bit;uint32_t flag;} map[]={
    {0,A_FLAG},{1,B_FLAG},{2,X_FLAG},{3,Y_FLAG},{13,UP_FLAG},{10,DOWN_FLAG},
    {12,LEFT_FLAG},{11,RIGHT_FLAG},{19,LB_FLAG},{9,RB_FLAG},{6,PLAY_FLAG},
    {14,BACK_FLAG},{15,LS_CLK_FLAG},{5,RS_CLK_FLAG},{16,SPECIAL_FLAG},
    {4,MISC_FLAG},{7,PADDLE1_FLAG},{17,PADDLE2_FLAG},
    {8,PADDLE3_FLAG},{18,PADDLE4_FLAG},
    {26,TOUCHPAD_FLAG},{22,TOUCHPAD_FLAG},
    {26,LEFT_PAD_CLICK_FLAG},{22,RIGHT_PAD_CLICK_FLAG},
    {27,LEFT_TRIGGER_CLICK_FLAG},{23,RIGHT_TRIGGER_CLICK_FLAG},
    {29,LEFT_GRIP_TOUCH_FLAG},{28,RIGHT_GRIP_TOUCH_FLAG},
    {24,LEFT_STICK_TOUCH_FLAG},{20,RIGHT_STICK_TOUCH_FLAG}
  };
  for(size_t i=0;i<sizeof(map)/sizeof(map[0]);++i)
    if(sc26_bit(b,map[i].bit))flags|=map[i].flag;
  memset(out,0,sizeof(*out));
  out->buttons=flags;
  out->lt=sc26_trigger(sc26_s16(p+offset+5));
  out->rt=sc26_trigger(sc26_s16(p+offset+7));
  out->lx=sc26_stick(sc26_s16(p+offset+9));
  out->ly=sc26_stick(sc26_s16(p+offset+11));
  out->rx=sc26_stick(sc26_s16(p+offset+13));
  out->ry=sc26_stick(sc26_s16(p+offset+15));
  for(unsigned pad=0;pad<2;++pad) {
    const unsigned off=offset+17+6*pad+shift;
    const int16_t px=sc26_s16(p+off),py=sc26_s16(p+off+2);
    const uint16_t pressure=sc26_u16(p+off+4);
    out->pads[pad].touched=sc26_bit(b,pad?21:25);
    out->pads[pad].x=sc26_clamp01(px/65536.0f+0.5f);
    out->pads[pad].y=sc26_clamp01(-py/65536.0f+0.5f);
    out->pads[pad].pressure=sc26_clamp01(pressure/32768.0f);
  }
  const float acc=2.0f*9.80665f/32768.0f,gyro=2000.0f/32768.0f;
  out->accel[0]=sc26_s16(p+offset+33)*acc;
  out->accel[1]=sc26_s16(p+offset+37)*acc;
  out->accel[2]=-sc26_s16(p+offset+35)*acc;
  out->gyro[0]=sc26_s16(p+offset+39)*gyro;
  out->gyro[1]=sc26_s16(p+offset+43)*gyro;
  out->gyro[2]=-sc26_s16(p+offset+41)*gyro;
  return true;
}
static inline bool sc26_battery(const uint8_t *p,size_t size,
                                uint8_t *state,uint8_t *percent) {
  if(!p||size<15||p[0]!=SC26_REPORT_BATTERY||!state||!percent)return false;
  switch(p[1]){
    case 1:*state=LI_BATTERY_STATE_DISCHARGING;break;
    case 2:case 3:*state=LI_BATTERY_STATE_CHARGING;break;
    case 4:*state=LI_BATTERY_STATE_FULL;break;
    default:*state=LI_BATTERY_STATE_UNKNOWN;break;
  }
  *percent=p[2]>100?100:p[2];
  return true;
}
#endif
