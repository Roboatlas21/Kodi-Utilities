/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2019 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "loop.h"
#include "startup_cancel.h"
#include "connection.h"
#include "configuration.h"
#include "platform.h"
#include "config.h"
#include "host_config_path.h"
#include "sdl.h"

#include "audio/audio.h"
#include "video/video.h"
#include "video/first_video_ready.h"
#if defined(HAVE_AML) || defined(HAVE_AML_VFM)
#include "video/latency_priority.h"
#endif
#ifdef HAVE_AML
#include "osd/osd.h"
#include "osd/telemetry.h"
#include "video/aml_refresh.h"
#endif

#include "input/mapping.h"
#include "input/evdev.h"
#include "input/steam_controller_2026.h"
#include "input/controller_count.h"
#include "input/handoff.h"
#include "input/udev.h"
#ifdef HAVE_LIBCEC
#include "input/cec.h"
#endif
#ifdef HAVE_SDL
#include "input/sdl.h"
#endif

#include <Limelight.h>

#include <client.h>
#include <xml.h>
#include <discover.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include "app_list_ids.h"
#include <openssl/rand.h>

static int applist(PSERVER_DATA server) {
  PAPP_LIST list = NULL;
  if (gs_applist(server, &list) != GS_OK) {
    fprintf(stderr, "Can't get app list\n");
    return EXIT_FAILURE;
  }
  int index = 1;
  for (PAPP_LIST app = list; app; app = app->next)
    if (app->name)
      printf("%d. %s\n", index++, app->name);
  xml_free_applist(list);
  return EXIT_SUCCESS;
}

/* Native fallback: IDs are Sunshine IDs, titles are hex-encoded for safe
 * line-based transport even when titles contain tabs or newlines. */
static int applist_ids(PSERVER_DATA server) {
  PAPP_LIST list = NULL;
  if (gs_applist(server, &list) != GS_OK) {
    fprintf(stderr, "Can't get app ID list\n");
    return EXIT_FAILURE;
  }
  int status = EXIT_SUCCESS;
  puts("LUNA_APP_IDS_V1");
  for (PAPP_LIST app = list; app; app = app->next) {
    if (app->name && !moonlight_app_id_line(stdout, app->id, app->name)) {
      status = EXIT_FAILURE;
      break;
    }
  }
  if (status == EXIT_SUCCESS && puts("LUNA_APP_IDS_END") < 0)
    status = EXIT_FAILURE;
  xml_free_applist(list);
  return ferror(stdout) ? EXIT_FAILURE : status;
}

static int get_app_id(PSERVER_DATA server, const char *name) {
  if (!name) return -1;
  PAPP_LIST list = NULL;
  if (gs_applist(server, &list) != GS_OK) {
    fprintf(stderr, "Can't get app list\n");
    return -1;
  }
  int id = -1;
  for (PAPP_LIST app = list; app; app = app->next) {
    if (app->name && strcmp(app->name, name) == 0) {
      id = app->id;
      break;
    }
  }
  xml_free_applist(list);
  return id;
}

static bool signal_stream_ready(void) {
  /* The Luna-owned receipt must be opened with O_NOFOLLOW/O_NONBLOCK and
   * verified as a single-link, owned regular file before truncation. */
  const char *path = getenv("MOONLIGHT_READY_FILE");
  if (moonlight_receipt_publish(path)) return true;
  fprintf(stderr, "Unable to safely signal stream readiness\n");
  return false;
}

/* Tell the independent Luna watchdog before any native teardown can block. */
static void signal_native_shutdown(void) {
  static bool signalled;
  if (signalled) return;
  signalled = true;
  /* Preserve any earlier readiness line for short successful sessions. */
  if (!moonlight_receipt_publish_value(getenv("MOONLIGHT_READY_FILE"), "stopping\n", true))
    fprintf(stderr, "Unable to publish native shutdown receipt\n");
}

/* Join input producers while Limelight queues and mutexes still exist. */
static void quiesce_native_input(enum platform system, PCONFIGURATION config) {
  signal_native_shutdown();
  if (!IS_EMBEDDED(system) || config->viewonly)
    return;
  sc26_stop();
  evdev_stop();
#ifdef HAVE_LIBCEC
  if (config->cec)
    cec_shutdown();
#endif
}

static int stream(PSERVER_DATA server, PCONFIGURATION config, enum platform system) {
  /* Begin cancellation before the applist and remote app-launch requests.
   * Both can block before LiStartConnection begins. */
  StartupCancellation startup_cancel = {0};
  if (IS_EMBEDDED(system)) {
    loop_init();
    if (!startup_cancel_begin(&startup_cancel)) {
      fprintf(stderr, "Cannot monitor termination during Moonlight startup\n");
      quiesce_native_input(system, config);
      return EXIT_FAILURE;
    }
  }
#ifdef HAVE_AML
  if (system == AML || system == AML_VFM) {
    const int refresh_x100 = aml_refresh_rate_x100();
    if (refresh_x100 > 0) {
      config->stream.clientRefreshRateX100 = refresh_x100;
      if (config->debug_level > 0)
        printf("Amlogic display refresh: %.2f Hz (clientRefreshRateX100=%d)\n",
               refresh_x100 / 100.0, refresh_x100);
    } else if (config->debug_level > 0) {
      printf("Amlogic display refresh unavailable; leaving clientRefreshRateX100 unset\n");
    }
  }
#endif

  /* A validated exact ID avoids selecting the first same-named app.
   * Retain name lookup for existing scripts and older Luna installations. */
  int appId = config->app_id >= 0 ? config->app_id :
      get_app_id(server, config->app);
  if (appId<0) {
    fprintf(stderr, "Can't find app %s\n", config->app);
    startup_cancel_end(&startup_cancel);
    quiesce_native_input(system, config);
    return EXIT_FAILURE;
  }

  /* Protocol and input-slot bookkeeping support at most 16 controllers.
   * Bound the unsigned mask without shifting signed integers or summing
   * potentially untrusted counter values. */
  int sdl_count = 0;
  #ifdef HAVE_SDL
  sdl_count = sdl_gamepads;
  #endif
  /* Steam HID claims shadow their evdev siblings, so they are absent from
   * evdev_gamepads. Advertise them at app launch, before arrival events. */
  const int native_steam_count = sc26_claimed_controller_count();
  const int gamepad_mask = moonlight_gamepad_mask(
      evdev_gamepads + native_steam_count, sdl_count);

  int ret = gs_start_app(server, &config->stream, appId, config->sops, config->localaudio, gamepad_mask);
  if (ret < 0) {
    if (ret == GS_NOT_SUPPORTED_4K)
      fprintf(stderr, "Server doesn't support 4K\n");
    else if (ret == GS_NOT_SUPPORTED_MODE)
      fprintf(stderr, "Server doesn't support %dx%d (%d fps) or remove --nounsupported option\n", config->stream.width, config->stream.height, config->stream.fps);
    else if (ret == GS_NOT_SUPPORTED_SOPS_RESOLUTION)
      fprintf(stderr, "Optimal Playable Settings isn't supported for the resolution %dx%d, use supported resolution or add --nosops option\n", config->stream.width, config->stream.height);
    else if (ret == GS_ERROR || ret == GS_WRONG_STATE)
      fprintf(stderr, "Gamestream error: %s\n", gs_error);
    else
      fprintf(stderr, "Errorcode starting app: %d\n", ret);
    startup_cancel_end(&startup_cancel);
    quiesce_native_input(system, config);
    return EXIT_FAILURE;
  }

  /* A signal caught while launching the remote app should stop before any
   * video/audio platform setup, not wait for a new connection to start. */
  if (startup_cancel_requested(&startup_cancel)) {
    startup_cancel_end(&startup_cancel);
    quiesce_native_input(system, config);
    return EXIT_FAILURE;
  }

  int drFlags = 0;
  if (config->fullscreen)
    drFlags |= DISPLAY_FULLSCREEN;

  switch (config->rotate) {
  case 0:
    break;
  case 90:
    drFlags |= DISPLAY_ROTATE_90;
    break;
  case 180:
    drFlags |= DISPLAY_ROTATE_180;
    break;
  case 270:
    drFlags |= DISPLAY_ROTATE_270;
    break;
  default:
    printf("Ignoring invalid rotation value: %d\n", config->rotate);
  }

  if (config->debug_level > 0) {
    printf("Stream %d x %d, %d fps, %d kbps\n", config->stream.width, config->stream.height, config->stream.fps, config->stream.bitrate);
    connection_debug = true;
  }

  if (platform_start(system) != 0) {
    fprintf(stderr, "Failed to prepare native display, restoring Kodi ownership\n");
    startup_cancel_end(&startup_cancel);
    quiesce_native_input(system, config);
    (void)platform_stop(system);
    return EXIT_FAILURE;
  }
#ifdef HAVE_AML
  Osd native_osd = {0};
  const bool diagnostics = osd_diagnostics_enabled();
  if (system == AML && (config->osd || diagnostics))
    setenv("MOONLIGHT_AML_OSD", "1", 1);
  else
    unsetenv("MOONLIGHT_AML_OSD");
#endif
  if (startup_cancel_requested(&startup_cancel)) {
    startup_cancel_end(&startup_cancel);
    quiesce_native_input(system, config);
    platform_stop(system);
    return EXIT_FAILURE;
  }
  PDECODER_RENDERER_CALLBACKS video = platform_get_video(system);
  PAUDIO_RENDERER_CALLBACKS audio = platform_get_audio(system, config->audio_device);
#ifdef HAVE_AML
  if ((system == AML || system == AML_VFM) && config->osd) {
    OsdOptions osd_options;
    const bool frame_graph = osd_parse_options(config->osdargs, &osd_options) &&
                             osd_options.frametime;
    osd_telemetry_prepare(server->serverInfo.address, server->httpsPort,
                          &video, &audio, frame_graph);
  }
#endif
  int connection_result;
  if (IS_EMBEDDED(system)) {
    /* Register dedicated, bounded haptics and speaker callbacks for a host
     * implementing Vibeshine's versioned controller PCM protocol. */
    connection_callbacks.controllerHaptics = evdev_receive_haptics;
    connection_result = LiStartConnectionWithSteamController(
        &server->serverInfo, &config->stream, &connection_callbacks,
        video, audio, NULL, drFlags, config->audio_device, 0,
        evdev_receive_speaker, sc26_haptic_host, sc26_settings_host);
  } else {
    connection_callbacks.controllerHaptics = NULL;
    connection_result = LiStartConnection(&server->serverInfo, &config->stream,
        &connection_callbacks, video, audio, NULL, drFlags, config->audio_device, 0);
  }
  bool cancelled_during_startup = startup_cancel_end(&startup_cancel);
  if (connection_result != 0 || cancelled_during_startup) {
    if (cancelled_during_startup)
      fprintf(stderr, "Moonlight startup interrupted by a termination signal\n");
    else
      fprintf(stderr, "Streaming setup failed: %d\n", connection_result);
    quiesce_native_input(system, config);
    if (connection_result == 0)
      LiStopConnection();
    platform_stop(system);
    return EXIT_FAILURE;
  }
#if defined(HAVE_AML) || defined(HAVE_AML_VFM)
  /* Common-c workers now exist; find them by their published thread names
   * without a private fork of the upstream common-c submodule. */
  if (IS_EMBEDDED(system)) moonlight_latency_priority_start();
#endif
  /* Luna uses this explicit post-connection marker for startup recovery and
   * confirmed resume state. If a caller requests the marker, failing to publish
   * it leaves the launch unconfirmable, so stop the just-opened connection and
   * report startup failure rather than running until Luna's timeout kills it. */
  if (IS_EMBEDDED(system) && !config->viewonly)
    sc26_set_online(true);
  if (!signal_stream_ready()) {
#if defined(HAVE_AML) || defined(HAVE_AML_VFM)
    if (IS_EMBEDDED(system)) moonlight_latency_priority_stop();
#endif
    quiesce_native_input(system, config);
    LiStopConnection();
    platform_stop(system);
    return EXIT_FAILURE;
  }
#ifdef HAVE_LIBCEC
  if (config->cec && IS_EMBEDDED(system) && !config->viewonly)
    cec_stream_ready();
#endif
#ifdef HAVE_AML
  if ((system == AML || system == AML_VFM) && (config->osd || diagnostics)) {
    if (diagnostics)
      fprintf(stderr, "STREAM_DIAG_CONFIG_V1 pipeline=%s width=%d height=%d fps=%d bitrate_kbps=%d\n",
              system == AML ? "aml" : "aml-vfm", config->stream.width,
              config->stream.height, config->stream.fps, config->stream.bitrate);
    osd_start_monitor(&native_osd, config->osdargs, config->osd,
                      system == AML);
  }
#endif

  int input_loop_status = LOOP_OK;
  if (IS_EMBEDDED(system)) {
    if (!config->viewonly)
      evdev_start();
#if defined(HAVE_AML) || defined(HAVE_AML_VFM)
    /* Boost the input loop only after OSD/monitor workers are spawned:
     * children inherit the creating thread's Linux nice value. */
    if (!config->viewonly)
      moonlight_latency_priority_current("InputLoop", -3);
#endif
    input_loop_status = loop_main();
  }
  #ifdef HAVE_SDL
  else if (system == SDL) {
    sdl_loop();
    input_loop_status = loop_stream_failed() ? LOOP_ERROR : LOOP_OK;
  }
  #endif

  signal_native_shutdown();
#ifdef HAVE_AML
  /* Polls Limelight and native counters: stop before tearing down the stream. */
  osd_stop(&native_osd);
#endif
#if defined(HAVE_AML) || defined(HAVE_AML_VFM)
  if (IS_EMBEDDED(system)) moonlight_latency_priority_stop();
#endif
  quiesce_native_input(system, config);
  LiStopConnection();
  /* Preserve asynchronous termination errors even for SDL, which has no
   * signalfd-backed input loop to supply a failure status. */
  if (loop_stream_failed())
    input_loop_status = LOOP_ERROR;

  int quit_status = EXIT_SUCCESS;
  if (config->quitappafter) {
    if (config->debug_level > 0)
      printf("Sending app quit request ...\n");
    if (gs_quit_app(server) != GS_OK) {
      fprintf(stderr, "Failed to quit remote app after streaming: %s\n", gs_error);
      quit_status = EXIT_FAILURE;
    }
  }

  if (platform_stop(system) != 0) {
    fprintf(stderr, "Display restoration incomplete; Luna watchdog must verify Kodi recovery\n");
    input_loop_status = LOOP_ERROR;
  }
  return input_loop_status == LOOP_OK ? quit_status : EXIT_FAILURE;
}

static void help() {
  #ifdef GIT_BRANCH
  printf("Moonlight Embedded %d.%d.%d-%s-%s\n", VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH, GIT_BRANCH, GIT_COMMIT_HASH);
  #else
  printf("Moonlight Embedded %d.%d.%d\n", VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH);
  #endif
  /* A loader-independent handshake for Luna. Old native builds must not
   * pass a preflight that requires a first-video readiness receipt. */
  #if defined(HAVE_AML)
  printf("LUNA_NATIVE_FIRST_VIDEO_READY_V1\n");
  #endif
  printf("Usage: moonlight [action] (options) [host] [-port <number>]\n");
  printf("       moonlight [configfile]\n");
  printf("\n Actions\n\n");
  printf("\tpair\t\t\tPair device with computer\n");
  printf("\tunpair\t\t\tUnpair device with computer\n");
  printf("\tstream\t\t\tStream computer to device\n");
  printf("\tlist\t\t\tList available games and applications\n");
  printf("\tquit\t\t\tQuit the application or game being streamed\n");
  printf("\tmap\t\t\tCreate mapping for gamepad\n");
  printf("\tcheck-vfm\t\tCheck experimental VFM libraries without touching hardware\n");
  printf("\thelp\t\t\tShow this help\n");
  printf("\n Global Options\n\n");
  printf("\t-config <config>\tLoad configuration file\n");
  printf("\t-save <config>\t\tSave configuration file\n");
  printf("\t-verbose\t\tEnable verbose output\n");
  printf("\t-debug\t\t\tEnable verbose and debug output\n");
  printf("\n Streaming options\n\n");
  printf("\t-720\t\t\tUse 1280x720 resolution [default]\n");
  printf("\t-1080\t\t\tUse 1920x1080 resolution\n");
  printf("\t-4k\t\t\tUse 3840x2160 resolution\n");
  printf("\t-width <width>\t\tHorizontal resolution (default 1280)\n");
  printf("\t-height <height>\tVertical resolution (default 720)\n");
  #ifdef HAVE_EMBEDDED
  printf("\t-rotate <angle>\tRotate display: 0/90/180/270 (default 0)\n");
  #endif
  printf("\t-fps <fps>\t\tSpecify the fps to use (default 60)\n");
  printf("\t-bitrate <bitrate>\tSpecify the bitrate in Kbps\n");
  printf("\t-packetsize <size>\tSpecify the maximum packetsize in bytes\n");
  printf("\t-codec <codec>\t\tSelect used codec: auto/h264/h265/av1 (default auto)\n");
  printf("\t-hdr\t\tEnable HDR streaming (experimental, requires host and device support)\n");
  printf("\t-cec <true/false>\tForward CEC remote keys while streaming (opt-in)\n");
  printf("\t-osd\t\tEnable Amlogic native statistics overlay (experimental)\n");
  printf("\t-osdargs <args>\tConfigure overlay, e.g. '-font-size 20 -interval 1.5 -log'\n");
  printf("\t-remote <yes/no/auto>\t\t\tEnable optimizations for WAN streaming (default auto)\n");
  printf("\t-app <app>\t\tName of app to stream\n");
  printf("\t-nosops\t\t\tDon't allow GFE to modify game settings\n");
  printf("\t-localaudio\t\tPlay audio locally on the host computer\n");
  printf("\t-surround <5.1/7.1>\t\tStream 5.1 or 7.1 surround sound\n");
  printf("\t-keydir <directory>\tLoad encryption keys from directory\n");
  printf("\tforget-server-cert <host>\tForget ONLY this host's trusted certificate; re-pair before trusting it again\n");
  printf("\t-mapping <file>\t\tUse <file> as gamepad mappings configuration file\n");
  printf("\t-platform <system>\tSpecify system used for audio, video and input: pi/imx/aml/aml-vfm/rk/x11/x11_vdpau/sdl/fake (default auto)\n");
  printf("\t-nounsupported\t\tDon't stream if resolution is not officially supported by the server\n");
  printf("\t-quitappafter\t\tSend quit app request to remote after quitting session\n");
  printf("\t-viewonly\t\tDisable all input processing (view-only mode)\n");
  printf("\t-nomouseemulation\t\tDisable gamepad mouse emulation support (long pressing Start button)\n");
  #if defined(HAVE_SDL) || defined(HAVE_X11)
  printf("\n WM options (SDL and X11 only)\n\n");
  printf("\t-windowed\t\tDisplay screen in a window\n");
  #endif
  #ifdef HAVE_EMBEDDED
  printf("\n I/O options (Not for SDL)\n\n");
  printf("\t-input <device>\t\tUse <device> as input. Can be used multiple times\n");
  printf("\t-audio <device>\t\tUse <device> as audio output device\n");
  #endif
  printf("\nUse Ctrl+Alt+Shift+Q or Play+Back+LeftShoulder+RightShoulder to exit streaming session\n\n");
  exit(0);
}

static void pair_check(PSERVER_DATA server) {
  if (!server->paired || !gs_server_identity_verified()) {
    fprintf(stderr, "PIN-verified Sunshine server trust is required; re-pair before streaming or listing apps\n");
    exit(-1);
  }
}

/* A fresh PIN must be unpredictable across repeated Moonlight invocations.
 * Use OpenSSL's CSPRNG with rejection sampling to avoid modulo bias. */
static bool generate_pairing_pin(char pin[5]) {
  unsigned int digits = 0;
  for (unsigned int attempts = 0; attempts < 128 && digits < 4; ++attempts) {
    unsigned char byte = 0;
    if (RAND_bytes(&byte, 1) != 1)
      return false;
    if (byte >= 250)
      continue;
    pin[digits++] = (char)('0' + byte % 10);
  }
  if (digits != 4)
    return false;
  pin[4] = '\0';
  return true;
}

int main(int argc, char* argv[]) {
  CONFIGURATION config;
  config_parse(argc, argv, &config);

  if (config.action == NULL || strcmp("help", config.action) == 0)
    help();

  /* Check the AML loader while Kodi still owns the screen. */
  if (strcmp("check-aml", config.action) == 0) {
    if (platform_probe_aml() != 0)
      return EXIT_FAILURE;
    puts("AML decoder dependencies ready (hardware not tested)");
    return EXIT_SUCCESS;
  }

  if (strcmp("check-vfm", config.action) == 0) {
    if (platform_probe_vfm() != 0)
      return 1;
    printf("AML-VFM userspace dependencies ready (hardware not tested)\n");
    return 0;
  }

  if (config.debug_level > 0)
    printf("Moonlight Embedded %d.%d.%d (%s)\n", VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH, COMPILE_OPTIONS);

  if (strcmp("map", config.action) == 0) {
    if (config.inputsCount != 1) {
      printf("You need to specify one input device using -input.\n");
      exit(-1);
    }

    evdev_create(config.inputs[0], NULL, config.debug_level > 0, config.rotate);
    return evdev_map(config.inputs[0]) ? EXIT_SUCCESS : EXIT_FAILURE;
  }

  if (config.address == NULL) {
    config.address = malloc(MAX_ADDRESS_SIZE);
    if (config.address == NULL) {
      perror("Not enough memory");
      exit(-1);
    }
    config.address[0] = 0;
    printf("Searching for server...\n");
    gs_discover_server(config.address, &config.port);
    if (config.address[0] == 0) {
      fprintf(stderr, "Autodiscovery failed. Specify an IP address next time.\n");
      exit(-1);
    }
  }

  /* Deliberate local-only trust reset. This must work even when Sunshine
   * cannot connect or hosts/<name>.conf has malformed/hostile contents. */
  if (strcmp(config.action, "forget-server-cert") == 0) {
    if (!config.command_line_address_set || !config.address || !*config.address) {
      fprintf(stderr, "Specify the exact host to forget. This never clears all hosts.\n");
      return EXIT_FAILURE;
    }
    if (gs_forget_server_pin(config.key_dir, config.address) != GS_OK) {
      fprintf(stderr, "Unable to forget host trust: %s\n", gs_error);
      return EXIT_FAILURE;
    }
    printf("Forgot trusted server certificate for %s. Re-pair to verify its new key.\n",
           config.address);
    return EXIT_SUCCESS;
  }


  /* An explicitly supplied Quit destination must not be rewritten by an
   * optional hosts/<name>.conf file. A stale per-host config could otherwise
   * direct a successful Quit to a different Sunshine server. */
  char *explicit_quit_host = config.command_line_address_set &&
      (strcmp(config.action, "quit") == 0 || strcmp(config.action, "unpair") == 0 ||
       strcmp(config.action, "forget-server-cert") == 0)
      ? config.address : NULL;

  /* A valid DNS host can exceed the original 128-byte stack buffer.
   * Use one checked allocator shared with the host-only regression test. */
  char *host_config_file = moonlight_host_config_path(config.address);
  if (!host_config_file) {
    if (errno == EINVAL)
      fprintf(stderr, "Invalid Sunshine host address for local configuration lookup\n");
    else
      perror("Cannot allocate host config path");
    return EXIT_FAILURE;
  }
  /* Per-host config is another mutable source. Luna already generated
   * and preflighted a complete private session snapshot, so never merge a
   * later hosts/<name>.conf into that detached session. */
  const char *session_snapshot = getenv("LUNA_STREAM_CONFIG");
  const char *selected_host = config.address;
  if (!(session_snapshot && *session_snapshot)) {
    struct stat host_info;
    const bool exists_or_inaccessible =
        lstat(host_config_file, &host_info) == 0 ||
        (errno != ENOENT && errno != ENOTDIR);
    if (exists_or_inaccessible &&
        !config_file_parse_for_host(host_config_file, &config, selected_host)) {
      /* A per-host overlay may change stream options, but may not silently
       * redirect the authenticated target to another Sunshine computer. */
      fprintf(stderr, "Host-specific Moonlight configuration rejected; refusing to connect\n");
      free(host_config_file);
      return EXIT_FAILURE;
    }
  }
  free(host_config_file);
  if (explicit_quit_host != NULL)
    config.address = explicit_quit_host;


  SERVER_DATA server;
  printf("Connecting to %s...\n", config.address);

  int ret;
  if ((ret = gs_init(&server, config.address, config.port, config.key_dir, config.debug_level, config.unsupported)) == GS_OUT_OF_MEMORY) {
    fprintf(stderr, "Not enough memory\n");
    exit(-1);
  } else if (ret == GS_ERROR) {
    fprintf(stderr, "Gamestream error: %s\n", gs_error);
    exit(-1);
  } else if (ret == GS_INVALID) {
    fprintf(stderr, "Invalid data received from server: %s\n", gs_error);
    exit(-1);
  } else if (ret == GS_UNSUPPORTED_VERSION) {
    fprintf(stderr, "Unsupported version: %s\n", gs_error);
    exit(-1);
  } else if (ret != GS_OK) {
    fprintf(stderr, "Can't initialize Moonlight for %s: %s\n",
            config.address, gs_error ? gs_error : "unknown error");
    exit(-1);
  }

  if (config.debug_level > 0) {
    printf("GPU: %s, GFE: %s (%s, %s)\n", server.gpuType, server.serverInfo.serverInfoGfeVersion, server.gsVersion, server.serverInfo.serverInfoAppVersion);
    printf("Server codec flags: 0x%x\n", server.serverInfo.serverCodecModeSupport);
  }

  if (strcmp("list", config.action) == 0) {
    pair_check(&server);
    return applist(&server);
  } else if (strcmp("list-ids", config.action) == 0) {
    pair_check(&server);
    return applist_ids(&server);
  } else if (strcmp("app-status", config.action) == 0) {
    /* Read-only, paired-host preflight before Luna stops Kodi. The checked
     * serverinfo parser supplies the currently running host application ID. */
    pair_check(&server);
    if (config.app_id < 0) {
      fprintf(stderr, "app-status requires -appid\n");
      return EXIT_FAILURE;
    }
    printf("LUNA_APP_STATUS_V1 %d\n", server.currentGame);
    return EXIT_SUCCESS;
  } else if (strcmp("stream", config.action) == 0) {
    pair_check(&server);
    enum platform system = platform_check(config.platform);
    if (config.debug_level > 0)
      printf("Platform %s\n", platform_name(system));

    if (system == 0) {
      fprintf(stderr, "Platform '%s' not found\n", config.platform);
      exit(-1);
    } else if (system == SDL && config.audio_device != NULL) {
      fprintf(stderr, "You can't select a audio device for SDL\n");
      exit(-1);
    }

    if (system == AML_VFM && (config.codec == CODEC_AV1 || config.rotate)) {
      fprintf(stderr, "AML-VFM supports H.264/HEVC without rotation; disable AV1/rotation\n");
      exit(-1);
    }

    config.stream.supportedVideoFormats = VIDEO_FORMAT_H264;
    if (config.codec == CODEC_HEVC || (config.codec == CODEC_UNSPECIFIED && platform_prefers_codec(system, CODEC_HEVC))) {
      config.stream.supportedVideoFormats |= VIDEO_FORMAT_H265;
      if (config.hdr)
        config.stream.supportedVideoFormats |= VIDEO_FORMAT_H265_MAIN10;
    }
    if (config.codec == CODEC_AV1 || (config.codec == CODEC_UNSPECIFIED && platform_prefers_codec(system, CODEC_AV1))) {
      config.stream.supportedVideoFormats |= VIDEO_FORMAT_AV1_MAIN8;
      if (config.hdr)
        config.stream.supportedVideoFormats |= VIDEO_FORMAT_AV1_MAIN10;
    }

    if (config.hdr && !(config.stream.supportedVideoFormats & VIDEO_FORMAT_MASK_10BIT)) {
      fprintf(stderr, "HDR streaming requires HEVC or AV1 codec\n");
      exit(-1);
    }

    #ifdef HAVE_SDL
    if (system == SDL)
      sdl_init(config.stream.width, config.stream.height, config.fullscreen);
    #endif

    if (config.viewonly) {
      if (config.debug_level > 0)
        printf("View-only mode enabled, no input will be sent to the host computer\n");
    } else {
      if (IS_EMBEDDED(system)) {
        /* Block termination on the main thread before evdev/libCEC create
         * workers. Otherwise a process-directed TERM can kill a worker
         * using the default disposition and skip native teardown. */
        loop_block_termination_signals();
        char* mapping_env = getenv("SDL_GAMECONTROLLERCONFIG");
        if (config.mapping == NULL && mapping_env == NULL) {
          fprintf(stderr, "Please specify mapping file as default mapping could not be found.\n");
          exit(-1);
        }

        struct mapping* mappings = NULL;
        if (config.mapping != NULL)
          mappings = mapping_load(config.mapping, config.debug_level > 0);

        if (mapping_env != NULL) {
          /* The environment string is not ours to modify. An invalid
           * override must not dereference a NULL mapping either. */
          struct mapping* map = mapping_parse_override(mapping_env);
          if (map != NULL) {
            map->next = mappings;
            mappings = map;
          } else if (mappings == NULL) {
            fprintf(stderr, "Invalid SDL_GAMECONTROLLERCONFIG and no mapping file available\n");
            return EXIT_FAILURE;
          } else {
            fprintf(stderr, "Ignoring invalid SDL_GAMECONTROLLERCONFIG; using mapping file\n");
          }
        }

        /* Read-only inspection of open evdev descriptors, never EVIOCGRAB,
         * USB driver unbind/rebind, or other global kernel modifications. */
        if (input_handoff_enabled("MOONLIGHT_INPUT_HANDOFF_PROBE"))
          input_handoff_probe((const char *const *)config.inputs, config.inputsCount);

        /* Claim recognized Valve 2026 vendor HID interfaces before the
         * normal evdev sweep, so only successful claims shadow their own
         * keyboard/mouse and gamepad nodes. Other devices are untouched. */
        if (!config.mouse_emulation) (void)sc26_start();
        else fprintf(stderr, "Steam Controller: using evdev for requested mouse emulation\n");
        for (int i=0;i<config.inputsCount;i++) {
          if (config.debug_level > 0)
            printf("Adding input device %s...\n", config.inputs[i]);

          evdev_create(config.inputs[i], mappings, config.debug_level > 0, config.rotate);
        }

        udev_init(!inputAdded, mappings, config.debug_level > 0, config.rotate);
        evdev_init(config.mouse_emulation);
        rumble_handler = evdev_rumble;
        set_motion_event_state_handler = evdev_set_motion_event_state;
        set_controller_led_handler = evdev_set_controller_led;
        set_adaptive_triggers_handler = evdev_set_adaptive_triggers;
        #ifdef HAVE_LIBCEC
        if (config.cec)
          cec_init();
        #else
        if (config.cec)
          fprintf(stderr, "CEC requested but libCEC support is not compiled in\n");
        #endif /* HAVE_LIBCEC */
      }
      #ifdef HAVE_SDL
      else if (system == SDL) {
        if (config.inputsCount > 0) {
          fprintf(stderr, "You can't select input devices as SDL will automatically use all available controllers\n");
          exit(-1);
        }

        sdlinput_init(config.mapping);
        rumble_handler = sdlinput_rumble;
        rumble_triggers_handler = sdlinput_rumble_triggers;
        set_motion_event_state_handler = sdlinput_set_motion_event_state;
        set_controller_led_handler = sdlinput_set_controller_led;
      }
      #endif
    }

    int stream_result = stream(&server, &config, system);
    if (stream_result != EXIT_SUCCESS)
      return stream_result;
  } else if (strcmp("pair", config.action) == 0) {
    char pin[5];
    if (config.pin > 0 && config.pin <= 9999) {
      sprintf(pin, "%04d", config.pin);
    } else if (!generate_pairing_pin(pin)) {
      fprintf(stderr, "Secure pairing PIN generation failed\n");
      return EXIT_FAILURE;
    }
    printf("Please enter the following PIN on the target PC: %s\n", pin);
    fflush(stdout);
    if (gs_pair(&server, &pin[0]) != GS_OK) {
      fprintf(stderr, "Failed to pair to server: %s\n", gs_error);
      return EXIT_FAILURE;
    } else {
      printf("Succesfully paired\n");
    }
  } else if (strcmp("unpair", config.action) == 0) {
    if (gs_unpair(&server) != GS_OK) {
      fprintf(stderr, "Failed to unpair to server: %s\n", gs_error);
      return EXIT_FAILURE;
    } else {
      printf("Succesfully unpaired\n");
    }
  } else if (strcmp("quit", config.action) == 0) {
    pair_check(&server);
    if (gs_quit_app(&server) != GS_OK) {
      fprintf(stderr, "Failed to quit remote app: %s\n", gs_error);
      return EXIT_FAILURE;
    }
  } else {
    fprintf(stderr, "%s is not a valid action\n", config.action);
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}
