/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include "host_metrics.h"
#include "http.h"
#include <stdio.h>
#include <string.h>
#include <time.h>

static uint64_t monotonic_ms(void) {
  struct timespec t;
  if (clock_gettime(CLOCK_MONOTONIC,&t)) return 0;
  return (uint64_t)t.tv_sec*1000u+t.tv_nsec/1000000u;
}
static struct timespec deadline(unsigned milliseconds) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME,&t);
  t.tv_sec+=milliseconds/1000u;
  t.tv_nsec+=(long)(milliseconds%1000u)*1000000L;
  if (t.tv_nsec>=1000000000L) {++t.tv_sec;t.tv_nsec-=1000000000L;}
  return t;
}

static void *metrics_worker(void *param) {
  HostMetricsReader *r=param;
  unsigned wait_ms=0;
  for (;;) {
    pthread_mutex_lock(&r->mutex);
    if (wait_ms) {
      struct timespec until=deadline(wait_ms);
      while (!r->stopping) {
        if (pthread_cond_timedwait(&r->wake,&r->mutex,&until)) break;
      }
    }
    const bool stop=r->stopping;
    pthread_mutex_unlock(&r->mutex);
    if (stop) return NULL;
    char response[8192]={0};
    HostMetricsSample fresh;
    const int status=http_fetch_hardware_metrics(r->address,r->port,
                                                  response,sizeof(response));
    const bool valid=status==0 &&
                     host_metrics_parse_json(response,strlen(response),&fresh);
    pthread_mutex_lock(&r->mutex);
    if (status==1) {
      r->unsupported=true;
      r->have_sample=false; /* Host withdrew the API; discard old numbers. */
      pthread_mutex_unlock(&r->mutex);
      return NULL; /* No repeated probes against Sunshine/Apollo/disabled APIs. */
    }
    if (valid) {
      r->sample=fresh;
      r->received_ms=monotonic_ms();
      r->have_sample=true;
      wait_ms=fresh.interval_ms>2000 ? fresh.interval_ms : 2000;
    } else {
      wait_ms=5000;
    }
    pthread_mutex_unlock(&r->mutex);
  }
}

void host_metrics_open(HostMetricsReader *r, const char *address,
                       unsigned short port) {
  if (!r) return;
  memset(r,0,sizeof(*r));
  if (!address || !*address || strlen(address)>=sizeof(r->address) || !port) return;
  memcpy(r->address,address,strlen(address)+1);
  r->port=port;
  if (pthread_mutex_init(&r->mutex,NULL)) return;
  if (pthread_cond_init(&r->wake,NULL)) {
    pthread_mutex_destroy(&r->mutex);
    return;
  }
  if (pthread_create(&r->thread,NULL,metrics_worker,r)) {
    pthread_cond_destroy(&r->wake);
    pthread_mutex_destroy(&r->mutex);
    return;
  }
  r->started=true;
}
void host_metrics_close(HostMetricsReader *r) {
  if (!r || !r->started) return;
  pthread_mutex_lock(&r->mutex);
  r->stopping=true;
  pthread_cond_signal(&r->wake);
  pthread_mutex_unlock(&r->mutex);
  pthread_join(r->thread,NULL);
  pthread_cond_destroy(&r->wake);
  pthread_mutex_destroy(&r->mutex);
  r->started=false;
}
static void show_percent(bool valid, double n, char *out, size_t cap) {
  if (valid) snprintf(out,cap,"%.0f%%",n);
  else snprintf(out,cap,"n/a");
}
void host_metrics_format(HostMetricsReader *r, char *out, size_t capacity) {
  if (!out || !capacity) return;
  if (!r || !r->started) {
    snprintf(out,capacity,"Host CPU/GPU n/a (no telemetry)");
    return;
  }
  HostMetricsSample s;
  bool unsupported,valid;
  uint64_t age;
  pthread_mutex_lock(&r->mutex);
  unsupported=r->unsupported;
  valid=r->have_sample;
  s=r->sample;
  uint64_t now=monotonic_ms();
  age=now>=r->received_ms ? now-r->received_ms : UINT64_MAX;
  pthread_mutex_unlock(&r->mutex);
  uint64_t stale_after=(uint64_t)(s.interval_ms > 2000 ? s.interval_ms : 2000)*3u;
  if (!valid || age>stale_after) {
    snprintf(out,capacity,unsupported ? "Host CPU/GPU n/a (not exposed by host)" :
             "Host CPU/GPU n/a (waiting for metrics)");
    return;
  }
  char cpu[24],gpu[24],encoder[24],vram[40],temp[24];
  show_percent(s.has_cpu,s.cpu,cpu,sizeof(cpu));
  show_percent(s.has_gpu,s.gpu,gpu,sizeof(gpu));
  show_percent(s.has_encoder,s.encoder,encoder,sizeof(encoder));
  if (s.has_vram && s.has_vram_percent)
    snprintf(vram,sizeof(vram),"%.0f MiB (%.0f%%)",s.vram_mb,s.vram_percent);
  else if (s.has_vram)
    snprintf(vram,sizeof(vram),"%.0f MiB",s.vram_mb);
  else if (s.has_vram_percent)
    snprintf(vram,sizeof(vram),"%.0f%%",s.vram_percent);
  else snprintf(vram,sizeof(vram),"n/a");
  if (s.has_temp) snprintf(temp,sizeof(temp),"%.0fC",s.temp);
  else snprintf(temp,sizeof(temp),"n/a");
  snprintf(out,capacity,"Host CPU %s | GPU %s | ENC %s | VRAM %s | Temp %s",
           cpu,gpu,encoder,vram,temp);
}
