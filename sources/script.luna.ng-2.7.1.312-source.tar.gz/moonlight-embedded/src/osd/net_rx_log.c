/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "net_rx_log.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

/* Histogram upper bounds in microseconds. Last bin is unbounded. */
static const uint32_t bucket_us[LUNA_NET_DEBUG_BINS - 1] = {
  100, 250, 500, 1000, 2000, 4000, 8000, 16000, 33000
};

static void timing_format(const LunaNetworkTimingV1 *now,
                          const LunaNetworkTimingV1 *old,
                          char *text, size_t size) {
  const uint32_t samples = now->samples - old->samples;
  if (!samples) {
    snprintf(text, size, "n/a");
    return;
  }
  uint32_t hist[LUNA_NET_DEBUG_BINS];
  for (unsigned i = 0; i < LUNA_NET_DEBUG_BINS; ++i)
    hist[i] = now->bins[i] - old->bins[i];
  uint32_t pct[2] = {0,0};
  const unsigned cutoffs[2] = {95,99};
  for (unsigned p = 0; p < 2; ++p) {
    const uint64_t rank = ((uint64_t)samples * cutoffs[p] + 99) / 100;
    uint64_t at = 0;
    for (unsigned i = 0; i < LUNA_NET_DEBUG_BINS; ++i) {
      at += hist[i];
      if (at >= rank) {
        pct[p] = i == LUNA_NET_DEBUG_BINS - 1 ? UINT32_MAX : bucket_us[i];
        break;
      }
    }
  }
  char p95[16], p99[16];
  if (pct[0] == UINT32_MAX) snprintf(p95, sizeof(p95), ">33000");
  else if (!pct[0]) snprintf(p95, sizeof(p95), "n/a");
  else snprintf(p95, sizeof(p95), "%" PRIu32, pct[0]);
  if (pct[1] == UINT32_MAX) snprintf(p99, sizeof(p99), ">33000");
  else if (!pct[1]) snprintf(p99, sizeof(p99), "n/a");
  else snprintf(p99, sizeof(p99), "%" PRIu32, pct[1]);
  const uint32_t sum = now->sum_16us - old->sum_16us;
  snprintf(text, size,
           "n=%u mean_us=%" PRIu64 " p95_bucket_us=%s p99_bucket_us=%s worst_session_us=%u",
           samples, ((uint64_t)sum * 16U) / samples, p95, p99, now->worst_us);
}

void luna_net_debug_format(LunaNetworkDebugTracker *tracker,
                           const LunaNetworkDebugV1 *current,
                           char *output, size_t size) {
  if (!tracker || !current || !output || !size) return;
  if (current->abi != LUNA_NET_DEBUG_ABI) {
    snprintf(output, size, "NET_DIAG_V1 unavailable=abi-mismatch");
    tracker->initialized = false;
    return;
  }
  char req[24] = "n/a", actual[24] = "n/a", drops[24] = "n/a";
  if (current->socket_rcvbuf_known) {
    snprintf(req, sizeof(req), "%" PRIu32, current->socket_rcvbuf_requested);
    snprintf(actual, sizeof(actual), "%" PRIu32,
             current->socket_rcvbuf_linux_usable);
  }
  if (!tracker->initialized) {
    snprintf(output, size, "NET_DIAG_V1 baseline=1 rcvbuf_req_bytes=%s "
             "rcvbuf_linux_half_bytes=%s kernel_udp_drops=n/a", req, actual);
    tracker->previous = *current;
    tracker->initialized = true;
    return;
  }
  if (current->kernel_udp_drops_known && tracker->previous.kernel_udp_drops_known &&
      current->kernel_udp_drops >= tracker->previous.kernel_udp_drops) {
    snprintf(drops, sizeof(drops), "+%" PRIu32,
             current->kernel_udp_drops - tracker->previous.kernel_udp_drops);
  }
  const LunaNetworkDebugV1 *p = &tracker->previous;
#define C(k) ((uint32_t)(current->counts[(k)] - p->counts[(k)]))
  char rx[128], fec[128];
  timing_format(&current->receiver_work, &p->receiver_work, rx, sizeof(rx));
  timing_format(&current->fec_work, &p->fec_work, fec, sizeof(fec));
  snprintf(output, size,
      "NET_DIAG_V1 udp_datagrams=+%u udp_bytes=+%u data_accepted=+%u "
      "parity_accepted=+%u reordered=+%u duplicates=+%u rejected=+%u "
      "runt=+%u decrypt_failed=+%u "
      "fec_attempts=+%u fec_recovered_data=+%u fec_failed_attempts=+%u "
      "abandoned_data=+%u abandoned_blocks=+%u decoder_queue_overflows=+%u "
      "rx_gap20=+%u rx_gap50=+%u old_window=+%u old_frame=+%u "
      "rx_stall_gt1s=+%u fec_stall_gt1s=+%u kernel_udp_drops=%s "
      "rcvbuf_req_bytes=%s rcvbuf_linux_half_bytes=%s "
      "receiver_work=(%s) fec_work=(%s)",
      C(LUNA_NET_UDP_DATAGRAMS), C(LUNA_NET_UDP_BYTES),
      C(LUNA_NET_DATA_ACCEPTED), C(LUNA_NET_PARITY_ACCEPTED),
      C(LUNA_NET_REORDERED), C(LUNA_NET_DUPLICATES), C(LUNA_NET_REJECTED),
      C(LUNA_NET_RUNT), C(LUNA_NET_DECRYPT_FAILED),
      C(LUNA_NET_FEC_ATTEMPTS), C(LUNA_NET_FEC_RECOVERED_DATA),
      C(LUNA_NET_FEC_FAILED_ATTEMPTS), C(LUNA_NET_ABANDONED_DATA),
      C(LUNA_NET_ABANDONED_BLOCKS), C(LUNA_NET_DECODER_QUEUE_OVERFLOWS),
      C(LUNA_NET_RX_GAP_20MS), C(LUNA_NET_RX_GAP_50MS),
      C(LUNA_NET_OLD_WINDOW), C(LUNA_NET_OLD_FRAME),
      C(LUNA_NET_RX_STALL_GT1S), C(LUNA_NET_FEC_STALL_GT1S),
      drops, req, actual, rx, fec);
  tracker->previous = *current;
#undef C
}
