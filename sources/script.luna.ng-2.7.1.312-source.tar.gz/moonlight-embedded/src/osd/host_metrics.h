/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef MOONLIGHT_HOST_METRICS_H
#define MOONLIGHT_HOST_METRICS_H
#include "host_metrics_json.h"
#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
  pthread_t thread;
  pthread_mutex_t mutex;
  pthread_cond_t wake;
  bool started, stopping, unsupported, have_sample;
  uint64_t received_ms;
  HostMetricsSample sample;
  char address[256];
  unsigned short port;
} HostMetricsReader;

/* Read-only, opt-in-by-OSD extension. Ordinary hosts remain fully usable. */
void host_metrics_open(HostMetricsReader *reader, const char *address,
                       unsigned short https_port);
void host_metrics_close(HostMetricsReader *reader);
void host_metrics_format(HostMetricsReader *reader, char *out, size_t out_size);
#endif
