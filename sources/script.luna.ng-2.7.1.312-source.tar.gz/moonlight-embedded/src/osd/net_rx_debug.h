/* SPDX-License-Identifier: GPL-3.0-or-later
 * Private CoreELEC-only diagnostics contract, shared verbatim with the
 * locally patched common-c submodule at build time. All fields are u32
 * for lock-free sampling from an ARM32 monitoring thread.
 */
#ifndef LUNA_NETWORK_DEBUG_ABI_H
#define LUNA_NETWORK_DEBUG_ABI_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define LUNA_NET_DEBUG_ABI 1U
#define LUNA_NET_DEBUG_BINS 10U
enum LunaNetDebugCounter {
  LUNA_NET_UDP_DATAGRAMS = 0,
  LUNA_NET_UDP_BYTES,
  LUNA_NET_DATA_ACCEPTED,
  LUNA_NET_PARITY_ACCEPTED,
  LUNA_NET_REORDERED,
  LUNA_NET_DUPLICATES,
  LUNA_NET_REJECTED,
  LUNA_NET_RUNT,
  LUNA_NET_DECRYPT_FAILED,
  LUNA_NET_FEC_ATTEMPTS,
  LUNA_NET_FEC_RECOVERED_DATA,
  LUNA_NET_FEC_FAILED_ATTEMPTS,
  LUNA_NET_ABANDONED_DATA,
  LUNA_NET_ABANDONED_BLOCKS,
  LUNA_NET_DECODER_QUEUE_OVERFLOWS,
  LUNA_NET_RX_GAP_20MS,
  LUNA_NET_RX_GAP_50MS,
  LUNA_NET_OLD_WINDOW,
  LUNA_NET_OLD_FRAME,
  LUNA_NET_RX_STALL_GT1S,
  LUNA_NET_FEC_STALL_GT1S,
  LUNA_NET_COUNTERS
};
typedef struct {
  uint32_t samples, sum_16us, worst_us;
  uint32_t bins[LUNA_NET_DEBUG_BINS];
} LunaNetworkTimingV1;
typedef struct {
  uint32_t abi; /* Exactly LUNA_NET_DEBUG_ABI, or absent. */
  uint32_t counts[LUNA_NET_COUNTERS];
  LunaNetworkTimingV1 receiver_work;
  LunaNetworkTimingV1 fec_work;
  uint32_t socket_rcvbuf_requested, socket_rcvbuf_linux_usable;
  uint32_t socket_rcvbuf_known;
  uint32_t kernel_udp_drops, kernel_udp_drops_known;
} LunaNetworkDebugV1;

/* Optional dynamically resolved common-c API. */
bool LiGetLunaNetworkDebugV1(LunaNetworkDebugV1 *out, uint32_t bytes);

/* Internal hooks, used by a local build overlay on the pinned submodule.
 * No separate upstream source revision or public GitHub commit is needed. */
void LunaNetDebugInit(void);
bool LunaNetDebugEnabled(void);
void LunaNetDebugCount(enum LunaNetDebugCounter counter, uint32_t value);
uint64_t LunaNetDebugDatagram(int bytes);
void LunaNetDebugReceiverWork(uint64_t start_us);
void LunaNetDebugFecWork(uint64_t start_us);
void LunaNetDebugSocketSet(int fd, uint32_t requested_bytes);
#endif
