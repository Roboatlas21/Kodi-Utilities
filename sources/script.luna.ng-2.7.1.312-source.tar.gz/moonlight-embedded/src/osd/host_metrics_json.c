/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "host_metrics_json.h"
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

typedef struct {const char *p, *end; unsigned depth;} Reader;
enum Scope { ROOT, CPU, GPU, GPU_DATA, SKIP };

static void space(Reader *r) {
  while (r->p < r->end && (*r->p == ' ' || *r->p == '\n' ||
         *r->p == '\r' || *r->p == '\t')) r->p++;
}
static bool take(Reader *r, char c) {
  space(r);
  if (r->p == r->end || *r->p != c) return false;
  r->p++; return true;
}
static bool jstring(Reader *r, char *out, size_t capacity) {
  if (!take(r, '"')) return false;
  size_t n=0;
  while (r->p < r->end) {
    unsigned char c=(unsigned char)*r->p++;
    if (c == '"') {
      if (capacity) out[n]=0;
      return true;
    }
    if (c < 32) return false;
    if (c == '\\') {
      if (r->p == r->end) return false;
      c=(unsigned char)*r->p++;
      if (c == 'u') {
        for (int i=0;i<4;i++) {
          if (r->p == r->end || !isxdigit((unsigned char)*r->p++)) return false;
        }
        c='?';
      } else if (c == 'b'||c == 'f'||c == 'n'||c == 'r'||c == 't') {
        c='?';
      } else if (c != '"' && c != '\\' && c != '/') return false;
    }
    if (capacity && n+1<capacity) out[n++]=(char)c;
  }
  return false;
}
static bool jnumber(Reader *r, double *value) {
  space(r);
  const char *start=r->p;
  if (r->p<r->end && *r->p=='-') r->p++;
  if (r->p==r->end) return false;
  if (*r->p=='0') r->p++;
  else {
    if (*r->p<'1'||*r->p>'9') return false;
    do {r->p++;} while (r->p<r->end && isdigit((unsigned char)*r->p));
  }
  if (r->p<r->end && *r->p=='.') {
    r->p++;
    if (r->p==r->end || !isdigit((unsigned char)*r->p)) return false;
    do {r->p++;} while (r->p<r->end && isdigit((unsigned char)*r->p));
  }
  if (r->p<r->end && (*r->p=='e'||*r->p=='E')) {
    r->p++;
    if (r->p<r->end && (*r->p=='+'||*r->p=='-')) r->p++;
    if (r->p==r->end || !isdigit((unsigned char)*r->p)) return false;
    do {r->p++;} while (r->p<r->end && isdigit((unsigned char)*r->p));
  }
  if ((size_t)(r->p-start)>=64) return false;
  char buf[64];
  memcpy(buf,start,(size_t)(r->p-start)); buf[r->p-start]=0;
  char *end=NULL;
  errno=0;
  double number=strtod(buf,&end);
  if (errno || !isfinite(number) || !end || *end) return false;
  if (value) *value=number;
  return true;
}
static bool literal(Reader *r, const char *word) {
  size_t len=strlen(word);
  space(r);
  if ((size_t)(r->end-r->p)<len || memcmp(r->p,word,len)) return false;
  r->p+=len; return true;
}
static bool value(Reader *r, enum Scope scope, HostMetricsSample *m,
                  bool *version, bool *gpu_found);
static bool object(Reader *r, enum Scope scope, HostMetricsSample *m,
                   bool *version, bool *gpu_found) {
  if (!take(r,'{') || ++r->depth>12) return false;
  if (take(r,'}')) {r->depth--;return true;}
  do {
    char key[80];
    if (!jstring(r,key,sizeof(key)) || !take(r,':')) return false;
    space(r);
    enum Scope next=SKIP;
    if (scope==ROOT && !strcmp(key,"cpu")) next=CPU;
    if (scope==GPU && !strcmp(key,"metrics")) next=GPU_DATA;
    if (next!=SKIP && r->p<r->end && *r->p=='{') {
      if (!object(r,next,m,version,gpu_found)) return false;
    } else if (scope==ROOT && !strcmp(key,"gpus")) {
      if (!take(r,'[') || ++r->depth>12) return false;
      if (!take(r,']')) {
        do {
          space(r);
          if (!value(r,*gpu_found?SKIP:GPU,m,version,gpu_found)) return false;
          if (m->has_gpu || m->has_encoder || m->has_temp ||
              m->has_vram || m->has_vram_percent) *gpu_found=true;
          if (take(r,']')) break;
          if (!take(r,',')) return false;
        } while (true);
      }
      r->depth--;
    } else if ((scope==ROOT && (!strcmp(key,"version") || !strcmp(key,"interval_ms"))) ||
               (scope==CPU && !strcmp(key,"cpu_usage_percent")) ||
               (scope==GPU_DATA && (!strcmp(key,"gpu_usage_percent") ||
                  !strcmp(key,"gpu_encoder_percent") || !strcmp(key,"gpu_temperature_c") ||
                  !strcmp(key,"gpu_vram_used_mb") || !strcmp(key,"gpu_vram_usage_percent")))) {
      space(r);
      if (r->p<r->end && (*r->p=='-' || isdigit((unsigned char)*r->p))) {
        double n;
        if (!jnumber(r,&n)) return false;
        if (scope==ROOT && !strcmp(key,"version")) *version=(n==1);
        else if (scope==ROOT && !strcmp(key,"interval_ms") && n>=100 && n<=60000 && n==(uint32_t)n)
          m->interval_ms=(uint32_t)n;
        else if (scope==CPU && n>=0 && n<=100) {m->has_cpu=true;m->cpu=n;}
        else if (scope==GPU_DATA && !strcmp(key,"gpu_usage_percent") && n>=0 && n<=100) {m->has_gpu=true;m->gpu=n;}
        else if (scope==GPU_DATA && !strcmp(key,"gpu_encoder_percent") && n>=0 && n<=100) {m->has_encoder=true;m->encoder=n;}
        else if (scope==GPU_DATA && !strcmp(key,"gpu_temperature_c") && n>=-50 && n<=150) {m->has_temp=true;m->temp=n;}
        else if (scope==GPU_DATA && !strcmp(key,"gpu_vram_used_mb") && n>=0 && n<=1e9) {m->has_vram=true;m->vram_mb=n;}
        else if (scope==GPU_DATA && !strcmp(key,"gpu_vram_usage_percent") && n>=0 && n<=100) {m->has_vram_percent=true;m->vram_percent=n;}
      } else if (!value(r,SKIP,m,version,gpu_found)) return false;
    } else if (!value(r,SKIP,m,version,gpu_found)) return false;
    if (take(r,'}')) {r->depth--;return true;}
  } while (take(r,','));
  return false;
}
static bool array(Reader *r, HostMetricsSample *m, bool *version, bool *gpu_found) {
  if (!take(r,'[') || ++r->depth>12) return false;
  if (take(r,']')) {r->depth--;return true;}
  do {
    if (!value(r,SKIP,m,version,gpu_found)) return false;
    if (take(r,']')) {r->depth--;return true;}
  } while (take(r,','));
  return false;
}
static bool value(Reader *r, enum Scope scope, HostMetricsSample *m,
                  bool *version, bool *gpu_found) {
  space(r);
  if (r->p==r->end) return false;
  if (*r->p=='{') return object(r,scope,m,version,gpu_found);
  if (*r->p=='[') return array(r,m,version,gpu_found);
  if (*r->p=='"') return jstring(r,NULL,0);
  if (*r->p=='t') return literal(r,"true");
  if (*r->p=='f') return literal(r,"false");
  if (*r->p=='n') return literal(r,"null");
  return jnumber(r,NULL);
}
bool host_metrics_parse_json(const char *json, size_t length, HostMetricsSample *result) {
  if (!result || !json || length<2 || length>8192) return false;
  HostMetricsSample m={0}; m.interval_ms=1000;
  Reader r={.p=json,.end=json+length};
  bool version=false,gpu_found=false;
  if (!object(&r,ROOT,&m,&version,&gpu_found)) return false;
  space(&r);
  if (r.p!=r.end || !version) return false;
  *result=m;
  return true;
}
