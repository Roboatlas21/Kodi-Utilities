#!/usr/bin/env python3
"""Choose a monotonically increasing Luna addon version for the Kodi feed.

Use the current private source version if it exceeds the published version.
Otherwise increment the fourth component of the public version. Modifies only
the root addon version attribute, not the add-on ID, source tree or binaries.
"""
import argparse
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ADDON_ID = "script.luna.ng"
VERSION = re.compile(r"[0-9]+(?:\.[0-9]+){3}\Z")


def parse_version(value):
    if not isinstance(value, str) or not VERSION.fullmatch(value):
        raise ValueError("Expected a four-part numeric Luna version")
    return tuple(int(part) for part in value.split("."))


def published_version(feed):
    root = ET.fromstring(Path(feed).read_bytes())
    if root.tag != "addons":
        raise ValueError("Invalid Kodi repository index")
    found = root.findall(f"addon[@id='{ADDON_ID}']")
    if len(found) != 1:
        raise ValueError("Expected exactly one published Luna NG entry")
    return parse_version(found[0].get("version"))


def release_version(addon, feed):
    original = Path(addon).read_text(encoding="utf-8")
    root = ET.fromstring(original)
    if root.tag != "addon" or root.get("id") != ADDON_ID:
        raise ValueError("Unexpected Luna NG add-on identity")
    current = parse_version(root.get("version"))
    published = published_version(feed)
    # Do not accidentally change the major/minor/build line when incrementing.
    if current > published:
        return ".".join(str(number) for number in current), original
    if current[:3] != published[:3]:
        raise ValueError(
            "Published Luna NG is on a different version line; update source addon.xml manually")
    next_version = (*published[:3], published[3] + 1)
    version = ".".join(str(number) for number in next_version)
    marker = re.compile(r'(<addon\b[^>]*\bversion=")([0-9]+(?:\.[0-9]+){3})(")', re.S)
    updated, replacements = marker.subn(lambda m: m.group(1) + version + m.group(3),
                                        original, count=1)
    if replacements != 1 or ET.fromstring(updated).get("version") != version:
        raise ValueError("Cannot update only the Luna addon version")
    return version, updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("addon_xml")
    parser.add_argument("public_addons_xml")
    args = parser.parse_args()
    version, content = release_version(args.addon_xml, args.public_addons_xml)
    path = Path(args.addon_xml)
    if path.read_text(encoding="utf-8") != content:
        path.write_text(content, encoding="utf-8")
    print(version)


if __name__ == "__main__":
    main()
