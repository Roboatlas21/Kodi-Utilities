"""Exercise application context menus and exact per-host streaming profiles."""
import ast
from pathlib import Path
import types
import unittest
import urllib.parse
from unittest import mock

from resources.lib.util.appidentity import canonical_app_id

SOURCE = Path(__file__).resolve().parents[1] / 'addon.py'
FUNCTIONS = {'_appItem', 'chooseStreamProfile'}


class StreamProfileUiTests(unittest.TestCase):
    def setUp(self):
        parsed = ast.parse(SOURCE.read_text(encoding='utf-8'))
        definitions = [node for node in parsed.body
                       if isinstance(node, ast.FunctionDef)
                       and node.name in FUNCTIONS]
        self.assertEqual({node.name for node in definitions}, FUNCTIONS)
        self.store = mock.Mock()
        self.store.key = 'a' * 20
        self.store.get.return_value = None
        self.dialog = mock.Mock()
        self.dialog.select.return_value = 2
        self.item = mock.Mock()
        self.gui = types.SimpleNamespace(
            ListItem=mock.Mock(return_value=self.item),
            Dialog=mock.Mock(return_value=self.dialog))
        self.xbmc = types.SimpleNamespace(executebuiltin=mock.Mock())
        self.logger = mock.Mock()
        self.scope = {
            'xbmc': self.xbmc, 'xbmcgui': self.gui,
            'addon': types.SimpleNamespace(getLocalizedString=lambda _id: ''),
            'base_url': 'plugin://script.luna.ng',
            'urllib': urllib,
            'canonical_app_id': canonical_app_id,
            'logger': self.logger,
            '_stream_profiles': lambda: self.store,
            'args': {'id': ['42'], 'host': ['a' * 20]},
        }
        module = ast.Module(body=definitions, type_ignores=[])
        exec(compile(module, str(SOURCE), 'exec'), self.scope)

    def test_context_menu_has_profile_action_with_bound_host_and_app_id(self):
        for folder in (None, 'Favorites'):
            self.item.reset_mock()
            self.scope['_appItem']('42', 'Game', None, folder, 'a' * 20)
            self.item.addContextMenuItems.assert_called_once()
            menu = self.item.addContextMenuItems.call_args.args[0]
            self.assertEqual(len(menu), 2)
            actions = [target for _, target in menu]
            self.assertIn('action=streamprofile&id=42&host=' + 'a' * 20,
                          actions[1])
            self.assertIn('action=assign&id=42', actions[0])

    def test_save_performance_profile_and_remember_preselection(self):
        self.scope['chooseStreamProfile']()
        self.store.get.assert_called_once_with('42')
        self.store.set.assert_called_once_with('42', 'gaming_1080p120')
        self.assertEqual(self.dialog.select.call_args.kwargs['preselect'], 0)
        self.assertEqual(self.dialog.select.call_args.args[1], [
            'Use Luna default settings',
            'Quality (4K60)',
            'Performance (1080p120)',
        ])
        self.xbmc.executebuiltin.assert_called_once_with('Container.Refresh')
        self.store.get.return_value = 'gaming_1080p120'
        self.store.reset_mock()
        self.dialog.select.return_value = 2
        self.scope['chooseStreamProfile']()
        self.assertEqual(self.dialog.select.call_args.kwargs['preselect'], 2)

    def test_choose_quality_or_reset_to_luna_defaults(self):
        for index, expected in ((1, 'desktop_4k60'), (0, None)):
            with self.subTest(index=index):
                self.store.reset_mock()
                self.dialog.select.return_value = index
                self.scope['chooseStreamProfile']()
                self.store.set.assert_called_once_with('42', expected)

    def test_cancel_and_host_change_never_mutate_profiles(self):
        self.dialog.select.return_value = -1
        self.scope['chooseStreamProfile']()
        self.store.set.assert_not_called()
        self.store.reset_mock()
        self.scope['args']['host'] = ['wrong-host-key']
        self.scope['chooseStreamProfile']()
        self.store.get.assert_not_called()
        self.store.set.assert_not_called()
        self.dialog.ok.assert_called()
        self.xbmc.executebuiltin.reset_mock()
        self.scope['chooseStreamProfile']()
        self.xbmc.executebuiltin.assert_not_called()

    def test_corrupt_storage_shows_error_and_does_not_refresh(self):
        self.store.get.side_effect = ValueError('corrupted')
        self.scope['chooseStreamProfile']()
        self.store.set.assert_not_called()
        self.xbmc.executebuiltin.assert_not_called()
        self.dialog.ok.assert_called()
        self.logger.error.assert_called()


if __name__ == '__main__':
    unittest.main()
