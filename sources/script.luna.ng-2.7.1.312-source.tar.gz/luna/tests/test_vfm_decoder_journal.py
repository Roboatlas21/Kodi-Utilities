"""Durable decoder replacement journal tests (no kernel module writes)."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from resources.lib.util import vfmruntime as runtime


class DecoderJournalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.journal = self.root / '.luna-session.ABCD1234.decoder-state'
        self.stock = self.root / 'amvdec_ports.ko'
        self.stock.write_bytes(b'old signed module image')

    def test_persists_journal_with_original_and_fsync(self):
        runtime._journal_save(self.journal, (self.stock, '0', ''))
        self.assertTrue(self.journal.is_file())
        path, record = runtime._journal_read(self.journal)
        self.assertEqual(path, self.journal)
        self.assertEqual(record['stock'], str(self.stock))
        self.assertEqual(record['mode'], '0')
        self.assertEqual(record['schema'], runtime.DECODER_JOURNAL_SCHEMA)
        self.assertEqual(len(record['sha256']), 64)

    def test_duplicate_journal_does_not_overwrite_recovery(self):
        runtime._journal_save(self.journal, (self.stock, '0', ''))
        original = self.journal.read_bytes()
        with self.assertRaisesRegex(runtime.VfmRuntimeError, 'already exists'):
            runtime._journal_save(self.journal, (self.stock, '1', 'new'))
        self.assertEqual(self.journal.read_bytes(), original)

    def test_old_boot_journal_retired_without_module_operations(self):
        runtime._journal_save(self.journal, (self.stock, '0', ''))
        record = json.loads(self.journal.read_text())
        record['boot'] = 'prior-boot'
        self.journal.write_text(json.dumps(record) + '\n')
        with mock.patch.object(runtime, '_restore_stock_decoder') as restore:
            runtime.recover_decoder(self.journal, old_boot=True)
            restore.assert_not_called()
        self.assertFalse(self.journal.exists())

    def test_current_boot_must_not_use_old_boot_retirement(self):
        runtime._journal_save(self.journal, (self.stock, '0', ''))
        with self.assertRaisesRegex(runtime.VfmRuntimeError, 'live-boot'):
            runtime.recover_decoder(self.journal, old_boot=True)
        self.assertTrue(self.journal.exists())

    def test_malformed_and_symlinked_journals_fail_closed(self):
        self.journal.write_text('not json\n')
        with self.assertRaises((ValueError, runtime.VfmRuntimeError)):
            runtime.recover_decoder(self.journal)
        self.journal.unlink()
        self.journal.symlink_to(self.stock)
        with self.assertRaises((OSError, runtime.VfmRuntimeError)):
            runtime.recover_decoder(self.journal)

    def test_recovery_refuses_stock_outside_same_trusted_roots(self):
        runtime._journal_save(self.journal, (self.stock, '0', ''))
        with mock.patch.object(runtime, '_restore_stock_decoder') as restore:
            with self.assertRaisesRegex(runtime.VfmRuntimeError,
                                        'escaped kernel module directories'):
                runtime.recover_decoder(self.journal)
            restore.assert_not_called()
        self.assertTrue(self.journal.exists())

    def test_mismatched_resident_stock_build_keeps_decoder_journal(self):
        # The file hash and version can be valid while a different build
        # with the same MODULE_VERSION is loaded. Never disarm on that basis.
        self.stock.write_bytes(b'stock module')
        runtime._journal_save(self.journal, (self.stock, '0', 'stock-v1'))
        with mock.patch.object(runtime, '_stock_module_path_allowed', return_value=True), \
             mock.patch.object(runtime, '_module_info',
                               side_effect=lambda field, path: (
                                   __import__('os').uname().release + ' SMP'
                                   if field == 'vermagic' else
                                   'stock-v1' if field == 'version' else 'MATCHED_SRC')), \
             mock.patch.object(runtime, '_restore_stock_decoder',
                               side_effect=runtime.VfmRuntimeError('stock srcversion mismatch; recovery retained')):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime.recover_decoder(self.journal)
        self.assertTrue(self.journal.exists())

    def test_wrong_resident_multiplanar_retains_recovery_journal(self):
        self.stock.write_bytes(b'stock module')
        runtime._journal_save(self.journal, (self.stock, '0', 'stock-v1'))
        with mock.patch.object(runtime, '_stock_module_path_allowed', return_value=True), \
             mock.patch.object(runtime, '_module_info',
                               side_effect=lambda field, path: (
                                   __import__('os').uname().release + ' SMP' if field == 'vermagic'
                                   else 'stock-v1' if field == 'version' else 'SRC')), \
             mock.patch.object(runtime, '_loaded_module_version', return_value='stock-v1'), \
             mock.patch.object(runtime, '_verify_loaded_stock_decoder'), \
             mock.patch.object(runtime, '_verify_stock_multiplanar',
                               side_effect=runtime.VfmRuntimeError('mode mismatch; recovery retained')):
            with self.assertRaisesRegex(runtime.VfmRuntimeError, 'recovery retained'):
                runtime.recover_decoder(self.journal)
        self.assertTrue(self.journal.exists())

    def test_loader_journals_before_unload_and_disarms_after_probe(self):
        import subprocess
        state = {'decoder': 'stock-v1', 'bridge': False}
        calls = []
        release = '4.9.test'

        def exists(path):
            name = str(path)
            if name == '/sys/module/amvdec_ports':
                return state['decoder'] is not None
            if name == '/sys/module/moonlight_vfm':
                return state['bridge']
            return name == '/dev/moonlight-vfm'

        def run(args, **kwargs):
            if args[0] == 'rmmod':
                calls.append('rmmod')
                state['decoder'] = None
            elif args[0] == 'insmod':
                if str(args[1]).endswith('amvdec_ports.ko'):
                    state['decoder'] = 'moonlight-hdr1'
                else:
                    state['bridge'] = True
                calls.append('insmod')
            return subprocess.CompletedProcess(args, 0)

        with mock.patch.object(runtime, 'verify_bundle', return_value={
                    'kernel_release': release,
                    'module_order': ['amvdec_ports.ko', 'moonlight_vfm.ko']}), \
             mock.patch.object(runtime, 'check_loaded_bridge'), \
             mock.patch.object(runtime, 'check_decoder_device'), \
             mock.patch.object(runtime, '_module_info', side_effect=lambda field, path:
                               release + ' SMP' if field == 'vermagic' else '6'), \
             mock.patch.object(runtime, 'prepare_hdr_decoder', return_value=(
                               self.stock, '0', 'stock-v1')), \
             mock.patch.object(runtime, '_loaded_module_version',
                               side_effect=lambda name: state['decoder']), \
             mock.patch.object(runtime.os, 'uname',
                               return_value=type('U', (), {'release': release})()), \
             mock.patch.object(Path, 'exists', new=exists), \
             mock.patch.object(runtime.subprocess, 'run', side_effect=run), \
             mock.patch.object(runtime, '_journal_save',
                               side_effect=lambda *args: calls.append('journal')), \
             mock.patch.object(runtime, '_journal_remove',
                               side_effect=lambda *args: calls.append('disarm')):
            runtime.load_modules(self.root, self.journal)
        self.assertEqual(calls, ['journal', 'rmmod', 'insmod', 'insmod', 'disarm'])

    def test_missing_journal_is_safe_noop(self):
        with mock.patch.object(runtime, '_restore_stock_decoder') as restore:
            runtime.recover_decoder(self.journal)
            restore.assert_not_called()


if __name__ == '__main__':
    unittest.main()
