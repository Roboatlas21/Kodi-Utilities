"""Hardware outputs remain selectable alongside ALSA plugins."""
import unittest
from unittest.mock import patch
from resources.lib.util import audiodevices


class AudioEnumerationTests(unittest.TestCase):
    def test_usb_plugin_does_not_hide_hdmi_hardware(self):
        plugin = {'alsa': 'surround40:CARD=USB,DEV=0', 'name': 'USB',
                  'dummy': False, 'busy': False}
        with patch.object(audiodevices.subprocess, 'check_output', return_value=
                          'card 0: AML [AML], device 0: HDMI []\n'), \
             patch.object(audiodevices, '_busy', return_value=False), \
             patch.object(audiodevices, '_plugin_devices', return_value=[plugin]):
            self.assertEqual([d['alsa'] for d in audiodevices.list_playback()],
                             [plugin['alsa'], 'hw:0,0'])
