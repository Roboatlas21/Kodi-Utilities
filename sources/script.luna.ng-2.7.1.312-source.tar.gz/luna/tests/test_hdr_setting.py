"""HDR is opt-in, independent of OSD, and available on AML and native Main10 VFM."""
import configparser
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock
from xml.etree import ElementTree

sys.modules.setdefault('xbmcaddon', types.ModuleType('xbmcaddon'))
from resources.lib.util.confighelper import ConfigHelper

ROOT = Path(__file__).resolve().parents[1]


class HdrSettingTests(unittest.TestCase):
    def test_hdr_is_visible_separate_default_off_and_enabled_for_vfm(self):
        root = ElementTree.parse(ROOT / 'resources/settings.xml').getroot()
        hdr = [s for s in root.iter('setting') if s.get('id') == 'hdr_flag']
        self.assertEqual(len(hdr), 1)
        self.assertEqual(hdr[0].get('type'), 'boolean')
        self.assertEqual(hdr[0].findtext('default'), 'false')
        self.assertNotEqual(hdr[0].findtext('visible'), 'false')
        self.assertIsNone(hdr[0].get('parent'))
        self.assertIsNone(hdr[0].find('dependencies'))
        self.assertTrue(hdr[0].get('help'))

    def test_hdr_codec_and_pipeline_switches_reach_the_launch_snapshot(self):
        defaults = {s.get('id'): s.findtext('default') or '' for s in
                    ElementTree.parse(ROOT / 'resources/settings.xml').getroot().iter('setting')}
        values = dict(defaults, codec='h264', local_audio='true',
                      host_addr='192.0.2.1', input_device_selectors_v2='')
        with tempfile.TemporaryDirectory() as td:
            addon = Path(td)
            binary = addon / 'bin/coreelec-ng'
            binary.mkdir(parents=True)
            helper = ConfigHelper.__new__(ConfigHelper)
            helper.addon_path = str(addon) + '/'
            helper.logger = mock.Mock()
            helper.plugin = types.SimpleNamespace(
                getSetting=lambda k: values.get(k, ''),
                getSettingInt=lambda k: int(values.get(k) or 0),
                setSettingString=mock.Mock())
            with mock.patch.object(helper, '_find_binary', return_value=str(binary) + '/'), \
                 mock.patch('resources.lib.util.confighelper.inputdevices.resolve_selectors', return_value=[]):
                # A saved H.264 choice survives HDR on/off and switching to VFM.
                for pipeline, requested, osd, effective_hdr, codec in (
                    ('aml', 'false', 'true', 'false', 'h264'),
                    ('aml', 'true', 'false', 'true', 'h265'),
                    ('aml', 'true', 'true', 'true', 'h265'),
                    ('aml-vfm', 'true', 'true', 'true', 'h265'),
                    ('aml-vfm', 'false', 'true', 'false', 'h264'),
                    ('aml', 'true', 'true', 'true', 'h265'),
                    ('aml', 'false', 'false', 'false', 'h264'),
                ):
                    with self.subTest(pipeline=pipeline, hdr=requested, osd=osd):
                        values.update(video_pipeline=pipeline, hdr_flag=requested, osd=osd)
                        helper.configure()
                        snapshot = Path(helper.create_launch_snapshot())
                        try:
                            rendered = configparser.ConfigParser()
                            rendered.read(snapshot)
                            self.assertEqual(rendered['Moonlight']['hdr'], effective_hdr)
                            self.assertEqual(rendered['Moonlight']['codec'], codec)
                            self.assertEqual(rendered['Moonlight']['osd'], osd)
                            self.assertEqual(values['codec'], 'h264')
                            self.assertEqual(values['hdr_flag'], requested)
                        finally:
                            snapshot.unlink()
            for call in helper.plugin.setSettingString.call_args_list:
                self.assertNotIn(call.args[0], ('codec', 'hdr_flag'))


if __name__ == '__main__':
    unittest.main()
