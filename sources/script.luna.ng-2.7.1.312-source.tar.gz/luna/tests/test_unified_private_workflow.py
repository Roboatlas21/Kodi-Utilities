"""Static regression checks for the public-to-private CI feature migration."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UNIFIED = ROOT / ".github/workflows/unified-luna-ng.yml"
PACKAGE = ROOT / ".github/workflows/build-luna-ng.yml"
VALIDATOR = ROOT / "packaging/validate_private.sh"


class UnifiedWorkflowTests(unittest.TestCase):
    def test_private_workflow_is_manual_and_keeps_publishing_separate(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("  workflow_dispatch:", source)
        self.assertIn("  workflow_call:", source)
        self.assertNotIn("  push:", source)
        self.assertNotIn("repository: Roboatlas21/xbmc-p3i", source)
        self.assertNotIn("repository: Roboatlas21/Luna-build", source)
        self.assertNotIn("git push ", source)
        self.assertNotIn("publish: true", source)

    def test_all_validation_groups_run_before_native_dispatch(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("  preflight:", source)
        self.assertIn("  select-native:\n    needs: preflight", source)
        for group in ("source", "host", "vfm", "audio"):
            self.assertIn(f"bash tests/validate_private_source.sh {group}",
                          source)
        for group in ("luna-python", "luna-launch", "luna-packaging"):
            self.assertIn(f"bash packaging/validate_private.sh {group}",
                          source)
        self.assertIn("luna-ng-private-validation-logs", source)
        self.assertIn("LUNA_PRIVATE_CHECKOUT:", source)
        self.assertIn("tests/validate_private_source.sh extras", source)
        self.assertIn("steps.moonlight_extra_tests.outcome", source)
        self.assertGreaterEqual(source.count("continue-on-error: true"), 8)
        self.assertIn("Report all validation groups and block unverified ARM32 builds",
                      source)

    def test_diagnostics_only_never_dispatches_native(self):
        source = UNIFIED.read_text(encoding="utf-8")
        self.assertIn("validate_only:", source)
        self.assertIn("if: ${{ !inputs.validate_only }}", source)

    def test_exact_source_pair_is_checked_and_packaged(self):
        source = UNIFIED.read_text(encoding="utf-8")
        packaged = PACKAGE.read_text(encoding="utf-8")
        self.assertIn("PREFLIGHT_MOONLIGHT_SHA", source)
        self.assertIn('[[ "$sha" == "$PREFLIGHT_MOONLIGHT_SHA" ]]',
                      source)
        self.assertIn("luna_ref: ${{ needs.preflight.outputs.luna_sha }}",
                      source)
        self.assertIn("ref: ${{ inputs.luna_ref || 'feat/vortex-ng' }}",
                      packaged)
        self.assertIn("ref: ${{ steps.native.outputs.sha }}", packaged)
        self.assertIn("expected_native_sha: ${{ needs.select-native.outputs.native_sha }}",
                      source)
        self.assertIn("native_reuse_policy.py", source)
        self.assertIn("steps.select.outputs.native_sha", source)

    def test_dispatch_uses_unique_run_title_not_concurrent_head_sha(self):
        source = UNIFIED.read_text(encoding="utf-8")
        for expected in (
                'correlation="luna-$GITHUB_RUN_ID-$GITHUB_RUN_ATTEMPT"',
                'inputs[dispatch_correlation]="$correlation"',
                '.display_title == $title',
                '[[ "$title" =~ ^CoreELEC21-NG',
                'if artifact_ready "$selected"; then',
                'expected_native_sha: ${{ needs.select-native.outputs.native_sha }}',
                'python3 luna/packaging/native_reuse_policy.py',
                'compatible_source "$built"',
                'require_latest_moonlight: false'):
            self.assertIn(expected, source)
        self.assertNotIn('select_run "$started"', source)
        self.assertNotIn('.head_sha == $sha', source)
        self.assertNotIn('[[ "$commit" == "$sha" ]]', source)
        self.assertNotIn('.created_at >= $since', source)

    def test_pinned_native_provenance_is_checked_again_during_packaging(self):
        source = PACKAGE.read_text(encoding="utf-8")
        for expected in (
                'expected_native_sha:', 'EXPECTED_NATIVE_SHA',
                'run.get("display_title")', 'stamped.group(1) != sha',
                'expected != sha', 'manifest.get("source_git_sha")'):
            self.assertIn(expected, source)
        self.assertNotIn('run["head_branch"] == "feat/coreelec-ng" and run["head_sha"] != sha',
                         source)

    def test_reusable_package_always_runs_regressions(self):
        unified = UNIFIED.read_text(encoding='utf-8')
        package = PACKAGE.read_text(encoding='utf-8')
        self.assertNotIn('preflight_validated:', package)
        self.assertNotIn('preflight_validated:', unified)
        self.assertIn('needs: [preflight, select-native]', unified)
        self.assertIn('Run complete Luna Python, Kodi launcher and watchdog tests', package)
        self.assertIn('bash tests/test_launch.sh', package)

    def test_launcher_expected_exit_codes_do_not_emit_assertion_failure(self):
        import re
        launcher = (ROOT / "tests/test_launch.sh").read_text(encoding="utf-8")
        self.assertIn('LUNA_ASSERTION_FAILURE', launcher)
        self.assertIn('if sh "$launcher" Desktop >"$tmp/out" 2>&1; then', launcher)
        self.assertGreaterEqual(launcher.count(
            'if sh "$launcher" Desktop >"$tmp/out" 2>&1; then'), 10)
        self.assertNotRegex(
            launcher,
            r'(?m)^\s*sh "\$launcher" Desktop >\s*"\$tmp/out" 2>&1\n\s*status=\$\?')
        self.assertIn('[[ "$status" == 42 ]]', launcher)
        self.assertIn('[[ "$status" == 127 ]]', launcher)
        self.assertIn('[[ "$status" == 124 ]]', launcher)

    def test_luna_groups_record_logs_and_failure_counts(self):
        source = VALIDATOR.read_text(encoding="utf-8")
        for group in ("luna-python", "luna-launch", "luna-packaging"):
            self.assertIn(group + ")", source)
        self.assertIn("SOURCE_CHECK_FAIL", source)
        self.assertIn("test_aml_recovery.sh", source)
        self.assertIn("resources/lib/util/resumestate.py", source)
        self.assertIn("resources/lib/util/hdmigamemode.py", source)
        self.assertIn("results.tsv", source)
        self.assertIn("if (( failures )); then", source)


if __name__ == "__main__":
    unittest.main()
