"""Local-only log collection must never upload private diagnostics."""
import importlib.util
import os
from pathlib import Path
import stat
import tempfile
import types
import unittest
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / 'resources/lib/util/diagnosticreport.py'
spec = importlib.util.spec_from_file_location('luna_diagnostics', SCRIPT)
report = importlib.util.module_from_spec(spec)
spec.loader.exec_module(report)


class DiagnosticReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.kodi = self.root / 'kodi.log'
        (self.root / 'logfile').write_text('Luna connecting to https://user:pass@192.168.1.10/?token=abc123\n')
        self.kodi.write_text('password = secretValue\nemail=person@example.com\nMAC aa:bb:cc:dd:ee:ff\n')

    def test_report_is_private_redacted_and_never_uploaded(self):
        with mock.patch.object(report.subprocess, 'run') as run:
            path = report.create_report(
                self.root, self.kodi, kernel_output='GPU error from fe80::aabb:1 and 10.0.0.1\n')
        self.assertFalse(run.called)
        self.assertEqual(path.parent, self.root / 'diagnostics')
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(path.parent.stat().st_mode), 0o700)
        text = path.read_text()
        for protected in ['192.168.1.10', '10.0.0.1', 'fe80::aabb:1', 'abc123',
                          'secretValue', 'person@example.com', 'aa:bb:cc:dd:ee:ff',
                          'https://user:pass', 'paste.coreelec.org']:
            self.assertNotIn(protected, text)
        self.assertIn('LOCAL FILE ONLY', text)
        self.assertIn('Nothing was uploaded', text)
        self.assertIn('Luna session log', text)
        self.assertIn('Kodi log', text)
        self.assertIn('Kernel log', text)
        self.assertIn('have been masked', text)
        self.assertIn('connecting', text)
        self.assertEqual((self.root / 'logfile').read_text(),
                         'Luna connecting to https://user:pass@192.168.1.10/?token=abc123\n')

    def test_two_reports_get_distinct_paths_and_originals_stay_unchanged(self):
        first = report.create_report(self.root, self.kodi, kernel_output='failure 1\n')
        second = report.create_report(self.root, self.kodi, kernel_output='failure 2\n')
        self.assertNotEqual(first, second)
        self.assertIn('failure 1', first.read_text())
        self.assertIn('failure 2', second.read_text())

    def test_malicious_report_directory_symlink_is_refused(self):
        external = self.root / 'external'
        external.mkdir()
        (self.root / 'diagnostics').symlink_to(external, target_is_directory=True)
        with self.assertRaises((OSError, FileExistsError)):
            report.create_report(self.root, self.kodi, kernel_output='hello')
        self.assertEqual(list(external.iterdir()), [])

    def test_symlinked_source_log_not_followed(self):
        secret = self.root / 'secret'
        secret.write_text('secret_should_not_leak=CONFIDENTIAL')
        self.kodi.unlink()
        self.kodi.symlink_to(secret)
        local = report.create_report(self.root, self.kodi, kernel_output='')
        self.assertNotIn('CONFIDENTIAL', local.read_text())
        self.assertIn('not available: log could not be read safely', local.read_text())

    def test_large_logs_are_bounded(self):
        self.kodi.write_text(('line\n' * 1200) + ('end marker\n'))
        local = report.create_report(self.root, self.kodi, kernel_output='')
        self.assertLess(local.stat().st_size, 25000)
        self.assertIn('end marker', local.read_text())

    def test_missing_logs_still_produce_local_report(self):
        (self.root / 'logfile').unlink()
        self.kodi.unlink()
        with mock.patch.object(report.subprocess, 'run', side_effect=OSError('no dmesg')):
            local = report.create_report(self.root, self.kodi)
        self.assertIn('not available', local.read_text())

    def test_bearer_pin_xml_and_pem_redaction(self):
        value = ('Authorization: Bearer supersecret\n'
                 'PIN=1122\n<token>abcPRIVATE</token>\n'
                 '-----BEGIN PRIVATE KEY-----\nsecretblock\n'
                 '-----END PRIVATE KEY-----\n')
        redacted = report.redact(value)
        for secret in ['supersecret', '1122', 'abcPRIVATE', 'secretblock']:
            self.assertNotIn(secret, redacted)
        self.assertIn('[PEM DATA REDACTED]', redacted)

    def test_short_prefixed_credentials_are_scrubbed_in_log_formats(self):
        fixtures = (
            'session_token=abc123\n'
            'api_token: xyz12\n'
            'my_password: nope123\n'
            '"session_token": "json12"\n'
            "'service.auth_token': 'tiny17'\n"
            'SESSION_TOKEN = capital18\n'
            'the_api_key = foo19\n'
            'module.secret = bar20\n'
            'Decoder: dropped 2 frames\n')
        result = report.redact(fixtures)
        for value in ('abc123', 'xyz12', 'nope123', 'json12', 'tiny17',
                      'capital18', 'foo19', 'bar20'):
            self.assertNotIn(value, result)
        self.assertIn('Decoder: dropped 2 frames', result)
        # Export applies a second redaction pass; it must remain safe.
        self.assertEqual(report.redact(result), result)

    def test_multiline_prefixed_xml_credentials_are_scrubbed(self):
        content = (
            '<session_token>\nshortXMLvalue\n</session_token>\n'
            '<ns:api_key method="AUTO">\nscopedXMLvalue\n</ns:api_key>\n'
            '<my_password>passwordXMLvalue</my_password>\n'
            '<system><state>Decoder ready</state></system>\n')
        cleaned = report.redact(content)
        for value in ('shortXMLvalue', 'scopedXMLvalue', 'passwordXMLvalue'):
            self.assertNotIn(value, cleaned)
        self.assertIn('Decoder ready', cleaned)

    def test_short_credentials_do_not_reappear_in_samba_export(self):
        content = (
            'connection to VM failed\n'
            'session_token=short41\n'
            'api_token = short42\n'
            'my_password: short43\n'
            '{"session_token": "short44"}\n'
            '<session_token>\nshort45\n</session_token>\n'
            'Decoder: frame pacing delay 7 ms\n')
        (self.root / 'logfile').write_text(content, encoding='utf-8')
        private = report.create_report(self.root, self.kodi, kernel_output='')
        shared = report.export_report(private, self.root / 'share')
        for body in (private.read_text(encoding='utf-8'),
                     shared.read_text(encoding='utf-8')):
            for word in ('short41', 'short42', 'short43', 'short44', 'short45'):
                self.assertNotIn(word, body)
            self.assertIn('Decoder: frame pacing delay 7 ms', body)
        # Never rewrite raw input logs, even when they contain credentials.
        self.assertEqual((self.root / 'logfile').read_text(encoding='utf-8'),
                         content)

    def test_native_pairing_pin_and_free_text_hostname_are_redacted(self):
        raw = (
            'Please enter the following PIN on the target PC: 8293\n'
            'Connecting to gaming-vm...\n'
            'Paired with desktop-pc.local\n'
            'Sunshine host is gamerbox\n'
            'Peer user@game-pc.local\n'
            'Decoder recovered after timeout\n')
        cleaned = report.redact(raw)
        for sensitive in ('8293', 'gaming-vm', 'desktop-pc.local',
                          'gamerbox', 'user@game-pc.local'):
            self.assertNotIn(sensitive, cleaned)
        self.assertIn('connecting to', cleaned.lower())
        self.assertIn('Decoder recovered after timeout', cleaned)

    def test_smb_export_redacts_plain_language_identifiers(self):
        (self.root / 'logfile').write_text(
            'Please enter the following PIN on the target PC: 3498\n'
            'Connecting to PC-LIVINGROOM...\n'
            'Paired with windows-vm\n'
            'Decoder: dropped 7 frames\n')
        original = report.create_report(self.root, self.kodi, kernel_output='')
        exported = report.export_report(original, self.root / 'shared')
        text = exported.read_text()
        for sensitive in ('3498', 'PC-LIVINGROOM', 'windows-vm'):
            self.assertNotIn(sensitive, text)
        self.assertIn('dropped 7 frames', text)
        self.assertEqual(exported.stat().st_mode & 0o777, 0o644)

    def test_export_is_atomic_readable_redacted_and_preserves_original(self):
        (self.root / 'logfile').write_text(
            'Authorization: Bearer OPENKEY\n'
            'Cookie: session=otherkey\n'
            'Host=private-machine\n'
            'secret location /storage/.kodi/userdata/passwords.xml\n'
            'User at C:\\Users\\Private\\myfile.txt\n'
            'Source \\\\NAS\\Movies\\Private.mkv\n'
            'opaque 0123456789abcdef0123456789abcdef0123456789abcdef\n'
            'Video decoder: frame ready\n')
        private = report.create_report(self.root, self.kodi, kernel_output='warning')
        share_root = self.root / 'samba-logfiles'
        exported = report.export_report(private, share_root)
        self.assertEqual(exported.parent, share_root / 'Luna')
        self.assertEqual(exported.name, private.name)
        self.assertEqual(stat.S_IMODE(exported.stat().st_mode), 0o644)
        self.assertEqual(stat.S_IMODE(exported.parent.stat().st_mode), 0o755)
        self.assertEqual(stat.S_IMODE(private.stat().st_mode), 0o600)
        text = exported.read_text()
        for value in ('OPENKEY', 'otherkey', 'private-machine', 'passwords.xml',
                      'C:\\Users\\Private', '\\\\NAS\\Movies', 
                      '0123456789abcdef0123456789abcdef0123456789abcdef'):
            self.assertNotIn(value, text)
        self.assertIn('Video decoder: frame ready', text)
        self.assertIn('Nothing was uploaded', text)
        self.assertTrue(private.exists())

    def test_export_rejects_symlink_folder_and_refuses_overwrite(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        outside = self.root / 'outside'
        outside.mkdir()
        share = self.root / 'share'
        share.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(OSError):
            report.export_report(private, share)
        self.assertFalse(list(outside.iterdir()))
        share.unlink()
        exported = report.export_report(private, share)
        before = exported.read_bytes()
        with self.assertRaises(FileExistsError):
            report.export_report(private, share)
        self.assertEqual(before, exported.read_bytes())

    def test_export_rejects_arbitrary_source_and_does_not_publish(self):
        plain = self.root / 'luna-diagnostics-unknown.txt'
        plain.write_text('PRIVATE RAW FILE')
        shared = self.root / 'share'
        with self.assertRaises(OSError):
            report.export_report(plain, shared)
        self.assertFalse((shared / 'Luna' / plain.name).exists())

    def test_export_confirmation_has_no_review_prompt_or_upload(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        shared = report.export_report(private, self.root / 'share')
        dialog = mock.Mock()
        import sys
        with mock.patch.dict(
                sys.modules, {'xbmcgui': types.SimpleNamespace(Dialog=lambda: dialog)}):
            report.show_in_kodi(shared)
        dialog.ok.assert_called_once()
        dialog.yesno.assert_not_called()
        dialog.textviewer.assert_not_called()
        self.assertIn('Saved redacted', dialog.ok.call_args.args[1])
        self.assertIn('CoreELEC', dialog.ok.call_args.args[1])

    def test_export_directory_swap_before_open_is_rejected(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        share = self.root / 'share'
        outside = self.root / 'outside'
        outside.mkdir()
        real_open = os.open
        swapped = [False]

        def replace_before_open(path, flags, *args, **kwargs):
            if path == 'Luna' and kwargs.get('dir_fd') is not None:
                (share / 'Luna').rename(share / 'Luna-original')
                (share / 'Luna').symlink_to(outside, target_is_directory=True)
                swapped[0] = True
            return real_open(path, flags, *args, **kwargs)

        with mock.patch.object(report.os, 'open', side_effect=replace_before_open):
            with self.assertRaises(OSError):
                report.export_report(private, share)
        self.assertTrue(swapped[0])
        self.assertEqual(list(outside.iterdir()), [])
        self.assertTrue(private.exists())

    def test_export_directory_swap_during_link_uses_open_fd(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        share = self.root / 'share'
        outside = self.root / 'outside'
        outside.mkdir()
        real_link = os.link
        swapped = [False]

        def replace_during_link(src, dst, *args, **kwargs):
            (share / 'Luna').rename(share / 'Luna-original')
            (share / 'Luna').symlink_to(outside, target_is_directory=True)
            swapped[0] = True
            return real_link(src, dst, *args, **kwargs)

        with mock.patch.object(report.os, 'link', side_effect=replace_during_link):
            with self.assertRaisesRegex(OSError, 'directory changed'):
                report.export_report(private, share)
        self.assertTrue(swapped[0])
        self.assertEqual(list(outside.iterdir()), [])
        anchored = share / 'Luna-original' / private.name
        self.assertTrue(anchored.exists())
        self.assertIn('LOCAL FILE ONLY', anchored.read_text())
        self.assertTrue(private.exists())

    def test_export_rejects_symlinked_ancestor(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        outside = self.root / 'outside'
        outside.mkdir()
        shortcut = self.root / 'shortcut'
        shortcut.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(OSError):
            report.export_report(private, shortcut / 'share')
        self.assertEqual(list(outside.iterdir()), [])

    def test_export_read_only_or_permission_error_preserves_private_report(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        original = private.read_bytes()
        share = self.root / 'share'
        real_mkdir = os.mkdir

        def fail_directory_creation(path, *args, **kwargs):
            if path == 'Luna' and kwargs.get('dir_fd') is not None:
                raise OSError(30, 'Read-only filesystem')
            return real_mkdir(path, *args, **kwargs)

        with mock.patch.object(report.os, 'mkdir', side_effect=fail_directory_creation):
            with self.assertRaises(OSError):
                report.export_report(private, share)
        self.assertEqual(private.read_bytes(), original)
        self.assertFalse((share / 'Luna').exists())

    def test_export_failed_link_cleans_unpublished_temporary(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        original = private.read_bytes()
        share = self.root / 'share'
        with mock.patch.object(report.os, 'link',
                               side_effect=PermissionError('Access denied')):
            with self.assertRaises(PermissionError):
                report.export_report(private, share)
        self.assertEqual(list((share / 'Luna').iterdir()), [])
        self.assertEqual(private.read_bytes(), original)

    def test_export_rejects_changed_report_inode_after_hardlink(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        original = private.read_bytes()
        share = self.root / 'share'
        real_link = os.link

        def replace_target_after_link(src, dst, *args, **kwargs):
            result = real_link(src, dst, *args, **kwargs)
            target = share / 'Luna' / dst
            target.unlink()
            target.write_text('an unrelated replacement file')
            return result

        with mock.patch.object(report.os, 'link',
                               side_effect=replace_target_after_link):
            with self.assertRaisesRegex(OSError, 'destination changed'):
                report.export_report(private, share)
        self.assertEqual(private.read_bytes(), original)

    def test_export_rejects_share_root_swap_after_hardlink(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        share = self.root / 'share'
        outside = self.root / 'outside'
        outside.mkdir()
        real_link = os.link

        def replace_share_after_link(src, dst, *args, **kwargs):
            result = real_link(src, dst, *args, **kwargs)
            share.rename(self.root / 'share-original')
            share.symlink_to(outside, target_is_directory=True)
            return result

        with mock.patch.object(report.os, 'link',
                               side_effect=replace_share_after_link):
            with self.assertRaises(OSError):
                report.export_report(private, share)
        self.assertEqual(list(outside.iterdir()), [])
        self.assertTrue((self.root / 'share-original' / 'Luna' / private.name).exists())
        self.assertTrue(private.exists())

    def test_shared_report_handler_preserves_created_private_file(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        dialog = mock.Mock()
        import sys
        with mock.patch.dict(sys.modules, {
                'xbmcgui': types.SimpleNamespace(Dialog=lambda: dialog)}), \
             mock.patch.object(report, 'create_report', return_value=private), \
             mock.patch.object(report, 'export_report',
                               side_effect=OSError('Read-only SMB share')), \
             mock.patch.object(report, 'show_in_kodi') as show:
            errors = []
            self.assertFalse(report.save_report_with_dialog(
                self.root, self.kodi, log_failure=errors.append))
        self.assertEqual(errors, ['OSError'])
        self.assertTrue(private.exists())
        self.assertIn(str(private), dialog.ok.call_args.args[1])
        self.assertIn('Private redacted report saved to:',
                      dialog.ok.call_args.args[1])
        show.assert_not_called()

    def test_shared_report_handler_reports_private_creation_error(self):
        dialog = mock.Mock()
        import sys
        with mock.patch.dict(sys.modules, {
                'xbmcgui': types.SimpleNamespace(Dialog=lambda: dialog)}), \
             mock.patch.object(report, 'create_report',
                               side_effect=PermissionError('Private storage denied')), \
             mock.patch.object(report, 'export_report') as exported:
            self.assertFalse(report.save_report_with_dialog(self.root, self.kodi))
        exported.assert_not_called()
        self.assertIn('Could not create the private diagnostic report',
                      dialog.ok.call_args.args[1])
        self.assertNotIn('Private redacted report saved to:',
                         dialog.ok.call_args.args[1])

    def test_shared_report_handler_confirms_success(self):
        private = report.create_report(self.root, self.kodi, kernel_output='')
        exported = self.root / 'share' / 'Luna' / private.name
        with mock.patch.object(report, 'create_report', return_value=private), \
             mock.patch.object(report, 'export_report', return_value=exported), \
             mock.patch.object(report, 'show_in_kodi') as show:
            self.assertTrue(report.save_report_with_dialog(self.root, self.kodi))
        show.assert_called_once_with(exported)


if __name__ == '__main__':
    unittest.main()
