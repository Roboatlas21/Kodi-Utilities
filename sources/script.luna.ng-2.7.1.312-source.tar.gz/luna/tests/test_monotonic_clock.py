"""Boot-relative elapsed clocks survive NTP/manual wall-clock adjustments."""
import os
from pathlib import Path
import re
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CLOCK = ROOT / 'resources/launchscripts/coreelec/clock.sh'
LAUNCHER = ROOT / 'resources/launchscripts/coreelec/launch.sh'
WATCHDOG = ROOT / 'resources/launchscripts/coreelec/kodi-watchdog.sh'


class MonotonicClockTests(unittest.TestCase):
    def shell(self, expression, env=None):
        script = '. "$1"; ' + expression
        return subprocess.run(['sh', '-c', script, 'test-clock', str(CLOCK)],
                              text=True, capture_output=True, env=env)

    def test_uptime_stamp_matches_proc_uptime(self):
        result = self.shell('luna_duration_stamp')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertRegex(result.stdout.strip(), r'^mono:[0-9]+$')
        now = int(float(Path('/proc/uptime').read_text().split()[0]))
        self.assertLessEqual(abs(int(result.stdout.strip().split(':')[1]) - now), 2)

    def test_ntp_forward_and_backward_jumps_do_not_change_elapsed(self):
        with tempfile.TemporaryDirectory() as directory:
            bindir = Path(directory)
            fake_date = bindir / 'date'
            env = dict(os.environ, PATH=str(bindir) + ':' + os.environ.get('PATH', ''))
            for wallclock in ('1', '9999999999'):
                with self.subTest(wallclock=wallclock):
                    fake_date.write_text('#!/bin/sh\nprintf "%s\n" ' + wallclock + '\n')
                    fake_date.chmod(0o755)
                    result = self.shell(
                        'luna_monotonic_seconds() { printf "200\n"; }; '
                        'luna_elapsed_since mono:185', env)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(result.stdout.strip(), '15')

    def test_previous_epoch_stamps_remain_readable_once(self):
        result = self.shell('luna_elapsed_since 1')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertGreater(int(result.stdout.strip()), 0)

    def test_invalid_and_future_monotonic_stamps_refuse_recovery_elapsed(self):
        for stamp in ('mono:', 'mono:corrupt', 'mono:-1', 'mono:9999999999999'):
            with self.subTest(stamp=stamp):
                result = self.shell('luna_monotonic_seconds() { echo 100; }; '
                                    f'luna_elapsed_since "{stamp}"')
                self.assertNotEqual(result.returncode, 0)

    def test_launcher_and_watchdog_both_use_shared_monotonic_clock(self):
        launch, watchdog = LAUNCHER.read_text(), WATCHDOG.read_text()
        for source in (launch, watchdog):
            self.assertIn('. "$scripts/clock.sh"', source)
        self.assertEqual(launch.count('luna_duration_stamp > "$session.startup"'), 2)
        self.assertIn('luna_duration_stamp > "$session.cleanup"', launch)
        self.assertIn('luna_elapsed_since "$started"', watchdog)
        self.assertIn('recovery_started="$(luna_monotonic_seconds)"', watchdog)
        self.assertNotIn('date +%s', watchdog)


if __name__ == '__main__':
    unittest.main()
