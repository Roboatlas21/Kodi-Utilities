# Experimental automatic HDMI display-mode matching (CoreELEC NG)

Enable **Match HDMI resolution and refresh rate (experimental)** in Luna
Advanced settings. This is **OFF by default**, separate from HDMI ALLM Game
Mode and CPU thread-priority options.

With a validated immutable Moonlight stream configuration, Luna's detached
session process:

1. Arms its independent Kodi recovery watchdog and confirms Kodi's display
   ownership is released.
2. Reads `/sys/class/display/mode` and the connected display's advertised
   modes at `/sys/class/amhdmitx/amhdmitx0/disp_cap`.
3. If an exact stream-resolution / FPS mode is supported, durably saves the
   current mode to `.luna-session.XXXXXXXX.displaymode-state` **before** any
   write. It then writes the chosen mode and confirms the readback.
4. Starts Moonlight. On exit, it restores the old mode **before** restoring
   ALLM content hints and restarting Kodi. The separate watchdog performs
   the same rollback after an unexpected session failure.

Only 720p, 1080p, 3840x2160 (2160p), and 4096x2160 (smpte) combinations
with explicitly advertised rates can be selected. UHD 4:2:0 may be used
only if no matching non-420 mode is advertised.

**No silent fallback:** when the TV does not advertise an exact supported
mode (or the mode/capabilities cannot be verified), Luna displays a
blocking error before stopping Kodi, and leaves existing playback
untouched. The detached launcher rechecks immediately before applying
a mode and aborts streaming if the HDMI environment changed.

This does **not** force arbitrary frequencies, change the desktop host
resolution, alter fbdev/decoder geometry, or modify EDID. Modesets may
briefly blank the TV.

The recovery helper does not follow state-file symlinks or use a journal's
path without checking the trusted output path passed by Luna. It will not
overwrite a third-party mode change; malformed or failed recovery retains
an armed journal. After a reboot, Luna retires stale HDMI *mode* snapshots
without applying them to a potentially different TV/EDID.

## Hardware validation on the Ugoos AM6B+

1. With 4K60 enabled in Moonlight and the TV's 2160p60 EDID mode present,
   begin a session from a different original Kodi HDMI mode. Verify actual
   HDMI output with `cat /sys/class/display/mode`.
2. End normally; confirm Kodi and the exact original HDMI mode return.
3. Test Moonlight disconnect, failed first-video startup, and abnormal
   launcher termination; confirm the independent watchdog restores the mode.
4. Test a 4K mode *not* advertised by the TV. Confirm Luna shows a
   clear error before stopping Kodi, leaves existing playback running,
   and never switches to a lower-resolution or incorrect-refresh mode.
5. Test with HDR/ALLM and the optional graphics OSD separately; modesetting
   can affect HDMI colour and fb0 overlay behavior on CoreELEC NG.

There is no substitute for on-device testing. Do not enable by default
until the HDMI handoff and framebuffer/OSD restoration have been verified.
