# Per-application streaming profiles (CoreELEC NG)

Luna can remember stream resolution and frame rate **per Sunshine/Apollo host
and exact numeric application ID**. Different applications can therefore use
different resolutions without changing Luna's global settings.

Choose **Applications → highlight an app → context menu → Streaming profile…**
and select:

| Profile | Moonlight stream |
| --- | --- |
| Use Luna default settings | Whatever is set in Luna Settings → Streaming |
| Quality (4K60) | 3840×2160, 60 FPS |
| Performance (1080p120) | 1920×1080, 120 FPS |

The names are presentation-only. Existing saved per-app assignments with the
internal IDs `desktop_4k60` and `gaming_1080p120` remain valid, so no
migration or reset is required.

**The choices are explicit.** Luna does not guess whether an application is a
game or a desktop from its name. Set the profile once; subsequent launches and
Resume use the saved selection for that same app on that same host. Switching
Sunshine hosts or launching another app ID does not reuse the wrong profile.
Names can be duplicated or renamed without changing the saved selection.

## Where it is stored

The profile map is written in the Kodi user data directory:
special://profile/addon_data/script.luna.ng/stream-profiles.json

The JSON file is atomically replaced under a stable lock with user-only
permissions. A malformed existing file is **not** overwritten. Choosing
Use Luna default settings removes only that application's override; all
other app/host assignments remain intact.

## Streaming and HDMI modes

For each launch, Luna first resolves the final target ID (including Resume,
name-based selection and the option to join an already-running application).
It then produces an independent immutable Moonlight config snapshot with
that application's saved **width, height, and FPS**. All other settings,
including controller inputs, codec, HDR, audio and bitrate, remain identical
to the Luna global configuration.

If automatic HDMI mode matching is enabled, its Kodi-side check and the
detached launcher's second check operate on the **effective per-app snapshot**.
An unsupported exact HDMI mode is an error before Kodi is stopped, rather than
a silent fallback. After the session Luna restores the original HDMI mode.

**Important:** These settings change the Moonlight client's requested stream
parameters and the local HDMI output. Sunshine/Apollo's host display also
needs to be configured for the intended resolution and refresh rate if
host-side resolution switching is desired. The profile selection does not
guarantee that a connected decoder can sustainably process 1080p at 120 FPS.

Existing stored global Luna options, moonlight.conf, and the cached application
list are not rewritten when a per-app profile is selected.

## Testing

- Save Game A as Performance (1080p120) and Desktop as Quality (4K60).
- Launch Game A twice, then Resume it; confirm the effective stream is 1080p120.
- Launch Desktop; confirm 4K60.
- Set a third app to Use Luna defaults; confirm global resolution and FPS.
- Rename two apps to the same title with different app IDs; confirm separation.
- Change Sunshine host; confirm its apps retain only that host's profiles.
- Enable HDMI matching, test the two exact TV-advertised modes and confirm
  original Kodi mode is restored on both clean exit and watchdog recovery.

Do not use an unverified HDMI mode to bypass the mode-matching check.
