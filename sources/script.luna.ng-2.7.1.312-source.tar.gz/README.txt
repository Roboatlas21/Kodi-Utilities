Luna NG version: 2.7.1.312
Luna commit: 60f70c39ee608e49b16bc3bcf4a51d51a9075f43
Moonlight native commit: 40f80d58e8d116865646ca59ec56fb1ec6b950fb
Moonlight native run: 41482592164
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
