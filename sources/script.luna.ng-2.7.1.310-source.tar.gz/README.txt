Luna NG version: 2.7.1.310
Luna commit: 25141d5abf828db15adeacd89c75c0270f0f7fd5
Moonlight native commit: 2f808ad267a1c1eb0ba100016a97bbcd405fc426
Moonlight native run: 41378012908
VFM: true
CoreELEC native recipe and dependency pins: moonlight-embedded/packaging/coreelec-ng/
