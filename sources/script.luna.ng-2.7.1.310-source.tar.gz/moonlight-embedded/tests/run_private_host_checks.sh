#!/usr/bin/env bash
# Run the recent private-branch regression checks locally before ARM32 builds.
# This script neither invokes nor changes any GitHub Actions workflows.
set -uo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root" || exit 1
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# Retain per-check logs while continuing through independent failures.
log_dir="${SOURCE_VALIDATION_LOG_DIR:-${RUNNER_TEMP:-/tmp}/source-validation}"
mkdir -p "$log_dir" || exit 1
printf 'check\tresult\texit_code\tlog\n' > "$log_dir/host-results.tsv"
checks=0
failures=0
run_checked() {
  local label="$1" safe log result=0
  shift
  checks=$((checks + 1))
  safe="${label//[^a-zA-Z0-9_.-]/_}"
  printf -v log '%s/%03d-%s.log' "$log_dir" "$checks" "$safe"
  printf '::group::Moonlight host / %s\n' "$label"
  "$@" 2>&1 | tee "$log"
  local -a statuses=( "${PIPESTATUS[@]}" )
  if (( statuses[0] != 0 )); then result="${statuses[0]}"; fi
  if (( result == 0 && statuses[1] != 0 )); then result="${statuses[1]}"; fi
  printf '::endgroup::\n'
  if (( result != 0 )); then
    failures=$((failures + 1))
    printf 'SOURCE_CHECK_FAIL check=%s code=%d log=%s\n' "$label" "$result" "$log" >&2
    printf '%s\tFAIL\t%d\t%s\n' "$label" "$result" "$log" >> "$log_dir/host-results.tsv"
  else
    printf 'SOURCE_CHECK_PASS check=%s\n' "$label"
    printf '%s\tPASS\t0\t%s\n' "$label" "$log" >> "$log_dir/host-results.tsv"
  fi
  return 0
}

for name in \
  test_aml_guard_order.py \
  test_aml_startup_stall.py \
  test_video_readiness_wiring.py \
  test_alsa_rate_guard.py \
  test_evdev_axis_geometry.py \
  test_evdev_sync.py \
  test_evdev_device_isolation.py \
  test_evdev_release_inputs.py \
  test_evdev_quit_scope.py \
  test_evdev_drain_budget.py \
  test_dualsense_touch_detach.py \
  test_dualsense_output_recovery.py \
  test_dualsense_write_retry.py \
  test_dualsense_cleanup_reaper.py \
  test_udev_retry_budget.py \
  test_steam_wake_budget.py \
  test_controller_mapping_wizard.py \
  test_stream_failure_exit.py \
  test_config_lookup_safety.py \
  test_native_config_sections.py \
  test_native_dependency_key.py \
  test_private_native_workflow.py \
  test_gamestream_url_wiring.py \
  test_hdr_config.py \
  test_source_config_guard.py \
  test_udev_errors.py \
  test_native_input_safety.py \
  test_steam_launch_count.py \
  test_vfm_setup_guard.py \
  test_controller_registration.py \
  test_evdev_fd_dedup.py \
  test_osd_first_commit.py \
  test_evdev_mapping_failure.py \
  test_unique_id_persistence.py \
  test_pairing_exchange.py \
  test_session_config_precedence.py \
  test_private_credentials.py \
  test_client_identity_permissions.py \
  test_certificate_hex.py \
  test_app_id_aml_probe.py \
  test_vfm_package_source_lock.py \
  test_vfm_real_cross_repo.py \
  test_network_debug_overlay.py
do
  run_checked "unit-$name" python3 -m unittest discover -s tests -p "$name" -v
done

run_checked "compile-test-controller-mapping" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_controller_mapping_roundtrip.c src/input/mapping.c \
   -o "$tmp/test-controller-mapping"
run_checked "execute-test-controller-mapping" "$tmp/test-controller-mapping"

run_checked "compile-test-mapping-capture" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_mapping_capture.c -o "$tmp/test-mapping-capture"
run_checked "execute-test-mapping-capture" "$tmp/test-mapping-capture"

run_checked "compile-test-motion-math" cc -std=gnu99 -Wall -Wextra -Werror \
   -fsanitize=undefined -fno-sanitize-recover=undefined \
   tests/test_motion_math.c -o "$tmp/test-motion-math"
run_checked "execute-test-motion-math" "$tmp/test-motion-math"

run_checked "compile-test-osd-ownership" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_osd_plane_ownership.c -o "$tmp/test-osd-ownership"
run_checked "execute-test-osd-ownership" "$tmp/test-osd-ownership"

run_checked "compile-test-mapping-usable" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_mapping_usable.c -o "$tmp/test-mapping-usable"
run_checked "execute-test-mapping-usable" "$tmp/test-mapping-usable"

run_checked "compile-test-aml-pacing" cc -std=gnu99 -Wall -Wextra -Werror -pedantic \
   tests/test_aml_pacing.c -o "$tmp/test-aml-pacing"
run_checked "execute-test-aml-pacing" "$tmp/test-aml-pacing"

run_checked "test_aml_pacing_modes.py" python3 -m unittest discover -s tests -p 'test_aml_pacing_modes.py' -v

run_checked "compile-test-aml-pacing-fault" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_aml_pacing_fault.c -o "$tmp/test-aml-pacing-fault"
run_checked "execute-test-aml-pacing-fault" "$tmp/test-aml-pacing-fault"

run_checked "compile-test-alsa-rate" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_alsa_rate.c -o "$tmp/test-alsa-rate"
run_checked "execute-test-alsa-rate" "$tmp/test-alsa-rate"

run_checked "compile-test-config-numeric" cc -std=gnu99 -Wall -Wextra -Werror \
   -fsanitize=undefined -fno-sanitize-recover=undefined \
   tests/test_config_numeric.c -o "$tmp/test-config-numeric"
run_checked "execute-test-config-numeric" "$tmp/test-config-numeric"

run_checked "compile-test-serverinfo-numeric" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_serverinfo_numeric.c -o "$tmp/test-serverinfo-numeric"
run_checked "execute-test-serverinfo-numeric" "$tmp/test-serverinfo-numeric"

run_checked "compile-test-mouse-deadzone" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_mouse_deadzone.c -o "$tmp/test-mouse-deadzone"
run_checked "execute-test-mouse-deadzone" "$tmp/test-mouse-deadzone"

run_checked "compile-test-server-https-port" cc -std=gnu99 -Wall -Wextra -Werror \
   -fsanitize=undefined -fno-sanitize-recover=undefined \
   tests/test_server_https_port.c -o "$tmp/test-server-https-port"
run_checked "execute-test-server-https-port" "$tmp/test-server-https-port"

run_checked "compile-test-selected-names" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_selected_names.c -o "$tmp/test-selected-names"
run_checked "execute-test-selected-names" "$tmp/test-selected-names"

run_checked "compile-test-controller-count" cc -std=gnu99 -Wall -Wextra -Werror -pedantic \
   tests/test_controller_count.c -o "$tmp/test-controller-count"
run_checked "execute-test-controller-count" "$tmp/test-controller-count"

run_checked "compile-test-steam-initial-slots" cc -std=gnu99 -Wall -Wextra -Werror -pedantic \
  tests/test_steam_initial_slots.c -o "$tmp/test-steam-initial-slots"
run_checked "execute-test-steam-initial-slots" "$tmp/test-steam-initial-slots"

# Exercise actual native Steam queue and haptic codecs without HID hardware.
for source in test_steam_controller_2026_codec test_steam_controller_2026_fallback test_steam_output_queue; do
  run_checked "compile-$source" cc -std=c99 -Wall -Wextra -Werror -pedantic \
    -Ithird_party/moonlight-common-c/src "tests/$source.c" -o "$tmp/$source"
  run_checked "execute-$source" "$tmp/$source"
done
run_checked "test_controller_rumble_wiring.py" python3 -m unittest discover -s tests -p 'test_controller_rumble_wiring.py' -v
run_checked "test_steam_controller_2026_integration.py" python3 tests/test_steam_controller_2026_integration.py
run_checked "test_steam_failure_race.py" python3 -m unittest discover -s tests -p test_steam_failure_race.py -v
run_checked "test_alsa_error_logging.py" python3 -m unittest discover -s tests -p test_alsa_error_logging.py -v
run_checked "test_server_pin_file_safety.py" python3 -m unittest discover -s tests -p test_server_pin_file_safety.py -v
for name in test_config_section test_config_ini test_input_limits test_url_host; do
  run_checked "compile-$name" cc -std=gnu99 -Wall -Wextra -Werror -pedantic \
     "tests/$name.c" -o "$tmp/$name"
  run_checked "execute-$name" "$tmp/$name"
done
run_checked "compile-test-host-config-path" cc -std=gnu99 -Wall -Wextra -Werror -pedantic \
   tests/test_host_config_path.c src/host_config_path.c \
   -o "$tmp/test-host-config-path"
run_checked "execute-test-host-config-path" "$tmp/test-host-config-path"

run_checked "compile-test-applist-ids" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_applist_ids.c -o "$tmp/test-applist-ids"
run_checked "execute-test-applist-ids" "$tmp/test-applist-ids"

run_checked "compile-test-loop" cc -std=gnu99 -Wall -Wextra -Werror -pthread \
   -Ithird_party/moonlight-common-c/src \
   tests/test_loop_dispatch.c -o "$tmp/test-loop"
run_checked "execute-test-loop" "$tmp/test-loop"

run_checked "compile-test-aml-units" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_aml_decode_unit_validate.c -o "$tmp/test-aml-units"
run_checked "execute-test-aml-units" "$tmp/test-aml-units"

run_checked "compile-test-vfm-progress" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_vfm_progress.c -o "$tmp/test-vfm-progress"
run_checked "execute-test-vfm-progress" "$tmp/test-vfm-progress"

# New safety paths use only libc and the checked-out native source. These
# tests do not need the ARM32 toolchain, FFmpeg or an attached CoreELEC box.
for source in test_first_video_ready test_aml_write_watchdog test_vfm_ioctl_watchdog test_util_write_bool; do
  if [ "$source" = test_util_write_bool ]; then
    run_checked "compile-$source" cc -std=gnu99 -Wall -Wextra -Werror "tests/$source.c" src/util.c -o "$tmp/$source"
  else
    run_checked "compile-$source" cc -std=gnu99 -Wall -Wextra -Werror "tests/$source.c" -o "$tmp/$source"
  fi
  run_checked "execute-$source" "$tmp/$source"
done

run_checked "test_latency_priority_wiring.py" python3 -m unittest discover -s tests -p 'test_latency_priority_wiring.py' -v
run_checked "compile-test-latency-priority" cc -std=gnu99 -Wall -Wextra -Werror -pedantic -pthread \
   -fsanitize=undefined -fno-sanitize-recover=undefined \
   tests/test_latency_priority.c src/video/latency_priority.c \
   -Wl,--wrap=getpriority,--wrap=setpriority -o "$tmp/test-latency-priority"
run_checked "execute-test-latency-priority" "$tmp/test-latency-priority"

run_checked "test_native_xml-sh" bash tests/test_native_xml.sh

# Compile the real GameStream client functions with in-memory HTTP and the
# actual XML parser. This catches missing status/required response regressions.
run_checked "compile-test-gamestream-protocol" cc -std=gnu99 -Wall -Wextra -Werror -Wno-unused-parameter \
   -Wno-deprecated-declarations \
   -ffunction-sections -fdata-sections \
   -fsanitize=address,undefined -fno-omit-frame-pointer \
   -Ithird_party/moonlight-common-c/src -Ilibgamestream \
   tests/test_gamestream_protocol.c libgamestream/xml.c \
   -Wl,--gc-sections -lcrypto -lssl -lexpat -l:libuuid.so.1 \
   -o "$tmp/test-gamestream-protocol"
run_checked "execute-test-gamestream-protocol" env ASAN_OPTIONS=detect_leaks=1 "$tmp/test-gamestream-protocol"

run_checked "compile-test-net-debug" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_net_rx_debug.c src/osd/net_rx_log.c \
   -o "$tmp/test-net-debug"
run_checked "execute-test-net-debug" "$tmp/test-net-debug"

run_checked "compile-test-log-budget" cc -std=gnu99 -Wall -Wextra -Werror \
   tests/test_osd_log_budget.c -o "$tmp/test-log-budget"
run_checked "execute-test-log-budget" "$tmp/test-log-budget"

run_checked "test_network_packet_pipeline-sh" bash tests/test_network_packet_pipeline.sh

# DualSense Bluetooth HID fault injection and tail-zero-padding are pure C
# host tests; neither opens /dev/hidraw nor calls a GitHub workflow.
for source in test_dualsense_pcm_packets test_saxense_hid_write; do
  run_checked "compile-$source" cc -std=c11 -Wall -Wextra -Werror -pedantic "tests/$source.c" -o "$tmp/$source"
  run_checked "execute-$source" "$tmp/$source"
done

printf '\nSOURCE_VALIDATION_SUMMARY group=moonlight-host total=%d failed=%d\n' "$checks" "$failures"
if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    printf '### Moonlight host regression checks\n\n'
    printf '| Check | Result | Exit code |\n| --- | --- | --- |\n'
    tab=$(printf '\t')
    while IFS="$tab" read -r label result status log; do
      [[ "$label" == check ]] && continue
      printf '| %s | %s | %s |\n' "$label" "$result" "$status"
    done < "$log_dir/host-results.tsv"
    printf '\nTotal: %d checks; %d failed. Individual logs are uploaded in the validation artifact.\n' "$checks" "$failures"
  } >> "$GITHUB_STEP_SUMMARY"
fi
if (( failures != 0 )); then
  printf '::error::%d of %d private host checks failed; ARM32 compilation is blocked.\n' "$failures" "$checks" >&2
  exit 1
fi
echo "PASS: private host regressions (full ARM32 build still required)"
