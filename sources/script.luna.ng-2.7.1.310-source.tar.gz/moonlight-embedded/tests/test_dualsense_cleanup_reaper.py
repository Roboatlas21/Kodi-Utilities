"""Check that failed DualSense teardown cannot join ALSA on the input loop."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


def section(code, start, end):
    i = code.index(start)
    return code[i:code.index(end, i + len(start))]


class DeferredDualSenseCleanupTests(unittest.TestCase):
    def test_retirement_and_alsa_worker_have_separate_ownership(self):
        code = (ROOT / "src/input/dualsense.c").read_text()
        worker = section(code, "static void *dualsense_cleanup_worker(",
                         "static bool dualsense_cleanup_start(")
        detach = code[code.index("void dualsense_detach("):]
        self.assertIn("ml_ds_audio_close(d->audio);", worker)
        self.assertIn("free(d);", worker)
        self.assertIn("pthread_cond_signal(&bridge_cleanup.wake);", detach)
        self.assertIn("dualsense_release_touches(d);", detach)
        self.assertIn("loop_remove_fd(d->fd);", detach)
        self.assertNotIn("ml_ds_audio_close(", detach)
        self.assertNotIn("pthread_join(", detach)
        self.assertNotIn("free(d);", detach)

    def test_reconnect_waits_for_cleanup_and_shutdown_is_bounded(self):
        evdev = (ROOT / "src/input/evdev.c").read_text()
        ds = (ROOT / "src/input/dualsense.c").read_text()
        repair = section(evdev, "bool evdev_retry_dualsense_bridges(void) {",
                         "void evdev_start()")
        stop = section(evdev, "void evdev_stop() {", "void evdev_init(")
        bounded = section(ds, "void dualsense_cleanup_shutdown(void) {",
                          "static void dualsense_release_touches(")
        self.assertLess(repair.index("dualsense_cleanup_pending()"),
                        repair.index("dualsense_attach("))
        self.assertIn("dualsense_detach(old);", repair)
        self.assertIn("dualsense_cleanup_shutdown();", stop)
        self.assertIn("pthread_timedjoin_np(", bounded)
        self.assertIn("pthread_detach(", bounded)
        self.assertNotIn("pthread_join(", bounded)
        self.assertIn("deadline.tv_nsec += 250000000L", bounded)

    def test_queue_output_uses_atomic_online_state(self):
        code = (ROOT / "src/input/evdev.c").read_text()
        self.assertGreaterEqual(code.count(
            "__atomic_load_n(&dualsense_output_online, __ATOMIC_ACQUIRE)"), 2)
        self.assertIn("__atomic_store_n(&dualsense_output_online, true, __ATOMIC_RELEASE)", code)
        self.assertIn("__atomic_store_n(&dualsense_output_online, false, __ATOMIC_RELEASE)", code)
        self.assertNotIn("dualsense_output_online = true;", code)
        self.assertNotIn("dualsense_output_online = false;", code)


if __name__ == "__main__":
    unittest.main()
