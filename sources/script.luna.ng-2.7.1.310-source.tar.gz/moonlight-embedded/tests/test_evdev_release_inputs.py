"""Compile the real detach path and verify host releases and slot isolation."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class NativeHeldInputReleaseTests(unittest.TestCase):
    def test_detach_releases_keyboard_mouse_gamepad_without_touching_other_slot(self):
        source = (ROOT / "src/input/evdev.c").read_text()
        begin = source.index("static int evdev_mouse_button_index(")
        end = source.index("/* Out-of-range or malformed axis geometry", begin)
        native = source[begin:end]
        harness = r'''
#define _GNU_SOURCE
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#define MAX_GAMEPADS 16
#define KEY_ACTION_UP 0
#define BUTTON_ACTION_PRESS 1
#define BUTTON_ACTION_RELEASE 0
#define BUTTON_LEFT 1
#define BUTTON_MIDDLE 2
#define BUTTON_RIGHT 3
#define BUTTON_X1 4
#define BUTTON_X2 5
typedef void moonlight_dualsense;
struct input_device {
  void *dev;
  int fd;
  short controllerId;
  bool is_gamepad, mouseEmulation;
  pthread_t meThread;
  void *dualsense;
  int haptic_effect_id;
  pthread_mutex_t ff_mutex;
  unsigned ff_refs;
  bool ff_retired;
  bool ff_cleanup_done;
  unsigned char held_keys[(KEY_CNT + 7) / 8];
  bool held_mouse_buttons[5];
};
static struct input_device *devices[2];
static int numDevices = 2;
static int assignedControllerIds = 3;
static bool gamepad_capacity_warned;
static int evdev_gamepads = 2;
static pthread_mutex_t devices_mutex = PTHREAD_MUTEX_INITIALIZER;
static short keyCodes[KEY_CNT] = {[30] = 0x1e};
static int up_keys, up_mouse, neutral, freed, removed_fd;
static const char *libevdev_get_name(void *d) { (void)d; return "controller"; }
static void libevdev_free(void *d) { (void)d; ++freed; }
static void dualsense_detach(void *d) { (void)d; }
static void loop_remove_fd(int fd) { removed_fd = fd; }
static void input_slots_remove(struct input_device **items, int *count, int index) {
  for (int i = index; i < *count - 1; ++i) items[i] = items[i+1];
  --*count;
}
static void LiSendKeyboardEvent(int code, int action, int mods) {
  assert(code == (short)((0x80 << 8) | 0x1e) && action == KEY_ACTION_UP && mods == 0);
  ++up_keys;
}
static void LiSendMouseButtonEvent(int action, int button) {
  assert(button == BUTTON_LEFT);
  if (action == BUTTON_ACTION_RELEASE) ++up_mouse;
  else assert(action == BUTTON_ACTION_PRESS);
}
static void LiSendMultiControllerEvent(int id, int mask, int buttons,
     int lt, int rt, int lx, int ly, int rx, int ry) {
  assert(id == 0 && buttons == 0 && lt == 0 && rt == 0 &&
         lx == 0 && ly == 0 && rx == 0 && ry == 0);
  assert(mask == (neutral == 0 ? 3 : 2));
  ++neutral;
}
'''
        harness += native
        harness += r'''
int main(void) {
  struct input_device *bad = calloc(1, sizeof(*bad));
  struct input_device *good = calloc(1, sizeof(*good));
  assert(bad && good);
  assert(pthread_mutex_init(&bad->ff_mutex, NULL) == 0);
  assert(pthread_mutex_init(&good->ff_mutex, NULL) == 0);
  bad->fd = -1;
  bad->controllerId = 0;
  bad->is_gamepad = true;
  bad->haptic_effect_id = -1;
  bad->held_keys[30 / 8] = 1u << (30 % 8);
  evdev_send_mouse_button(bad, BUTTON_ACTION_PRESS, BUTTON_LEFT);
  good->fd = -1;
  good->controllerId = 1;
  good->is_gamepad = true;
  good->haptic_effect_id = -1;
  devices[0] = bad;
  devices[1] = good;
  evdev_remove(0);
  assert(up_keys == 1 && up_mouse == 1 && neutral == 2);
  assert(numDevices == 1 && devices[0] == good && assignedControllerIds == 2);
  assert(evdev_gamepads == 1 && freed == 1 && removed_fd == -1);
  /* A healthy second input also holds the same keyboard and mouse button.
   * Removing the failed node must not release the surviving device's state. */
  struct input_device *bad2 = calloc(1, sizeof(*bad2));
  assert(bad2);
  assert(pthread_mutex_init(&bad2->ff_mutex, NULL) == 0);
  bad2->fd = -1;
  bad2->controllerId = 0;
  bad2->is_gamepad = true;
  bad2->haptic_effect_id = -1;
  bad2->held_keys[30 / 8] = 1u << (30 % 8);
  bad2->held_mouse_buttons[0] = true;
  good->held_keys[30 / 8] = 1u << (30 % 8);
  good->held_mouse_buttons[0] = true;
  devices[0] = bad2;
  devices[1] = good;
  numDevices = 2;
  assignedControllerIds = 3;
  evdev_gamepads = 2;
  neutral = up_keys = up_mouse = 0;
  evdev_remove(0);
  assert(up_keys == 0 && up_mouse == 0 && neutral == 2);
  assert(numDevices == 1 && devices[0] == good);
  pthread_mutex_destroy(&good->ff_mutex);
  free(good);
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as directory:
            src = Path(directory) / "release.c"
            binary = Path(directory) / "release"
            src.write_text(harness)
            cmd = shlex.split(os.environ.get("CC", "cc")) + [
                "-std=gnu11", "-pthread", "-Wall", "-Wextra", "-Werror",
                str(src), "-o", str(binary)]
            result = subprocess.run(cmd, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            subprocess.run([str(binary)], check=True, timeout=5)


if __name__ == "__main__":
    unittest.main()
