"""Compile the real HID report writer with injected transient and fatal writes."""
from pathlib import Path
import os
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DualSenseWriteRetryTests(unittest.TestCase):
    def test_transient_write_retains_complete_report_and_sequence(self):
        source = (ROOT / "src/input/dualsense.c").read_text()
        start = source.index("static int send_report(")
        end = source.index("\nint dualsense_led_try(", start)
        native = source[start:end]
        harness = r'''
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>
#include "dualsense.h"
#include "dualsense_report.h"
struct moonlight_dualsense {
  int fd, transport;
  unsigned sequence;
  bool stopping;
};
static int mode, failures;
bool dualsense_hid_healthy(const moonlight_dualsense *d) { return d != NULL; }
static void dualsense_mark_failed(moonlight_dualsense *d) {
  assert(d); ++failures;
}
static ssize_t fake_write(int fd, const void *buf, size_t length) {
  assert(fd == 3 && buf && length == ML_DS_USB_OUT);
  if (mode == 0) { errno = EAGAIN; return -1; }
  if (mode == 1) { errno = EINTR; return -1; }
  if (mode == 2) return length - 1; /* Never split HID report. */
  if (mode == 3) { errno = EIO; return -1; }
  return length;
}
#define write fake_write
'''
        harness += native
        harness += r'''
int main(void) {
  moonlight_dualsense d = {.fd=3,.transport=ML_DS_USB,.sequence=8};
  uint8_t packet[ML_DS_PAYLOAD] = {0};
  mode = 0;
  assert(send_report(&d, packet) == ML_DS_SEND_RETRY);
  assert(d.sequence == 8 && failures == 0);
  mode = 1;
  assert(send_report(&d, packet) == ML_DS_SEND_RETRY);
  assert(d.sequence == 8 && failures == 0);
  mode = 4;
  assert(send_report(&d, packet) == ML_DS_SEND_OK);
  assert(d.sequence == 9 && failures == 0);
  mode = 2;
  assert(send_report(&d, packet) == ML_DS_SEND_FAILED);
  assert(d.sequence == 9 && failures == 1);
  mode = 3;
  assert(send_report(&d, packet) == ML_DS_SEND_FAILED);
  assert(d.sequence == 9 && failures == 2);
  return 0;
}
'''
        with tempfile.TemporaryDirectory() as directory:
            src = Path(directory) / "test.c"
            exe = Path(directory) / "test"
            src.write_text(harness)
            built = subprocess.run(
                shlex.split(os.environ.get("CC", "cc")) +
                ["-std=gnu11", "-Wall", "-Wextra", "-Werror",
                 "-I", str(ROOT / "src/input"), str(src), "-o", str(exe)],
                capture_output=True, text=True)
            self.assertEqual(built.returncode, 0, built.stderr)
            subprocess.run([str(exe)], timeout=5, check=True)


if __name__ == "__main__":
    unittest.main()
