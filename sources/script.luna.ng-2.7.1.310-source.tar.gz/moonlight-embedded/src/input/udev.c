/*
 * This file is part of Moonlight Embedded.
 *
 * Copyright (C) 2015-2017 Iwan Timmer
 *
 * Moonlight is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moonlight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moonlight; if not, see <http://www.gnu.org/licenses/>.
 */

#include "../loop.h"

#include "udev.h"
#include "evdev.h"
#include "selected_names.h"

#include <libudev.h>

#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <poll.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#include <sys/timerfd.h>
#include <stdint.h>
#include <time.h>
#include <sys/stat.h>
#include <errno.h>
#include <limits.h>

static bool autoadd, debug;
static bool whitelist_active;
static char *selected_names;
static char *selected_selectors;
static bool selectors_v2_active;

static bool udev_allowed_name(const char *name) {
  return !whitelist_active ||
         ((selected_selectors || selected_names) &&
          (!selectors_v2_active || selected_selectors) &&
          moonlight_selected_identity(selected_selectors, selected_names,
                                      name, "", ""));
}

/* Query the same evdev device name that Luna displays in its picker.
 * Do not open an unselected hotplug node for write/input capture. */
static bool udev_allowed_node(const char *devnode) {
  if (!whitelist_active) return true;
  if (!devnode || (!selected_selectors && !selected_names) ||
      (selectors_v2_active && !selected_selectors))
    return false;
  int fd = open(devnode, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
  if (fd < 0) return false;
  char name[256] = {0}, uniq[256] = {0}, phys[256] = {0};
  int length = ioctl(fd, EVIOCGNAME(sizeof(name)), name);
  if (length <= 0 || length >= (int)sizeof(name)) {
    close(fd);
    return false;
  }
  name[sizeof(name) - 1] = 0;
  if (!selectors_v2_active && !udev_allowed_name(name)) {
    close(fd);
    return false;
  }
  length = ioctl(fd, EVIOCGUNIQ(sizeof(uniq)), uniq);
  if (length <= 0 || length >= (int)sizeof(uniq)) uniq[0] = 0;
  length = ioctl(fd, EVIOCGPHYS(sizeof(phys)), phys);
  if (length <= 0 || length >= (int)sizeof(phys)) phys[0] = 0;
  uniq[sizeof(uniq) - 1] = 0;
  phys[sizeof(phys) - 1] = 0;
  close(fd);
  return moonlight_selected_identity(selected_selectors, selected_names,
                                     name, uniq, phys);
}
static struct mapping* defaultMappings;
static struct udev *udev;

/* The eventN character-device number is recyclable. Only a still-identical
 * udev sysfs event instance can be retried without an explicit re-add event.
 * Include input uniq/phys when exposed by its parent input node. */
static bool udev_identity_for_rdev(unsigned long long rdev,
                                   char *out, size_t capacity) {
  if (!rdev || !out || capacity < 16) return false;
  /* Explicit input= paths are registered before udev_init(). Borrow a
   * short-lived context to capture their original physical identity. */
  struct udev *context = udev ? udev : udev_new();
  if (!context) return false;
  struct udev_device *event = udev_device_new_from_devnum(context, 'c',
                                                          (dev_t)rdev);
  if (!event) {
    if (context != udev) udev_unref(context);
    return false;
  }
  const char *sysfs = udev_device_get_syspath(event);
  struct udev_device *parent = udev_device_get_parent_with_subsystem_devtype(
      event, "input", NULL);
  const char *uniq = parent ? udev_device_get_sysattr_value(parent, "uniq") : NULL;
  const char *phys = parent ? udev_device_get_sysattr_value(parent, "phys") : NULL;
  bool valid = false;
  if (sysfs && strncmp(sysfs, "/sys/devices/", 13) == 0) {
    const int n = snprintf(out, capacity, "%s\n%s\n%s", sysfs,
                           uniq ? uniq : "", phys ? phys : "");
    valid = n > 0 && (size_t)n < capacity;
  }
  udev_device_unref(event);
  if (context != udev) udev_unref(context);
  if (!valid) out[0] = 0;
  return valid;
}

bool udev_input_identity_for_fd(int fd, char *out, size_t capacity) {
  if (!out || !capacity) return false;
  out[0] = 0;
  struct stat st = {0};
  if (fstat(fd, &st) < 0 || !S_ISCHR(st.st_mode)) return false;
  return udev_identity_for_rdev((unsigned long long)st.st_rdev,
                                out, capacity);
}

static struct udev_monitor *udev_mon;
static int inputRotate;
static int monitor_fd = -1;
/* Failed physical devices are retried independently. A stale eventN reused
 * by another controller must never inherit the old retry's permissions.
 * Retries are bounded in count and capped at one attempt per 32 seconds. */
#define UDEV_RETRY_SLOTS 32
#define UDEV_RETRY_MIN_MS 2000U
#define UDEV_RETRY_MAX_MS 32000U
struct input_retry {
  char path[64];
  unsigned long long rdev;
  char identity[ML_INPUT_IDENTITY_MAX];
  uint64_t due_ms;
  unsigned delay_ms;
  bool active;
};
static struct input_retry input_retries[UDEV_RETRY_SLOTS];
static int recovery_timer_fd = -1;
static uint64_t monitor_retry_due_ms;
static unsigned monitor_retry_ms = UDEV_RETRY_MIN_MS;
static uint64_t advanced_retry_due_ms;
static unsigned advanced_retry_ms = UDEV_RETRY_MIN_MS;

void udev_rescan_inputs(void);
static int udev_handle(int fd);
static int udev_monitor_fault(int fd);

static uint64_t udev_now_ms(void) {
  struct timespec now = {0};
  if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return 0;
  return (uint64_t)now.tv_sec * 1000U +
         (uint64_t)now.tv_nsec / 1000000U;
}

static bool exact_event_node(const char *path) {
  if (!path || strncmp(path, "/dev/input/event", 16) != 0 ||
      strlen(path) >= sizeof(input_retries[0].path))
    return false;
  const char *digits = path + 16;
  if (!*digits) return false;
  for (; *digits; ++digits)
    if (*digits < '0' || *digits > '9') return false;
  return true;
}

static void retry_program_timer(void);

static int udev_activate_monitor(void) {
  if (!udev || udev_mon) return udev_mon ? 0 : -1;
  struct udev_monitor *candidate = udev_monitor_new_from_netlink(udev, "udev");
  if (!candidate) return -1;
  int rc = udev_monitor_filter_add_match_subsystem_devtype(
      candidate, "input", NULL);
  if (rc >= 0) rc = udev_monitor_enable_receiving(candidate);
  const int fd = rc >= 0 ? udev_monitor_get_fd(candidate) : -1;
  if (rc < 0 || fd < 0) {
    udev_monitor_unref(candidate);
    return -1;
  }
  udev_mon = candidate;
  monitor_fd = fd;
  loop_add_device_fd(monitor_fd, udev_handle, udev_monitor_fault, POLLIN);
  monitor_retry_due_ms = 0;
  monitor_retry_ms = UDEV_RETRY_MIN_MS;
  return 0;
}

static void udev_mark_monitor_failed(void) {
  if (monitor_fd >= 0) loop_remove_fd(monitor_fd);
  monitor_fd = -1;
  if (udev_mon) udev_monitor_unref(udev_mon);
  udev_mon = NULL;
  if (udev && (autoadd || whitelist_active)) {
    monitor_retry_due_ms = udev_now_ms() + monitor_retry_ms;
    if (monitor_retry_ms < UDEV_RETRY_MAX_MS)
      monitor_retry_ms *= 2;
    retry_program_timer();
  }
}

static int udev_monitor_fault(int fd) {
  if (fd != monitor_fd) {
    loop_remove_fd(fd);
    return LOOP_OK;
  }
  fprintf(stderr, "Input: udev monitor stopped; retrying independently\n");
  udev_mark_monitor_failed();
  return LOOP_OK;
}

static int retry_handle(int fd) {
  uint64_t expirations = 0;
  if (read(fd, &expirations, sizeof(expirations)) != sizeof(expirations))
    return LOOP_OK;
  const uint64_t now = udev_now_ms();
  if (advanced_retry_due_ms && now >= advanced_retry_due_ms) {
    if (evdev_retry_dualsense_bridges()) {
      advanced_retry_ms = advanced_retry_ms < UDEV_RETRY_MAX_MS ?
          advanced_retry_ms * 2 : UDEV_RETRY_MAX_MS;
      advanced_retry_due_ms = now + advanced_retry_ms;
    } else {
      advanced_retry_due_ms = 0;
      advanced_retry_ms = UDEV_RETRY_MIN_MS;
    }
  }
  if (monitor_retry_due_ms && now >= monitor_retry_due_ms) {
    if (udev_activate_monitor() < 0) {
      monitor_retry_due_ms = now + monitor_retry_ms;
      if (monitor_retry_ms < UDEV_RETRY_MAX_MS)
        monitor_retry_ms *= 2;
    } else {
      /* A working monitor also picks up events missed while it was down. */
      udev_rescan_inputs();
    }
  }

  for (unsigned i = 0; i < UDEV_RETRY_SLOTS; ++i) {
    struct input_retry *retry = &input_retries[i];
    if (!retry->active || retry->due_ms > now) continue;
    struct stat st = {0};
    if (stat(retry->path, &st) != 0) {
      if (errno == ENOENT || errno == ENODEV) retry->active = false;
    } else if (!S_ISCHR(st.st_mode) ||
               (unsigned long long)st.st_rdev != retry->rdev) {
      retry->active = false; /* eventN was replaced by another physical node */
    } else {
      char current[ML_INPUT_IDENTITY_MAX] = {0};
      if (!udev_identity_for_rdev(retry->rdev, current, sizeof(current)) ||
          strcmp(current, retry->identity) != 0) {
        /* Even matching major/minor cannot prove this is the same device. */
        retry->active = false;
      } else if (udev_allowed_node(retry->path)) {
        char path[sizeof(retry->path)];
        char expected[ML_INPUT_IDENTITY_MAX];
        memcpy(path, retry->path, sizeof(path));
        memcpy(expected, retry->identity, sizeof(expected));
        /* Re-validate identity against the freshly opened FD to close the
         * pathname replacement race between stat() and evdev_create(). */
        evdev_create_verified(path, defaultMappings, debug, inputRotate,
                              expected);
        /* Successful evdev_create cancels its exact pending retry. */
      }
    }
    if (retry->active) {
      retry->delay_ms = retry->delay_ms < UDEV_RETRY_MAX_MS ?
          retry->delay_ms * 2 : UDEV_RETRY_MAX_MS;
      retry->due_ms = now + retry->delay_ms;
    }
  }
  retry_program_timer();
  return LOOP_OK;
}

static void retry_program_timer(void) {
  if (!udev) return;
  uint64_t next = monitor_retry_due_ms;
  if (advanced_retry_due_ms &&
      (!next || advanced_retry_due_ms < next))
    next = advanced_retry_due_ms;
  for (unsigned i = 0; i < UDEV_RETRY_SLOTS; ++i)
    if (input_retries[i].active &&
        (!next || input_retries[i].due_ms < next))
      next = input_retries[i].due_ms;
  if (!next && recovery_timer_fd < 0) return;
  if (recovery_timer_fd < 0) {
    recovery_timer_fd = timerfd_create(CLOCK_MONOTONIC,
                                        TFD_NONBLOCK | TFD_CLOEXEC);
    if (recovery_timer_fd < 0) {
      fprintf(stderr, "Input: cannot schedule recovery timer\n");
      return;
    }
    loop_add_fd(recovery_timer_fd, retry_handle, POLLIN);
  }
  struct itimerspec delay = {0};
  if (next) {
    const uint64_t now = udev_now_ms();
    const uint64_t wait = next > now ? next - now : 1;
    delay.it_value.tv_sec = wait / 1000;
    delay.it_value.tv_nsec = (long)(wait % 1000) * 1000000L;
  }
  (void)timerfd_settime(recovery_timer_fd, 0, &delay, NULL);
}

void udev_cancel_input_retry(const char *node_path,
                             unsigned long long rdev) {
  if (!node_path || !*node_path) return;
  for (unsigned i = 0; i < UDEV_RETRY_SLOTS; ++i) {
    if (input_retries[i].active && input_retries[i].rdev == rdev &&
        !strcmp(node_path, input_retries[i].path))
      input_retries[i].active = false;
  }
  retry_program_timer();
}

void udev_schedule_advanced_retry(void) {
  /* Explicit input= paths can own Sony bridges without udev autoadd. */
  if (!udev || advanced_retry_due_ms)
    return;
  advanced_retry_ms = UDEV_RETRY_MIN_MS;
  advanced_retry_due_ms = udev_now_ms() + advanced_retry_ms;
  retry_program_timer();
}

void udev_schedule_input_retry(const char *node_path,
                               unsigned long long rdev, const char *identity) {
  /* Previously registered explicit input= nodes are eligible too. A stable
   * sysfs identity is mandatory; rdev alone can be recycled. */
  if (!udev || !exact_event_node(node_path) || !rdev || !identity ||
      !*identity || strnlen(identity, ML_INPUT_IDENTITY_MAX) >=
                    ML_INPUT_IDENTITY_MAX)
    return;
  for (unsigned i = 0; i < UDEV_RETRY_SLOTS; ++i) {
    if (input_retries[i].active && input_retries[i].rdev == rdev &&
        !strcmp(input_retries[i].path, node_path))
      return; /* Do not reset the backoff on duplicate failure notifications. */
  }
  for (unsigned i = 0; i < UDEV_RETRY_SLOTS; ++i) {
    if (input_retries[i].active) continue;
    struct input_retry *retry = &input_retries[i];
    memset(retry, 0, sizeof(*retry));
    snprintf(retry->path, sizeof(retry->path), "%s", node_path);
    retry->rdev = rdev;
    snprintf(retry->identity, sizeof(retry->identity), "%s", identity);
    retry->delay_ms = UDEV_RETRY_MIN_MS;
    retry->due_ms = udev_now_ms() + retry->delay_ms;
    retry->active = true;
    retry_program_timer();
    return;
  }
  fprintf(stderr, "Input: device retry table full; ignoring excess failure\n");
}

static int udev_handle(int fd) {
  (void)fd;
  if (!udev_mon) return LOOP_OK;
  errno = 0;
  struct udev_device *dev = udev_monitor_receive_device(udev_mon);
  if (!dev) {
    if (errno && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
      udev_mark_monitor_failed();
    return LOOP_OK;
  }
  const char *action = udev_device_get_action(dev);
  if (action && !strcmp("remove", action)) {
    const char *node = udev_device_get_devnode(dev);
    if (node && exact_event_node(node)) {
      for (unsigned i = 0; i < UDEV_RETRY_SLOTS; ++i)
        if (input_retries[i].active &&
            !strcmp(input_retries[i].path, node))
          input_retries[i].active = false;
      retry_program_timer();
    }
  }
  if ((autoadd || whitelist_active) && action &&
      strcmp("add", action) == 0) {
    const char *devnode = udev_device_get_devnode(dev);
    int id;
    char extra;
    if (devnode && sscanf(devnode, "/dev/input/event%d%c", &id, &extra) == 1 &&
        id >= 0 && udev_allowed_node(devnode)) {
      evdev_create(devnode, defaultMappings, debug, inputRotate);
    }
  }
  udev_device_unref(dev); /* Also release devices with no action. */
  return LOOP_OK;
}

void udev_init(bool autoload, struct mapping* mappings, bool verbose, int rotate) {
  debug = verbose;
  autoadd = autoload;
  const char *requested = getenv("MOONLIGHT_INPUT_NAMES_HEX");
  const char *v2 = getenv("MOONLIGHT_INPUT_SELECTORS_V2");
  whitelist_active = requested != NULL || v2 != NULL;
  selectors_v2_active = v2 != NULL;
  free(selected_names);
  free(selected_selectors);
  selected_names = NULL;
  selected_selectors = NULL;
  if (requested && strlen(requested) <= 16384)
    selected_names = strdup(requested);
  if (v2 && strlen(v2) <= 16384)
    selected_selectors = strdup(v2);
  defaultMappings = mappings;
  inputRotate = rotate;
  udev = udev_new();
  if (!udev) {
    fprintf(stderr, "Input: cannot create udev context; hotplug unavailable\n");
    return;
  }

  /* Activate the monitor BEFORE scanning. Events arriving during the
   * enumeration stay in its queue; evdev_create deduplicates devices that
   * appear in both the snapshot and the queued notifications. */
  if (udev_activate_monitor() != 0) {
    fprintf(stderr, "Input: udev monitor unavailable; retry scheduled\n");
    if (autoadd || whitelist_active) {
      monitor_retry_due_ms = udev_now_ms() + UDEV_RETRY_MIN_MS;
      retry_program_timer();
    }
  }

  /* Explicit selectors still enumerate already connected nodes, including
   * controllers whose eventN changed after Luna wrote its session snapshot. */
  if (autoload || whitelist_active) {
    struct udev_enumerate *enumerate = udev_enumerate_new(udev);
    if (!enumerate) {
      fprintf(stderr, "Input: cannot allocate udev enumeration\n");
    } else {
      int filter = udev_enumerate_add_match_subsystem(enumerate, "input");
      int scanned = filter < 0 ? filter : udev_enumerate_scan_devices(enumerate);
      if (scanned < 0) {
        fprintf(stderr, "Input: udev enumeration failed: %d\n", scanned);
      } else {
        struct udev_list_entry *entry;
        udev_list_entry_foreach(entry, udev_enumerate_get_list_entry(enumerate)) {
          const char *path = udev_list_entry_get_name(entry);
          struct udev_device *dev = path ?
              udev_device_new_from_syspath(udev, path) : NULL;
          if (!dev) continue;
          const char *devnode = udev_device_get_devnode(dev);
          int id;
          char extra;
          if (devnode && sscanf(devnode, "/dev/input/event%d%c", &id, &extra) == 1 &&
              id >= 0 && udev_allowed_node(devnode))
            evdev_create(devnode, mappings, verbose, rotate);
          udev_device_unref(dev);
        }
      }
      udev_enumerate_unref(enumerate);
    }
  }
}

void udev_destroy() {
  if (recovery_timer_fd >= 0) {
    loop_remove_fd(recovery_timer_fd);
    close(recovery_timer_fd);
    recovery_timer_fd = -1;
  }
  memset(input_retries, 0, sizeof(input_retries));
  monitor_retry_due_ms = 0;
  monitor_retry_ms = UDEV_RETRY_MIN_MS;
  advanced_retry_due_ms = 0;
  advanced_retry_ms = UDEV_RETRY_MIN_MS;
  if (monitor_fd >= 0) loop_remove_fd(monitor_fd);
  monitor_fd = -1;
  if (udev_mon) udev_monitor_unref(udev_mon);
  udev_mon = NULL;
  if (udev) udev_unref(udev);
  udev = NULL;
  free(selected_names);
  free(selected_selectors);
  selected_names = NULL;
  selected_selectors = NULL;
  selectors_v2_active = false;
  whitelist_active = false;
}

/* Failure recovery: resubscribe only eligible nodes. evdev_create performs
 * duplicate-fd protection and the Steam ownership check on every attempt. */
void udev_rescan_inputs(void) {
  if(!udev || (!autoadd && !whitelist_active))return;
  struct udev_enumerate *e=udev_enumerate_new(udev);
  if(!e)return;
  if(udev_enumerate_add_match_subsystem(e,"input")>=0 &&
     udev_enumerate_scan_devices(e)>=0) {
    struct udev_list_entry *item;
    udev_list_entry_foreach(item,udev_enumerate_get_list_entry(e)) {
      struct udev_device *device=udev_device_new_from_syspath(
          udev,udev_list_entry_get_name(item));
      if(!device)continue;
      const char *node=udev_device_get_devnode(device);
      int id;char extra;
      if(node&&sscanf(node,"/dev/input/event%d%c",&id,&extra)==1 &&
         id>=0&&udev_allowed_node(node))
        evdev_create(node,defaultMappings,debug,inputRotate);
      udev_device_unref(device);
    }
  }
  udev_enumerate_unref(e);
}
