"""Apply the Arctic Fuse 3 Home-window workaround from PR #454.

The patch is intentionally narrow and fail-closed: only the exact known AF3
navigation constructs are changed. If upstream changes the surrounding layout,
Kodi Utilities logs a warning and leaves the skin files untouched.
"""

import hashlib
import json
import os
import stat
import tempfile
import xml.etree.ElementTree as ET

SKIN_ID = "skin.arctic.fuse.3"
HOME_FILENAME = "Includes_Home.xml"
BUTTON_FILENAME = "Includes_ButtonMenu.xml"
FILENAMES = (HOME_FILENAME, BUTTON_FILENAME)
DISABLED_FILENAME = "af3_black_screen_fix.disabled"
BACKUP_DIRNAME = "af3_black_screen_fix_backups"
BACKUP_FILENAME = HOME_FILENAME
BACKUP_META_FILENAME = "metadata.json"

_HUB_WINDOWS = ("1105", "1101", "1102", "1103", "1104", "1106", "1107", "1108", "1109")


class PatchError(RuntimeError):
    """Unsupported upstream layout or a write that cannot be made safely."""


def skin_files(addons_dir):
    base = os.path.join(addons_dir, SKIN_ID, "1080i")
    return {
        HOME_FILENAME: os.path.join(base, HOME_FILENAME),
        BUTTON_FILENAME: os.path.join(base, BUTTON_FILENAME),
    }


def _replace_unique(content, old, new, label):
    if content.count(old) != 1:
        raise PatchError("Arctic Fuse layout changed near {}".format(label))
    return content.replace(old, new, 1)


def _patch_home(content):
    changed = False

    if '<param name="hub_window" />' not in content:
        old = '    <include name="Home_ControlList_Item">\n        <property name="enabled">true</property>'
        new = '    <include name="Home_ControlList_Item">\n        <param name="hub_window" />\n        <property name="enabled">true</property>'
        content = _replace_unique(content, old, new, "Home_ControlList_Item parameter")
        changed = True

    if '<property name="hub_window">$PARAM[hub_window]</property>' not in content:
        old = '                <property name="action">$PARAM[action]</property>\n                <visible>$PARAM[enabled]</visible>'
        new = ('                <property name="action">$PARAM[action]</property>\n'
               '                <property name="hub_window">$PARAM[hub_window]</property>\n'
               '                <visible>$PARAM[enabled]</visible>')
        content = _replace_unique(content, old, new, "Home_ControlList_Item property")
        changed = True

    for window in _HUB_WINDOWS:
        marker = '<param name="hub_window">{}</param>'.format(window)
        if marker in content:
            continue
        old = '            <param name="action">ReplaceWindow({})</param>'.format(window)
        new = old + '\n            ' + marker
        content = _replace_unique(content, old, new, "hub {}".format(window))
        changed = True

    movement = (
        (
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(-1).Property(action)]</onleft>',
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))]">$INFO[Container(399).ListItem(-1).Property(action)]</onleft>\n'
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(-1).Property(hub_window)])</onleft>',
            "horizontal previous hub",
        ),
        (
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(1).Property(action)]</onright>',
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(1).Property(hub_window))]">$INFO[Container(399).ListItem(1).Property(action)]</onright>\n'
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(1).Property(hub_window)])</onright>',
            "horizontal next hub",
        ),
        (
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(-1).Property(action)]</onup>',
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))]">$INFO[Container(399).ListItem(-1).Property(action)]</onup>\n'
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(-1).Property(hub_window)])</onup>',
            "vertical previous hub",
        ),
        (
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(1).Property(action)]</ondown>',
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(1).Property(hub_window))]">$INFO[Container(399).ListItem(1).Property(action)]</ondown>\n'
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(1).Property(hub_window)])</ondown>',
            "vertical next hub",
        ),
    )
    for old, new, label in movement:
        if new in content:
            continue
        content = _replace_unique(content, old, new, label)
        changed = True

    direct_old = '                    <onclick condition="!Window.IsVisible($PARAM[window])">ReplaceWindow($PARAM[window])</onclick>'
    direct_new = (
        '                    <onclick condition="!Window.IsVisible($PARAM[window]) + !Window.IsVisible(Home)">ReplaceWindow($PARAM[window])</onclick>\n'
        '                    <onclick condition="!Window.IsVisible($PARAM[window]) + Window.IsVisible(Home)">ActivateWindow($PARAM[window])</onclick>'
    )
    if direct_new not in content:
        content = _replace_unique(content, direct_old, direct_new, "hub click action")
        changed = True

    try:
        ET.fromstring(content)
    except ET.ParseError as exc:
        raise PatchError("Patched Includes_Home.xml would not parse: {}".format(exc)) from exc
    return content, changed


def _unpatch_home(content):
    """Reverse only the Home/history workaround back to upstream AF3 navigation."""
    changed = False

    direct_old = '                    <onclick condition="!Window.IsVisible($PARAM[window])">ReplaceWindow($PARAM[window])</onclick>'
    direct_new = (
        '                    <onclick condition="!Window.IsVisible($PARAM[window]) + !Window.IsVisible(Home)">ReplaceWindow($PARAM[window])</onclick>\n'
        '                    <onclick condition="!Window.IsVisible($PARAM[window]) + Window.IsVisible(Home)">ActivateWindow($PARAM[window])</onclick>'
    )
    if direct_new in content:
        content = _replace_unique(content, direct_new, direct_old, "hub click action")
        changed = True
    elif direct_old not in content:
        raise PatchError("Arctic Fuse layout changed near hub click action")

    movement = (
        (
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(-1).Property(action)]</onleft>',
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))]">$INFO[Container(399).ListItem(-1).Property(action)]</onleft>\n'
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(-1).Property(hub_window)])</onleft>',
            "horizontal previous hub",
        ),
        (
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(1).Property(action)]</onright>',
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(1).Property(hub_window))]">$INFO[Container(399).ListItem(1).Property(action)]</onright>\n'
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(1).Property(hub_window)])</onright>',
            "horizontal next hub",
        ),
        (
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(-1).Property(action)]</onup>',
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))]">$INFO[Container(399).ListItem(-1).Property(action)]</onup>\n'
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(-1).Property(hub_window)])</onup>',
            "vertical previous hub",
        ),
        (
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(1).Property(action)]</ondown>',
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(1).Property(hub_window))]">$INFO[Container(399).ListItem(1).Property(action)]</ondown>\n'
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(1).Property(hub_window)])</ondown>',
            "vertical next hub",
        ),
    )
    for old, new, label in movement:
        if new in content:
            content = _replace_unique(content, new, old, label)
            changed = True
        elif old not in content:
            raise PatchError("Arctic Fuse layout changed near {}".format(label))

    for window in _HUB_WINDOWS:
        old = '            <param name="action">ReplaceWindow({})</param>'.format(window)
        marker = '            <param name="hub_window">{}</param>'.format(window)
        new = old + '\n' + marker
        if new in content:
            content = _replace_unique(content, new, old, "hub {}".format(window))
            changed = True
        elif marker in content or old not in content:
            raise PatchError("Arctic Fuse layout changed near hub {}".format(window))

    old = (
        '                <property name="action">$PARAM[action]</property>\n'
        '                <visible>$PARAM[enabled]</visible>'
    )
    new = (
        '                <property name="action">$PARAM[action]</property>\n'
        '                <property name="hub_window">$PARAM[hub_window]</property>\n'
        '                <visible>$PARAM[enabled]</visible>'
    )
    if new in content:
        content = _replace_unique(content, new, old, "Home_ControlList_Item property")
        changed = True
    elif old not in content:
        raise PatchError("Arctic Fuse layout changed near Home_ControlList_Item property")

    old = '    <include name="Home_ControlList_Item">\n        <property name="enabled">true</property>'
    new = (
        '    <include name="Home_ControlList_Item">\n'
        '        <param name="hub_window" />\n'
        '        <property name="enabled">true</property>'
    )
    if new in content:
        content = _replace_unique(content, new, old, "Home_ControlList_Item parameter")
        changed = True
    elif old not in content:
        raise PatchError("Arctic Fuse layout changed near Home_ControlList_Item parameter")

    try:
        ET.fromstring(content)
    except ET.ParseError as exc:
        raise PatchError("Restored Includes_Home.xml would not parse: {}".format(exc)) from exc
    return content, changed


def detect_home_content(content):
    """Return 'workaround', 'original', or 'unknown' for one Home XML payload."""
    try:
        _, patch_changed = _patch_home(content)
    except PatchError:
        patch_changed = None
    try:
        _, unpatch_changed = _unpatch_home(content)
    except PatchError:
        unpatch_changed = None

    if patch_changed is False and unpatch_changed is True:
        return "workaround"
    if patch_changed is True and unpatch_changed is False:
        return "original"
    return "unknown"


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def disabled_path(data_dir):
    return os.path.join(data_dir, DISABLED_FILENAME)


def _backup_paths(data_dir):
    root = os.path.join(data_dir, BACKUP_DIRNAME)
    return (
        root,
        os.path.join(root, BACKUP_FILENAME),
        os.path.join(root, BACKUP_META_FILENAME),
    )


def _atomic_json(path, value):
    payload = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    mode = os.stat(path).st_mode if os.path.exists(path) else 0o644
    _atomic_write(path, payload, mode)


def _set_disabled(data_dir):
    os.makedirs(data_dir, exist_ok=True)
    path = disabled_path(data_dir)
    if os.path.exists(path):
        return
    _atomic_write(path, b"disabled\n", 0o644)


def _clear_disabled(data_dir):
    path = disabled_path(data_dir)
    if os.path.exists(path):
        os.unlink(path)


def detect_home(addons_dir):
    path = skin_files(addons_dir)[HOME_FILENAME]
    if not os.path.isfile(path):
        return "missing"
    with open(path, "r", encoding="utf-8") as handle:
        return detect_home_content(handle.read())


def remove_home(addons_dir, data_dir, skin_version=""):
    """Remove only the Home/history workaround and persist the disabled marker."""
    path = skin_files(addons_dir)[HOME_FILENAME]
    if not os.path.isfile(path):
        return "missing"

    with open(path, "rb") as handle:
        original = handle.read()
    state = detect_home_content(original.decode("utf-8"))
    if state == "unknown":
        raise PatchError("Arctic Fuse Home navigation is partially patched or unsupported")
    if state == "original":
        _set_disabled(data_dir)
        return "unchanged"

    restored, changed = _unpatch_home(original.decode("utf-8"))
    if not changed or detect_home_content(restored) != "original":
        raise PatchError("Could not safely derive the original Arctic Fuse Home navigation")
    restored_bytes = restored.encode("utf-8")

    backup_dir, backup_file, metadata_file = _backup_paths(data_dir)
    os.makedirs(backup_dir, exist_ok=True)
    _atomic_write(backup_file, original, os.stat(path).st_mode)
    _atomic_json(metadata_file, {
        "skin_version": skin_version or "",
        "source_sha256": _sha256(original),
        "removed_sha256": _sha256(restored_bytes),
    })

    # The marker must become authoritative before the file changes so the
    # maintenance service cannot race the removal and put the workaround back.
    _set_disabled(data_dir)
    with open(path, "rb") as handle:
        if handle.read() != original:
            raise PatchError("AF3 Home changed concurrently while removing workaround")

    _atomic_write(path, restored_bytes, os.stat(path).st_mode)
    with open(path, "r", encoding="utf-8") as handle:
        if detect_home_content(handle.read()) != "original":
            raise PatchError("Removed AF3 Home workaround could not be verified")
    return "changed"


def restore_home(addons_dir, data_dir, skin_version=""):
    """Restore the Home workaround, then clear the disabled marker."""
    path = skin_files(addons_dir)[HOME_FILENAME]
    if not os.path.isfile(path):
        return "missing"

    with open(path, "rb") as handle:
        current = handle.read()
    state = detect_home_content(current.decode("utf-8"))
    if state == "unknown":
        raise PatchError("Arctic Fuse Home navigation is partially patched or unsupported")
    if state == "workaround":
        _clear_disabled(data_dir)
        return "unchanged"

    replacement = None
    backup_dir, backup_file, metadata_file = _backup_paths(data_dir)
    if os.path.isfile(backup_file) and os.path.isfile(metadata_file):
        try:
            with open(metadata_file, "r", encoding="utf-8") as handle:
                metadata = json.load(handle)
            with open(backup_file, "rb") as handle:
                backup = handle.read()
            same_version = bool(skin_version) and metadata.get("skin_version") == skin_version
            if (same_version and metadata.get("removed_sha256") == _sha256(current) and
                    metadata.get("source_sha256") == _sha256(backup) and
                    detect_home_content(backup.decode("utf-8")) == "workaround"):
                replacement = backup
        except (OSError, ValueError, UnicodeError):
            replacement = None

    if replacement is None:
        patched, changed = _patch_home(current.decode("utf-8"))
        if not changed:
            raise PatchError("Could not restore AF3 Home workaround")
        replacement = patched.encode("utf-8")

    # Keep the disabled marker present until the patched file is completely
    # written and verified. A service wakeup during this window still skips Home.
    with open(path, "rb") as handle:
        if handle.read() != current:
            raise PatchError("AF3 Home changed concurrently while restoring workaround")
    _atomic_write(path, replacement, os.stat(path).st_mode)
    with open(path, "r", encoding="utf-8") as handle:
        if detect_home_content(handle.read()) != "workaround":
            raise PatchError("Restored AF3 Home workaround could not be verified")
    _clear_disabled(data_dir)
    return "changed"


def _patch_button_menu(content):
    old = '                <onclick>ActivateWindow(settings)</onclick>'
    new = '                <onclick>ReplaceWindow(settings)</onclick>'
    if new in content:
        changed = False
    else:
        content = _replace_unique(content, old, new, "Settings button")
        changed = True
    try:
        ET.fromstring(content)
    except ET.ParseError as exc:
        raise PatchError("Patched Includes_ButtonMenu.xml would not parse: {}".format(exc)) from exc
    return content, changed


def _atomic_write(path, data, mode):
    fd, tmp = tempfile.mkstemp(prefix=".af3-window-fix-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, stat.S_IMODE(mode))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def home_workaround_enabled(data_dir):
    return not os.path.exists(disabled_path(data_dir))


def apply_home(addons_dir, data_dir, force=False):
    path = skin_files(addons_dir)[HOME_FILENAME]
    if not os.path.isfile(path):
        return "missing"
    if not force and not home_workaround_enabled(data_dir):
        return "disabled"

    with open(path, "rb") as handle:
        original = handle.read()
    state = detect_home_content(original.decode("utf-8"))
    if state == "unknown":
        raise PatchError("Arctic Fuse Home navigation is partially patched or unsupported")
    if state == "workaround":
        return "unchanged"

    patched, changed = _patch_home(original.decode("utf-8"))
    if not changed:
        return "unchanged"
    with open(path, "rb") as handle:
        if handle.read() != original:
            raise PatchError("AF3 Home changed concurrently")
    if not force and not home_workaround_enabled(data_dir):
        return "disabled"
    _atomic_write(path, patched.encode("utf-8"), os.stat(path).st_mode)
    return "changed"


def apply_button_menu(addons_dir):
    path = skin_files(addons_dir)[BUTTON_FILENAME]
    if not os.path.isfile(path):
        return "missing"
    with open(path, "rb") as handle:
        original = handle.read()
    patched, changed = _patch_button_menu(original.decode("utf-8"))
    if not changed:
        return "unchanged"
    with open(path, "rb") as handle:
        if handle.read() != original:
            raise PatchError("AF3 ButtonMenu changed concurrently")
    _atomic_write(path, patched.encode("utf-8"), os.stat(path).st_mode)
    return "changed"


def apply(addons_dir):
    """Return 'changed', 'unchanged' or 'missing'."""
    paths = skin_files(addons_dir)
    if not os.path.isdir(os.path.join(addons_dir, SKIN_ID)):
        return "missing"
    if not all(os.path.isfile(path) for path in paths.values()):
        raise PatchError("Required Arctic Fuse navigation files are missing")

    originals = {}
    decoded = {}
    for name, path in paths.items():
        with open(path, "rb") as handle:
            originals[name] = handle.read()
        decoded[name] = originals[name].decode("utf-8")

    home, home_changed = _patch_home(decoded[HOME_FILENAME])
    button, button_changed = _patch_button_menu(decoded[BUTTON_FILENAME])
    if not home_changed and not button_changed:
        return "unchanged"

    # Preflight every target before writing either file. This prevents an
    # upstream layout change in one file from leaving a half-applied patch.
    for name, path in paths.items():
        with open(path, "rb") as handle:
            if handle.read() != originals[name]:
                raise PatchError("Skin changed while applying blank-screen fix; retry on next event")

    if home_changed:
        _atomic_write(paths[HOME_FILENAME], home.encode("utf-8"),
                      os.stat(paths[HOME_FILENAME]).st_mode)
    if button_changed:
        _atomic_write(paths[BUTTON_FILENAME], button.encode("utf-8"),
                      os.stat(paths[BUTTON_FILENAME]).st_mode)
    return "changed"
