"""Temporary Kodi test-build support for CoreELEC.

Verified test binaries are staged under /storage and bind-mounted over the
stock /usr/lib/kodi/kodi.bin only for the current boot. Nothing persists the
bind mount, so reboot or power-cycle always restores the stock Kodi binary.
"""

import hashlib
import os
import shlex
import shutil
import subprocess
import urllib.request

TEST_ROOT = "/storage/.config/kodi-utilities/kodi-test"
STOCK_BIN = "/usr/lib/kodi/kodi.bin"

LEGACY_BUILD_ID = "legacy_af3_v1"
LEGACY_LABEL = "Legacy AF3 Window Fallback (v1)"
LEGACY_SHA256 = "f42aa2d8ada188dcddfa75d8faca610922104c1996f171e72caa8b9163dd935a"
LEGACY_TEST_BIN = os.path.join(TEST_ROOT, "kodi.bin")
LEGACY_PART_BIN = LEGACY_TEST_BIN + ".part"

BUILD_ORDER = (
    "af3_window_fallback",
    "segmented_cache_4m",
)

BUILDS = {
    "af3_window_fallback": {
        "label": "AF3 Window Fallback",
        "sha256": "c3cf117ad3aaf1161ca07880929ee1c3a260989fa0209f169bc911de6a5fa49f",
        "url": (
            "https://github.com/Roboatlas21/xbmc-p3i/releases/download/"
            "kodi-p3i-window-fallback-arm32-v2/kodi.bin"
        ),
    },
    "segmented_cache_4m": {
        "label": "4 MiB Segmented Cache",
        "sha256": "5c77052087cb6d82fc7341f7dfcb5034d7ffb04408d67b954fe1aeda4b34984d",
        "url": (
            "https://github.com/Roboatlas21/xbmc-p3i/releases/download/"
            "kodi-p3i-cache-4m-arm32-v1/kodi.bin"
        ),
    },
}


class KodiTestError(RuntimeError):
    pass


def build_info(build_id):
    try:
        return BUILDS[build_id]
    except KeyError as exc:
        raise KodiTestError("Unknown Kodi test build: {}".format(build_id)) from exc


def test_bin(build_id):
    build_info(build_id)
    return os.path.join(TEST_ROOT, build_id, "kodi.bin")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def supported():
    return (
        os.path.isfile(STOCK_BIN)
        and shutil.which("systemd-run") is not None
        and shutil.which("mount") is not None
        and shutil.which("umount") is not None
        and shutil.which("mountpoint") is not None
    )


def active():
    result = subprocess.run(
        ["mountpoint", "-q", STOCK_BIN],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return result.returncode == 0


def active_build():
    """Return the active test build ID, None for stock, or 'foreign_mount'."""
    if not supported():
        return None
    if not active():
        return None
    try:
        current = sha256_file(STOCK_BIN)
    except OSError:
        return "foreign_mount"
    for build_id in BUILD_ORDER:
        if current == BUILDS[build_id]["sha256"]:
            return build_id
    if current == LEGACY_SHA256:
        return LEGACY_BUILD_ID
    return "foreign_mount"



def legacy_status():
    """Describe the old flat test layout without modifying it."""
    mounted = active_build()
    if mounted == LEGACY_BUILD_ID:
        return "active"
    if not os.path.isfile(LEGACY_TEST_BIN):
        return "absent"
    try:
        return "staged" if sha256_file(LEGACY_TEST_BIN) == LEGACY_SHA256 else "unknown"
    except OSError:
        return "unknown"


def _remove_legacy_files():
    """Remove only the pre-migration flat files; never touch new build directories."""
    changed = False
    for path in (LEGACY_TEST_BIN, LEGACY_PART_BIN):
        try:
            os.unlink(path)
            changed = True
        except FileNotFoundError:
            pass
    return changed


def migrate_legacy():
    """Clean an inactive known v1 flat build, but never unlink an active source."""
    state = legacy_status()
    if state == "active":
        return "active"
    if state == "staged":
        _remove_legacy_files()
        return "removed"
    if state == "absent":
        # A stale partial download from the old helper is safe to remove.
        try:
            os.unlink(LEGACY_PART_BIN)
            return "removed_partial"
        except FileNotFoundError:
            return "none"
    return "unknown"


def staged(build_id):
    info = build_info(build_id)
    path = test_bin(build_id)
    return os.path.isfile(path) and sha256_file(path) == info["sha256"]


def build_status(build_id):
    if not supported():
        return "unsupported"
    mounted = active_build()
    if mounted == "foreign_mount":
        return "foreign_mount"
    if mounted == build_id:
        return "active"
    path = test_bin(build_id)
    if os.path.isfile(path):
        try:
            return "staged" if staged(build_id) else "corrupt"
        except OSError:
            return "corrupt"
    return "not_downloaded"


def stage(build_id):
    """Download and verify one test binary without activating it."""
    if not supported():
        raise KodiTestError(
            "Temporary Kodi testing is available only on supported CoreELEC systems"
        )
    info = build_info(build_id)
    path = test_bin(build_id)
    build_dir = os.path.dirname(path)
    os.makedirs(build_dir, exist_ok=True)
    temporary = path + ".part"
    try:
        if os.path.exists(temporary):
            os.unlink(temporary)
        request = urllib.request.Request(
            info["url"],
            headers={"User-Agent": "KodiUtilities/0.1", "Cache-Control": "no-cache"},
        )
        with urllib.request.urlopen(request, timeout=30) as stream, open(
                temporary, "wb") as handle:
            copied = 0
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > 64 * 1024 * 1024:
                    raise KodiTestError("Test Kodi download exceeded the expected size")
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())

        actual = sha256_file(temporary)
        if actual != info["sha256"]:
            raise KodiTestError(
                "{} SHA256 verification failed".format(info["label"])
            )
        os.chmod(temporary, 0o755)
        os.replace(temporary, path)
        return "changed"
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _run_transient(prefix, script):
    unit = "{}-{}".format(prefix, os.getpid())
    result = subprocess.run(
        ["systemd-run", "--unit=" + unit, "--no-block", "/bin/sh", "-c", script],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise KodiTestError(
            result.stdout.strip() or "Could not schedule CoreELEC Kodi transition"
        )


def activate(build_id):
    """Activate a verified test binary until reboot, switching known tests safely."""
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    info = build_info(build_id)
    path = test_bin(build_id)
    if not staged(build_id):
        raise KodiTestError("Download and verify {} first".format(info["label"]))

    mounted = active_build()
    if mounted == build_id:
        return "unchanged"
    if mounted == "foreign_mount":
        raise KodiTestError(
            "Another unknown bind mount already covers the stock Kodi binary"
        )

    legacy_cleanup = mounted == LEGACY_BUILD_ID
    script = """set -eu
TEST_BIN={test_bin}
STOCK_BIN={stock_bin}
EXPECTED={expected}
LEGACY_BIN={legacy_bin}
LEGACY_PART={legacy_part}
CLEAN_LEGACY={clean_legacy}
sleep 1
systemctl stop kodi.service
if mountpoint -q "$STOCK_BIN"; then
  if ! umount "$STOCK_BIN"; then
    systemctl start kodi.service
    exit 1
  fi
fi
if [ "$CLEAN_LEGACY" = "1" ]; then
  rm -f "$LEGACY_BIN" "$LEGACY_PART"
fi
if ! mount --bind "$TEST_BIN" "$STOCK_BIN"; then
  systemctl start kodi.service
  exit 1
fi
ACTUAL="$(sha256sum "$STOCK_BIN" | awk '{{print $1}}')"
if [ "$ACTUAL" != "$EXPECTED" ]; then
  umount "$STOCK_BIN" || true
  systemctl start kodi.service
  exit 1
fi
systemctl start kodi.service
""".format(
        test_bin=shlex.quote(path),
        stock_bin=shlex.quote(STOCK_BIN),
        expected=shlex.quote(info["sha256"]),
        legacy_bin=shlex.quote(LEGACY_TEST_BIN),
        legacy_part=shlex.quote(LEGACY_PART_BIN),
        clean_legacy="1" if legacy_cleanup else "0",
    )
    _run_transient("kodi-utilities-test-kodi", script)
    return "scheduled"


def restore_stock():
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    mounted = active_build()
    if mounted == "foreign_mount":
        raise KodiTestError(
            "Refusing to remove an unknown bind mount from the Kodi binary"
        )
    if mounted is None:
        migrated = migrate_legacy()
        return "legacy_removed" if migrated in ("removed", "removed_partial") else "unchanged"

    legacy_cleanup = mounted == LEGACY_BUILD_ID
    script = """set -eu
STOCK_BIN={stock_bin}
LEGACY_BIN={legacy_bin}
LEGACY_PART={legacy_part}
CLEAN_LEGACY={clean_legacy}
sleep 1
systemctl stop kodi.service
if mountpoint -q "$STOCK_BIN"; then
  umount "$STOCK_BIN"
fi
if [ "$CLEAN_LEGACY" = "1" ]; then
  rm -f "$LEGACY_BIN" "$LEGACY_PART"
fi
systemctl start kodi.service
""".format(
        stock_bin=shlex.quote(STOCK_BIN),
        legacy_bin=shlex.quote(LEGACY_TEST_BIN),
        legacy_part=shlex.quote(LEGACY_PART_BIN),
        clean_legacy="1" if legacy_cleanup else "0",
    )
    _run_transient("kodi-utilities-restore-kodi", script)
    return "scheduled_legacy_cleanup" if legacy_cleanup else "scheduled"


def remove_staged(build_id):
    """Remove one downloaded test build, restoring stock first if it is active."""
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    info = build_info(build_id)
    path = test_bin(build_id)
    build_dir = os.path.dirname(path)
    mounted = active_build()
    if mounted == "foreign_mount":
        raise KodiTestError(
            "Refusing to remove an unknown bind mount from the Kodi binary"
        )

    if mounted == build_id:
        script = """set -eu
BUILD_DIR={build_dir}
STOCK_BIN={stock_bin}
sleep 1
systemctl stop kodi.service
if mountpoint -q "$STOCK_BIN"; then
  umount "$STOCK_BIN"
fi
rm -rf "$BUILD_DIR"
systemctl start kodi.service
""".format(
            build_dir=shlex.quote(build_dir),
            stock_bin=shlex.quote(STOCK_BIN),
        )
        _run_transient("kodi-utilities-remove-test-kodi", script)
        return "scheduled"

    if os.path.isdir(build_dir):
        shutil.rmtree(build_dir)
        return "changed"
    return "unchanged"


def remove_all():
    """Remove all staged test builds; restore stock first if a known test is active."""
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    mounted = active_build()
    if mounted == "foreign_mount":
        raise KodiTestError(
            "Refusing to remove an unknown bind mount from the Kodi binary"
        )

    if mounted is not None:
        script = """set -eu
TEST_ROOT={test_root}
STOCK_BIN={stock_bin}
sleep 1
systemctl stop kodi.service
if mountpoint -q "$STOCK_BIN"; then
  umount "$STOCK_BIN"
fi
rm -rf "$TEST_ROOT"
systemctl start kodi.service
""".format(
            test_root=shlex.quote(TEST_ROOT),
            stock_bin=shlex.quote(STOCK_BIN),
        )
        _run_transient("kodi-utilities-remove-all-test-kodi", script)
        return "scheduled"

    if os.path.isdir(TEST_ROOT):
        shutil.rmtree(TEST_ROOT)
        return "changed"
    return "unchanged"
