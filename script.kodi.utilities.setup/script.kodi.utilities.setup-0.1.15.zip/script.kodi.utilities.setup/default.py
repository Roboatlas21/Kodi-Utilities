"""Manual, opt-in CoreELEC/Kodi configuration sync from an explicit GitHub profile."""

import json
import os
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.profile import ProfileError, digest, parse
from resources.lib.file_sources import is_source_present, set_file_source
from resources.lib import cec_settings, advanced_settings, timezone_settings, weather_city, display_resolution

TITLE = "Kodi Utilities - Device Setup"
PROFILE_URL = "https://raw.githubusercontent.com/Roboatlas21/Kodi-Utilities/main/device-profiles/shared.json"
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/script.kodi.utilities.setup")
STATE_FILE = os.path.join(DATA_DIR, "state.json")
ROLLBACK_FILE = os.path.join(DATA_DIR, "rollback.json")
SOURCES_FILE = xbmcvfs.translatePath("special://masterprofile/sources.xml")
ADVANCED_FILE = xbmcvfs.translatePath("special://masterprofile/advancedsettings.xml")
CEC_WORKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "cec_worker.sh")
CEC_RESTORE_PENDING = os.path.join(DATA_DIR, "cec_restore_pending.json")
_KODI_SETTING_IDS = None


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return None


def save_json(path, data):
    os.makedirs(DATA_DIR, exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def rpc(method, params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params
    })))
    if "error" in result:
        raise RuntimeError("{}: {}".format(method, result["error"].get("message", "unknown")))
    return result["result"]


def read(op):
    typ = op["type"]
    if typ == "kodi_setting":
        return rpc("Settings.GetSettingValue", {"setting": op["id"]})["value"]
    if typ == "timezone_setting":
        return timezone_settings.read_state(rpc)["value"]
    if typ == "skin_setting":
        active = rpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})["value"]
        if active != op["skin"]:
            raise RuntimeError("Skin {} must be active before changing {}".format(op["skin"], op["id"]))
        return rpc("Settings.GetSkinSettingValue", {"setting": op["id"]})["value"]
    if typ == "addon_setting":
        addon = xbmcaddon.Addon(op["addon_id"])
        value = op["value"]
        if type(value) is bool:
            return addon.getSettingBool(op["id"])
        if type(value) is int:
            return addon.getSettingInt(op["id"])
        if type(value) is float:
            return addon.getSettingNumber(op["id"])
        return addon.getSettingString(op["id"])
    if typ == "cec_setting":
        return cec_settings.read(op)
    if typ == "advanced_setting":
        return advanced_settings.get_limit_state(ADVANCED_FILE)["value"]
    if typ == "file_source":
        return is_source_present(SOURCES_FILE, op["name"], op["path"])
    if typ == "install_addon":
        return bool(xbmc.getCondVisibility("System.HasAddon({})".format(op["id"])))
    raise RuntimeError("Unsupported operation")


def write(op, value, restore_metadata=None):
    typ = op["type"]
    if typ == "kodi_setting":
        result = rpc("Settings.SetSettingValue", {"setting": op["id"], "value": value})
        if result is not True:
            raise RuntimeError("Kodi refused to update {}".format(op["id"]))
    elif typ == "timezone_setting":
        timezone_settings.write(rpc, value, restore_metadata)
    elif typ == "skin_setting":
        active = rpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})["value"]
        if active != op["skin"]:
            raise RuntimeError("Wrong active skin; refusing change")
        result = rpc("Settings.SetSkinSettingValue", {"setting": op["id"], "value": value})
        if result is not True:
            raise RuntimeError("Kodi refused to update skin setting {}".format(op["id"]))
    elif typ == "addon_setting":
        addon = xbmcaddon.Addon(op["addon_id"])
        if type(value) is bool:
            result = addon.setSettingBool(op["id"], value)
        elif type(value) is int:
            result = addon.setSettingInt(op["id"], value)
        elif type(value) is float:
            result = addon.setSettingNumber(op["id"], value)
        else:
            result = addon.setSettingString(op["id"], value)
        if result is False:
            raise RuntimeError("Add-on refused to update {}".format(op["id"]))
    elif typ == "cec_setting":
        raise RuntimeError("CEC changes must be applied by the CoreELEC restart helper")
    elif typ == "advanced_setting":
        advanced_settings.set_recently_added(
            ADVANCED_FILE, value, os.path.join(DATA_DIR, "advancedsettings_backups"),
            restore_metadata=restore_metadata)
    elif typ == "file_source":
        set_file_source(SOURCES_FILE, op["name"], op["path"], value,
                        os.path.join(DATA_DIR, "source_backups"))
    elif typ == "install_addon":
        if not value:
            raise RuntimeError("Removing add-ons is not supported")
        xbmc.executebuiltin("InstallAddon({})".format(op["id"]))
        # Kodi schedules installations asynchronously. Do not report success
        # until Kodi actually exposes the requested add-on.
        monitor = xbmc.Monitor()
        for _ in range(60):
            if xbmc.getCondVisibility("System.HasAddon({})".format(op["id"])):
                break
            if monitor.waitForAbort(1):
                raise RuntimeError("Installation interrupted: {}".format(op["id"]))
        else:
            raise RuntimeError("Installation not verified: {} (Kodi may still finish later)".format(op["id"]))
    else:
        raise RuntimeError("Unsupported operation")


def fetch_profile():
    request = urllib.request.Request(PROFILE_URL, headers={"User-Agent": "KodiUtilitiesDeviceSetup/0.1", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(request, timeout=15) as stream:
        data = stream.read(65537)
    profile = parse(data)
    return profile, digest(data)


def label(op):
    if op["type"] == "skin_setting":
        return "{} / {}".format(op["skin"], op["id"])
    if op["type"] == "addon_setting":
        return "{} / {}".format(op["addon_id"], op["id"])
    if op["type"] == "cec_setting":
        return "HDMI-CEC: {}".format(cec_settings.CEC_LABELS[op["id"]])
    if op["type"] == "advanced_setting":
        return "Recently Added items limit"
    if op["type"] == "timezone_setting":
        return "Timezone country / timezone"
    if op["type"] == "file_source":
        return "File Manager source: {} ({})".format(op["name"], op["path"])
    return op["id"]


def format_value(value):
    if isinstance(value, dict) and set(value) == {"country", "timezone"}:
        return "{} / {}".format(value["country"] or "No country", value["timezone"])
    rendered = json.dumps(value, ensure_ascii=False)
    return rendered if len(rendered) < 150 else rendered[:147] + "..."


def addon_is_missing(op):
    """Skip only settings for add-ons Kodi confirms are not installed.

    System.HasAddon checks installation, not whether an add-on is enabled.
    Other read/write failures must still abort rather than silently skip them.
    """
    return (op["type"] == "addon_setting" and
            not xbmc.getCondVisibility("System.HasAddon({})".format(op["addon_id"])))


def missing_addons_text(operations):
    """Explain skipped add-on settings, grouped by installed add-on ID."""
    counts = {}
    for op in operations:
        addon_id = op["addon_id"]
        counts[addon_id] = counts.get(addon_id, 0) + 1
    return "\n".join("{} not installed — {} {} skipped.".format(
        addon_id, count, "setting" if count == 1 else "settings")
        for addon_id, count in counts.items())


def skip_reason(op):
    global _KODI_SETTING_IDS
    if op["type"] == "kodi_setting":
        if _KODI_SETTING_IDS is None:
            _KODI_SETTING_IDS = timezone_settings.setting_ids(rpc)
        if op["id"] not in _KODI_SETTING_IDS:
            return "Not available on this Kodi build"
    if op["type"] == "timezone_setting":
        return timezone_settings.unavailable_reason(rpc)
    if addon_is_missing(op):
        return "Add-on not installed"
    if op["type"] == "cec_setting":
        try:
            return cec_settings.unavailable_reason(op)
        except cec_settings.CecUnavailable as exc:
            return str(exc)
    return None


def skipped_text(operations):
    addons = [op for op in operations if op["type"] == "addon_setting"]
    cec = [op for op in operations if op["type"] == "cec_setting"]
    versioned = [op for op in operations if op["type"] in ("kodi_setting", "timezone_setting")]
    lines = []
    if addons:
        lines.append(missing_addons_text(addons))
        lines.append("Install the add-on and run Apply My Setup again.")
    for op in cec + versioned:
        try:
            reason = skip_reason(op)
        except Exception as exc:
            reason = str(exc)
        lines.append("{} — skipped: {}".format(label(op), reason or "Unavailable"))
    if cec:
        lines.append("Run Apply My Setup again when the CEC setting becomes available.")
    return "\n".join(lines)


def cec_value_text(value):
    return {36044: "Stop Playback", 36045: "Pause Playback", 231: "None",
            13011: "Suspend", 13005: "Power off", 13010: "Hibernate",
            13009: "Quit", 36028: "Ignore"}.get(value, format_value(value))


def confirm_change(change):
    """Show an intelligible one-line description when confirming a single change."""
    op = change["operation"]
    if op["type"] == "install_addon":
        return "Install add-on: {}".format(label(op))
    if op["type"] == "file_source":
        return "Add {}".format(label(op))
    if op["type"] == "kodi_setting" and op["id"] == "filecache.memorysize":
        return "Playback cache memory: {} MB → {} MB".format(change["before"], change["after"])
    if op["type"] == "kodi_setting" and op["id"] == "screensaver.mode":
        screen_modes = {"": "None", "screensaver.xbmc.builtin.dim": "Dim"}
        before = screen_modes.get(change["before"], format_value(change["before"]))
        after = screen_modes.get(change["after"], format_value(change["after"]))
        return "Screensaver mode: {} → {}".format(before, after)
    if op["type"] == "cec_setting":
        return "{}: {} → {}".format(label(op), cec_value_text(change["before"]),
                                     cec_value_text(change["after"]))
    return "{}: {} → {}".format(label(op), format_value(change["before"]),
                                 format_value(change["after"]))


def plan(profile):
    """Preflight available settings; missing add-on settings are optional."""
    result = []
    missing = []
    for op in profile["changes"]:
        if skip_reason(op):
            missing.append(op)
            continue
        try:
            current = read(op)
        except (cec_settings.CecUnavailable, timezone_settings.TimezoneUnavailable):
            missing.append(op)
            continue
        wanted = True if op["type"] in ("install_addon", "file_source") else op["value"]
        # Type changes are permitted only if the Kodi API itself accepts them.
        if current != wanted or type(current) is not type(wanted):
            change = {"operation": op, "before": current, "after": wanted}
            if op["type"] == "advanced_setting":
                previous = advanced_settings.get_limit_state(ADVANCED_FILE)
                if previous["value"] != current:
                    raise RuntimeError("Recently Added limit changed during preview; retry")
                change["advanced_original"] = {
                    "file_present": previous["file_present"],
                    "section_present": previous["section_present"],
                    "entry_present": previous["entry_present"],
                }
            if op["type"] == "timezone_setting":
                previous = timezone_settings.read_state(rpc)
                if previous["value"] != current:
                    raise RuntimeError("Timezone changed during preview; retry")
                change["timezone_original"] = {key: value for key, value in previous.items()
                                               if key != "value"}
            result.append(change)
    return result, missing


def preview_text(profile, changes, missing=()):
    lines = ["GitHub shared profile — revision {}".format(profile["revision"]),
             "Detected: {} / Kodi {}".format(timezone_settings.description(), xbmc.getInfoLabel("System.BuildVersion")),
             "Review the changes below.", ""]
    if not changes:
        lines.append("No available settings need changing.")
    for idx, change in enumerate(changes, 1):
        op = change["operation"]
        lines.append("{}. {}".format(idx, confirm_change(change)))
        if op["type"] == "install_addon":
            lines.append("    Installation cannot be automatically undone.")
        if op["type"] == "file_source":
            lines.append("    Adds the path only; repository ZIP is NOT installed.")
            lines.append("    Restart Kodi before using the source in Install from zip file.")
        if op["type"] == "cec_setting":
            lines.append("    CoreELEC must reboot; the CEC helper updates settings after Kodi stops.")
        if op["type"] == "advanced_setting":
            lines.append("    Takes effect after your next full CoreELEC reboot (not automatic).")
        if op["type"] == "timezone_setting":
            method = change["timezone_original"]["backend"]
            lines.append("    Uses {}.".format("Kodi regional settings" if method == "kodi" else
                                              "CoreELEC timezone service"))
    if missing:
        lines.extend(["", "Skipped (unavailable settings):", skipped_text(missing)])
    return "\n".join(lines)


def show_error(exc):
    xbmc.log("Kodi Utilities Device Setup: {}".format(exc), xbmc.LOGERROR)
    xbmcgui.Dialog().ok(TITLE, "Nothing was applied.\n{}".format(exc))


def check():
    profile, signature = fetch_profile()
    changes, missing = plan(profile)
    state = load_json(STATE_FILE) or {}
    if state.get("signature") != signature:
        status = "GitHub profile differs from the last applied revision."
    elif changes or missing or state.get("skipped_addon_settings"):
        status = "This revision is not fully applied; some settings differ or were skipped."
    else:
        status = "This revision was applied here."
    job_status = cec_settings.status(DATA_DIR)
    if job_status in ("scheduled", "running", "rebooting"):
        status += "\nA CEC change is pending and CoreELEC will reboot."
    elif job_status.startswith("error:"):
        status += "\nPrevious CEC update failed: {}".format(job_status[6:])
    xbmcgui.Dialog().textviewer(TITLE, "{}\n\n{}".format(status,
                                   preview_text(profile, changes, missing)))


def preview():
    profile, _ = fetch_profile()
    changes, missing = plan(profile)
    xbmcgui.Dialog().textviewer(TITLE, preview_text(profile, changes, missing))


def pending_cec_restore_cleanup():
    """Finalize a previous CEC restore only after the helper reports success."""
    pending = load_json(CEC_RESTORE_PENDING)
    if not pending or cec_settings.status(DATA_DIR) != "done":
        return
    saved = load_json(ROLLBACK_FILE)
    if saved and saved.get("changes"):
        uncompleted = []
        for item in saved["changes"]:
            if item["operation"]["type"] != "cec_setting" or item not in pending.get("changes", []):
                uncompleted.append(item)
                continue
            try:
                if read(item["operation"]) != item["before"]:
                    uncompleted.append(item)
            except cec_settings.CecUnavailable:
                uncompleted.append(item)
        if uncompleted:
            save_json(ROLLBACK_FILE, {"revision": saved["revision"], "changes": uncompleted})
        else:
            os.remove(ROLLBACK_FILE)
    os.remove(CEC_RESTORE_PENDING)


class ApplyDialog(xbmcgui.WindowXMLDialog):
    """Keep the full change list and its confirmation buttons on one screen."""

    def onInit(self):
        self.getControl(1).setText(self.message)
        self.setFocusId(10)

    def onClick(self, control_id):
        if control_id in (10, 11):
            self.confirmed = control_id == 10
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):  # Parent, previous menu, navigation back
            self.confirmed = False
            self.close()


def confirm_apply(message):
    addon_path = os.path.dirname(os.path.abspath(__file__))
    dialog = ApplyDialog("SetupConfirm.xml", addon_path, "default", "720p")
    dialog.message = message
    dialog.confirmed = False
    try:
        dialog.doModal()
        return dialog.confirmed
    finally:
        del dialog


def apply():
    profile, signature = fetch_profile()
    changes, missing = plan(profile)
    if not changes:
        message = "No available settings need changing. Nothing was modified."
        if missing:
            message += "\n\n" + skipped_text(missing)
        xbmcgui.Dialog().ok(TITLE, message)
        return
    message = preview_text(profile, changes, missing)
    if any(x["operation"]["type"] == "cec_setting" for x in changes):
        message = "HDMI-CEC changes require a full CoreELEC reboot. Playback will stop.\n\n" + message
    if not confirm_apply(message):
        return
    ready = []
    for item in changes:
        op = item["operation"]
        if skip_reason(op):
            missing.append(op)
        else:
            if op["type"] == "cec_setting" and read(op) != item["before"]:
                raise RuntimeError("CEC value changed since preview; preview again before applying")
            if op["type"] == "advanced_setting" and (
                    advanced_settings.get_limit_state(ADVANCED_FILE)["value"] != item["before"]):
                raise RuntimeError("Recently Added limit changed since preview; preview again")
            if op["type"] == "timezone_setting":
                current = timezone_settings.read_state(rpc)
                expected = dict(item["timezone_original"], value=item["before"])
                if current != expected:
                    raise RuntimeError("Timezone or CoreELEC support changed since preview; preview again")
            ready.append(item)
    if not ready:
        xbmcgui.Dialog().ok(TITLE, "Nothing was modified.\n\n" + skipped_text(missing))
        return
    cec_items = [x for x in ready if x["operation"]["type"] == "cec_setting"]
    regular_items = [x for x in ready if x["operation"]["type"] != "cec_setting"]
    if cec_items:
        cec_settings.require_no_pending(DATA_DIR)
    reversible = [x for x in ready if x["operation"]["type"] != "install_addon"]
    previous_snapshot = load_json(ROLLBACK_FILE)
    previous_state = load_json(STATE_FILE)
    save_json(ROLLBACK_FILE, {"revision": profile["revision"], "changes": reversible})
    completed = []
    try:
        for item in regular_items:
            if addon_is_missing(item["operation"]):
                missing.append(item["operation"])
                continue
            completed.append(item)
            write(item["operation"], item["after"])
        # Prepare snapshots before scheduling the independent helper, which
        # might stop Kodi immediately after its timer fires.
        save_json(ROLLBACK_FILE, {"revision": profile["revision"], "changes": [
            x for x in completed + cec_items if x["operation"]["type"] != "install_addon"]})
        save_json(STATE_FILE, {"signature": signature, "revision": profile["revision"],
                               "skipped_addon_settings": len(missing)})
        # Schedule last: no further writes can fail after this point.
        if cec_items:
            cec_settings.schedule(cec_items, DATA_DIR, CEC_WORKER)
    except Exception as exc:
        errors = []
        for item in reversed(completed):
            if item["operation"]["type"] != "install_addon":
                try:
                    write(item["operation"], item["before"],
                          restore_metadata=item.get("advanced_original", item.get("timezone_original")))
                except Exception as rollback_exc:
                    errors.append("{}: {}".format(label(item["operation"]), rollback_exc))
        # Only restore old undo history after all attempted changes were
        # reverted. Otherwise retain the new snapshot for manual recovery.
        if not errors:
            if previous_snapshot:
                save_json(ROLLBACK_FILE, previous_snapshot)
            elif os.path.exists(ROLLBACK_FILE):
                os.remove(ROLLBACK_FILE)
            if previous_state:
                save_json(STATE_FILE, previous_state)
            elif os.path.exists(STATE_FILE):
                os.remove(STATE_FILE)
        raise RuntimeError("Apply failed: {}. {}".format(
            exc, "Restore errors: {}. Snapshot retained.".format("; ".join(errors)) if errors else
            "Attempted setting changes were reverted; install requests cannot be undone."))
    if cec_items:
        # Modal dialogs block until dismissed; the separate worker may stop
        # Kodi soon, so use a short non-modal notification instead.
        xbmcgui.Dialog().notification(TITLE, "CEC settings queued. CoreELEC will reboot shortly.",
                                       xbmcgui.NOTIFICATION_INFO, 8000)
        return
    info = "\nRestart Kodi to use the new File Manager source." if any(
        x["operation"]["type"] == "file_source" for x in completed) else ""
    if any(x["operation"]["type"] == "advanced_setting" for x in completed):
        info += "\nReboot CoreELEC when convenient to activate the Recently Added limit."
    skipped_info = "\n\n" + skipped_text(missing) if missing else ""
    xbmcgui.Dialog().ok(TITLE, "Applied {} changes.{}{}".format(len(completed), info, skipped_info))


def restore():
    pending_cec_restore_cleanup()
    saved = load_json(ROLLBACK_FILE)
    if not saved or not saved.get("changes"):
        xbmcgui.Dialog().ok(TITLE, "No previous setting changes are available to restore.")
        return
    eligible, skipped, missing = [], [], []
    for item in saved["changes"]:
        if skip_reason(item["operation"]):
            missing.append(item)
            continue
        if (item["operation"]["type"] == "timezone_setting" and
                timezone_settings.backend(rpc) != item["timezone_original"]["backend"]):
            skipped.append(label(item["operation"]) + " (CoreELEC timezone method changed)")
            continue
        try:
            current = read(item["operation"])
        except (cec_settings.CecUnavailable, timezone_settings.TimezoneUnavailable):
            missing.append(item)
            continue
        if current == item["after"] and type(current) is type(item["after"]):
            eligible.append(item)
        else:
            skipped.append(label(item["operation"]))
    message = ["Restore only items last changed by Device Setup:", ""]
    for item in eligible:
        message.append("{}: {} -> {}".format(label(item["operation"]),
                       format_value(item["after"]), format_value(item["before"])))
    if skipped:
        message.append("\nSkipped (changed since application): " + ", ".join(skipped))
    if missing:
        message.extend(["", "Skipped (unavailable):", skipped_text([x["operation"] for x in missing])])
    xbmcgui.Dialog().textviewer(TITLE, "\n".join(message))
    if not eligible:
        xbmcgui.Dialog().ok(TITLE, "Nothing currently safe to restore." +
                          ("\n\n" + skipped_text([x["operation"] for x in missing]) if missing else ""))
        return
    cec_items = [x for x in eligible if x["operation"]["type"] == "cec_setting"]
    ordinary = [x for x in eligible if x["operation"]["type"] != "cec_setting"]
    prompt = "Restore {} previous changes?".format(len(eligible))
    if cec_items:
        prompt += "\n\nA full CoreELEC reboot is required to restore the HDMI-CEC settings."
    if not xbmcgui.Dialog().yesno(TITLE, prompt, nolabel="Cancel", yeslabel="Restore"):
        return
    if cec_items:
        cec_settings.require_no_pending(DATA_DIR)
    restored = []
    try:
        for item in reversed(ordinary):
            if skip_reason(item["operation"]):
                missing.append(item)
                continue
            if item["operation"]["type"] == "timezone_setting" and read(item["operation"]) != item["after"]:
                raise RuntimeError("Timezone changed since restore preview; retry")
            write(item["operation"], item["before"],
                  restore_metadata=item.get("advanced_original", item.get("timezone_original")))
            restored.append(item)
        remaining = missing + cec_items
        if remaining:
            save_json(ROLLBACK_FILE, {"revision": saved["revision"], "changes": remaining})
        else:
            os.remove(ROLLBACK_FILE)
        if os.path.exists(STATE_FILE):
            os.remove(STATE_FILE)
        if cec_items:
            reverse = [{"operation": x["operation"], "before": x["after"], "after": x["before"]}
                       for x in cec_items]
            save_json(CEC_RESTORE_PENDING, {"changes": cec_items})
            # This is the final operation; the timer can now safely restart Kodi.
            cec_settings.schedule(reverse, DATA_DIR, CEC_WORKER)
    except Exception:
        # Keep remaining reversible changes if an earlier write succeeded.
        raise
    if cec_items:
        xbmcgui.Dialog().notification(TITLE, "CEC restore queued. CoreELEC will reboot shortly.",
                                       xbmcgui.NOTIFICATION_INFO, 8000)
        return
    note = "\nReboot CoreELEC to activate the restored Recently Added limit." if any(
        x["operation"]["type"] == "advanced_setting" for x in restored) else ""
    xbmcgui.Dialog().ok(TITLE, "Restored {} changes.{}{}".format(len(restored),
        " Skipped {} manually changed items.".format(len(skipped)) if skipped else "", note))


def edit_device_name(current):
    """Edit Kodi's advertised device name on THIS box, never the GitHub profile."""
    keyboard = xbmc.Keyboard(current, "Device name")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    wanted = keyboard.getText().strip()
    if not wanted:
        xbmcgui.Dialog().ok(TITLE, "Device name cannot be empty. Nothing was changed.")
        return
    if wanted == current:
        return
    write({"type": "kodi_setting", "id": "services.devicename"}, wanted)
    xbmcgui.Dialog().ok(TITLE, "Device name updated to: {}\n\nOnly this box was changed.".format(wanted))


def edit_recently_added_limit():
    """Change the local limit independently of the shared profile."""
    current = advanced_settings.get_limit_state(ADVANCED_FILE)["value"]
    options = list(advanced_settings.CHOICES)
    selected = xbmcgui.Dialog().select("Recently Added items limit",
                                       [str(x) for x in options],
                                       preselect=options.index(current) if current in options else -1)
    if selected < 0:
        return
    chosen = options[selected]
    if chosen == current:
        return
    if not xbmcgui.Dialog().yesno(TITLE,
            "Set the Recently Added movies/episodes limit to {}?\n\n"
            "This changes only this box. Apply My Setup uses the shared profile's value.\n\n"
            "A full CoreELEC reboot is needed to activate the change.".format(chosen),
            nolabel="Cancel", yeslabel="Set"):
        return
    advanced_settings.set_recently_added(
        ADVANCED_FILE, chosen, os.path.join(DATA_DIR, "advancedsettings_backups"))
    xbmcgui.Dialog().ok(TITLE,
        "Recently Added limit set to {}.\n\nReboot CoreELEC when convenient.".format(chosen))



def edit_display_resolution():
    """Change this box's Display > Resolution using Kodi's available modes."""
    info = display_resolution.details(rpc)
    sizes = display_resolution.SIZES
    selected = xbmcgui.Dialog().select(
        "Display resolution - this box", ["1080p (1920x1080)", "4K (3840x2160)"],
        preselect=sizes.index(info["current_size"]) if info["current_size"] in sizes else -1)
    if selected < 0:
        return
    chosen = sizes[selected]
    label = "4K" if chosen[1] == 2160 else "1080p"
    if chosen not in info["choices"]:
        xbmcgui.Dialog().ok(TITLE, "{} is not available in Kodi's Display > Resolution list. Nothing changed.".format(label))
        return
    if chosen == info["current_size"]:
        return
    if not xbmcgui.Dialog().yesno(TITLE,
            "Set this box's Kodi display resolution to {}?\n\n"
            "The TV may briefly go black. Confirm Kodi's keep-resolution prompt, "
            "or it will revert automatically.\n\n"
            "This Quick Setting does not change the GitHub profile.".format(label),
            nolabel="Cancel", yeslabel="Change"):
        return
    display_resolution.set_size(rpc, info, chosen)
    if display_resolution.details(rpc)["current_size"] == chosen:
        xbmcgui.Dialog().ok(TITLE, "Kodi display resolution set to {} on this box.".format(label))
    else:
        xbmcgui.Dialog().ok(TITLE, "Kodi did not retain the {} resolution. Check the TV and try again.".format(label))

def weather_city_label():
    if not xbmc.getCondVisibility("System.HasAddon(weather.openmeteo)"):
        return "Open-Meteo not installed"
    try:
        return xbmcaddon.Addon("weather.openmeteo").getSettingString("loc1") or "Not set"
    except RuntimeError:
        return "Unavailable"


def edit_weather_city():
    if not xbmc.getCondVisibility("System.HasAddon(weather.openmeteo)"):
        xbmcgui.Dialog().ok(TITLE, "Run Apply My Setup to install Open-Meteo, then choose Weather city again.")
        return
    addon = xbmcaddon.Addon("weather.openmeteo")
    current = addon.getSettingString("loc1")
    names = ["{}, Ontario".format(city[0]) for city in weather_city.CITIES]
    preselect = next((i for i, name in enumerate(names) if current in (name, name + ", CA")), -1)
    selected = xbmcgui.Dialog().select("Weather city - this box", names, preselect=preselect)
    if selected < 0:
        return
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "Setting weather city...")
    try:
        city = weather_city.set_city(addon, xbmcvfs.translatePath(addon.getAddonInfo("path")),
                                     selected, rpc, xbmc.Monitor())
    finally:
        progress.close()
    xbmc.executebuiltin("Weather.Refresh")
    xbmcgui.Dialog().ok(TITLE, "Weather city set to {}, Ontario on this box.\n\n"
                       "The forecast will update on Open-Meteo's next check, normally within five minutes.".format(city))


def quick_settings():
    """Manual per-device shortcuts, entirely independent of GitHub sync."""
    current = rpc("Settings.GetSettingValue", {"setting": "services.devicename"})["value"]
    current_limit = advanced_settings.get_limit_state(ADVANCED_FILE)["value"]
    selected = xbmcgui.Dialog().select("Kodi Utilities - Quick Settings",
        ["Device name: {}".format(current),
         "Recently Added items limit: {}".format(current_limit),
         "Weather city: {}".format(weather_city_label()),
          "Display resolution: 1080p / 4K"])
    if selected == 0:
        edit_device_name(current)
    elif selected == 1:
        edit_recently_added_limit()
    elif selected == 2:
        edit_weather_city()
    elif selected == 3:
        edit_display_resolution()


def finalize_cec_reboot():
    changed_keys = cec_settings.reconcile_reboot(DATA_DIR)
    if changed_keys is None:
        return
    # Kodi may save a setting to the requested value during shutdown.
    # The add-on must not claim it changed that value or offer to undo it.
    if not os.path.exists(CEC_RESTORE_PENDING):
        saved = load_json(ROLLBACK_FILE)
        if saved and saved.get("changes"):
            updated = [item for item in saved["changes"]
                       if item["operation"]["type"] != "cec_setting" or
                       item["operation"]["id"] in changed_keys]
            if updated:
                save_json(ROLLBACK_FILE, {"revision": saved["revision"], "changes": updated})
            else:
                os.remove(ROLLBACK_FILE)
    cec_settings.complete_reboot(DATA_DIR)


def check_addon_updates():
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmcgui.Dialog().notification(TITLE, "Checking all add-ons for updates...")


def main():
    try:
        finalize_cec_reboot()
        pending_cec_restore_cleanup()
    except (OSError, RuntimeError, ValueError) as exc:
        xbmc.log("CEC restore status: {}".format(exc), xbmc.LOGWARNING)
    actions = ["Quick Settings", "Preview GitHub Changes", "Apply My Setup",
               "Check My Setup Status", "Check All Add-on Updates", "Restore Previous Settings"]
    selected = xbmcgui.Dialog().select(TITLE, actions)
    if selected < 0:
        return
    try:
        [quick_settings, preview, apply, check, check_addon_updates, restore][selected]()
    except (ProfileError, RuntimeError, OSError, ValueError, KeyError) as exc:
        show_error(exc)
    except Exception as exc:
        # Network exceptions such as URLError can be caught here without mutating settings.
        show_error(exc)


if __name__ == "__main__":
    main()
