"""Manual, opt-in CoreELEC/Kodi configuration sync from an explicit GitHub profile."""

import json
import os
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.profile import ProfileError, digest, parse

TITLE = "Kodi Utilities - Device Setup"
PROFILE_URL = "https://raw.githubusercontent.com/Roboatlas21/Kodi-Utilities/main/device-profiles/shared.json"
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/script.kodi.utilities.setup")
STATE_FILE = os.path.join(DATA_DIR, "state.json")
ROLLBACK_FILE = os.path.join(DATA_DIR, "rollback.json")


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return None


def save_json(path, data):
    os.makedirs(DATA_DIR, exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def rpc(method, params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params
    })))
    if "error" in result:
        raise RuntimeError("{}: {}".format(method, result["error"].get("message", "unknown")))
    return result["result"]


def read(op):
    typ = op["type"]
    if typ == "kodi_setting":
        return rpc("Settings.GetSettingValue", {"setting": op["id"]})["value"]
    if typ == "skin_setting":
        active = rpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})["value"]
        if active != op["skin"]:
            raise RuntimeError("Skin {} must be active before changing {}".format(op["skin"], op["id"]))
        return rpc("Settings.GetSkinSettingValue", {"setting": op["id"]})["value"]
    if typ == "addon_setting":
        addon = xbmcaddon.Addon(op["addon_id"])
        value = op["value"]
        if type(value) is bool:
            return addon.getSettingBool(op["id"])
        if type(value) is int:
            return addon.getSettingInt(op["id"])
        if type(value) is float:
            return addon.getSettingNumber(op["id"])
        return addon.getSettingString(op["id"])
    if typ == "install_addon":
        return bool(xbmc.getCondVisibility("System.HasAddon({})".format(op["id"])))
    raise RuntimeError("Unsupported operation")


def write(op, value):
    typ = op["type"]
    if typ == "kodi_setting":
        result = rpc("Settings.SetSettingValue", {"setting": op["id"], "value": value})
        if result is not True:
            raise RuntimeError("Kodi refused to update {}".format(op["id"]))
    elif typ == "skin_setting":
        active = rpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})["value"]
        if active != op["skin"]:
            raise RuntimeError("Wrong active skin; refusing change")
        result = rpc("Settings.SetSkinSettingValue", {"setting": op["id"], "value": value})
        if result is not True:
            raise RuntimeError("Kodi refused to update skin setting {}".format(op["id"]))
    elif typ == "addon_setting":
        addon = xbmcaddon.Addon(op["addon_id"])
        if type(value) is bool:
            result = addon.setSettingBool(op["id"], value)
        elif type(value) is int:
            result = addon.setSettingInt(op["id"], value)
        elif type(value) is float:
            result = addon.setSettingNumber(op["id"], value)
        else:
            result = addon.setSettingString(op["id"], value)
        if result is False:
            raise RuntimeError("Add-on refused to update {}".format(op["id"]))
    elif typ == "install_addon":
        if not value:
            raise RuntimeError("Removing add-ons is not supported")
        xbmc.executebuiltin("InstallAddon({})".format(op["id"]))
        # Kodi schedules installations asynchronously. Do not report success
        # until Kodi actually exposes the requested add-on.
        monitor = xbmc.Monitor()
        for _ in range(60):
            if xbmc.getCondVisibility("System.HasAddon({})".format(op["id"])):
                break
            if monitor.waitForAbort(1):
                raise RuntimeError("Installation interrupted: {}".format(op["id"]))
        else:
            raise RuntimeError("Installation not verified: {} (Kodi may still finish later)".format(op["id"]))
    else:
        raise RuntimeError("Unsupported operation")


def fetch_profile():
    request = urllib.request.Request(PROFILE_URL, headers={"User-Agent": "KodiUtilitiesDeviceSetup/0.1", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(request, timeout=15) as stream:
        data = stream.read(65537)
    profile = parse(data)
    return profile, digest(data)


def label(op):
    if op["type"] == "skin_setting":
        return "{} / {}".format(op["skin"], op["id"])
    if op["type"] == "addon_setting":
        return "{} / {}".format(op["addon_id"], op["id"])
    return op["id"]


def format_value(value):
    rendered = json.dumps(value, ensure_ascii=False)
    return rendered if len(rendered) < 150 else rendered[:147] + "..."


def plan(profile):
    """Fully preflight all operations before any mutation."""
    result = []
    for op in profile["changes"]:
        current = read(op)
        wanted = True if op["type"] == "install_addon" else op["value"]
        # Type changes are permitted only if the Kodi API itself accepts them.
        if current != wanted or type(current) is not type(wanted):
            result.append({"operation": op, "before": current, "after": wanted})
    return result


def preview_text(profile, changes):
    lines = ["GitHub shared profile — revision {}".format(profile["revision"]),
             "Only explicitly listed entries can be changed.", ""]
    if not changes:
        lines.append("No changes. Your current settings remain untouched.")
    for idx, change in enumerate(changes, 1):
        op = change["operation"]
        lines.append("{}. {} [{}]".format(idx, label(op), op["type"]))
        lines.append("    Current: {}".format(format_value(change["before"])))
        lines.append("    Proposed: {}".format(format_value(change["after"])))
        if op["type"] == "install_addon":
            lines.append("    Installation cannot be automatically undone.")
    return "\n".join(lines)


def show_error(exc):
    xbmc.log("Kodi Utilities Device Setup: {}".format(exc), xbmc.LOGERROR)
    xbmcgui.Dialog().ok(TITLE, "Nothing was applied.\n{}".format(exc))


def check():
    profile, signature = fetch_profile()
    changes = plan(profile)
    state = load_json(STATE_FILE) or {}
    status = ("This revision was applied here." if state.get("signature") == signature else
              "GitHub profile differs from the last applied revision.")
    xbmcgui.Dialog().textviewer(TITLE, "{}\n\n{}".format(status, preview_text(profile, changes)))


def preview():
    profile, _ = fetch_profile()
    changes = plan(profile)
    xbmcgui.Dialog().textviewer(TITLE, preview_text(profile, changes))


def apply():
    profile, signature = fetch_profile()
    changes = plan(profile)
    if not changes:
        xbmcgui.Dialog().ok(TITLE, "No settings to change. Nothing was modified.")
        return
    # Explicit review then confirmation. No install or setting changes before this point.
    xbmcgui.Dialog().textviewer(TITLE, preview_text(profile, changes))
    if not xbmcgui.Dialog().yesno(TITLE, "Apply these {} explicitly listed changes?".format(len(changes)),
                                    "Only these items will be changed. No automatic sync."):
        return
    reversible = [item for item in changes if item["operation"]["type"] != "install_addon"]
    # Rollback snapshot is written BEFORE the first setting change.
    save_json(ROLLBACK_FILE, {"revision": profile["revision"], "changes": reversible})
    completed = []
    try:
        for item in changes:
            # Count an attempted write too: an API may mutate and then fail.
            completed.append(item)
            write(item["operation"], item["after"])
        save_json(STATE_FILE, {"signature": signature, "revision": profile["revision"]})
    except Exception as exc:
        errors = []
        for item in reversed(completed):
            if item["operation"]["type"] != "install_addon":
                try:
                    write(item["operation"], item["before"])
                except Exception as rollback_exc:
                    errors.append("{}: {}".format(label(item["operation"]), rollback_exc))
        raise RuntimeError("Apply failed: {}. {}".format(
            exc, "Restore errors: {}. Snapshot retained.".format("; ".join(errors)) if errors else
            "Attempted setting changes were reverted; install requests cannot be undone."))
    xbmcgui.Dialog().ok(TITLE, "Applied {} changes.\nYou can restore the previous settings if needed.".format(len(changes)))


def restore():
    saved = load_json(ROLLBACK_FILE)
    if not saved or not saved.get("changes"):
        xbmcgui.Dialog().ok(TITLE, "No previous setting changes are available to restore.")
        return
    eligible = []
    skipped = []
    for item in saved["changes"]:
        current = read(item["operation"])
        # Don't overwrite settings manually modified since our apply.
        if current == item["after"] and type(current) is type(item["after"]):
            eligible.append(item)
        else:
            skipped.append(label(item["operation"]))
    message = ["Restore only settings last changed by Device Setup:", ""]
    for item in eligible:
        message.append("{}: {} -> {}".format(label(item["operation"]),
                        format_value(item["after"]), format_value(item["before"])))
    if skipped:
        message.append("\nSkipped (changed since application): " + ", ".join(skipped))
    xbmcgui.Dialog().textviewer(TITLE, "\n".join(message))
    if not eligible:
        xbmcgui.Dialog().ok(TITLE, "Nothing safe to restore.")
        return
    if not xbmcgui.Dialog().yesno(TITLE, "Restore these {} previous values?".format(len(eligible))):
        return
    for item in reversed(eligible):
        write(item["operation"], item["before"])
    os.remove(ROLLBACK_FILE)
    if os.path.exists(STATE_FILE):
        os.remove(STATE_FILE)
    xbmcgui.Dialog().ok(TITLE, "Restored {} settings.{}".format(
        len(eligible), " Skipped {} independently modified settings.".format(len(skipped)) if skipped else ""))


def main():
    actions = ["Preview GitHub Changes", "Apply My Setup", "Check for Updates", "Restore Previous Settings"]
    selected = xbmcgui.Dialog().select(TITLE, actions)
    if selected < 0:
        return
    try:
        [preview, apply, check, restore][selected]()
    except (ProfileError, RuntimeError, OSError, ValueError, KeyError) as exc:
        show_error(exc)
    except Exception as exc:
        # Network exceptions such as URLError can be caught here without mutating settings.
        show_error(exc)


if __name__ == "__main__":
    main()
