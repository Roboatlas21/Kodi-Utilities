"""Pure profile validation. There is deliberately no arbitrary file/script operation."""

import hashlib
import json
import math
import re
from urllib.parse import urlsplit
import ipaddress

ALLOWED = {"kodi_setting", "skin_setting", "addon_setting", "install_addon", "file_source"}
IDENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
# GitHub profiles are PUBLIC. Never accept credentials or machine-local identifiers.
PRIVATE = re.compile(r"(password|passwd|token|api.?key|secret|credential|oauth|session|cookie|authorization|private.?key|device.?id)", re.I)


class ProfileError(ValueError):
    pass


def _file_source(name, url):
    """Only accept a named, public HTTPS repository path without credentials.

    The shared GitHub profile is the approval list: installing the source's ZIP
    and enabling Unknown Sources remain entirely manual Kodi operations.
    """
    if (not isinstance(name, str) or len(name) > 80 or not name or
            not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 ._()\-]*", name) or
            PRIVATE.search(name)):
        raise ProfileError("Invalid File Manager source name")
    if not isinstance(url, str) or len(url) > 512 or any(ch.isspace() for ch in url):
        raise ProfileError("Invalid File Manager source URL")
    try:
        parts = urlsplit(url)
        hostname = parts.hostname
        port = parts.port
    except ValueError as exc:
        raise ProfileError("Invalid File Manager source URL: {}".format(exc))
    if (parts.scheme != "https" or not hostname or port is not None or
            parts.username is not None or parts.password is not None or
            parts.query or parts.fragment or not re.fullmatch(r"[A-Za-z0-9.-]+", hostname) or
            hostname in ("localhost", "localhost.localdomain") or ".." in hostname or
            not "." in hostname or any(ch in parts.path for ch in ("\\", "<", ">", "'", '"'))):
        raise ProfileError("File Manager source must be a public HTTPS URL without credentials")
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        address = None
    if address is not None:
        raise ProfileError("IP-address File Manager sources are not allowed in public profiles")
    return name, url


def _identifier(value, label):
    if not isinstance(value, str) or not IDENT.fullmatch(value):
        raise ProfileError("Invalid {}".format(label))
    if PRIVATE.search(value):
        raise ProfileError("Private {} is not allowed in public profiles".format(label))
    return value


def _value(value):
    if isinstance(value, (dict, list)) or value is None:
        raise ProfileError("Only individual boolean, string, and numeric values are supported")
    if not isinstance(value, (str, int, float, bool)):
        raise ProfileError("Unsupported setting type")
    if isinstance(value, float) and not math.isfinite(value):
        raise ProfileError("Non-finite number")
    if isinstance(value, str) and len(value) > 2048:
        raise ProfileError("Setting value is too long")
    return value


def validate(raw):
    """Validate whole document BEFORE any device state can be changed."""
    if not isinstance(raw, dict) or set(raw) != {"schema", "profile", "revision", "changes"}:
        raise ProfileError("Profile must contain only schema, profile, revision, changes")
    if type(raw["schema"]) is not int or raw["schema"] != 1:
        raise ProfileError("Unsupported profile schema")
    if raw["profile"] != "shared":
        raise ProfileError("Only shared profile is supported")
    if type(raw["revision"]) is not int or raw["revision"] < 0:
        raise ProfileError("Invalid revision")
    changes = raw["changes"]
    if not isinstance(changes, list) or len(changes) > 100:
        raise ProfileError("Changes must be an array of at most 100 items")
    seen = set()
    for i, item in enumerate(changes):
        if not isinstance(item, dict) or item.get("type") not in ALLOWED:
            raise ProfileError("Unsupported operation at index {}".format(i))
        typ = item["type"]
        expected = ({"type", "name", "path"} if typ == "file_source" else
                    {"type", "id", "value"} if typ == "kodi_setting" else
                    {"type", "skin", "id", "value"} if typ == "skin_setting" else
                    {"type", "addon_id", "id", "value"} if typ == "addon_setting" else
                    {"type", "id"})
        if set(item) != expected:
            raise ProfileError("Unexpected/missing fields at index {}".format(i))
        if typ == "file_source":
            _file_source(item["name"], item["path"])
            uniq = (typ, item["name"].casefold())
            key = item["name"]
        else:
            key = _identifier(item["id"], "setting/add-on id")
        if typ == "skin_setting":
            _identifier(item["skin"], "skin id")
            if not item["skin"].startswith("skin."):
                raise ProfileError("Skin id must start with skin.")
            if type(_value(item["value"])) not in (str, bool):
                raise ProfileError("Skin settings must be strings or booleans")
            uniq = (typ, item["skin"], key)
        elif typ == "addon_setting":
            _identifier(item["addon_id"], "addon id")
            _value(item["value"])
            uniq = (typ, item["addon_id"], key)
        elif typ == "kodi_setting":
            _value(item["value"])
            uniq = (typ, key)
        elif typ == "install_addon":
            uniq = (typ, key)
        if uniq in seen:
            raise ProfileError("Duplicate operation: {}".format(key))
        seen.add(uniq)
    return raw


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def parse(data):
    if len(data) > 65536:
        raise ProfileError("Profile too large")
    try:
        return validate(json.loads(data.decode("utf-8")))
    except (ValueError, UnicodeError) as exc:
        raise ProfileError("Invalid profile: {}".format(exc))
