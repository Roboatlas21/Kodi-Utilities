"""Keep a fixed 30-minute idle login timer in Arctic Fuse 3.

This mirrors Roboatlas21/skin.arctic.fuse.3 feat/idle-30m-login. There is no
local setting: after 30 minutes idle, AF3 profile mode opens window 1195 and
Kodi profile mode uses System.LogOff.
"""

import os
import stat
import tempfile
import xml.etree.ElementTree as ET

SKIN_ID = "skin.arctic.fuse.3"
FILENAME = "Timers.xml"
FILENAMES = (FILENAME,)

_TIMER = """    <timer>
        <name>auto_skin_login</name>
        <description>Return to the configured login screen after 30 minutes of inactivity.</description>
        <start reset="true">System.LoggedOn + !Window.IsVisible(1195) + !Window.IsVisible(loginscreen) + !System.HasVisibleModalDialog + [!Player.HasMedia | Player.Paused] + [!Skin.HasSetting(SkinUserLogin.Disabled) | System.HasLoginScreen] + System.IdleTime(1800)</start>
        <stop>Window.IsVisible(1195) | Window.IsVisible(loginscreen) | !System.LoggedOn | !System.IdleTime(1) | [Player.HasMedia + !Player.Paused]</stop>
        <onstart condition="Skin.HasSetting(SkinUserLogin.Disabled)">System.LogOff</onstart>
        <onstart condition="!Skin.HasSetting(SkinUserLogin.Disabled)">ActivateWindow(1195)</onstart>
    </timer>
"""


class PatchError(RuntimeError):
    """Unsupported upstream layout or conflicting timer definition."""


def skin_file(addons_dir):
    return os.path.join(addons_dir, SKIN_ID, "1080i", FILENAME)


def _atomic_write(path, data, mode):
    fd, tmp = tempfile.mkstemp(prefix=".af3-idle-login-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, stat.S_IMODE(mode))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def apply(addons_dir):
    """Return 'changed', 'unchanged' or 'missing'; never overwrite a conflict."""
    path = skin_file(addons_dir)
    if not os.path.isdir(os.path.join(addons_dir, SKIN_ID)):
        return "missing"
    if not os.path.isfile(path):
        raise PatchError("Arctic Fuse Timers.xml is missing")

    with open(path, "rb") as handle:
        original_bytes = handle.read()
    original = original_bytes.decode("utf-8")

    if "<name>auto_skin_login</name>" in original:
        if _TIMER.strip() not in original:
            raise PatchError("Arctic Fuse already defines a different auto_skin_login timer")
        return "unchanged"

    if original.count("<timers>") != 1 or original.count("</timers>") != 1:
        raise PatchError("Arctic Fuse Timers.xml layout changed")
    if original.count("<name>splashtest_autotime</name>") != 1:
        raise PatchError("Arctic Fuse timer anchor changed")

    marker = "</timers>"
    patched = original.replace(marker, _TIMER + marker, 1)
    try:
        ET.fromstring(patched)
    except ET.ParseError as exc:
        raise PatchError("Patched Timers.xml would not parse: {}".format(exc)) from exc

    with open(path, "rb") as handle:
        if handle.read() != original_bytes:
            raise PatchError("Timers.xml changed while applying idle-login fix; retry on next event")

    _atomic_write(path, patched.encode("utf-8"), os.stat(path).st_mode)
    return "changed"
