"""Temporary patched-Kodi test support for CoreELEC.

The patched binary is staged under /storage and bind-mounted over the stock
/usr/lib/kodi/kodi.bin only for the current boot. Reboot always restores stock.
"""

import hashlib
import os
import shutil
import subprocess
import urllib.request

TEST_DIR = "/storage/.config/kodi-utilities/kodi-test"
TEST_BIN = os.path.join(TEST_DIR, "kodi.bin")
STOCK_BIN = "/usr/lib/kodi/kodi.bin"
EXPECTED_SHA256 = "f42aa2d8ada188dcddfa75d8faca610922104c1996f171e72caa8b9163dd935a"
DOWNLOAD_URL = (
    "https://github.com/Roboatlas21/xbmc-p3i/releases/download/"
    "kodi-p3i-window-fallback-arm32-v1/kodi.bin"
)


class KodiTestError(RuntimeError):
    pass


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def supported():
    return (
        os.path.isfile(STOCK_BIN)
        and shutil.which("systemd-run") is not None
        and shutil.which("mount") is not None
        and shutil.which("umount") is not None
        and shutil.which("mountpoint") is not None
    )


def staged():
    return os.path.isfile(TEST_BIN) and sha256_file(TEST_BIN) == EXPECTED_SHA256


def active():
    result = subprocess.run(
        ["mountpoint", "-q", STOCK_BIN],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return result.returncode == 0


def status():
    if not supported():
        return "unsupported"
    if active():
        try:
            return "active" if sha256_file(STOCK_BIN) == EXPECTED_SHA256 else "foreign_mount"
        except OSError:
            return "foreign_mount"
    if os.path.isfile(TEST_BIN):
        try:
            return "staged" if staged() else "corrupt"
        except OSError:
            return "corrupt"
    return "stock"


def stage():
    if not supported():
        raise KodiTestError("Temporary Kodi testing is available only on supported CoreELEC systems")
    if active():
        raise KodiTestError("Restore stock Kodi before refreshing the staged test build")

    os.makedirs(TEST_DIR, exist_ok=True)
    temporary = TEST_BIN + ".part"
    try:
        if os.path.exists(temporary):
            os.unlink(temporary)
        request = urllib.request.Request(
            DOWNLOAD_URL,
            headers={"User-Agent": "KodiUtilities/0.1", "Cache-Control": "no-cache"},
        )
        with urllib.request.urlopen(request, timeout=30) as stream, open(temporary, "wb") as handle:
            copied = 0
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > 64 * 1024 * 1024:
                    raise KodiTestError("Test Kodi download exceeded the expected size")
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())

        actual = sha256_file(temporary)
        if actual != EXPECTED_SHA256:
            raise KodiTestError("Patched Kodi SHA256 verification failed")
        os.chmod(temporary, 0o755)
        os.replace(temporary, TEST_BIN)
        return "changed"
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _run_transient(prefix, script):
    unit = "{}-{}".format(prefix, os.getpid())
    result = subprocess.run(
        ["systemd-run", "--unit=" + unit, "--no-block", "/bin/sh", "-c", script],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise KodiTestError(result.stdout.strip() or "Could not schedule CoreELEC Kodi transition")


def activate():
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    if not staged():
        raise KodiTestError("Download and verify the patched Kodi build first")
    state = status()
    if state == "active":
        return "unchanged"
    if state == "foreign_mount":
        raise KodiTestError("Another bind mount already covers the stock Kodi binary")

    script = r'''set -eu
TEST_BIN="/storage/.config/kodi-utilities/kodi-test/kodi.bin"
STOCK_BIN="/usr/lib/kodi/kodi.bin"
EXPECTED="f42aa2d8ada188dcddfa75d8faca610922104c1996f171e72caa8b9163dd935a"
sleep 1
systemctl stop kodi.service
if ! mount --bind "$TEST_BIN" "$STOCK_BIN"; then
  systemctl start kodi.service
  exit 1
fi
ACTUAL="$(sha256sum "$STOCK_BIN" | awk '{print $1}')"
if [ "$ACTUAL" != "$EXPECTED" ]; then
  umount "$STOCK_BIN" || true
  systemctl start kodi.service
  exit 1
fi
systemctl start kodi.service
'''
    _run_transient("kodi-utilities-test-kodi", script)
    return "scheduled"


def restore_stock():
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    state = status()
    if state == "foreign_mount":
        raise KodiTestError("Refusing to remove an unknown bind mount from the Kodi binary")
    if state != "active":
        return "unchanged"

    script = r'''set -eu
STOCK_BIN="/usr/lib/kodi/kodi.bin"
sleep 1
systemctl stop kodi.service
if mountpoint -q "$STOCK_BIN"; then
  umount "$STOCK_BIN"
fi
systemctl start kodi.service
'''
    _run_transient("kodi-utilities-restore-kodi", script)
    return "scheduled"


def remove_staged():
    if not supported():
        raise KodiTestError("Temporary Kodi testing is unavailable on this system")
    state = status()
    if state == "foreign_mount":
        raise KodiTestError("Refusing to remove an unknown bind mount from the Kodi binary")
    if state == "active":
        script = r'''set -eu
TEST_DIR="/storage/.config/kodi-utilities/kodi-test"
STOCK_BIN="/usr/lib/kodi/kodi.bin"
sleep 1
systemctl stop kodi.service
if mountpoint -q "$STOCK_BIN"; then
  umount "$STOCK_BIN"
fi
rm -rf "$TEST_DIR"
systemctl start kodi.service
'''
        _run_transient("kodi-utilities-remove-test-kodi", script)
        return "scheduled"

    if os.path.isdir(TEST_DIR):
        shutil.rmtree(TEST_DIR)
        return "changed"
    return "unchanged"
