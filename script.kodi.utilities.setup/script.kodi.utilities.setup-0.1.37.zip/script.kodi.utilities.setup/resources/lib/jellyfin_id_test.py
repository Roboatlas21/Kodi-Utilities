"""Temporary, reboot-safe Jellyfin provider ID patch for CoreELEC."""

import ast
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import urllib.request
import xml.etree.ElementTree as ET

ADDON_ID = "plugin.video.jellyfin"
COMMIT = "a7458de946535c1d3971d38dfcb87dd5b5cf5f04"
ROOT = "/storage/.config/kodi-utilities/jellyfin-id-test"
STAGED = os.path.join(ROOT, "addon")
MARKER = ".kodi_utilities_jellyfin_id_test.json"
SUPPORTED_VERSIONS = ("2.2.0+py3",)
FILES = {
    "jellyfin_kodi/objects/kodi/uniqueids.py": "26bedbf70f1b3473c53f1babb6dc7fb41a30fce6",
    "jellyfin_kodi/objects/movies.py": "fcd149a60fd9470e9ed80a9631fc2342c1b38419",
    "jellyfin_kodi/objects/tvshows.py": "3f2e6bae41f07e974ac8660f79d19e3039bb32f6",
    "jellyfin_kodi/objects/obj_map.json": "ce50caf0b3124e8155ef698e3c94455323138c1e",
}
SOURCE_MARKERS = {
    "jellyfin_kodi/objects/movies.py": (
        'obj["Unique"] = self.create_entry_unique_id()',
        'self.add_unique_id(*values(obj, QU.add_unique_id_movie_obj))',
    ),
    "jellyfin_kodi/objects/tvshows.py": (
        'obj["Unique"] = self.create_entry_unique_id()',
        'self.add_unique_id(*values(obj, QU.add_unique_id_episode_obj))',
    ),
    "jellyfin_kodi/objects/obj_map.json": (
        '"UniqueId": "ProviderIds/Imdb"',
        '"UniqueId": "ProviderIds/Tvdb"',
    ),
}
DOWNLOAD_LIMIT = 1024 * 1024


class JellyfinTestError(RuntimeError):
    pass


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git_sha(data):
    header = "blob {}\0".format(len(data)).encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def _file_git_sha(path):
    with open(path, "rb") as handle:
        return _git_sha(handle.read())


def _addon_path():
    import xbmcaddon
    import xbmcvfs

    try:
        path = xbmcvfs.translatePath(
            xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"))
    except RuntimeError as exc:
        raise JellyfinTestError("Jellyfin for Kodi is not installed") from exc
    path = os.path.realpath(path)
    if path != "/storage/.kodi/addons/" + ADDON_ID:
        raise JellyfinTestError("Only the standard CoreELEC add-on directory is supported")
    if not os.path.isfile(os.path.join(path, "addon.xml")):
        raise JellyfinTestError("Jellyfin addon.xml is missing")
    return path


def _version(path):
    tree = ET.parse(os.path.join(path, "addon.xml"))
    addon = tree.getroot()
    if addon.tag != "addon" or addon.get("id") != ADDON_ID:
        raise JellyfinTestError("Unexpected installed add-on")
    return addon.get("version", "")


def _supported():
    return os.access("/proc/self/mountinfo", os.R_OK) and all(
        shutil.which(tool)
        for tool in ("systemd-run", "systemctl", "mount", "umount", "awk")
    )


def _mounted(path):
    # BusyBox mountpoint can miss bind mounts on the same filesystem.
    with open("/proc/self/mountinfo", encoding="utf-8") as mounts:
        for line in mounts:
            fields = line.split(" ", 6)
            if len(fields) > 4 and fields[4] == path:
                return True
    return False


def _marker_valid(path):
    try:
        with open(os.path.join(path, MARKER), encoding="utf-8") as handle:
            meta = json.load(handle)
        return (
            meta.get("commit") == COMMIT
            and meta.get("version") in SUPPORTED_VERSIONS
            and all(_file_git_sha(os.path.join(path, name)) == sha
                    for name, sha in FILES.items())
        )
    except (OSError, ValueError, TypeError):
        return False


def status():
    try:
        target = _addon_path()
        if not _supported():
            return "unsupported"
        if _mounted(target):
            return "active" if _marker_valid(target) else "foreign_mount"
        if _version(target) not in SUPPORTED_VERSIONS:
            return "incompatible"
        if os.path.isdir(STAGED):
            return "staged" if _marker_valid(STAGED) else "stale"
        return "not_downloaded"
    except (JellyfinTestError, OSError, ET.ParseError):
        return "unavailable"


def _check_original(target):
    version = _version(target)
    if version not in SUPPORTED_VERSIONS:
        raise JellyfinTestError(
            "Requires Jellyfin for Kodi {}; found {}".format(
                ", ".join(SUPPORTED_VERSIONS), version))
    for name, markers in SOURCE_MARKERS.items():
        with open(os.path.join(target, name), encoding="utf-8") as handle:
            original = handle.read()
        if not all(marker in original for marker in markers):
            raise JellyfinTestError(
                "Installed Jellyfin source differs at {}; refusing to patch".format(name))
    if os.path.exists(os.path.join(target, "jellyfin_kodi/objects/kodi/uniqueids.py")):
        raise JellyfinTestError("Jellyfin already contains provider-ID changes")
    return version


def _original_hashes(target):
    return {
        name: _sha256(os.path.join(target, name))
        for name in SOURCE_MARKERS
    }


def _download(name, expected_sha):
    url = (
        "https://raw.githubusercontent.com/Roboatlas21/jellyfin-kodi/"
        + COMMIT + "/" + name
    )
    request = urllib.request.Request(
        url, headers={"User-Agent": "KodiUtilities-JellyfinTest/1.0"})
    with urllib.request.urlopen(request, timeout=30) as stream:
        data = stream.read(DOWNLOAD_LIMIT + 1)
    if len(data) > DOWNLOAD_LIMIT or _git_sha(data) != expected_sha:
        raise JellyfinTestError("Patch file verification failed: " + name)
    return data


def _check_patch_imports(target, patches):
    """Reject imports requiring a different installed Jellyfin release."""
    expected = {
        (1, "kodi.uniqueids", "sync_unique_ids"),
        (1, "kodi.uniqueids", "sync_savepoint"),
    }

    def imports(source):
        return {
            (node.level, node.module, alias.name)
            for node in ast.walk(ast.parse(source))
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
        }

    for name in ("jellyfin_kodi/objects/movies.py",
                 "jellyfin_kodi/objects/tvshows.py"):
        with open(os.path.join(target, name), encoding="utf-8") as handle:
            installed = handle.read()
        patched = patches[name].decode("utf-8")
        if imports(patched) - imports(installed) != expected:
            raise JellyfinTestError("Jellyfin patch imports differ from installed " + name)


def stage():
    """Copy the original add-on and add verified patched files, without activating."""
    current = status()
    if current in ("active", "foreign_mount"):
        raise JellyfinTestError("Restore the active add-on before downloading")
    if current == "unsupported":
        raise JellyfinTestError("Temporary tests require CoreELEC mount tools")
    target = _addon_path()
    version = _check_original(target)
    if current == "staged":
        with open(os.path.join(STAGED, MARKER), encoding="utf-8") as handle:
            saved = json.load(handle)
        if (saved.get("original_addon_sha") == _sha256(os.path.join(target, "addon.xml"))
                and saved.get("original_file_hashes") == _original_hashes(target)):
            return "unchanged"

    patches = {name: _download(name, sha) for name, sha in FILES.items()}
    _check_patch_imports(target, patches)
    os.makedirs(ROOT, exist_ok=True)
    candidate = os.path.join(ROOT, "addon.part-{}".format(os.getpid()))
    if os.path.lexists(candidate):
        raise JellyfinTestError("A previous staging operation needs cleanup")
    try:
        shutil.copytree(
            target, candidate,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
        for name, payload in patches.items():
            path = os.path.join(candidate, name)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as handle:
                handle.write(payload)
        marker = {
            "commit": COMMIT,
            "version": version,
            "original_addon_sha": _sha256(os.path.join(target, "addon.xml")),
            "original_file_hashes": _original_hashes(target),
        }
        with open(os.path.join(candidate, MARKER), "w", encoding="utf-8") as handle:
            json.dump(marker, handle)
        if not _marker_valid(candidate):
            raise JellyfinTestError("Staged patch failed verification")
        if os.path.lexists(STAGED):
            if os.path.islink(STAGED):
                raise JellyfinTestError("Unexpected staged directory symlink")
            shutil.rmtree(STAGED)
        os.replace(candidate, STAGED)
        return "changed"
    finally:
        if os.path.isdir(candidate):
            shutil.rmtree(candidate)


def _schedule(label, script):
    result = subprocess.run(
        ["systemd-run", "--unit={}--{}".format(label, os.getpid()),
         "--no-block", "/bin/sh", "-c", script],
        check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        universal_newlines=True,
    )
    if result.returncode != 0:
        raise JellyfinTestError(
            result.stdout.strip() or "Could not schedule Kodi restart")


def activate():
    """Mount the staged Jellyfin copy for this boot only."""
    if status() == "active":
        return "unchanged"
    if status() != "staged":
        raise JellyfinTestError("Download and verify the Jellyfin test patch first")
    target = _addon_path()
    with open(os.path.join(STAGED, MARKER), encoding="utf-8") as handle:
        saved = json.load(handle)
    if (_sha256(os.path.join(target, "addon.xml")) != saved["original_addon_sha"]
            or _original_hashes(target) != saved["original_file_hashes"]):
        raise JellyfinTestError("Installed add-on changed since download")
    script = """set -eu
sleep 1
systemctl stop kodi.service
if [ ! -r /proc/self/mountinfo ]; then
  systemctl start kodi.service
  exit 1
fi
if awk -v target={target} '$5 == target {{ found=1; exit }} END {{ exit !found }}' /proc/self/mountinfo; then
  systemctl start kodi.service
  exit 1
fi
if ! mount --bind {staged} {target}; then
  systemctl start kodi.service
  exit 1
fi
if [ ! -f {marker} ]; then
  umount {target} || true
  systemctl start kodi.service
  exit 1
fi
systemctl start kodi.service
""".format(
        target=shlex.quote(target),
        staged=shlex.quote(STAGED),
        marker=shlex.quote(os.path.join(target, MARKER)))
    _schedule("kodi-utilities-jellyfin-test", script)
    return "scheduled"


def restore(remove=False):
    """Unmount the known patch and restart Kodi; leave the database untouched."""
    current = status()
    if current == "foreign_mount":
        raise JellyfinTestError("Unknown add-on mount; refusing to unmount it")
    if current != "active":
        if remove:
            return remove_staged()
        return "unchanged"
    target = _addon_path()
    script = """set -eu
sleep 1
systemctl stop kodi.service
if [ ! -r /proc/self/mountinfo ]; then
  systemctl start kodi.service
  exit 1
fi
if awk -v target={target} '$5 == target {{ found=1; exit }} END {{ exit !found }}' /proc/self/mountinfo; then
  if [ ! -f {marker} ]; then
    systemctl start kodi.service
    exit 1
  fi
  if ! umount {target}; then
    systemctl start kodi.service
    exit 1
  fi
else
  systemctl start kodi.service
  exit 1
fi
{cleanup}
systemctl start kodi.service
""".format(
        target=shlex.quote(target),
        marker=shlex.quote(os.path.join(target, MARKER)),
        cleanup=("rm -rf " + shlex.quote(STAGED)) if remove else ":")
    _schedule("kodi-utilities-jellyfin-restore", script)
    return "scheduled"


def remove_staged():
    current = status()
    if current in ("active", "foreign_mount"):
        if current == "active":
            return restore(remove=True)
        raise JellyfinTestError("Cannot remove files under an unknown mount")
    if not os.path.lexists(STAGED):
        return "unchanged"
    if os.path.islink(STAGED) or not os.path.isdir(STAGED):
        raise JellyfinTestError("Unexpected staged path; refusing removal")
    shutil.rmtree(STAGED)
    return "changed"
