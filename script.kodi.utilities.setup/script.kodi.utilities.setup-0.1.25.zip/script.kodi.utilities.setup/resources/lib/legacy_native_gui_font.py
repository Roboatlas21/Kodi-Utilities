"""Retire Kodi Utilities' legacy native-4K font workaround when upstream is fixed."""

import os
import shlex
import stat
import subprocess
import tempfile

SHADER = "/usr/share/kodi/system/shaders/GLES/2.0/gles_shader_fonts.frag"
AUTOSTART = "/storage/.config/autostart.sh"
DATA_DIR = "/storage/.kodi/userdata/addon_data/script.kodi.utilities.setup/native_gui_font"
START = b"# BEGIN Kodi Utilities native 4K GUI font fix\n"
END = b"# END Kodi Utilities native 4K GUI font fix\n"
CREATED_HEADER = b"#!/bin/sh\n# Created by Kodi Utilities for the native 4K font fix\n"


def _paths(shader=SHADER, autostart=AUTOSTART, data_dir=DATA_DIR):
    return shader, autostart, os.path.join(data_dir, "boot.sh"), os.path.join(data_dir, "patched.frag")


def _hook(boot):
    return START + ("/bin/sh {} || :\n".format(shlex.quote(boot))).encode("utf-8") + END


def _check_regular(path):
    if os.path.lexists(path) and not stat.S_ISREG(os.lstat(path).st_mode):
        raise RuntimeError("Refusing non-regular file: {}".format(path))


def _atomic_write(path, contents, mode):
    _check_regular(path)
    fd, tmp = tempfile.mkstemp(prefix=".kodi-utilities-cleanup-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as out:
            out.write(contents)
            out.flush()
            os.fsync(out.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _upstream_fixed(shader):
    _check_regular(shader)
    if not os.path.isfile(shader):
        return False
    with open(shader, "rb") as stream:
        source = stream.read(131073)
    if len(source) > 131072:
        return False
    return b"varying highp vec4 m_cord0;" in source


def _active(shader, patch):
    try:
        return os.path.samefile(shader, patch)
    except OSError:
        return False


def cleanup_if_upstream_fixed(shader=SHADER, autostart=AUTOSTART, data_dir=DATA_DIR):
    """Return 'absent', 'still-needed', or 'removed'."""
    shader, autostart, boot, patch = _paths(shader, autostart, data_dir)
    block = _hook(boot)

    for path in (autostart, boot, patch):
        _check_regular(path)

    content = None
    if os.path.exists(autostart):
        with open(autostart, "rb") as stream:
            content = stream.read()
        if (START in content or END in content) and (
                content.count(START) != 1 or content.count(END) != 1 or content.count(block) != 1):
            raise RuntimeError("Legacy native 4K font startup hook was modified; not removing it")

    has_hook = content is not None and block in content
    has_files = os.path.exists(boot) or os.path.exists(patch)
    if not has_hook and not has_files:
        return "absent"

    was_active = _active(shader, patch)
    if was_active:
        subprocess.run(["umount", shader], check=True, timeout=10)

    if not _upstream_fixed(shader):
        if was_active:
            if not os.path.isfile(patch):
                raise RuntimeError("Legacy font overlay disappeared during cleanup")
            subprocess.run(["mount", "--bind", patch, shader], check=True, timeout=10)
        return "still-needed"

    if has_hook:
        remaining = content.replace(block, b"", 1)
        if remaining == CREATED_HEADER:
            os.unlink(autostart)
        else:
            _atomic_write(autostart, remaining, stat.S_IMODE(os.stat(autostart).st_mode))

    for path in (boot, patch):
        _check_regular(path)
        if os.path.exists(path):
            os.unlink(path)
    if os.path.isdir(data_dir) and not os.listdir(data_dir):
        os.rmdir(data_dir)
    return "removed"
