"""Read-only, opt-in GUI timing capture using Kodi's built-in control profiler.

Kodi 21 handles Action(guiprofile) and writes special://home/guiprofiler.xml
after 200 rendered frames. This module does not touch Kodi settings, patch a
skin, reload Kodi, or enable any background sampling. Results identify GUI
control render/visibility hotspots, NOT individual GUIInfoManager label times.
"""

import datetime
import json
import os
import stat
import xml.etree.ElementTree as ET

MAX_PROFILE_BYTES = 8 * 1024 * 1024
MAX_CONTROLS = 20000
OUTPUT_NAME = "guiprofiler.xml"
REQUEST_NAME = "gui-profiler-request.json"


class GUIProfilerError(RuntimeError):
    pass


def _fingerprint(path):
    """Identify a completed capture without changing an existing profile file."""
    try:
        entry = os.stat(path, follow_symlinks=False)
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(entry.st_mode):
        raise GUIProfilerError("Kodi's GUI profile output is not a regular file")
    if entry.st_size > MAX_PROFILE_BYTES:
        raise GUIProfilerError("Kodi's GUI profile output exceeds the 8 MiB limit")
    return [entry.st_mtime_ns, entry.st_size, entry.st_ino]


def _request_path(data_dir):
    return os.path.join(data_dir, REQUEST_NAME)


def _read_request(data_dir):
    try:
        with open(_request_path(data_dir), "r", encoding="utf-8") as handle:
            record = json.load(handle)
        return record if isinstance(record, dict) and record.get("version") == 1 else None
    except (FileNotFoundError, ValueError, OSError):
        return None


def _save_request(data_dir, record):
    os.makedirs(data_dir, mode=0o700, exist_ok=True)
    filename = _request_path(data_dir)
    temp = filename + ".tmp"
    try:
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(record, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, filename)
    finally:
        if os.path.isfile(temp):
            os.unlink(temp)


def capture_status(output_file, data_dir):
    """Return missing/pending/ready; never mistake an old XML for a new capture."""
    signature = _fingerprint(output_file)
    record = _read_request(data_dir)
    if signature is None:
        return "pending" if record else "missing"
    if record and signature == record.get("previous_signature"):
        return "pending"
    return "ready"


def _positive_int(value, field):
    try:
        number = int(value)
    except (ValueError, TypeError):
        raise GUIProfilerError("Invalid GUI profile {} value".format(field))
    if number < 0:
        raise GUIProfilerError("Negative GUI profile {} value".format(field))
    return number


def analyze_xml(data):
    """Parse Kodi's saved hierarchy and rank approximate exclusive control costs."""
    if len(data) > MAX_PROFILE_BYTES:
        raise GUIProfilerError("GUI profile exceeds the 8 MiB limit")
    if b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
        raise GUIProfilerError("Unsupported XML declaration in GUI profile")
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise GUIProfilerError("Incomplete or invalid GUI profile: {}".format(exc))
    if root.tag != "guicontrolprofiler" or root.get("timeunit") != "ms":
        raise GUIProfilerError("This is not Kodi's GUI control profiler output")
    frames = _positive_int(root.get("framecount"), "framecount")
    if not 1 <= frames <= 100000:
        raise GUIProfilerError("Unexpected number of profiled frames")
    head = root.find("control")
    if head is None:
        raise GUIProfilerError("GUI profile contains no control tree")

    rows = []

    def walk(control, ancestry):
        if len(rows) >= MAX_CONTROLS:
            raise GUIProfilerError("GUI profile contains too many controls")
        render = _positive_int(control.findtext("rendertime", default="0"), "render time")
        visibility = _positive_int(control.findtext("visibletime", default="0"), "visibility time")
        kind = (control.get("type") or "root")[:40]
        ident = (control.get("id") or "")[:20]
        description = (control.findtext("description") or "").strip()[:120]
        name = "{}{}{}".format(kind, " #" if ident else "", ident)
        path = ancestry + (name,)
        row = {
            "name": name,
            "path": " / ".join(path[-5:]),
            "description": description,
            "inclusive_render_ms": render,
            "inclusive_visibility_ms": visibility,
            "exclusive_render_ms": 0,
            "exclusive_visibility_ms": 0,
        }
        rows.append(row)
        child_render = child_visibility = 0
        children = control.find("children")
        if children is not None:
            for child in children.findall("control"):
                cr, cv = walk(child, path)
                child_render += cr
                child_visibility += cv
        row["exclusive_render_ms"] = max(0, render - child_render)
        row["exclusive_visibility_ms"] = max(0, visibility - child_visibility)
        return render, visibility

    try:
        total_render, total_visibility = walk(head, ())
    except RecursionError:
        raise GUIProfilerError("GUI profile control nesting exceeds supported depth")
    return {
        "frames": frames,
        "root_render_ms": total_render,
        "root_visibility_ms": total_visibility,
        "controls": len(rows),
        "rows": rows,
    }


def _top_rows(report, count=20):
    return sorted(
        (row for row in report["rows"] if row["name"] != "root"),
        key=lambda row: (
            row["exclusive_render_ms"] + row["exclusive_visibility_ms"],
            row["inclusive_render_ms"] + row["inclusive_visibility_ms"]),
        reverse=True,
    )[:count]


def format_report(report, metadata=None):
    metadata = metadata or {}
    lines = [
        "KODI GUI PERFORMANCE DIAGNOSTIC",
        "Skin: {}".format(metadata.get("skin") or "unknown"),
        "Kodi version: {}".format(metadata.get("kodi") or "unknown"),
        "Capture started: {}".format(metadata.get("started_utc") or "unknown"),
        "Frames captured: {}".format(report["frames"]),
        "Control nodes: {}".format(report["controls"]),
        "",
        "Kodi cumulative control totals (not wall-clock frame time):",
        "Render: {} ms | Visibility: {} ms".format(
            report["root_render_ms"], report["root_visibility_ms"]),
        "",
        "TOP CONTROLS — APPROXIMATE EXCLUSIVE COST",
        "Render and visibility are measured by Kodi's built-in GUI control profiler.",
        "Parent times can include descendants; the exclusive values subtract",
        "direct child totals. All times are cumulative across the capture.",
        "",
    ]
    rows = _top_rows(report)
    if not rows:
        lines.append("No timed GUI controls found.")
    for number, row in enumerate(rows, 1):
        lines.append("{:2d}. {:6d} ms own render + {:6d} ms own visibility".format(
            number, row["exclusive_render_ms"], row["exclusive_visibility_ms"]))
        lines.append("    {}".format(row["path"]))
        if row["description"]:
            lines.append("    {}".format(row["description"]))
    lines += [
        "",
        "LIMITATIONS",
        "- Does not time individual $INFO/$VAR evaluations or provider functions.",
        "- Does not measure time spent loading widgets, Python work, or disk I/O.",
        "- Profiles alter timing slightly; compare repeated captures.",
        "- Profile lasts 200 GUI frames (about 3.3 s at 60 FPS).",
        "- The most expensive control is not necessarily the main bottleneck.",
    ]
    return "\n".join(lines)


def read_profile(output_file, data_dir):
    if capture_status(output_file, data_dir) != "ready":
        raise GUIProfilerError("No completed new capture. Start a capture, then return here.")
    with open(output_file, "rb") as handle:
        payload = handle.read(MAX_PROFILE_BYTES + 1)
    report = analyze_xml(payload)
    metadata = _read_request(data_dir) or {}
    return payload, report, metadata


def save_report(data_dir, payload, report, metadata):
    """Write private report copies without touching Kodi's guiprofiler.xml."""
    folder = os.path.join(data_dir, "gui-profiles")
    os.makedirs(folder, mode=0o700, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    stem = os.path.join(folder, "gui-profile-" + stamp)
    summary = format_report(report, metadata)
    for suffix, data in (
        (".xml", payload),
        (".txt", summary.encode("utf-8")),
        (".json", json.dumps(
            {"capture": metadata, "frames": report["frames"],
             "root_render_ms": report["root_render_ms"],
             "root_visibility_ms": report["root_visibility_ms"],
             "controls": report["controls"], "rows": report["rows"]},
            indent=2, ensure_ascii=False).encode("utf-8")),
    ):
        with open(stem + suffix, "xb") as handle:
            handle.write(data)
    return stem


def _paths():
    import xbmcvfs
    output = xbmcvfs.translatePath("special://home/" + OUTPUT_NAME)
    data = xbmcvfs.translatePath(
        "special://profile/addon_data/script.kodi.utilities.setup")
    return output, data


def start_capture():
    import xbmc
    import xbmcgui

    output, data = _paths()
    record = {
        "version": 1,
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "previous_signature": _fingerprint(output),
        "skin": xbmc.getSkinDir(),
        "kodi": xbmc.getInfoLabel("System.BuildVersion"),
    }
    _save_request(data, record)
    # Kodi 21's CApplication handles ACTION_GUIPROFILE_BEGIN and automatically
    # writes guiprofiler.xml after 200 GUI frames. No patched kodi.bin needed.
    xbmc.executebuiltin("Action(guiprofile)")
    xbmcgui.Dialog().notification(
        "Kodi GUI Profiler", "200-frame capture started. Navigate AF3 now.",
        xbmcgui.NOTIFICATION_INFO, 4500)


def view_capture():
    import xbmcgui
    output, data = _paths()
    _, report, metadata = read_profile(output, data)
    xbmcgui.Dialog().textviewer(
        "Kodi GUI Performance — {}".format(report["frames"]) + " frames",
        format_report(report, metadata))


def export_capture():
    import xbmcgui
    output, data = _paths()
    payload, report, metadata = read_profile(output, data)
    stem = save_report(data, payload, report, metadata)
    xbmcgui.Dialog().ok(
        "Kodi GUI Profiler",
        "Saved the original XML, ranked text report and machine-readable JSON.\n\n"
        "{}\n\nRead-only report. No Kodi or AF3 settings were modified.".format(stem))


def menu():
    import xbmcgui
    output, data = _paths()
    state = capture_status(output, data)
    caption = {
        "ready": "Completed capture available",
        "pending": "Waiting for new 200-frame capture",
        "missing": "No capture available",
    }[state]
    actions = [
        ("Start 200-frame GUI timing capture", start_capture),
        ("View last capture ({})".format(caption), view_capture),
        ("Save capture as XML + ranked TXT + JSON", export_capture),
        ("About GUI profiler", lambda: xbmcgui.Dialog().ok(
            "Kodi GUI Profiler",
            "Kodi's built-in GUI profiler measures control rendering and "
            "visibility evaluation for 200 frames. After starting, navigate "
            "the screen you want to test, then return to View or Save.\n\n"
            "It cannot measure individual GUI label lookup costs. That would "
            "require a separate instrumented Kodi test binary.")),
    ]
    index = xbmcgui.Dialog().select(
        "Kodi Utilities — GUI Performance", [label for label, _ in actions])
    if index >= 0:
        actions[index][1]()
