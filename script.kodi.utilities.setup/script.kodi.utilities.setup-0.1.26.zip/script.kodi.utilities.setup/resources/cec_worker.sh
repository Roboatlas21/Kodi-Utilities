#!/bin/sh
# Runs in a transient systemd unit, outside Kodi's service cgroup.
# Only the two specifically approved CEC keys may be changed.
set -eu
PLAN=$1
FILE=$2
STATUS=$3
LOG=$4
TMP=""
CHANGED_TMP=""
KODI_STOPPED=0
ERROR=""

fail() {
  ERROR=$1
  printf '%s\n' "ERROR: $ERROR" >> "$LOG"
  exit 1
}

finish() {
  exitcode=$?
  trap - EXIT HUP INT TERM
  set +e  # Recovery must still run if status/log/sync encounters an error.
  if [ -n "$TMP" ] && [ -f "$TMP" ]; then rm -f "$TMP"; fi
  if [ -n "$CHANGED_TMP" ] && [ -f "$CHANGED_TMP" ]; then rm -f "$CHANGED_TMP"; fi
  if [ "$exitcode" -eq 0 ]; then
    result_status=done
  else
    [ -n "$ERROR" ] || ERROR="CEC helper failed; inspect cec_job.log"
    result_status="error:$ERROR"
  fi
  if [ "$KODI_STOPPED" = 1 ]; then
    # Restarting Kodi alone can leave an Amlogic HDMI output with no signal.
    # Save the result BEFORE asking systemd to shut down this transient unit.
    if [ "$exitcode" -eq 0 ]; then result_status=rebooting; fi
    printf '%s\n' "$result_status" > "$STATUS"
    printf '%s\n' 'CEC helper requesting full CoreELEC reboot' >> "$LOG"
    sync
    if systemctl reboot >> "$LOG" 2>&1; then
      exit "$exitcode"
    fi
    # Reboot failed: recover the Kodi UI if possible and report the failure.
    ERROR="Full CoreELEC reboot request failed; check cec_job.log"
    if ! systemctl start kodi >> "$LOG" 2>&1; then
      ERROR="$ERROR; Kodi could not restart (run systemctl start kodi over SSH)"
    fi
    printf 'error:%s\n' "$ERROR" > "$STATUS"
    exit 1
  fi
  printf '%s\n' "$result_status" > "$STATUS"
  exit "$exitcode"
}
trap finish EXIT

printf '%s\n' "CEC helper starting" > "$LOG"
[ -f "$PLAN" ] && [ ! -L "$PLAN" ] || fail "Missing or unsafe plan file"
[ -f "$FILE" ] && [ ! -L "$FILE" ] || fail "CEC preferences file missing or unsafe"
[ -n "${FILE##*/}" ] || fail "Invalid CEC file"
case "${FILE##*/}" in cec_*.xml) ;; *) fail "Unexpected CEC filename";; esac

# Validate entire plan before stopping Kodi.
count=0
while read -r key old new extra; do
  [ -n "$key" ] || fail "Empty CEC plan line"
  [ -z "${extra:-}" ] || fail "Invalid CEC plan line"
  case "$key" in
    standby_pc_on_tv_standby)
      case "$old" in 36028|13005|13011|13010|13009|36044|36045) ;; *) fail "Invalid old TV standby option";; esac
      case "$new" in 36028|13005|13011|13010|13009|36044|36045) ;; *) fail "Invalid new TV standby option";; esac
      ;;
    pause_or_stop_playback_on_deactivate)
      case "$old" in 231|36044|36045) ;; *) fail "Invalid old source-change option";; esac
      case "$new" in 231|36044|36045) ;; *) fail "Invalid new source-change option";; esac
      ;;
    *) fail "Unapproved CEC setting";;
  esac
  count=$((count+1))
done < "$PLAN"
[ "$count" -ge 1 ] && [ "$count" -le 2 ] || fail "CEC plan must contain one or two changes"

printf '%s\n' 'running' > "$STATUS"
KODI_STOPPED=1
if ! systemctl stop kodi >> "$LOG" 2>&1; then fail "Could not stop Kodi"; fi
[ -f "$FILE" ] && [ ! -L "$FILE" ] || fail "CEC preferences changed during shutdown"
# Kodi can migrate an adapter's old filename to a location-specific filename
# at shutdown. Never accidentally patch a stale legacy copy.
cec_count=0
for candidate in "${FILE%/*}"/cec_*.xml; do
  if [ -f "$candidate" ] && [ ! -L "$candidate" ]; then
    cec_count=$((cec_count+1))
  fi
done
[ "$cec_count" = 1 ] || fail "CEC adapter files changed during Kodi shutdown; preview again"

# Create the new XML beside the existing file so final rename is atomic.
TMP="${FILE}.kodi-utilities.$$"
CHANGED="${STATUS}.changed"
CHANGED_TMP="${CHANGED}.$$"
: > "$CHANGED_TMP" || fail "Cannot stage CEC job results"
cp -p "$FILE" "$TMP" || fail "Cannot stage CEC preferences"
while read -r key old new extra; do
  # Kodi persists each setting as <setting id="..." value="..." />.
  # Require exactly one record and the expected value after Kodi saves.
  matches=$(grep -c "<setting id=\"${key}\" value=\"" "$TMP" || true)
  [ "$matches" = 1 ] || fail "CEC key missing or duplicated after shutdown: $key"
  if grep -q "<setting id=\"${key}\" value=\"${new}\"" "$TMP"; then
    # Kodi may save the target value itself when it closes; do not reject it.
    printf 'Already at requested value: %s\n' "$key" >> "$LOG"
    continue
  fi
  if ! grep -q "<setting id=\"${key}\" value=\"${old}\"" "$TMP"; then
    fail "CEC value changed to an unexpected value during shutdown: $key. Preview again"
  fi
  sed "s|<setting id=\"${key}\" value=\"${old}\"|<setting id=\"${key}\" value=\"${new}\"|" "$TMP" > "${TMP}.new" || fail "CEC XML update failed"
  mv -f "${TMP}.new" "$TMP" || fail "CEC XML staging failed"
  printf '%s\n' "$key" >> "$CHANGED_TMP" || fail "Cannot record CEC change"
  printf 'Changed CEC value: %s (%s -> %s)\n' "$key" "$old" "$new" >> "$LOG"
done < "$PLAN"

# Keep a full original backup, but never restore that whole file as a normal
# undo operation (the Kodi addon restores approved keys only).
BACKUP="${FILE}.kodi-utilities-backup"
cp -p "$FILE" "$BACKUP" || fail "Could not back up CEC preferences"
mv -f "$TMP" "$FILE" || fail "Could not save CEC preferences"
TMP=""
mv -f "$CHANGED_TMP" "$CHANGED" || fail "Could not save CEC job results"
CHANGED_TMP=""
printf '%s\n' 'CEC preferences saved; preparing full CoreELEC reboot' >> "$LOG"
