"""Keep a small, reversible startup title override in the installed skin."""

import json
import os
import re
import stat
import tempfile
import xml.etree.ElementTree as ET

SKIN_ID = "skin.arctic.fuse.3"
FILENAME = "Includes_Objects.xml"
_BACKUP_NAME = "startup_branding_backup.json"
_CONFIG_NAME = "startup_branding.json"
_BEGIN = '<include name="Object_StartUp_Logo">'
_TITLE_GROUP = '<control type="grouplist">'
_WEATHER_GROUP = '<control type="group">'
_LABEL = re.compile(r'(?P<indent>^[ \t]*)<control type="label">.*?</control>\n?', re.M | re.S)
_CUSTOM_LABELS = ("<label>Rocket</label>", "<label>Cloud</label>")


class BrandingError(RuntimeError):
    """Unsupported upstream layout or a write that cannot be made safely."""


def is_enabled(data_dir):
    path = os.path.join(data_dir, _CONFIG_NAME)
    if not os.path.exists(path):
        return True  # Keep automatic startup title customization enabled by default.
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)["enabled"] is True
    except (OSError, ValueError, KeyError, TypeError):
        return False  # A damaged preference must not silently enable modifications.


def set_enabled(data_dir, enabled):
    _save_json(os.path.join(data_dir, _CONFIG_NAME), {"enabled": enabled})


def skin_file(addons_dir):
    return os.path.join(addons_dir, SKIN_ID, "1080i", FILENAME)


def _title_bounds(content):
    """Limit the edit to the startup title, never similarly named UI labels."""
    start = content.find(_BEGIN)
    if start < 0 or content.find(_BEGIN, start + len(_BEGIN)) >= 0:
        raise BrandingError("Arctic Fuse startup logo include was not found uniquely")
    include_end = content.find('\n    </include>', start)
    if include_end < 0:
        raise BrandingError("Arctic Fuse startup logo include has changed")
    logo = content[start:include_end]
    first_group = logo.find(_TITLE_GROUP)
    title_start = logo.find(_TITLE_GROUP, first_group + len(_TITLE_GROUP))
    title_end = logo.find(_WEATHER_GROUP, title_start)
    if first_group < 0 or title_start < 0 or title_end <= title_start:
        raise BrandingError("Arctic Fuse startup title layout has changed")
    return start + title_start, start + title_end


def _replace_title(content, new_title):
    a, b = _title_bounds(content)
    updated = content[:a] + new_title + content[b:]
    try:
        ET.fromstring(updated)
    except ET.ParseError as exc:
        raise BrandingError("Modified skin XML would not parse: {}".format(exc)) from exc
    return updated


def _branded_title(title):
    matches = list(_LABEL.finditer(title))
    if len(matches) != 3:
        raise BrandingError("Arctic Fuse startup title no longer has three labels")
    labels = ("<label>Arctic</label>", "<label>Fuse</label>", "<label>$NUMBER[3]</label>")
    if any(item not in match.group() for item, match in zip(labels, matches)):
        raise BrandingError("Arctic Fuse startup title has been customized or changed")
    if title.count("<itemgap>10</itemgap>") != 1:
        raise BrandingError("Arctic Fuse startup label spacing has changed")
    first, second, third = matches
    result = title[:third.start()] + title[third.end():]
    result = result.replace(labels[0], _CUSTOM_LABELS[0], 1)
    result = result.replace(labels[1], _CUSTOM_LABELS[1], 1)
    return result.replace("<itemgap>10</itemgap>", "<itemgap>0</itemgap>", 1)


def _save_json(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    _atomic_write(path, (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def _atomic_write(path, data, mode=None):
    fd, tmp = tempfile.mkstemp(prefix=".startup-title-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        if mode is not None:
            os.chmod(tmp, stat.S_IMODE(mode))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _write_if_unchanged(path, old, new):
    with open(path, "rb") as handle:
        if handle.read() != old:
            raise BrandingError("Skin changed during branding update; retry on next event")
    _atomic_write(path, new, os.stat(path).st_mode)


def apply(addons_dir, data_dir):
    """Return 'changed', 'unchanged' or 'missing'; never touch unknown layouts."""
    path = skin_file(addons_dir)
    if not os.path.isfile(path):
        return "missing"
    with open(path, "rb") as handle:
        original_bytes = handle.read()
    original = original_bytes.decode("utf-8")
    a, b = _title_bounds(original)
    title = original[a:b]
    if (_CUSTOM_LABELS[0] in title and
            _CUSTOM_LABELS[1] in title and
            "<label>$NUMBER[3]</label>" not in title):
        return "unchanged"
    patched_title = _branded_title(title)
    patched = _replace_title(original, patched_title)
    _save_json(os.path.join(data_dir, _BACKUP_NAME), {
        "original_title": title, "patched_title": patched_title,
    })
    _write_if_unchanged(path, original_bytes, patched.encode("utf-8"))
    return "changed"


def restore(addons_dir, data_dir):
    """Restore exactly the title we replaced, if it is still our own patch."""
    path = skin_file(addons_dir)
    if not os.path.isfile(path):
        return "missing"
    with open(path, "rb") as handle:
        current_bytes = handle.read()
    current = current_bytes.decode("utf-8")
    a, b = _title_bounds(current)
    title = current[a:b]
    if "<label>Arctic</label>" in title and "<label>Fuse</label>" in title:
        return "unchanged"
    backup_path = os.path.join(data_dir, _BACKUP_NAME)
    try:
        with open(backup_path, "r", encoding="utf-8") as handle:
            backup = json.load(handle)
    except (OSError, ValueError):
        raise BrandingError("No original branding backup is available")
    if title != backup.get("patched_title"):
        raise BrandingError("Startup title changed since branding was applied; not restoring")
    restored = _replace_title(current, backup["original_title"])
    _write_if_unchanged(path, current_bytes, restored.encode("utf-8"))
    return "changed"
