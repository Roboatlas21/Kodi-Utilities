"""Targeted, reversible management of Kodi's Recently Added item count.

This module only accesses the single supported setting under <videolibrary> in
advancedsettings.xml. It preserves unrelated nodes, comments and processing
instructions, rejects ambiguous input, and makes atomic writes plus backups.
"""

import os
import re
import stat
import tempfile
import xml.etree.ElementTree as ET

DEFAULT_RECENTLY_ADDED = 25
CHOICES = (25, 50, 75, 100)
MAX_XML_BYTES = 1024 * 1024


def _load(path):
    if os.path.islink(path):
        raise RuntimeError("advancedsettings.xml is a symlink; refusing to modify it")
    if not os.path.exists(path):
        return ET.Element("advancedsettings"), b"", False
    if not os.path.isfile(path):
        raise RuntimeError("advancedsettings.xml is not a regular file")
    with open(path, "rb") as handle:
        data = handle.read(MAX_XML_BYTES + 1)
    if len(data) > MAX_XML_BYTES:
        raise RuntimeError("advancedsettings.xml is unexpectedly large")
    if b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
        raise RuntimeError("advancedsettings.xml contains unsupported XML declarations")
    try:
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True, insert_pis=True))
        root = ET.fromstring(data, parser=parser)
    except ET.ParseError as exc:
        raise RuntimeError("advancedsettings.xml is malformed: {}".format(exc))
    if root.tag != "advancedsettings":
        raise RuntimeError("Unexpected advancedsettings.xml root element")
    return root, data, True


def _locate(root):
    groups = root.findall("videolibrary")
    if len(groups) > 1:
        raise RuntimeError("Duplicate videolibrary sections; refusing to modify")
    group = groups[0] if groups else None
    entries = group.findall("recentlyaddeditems") if group is not None else []
    if len(entries) > 1:
        raise RuntimeError("Duplicate recentlyaddeditems entries; refusing to modify")
    entry = entries[0] if entries else None
    if entry is not None and (len(entry) or entry.attrib):
        raise RuntimeError("Unexpected recentlyaddeditems structure; refusing to modify")
    return group, entry


def get_limit_state(path):
    """Return effective value and metadata for exact restoration after apply."""
    root, _, exists = _load(path)
    group, entry = _locate(root)
    if entry is None:
        limit = DEFAULT_RECENTLY_ADDED
    else:
        data = (entry.text or "").strip()
        if not re.fullmatch(r"[0-9]+", data):
            raise RuntimeError("Recently Added value is not a valid positive integer")
        limit = int(data)
        if not 1 <= limit <= 2147483647:
            raise RuntimeError("Recently Added value is out of range")
    return {"value": limit, "file_present": exists,
            "section_present": group is not None, "entry_present": entry is not None}


def _is_empty(element):
    return (not list(element) and not element.attrib and
            not (element.text or "").strip())


def _backup(original, backup_dir):
    os.makedirs(backup_dir, mode=0o700, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix="advancedsettings-before-", suffix=".xml.bak", dir=backup_dir)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(original)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        if os.path.exists(name):
            os.unlink(name)
        raise
    return name


def set_recently_added(path, value, backup_dir, restore_metadata=None):
    """Update only recentlyaddeditems; undo removes an entry we originally added."""
    if type(value) is not int or value not in CHOICES:
        raise RuntimeError("Unsupported Recently Added limit")
    if restore_metadata is not None:
        if (not isinstance(restore_metadata, dict) or
                set(restore_metadata) != {"file_present", "section_present", "entry_present"} or
                any(type(item) is not bool for item in restore_metadata.values())):
            raise RuntimeError("Invalid original advancedsettings.xml metadata")

    root, before, existed = _load(path)
    group, entry = _locate(root)
    if entry is not None:
        current = (entry.text or "").strip()
        if not re.fullmatch(r"[0-9]+", current) or not 1 <= int(current) <= 2147483647:
            raise RuntimeError("Recently Added value is invalid; refusing to overwrite it")
    # Restore previously absent setting as absence, not an added explicit 25.
    remove = restore_metadata is not None and not restore_metadata["entry_present"]
    if remove:
        if entry is None:
            return False
        group.remove(entry)
        if not restore_metadata["section_present"] and _is_empty(group):
            root.remove(group)
    else:
        if group is None:
            group = ET.SubElement(root, "videolibrary")
        if entry is None:
            entry = ET.SubElement(group, "recentlyaddeditems")
        if (entry.text or "").strip() == str(value):
            return False
        entry.text = str(value)

    # Only remove an originally nonexistent file if it is empty other than
    # the section created by this add-on; leave subsequent user edits alone.
    should_delete = (remove and not restore_metadata["file_present"] and
                     _is_empty(root))
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        raise RuntimeError("Kodi userdata directory is missing")
    _backup(before, backup_dir)
    if should_delete:
        os.unlink(path)
        return True
    after = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    fd, tmp = tempfile.mkstemp(prefix=".advancedsettings-kodi-utilities-", suffix=".xml", dir=parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            os.fchmod(handle.fileno(), stat.S_IMODE(os.stat(path).st_mode) if existed else 0o644)
            handle.write(after)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return True
