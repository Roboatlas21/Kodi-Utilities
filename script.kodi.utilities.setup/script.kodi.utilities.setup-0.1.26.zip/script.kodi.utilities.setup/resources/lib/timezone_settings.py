"""Version-aware, paired country/timezone changes for CoreELEC 21 and 22."""

import os
import re
import shutil
import subprocess
import tempfile
import time

OS_RELEASE = "/etc/os-release"
TIMEZONE_FILE = "/storage/.cache/timezone"
ZONEINFO = "/usr/share/zoneinfo"
LOCALTIME = "/var/run/localtime"
UNIT = "/usr/lib/systemd/system/tz-data.service"
COUNTRY_ID = "locale.timezonecountry"
ZONE_ID = "locale.timezone"


class TimezoneUnavailable(RuntimeError):
    pass


def device_info():
    values = {}
    try:
        with open(OS_RELEASE, encoding="utf-8") as handle:
            for line in handle:
                key, sep, value = line.strip().partition("=")
                if sep and key in ("ID", "VERSION_ID", "VERSION"):
                    values[key] = value.strip('"\'')
    except FileNotFoundError:
        pass
    version = values.get("VERSION_ID", "")
    match = re.match(r"^(\d+)(?:\.|$|-)", version)
    return {"coreelec": values.get("ID", "").lower() == "coreelec",
            "major": int(match.group(1)) if match else None,
            "version": values.get("VERSION", version) or "unknown"}


def description():
    info = device_info()
    return "CoreELEC {}".format(info["version"]) if info["coreelec"] else "CoreELEC version not detected"


def setting_ids(rpc):
    result = rpc("Settings.GetSettings", {"level": "expert"})
    return {item["id"] for item in result["settings"]}


def backend(rpc):
    info = device_info()
    if not info["coreelec"] or info["major"] not in (21, 22):
        raise TimezoneUnavailable("Timezone setup supports detected CoreELEC 21 or 22 only")
    available = setting_ids(rpc)
    if {COUNTRY_ID, ZONE_ID} <= available:
        return "kodi"
    if info["major"] == 21 or {COUNTRY_ID, ZONE_ID} & available:
        raise TimezoneUnavailable("This build does not expose both Kodi timezone settings")
    if not os.path.isfile(UNIT) or not shutil.which("systemctl"):
        raise TimezoneUnavailable("CoreELEC tz-data service is unavailable")
    for name in ("zone.tab", "iso3166.tab", "America/Toronto"):
        if not os.path.isfile(os.path.join(ZONEINFO, name)):
            raise TimezoneUnavailable("CoreELEC timezone data is unavailable")
    if not os.path.isdir(os.path.dirname(TIMEZONE_FILE)):
        raise TimezoneUnavailable("CoreELEC timezone storage is unavailable")
    return "coreelec"


def _zone_path(zone):
    if (not isinstance(zone, str) or len(zone) > 128 or
            not re.fullmatch(r"[A-Za-z0-9_+.-]+(?:/[A-Za-z0-9_+.-]+)*", zone) or
            any(part in (".", "..") for part in zone.split("/"))):
        raise RuntimeError("Invalid timezone name")
    path = os.path.realpath(os.path.join(ZONEINFO, zone))
    if not path.startswith(os.path.realpath(ZONEINFO) + os.sep) or not os.path.isfile(path):
        raise RuntimeError("Timezone data is missing: {}".format(zone))
    return path


def _country(zone):
    countries = {}
    with open(os.path.join(ZONEINFO, "iso3166.tab"), encoding="utf-8") as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if not line.startswith("#") and len(fields) >= 2:
                countries[fields[0]] = fields[1]
    with open(os.path.join(ZONEINFO, "zone.tab"), encoding="utf-8") as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if not line.startswith("#") and len(fields) >= 3 and fields[2] == zone:
                return countries.get(fields[0], "")
    return ""  # UTC and legacy aliases need not have a country entry.


def _content():
    if os.path.islink(TIMEZONE_FILE):
        raise RuntimeError("Refusing a symbolic-link timezone configuration")
    try:
        with open(TIMEZONE_FILE, encoding="utf-8") as handle:
            content = handle.read(1025)
    except FileNotFoundError:
        return None
    if len(content) > 1024:
        raise RuntimeError("Unexpected timezone configuration size")
    return content


def _configured_zone(content):
    if content is None:
        return "UTC"  # tz-data.service's documented default.
    match = re.fullmatch(r"TIMEZONE=([A-Za-z0-9_+./-]+)\n?", content)
    if not match:
        raise RuntimeError("Unexpected timezone configuration; nothing overwritten")
    return match.group(1)


def read_state(rpc):
    method = backend(rpc)
    if method == "kodi":
        value = {"country": rpc("Settings.GetSettingValue", {"setting": COUNTRY_ID})["value"],
                 "timezone": rpc("Settings.GetSettingValue", {"setting": ZONE_ID})["value"]}
        return {"backend": method, "value": value}
    content = _content()
    zone = _configured_zone(content)
    _zone_path(zone)
    return {"backend": method, "value": {"country": _country(zone), "timezone": zone},
            "content": content}


def unavailable_reason(rpc):
    try:
        backend(rpc)
    except TimezoneUnavailable as exc:
        return str(exc)
    return None


def _set_pair(rpc, value):
    # Changing the country may automatically choose its first zone. Always
    # write the zone second, even if it matched before the country changed.
    for key, setting in (("country", COUNTRY_ID), ("timezone", ZONE_ID)):
        if rpc("Settings.GetSettingValue", {"setting": setting})["value"] != value[key]:
            if rpc("Settings.SetSettingValue", {"setting": setting, "value": value[key]}) is not True:
                raise RuntimeError("Kodi refused to update {}".format(setting))
    actual = {"country": rpc("Settings.GetSettingValue", {"setting": COUNTRY_ID})["value"],
              "timezone": rpc("Settings.GetSettingValue", {"setting": ZONE_ID})["value"]}
    if actual != value:
        raise RuntimeError("Kodi timezone change could not be verified")


def _replace_content(content):
    _content()  # Refuse symlinks before both applying and restoring.
    if content is None:
        if os.path.exists(TIMEZONE_FILE):
            os.remove(TIMEZONE_FILE)
        return
    fd, path = tempfile.mkstemp(prefix="timezone-", dir=os.path.dirname(TIMEZONE_FILE))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(path, 0o644)
        os.replace(path, TIMEZONE_FILE)
    finally:
        if os.path.exists(path):
            os.remove(path)


def _activate(zone):
    subprocess.run(["systemctl", "restart", "tz-data.service"], check=True,
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    if os.path.realpath(LOCALTIME) != _zone_path(zone):
        raise RuntimeError("CoreELEC did not activate the requested timezone")
    os.environ["TZ"] = zone
    time.tzset()


def write(rpc, value, restore_metadata=None):
    if not isinstance(value, dict) or set(value) != {"country", "timezone"} or not all(
            isinstance(v, str) for v in value.values()):
        raise RuntimeError("Invalid country/timezone pair")
    previous = read_state(rpc)
    method = previous["backend"]
    if restore_metadata and restore_metadata["backend"] != method:
        raise RuntimeError("Timezone method changed since application; refusing restore")
    if method == "kodi":
        try:
            _set_pair(rpc, value)
        except Exception as exc:
            try:
                _set_pair(rpc, previous["value"])
            except Exception as undo:
                raise RuntimeError("Timezone change failed: {}; undo failed: {}".format(exc, undo))
            raise
        return
    _zone_path(value["timezone"])
    if value["country"] != _country(value["timezone"]):
        raise RuntimeError("Timezone does not belong to the requested country")
    content = (restore_metadata["content"] if restore_metadata else
               "TIMEZONE={}".format(value["timezone"]))
    if _configured_zone(content) != value["timezone"]:
        raise RuntimeError("Timezone restore data does not match the previous value")
    try:
        _replace_content(content)
        _activate(value["timezone"])
    except Exception as exc:
        try:
            _replace_content(previous["content"])
            _activate(previous["value"]["timezone"])
        except Exception as undo:
            raise RuntimeError("Timezone change failed: {}; undo failed: {}".format(exc, undo))
        raise
