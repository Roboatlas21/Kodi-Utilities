"""Apply the Arctic Fuse 3 Home-window workaround from PR #454.

The patch is intentionally narrow and fail-closed: only the exact known AF3
navigation constructs are changed. If upstream changes the surrounding layout,
Kodi Utilities logs a warning and leaves the skin files untouched.
"""

import os
import stat
import tempfile
import xml.etree.ElementTree as ET

SKIN_ID = "skin.arctic.fuse.3"
HOME_FILENAME = "Includes_Home.xml"
BUTTON_FILENAME = "Includes_ButtonMenu.xml"
FILENAMES = (HOME_FILENAME, BUTTON_FILENAME)

_HUB_WINDOWS = ("1105", "1101", "1102", "1103", "1104", "1106", "1107", "1108", "1109")


class PatchError(RuntimeError):
    """Unsupported upstream layout or a write that cannot be made safely."""


def skin_files(addons_dir):
    base = os.path.join(addons_dir, SKIN_ID, "1080i")
    return {
        HOME_FILENAME: os.path.join(base, HOME_FILENAME),
        BUTTON_FILENAME: os.path.join(base, BUTTON_FILENAME),
    }


def _replace_unique(content, old, new, label):
    if content.count(old) != 1:
        raise PatchError("Arctic Fuse layout changed near {}".format(label))
    return content.replace(old, new, 1)


def _patch_home(content):
    changed = False

    if '<param name="hub_window" />' not in content:
        old = '    <include name="Home_ControlList_Item">\n        <property name="enabled">true</property>'
        new = '    <include name="Home_ControlList_Item">\n        <param name="hub_window" />\n        <property name="enabled">true</property>'
        content = _replace_unique(content, old, new, "Home_ControlList_Item parameter")
        changed = True

    if '<property name="hub_window">$PARAM[hub_window]</property>' not in content:
        old = '                <property name="action">$PARAM[action]</property>\n                <visible>$PARAM[enabled]</visible>'
        new = ('                <property name="action">$PARAM[action]</property>\n'
               '                <property name="hub_window">$PARAM[hub_window]</property>\n'
               '                <visible>$PARAM[enabled]</visible>')
        content = _replace_unique(content, old, new, "Home_ControlList_Item property")
        changed = True

    for window in _HUB_WINDOWS:
        marker = '<param name="hub_window">{}</param>'.format(window)
        if marker in content:
            continue
        old = '            <param name="action">ReplaceWindow({})</param>'.format(window)
        new = old + '\n            ' + marker
        content = _replace_unique(content, old, new, "hub {}".format(window))
        changed = True

    movement = (
        (
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(-1).Property(action)]</onleft>',
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))]">$INFO[Container(399).ListItem(-1).Property(action)]</onleft>\n'
            '                <onleft condition="!Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(-1).Property(hub_window)])</onleft>',
            "horizontal previous hub",
        ),
        (
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(1).Property(action)]</onright>',
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(1).Property(hub_window))]">$INFO[Container(399).ListItem(1).Property(action)]</onright>\n'
            '                <onright condition="!Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(1).Property(hub_window)])</onright>',
            "horizontal next hub",
        ),
        (
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(-1).Property(action)]</onup>',
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))]">$INFO[Container(399).ListItem(-1).Property(action)]</onup>\n'
            '                <onup condition="Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(-1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(-1).Property(hub_window)])</onup>',
            "vertical previous hub",
        ),
        (
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical)">$INFO[Container(399).ListItem(1).Property(action)]</ondown>',
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical) + [!Window.IsVisible(Home) | String.IsEmpty(Container(399).ListItem(1).Property(hub_window))]">$INFO[Container(399).ListItem(1).Property(action)]</ondown>\n'
            '                <ondown condition="Skin.HasSetting(HomeSwitcher.Vertical) + Window.IsVisible(Home) + !String.IsEmpty(Container(399).ListItem(1).Property(hub_window))">ActivateWindow($INFO[Container(399).ListItem(1).Property(hub_window)])</ondown>',
            "vertical next hub",
        ),
    )
    for old, new, label in movement:
        if new in content:
            continue
        content = _replace_unique(content, old, new, label)
        changed = True

    direct_old = '                    <onclick condition="!Window.IsVisible($PARAM[window])">ReplaceWindow($PARAM[window])</onclick>'
    direct_new = (
        '                    <onclick condition="!Window.IsVisible($PARAM[window]) + !Window.IsVisible(Home)">ReplaceWindow($PARAM[window])</onclick>\n'
        '                    <onclick condition="!Window.IsVisible($PARAM[window]) + Window.IsVisible(Home)">ActivateWindow($PARAM[window])</onclick>'
    )
    if direct_new not in content:
        content = _replace_unique(content, direct_old, direct_new, "hub click action")
        changed = True

    try:
        ET.fromstring(content)
    except ET.ParseError as exc:
        raise PatchError("Patched Includes_Home.xml would not parse: {}".format(exc)) from exc
    return content, changed


def _patch_button_menu(content):
    old = '                <onclick>ActivateWindow(settings)</onclick>'
    new = '                <onclick>ReplaceWindow(settings)</onclick>'
    if new in content:
        changed = False
    else:
        content = _replace_unique(content, old, new, "Settings button")
        changed = True
    try:
        ET.fromstring(content)
    except ET.ParseError as exc:
        raise PatchError("Patched Includes_ButtonMenu.xml would not parse: {}".format(exc)) from exc
    return content, changed


def _atomic_write(path, data, mode):
    fd, tmp = tempfile.mkstemp(prefix=".af3-window-fix-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, stat.S_IMODE(mode))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def apply(addons_dir):
    """Return 'changed', 'unchanged' or 'missing'."""
    paths = skin_files(addons_dir)
    if not os.path.isdir(os.path.join(addons_dir, SKIN_ID)):
        return "missing"
    if not all(os.path.isfile(path) for path in paths.values()):
        raise PatchError("Required Arctic Fuse navigation files are missing")

    originals = {}
    decoded = {}
    for name, path in paths.items():
        with open(path, "rb") as handle:
            originals[name] = handle.read()
        decoded[name] = originals[name].decode("utf-8")

    home, home_changed = _patch_home(decoded[HOME_FILENAME])
    button, button_changed = _patch_button_menu(decoded[BUTTON_FILENAME])
    if not home_changed and not button_changed:
        return "unchanged"

    # Preflight every target before writing either file. This prevents an
    # upstream layout change in one file from leaving a half-applied patch.
    for name, path in paths.items():
        with open(path, "rb") as handle:
            if handle.read() != originals[name]:
                raise PatchError("Skin changed while applying blank-screen fix; retry on next event")

    if home_changed:
        _atomic_write(paths[HOME_FILENAME], home.encode("utf-8"),
                      os.stat(paths[HOME_FILENAME]).st_mode)
    if button_changed:
        _atomic_write(paths[BUTTON_FILENAME], button.encode("utf-8"),
                      os.stat(paths[BUTTON_FILENAME]).st_mode)
    return "changed"
