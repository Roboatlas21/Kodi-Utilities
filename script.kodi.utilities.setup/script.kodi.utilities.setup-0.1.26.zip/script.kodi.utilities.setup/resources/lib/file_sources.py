"""Safely add/remove explicitly approved File Manager sources in Kodi's sources.xml.

Kodi's File Manager sources are not writable through JSON-RPC. Kodi loads this
file into memory at startup, so the user may have to restart Kodi to see it.
"""

import os
import stat
import tempfile
import xml.etree.ElementTree as ET

MAX_SOURCES_BYTES = 1024 * 1024


def _normalized_url(value):
    return (value or "").strip().rstrip("/").casefold()


def _load(filename):
    if not os.path.isfile(filename):
        return ET.Element("sources"), b"", False
    with open(filename, "rb") as handle:
        raw = handle.read(MAX_SOURCES_BYTES + 1)
    if len(raw) > MAX_SOURCES_BYTES:
        raise RuntimeError("sources.xml is unexpectedly large; refusing to modify it")
    try:
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
        root = ET.fromstring(raw, parser=parser)
    except ET.ParseError as exc:
        raise RuntimeError("sources.xml is malformed; refusing to modify it: {}".format(exc))
    if root.tag != "sources" or len(root.findall("files")) > 1:
        raise RuntimeError("Unexpected sources.xml layout; refusing to modify it")
    return root, raw, True


def _file_sources(root):
    section = root.find("files")
    return [] if section is None else section.findall("source")


def _check_for_existing(root, name, url):
    """Find duplicate URL without duplicating, reject collisions on name."""
    matching_url = False
    for source in _file_sources(root):
        source_name = (source.findtext("name") or "").strip()
        paths = [item.text or "" for item in source.findall("path")]
        if source_name.casefold() == name.casefold() and not any(
                _normalized_url(path) == _normalized_url(url) for path in paths):
            raise RuntimeError("File Manager source '{}' already exists with a different path".format(name))
        if any(_normalized_url(path) == _normalized_url(url) for path in paths):
            matching_url = True
    return matching_url


def is_source_present(filename, name, url):
    root, _, _ = _load(filename)
    return _check_for_existing(root, name, url)


def _add(root, name, url):
    if _check_for_existing(root, name, url):
        return False
    section = root.find("files")
    if section is None:
        section = ET.SubElement(root, "files")
        ET.SubElement(section, "default", {"pathversion": "1"})
    entry = ET.SubElement(section, "source")
    ET.SubElement(entry, "name").text = name
    ET.SubElement(entry, "path", {"pathversion": "1"}).text = url
    ET.SubElement(entry, "allowsharing").text = "true"
    return True


def _remove(root, name, url):
    section = root.find("files")
    if section is None:
        return False
    matches = []
    for source in section.findall("source"):
        if (source.findtext("name") or "").strip() != name:
            continue
        paths = source.findall("path")
        if not any(_normalized_url(item.text) == _normalized_url(url) for item in paths):
            continue
        # Never remove a source changed manually after Device Setup added it.
        children = list(source)
        if (source.attrib or [child.tag for child in children] != ["name", "path", "allowsharing"]
                or len(paths) != 1 or paths[0].attrib != {"pathversion": "1"}
                or (source.findtext("allowsharing") or "").strip() != "true"):
            raise RuntimeError("File Manager source has been edited; refusing to remove it")
        matches.append(source)
    if len(matches) > 1:
        raise RuntimeError("Duplicate File Manager source entries; refusing to remove any")
    if not matches:
        return False
    section.remove(matches[0])
    return True


def set_file_source(filename, name, url, present, backup_dir):
    root, before, existed = _load(filename)
    changed = _add(root, name, url) if present else _remove(root, name, url)
    if not changed:
        return False

    # Preserve all existing sections, other sources and XML comments.
    after = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    os.makedirs(backup_dir, mode=0o700, exist_ok=True)
    backup_fd, backup_name = tempfile.mkstemp(prefix="sources-before-", suffix=".xml.bak", dir=backup_dir)
    try:
        with os.fdopen(backup_fd, "wb") as backup:
            backup.write(before)
            backup.flush()
            os.fsync(backup.fileno())
    except Exception:
        if os.path.exists(backup_name):
            os.unlink(backup_name)
        raise

    parent = os.path.dirname(filename)
    os.makedirs(parent, exist_ok=True)
    temporary_fd, temporary_name = tempfile.mkstemp(prefix=".sources-kodi-utilities-", suffix=".xml", dir=parent)
    try:
        with os.fdopen(temporary_fd, "wb") as temporary:
            if existed:
                os.fchmod(temporary.fileno(), stat.S_IMODE(os.stat(filename).st_mode))
            else:
                os.fchmod(temporary.fileno(), 0o644)
            temporary.write(after)
            temporary.flush()
            os.fsync(temporary.fileno())
        os.replace(temporary_name, filename)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)
    return True
