"""Per-device Kodi GUI resolution selection using the modes Kodi reports."""

import re

SETTING = "videoscreen.resolution"
SIZES = ((1920, 1080), (3840, 2160))


def details(rpc):
    """Return the current mode and supported 1080p/4K IDs, never guess IDs."""
    result = rpc("Settings.GetSettings", {
        "level": "basic", "filter": {"section": "system", "category": "display"}
    })
    setting = next((item for item in result.get("settings", [])
                    if item.get("id") == SETTING), None)
    if not setting or not setting.get("enabled", True):
        raise RuntimeError("Kodi's Display > Resolution setting is not available")
    if setting.get("optionspending"):
        raise RuntimeError("Kodi is still detecting display modes. Try again shortly")

    choices = {}
    for item in setting.get("options", []):
        label = item.get("label", "")
        value = item.get("value")
        if not isinstance(label, str) or type(value) is not int:
            continue
        match = re.match(r"^\s*(\d+)\s*x\s*(\d+)([pi])?", label, re.I)
        if not match:
            continue
        size = (int(match.group(1)), int(match.group(2)))
        if size not in SIZES or (match.group(3) or "p").lower() != "p":
            continue
        # Prefer the ordinary output mode if Kodi also advertises a HiDPI variant.
        if size not in choices or ("HiDPI" in choices[size]["label"] and "HiDPI" not in label):
            choices[size] = {"label": label, "value": value}

    current = setting.get("value")
    current_size = next((size for size, item in choices.items()
                         if item["value"] == current), None)
    return {"current": current, "current_size": current_size, "choices": choices}


def set_size(rpc, info, size):
    """Apply Kodi's own resolution setting and its native keep/revert prompt."""
    if size not in SIZES or size not in info["choices"]:
        raise ValueError("That display resolution isn't offered by Kodi")
    target = info["choices"][size]["value"]
    if target == info["current"]:
        return False
    if rpc("Settings.SetSettingValue", {"setting": SETTING, "value": target}) is not True:
        raise RuntimeError("Kodi didn't keep the display resolution change")
    return True
