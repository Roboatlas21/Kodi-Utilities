"""Temporary TMDb Helper SQLite test patch for CoreELEC 21."""

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime

ADDON_ID = "plugin.video.themoviedb.helper"
VERSION = "6.20.3"
COMMIT = "c7a0520ba5d3dea7a367d594aa2e8e3b04645a87"
BASE_FILES = {
    "resources/tmdbhelper/lib/files/dbdata.py": "56dd72f5bdc0a3b59ffceb1f430af704e143a830",
    "resources/tmdbhelper/lib/files/dbfunc.py": "cffa4bdb63951fb1976bb1092fe66ff2c254a4a8",
    "resources/tmdbhelper/lib/items/database/details/backend.py": "7322c3c238b1ce038faef2661b0ca30987e395d4",
    "resources/tmdbhelper/lib/sync/datasync.py": "29b85893e91848af9ed17acf702b942c88a3e34a",
}
PATCH_FILES = {
    "resources/tmdbhelper/lib/files/dbdata.py": "c619fbb76dd6910c6a4abcc5979261dfb76f4849",
    "resources/tmdbhelper/lib/files/dbfunc.py": "c30ba86f0cd4d245bfc40a5fbfb3eb9795da32e8",
    "resources/tmdbhelper/lib/items/database/details/backend.py": "11498e107b116a77fd802c9647a606f139957c07",
    "resources/tmdbhelper/lib/sync/datasync.py": "b029e5c369941e0069d59666bad4ec029a014ff8",
}
# Previous test build remains recognized for safe restoration after an update.
PREVIOUS_PATCHES = {
    "e289f936860f51a58f0608bb8ac3e90f928020ff": {
        "resources/tmdbhelper/lib/files/dbdata.py": "3e6105190ceb8da70a92189cc507ee8c665bb5b6",
        "resources/tmdbhelper/lib/files/dbfunc.py": "a4d17b3bcb2cfe087e65ae4e7d0b9e9c4ca7e00f",
        "resources/tmdbhelper/lib/items/database/details/backend.py": "d0dad581df324f71fa53049bd3ce1c2316e7ba90",
        "resources/tmdbhelper/lib/sync/datasync.py": "b029e5c369941e0069d59666bad4ec029a014ff8",
    },
}
ROOT = "/storage/.config/kodi-utilities/tmdbhelper-sqlite-test"
STAGED = os.path.join(ROOT, "addon")
MARKER = ".kodi_utilities_sqlite_test.json"
BASELINE = "/storage/.config/kodi-utilities/tmdbhelper-sqlite-baseline.json"
DOWNLOAD_LIMIT = 512 * 1024
REQUIRED_COMMANDS = ("systemd-run", "systemctl", "mount", "umount", "awk", "stat")


class SQLiteTestError(RuntimeError):
    pass


def _git_sha(data):
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def _hash(path):
    with open(path, "rb") as handle:
        return _git_sha(handle.read())


def _target():
    return "/storage/.kodi/addons/" + ADDON_ID


def _installed():
    import xbmcaddon
    import xbmcvfs
    try:
        path = os.path.realpath(xbmcvfs.translatePath(
            xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")))
    except RuntimeError as error:
        raise SQLiteTestError("TMDb Helper is not installed") from error
    if path != _target() or not os.path.isdir(path):
        raise SQLiteTestError("Only the standard CoreELEC TMDb Helper installation is supported")
    root = ET.parse(os.path.join(path, "addon.xml")).getroot()
    if root.tag != "addon" or root.get("id") != ADDON_ID:
        raise SQLiteTestError("Unexpected TMDb Helper add-on")
    return path, root.get("version", "")


def _missing_requirements():
    missing = [name for name in REQUIRED_COMMANDS if shutil.which(name) is None]
    if not os.access("/proc/self/mountinfo", os.R_OK):
        missing.append("/proc/self/mountinfo")
    return missing


def _mounted(path):
    with open("/proc/self/mountinfo", encoding="utf-8") as stream:
        return any(parts[4] == path for line in stream
                   if len(parts := line.split()) > 4)


def _hashes(folder, expected):
    return all(_hash(os.path.join(folder, name)) == sha
               for name, sha in expected.items())


def _marker_valid(folder, addon_xml_sha=None, allow_previous=False):
    try:
        with open(os.path.join(folder, MARKER), encoding="utf-8") as handle:
            saved = json.load(handle)
        commit = saved.get("commit")
        hashes = (PATCH_FILES if commit == COMMIT else
                  PREVIOUS_PATCHES.get(commit) if allow_previous else None)
        return (hashes is not None
                and saved.get("version") == VERSION
                and saved.get("original_hashes") == BASE_FILES
                and (addon_xml_sha is None or saved.get("addon_xml_sha") == addon_xml_sha)
                and _hash(os.path.join(folder, "addon.xml")) == saved.get("addon_xml_sha")
                and _hashes(folder, hashes))
    except (OSError, ValueError, TypeError):
        return False


def status():
    try:
        addon, version = _installed()
        if _missing_requirements():
            return "unsupported"
        if _mounted(addon):
            if not os.path.isdir(STAGED) or not os.path.samefile(addon, STAGED):
                return "foreign_mount"
            if _marker_valid(STAGED):
                return "active"
            return "active_previous" if _marker_valid(STAGED, allow_previous=True) else "foreign_mount"
        if version != VERSION or not _hashes(addon, BASE_FILES):
            return "incompatible"
        if os.path.lexists(STAGED):
            addon_xml_sha = _hash(os.path.join(addon, "addon.xml"))
            if _marker_valid(STAGED, addon_xml_sha):
                return "staged"
            if _marker_valid(STAGED, addon_xml_sha, allow_previous=True):
                return "staged_previous"
            return "stale"
        return "not_downloaded"
    except (SQLiteTestError, OSError, ET.ParseError):
        return "unavailable"


def _download(name, sha):
    url = ("https://raw.githubusercontent.com/Roboatlas21/"
           "plugin.video.themoviedb.helper/" + COMMIT + "/" + name)
    request = urllib.request.Request(url, headers={"User-Agent": "KodiUtilities-SQLiteTest/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(DOWNLOAD_LIMIT + 1)
    if len(data) > DOWNLOAD_LIMIT or _git_sha(data) != sha:
        raise SQLiteTestError("TMDb Helper test patch verification failed: " + name)
    return data


def stage():
    """Stage a verified add-on copy without changing installed files."""
    state = status()
    if state == "staged":
        return "unchanged"
    if state == "unsupported":
        raise SQLiteTestError("Missing CoreELEC commands: " + ", ".join(_missing_requirements()))
    if state == "incompatible":
        raise SQLiteTestError("Requires unmodified TMDb Helper {} files".format(VERSION))
    if state != "not_downloaded":
        raise SQLiteTestError("Cannot stage patch: {}".format(state))
    addon, _ = _installed()
    # Download everything before creating the staging directory.
    files = {name: _download(name, sha) for name, sha in PATCH_FILES.items()}
    if os.path.islink(ROOT) or (os.path.lexists(ROOT) and not os.path.isdir(ROOT)):
        raise SQLiteTestError("Unexpected staging directory")
    os.makedirs(ROOT, exist_ok=True)
    candidate = STAGED + ".part-{}".format(os.getpid())
    if os.path.lexists(candidate):
        raise SQLiteTestError("Previous incomplete staging directory needs cleanup")
    try:
        for directory, folders, filenames in os.walk(addon):
            if any(os.path.islink(os.path.join(directory, name)) for name in folders + filenames):
                raise SQLiteTestError("Symlinked add-on source is not supported")
        shutil.copytree(addon, candidate, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
        for name, contents in files.items():
            path = os.path.join(candidate, name)
            with open(path, "wb") as handle:
                handle.write(contents)
        with open(os.path.join(candidate, MARKER), "w", encoding="utf-8") as handle:
            json.dump({"commit": COMMIT, "version": VERSION,
                       "addon_xml_sha": _hash(os.path.join(addon, "addon.xml")),
                       "original_hashes": BASE_FILES}, handle)
        if not _marker_valid(candidate, _hash(os.path.join(addon, "addon.xml"))):
            raise SQLiteTestError("Staged TMDb Helper patch failed verification")
        if not _hashes(addon, BASE_FILES) or os.path.lexists(STAGED):
            raise SQLiteTestError("Installed add-on changed during staging")
        os.replace(candidate, STAGED)
    finally:
        if os.path.isdir(candidate):
            shutil.rmtree(candidate)
    return "changed"


def _schedule(name, script):
    result = subprocess.run(["systemd-run", "--unit={}--{}".format(name, os.getpid()),
                             "--no-block", "/bin/sh", "-c", script],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            universal_newlines=True, check=False)
    if result.returncode:
        raise SQLiteTestError(result.stdout.strip() or "Could not schedule Kodi restart")


def _mount_test(target):
    return ("awk -v target={target} '$5 == target {{ found=1; exit }} "
            "END {{ exit !found }}' /proc/self/mountinfo").format(target=shlex.quote(target))


def _samefile_test(target):
    return ('[ "$(stat -c %d:%i {staged} 2>/dev/null)" = '
            '"$(stat -c %d:%i {target} 2>/dev/null)" ]').format(
                staged=shlex.quote(STAGED), target=shlex.quote(target))


def activate():
    if status() == "active":
        return "unchanged"
    if status() != "staged":
        raise SQLiteTestError("Stage an unmodified 6.20.3 installation first")
    target = _target()
    script = """set -eu
sleep 1
systemctl stop kodi.service
if [ ! -r /proc/self/mountinfo ] || {check}; then
  systemctl start kodi.service
  exit 1
fi
if ! mount --bind {staged} {target}; then
  systemctl start kodi.service
  exit 1
fi
if ! {check} || [ ! -f {marker} ] || ! {samefile}; then
  umount {target} || true
  systemctl start kodi.service
  exit 1
fi
systemctl start kodi.service
""".format(check=_mount_test(target), staged=shlex.quote(STAGED),
           target=shlex.quote(target), marker=shlex.quote(os.path.join(target, MARKER)),
           samefile=_samefile_test(target))
    _schedule("kodi-utilities-tmdb-sqlite-test", script)
    return "scheduled"


def restore(remove=False):
    state = status()
    if state == "foreign_mount":
        raise SQLiteTestError("Unknown TMDb Helper mount; refusing to unmount")
    if state not in ("active", "active_previous"):
        if remove:
            return remove_staged()
        return "unchanged"
    target = _target()
    cleanup = "rm -rf {} || true".format(shlex.quote(ROOT)) if remove else ":"
    script = """set -eu
sleep 1
systemctl stop kodi.service
if ! {check} || ! {samefile} || [ ! -f {marker} ]; then
  systemctl start kodi.service
  exit 1
fi
if ! umount {target} || {check}; then
  systemctl start kodi.service
  exit 1
fi
{cleanup}
systemctl start kodi.service
""".format(check=_mount_test(target), samefile=_samefile_test(target),
           marker=shlex.quote(os.path.join(target, MARKER)),
           target=shlex.quote(target), cleanup=cleanup)
    _schedule("kodi-utilities-tmdb-sqlite-restore", script)
    return "scheduled"


def remove_staged():
    state = status()
    if state in ("active", "active_previous"):
        return restore(remove=True)
    if state == "foreign_mount":
        raise SQLiteTestError("Unknown TMDb Helper mount; refusing to remove files")
    if not os.access("/proc/self/mountinfo", os.R_OK) or _mounted(_target()):
        raise SQLiteTestError("Cannot verify that the test patch is inactive")
    if not os.path.lexists(ROOT):
        return "unchanged"
    if os.path.islink(ROOT) or not os.path.isdir(ROOT):
        raise SQLiteTestError("Unexpected staging path; refusing removal")
    shutil.rmtree(ROOT)
    return "changed"


def memory_snapshot():
    """Measure the real Kodi process and main ItemDetails.db mappings."""
    result = subprocess.run(["pidof", "kodi.bin"], check=False,
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            universal_newlines=True)
    if result.returncode or not result.stdout.strip():
        raise SQLiteTestError("Kodi process was not found")
    pid = result.stdout.split()[0]
    with open("/proc/{}/status".format(pid), encoding="ascii") as handle:
        lines = handle.readlines()
    numbers = {}
    for line in lines:
        key = line.split(":", 1)[0]
        if key in ("VmSize", "VmRSS", "Threads"):
            numbers[key] = int(line.split()[1])
    count, mapped_kb = 0, 0
    with open("/proc/{}/maps".format(pid), encoding="ascii") as handle:
        for line in handle:
            parts = line.split()
            if len(parts) > 5 and parts[5].endswith("/ItemDetails.db"):
                start, end = parts[0].split("-")
                count += 1
                mapped_kb += (int(end, 16) - int(start, 16)) // 1024
    return {"pid": int(pid), "vm_kb": numbers.get("VmSize", 0),
            "rss_kb": numbers.get("VmRSS", 0), "threads": numbers.get("Threads", 0),
            "maps": count, "mapped_kb": mapped_kb, "time": datetime.now().isoformat(timespec="seconds")}


def save_baseline():
    result = memory_snapshot()
    os.makedirs(os.path.dirname(BASELINE), exist_ok=True)
    temp = BASELINE + ".part-{}".format(os.getpid())
    try:
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(result, handle)
        os.replace(temp, BASELINE)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return result


def get_baseline():
    try:
        with open(BASELINE, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def _memory_text(snapshot):
    return ("Kodi PID: {pid}  •  {time}\n"
            "Virtual memory: {vm_kb:.0f} KiB\n"
            "Resident memory: {rss_kb:.0f} KiB\n"
            "Threads: {threads}\n"
            "ItemDetails.db mappings: {maps}\n"
            "ItemDetails.db mapped virtual size: {mapped_kb:.0f} KiB").format(**snapshot)


def show_menu():
    """Manual test controls. Nothing is installed by Apply My Setup."""
    import xbmcgui
    dialog = xbmcgui.Dialog()
    labels = {
        "not_downloaded": "Not downloaded", "staged": "Downloaded (inactive)",
        "active": "ACTIVE (until CoreELEC reboot)",
        "active_previous": "ACTIVE (older patch; restore before updating)",
        "staged_previous": "Older download (remove before updating)",
        "incompatible": "Unsupported installed files",
        "unsupported": "Unsupported device", "stale": "Stale download",
        "foreign_mount": "Unrecognized mount", "unavailable": "TMDb Helper not found",
    }
    state = status()
    options = [
        "Patch status: " + labels.get(state, state),
        "Capture memory baseline (before patch)",
        "Compare current memory with baseline",
        "Install & Test SQLite Memory Fix (temporary)",
        "Restore Original TMDb Helper Now",
        "Remove Downloaded Patch Files",
    ]
    selected = dialog.select("Kodi Utilities - TMDb Helper SQLite Test", options)
    if selected < 0:
        return
    if selected == 0:
        dialog.ok("TMDb Helper SQLite Test",
                  "Status: {}\n\nPatched version: {}\nCommit: {}\n\n"
                  "Kodi must restart to load the patch. Rebooting CoreELEC removes "
                  "the temporary mount; this does not delete the TMDb Helper cache.".format(
                      labels.get(state, state), VERSION, COMMIT[:12]))
    elif selected == 1:
        value = save_baseline()
        dialog.textviewer("TMDb Helper - baseline captured", _memory_text(value))
    elif selected == 2:
        value, baseline = memory_snapshot(), get_baseline()
        display = _memory_text(value)
        if baseline:
            display += "\n\nSaved baseline:\n" + _memory_text(baseline)
            display += ("\n\nChange: VmSize {:+,} KiB, main mappings {:+d}".format(
                value["vm_kb"] - baseline["vm_kb"], value["maps"] - baseline["maps"]))
        else:
            display += "\n\nNo baseline yet. Capture one before installing the patch."
        dialog.textviewer("TMDb Helper - memory comparison", display)
    elif selected == 3:
        if state == "active":
            dialog.ok("TMDb Helper SQLite Test", "The patch is already active.")
            return
        if state in ("active_previous", "staged_previous"):
            dialog.ok("TMDb Helper SQLite Test",
                      "Restore the older patch if active, then remove its downloaded "
                      "files before installing the updated fix.")
            return
        warning = (
            "Test TMDb Helper {} SQLite fix?\n\n"
            "Four verified Python files will be staged in a private copy of the add-on. "
            "The installed add-on files are not overwritten.\n\n"
            "Kodi will restart using a temporary CoreELEC bind mount. "
            "A full CoreELEC reboot restores the original files.\n\n"
            "Capture a memory baseline first for comparison. "
            "Avoid updating TMDb Helper during the test.\n\nContinue?"
        ).format(VERSION)
        if not dialog.yesno("Kodi Utilities - SQLite Test", warning,
                            nolabel="Cancel", yeslabel="Install & Test"):
            return
        if state != "staged":
            progress = xbmcgui.DialogProgressBG()
            progress.create("Kodi Utilities", "Verifying SQLite test patch...")
            try:
                stage()
            finally:
                progress.close()
        if activate() == "scheduled":
            dialog.notification("Kodi Utilities", "Restarting Kodi with SQLite test fix...",
                                xbmcgui.NOTIFICATION_WARNING, 7000)
    elif selected == 4:
        if state not in ("active", "active_previous"):
            dialog.ok("TMDb Helper SQLite Test", "No active test patch to restore.")
            return
        if dialog.yesno("Kodi Utilities", "Restore original TMDb Helper now? Kodi will restart.",
                        nolabel="Cancel", yeslabel="Restore"):
            restore()
            dialog.notification("Kodi Utilities", "Restoring original TMDb Helper...",
                                xbmcgui.NOTIFICATION_INFO, 6000)
    elif selected == 5:
        if dialog.yesno("Kodi Utilities", "Remove staged TMDb Helper test files? "
                        "If active, the original code will be restored and Kodi restarted.",
                        nolabel="Cancel", yeslabel="Remove"):
            result = remove_staged()
            if result == "scheduled":
                dialog.notification("Kodi Utilities", "Restoring TMDb Helper...",
                                    xbmcgui.NOTIFICATION_INFO, 6000)
            else:
                dialog.ok("Kodi Utilities", "Staged files removed." if result == "changed"
                          else "No staged files to remove.")
