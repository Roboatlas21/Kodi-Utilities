"""Local, reversible CoreELEC native-4K GUI font shader workaround."""

import os
import shlex
import stat
import subprocess
import tempfile

SHADER = "/usr/share/kodi/system/shaders/GLES/2.0/gles_shader_fonts.frag"
AUTOSTART = "/storage/.config/autostart.sh"
DATA_DIR = "/storage/.kodi/userdata/addon_data/script.kodi.utilities.setup/native_gui_font"
START = b"# BEGIN Kodi Utilities native 4K GUI font fix\n"
END = b"# END Kodi Utilities native 4K GUI font fix\n"
CREATED_HEADER = b"#!/bin/sh\n# Created by Kodi Utilities for the native 4K font fix\n"


def _paths(shader=SHADER, autostart=AUTOSTART, data_dir=DATA_DIR):
    return shader, autostart, os.path.join(data_dir, "boot.sh"), os.path.join(data_dir, "patched.frag")


def _boot_script(shader, patch):
    # Runs before Kodi, without network access or a full shader replacement from an older build.
    return """#!/bin/sh
TARGET={target}
PATCH={patch}
[ -f "$TARGET" ] || exit 0
# If CoreELEC now ships a corrected shader, leave it alone.
if grep -q 'varying highp vec4 m_cord0;' "$TARGET"; then
  exit 0
fi
[ "$(grep -c '^varying vec4 m_cord0;$' "$TARGET")" = 1 ] || exit 0
TMP="${{PATCH}}.tmp.$$"
trap 'rm -f "$TMP"' 0
awk '
$0 == "varying vec4 m_cord0;" {{
  print "// Preserve enough UV precision to sample individual GUI glyphs in large 4K atlases."
  print "#ifdef GL_FRAGMENT_PRECISION_HIGH"
  print "varying highp vec4 m_cord0;"
  print "#else"
  print "varying mediump vec4 m_cord0;"
  print "#endif"
  found++
  next
}}
{{ print }}
END {{ if (found != 1) exit 1 }}
' "$TARGET" > "$TMP" || exit 0
[ -s "$TMP" ] || exit 0
mv -f "$TMP" "$PATCH" || exit 0
mount --bind "$PATCH" "$TARGET" || exit 1
exit 0
""".format(target=shlex.quote(shader), patch=shlex.quote(patch)).encode("utf-8")


def _hook(boot):
    return START + ("/bin/sh {} || :\n".format(shlex.quote(boot))).encode("utf-8") + END


def _check_regular(path):
    if os.path.lexists(path) and not stat.S_ISREG(os.lstat(path).st_mode):
        raise RuntimeError("Refusing non-regular file: {}".format(path))


def _write_atomic(path, contents, mode=0o644):
    _check_regular(path)
    directory = os.path.dirname(path)
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".kodi-utilities-", dir=directory)
    try:
        with os.fdopen(fd, "wb") as out:
            out.write(contents)
            out.flush()
            os.fsync(out.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _state(autostart, hook):
    _check_regular(autostart)
    if not os.path.exists(autostart):
        return None
    with open(autostart, "rb") as inp:
        content = inp.read()
    if (START in content or END in content) and (
            content.count(START) != 1 or content.count(END) != 1 or content.count(hook) != 1):
        raise RuntimeError("Existing native 4K font startup hook was modified; not overwriting it")
    return content


def installed(autostart=AUTOSTART, data_dir=DATA_DIR):
    _, _, boot, _ = _paths(autostart=autostart, data_dir=data_dir)
    content = _state(autostart, _hook(boot))
    return content is not None and _hook(boot) in content


def active(shader=SHADER, data_dir=DATA_DIR):
    _, _, _, patch = _paths(shader=shader, data_dir=data_dir)
    try:
        return os.path.samefile(shader, patch)
    except OSError:
        return False


def _requires_fix(shader):
    _check_regular(shader)
    if not os.path.isfile(shader):
        raise RuntimeError("CoreELEC GLES GUI font shader not found; no changes made")
    with open(shader, "rb") as stream:
        source = stream.read(131073)
    if len(source) > 131072:
        raise RuntimeError("Unexpected font shader size; no changes made")
    if source.count(b"varying vec4 m_cord0;") != 1 and b"varying highp vec4 m_cord0;" not in source:
        raise RuntimeError("Unrecognized GUI font shader; no changes made")
    return b"varying vec4 m_cord0;" in source


def install(shader=SHADER, autostart=AUTOSTART, data_dir=DATA_DIR, apply_now=True,
            storage_root="/storage"):
    if os.name != "posix" or not autostart.startswith(storage_root.rstrip("/") + "/"):
        raise RuntimeError("This fix is only available on CoreELEC")
    needs_fix = _requires_fix(shader)
    _, _, boot, patch = _paths(shader, autostart, data_dir)
    content = _state(autostart, _hook(boot))
    if content is None:
        content = CREATED_HEADER
    block = _hook(boot)
    if block not in content:
        if content.startswith(b"#!"):
            pos = content.find(b"\n")
            if pos < 0:
                raise RuntimeError("Invalid autostart.sh: no newline after shebang")
            content = content[:pos + 1] + block + content[pos + 1:]
        else:
            content = block + content
    script = _boot_script(shader, patch)
    _check_regular(boot)
    if os.path.exists(boot):
        with open(boot, "rb") as stream:
            if stream.read() != script:
                raise RuntimeError("Existing font fix boot script was modified; no changes made")
    _write_atomic(boot, script, 0o755)
    mode = stat.S_IMODE(os.stat(autostart).st_mode) if os.path.exists(autostart) else 0o755
    _write_atomic(autostart, content, mode)
    if apply_now and needs_fix:
        subprocess.run(["/bin/sh", boot], check=True, timeout=10)
    return {"installed": True, "active": active(shader, data_dir),
            "already_patched": not needs_fix}


def uninstall(shader=SHADER, autostart=AUTOSTART, data_dir=DATA_DIR):
    _, _, boot, patch = _paths(shader, autostart, data_dir)
    block = _hook(boot)
    content = _state(autostart, block)
    _check_regular(boot)
    if os.path.exists(boot):
        with open(boot, "rb") as stream:
            if stream.read() != _boot_script(shader, patch):
                raise RuntimeError("Existing font fix boot script was modified; not deleting it")
    if content is not None and block in content:
        remaining = content.replace(block, b"", 1)
        if remaining == CREATED_HEADER:
            os.unlink(autostart)
        else:
            _write_atomic(autostart, remaining, stat.S_IMODE(os.stat(autostart).st_mode))
    was_active = active(shader, data_dir)
    if was_active:
        subprocess.run(["umount", shader], check=True, timeout=10)
    for path in (boot, patch):
        _check_regular(path)
        if os.path.exists(path):
            os.unlink(path)
    if os.path.isdir(data_dir) and not os.listdir(data_dir):
        os.rmdir(data_dir)
    manual = False
    if not was_active and os.path.isfile(shader):
        with open(shader, "rb") as stream:
            manual = b"varying highp vec4 m_cord0;" in stream.read(131073)
    return {"active_removed": was_active, "external_mount_possible": manual}
