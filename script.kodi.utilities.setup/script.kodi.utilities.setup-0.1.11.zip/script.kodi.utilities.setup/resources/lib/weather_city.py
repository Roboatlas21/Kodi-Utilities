"""Local Open-Meteo location presets; never part of the shared profile."""

import os
import xml.etree.ElementTree as ET

# City centres verified against Open-Meteo / GeoNames on 2026-10-21.
# GeoNames IDs: Cambridge 5913695, Waterloo 6176823, Oakville 6092122.
CITIES = (("Cambridge", 43.3601, -80.31269),
          ("Waterloo", 43.4668, -80.51639),
          ("Oakville", 43.45011, -79.68292))
FIELDS = {"loc1": "string", "loc1lat": "number", "loc1lon": "number",
          "loc1tz": "string", "loc1data": "string", "loc1map": "string",
          "loc1rv": "string", "loc1gc": "string"}


def _read(addon, key):
    return addon.getSettingNumber(key) if FIELDS[key] == "number" else addon.getSettingString(key)


def _write(addon, key, value):
    result = (addon.setSettingNumber(key, value) if FIELDS[key] == "number" else
              addon.setSettingString(key, value))
    if result is False or _read(addon, key) != value:
        raise RuntimeError("Open-Meteo refused to update {}".format(key))


def _kodi_write(rpc, key, value):
    if rpc("Settings.SetSettingValue", {"setting": key, "value": value}) is not True:
        raise RuntimeError("Kodi refused to update {}".format(key))
    if rpc("Settings.GetSettingValue", {"setting": key})["value"] != value:
        raise RuntimeError("Could not verify {}".format(key))


def set_city(addon, addon_path, selection, rpc, monitor):
    """Set primary location, select it, and invalidate its cached forecast.

    Use the add-on's typed settings API and its own expired-cache timestamp.
    Existing secondary locations, aliases, alerts and units are preserved.
    A failed batch restores only the settings attempted by this operation.
    """
    if type(selection) is not int or not 0 <= selection < len(CITIES):
        raise ValueError("Invalid weather city selection")
    schema = ET.parse(os.path.join(addon_path, "resources", "settings.xml"))
    definitions = {setting.get("id"): setting.get("type") for setting in schema.iter("setting")}
    if any(definitions.get(key) != typ for key, typ in FIELDS.items()):
        raise RuntimeError("This Open-Meteo version uses different location settings")

    # Let an existing download finish before changing the coordinates and
    # expiring its timestamps, so it cannot mark old-city data as fresh.
    for _ in range(120):
        if addon.getSettingString("service") != "running":
            break
        if monitor.waitForAbort(0.25):
            raise RuntimeError("Weather city change cancelled")
    else:
        raise RuntimeError("Open-Meteo is still updating; try setting the city again shortly")

    name, latitude, longitude = CITIES[selection]
    desired = {"loc1lat": latitude, "loc1lon": longitude,
               "loc1tz": "America/Toronto", "loc1": "{}, Ontario, CA".format(name),
               "loc1data": "321318000", "loc1map": "321318000",
               "loc1rv": "321318000", "loc1gc": "321318000"}
    before = {key: _read(addon, key) for key in desired}
    kodi_desired = {"weather.addon": "weather.openmeteo", "weather.currentlocation": 1}
    kodi_before = {key: rpc("Settings.GetSettingValue", {"setting": key})["value"]
                   for key in kodi_desired}
    attempted, kodi_attempted = [], []
    try:
        for key, value in desired.items():
            if before[key] != value:
                attempted.append(key)
                _write(addon, key, value)
        for key, value in kodi_desired.items():
            if kodi_before[key] != value:
                kodi_attempted.append(key)
                _kodi_write(rpc, key, value)
    except Exception as exc:
        errors = []
        for key in reversed(kodi_attempted):
            try:
                _kodi_write(rpc, key, kodi_before[key])
            except Exception as undo:
                errors.append(str(undo))
        for key in reversed(attempted):
            try:
                _write(addon, key, before[key])
            except Exception as undo:
                errors.append(str(undo))
        raise RuntimeError("Weather city change failed: {}. {}".format(
            exc, "Restore errors: " + "; ".join(errors) if errors else "Previous settings restored"))
    return name
