"""Maintain local Arctic Fuse 3 fixes after official skin updates."""

import ctypes
import errno
import os
import select
import struct
import time

import xbmc
import xbmcvfs

from resources.lib import af3_black_screen_fix, af3_idle_login, startup_branding

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons")
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/script.kodi.utilities.setup")

# CoreELEC/Linux inotify: no repeated filesystem scans while idle.
IN_CLOSE_WRITE = 0x00000008
IN_MOVED_FROM = 0x00000040
IN_MOVED_TO = 0x00000080
IN_CREATE = 0x00000100
IN_DELETE = 0x00000200
IN_DELETE_SELF = 0x00000400
IN_MOVE_SELF = 0x00000800
IN_IGNORED = 0x00008000
DIR_EVENTS = IN_MOVED_FROM | IN_MOVED_TO | IN_CREATE | IN_DELETE | IN_DELETE_SELF | IN_MOVE_SELF
FILE_EVENTS = IN_CLOSE_WRITE | IN_MOVED_TO | IN_CREATE | IN_DELETE
LOG_PREFIX = "Kodi Utilities skin maintenance: "
WATCHED_FILES = frozenset((startup_branding.FILENAME,) + af3_black_screen_fix.FILENAMES + af3_idle_login.FILENAMES)


def log(message, level=xbmc.LOGINFO):
    xbmc.log(LOG_PREFIX + str(message), level)


def patch():
    """Apply the on-disk AF3 changes and return whether a skin reload is needed."""
    changed = False
    removed_auto_logoff = False

    try:
        result = af3_black_screen_fix.apply_home(ADDONS_DIR, DATA_DIR)
    except (OSError, UnicodeError, ValueError, af3_black_screen_fix.PatchError) as exc:
        log("Could not apply Arctic Fuse 3 Home-window workaround: {}".format(exc), xbmc.LOGWARNING)
    else:
        if result == "changed":
            changed = True
            log("Applied Arctic Fuse 3 Home-window workaround")
        elif result == "disabled":
            log("Arctic Fuse 3 Home-window workaround disabled; leaving Home navigation untouched")

    try:
        result = af3_black_screen_fix.apply_button_menu(ADDONS_DIR)
    except (OSError, UnicodeError, ValueError, af3_black_screen_fix.PatchError) as exc:
        log("Could not apply Arctic Fuse 3 Settings navigation fix: {}".format(exc), xbmc.LOGWARNING)
    else:
        if result == "changed":
            changed = True
            log("Applied Arctic Fuse 3 Settings navigation fix")

    try:
        result = af3_idle_login.apply(ADDONS_DIR, DATA_DIR)
    except (OSError, UnicodeError, ValueError, af3_idle_login.PatchError) as exc:
        log("Could not apply Arctic Fuse 3 idle-login fix: {}".format(exc), xbmc.LOGWARNING)
    else:
        if result == "changed":
            changed = True
            if af3_idle_login.is_enabled(DATA_DIR):
                log("Enabled Arctic Fuse 3 30-minute auto-logoff")
            else:
                removed_auto_logoff = True
                log("Removed legacy Arctic Fuse 3 auto-logoff timer")

    if startup_branding.is_enabled(DATA_DIR):
        try:
            result = startup_branding.apply(ADDONS_DIR, DATA_DIR)
        except (OSError, UnicodeError, ValueError, startup_branding.BrandingError) as exc:
            log("Could not apply startup title: {}".format(exc), xbmc.LOGWARNING)
        else:
            if result == "changed":
                changed = True
                log("Restored custom startup title")

    # The old timer is still live in Kodi's loaded skin until that skin is
    # reloaded. Remove it from the running AF3 session immediately on upgrade,
    # without waiting for the user to navigate back Home. This one-time reload
    # also applies any other local patches from the same pass.
    if reload_after_auto_logoff_cleanup(removed_auto_logoff):
        return False
    return changed


def reload_after_auto_logoff_cleanup(removed):
    """Apply the removed timer to the live AF3 skin immediately, once."""
    if not removed or xbmc.getSkinDir() != startup_branding.SKIN_ID:
        return False
    xbmc.executebuiltin("ReloadSkin()")
    log("Reloaded Arctic Fuse 3 immediately after removing auto-logoff")
    return True


def reload_when_home(pending):
    """Reload only from Home; never force Home or recover an invalid window."""
    if not pending:
        return False
    if xbmc.getSkinDir() != startup_branding.SKIN_ID:
        return False
    if not xbmc.getCondVisibility("Window.IsActive(Home)"):
        return True
    xbmc.executebuiltin("ReloadSkin()")
    log("Reloaded Arctic Fuse 3 from Home after applying local patch")
    return False

class SkinChanges:
    """Listen to AF3 replacements and the small files Kodi Utilities maintains."""

    def __init__(self):
        libc = ctypes.CDLL(None, use_errno=True)
        init = libc.inotify_init1
        init.argtypes, init.restype = [ctypes.c_int], ctypes.c_int
        add_watch = libc.inotify_add_watch
        add_watch.argtypes, add_watch.restype = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32], ctypes.c_int
        self._add_watch = add_watch
        self.fd = init(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd == -1:
            raise OSError(ctypes.get_errno(), "inotify_init1 failed")
        self.watches = {}
        self.refresh_watches()

    def refresh_watches(self):
        skin_dir = os.path.join(ADDONS_DIR, startup_branding.SKIN_ID)
        paths = (("addons", ADDONS_DIR), ("skin", skin_dir), ("1080i", os.path.join(skin_dir, "1080i")))
        watched = set(self.watches.values())
        for label, path in paths:
            if label in watched or not os.path.isdir(path):
                continue
            wd = self._add_watch(self.fd, os.fsencode(path), DIR_EVENTS | FILE_EVENTS)
            if wd == -1:
                log("Cannot watch {}: {}".format(path, os.strerror(ctypes.get_errno())), xbmc.LOGWARNING)
            else:
                self.watches[wd] = label

    def receive(self, timeout):
        ready, _, _ = select.select([self.fd], [], [], timeout)
        if not ready:
            return False
        try:
            buf = os.read(self.fd, 65536)
        except OSError as exc:
            if exc.errno == errno.EAGAIN:
                return False
            raise
        changed = False
        at = 0
        while at + 16 <= len(buf):
            wd, flags, _, length = struct.unpack_from("iIII", buf, at)
            raw_name = buf[at + 16:at + 16 + length]
            at += 16 + length
            name = os.fsdecode(raw_name.split(b"\0", 1)[0])
            kind = self.watches.get(wd)
            if flags & IN_IGNORED:
                self.watches.pop(wd, None)
                changed = True
            elif kind == "addons" and name == startup_branding.SKIN_ID and flags & DIR_EVENTS:
                changed = True
            elif kind == "skin" and name == "addon.xml" and flags & FILE_EVENTS:
                changed = True
                log("Detected Arctic Fuse 3 package update")
            elif kind == "skin" and name == "1080i" and flags & DIR_EVENTS:
                changed = True
            elif kind == "1080i" and name in WATCHED_FILES and flags & FILE_EVENTS:
                changed = True
            elif flags & (IN_DELETE_SELF | IN_MOVE_SELF) and kind in ("skin", "1080i"):
                changed = True
        if changed:
            self.refresh_watches()
        return changed

    def close(self):
        os.close(self.fd)


def main():
    monitor = xbmc.Monitor()
    pending_reload = False
    try:
        watcher = SkinChanges()
    except (AttributeError, OSError) as exc:
        log("Filesystem event monitoring unavailable: {}".format(exc), xbmc.LOGWARNING)
        pending_reload = patch()
        reload_when_home(pending_reload)
        return
    try:
        pending_reload = patch()
        due = None
        while not monitor.abortRequested():
            now = time.monotonic()
            timeout = min(1.0, max(0.0, due - now)) if due is not None else 1.0
            if watcher.receive(timeout):
                due = time.monotonic() + 1.0  # Debounce a burst of update writes.
            if due is not None and time.monotonic() >= due:
                watcher.refresh_watches()
                pending_reload = patch() or pending_reload
                due = None
            pending_reload = reload_when_home(pending_reload)
    except OSError as exc:
        log("Stopped watching skin updates: {}".format(exc), xbmc.LOGWARNING)
    finally:
        watcher.close()

if __name__ == "__main__":
    main()
