"""Opt-in Arctic Fuse 3 auto-logoff, with cleanup of the old forced timer.

Missing/invalid preferences default to OFF. Existing boxes automatically
remove the exact timer previously injected by Kodi Utilities.
"""

import json
import os
import stat
import tempfile
import xml.etree.ElementTree as ET

SKIN_ID = "skin.arctic.fuse.3"
FILENAME = "Timers.xml"
FILENAMES = (FILENAME,)
CONFIG_FILENAME = "af3_idle_login.json"
_TIMER_NAME = "<name>auto_skin_login</name>"

_TIMER = """    <timer>
        <name>auto_skin_login</name>
        <description>Return to the configured login screen after 30 minutes of inactivity.</description>
        <start reset="true">System.LoggedOn + !Window.IsVisible(1195) + !Window.IsVisible(loginscreen) + !System.HasVisibleModalDialog + [!Player.HasMedia | Player.Paused] + [!Skin.HasSetting(SkinUserLogin.Disabled) | System.HasLoginScreen] + System.IdleTime(1800)</start>
        <stop>Window.IsVisible(1195) | Window.IsVisible(loginscreen) | !System.LoggedOn | !System.IdleTime(1) | [Player.HasMedia + !Player.Paused]</stop>
        <onstart condition="Skin.HasSetting(SkinUserLogin.Disabled)">System.LogOff</onstart>
        <onstart condition="!Skin.HasSetting(SkinUserLogin.Disabled)">ActivateWindow(1195)</onstart>
    </timer>
"""


class PatchError(RuntimeError):
    """Unsupported upstream layout or conflicting timer definition."""


def skin_file(addons_dir):
    return os.path.join(addons_dir, SKIN_ID, "1080i", FILENAME)


def preference_file(data_dir):
    return os.path.join(data_dir, CONFIG_FILENAME)


def is_enabled(data_dir):
    """Never enable auto-logoff from a missing or invalid preference."""
    try:
        with open(preference_file(data_dir), "r", encoding="utf-8") as handle:
            setting = json.load(handle)
    except (OSError, ValueError, UnicodeError):
        return False
    return isinstance(setting, dict) and setting.get("enabled") is True


def set_enabled(data_dir, enabled):
    if type(enabled) is not bool:
        raise ValueError("Auto-logoff setting must be a boolean")
    os.makedirs(data_dir, exist_ok=True)
    _atomic_write(preference_file(data_dir),
                  (json.dumps({"enabled": enabled}) + "\n").encode("utf-8"), 0o644)


def _atomic_write(path, data, mode):
    fd, tmp = tempfile.mkstemp(prefix=".af3-idle-login-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, stat.S_IMODE(mode))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def apply(addons_dir, data_dir):
    """Install an opted-in timer or remove only the exact legacy managed timer."""
    path = skin_file(addons_dir)
    if not os.path.isdir(os.path.join(addons_dir, SKIN_ID)):
        return "missing"
    if not os.path.isfile(path):
        raise PatchError("Arctic Fuse Timers.xml is missing")

    with open(path, "rb") as handle:
        original_bytes = handle.read()
    original = original_bytes.decode("utf-8")
    enabled = is_enabled(data_dir)

    if enabled:
        if _TIMER_NAME in original:
            if original.count(_TIMER_NAME) != 1 or _TIMER.strip() not in original:
                raise PatchError("Arctic Fuse already defines a different auto_skin_login timer")
            return "unchanged"
        if original.count("<timers>") != 1 or original.count("</timers>") != 1:
            raise PatchError("Arctic Fuse Timers.xml layout changed")
        if original.count("<name>splashtest_autotime</name>") != 1:
            raise PatchError("Arctic Fuse timer anchor changed")
        updated = original.replace("</timers>", _TIMER + "</timers>", 1)
    else:
        if _TIMER_NAME not in original:
            return "unchanged"
        if original.count(_TIMER_NAME) != 1 or original.count(_TIMER) != 1:
            raise PatchError("Arctic Fuse has a different auto_skin_login timer; not removing it")
        updated = original.replace(_TIMER, "", 1)

    try:
        ET.fromstring(updated)
    except ET.ParseError as exc:
        raise PatchError("Modified Timers.xml would not parse: {}".format(exc)) from exc
    with open(path, "rb") as handle:
        if handle.read() != original_bytes:
            raise PatchError("Timers.xml changed concurrently; retry on next event")
    if is_enabled(data_dir) != enabled:
        raise PatchError("Auto-logoff preference changed concurrently; retry")
    _atomic_write(path, updated.encode("utf-8"), os.stat(path).st_mode)
    return "changed"
