"""Read-only Kodi provider-ID inspector for Jellyfin testing."""

import json
import os
import re
import sqlite3
import urllib.parse

MEDIA = {
    "movie": ("movie", "idMovie", "c09", "movieid"),
    "tvshow": ("tvshow", "idShow", "c12", "tvshowid"),
    "episode": ("episode", "idEpisode", "c20", "episodeid"),
}


class InspectorError(RuntimeError):
    pass


def _rpc(method, **params):
    import xbmc

    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params
    })))
    if "error" in response:
        raise InspectorError(
            "{}: {}".format(method, response["error"].get("message", "Failed")))
    return response.get("result", {})


def _items(method, result_key, limit=250, **params):
    items = []
    start = 0
    while True:
        page = _rpc(method, limits={"start": start, "end": start + limit}, **params)
        items.extend(page.get(result_key) or [])
        info = page.get("limits", {})
        end = info.get("end", len(items))
        if end >= info.get("total", len(items)):
            return items
        if end <= start:
            raise InspectorError("Kodi returned an incomplete library listing")
        start = end


def _choose(title, entries):
    import xbmcgui

    if not entries:
        xbmcgui.Dialog().ok("Kodi Provider IDs", "No matching library items found.")
        return None
    picked = xbmcgui.Dialog().select(title, [label for label, _ in entries])
    return entries[picked][1] if picked >= 0 else None


def _find_title(media_type):
    import xbmcgui

    title = "Search Kodi movies" if media_type == "movie" else "Search Kodi TV shows"
    term = xbmcgui.Dialog().input(title, type=xbmcgui.INPUT_ALPHANUM).strip()
    if not term:
        return None
    if media_type == "movie":
        method, key, id_key = "VideoLibrary.GetMovies", "movies", "movieid"
    else:
        method, key, id_key = "VideoLibrary.GetTVShows", "tvshows", "tvshowid"
    items = _items(
        method, key, filter={"field": "title", "operator": "contains", "value": term},
        properties=["title", "year"])
    entries = [
        ("{} ({})".format(item.get("title") or item.get("label", "Untitled"),
                          item.get("year") or "unknown year"),
         int(item[id_key]))
        for item in items
    ]
    return _choose("Kodi {}".format("Movies" if media_type == "movie" else "TV Shows"), entries)


def _find_episode():
    show_id = _find_title("tvshow")
    if show_id is None:
        return None
    seasons = _items(
        "VideoLibrary.GetSeasons", "seasons", tvshowid=show_id,
        properties=["season"])
    season = _choose(
        "Select season",
        [("Season {}".format(s["season"]) if s["season"] >= 0 else "Specials",
          s["season"]) for s in seasons if s.get("season") is not None])
    if season is None:
        return None
    episodes = _items(
        "VideoLibrary.GetEpisodes", "episodes", tvshowid=show_id,
        season=season, properties=["title", "season", "episode"])
    return _choose(
        "Select episode",
        [("S{:02d}E{:02d} — {}".format(
            e.get("season", 0), e.get("episode", 0),
            e.get("title") or e.get("label", "Untitled")),
          int(e["episodeid"])) for e in episodes])


def _video_database():
    import xbmcvfs

    folder = xbmcvfs.translatePath("special://database/")
    candidates = []
    for filename in os.listdir(folder):
        match = re.fullmatch(r"MyVideos([0-9]+)\.db", filename)
        if match:
            candidates.append((int(match.group(1)), os.path.join(folder, filename)))
    if not candidates:
        raise InspectorError("Kodi video database not found")
    return max(candidates)[1]


def read_ids(media_type, media_id, database_path=None):
    """Return provider rows and Kodi's default ID reference without changing the DB."""
    if media_type not in MEDIA:
        raise InspectorError("Unsupported media type")
    table, id_col, default_col, _ = MEDIA[media_type]
    path = database_path or _video_database()
    uri = "file:{}?mode=ro".format(urllib.parse.quote(path, safe="/"))
    conn = sqlite3.connect(uri, uri=True, timeout=3)
    try:
        conn.execute("PRAGMA query_only=ON")
        row = conn.execute(
            "SELECT {} FROM {} WHERE {} = ?".format(
                default_col, table, id_col), (media_id,)).fetchone()
        if row is None:
            raise InspectorError("This item is no longer in Kodi's video database")
        ids = conn.execute(
            "SELECT uniqueid_id, type, value FROM uniqueid "
            "WHERE media_type = ? AND media_id = ? ORDER BY uniqueid_id",
            (media_type, media_id)).fetchall()
        return {"default": row[0], "ids": ids}
    finally:
        conn.close()


def _describe(media_type, media_id, data):
    rows = data["ids"]
    default = data["default"]
    default_row = next((item for item in rows if item[0] == default), None)
    header = [
        "Kodi {} ID: {}".format(media_type, media_id),
        "Default provider: {}".format(
            default_row[1] if default_row else ("None" if not default else "Missing row")),
        "",
    ]
    if not rows:
        header.append("No provider IDs stored.")
    for unique_id, provider, value in rows:
        label = provider or "(no provider)"
        header.append("{}: {}{}".format(
            label.upper(), value or "(empty)",
            "  [DEFAULT]" if unique_id == default else ""))
    counts = {}
    for _, provider, _ in rows:
        counts[provider] = counts.get(provider, 0) + 1
    duplicates = sorted((key or "(no provider)") for key, count in counts.items()
                        if count > 1)
    if duplicates:
        header.extend(["", "Duplicate provider entries: " + ", ".join(duplicates)])
    if default and not default_row:
        header.extend(["", "Warning: Kodi's default ID row is missing."])
    return "\n".join(header)


def inspect():
    """Browse Kodi's library and inspect typed provider IDs; never write to Kodi."""
    import xbmcgui

    chosen = xbmcgui.Dialog().select(
        "Kodi Utilities — Inspect Provider IDs",
        ["Movies", "TV Shows", "Episodes"])
    if chosen < 0:
        return
    kind = ("movie", "tvshow", "episode")[chosen]
    media_id = _find_episode() if kind == "episode" else _find_title(kind)
    if media_id is None:
        return
    while True:
        data = read_ids(kind, media_id)
        xbmcgui.Dialog().textviewer(
            "Kodi Provider IDs", _describe(kind, media_id, data))
        if xbmcgui.Dialog().select(
                "Provider IDs", ["Refresh this item", "Back"]) != 0:
            return
