"""Reboot-safe TMDbHelper Sync missing-ID fix for CoreELEC."""

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import urllib.request
import xml.etree.ElementTree as ET

ADDON_ID = "script.module.tmdbhelper.sync.kodi"
VERSION = "1.1.4"
COMMIT = "3f38216bfcac6c18d5d8b51e57b0dd4da45053df"
# The published 1.1.4 add-on is pinned at 48fa258 in Jurialmunkey's repo:
# it STILL has the missing-uniqueid crash. 6b3ab1 fixed it later without a bump.
BASE_GIT_SHA = "ca0b8cec1025238713f4c50c4bfac4ccb47e9090"
# Also accept the later fixed GitHub source if manually installed as 1.1.4.
POST_RELEASE_BASE_GIT_SHA = "a08de41f73aa74cf421e8e471d6e4673252c58a7"
PATCH_GIT_SHA = "4bede96600888b4d6014445ea054bbc3ba055750"
RELATIVE_FILE = "resources/lib/tmdbhelper_sync_kodi/library.py"
ROOT = "/storage/.config/kodi-utilities/tmdbhelper-sync-test"
STAGED = os.path.join(ROOT, "library.py")
MARKER = os.path.join(ROOT, "patch.json")
DOWNLOAD_LIMIT = 1024 * 1024


class TMDbSyncTestError(RuntimeError):
    pass


def _git_sha(data):
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def _supported_base_hashes():
    """Exact vetted 1.1.4 source files: published first, post-fix second."""
    return (BASE_GIT_SHA, POST_RELEASE_BASE_GIT_SHA)


def _file_git_sha(path):
    with open(path, "rb") as stream:
        return _git_sha(stream.read())


def _sha256(path):
    with open(path, "rb") as stream:
        return hashlib.sha256(stream.read()).hexdigest()


def _installed():
    import xbmcaddon
    import xbmcvfs

    try:
        path = os.path.realpath(xbmcvfs.translatePath(
            xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")))
    except RuntimeError as exc:
        raise TMDbSyncTestError("TMDbHelper Sync - Kodi is not installed") from exc
    if path != "/storage/.kodi/addons/" + ADDON_ID:
        raise TMDbSyncTestError("Only the standard CoreELEC add-on path is supported")
    addon_xml = os.path.join(path, "addon.xml")
    if not os.path.isfile(addon_xml):
        raise TMDbSyncTestError("TMDbHelper Sync addon.xml is missing")
    root = ET.parse(addon_xml).getroot()
    if root.tag != "addon" or root.get("id") != ADDON_ID:
        raise TMDbSyncTestError("Unexpected TMDbHelper Sync add-on")
    return path, root.get("version", "")


REQUIRED_COMMANDS = ("systemd-run", "systemctl", "mount", "umount", "awk", "stat")


def _missing_requirements():
    missing = [tool for tool in REQUIRED_COMMANDS if shutil.which(tool) is None]
    if not os.access("/proc/self/mountinfo", os.R_OK):
        missing.append("/proc/self/mountinfo")
    return missing


def _supported():
    return not _missing_requirements()


def _mounted(target):
    # BusyBox mountpoint can falsely reject same-filesystem bind mounts.
    with open("/proc/self/mountinfo", encoding="utf-8") as mounts:
        return any(line.split()[4] == target for line in mounts if len(line.split()) > 4)


def _marker_valid(expected_original_sha=None):
    try:
        with open(MARKER, encoding="utf-8") as handle:
            marker = json.load(handle)
        return (marker.get("commit") == COMMIT
                and marker.get("version") == VERSION
                and marker.get("original_sha") in _supported_base_hashes()
                and (expected_original_sha is None
                     or marker.get("original_sha") == expected_original_sha)
                and marker.get("patch_sha") == PATCH_GIT_SHA
                and _file_git_sha(STAGED) == PATCH_GIT_SHA)
    except (OSError, ValueError, TypeError):
        return False


def _active_is_ours(target):
    try:
        return (_marker_valid()
                and os.path.samefile(target, STAGED)
                and _file_git_sha(target) == PATCH_GIT_SHA)
    except OSError:
        return False


def status():
    try:
        addon, version = _installed()
        target = os.path.join(addon, RELATIVE_FILE)
        if not _supported():
            return "unsupported"
        if _mounted(target):
            return "active" if _active_is_ours(target) else "foreign_mount"
        installed_sha = _file_git_sha(target)
        if version != VERSION or installed_sha not in _supported_base_hashes():
            return "incompatible"
        if os.path.lexists(STAGED) or os.path.lexists(MARKER):
            return "staged" if _marker_valid(installed_sha) else "stale"
        return "not_downloaded"
    except (TMDbSyncTestError, ET.ParseError, OSError):
        return "unavailable"


def stage():
    """Download and verify the single modified file; do not touch Kodi."""
    current = status()
    if current in ("active", "foreign_mount"):
        raise TMDbSyncTestError("An add-on bind mount is active; restore it first")
    if current == "unsupported":
        raise TMDbSyncTestError(
            "Missing CoreELEC requirement(s): " + ", ".join(_missing_requirements()))
    if current == "incompatible":
        addon, version = _installed()
        if version != VERSION:
            raise TMDbSyncTestError(
                "Requires TMDbHelper Sync - Kodi {}; found {}".format(VERSION, version))
        raise TMDbSyncTestError(
            "Installed TMDbHelper Sync library.py differs from expected {} source".format(VERSION))
    if current not in ("staged", "not_downloaded", "stale"):
        raise TMDbSyncTestError("Cannot stage TMDbHelper Sync patch: {}".format(current))
    addon, version = _installed()
    target = os.path.join(addon, RELATIVE_FILE)
    installed_sha = _file_git_sha(target)
    if version != VERSION or installed_sha not in _supported_base_hashes():
        raise TMDbSyncTestError("Installed TMDbHelper Sync code differs from approved {} sources".format(VERSION))
    if current == "staged":
        return "unchanged"

    url = ("https://raw.githubusercontent.com/Roboatlas21/"
           "script.module.tmdbhelper.sync.kodi/" + COMMIT + "/" + RELATIVE_FILE)
    request = urllib.request.Request(url, headers={
        "User-Agent": "KodiUtilities-TMDbSyncTest/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = response.read(DOWNLOAD_LIMIT + 1)
    if len(payload) > DOWNLOAD_LIMIT or _git_sha(payload) != PATCH_GIT_SHA:
        raise TMDbSyncTestError("Downloaded TMDbHelper Sync patch verification failed")

    os.makedirs(ROOT, exist_ok=True)
    temporary = STAGED + ".part-{}".format(os.getpid())
    if os.path.lexists(temporary):
        raise TMDbSyncTestError("Previous incomplete patch download needs cleanup")
    try:
        with open(temporary, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, STAGED)
        metadata = {"commit": COMMIT, "version": VERSION,
                    "original_sha": installed_sha, "patch_sha": PATCH_GIT_SHA}
        marker_part = MARKER + ".part-{}".format(os.getpid())
        with open(marker_part, "w", encoding="utf-8") as stream:
            json.dump(metadata, stream)
        os.replace(marker_part, MARKER)
        if not _marker_valid():
            raise TMDbSyncTestError("Staged patch failed verification")
        return "changed"
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _schedule(label, script):
    result = subprocess.run(
        ["systemd-run", "--unit={}--{}".format(label, os.getpid()),
         "--no-block", "/bin/sh", "-c", script],
        check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        universal_newlines=True)
    if result.returncode:
        raise TMDbSyncTestError(result.stdout.strip() or "Could not restart Kodi")


def _mount_test(target):
    return ("awk -v target={target} '$5 == target {{ found=1; exit }} "
            "END {{ exit !found }}' /proc/self/mountinfo").format(
                target=shlex.quote(target))


def _samefile_test(target):
    # Compare device/inode, not content: only the exact staged file may be unmounted.
    return ('[ "$(stat -c %d:%i {staged} 2>/dev/null)" = '
            '"$(stat -c %d:%i {target} 2>/dev/null)" ]').format(
                staged=shlex.quote(STAGED), target=shlex.quote(target))


def activate():
    """Bind-mount the patched Python file for this boot and restart Kodi."""
    current = status()
    if current == "active":
        return "unchanged"
    if current != "staged":
        raise TMDbSyncTestError("Stage a compatible, verified patch first")
    addon, _ = _installed()
    target = os.path.join(addon, RELATIVE_FILE)
    script = """set -eu
sleep 1
systemctl stop kodi.service
if [ ! -r /proc/self/mountinfo ] || {check}; then
  systemctl start kodi.service
  exit 1
fi
if ! mount --bind {staged} {target}; then
  systemctl start kodi.service
  exit 1
fi
if ! {check} || [ ! -f {staged} ] || [ ! -f {target} ] || ! {samefile}; then
  umount {target} || true
  systemctl start kodi.service
  exit 1
fi
systemctl start kodi.service
""".format(check=_mount_test(target), staged=shlex.quote(STAGED),
           target=shlex.quote(target), samefile=_samefile_test(target))
    _schedule("kodi-utilities-tmdb-sync-test", script)
    return "scheduled"


def restore(remove=False):
    """Restore the original module without removing settings or history."""
    current = status()
    if current == "foreign_mount":
        raise TMDbSyncTestError("Unknown add-on bind mount; refusing to unmount")
    if current in ("unsupported", "unavailable"):
        raise TMDbSyncTestError("Cannot verify the installed add-on or mount state")
    if current != "active":
        return remove_staged() if remove else "unchanged"
    addon, _ = _installed()
    target = os.path.join(addon, RELATIVE_FILE)
    cleanup = "rm -rf {} || true".format(shlex.quote(ROOT)) if remove else ":"
    script = """set -eu
sleep 1
systemctl stop kodi.service
if [ ! -r /proc/self/mountinfo ] || ! {check} || [ ! -f {staged} ] || [ ! -f {target} ] || ! {samefile}; then
  systemctl start kodi.service
  exit 1
fi
if ! umount {target}; then
  systemctl start kodi.service
  exit 1
fi
if {check}; then
  systemctl start kodi.service
  exit 1
fi
{cleanup}
systemctl start kodi.service
""".format(check=_mount_test(target), staged=shlex.quote(STAGED),
           target=shlex.quote(target), samefile=_samefile_test(target),
           cleanup=cleanup)
    _schedule("kodi-utilities-tmdb-sync-restore", script)
    return "scheduled"


def remove_staged():
    """Remove only this test's downloaded files; restore first if mounted."""
    current = status()
    if not os.access("/proc/self/mountinfo", os.R_OK):
        raise TMDbSyncTestError("Cannot verify mount table; refusing to delete patch files")
    target = os.path.join("/storage/.kodi/addons/" + ADDON_ID, RELATIVE_FILE)
    if _mounted(target):
        if current == "active":
            return restore(remove=True)
        raise TMDbSyncTestError("Unknown bind mount; refusing to remove patch files")
    if not os.path.lexists(ROOT):
        return "unchanged"
    if os.path.islink(ROOT) or not os.path.isdir(ROOT):
        raise TMDbSyncTestError("Unexpected staging path; refusing to remove")
    shutil.rmtree(ROOT)
    return "changed"
