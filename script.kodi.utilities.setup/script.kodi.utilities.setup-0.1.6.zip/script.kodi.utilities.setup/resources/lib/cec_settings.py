"""Narrow CoreELEC CEC setting support, never a generic filesystem operation.

CEC options are peripheral settings, not Kodi JSON-RPC settings. The active
adapter persists them on Kodi shutdown, so the only safe write window is
after Kodi has stopped and before it restarts.
"""

import os
import secrets
import shutil
import subprocess
import xml.etree.ElementTree as ET

import xbmcvfs

# Exact, separately approved keys. The public profile may request only Stop.
CEC_ALLOWED = {
    "standby_pc_on_tv_standby": frozenset((36028, 13005, 13011, 13010, 13009, 36044, 36045)),
    "pause_or_stop_playback_on_deactivate": frozenset((231, 36044, 36045)),
}
CEC_LABELS = {
    "standby_pc_on_tv_standby": "When the TV is switched off",
    "pause_or_stop_playback_on_deactivate": "Action when switching to another source",
}


class CecUnavailable(RuntimeError):
    """The adapter or requested key is not available on this installation."""


def system_settings_path():
    return xbmcvfs.translatePath("special://xbmc/system/peripherals.xml")


def data_directory():
    return xbmcvfs.translatePath("special://profile/peripheral_data")


def available_keys(path=None):
    path = path or system_settings_path()
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as exc:
        raise CecUnavailable("Cannot read Kodi's CEC definitions: {}".format(exc))
    for peripheral in root.findall("peripheral"):
        if peripheral.get("bus") == "cec":
            return {item.get("key") for item in peripheral.findall("setting")
                    if item.get("type") == "enum"}
    raise CecUnavailable("No CEC adapter settings are defined on this build")


def saved_settings_path(folder=None):
    """Only select one known CEC adapter file, never edit guessed alternatives."""
    folder = folder or data_directory()
    try:
        matches = [os.path.join(folder, name) for name in os.listdir(folder)
                   if name.startswith("cec_") and name.endswith(".xml")
                   and os.path.isfile(os.path.join(folder, name))
                   and not os.path.islink(os.path.join(folder, name))]
    except OSError as exc:
        raise CecUnavailable("CEC preferences are not yet saved: {}".format(exc))
    if not matches:
        raise CecUnavailable("CEC preferences not found. Open the HDMI-CEC settings, save, and try again")
    if len(matches) != 1:
        raise CecUnavailable("Multiple CEC adapter preference files found; select the correct device manually")
    return matches[0]


def read_saved(file_path, key):
    try:
        root = ET.parse(file_path).getroot()
    except (ET.ParseError, OSError) as exc:
        raise CecUnavailable("Cannot read saved CEC preferences: {}".format(exc))
    if root.tag != "settings":
        raise CecUnavailable("Unexpected CEC preferences format")
    matches = [item for item in root.findall("setting") if item.get("id") == key]
    if len(matches) != 1:
        raise CecUnavailable("CEC option is not yet saved: {}".format(CEC_LABELS[key]))
    value = matches[0].get("value")
    try:
        number = int(value)
    except (ValueError, TypeError):
        raise CecUnavailable("Invalid saved CEC value for {}".format(CEC_LABELS[key]))
    if number not in CEC_ALLOWED[key]:
        raise CecUnavailable("Unexpected saved CEC value for {}".format(CEC_LABELS[key]))
    return number


def unavailable_reason(op):
    if op["id"] not in available_keys():
        return "Not supported by this CoreELEC build: {}".format(CEC_LABELS[op["id"]])
    try:
        read_saved(saved_settings_path(), op["id"])
    except CecUnavailable as exc:
        return str(exc)
    return None


def read(op):
    key = op["id"]
    if key not in available_keys():
        raise CecUnavailable("CEC option unavailable: {}".format(CEC_LABELS[key]))
    return read_saved(saved_settings_path(), key)


def status_path(addon_dir):
    return os.path.join(addon_dir, "cec_job.status")


def status(addon_dir):
    try:
        with open(status_path(addon_dir), "r", encoding="utf-8") as handle:
            return handle.read().strip()
    except FileNotFoundError:
        return ""


def require_no_pending(addon_dir):
    value = status(addon_dir)
    if value in ("scheduled", "running"):
        raise RuntimeError("A CEC update is already scheduled. Wait for Kodi to restart before retrying")
    # A failed worker has exited and can be retried after the user reviews
    # the failure in Check for Updates; don't leave an unresettable lock.


def schedule(changes, addon_dir, worker_path):
    """Schedule an independent systemd timer to stop Kodi, patch, restart it.

    The worker rechecks exact prior values AFTER stopping Kodi and refuses a
    changed/ambiguous file. This prevents stale preview values overwriting
    changes that Kodi persisted during its shutdown.
    """
    if not changes:
        raise RuntimeError("Cannot schedule an empty CEC change")
    require_no_pending(addon_dir)
    if not shutil.which("systemd-run") or not shutil.which("systemctl"):
        raise RuntimeError("CEC configuration requires CoreELEC systemd-run and systemctl")
    cec_file = saved_settings_path()
    for change in changes:
        op = change["operation"]
        key, old, new = op["id"], change["before"], change["after"]
        if key not in CEC_ALLOWED or type(old) is not int or type(new) is not int:
            raise RuntimeError("Invalid CEC change")
        if old not in CEC_ALLOWED[key] or new not in CEC_ALLOWED[key]:
            raise RuntimeError("CEC value outside permitted options")
        if key not in available_keys():
            raise RuntimeError("CEC setting disappeared; run Preview again")
        if read_saved(cec_file, key) != old:
            raise RuntimeError("CEC preferences changed since preview; please try again")
    os.makedirs(addon_dir, exist_ok=True)
    token = secrets.token_hex(6)
    plan = os.path.join(addon_dir, "cec_job_{}.plan".format(token))
    worker = os.path.join(addon_dir, "cec_worker.sh")
    logfile = os.path.join(addon_dir, "cec_job.log")
    # Use only trusted package content and exact allowlisted CEC IDs/integers.
    shutil.copyfile(worker_path, worker)
    os.chmod(worker, 0o700)
    with open(plan + ".tmp", "w", encoding="ascii") as handle:
        for item in changes:
            handle.write("{} {} {}\n".format(item["operation"]["id"], item["before"], item["after"]))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(plan + ".tmp", plan)
    os.chmod(plan, 0o600)
    with open(status_path(addon_dir), "w", encoding="ascii") as handle:
        handle.write("scheduled\n")
        handle.flush()
        os.fsync(handle.fileno())
    # --on-active starts a transient *systemd timer*, not a process inside
    # kodi.service's cgroup, so Kodi can be safely stopped and restarted.
    argv = ["systemd-run", "--unit=kodi-utilities-cec-{}".format(token),
            "--on-active=12s", "/bin/sh", worker, plan, cec_file,
            status_path(addon_dir), logfile]
    try:
        result = subprocess.run(argv, capture_output=True, text=True, timeout=12, check=False)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "systemd-run failed")
    except Exception:
        try:
            os.remove(status_path(addon_dir))
        except FileNotFoundError:
            pass
        raise
    return token
