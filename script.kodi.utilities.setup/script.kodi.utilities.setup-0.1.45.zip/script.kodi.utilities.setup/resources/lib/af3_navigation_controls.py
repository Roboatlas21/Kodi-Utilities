"""Persistent AF3 navigation toggles and actual file-state inspection."""
import os
import xml.etree.ElementTree as ET
from . import af3_black_screen_fix as home
from . import startup_branding
from . import af3_idle_login

MARKER = "af3_settings_navigation_fix.disabled"
ORIGINAL = '                <onclick>ActivateWindow(settings)</onclick>'
PATCHED = '                <onclick>ReplaceWindow(settings)</onclick>'


def settings_enabled(data_dir):
    return not os.path.exists(os.path.join(data_dir, MARKER))


def _mark(data_dir, disabled):
    path = os.path.join(data_dir, MARKER)
    if disabled:
        os.makedirs(data_dir, exist_ok=True)
        if not os.path.exists(path):
            home._atomic_write(path, b"disabled\n", 0o644)
    elif os.path.isfile(path):
        os.unlink(path)


def detect_settings(addons_dir):
    path = home.skin_files(addons_dir)[home.BUTTON_FILENAME]
    if not os.path.isfile(path):
        return "missing"
    with open(path, encoding="utf-8") as file:
        content = file.read()
    old, new = content.count(ORIGINAL), content.count(PATCHED)
    return "original" if (old, new) == (1, 0) else (
        "patched" if (old, new) == (0, 1) else "unknown")


def apply_settings(addons_dir, data_dir):
    if not settings_enabled(data_dir):
        return "disabled"
    return home.apply_button_menu(addons_dir)


def _edit_settings(addons_dir, data_dir, enable):
    state = detect_settings(addons_dir)
    if state == "missing":
        return "missing"
    if state not in ("original", "patched"):
        raise home.PatchError("Unknown Settings navigation; refusing to edit")
    wanted = "patched" if enable else "original"
    if state == wanted:
        _mark(data_dir, not enable)
        return "unchanged"
    path = home.skin_files(addons_dir)[home.BUTTON_FILENAME]
    with open(path, "rb") as file:
        before = file.read()
    old, new = (ORIGINAL, PATCHED) if enable else (PATCHED, ORIGINAL)
    updated = before.decode("utf-8").replace(old, new, 1)
    try:
        ET.fromstring(updated)
    except ET.ParseError as error:
        raise home.PatchError("Invalid AF3 Settings navigation XML") from error
    if not enable:
        _mark(data_dir, True)  # Block service reapplication before writing.
    with open(path, "rb") as file:
        if file.read() != before:
            raise home.PatchError("AF3 Settings XML changed during edit")
    home._atomic_write(path, updated.encode("utf-8"), os.stat(path).st_mode)
    if detect_settings(addons_dir) != wanted:
        raise home.PatchError("AF3 Settings XML verification failed")
    if enable:
        _mark(data_dir, False)
    return "changed"


def disable_all(addons_dir, data_dir, skin_version=""):
    state = (home.detect_home(addons_dir), detect_settings(addons_dir))
    if "missing" in state:
        return "missing"
    if "unknown" in state:
        raise home.PatchError("Unknown AF3 navigation layout; no edits made")
    a = home.remove_home(addons_dir, data_dir, skin_version=skin_version)
    b = _edit_settings(addons_dir, data_dir, enable=False)
    return "changed" if "changed" in (a, b) else "unchanged"


def restore_all(addons_dir, data_dir, skin_version=""):
    state = (home.detect_home(addons_dir), detect_settings(addons_dir))
    if "missing" in state:
        return "missing"
    if "unknown" in state:
        raise home.PatchError("Unknown AF3 navigation layout; no edits made")
    a = home.restore_home(addons_dir, data_dir, skin_version=skin_version)
    b = _edit_settings(addons_dir, data_dir, enable=True)
    return "changed" if "changed" in (a, b) else "unchanged"


def detect_branding(addons_dir):
    path = startup_branding.skin_file(addons_dir)
    if not os.path.isfile(path):
        return "missing"
    try:
        with open(path, encoding="utf-8") as file:
            content = file.read()
        a, b = startup_branding._title_bounds(content)
        content = content[a:b]
        if all(label in content for label in startup_branding._CUSTOM_LABELS):
            return "custom"
        if all(label in content for label in (
            "<label>Arctic</label>", "<label>Fuse</label>",
            "<label>$NUMBER[3]</label>")):
            return "original"
    except (OSError, UnicodeError, ValueError, startup_branding.BrandingError):
        pass
    return "unknown"


def detect_idle_timer(addons_dir):
    path = af3_idle_login.skin_file(addons_dir)
    if not os.path.isfile(path):
        return "missing"
    with open(path, encoding="utf-8") as file:
        content = file.read()
    if af3_idle_login._TIMER_NAME not in content:
        return "original"
    return ("active" if content.count(af3_idle_login._TIMER_NAME) == 1
            and content.count(af3_idle_login._TIMER) == 1 else "unknown")
